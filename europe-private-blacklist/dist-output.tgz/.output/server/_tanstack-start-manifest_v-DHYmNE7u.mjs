// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHYmNE7u.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BqNZX46z.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BqNZX46z.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CoCU7hu7.js"]
	}
} });
export { tsrStartManifest };
