//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BeX3DbEV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BZGXcnWW.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BZGXcnWW.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DzgITWJD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
