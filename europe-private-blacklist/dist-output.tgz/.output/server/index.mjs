globalThis.__nitro_main__ = import.meta.url;
import { a as handleCacheHeaders, c as toResponse, i as defineLazyEventHandler, l as NodeResponse, n as HTTPError, o as toEventHandler, r as defineHandler, t as H3Core, u as serve } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { n as setStorage, t as defineCachedHandler$1 } from "./_libs/ocache+ohash.mjs";
import { n as prefixStorage, t as createStorage } from "./_libs/unstorage.mjs";
import nodeHTTP from "node:http";
import { existsSync, promises, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join, resolve } from "node:path";
import { EventEmitter } from "node:events";
import { inspect } from "node:util";
// #nitro/virtual/server-assets
var _assets = {};
var normalizeKey = function normalizeKey(key) {
	if (!key) return "";
	return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};
var assets = {
	getKeys() {
		return Promise.resolve(Object.keys(_assets));
	},
	hasItem(id) {
		id = normalizeKey(id);
		return Promise.resolve(id in _assets);
	},
	getItem(id) {
		id = normalizeKey(id);
		return Promise.resolve(_assets[id] ? _assets[id].import() : null);
	},
	getMeta(id) {
		id = normalizeKey(id);
		return Promise.resolve(_assets[id] ? _assets[id].meta : {});
	}
};
// #nitro/virtual/storage
function initStorage() {
	const storage = createStorage({});
	storage.mount("/assets", assets);
	return storage;
}
// node_modules/nitro/dist/runtime/internal/storage.mjs
function useStorage(base = "") {
	const storage = useStorage._storage ??= initStorage();
	return base ? prefixStorage(storage, base) : storage;
}
// node_modules/nitro/dist/runtime/internal/cache.mjs
var _storageReady = false;
function ensureStorage() {
	if (_storageReady) return;
	_storageReady = true;
	const storage = useStorage();
	setStorage({
		get: (key) => storage.getItem(key),
		set: (key, value, opts) => storage.setItem(key, value, opts?.ttl ? { ttl: opts.ttl } : void 0)
	});
}
function defaultOnError(error) {
	console.error("[cache]", error);
	useNitroApp().captureError?.(error, { tags: ["cache"] });
}
function defineCachedHandler(handler, opts = {}) {
	ensureStorage();
	const ocacheHandler = defineCachedHandler$1(handler, {
		group: "nitro/handlers",
		onError: defaultOnError,
		toResponse: (value, event) => toResponse(value, event),
		createResponse: (body, init) => new NodeResponse(body, init),
		handleCacheHeaders: (event, conditions) => handleCacheHeaders(event, conditions),
		...opts
	});
	return defineHandler((event) => ocacheHandler(event));
}
// node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
var cache = ((m) => function cacheRouteRule(event, next) {
	if (!event.context.matchedRoute) return next();
	const cachedHandlers = globalThis.__nitroCachedHandlers ??= /* @__PURE__ */ new Map();
	const { handler, route } = event.context.matchedRoute;
	const key = `${m.route}:${route}`;
	let cachedHandler = cachedHandlers.get(key);
	if (!cachedHandler) {
		cachedHandler = defineCachedHandler(handler, {
			group: "nitro/route-rules",
			name: key,
			...m.options
		});
		cachedHandlers.set(key, cachedHandler);
	}
	return cachedHandler(event);
});
// #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/og.jpg": {
		"type": "image/jpeg",
		"etag": "\"c146-DPlJ+QxGZMdZY972RJdrCtbFvXw\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 49478,
		"path": "../public/og.jpg"
	},
	"/assets/engrave-BWsWeYZW.svg": {
		"type": "image/svg+xml",
		"etag": "\"3f66c-L1dSZryMBFwIScEesm/edrCPAGI\"",
		"mtime": "2026-10-24T11:29:18.510Z",
		"size": 259692,
		"path": "../public/assets/engrave-BWsWeYZW.svg"
	},
	"/assets/engrave-BWsWeYZW.svg.br": {
		"type": "image/svg+xml",
		"encoding": "br",
		"etag": "\"7991-SguTYFoQ2Zm/1JEPyqTj930qwgo\"",
		"mtime": "2026-10-24T11:29:19.680Z",
		"size": 31121,
		"path": "../public/assets/engrave-BWsWeYZW.svg.br"
	},
	"/assets/engrave-BWsWeYZW.svg.gz": {
		"type": "image/svg+xml",
		"encoding": "gzip",
		"etag": "\"ada9-F+M9/tOSFlOHkAivAVvM5pTk2OM\"",
		"mtime": "2026-10-24T11:29:19.288Z",
		"size": 44457,
		"path": "../public/assets/engrave-BWsWeYZW.svg.gz"
	},
	"/assets/engrave-BWsWeYZW.svg.zst": {
		"type": "image/svg+xml",
		"encoding": "zstd",
		"etag": "\"c95a-bqjmR6RzTYE6vSd7atkisMsUsfM\"",
		"mtime": "2026-10-24T11:29:19.288Z",
		"size": 51546,
		"path": "../public/assets/engrave-BWsWeYZW.svg.zst"
	},
	"/assets/index-BqNZX46z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"626fc-SGuLqBjFUQuj2QmF3EXAdtYzA6w\"",
		"mtime": "2026-10-24T11:29:18.508Z",
		"size": 403196,
		"path": "../public/assets/index-BqNZX46z.js"
	},
	"/assets/index-BqNZX46z.js.br": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "br",
		"etag": "\"1a9ea-PgJpLDstp43XWTwWzqkiiRsWMww\"",
		"mtime": "2026-10-24T11:29:20.028Z",
		"size": 109034,
		"path": "../public/assets/index-BqNZX46z.js.br"
	},
	"/assets/index-BqNZX46z.js.gz": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "gzip",
		"etag": "\"1ebcd-Z6ZAtmWVxJ7kNYTI6CMECsePNKc\"",
		"mtime": "2026-10-24T11:29:19.292Z",
		"size": 125901,
		"path": "../public/assets/index-BqNZX46z.js.gz"
	},
	"/assets/index-BqNZX46z.js.zst": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "zstd",
		"etag": "\"1fbd4-7BKOdsCiG6UPt/ybvBwWft2Rd4A\"",
		"mtime": "2026-10-24T11:29:19.292Z",
		"size": 130004,
		"path": "../public/assets/index-BqNZX46z.js.zst"
	},
	"/assets/routes-CoCU7hu7.js.br": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "br",
		"etag": "\"94c9-RBdNlUiglhkhWs9sTr/N41JUpJA\"",
		"mtime": "2026-10-24T11:29:19.448Z",
		"size": 38089,
		"path": "../public/assets/routes-CoCU7hu7.js.br"
	},
	"/assets/routes-CoCU7hu7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23ded-zwtGu/6aqI5670ivj8vWlzW8F1s\"",
		"mtime": "2026-10-24T11:29:18.510Z",
		"size": 146925,
		"path": "../public/assets/routes-CoCU7hu7.js"
	},
	"/assets/routes-CoCU7hu7.js.gz": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "gzip",
		"etag": "\"b03d-yoZAWUxzhfufe7aKxpk+byeBQnQ\"",
		"mtime": "2026-10-24T11:29:19.288Z",
		"size": 45117,
		"path": "../public/assets/routes-CoCU7hu7.js.gz"
	},
	"/assets/routes-CoCU7hu7.js.zst": {
		"type": "text/javascript; charset=utf-8",
		"encoding": "zstd",
		"etag": "\"b910-Jj6WebQjQPP9wZ1nlwAZhMmrl8w\"",
		"mtime": "2026-10-24T11:29:19.288Z",
		"size": 47376,
		"path": "../public/assets/routes-CoCU7hu7.js.zst"
	},
	"/assets/styles-C1oPopGC.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"be5d-mff3bNfyB/EZ/uWoYsoZyb9Q0XQ\"",
		"mtime": "2026-10-24T11:29:18.510Z",
		"size": 48733,
		"path": "../public/assets/styles-C1oPopGC.css"
	},
	"/assets/styles-C1oPopGC.css.br": {
		"type": "text/css; charset=utf-8",
		"encoding": "br",
		"etag": "\"222d-itY0jrf/Kuw8w3H0Snq6xneO8iw\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 8749,
		"path": "../public/assets/styles-C1oPopGC.css.br"
	},
	"/__grok/icon-180.png": {
		"type": "image/png",
		"etag": "\"834-Xk8vfS0DTFn7ggtkfEduWTcNWGE\"",
		"mtime": "2026-10-24T11:29:19.169Z",
		"size": 2100,
		"path": "../public/__grok/icon-180.png"
	},
	"/assets/styles-C1oPopGC.css.zst": {
		"type": "text/css; charset=utf-8",
		"encoding": "zstd",
		"etag": "\"299a-q6shRNRzf8dMW+K3+iXAV4Z7kzM\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 10650,
		"path": "../public/assets/styles-C1oPopGC.css.zst"
	},
	"/assets/styles-C1oPopGC.css.gz": {
		"type": "text/css; charset=utf-8",
		"encoding": "gzip",
		"etag": "\"273a-rCAW5PbeZEvTsSTrasMXLCFpKYI\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 10042,
		"path": "../public/assets/styles-C1oPopGC.css.gz"
	},
	"/brand/card.webp": {
		"type": "image/webp",
		"etag": "\"3229c-ocQ2o1GqeAJtY11rYPAWwolbyqg\"",
		"mtime": "2026-10-24T11:29:19.169Z",
		"size": 205468,
		"path": "../public/brand/card.webp"
	},
	"/brand/emblem-v2.png": {
		"type": "image/png",
		"etag": "\"3a609-vIg/bJJAEn7qpOHdga1RFDexCEk\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 239113,
		"path": "../public/brand/emblem-v2.png"
	},
	"/brand/emblem-v2.webp": {
		"type": "image/webp",
		"etag": "\"c0ce-RppvDGRRdPQtzKC5SOf2Awq3rEo\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 49358,
		"path": "../public/brand/emblem-v2.webp"
	},
	"/partners/animal-planet.png": {
		"type": "image/png",
		"etag": "\"a036-kuqWXDAgqN7CniLHZD20rfiT9YU\"",
		"mtime": "2026-10-24T11:29:19.169Z",
		"size": 41014,
		"path": "../public/partners/animal-planet.png"
	},
	"/partners/btc-detective.png": {
		"type": "image/png",
		"etag": "\"4ef2-1wGBRjsgLXFvv1hWDA4SzlDwQu8\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 20210,
		"path": "../public/partners/btc-detective.png"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"178-gBRbscbQ8+YCJAYxEL7PJLGsZa8\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 376,
		"path": "../public/favicon.svg"
	},
	"/partners/chernyi-spisok.png": {
		"type": "image/png",
		"etag": "\"8ca1-KiYu7J1Gr2kbR2PtLo+TzlxCS4k\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 36001,
		"path": "../public/partners/chernyi-spisok.png"
	},
	"/partners/cookie.png": {
		"type": "image/png",
		"etag": "\"51f5-K6Pz5R9uK1l+3lGyrxy9S2fG6Nk\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 20981,
		"path": "../public/partners/cookie.png"
	},
	"/partners/illidan.png": {
		"type": "image/png",
		"etag": "\"8915-cgZeqiT48r2Zkpl8e5acb4u+z0w\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 35093,
		"path": "../public/partners/illidan.png"
	},
	"/partners/imperial.png": {
		"type": "image/png",
		"etag": "\"5d94-okebcGB8vXg+FkdLQygDldkDpbQ\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 23956,
		"path": "../public/partners/imperial.png"
	},
	"/partners/kidalam.png": {
		"type": "image/png",
		"etag": "\"8cdb-0H/llTBM2jrS4JcXzgfFtqSQqYE\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 36059,
		"path": "../public/partners/kidalam.png"
	},
	"/partners/pi.png": {
		"type": "image/png",
		"etag": "\"3d5c-VqPJ5B3XE8jls49tXdsoG0CgJQ0\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 15708,
		"path": "../public/partners/pi.png"
	},
	"/partners/shopping-avenue.png": {
		"type": "image/png",
		"etag": "\"8b13-9dFPgpRk9d+DkfARB8NnQlkvD9c\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 35603,
		"path": "../public/partners/shopping-avenue.png"
	},
	"/partners/skam-desk.png": {
		"type": "image/png",
		"etag": "\"43fc-gmlBns2k3nNFXW1KsicdEfsPEkc\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 17404,
		"path": "../public/partners/skam-desk.png"
	},
	"/partners/ws-blacklist.png": {
		"type": "image/png",
		"etag": "\"8562-Sc7sSPyQSVzel6Sbp9rt6OTpq30\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 34146,
		"path": "../public/partners/ws-blacklist.png"
	},
	"/partners/z-black.png": {
		"type": "image/png",
		"etag": "\"8628-xB97wOe01yJ6vtKSePGtUNPVhmU\"",
		"mtime": "2026-10-24T11:29:19.171Z",
		"size": 34344,
		"path": "../public/partners/z-black.png"
	},
	"/partners/wwh.png": {
		"type": "image/png",
		"etag": "\"15059-nwFDjXlpW899yspaj9JlbKgtSCE\"",
		"mtime": "2026-10-24T11:29:19.171Z",
		"size": 86105,
		"path": "../public/partners/wwh.png"
	},
	"/bot/published.jpg": {
		"type": "image/jpeg",
		"etag": "\"a4b9-vECv/GLq38iObmEF8u7d8hxdkI8\"",
		"mtime": "2026-10-24T11:29:19.169Z",
		"size": 42169,
		"path": "../public/bot/published.jpg"
	},
	"/bot/submitted.jpg": {
		"type": "image/jpeg",
		"etag": "\"aa53-NLXnoN2CjDSIWqgtsgwZUm3wtJw\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 43603,
		"path": "../public/bot/submitted.jpg"
	},
	"/bot/welcome.jpg": {
		"type": "image/jpeg",
		"etag": "\"16e22-nO6DiPhYkKbN9WPFNzsV7CV0GMY\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 93730,
		"path": "../public/bot/welcome.jpg"
	},
	"/__grok/install/styles.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1a3d-VUsWOMAheo1/P30EqU5qaIkyvIQ\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 6717,
		"path": "../public/__grok/install/styles.css"
	},
	"/__grok/install/styles.css.br": {
		"type": "text/css; charset=utf-8",
		"encoding": "br",
		"etag": "\"5f3-Sk4fN87A7YnEXbnWRsXwAnoz2KY\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 1523,
		"path": "../public/__grok/install/styles.css.br"
	},
	"/__grok/install/styles.css.gz": {
		"type": "text/css; charset=utf-8",
		"encoding": "gzip",
		"etag": "\"70d-/EqltxW6w2euBUiSq8OHRSeVo0I\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 1805,
		"path": "../public/__grok/install/styles.css.gz"
	},
	"/__grok/install/styles.css.zst": {
		"type": "text/css; charset=utf-8",
		"encoding": "zstd",
		"etag": "\"7a2-ZIYC1iSbmQxQUpxK3/dVuAm7Phk\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 1954,
		"path": "../public/__grok/install/styles.css.zst"
	},
	"/__grok/install/assets/homescreen/glass-puzzle.svg": {
		"type": "image/svg+xml",
		"etag": "\"713-AP2wG8KChAGjse1Fn+f/+vDN+sQ\"",
		"mtime": "2026-10-24T11:29:19.171Z",
		"size": 1811,
		"path": "../public/__grok/install/assets/homescreen/glass-puzzle.svg"
	},
	"/__grok/install/assets/homescreen/glass-puzzle.svg.br": {
		"type": "image/svg+xml",
		"encoding": "br",
		"etag": "\"2e7-1ySN7KXr+VtyqfnYphJR94cux2E\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 743,
		"path": "../public/__grok/install/assets/homescreen/glass-puzzle.svg.br"
	},
	"/__grok/install/assets/homescreen/glass-puzzle.svg.gz": {
		"type": "image/svg+xml",
		"encoding": "gzip",
		"etag": "\"347-lUx07ksHJQV7tqgFW+Z8O9echNI\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 839,
		"path": "../public/__grok/install/assets/homescreen/glass-puzzle.svg.gz"
	},
	"/__grok/install/assets/homescreen/glass-puzzle.svg.zst": {
		"type": "image/svg+xml",
		"encoding": "zstd",
		"etag": "\"357-mCXto1mC1D1lByRGqsFpT9qWBGs\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 855,
		"path": "../public/__grok/install/assets/homescreen/glass-puzzle.svg.zst"
	},
	"/__grok/install/assets/homescreen/glass-share.svg": {
		"type": "image/svg+xml",
		"etag": "\"954-jb3ATcKjqgMOYrA/4w1v21j0Jvg\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 2388,
		"path": "../public/__grok/install/assets/homescreen/glass-share.svg"
	},
	"/bot/welcome.mp4": {
		"type": "video/mp4",
		"etag": "\"11f9b9-wafL2pY4udE2Puyv9ZKbuxTm1Jw\"",
		"mtime": "2026-10-24T11:29:19.170Z",
		"size": 1178041,
		"path": "../public/bot/welcome.mp4"
	},
	"/brand/sending-frog.webp": {
		"type": "image/webp",
		"etag": "\"230a2c-cUjA1LNSuRxtf6KxwGvilOaerC4\"",
		"mtime": "2026-10-24T11:29:19.171Z",
		"size": 2296364,
		"path": "../public/brand/sending-frog.webp"
	},
	"/__grok/install/assets/homescreen/glass-share.svg.br": {
		"type": "image/svg+xml",
		"encoding": "br",
		"etag": "\"3b7-XnnhSxk6EnoxWpaTsWyIJWMoPMY\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 951,
		"path": "../public/__grok/install/assets/homescreen/glass-share.svg.br"
	},
	"/__grok/install/assets/homescreen/glass-share.svg.gz": {
		"type": "image/svg+xml",
		"encoding": "gzip",
		"etag": "\"425-Hka14B/Bh99P/eXvV62D0wu7g1k\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 1061,
		"path": "../public/__grok/install/assets/homescreen/glass-share.svg.gz"
	},
	"/__grok/install/assets/homescreen/glass-share.svg.zst": {
		"type": "image/svg+xml",
		"encoding": "zstd",
		"etag": "\"441-ZBwQIzvzaNYCJSBzrQUymGe3Ews\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 1089,
		"path": "../public/__grok/install/assets/homescreen/glass-share.svg.zst"
	},
	"/__grok/install/assets/homescreen/logo-grok.svg": {
		"type": "image/svg+xml",
		"etag": "\"423-5mXO+yh9KW40jM3to5JlWPhxNK8\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 1059,
		"path": "../public/__grok/install/assets/homescreen/logo-grok.svg"
	},
	"/__grok/install/assets/homescreen/logo-grok.svg.br": {
		"type": "image/svg+xml",
		"encoding": "br",
		"etag": "\"21b-2R4aLEuAwfBcmQ9D8o4WGG0gyLU\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 539,
		"path": "../public/__grok/install/assets/homescreen/logo-grok.svg.br"
	},
	"/__grok/install/assets/homescreen/logo-grok.svg.gz": {
		"type": "image/svg+xml",
		"encoding": "gzip",
		"etag": "\"26b-SGnKLIkqeB8BxF2XtvvCGQJjdSQ\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 619,
		"path": "../public/__grok/install/assets/homescreen/logo-grok.svg.gz"
	},
	"/__grok/install/assets/homescreen/logo-grok.svg.zst": {
		"type": "image/svg+xml",
		"encoding": "zstd",
		"etag": "\"274-guRS5Rv09J47Gvejo7iEYbZC9y4\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 628,
		"path": "../public/__grok/install/assets/homescreen/logo-grok.svg.zst"
	},
	"/__grok/install/assets/homescreen/ob-ipad.png": {
		"type": "image/png",
		"etag": "\"18dd3-wlRwrpmBImStuiu+4poVz7ANin4\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 101843,
		"path": "../public/__grok/install/assets/homescreen/ob-ipad.png"
	},
	"/__grok/install/assets/homescreen/ob-phone.png": {
		"type": "image/png",
		"etag": "\"194bc-oZradWHIHO68q2glHU0Gk5ttpWA\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 103612,
		"path": "../public/__grok/install/assets/homescreen/ob-phone.png"
	},
	"/__grok/install/assets/homescreen/plus.svg": {
		"type": "image/svg+xml",
		"etag": "\"961-sSBPunx/13vbMNAlPxb7UeO3l3A\"",
		"mtime": "2026-10-24T11:29:19.172Z",
		"size": 2401,
		"path": "../public/__grok/install/assets/homescreen/plus.svg"
	},
	"/__grok/install/assets/homescreen/plus.svg.br": {
		"type": "image/svg+xml",
		"encoding": "br",
		"etag": "\"2e8-9MltmB2+9GlDbEou3MZcsGT3l30\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 744,
		"path": "../public/__grok/install/assets/homescreen/plus.svg.br"
	},
	"/__grok/install/assets/homescreen/plus.svg.gz": {
		"type": "image/svg+xml",
		"encoding": "gzip",
		"etag": "\"36e-RbvCSnTbJDH4dvNzmddbnDPwjgs\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 878,
		"path": "../public/__grok/install/assets/homescreen/plus.svg.gz"
	},
	"/__grok/install/assets/homescreen/plus.svg.zst": {
		"type": "image/svg+xml",
		"encoding": "zstd",
		"etag": "\"372-HOeHt1KMaUuy8ruFUGJ8ZdQ6XG4\"",
		"mtime": "2026-10-24T11:29:19.280Z",
		"size": 882,
		"path": "../public/__grok/install/assets/homescreen/plus.svg.zst"
	}
};
// #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
// #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
// node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
// scripts/install-page.html?raw
var install_page_default = "<!DOCTYPE html>\n<html lang=\"en\" class=\"device-desktop\">\n  <head>\n    <meta charset=\"utf-8\" />\n    <meta\n      name=\"viewport\"\n      content=\"width=device-width, initial-scale=1, viewport-fit=cover\"\n    />\n    <meta name=\"color-scheme\" content=\"dark\" />\n    <meta name=\"theme-color\" content=\"#000000\" />\n    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\" />\n    <meta name=\"apple-mobile-web-app-title\" content=\"{{APP_NAME}}\" />\n    <title>Add {{APP_NAME}} to your Home Screen</title>\n    <link rel=\"manifest\" href=\"/__grok/manifest.webmanifest\" />\n    <link rel=\"apple-touch-icon\" href=\"/__grok/icon-180.png\" />\n    <link rel=\"stylesheet\" href=\"/__grok/install/styles.css\" />\n    <script>\n      (function () {\n        var ua = navigator.userAgent || \"\";\n        var touch = navigator.maxTouchPoints || 0;\n        var isiPad = /iPad/.test(ua) || (/Macintosh/.test(ua) && touch > 1);\n        var isiPhone = /iPhone|iPod/.test(ua);\n        var isIOS = isiPhone || isiPad;\n        var isAndroid = /Android/i.test(ua);\n        var isAndroidPhone = isAndroid && /Mobile/i.test(ua);\n        var isAndroidTablet = isAndroid && !/Mobile/i.test(ua);\n        var minSide = Math.min(screen.width || 0, screen.height || 0);\n        var maxSide = Math.max(screen.width || 0, screen.height || 0);\n\n        var type = \"desktop\";\n        if (isiPhone) type = \"phone\";\n        else if (isiPad || isAndroidTablet) type = \"tablet\";\n        else if (isAndroidPhone) type = \"phone\";\n        else if (touch > 0 && minSide > 0 && minSide <= 500) type = \"phone\";\n        else if (touch > 0 && minSide > 500 && maxSide <= 1400) type = \"tablet\";\n\n        var iosMajor = null;\n        var osToken = null;\n        var safariToken = null;\n        var iphoneOs = ua.match(/iPhone OS (\\d+)[._]/);\n        var ipadOs = ua.match(/CPU OS (\\d+)[._](\\d+) like Mac OS X/);\n        var safariVer = ua.match(/Version\\/(\\d+)[._]/);\n        if (iphoneOs) osToken = parseInt(iphoneOs[1], 10);\n        else if (ipadOs) osToken = parseInt(ipadOs[1], 10);\n        if (isIOS && safariVer) safariToken = parseInt(safariVer[1], 10);\n        if (osToken != null || safariToken != null) {\n          iosMajor = Math.max(osToken || 0, safariToken || 0);\n        }\n\n        var root = document.documentElement;\n        var classes = [\"device-\" + type];\n        if (iosMajor != null) {\n          root.dataset.ios = String(iosMajor);\n          classes.push(iosMajor >= 27 ? \"ios-27-plus\" : \"ios-below-27\");\n        }\n        root.className = classes.join(\" \");\n      })();\n    <\/script>\n  </head>\n  <body>\n    <div class=\"page\">\n      <header class=\"powered\" aria-label=\"Powered by Grok\">\n        <span class=\"powered-by\">Powered by</span>\n        <span class=\"powered-brand\">\n          <img\n            class=\"grok-logo\"\n            src=\"/__grok/install/assets/homescreen/logo-grok.svg\"\n            width=\"14\"\n            height=\"14\"\n            alt=\"\"\n          />\n          <span class=\"powered-grok\">Grok</span>\n        </span>\n      </header>\n\n      <main class=\"content\">\n        <div class=\"ob\" aria-hidden=\"true\">\n          <img\n            class=\"ob-img ob-phone\"\n            src=\"/__grok/install/assets/homescreen/ob-phone.png\"\n            width=\"338\"\n            height=\"294\"\n            alt=\"\"\n          />\n          <img\n            class=\"ob-img ob-ipad\"\n            src=\"/__grok/install/assets/homescreen/ob-ipad.png\"\n            width=\"634\"\n            height=\"294\"\n            alt=\"\"\n          />\n        </div>\n\n        <section class=\"copy\">\n          <h1>Add {{APP_NAME}} to your&nbsp;Home&nbsp;Screen</h1>\n\n          <div class=\"steps\">\n            <p class=\"step step-tap step-ios27\">\n              <span class=\"muted\">Tap</span>\n              <span class=\"glass glass--icon\" aria-hidden=\"true\">\n                <img src=\"/__grok/install/assets/homescreen/glass-puzzle.svg\" width=\"24\" height=\"24\" alt=\"\" />\n              </span>\n              <span class=\"muted loc loc-phone\">in the bottom bar, then</span>\n              <span class=\"muted loc loc-ipad\">in the tool bar, then</span>\n              <span class=\"glass glass--icon\" aria-hidden=\"true\">\n                <img src=\"/__grok/install/assets/homescreen/glass-share.svg\" width=\"24\" height=\"24\" alt=\"\" />\n              </span>\n            </p>\n\n            <p class=\"step step-tap step-ios-legacy\">\n              <span class=\"muted\">Tap</span>\n              <span class=\"glass glass--icon\" aria-hidden=\"true\">\n                <img src=\"/__grok/install/assets/homescreen/glass-share.svg\" width=\"24\" height=\"24\" alt=\"\" />\n              </span>\n              <span class=\"muted loc loc-phone\">in the bottom bar</span>\n              <span class=\"muted loc loc-ipad\">in the tool bar</span>\n            </p>\n\n            <p class=\"step step-select\">\n              <span class=\"muted\">Select</span>\n              <span class=\"add-label\">\n                <img\n                  class=\"plus-icon\"\n                  src=\"/__grok/install/assets/homescreen/plus.svg\"\n                  width=\"16\"\n                  height=\"16\"\n                  alt=\"\"\n                />\n                <span class=\"add-text\">Add to Home Screen</span>\n              </span>\n            </p>\n          </div>\n        </section>\n      </main>\n\n      <main class=\"content content-desktop\">\n        <section class=\"copy\">\n          <h1>Open this link on your iPhone&nbsp;or&nbsp;iPad</h1>\n          <p class=\"desktop-note\">\n            This page shows how to add {{APP_NAME}} to an iOS Home Screen.\n          </p>\n          <a class=\"desktop-open\" href=\"{{APP_URL}}\">Open {{APP_NAME}}</a>\n        </section>\n      </main>\n    </div>\n  </body>\n</html>\n";
// \0virtual:grok-og-identity
var grokOgIdentity = { "site": {
	"title": "Europe Private Blacklist",
	"type": "website",
	"card": "custom",
	"description": "Private fraud registry",
	"image": "/og.jpg"
} };
// scripts/grok-pwa-shared.mjs
/**
* Single source of truth for platform head chrome (PWA, extensions.js, OG),
* shared by the Vite plugin and Nitro middleware. Plain ESM so `node --test`
* and the Nitro bundler can both consume it.
*/
var DEFAULT_APP_NAME = "Grok App";
var OG_SITE_REL_PATH = "src/lib/og/site.json";
var SHARE_META_KEYS = /* @__PURE__ */ new Set([
	"og:title",
	"og:description",
	"og:image",
	"og:image:width",
	"og:image:height",
	"og:type",
	"og:url",
	"og:site_name",
	"twitter:card",
	"twitter:title",
	"twitter:image",
	"twitter:description",
	"x:game:image",
	"x:game:image:width",
	"x:game:image:height"
]);
function escapeHtml(value) {
	return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'", "&#39;");
}
/** Inverse of escapeHtml. Decode &amp; last so a single pass undoes one encode. */
function unescapeHtml(value) {
	return String(value).replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&quot;", "\"").replaceAll("&#39;", "'").replaceAll("&amp;", "&");
}
/** 6-digit hex for the og.grok.me placeholder, or "" if site.color is missing/invalid. */
function placeholderCardColor(site = {}) {
	const raw = String(site.color ?? "").trim();
	const hex = raw.startsWith("#") ? raw.slice(1) : raw;
	return /^[0-9a-fA-F]{6}$/.test(hex) ? hex : "";
}
/**
* "wild-race.grok.me" → "Wild Race". Only published app hosts encode the
* display name in the first label. Preview / guest hosts are image origins
* only — slugifying them produced internal names like "Hds Abc 3000 Xy".
*/
function appNameFromHost(hostHeader) {
	const host = String(hostHeader ?? "").split(",")[0].trim().split(":")[0].toLowerCase();
	if (!host.endsWith(".grok.me")) return DEFAULT_APP_NAME;
	const slug = host.split(".")[0] ?? "";
	if (!slug || slug === "www" || !/^[a-z0-9-]{1,63}$/.test(slug)) return DEFAULT_APP_NAME;
	return slug.split("-").filter(Boolean).map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ") || "Grok App";
}
/** True for Vercel system domains. Envoy rewrites origin Host to these; they SSO-protect `/og.jpg`. */
function isVercelSystemHost(host) {
	return host === "vercel.app" || host.endsWith(".vercel.app") || host === "vercel.com" || host.endsWith(".vercel.com");
}
/** Hostname suitable for absolute og:image URLs. Preview guests (X-Forwarded-Host) are allowed. */
function publicAppHost(hostHeader) {
	const host = String(hostHeader ?? "").split(",")[0].trim().split(":")[0].toLowerCase();
	if (!host || !/^[a-z0-9.-]+$/.test(host) || !host.includes(".")) return "";
	if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return "";
	if (isVercelSystemHost(host)) return "";
	return host;
}
/**
* Published apps always use `VITE_PUBLIC_HOSTNAME` (the grok.me host the
* deployer injects). Live preview has no such env, so fall back to the
* request host / X-Forwarded-Host. Never prefer request Host on a published
* app — Envoy rewrites it to `*.vercel.app`.
*/
function resolvePublicHost(hostHeader) {
	return publicAppHost(process.env?.VITE_PUBLIC_HOSTNAME) || publicAppHost(hostHeader);
}
function isInstallQuery(url) {
	const query = String(url ?? "").split("?", 2)[1] ?? "";
	const params = new URLSearchParams(query);
	const install = params.get("install");
	const platform = (params.get("platform") ?? "").toLowerCase();
	return (install === "1" || install === "true") && platform === "ios";
}
/** Paths that can carry an app document (vs assets / API / internals). */
function isDocumentPath(pathname) {
	const path = String(pathname ?? "");
	return !path.startsWith("/__grok/") && !path.startsWith("/api/") && !path.startsWith("/@") && !path.startsWith("/node_modules") && !/\.[a-z0-9]+$/i.test(path);
}
function acceptsHtml(accept) {
	const value = String(accept ?? "");
	return value === "" || value.includes("text/html") || value.includes("*/*");
}
/** The same URL without the install-tutorial params (used as the app link). */
function stripInstallParams(url) {
	const [path = "/", query = ""] = String(url ?? "/").split("?", 2);
	const params = new URLSearchParams(query);
	params.delete("install");
	params.delete("platform");
	const rest = params.toString();
	return rest ? `${path}?${rest}` : path;
}
function renderInstallPageHtml(template, { host, url } = {}) {
	return String(template).replaceAll("{{APP_NAME}}", escapeHtml(appNameFromHost(host))).replaceAll("{{APP_URL}}", escapeHtml(stripInstallParams(url)));
}
function renderWebManifest(hostHeader) {
	const name = appNameFromHost(hostHeader);
	return JSON.stringify({
		name,
		short_name: name,
		id: "/",
		start_url: "/",
		scope: "/",
		display: "standalone",
		background_color: "#000000",
		theme_color: "#000000",
		icons: [{
			src: "/__grok/icon-180.png",
			sizes: "180x180",
			type: "image/png"
		}]
	}, null, 2);
}
function grokPwaHeadTags(appName = DEFAULT_APP_NAME) {
	return [
		["manifest", "<link rel=\"manifest\" href=\"/__grok/manifest.webmanifest\">"],
		["apple-touch-icon", "<link rel=\"apple-touch-icon\" href=\"/__grok/icon-180.png\">"],
		["apple-mobile-web-app-title", `<meta name="apple-mobile-web-app-title" content="${escapeHtml(appName)}">`],
		["apple-mobile-web-app-status-bar-style", "<meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">"],
		["theme-color", "<meta name=\"theme-color\" content=\"#000000\">"]
	];
}
var GROK_EXTENSIONS_SCRIPT_SRC = "https://grok.com/grok-app-builder/extensions.js";
function readGrokProjectId() {
	const fromProcess = typeof process !== "undefined" ? process.env?.VITE_PROJECT_ID : "";
	return String(fromProcess ?? "").trim();
}
function readGrokExtensionsEnabled() {
	const fromProcess = typeof process !== "undefined" ? process.env?.VITE_GROK_EXTENSIONS : "";
	return String(fromProcess ?? "").trim() !== "0";
}
function readXCreator() {
	const fromProcess = typeof process !== "undefined" ? process.env?.X_CREATOR : "";
	return String(fromProcess ?? "").trim();
}
function readXCreatorId() {
	const fromProcess = typeof process !== "undefined" ? process.env?.X_CREATOR_ID : "";
	return String(fromProcess ?? "").trim();
}
function grokXCreatorHeadTags(creator = readXCreator(), creatorId = readXCreatorId()) {
	const name = String(creator ?? "").trim();
	const id = String(creatorId ?? "").trim();
	if (!name || !id) return [];
	return [`<meta property="x:creator" content="${escapeHtml(name)}">`, `<meta property="x:creator:id" content="${escapeHtml(id)}">`];
}
/** Platform "Created with Grok" banner — injected into every HTML document. */
function grokExtensionsHeadTags(projectId = readGrokProjectId()) {
	const id = escapeHtml(projectId);
	const tags = [];
	if (projectId) tags.push(`<meta name="grok-project-id" content="${id}">`);
	if (!readGrokExtensionsEnabled()) return tags;
	tags.push(`<script src="${GROK_EXTENSIONS_SCRIPT_SRC}"${projectId ? ` data-project-id="${id}"` : ""} defer><\/script>`);
	return tags;
}
function readOgSite(cwd = process.cwd()) {
	try {
		const raw = readFileSync(join(cwd, OG_SITE_REL_PATH), "utf8");
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
	} catch {
		return {};
	}
}
/** Public path of an on-disk share card, or "" if neither file exists. */
function ogCardPublicPath(cwd = process.cwd()) {
	if (existsSync(join(cwd, "public/og.jpg"))) return "/og.jpg";
	if (existsSync(join(cwd, "public/og.png"))) return "/og.png";
	return "";
}
function detectCustomOgCard(cwd = process.cwd(), site = {}) {
	if (ogCardPublicPath(cwd)) return true;
	return siteHasCustomCard(site) || Boolean(String(site.image ?? "").trim());
}
/** Snapshot for Vite/Nitro to bake into the server bundle (Vercel has no workspace FS). */
function snapshotOgIdentity(cwd = process.cwd()) {
	const site = { ...readOgSite(cwd) };
	const disk = ogCardPublicPath(cwd);
	if (disk) {
		site.card = "custom";
		site.image = disk;
	} else {
		if (siteHasCustomCard(site)) delete site.card;
		if (site.image) delete site.image;
	}
	if (existsSync(join(cwd, "public/x-banner.jpg"))) site.banner = site.banner || "/x-banner.jpg";
	return { site };
}
function ogServiceUrl() {
	return (String(process.env?.VITE_OG_SERVICE_URL ?? "").trim() || "https://og.grok.me").replace(/\/+$/, "");
}
function titleFromDocument(html) {
	const match = String(html ?? "").match(/<title\b[^>]*>([^<]*)<\/title>/i);
	return match ? unescapeHtml(match[1]).trim() : "";
}
function resolveOgTitle(site = {}, appName = DEFAULT_APP_NAME, host = "", documentTitle = "") {
	const fromSite = String(site.title ?? "").trim();
	if (fromSite) return fromSite;
	const fromDoc = String(documentTitle ?? "").trim();
	if (fromDoc) return fromDoc;
	const fromHost = appNameFromHost(host);
	if (fromHost && fromHost !== "Grok App") return fromHost;
	return String(appName ?? "").trim() || "Grok App";
}
function siteHasCustomCard(site = {}) {
	return String(site.card ?? "").toLowerCase() === "custom";
}
/**
* Preview: public/og.jpg|png on disk.
* Vercel: the bake (`card=custom` / `image`) because the function cannot stat public/.
* Otherwise empty — caller emits the og.grok.me placeholder.
*/
function resolveOgCardAsset(site = {}, cwd = process.cwd()) {
	return ogCardPublicPath(cwd) || (detectCustomOgCard(cwd, site) ? String(site.image ?? "").trim() || "/og.jpg" : "");
}
/** Stamp `card=custom` when public/og.jpg or public/og.png is on disk. */
function applyCustomCardFromFs(site, cwd) {
	const disk = ogCardPublicPath(cwd);
	if (!disk) return site;
	return {
		...site,
		card: "custom",
		image: disk
	};
}
function grokOgHeadTags({ host = "", appName = DEFAULT_APP_NAME, site = {}, documentTitle = "", cwd = process.cwd() } = {}) {
	const title = resolveOgTitle(site, appName, host, documentTitle);
	const publicHost = resolvePublicHost(host);
	const tags = [`<meta name="twitter:card" content="summary_large_image">`, `<meta property="og:title" content="${escapeHtml(title)}">`];
	const description = String(site.description ?? "").trim();
	if (description) tags.push(`<meta property="og:description" content="${escapeHtml(description)}">`);
	if (String(site.type ?? "").toLowerCase() === "x:game") tags.push(`<meta property="og:type" content="x:game">`);
	if (publicHost) {
		const asset = resolveOgCardAsset(site, cwd);
		const custom = Boolean(asset);
		let image = custom ? `https://${publicHost}${asset.startsWith("/") ? asset : `/${asset}`}` : `${ogServiceUrl()}/v1/card.png?host=${encodeURIComponent(publicHost)}&title=${encodeURIComponent(title)}`;
		const color = !custom ? placeholderCardColor(site) : "";
		if (color) image += `&color=${encodeURIComponent(color)}`;
		tags.push(`<meta property="og:image" content="${escapeHtml(image)}">`);
		tags.push(`<meta property="og:image:width" content="1200">`);
		tags.push(`<meta property="og:image:height" content="630">`);
		const banner = String(site.banner ?? "").trim();
		if (banner) {
			const bannerUrl = `https://${publicHost}${banner.startsWith("/") ? banner : `/${banner}`}`;
			tags.push(`<meta property="x:game:image" content="${escapeHtml(bannerUrl)}">`);
			tags.push(`<meta property="x:game:image:width" content="1200">`);
			tags.push(`<meta property="x:game:image:height" content="264">`);
		}
	}
	return tags;
}
function stripGrokExtensionsScript(html) {
	return String(html).replace(/<script\b[^>]*\bsrc\s*=\s*["'][^"']*\/grok-app-builder\/extensions\.js[^"']*["'][^>]*>\s*<\/script>/gi, "");
}
function stripShareMetaTags(html) {
	return String(html).replace(/<meta\b[^>]*>/gi, (tag) => {
		const attrs = [...tag.matchAll(/\b(?:property|name)\s*=\s*["']([^"']+)["']/gi)];
		for (const match of attrs) if (SHARE_META_KEYS.has(String(match[1]).toLowerCase())) return "";
		return tag;
	});
}
function insertAfterHeadOpen(html, snippet) {
	if (/<head\b[^>]*>/i.test(html)) return html.replace(/<head\b[^>]*>/i, (open) => `${open}${snippet}`);
	if (/<html\b[^>]*>/i.test(html)) return html.replace(/<html\b[^>]*>/i, (open) => `${open}<head>${snippet}</head>`);
	return `<!doctype html><html><head>${snippet}</head>${html}`;
}
function insertBeforeHeadClose(html, snippet) {
	if (/<\/head>/i.test(html)) return html.replace(/<\/head>/i, `${snippet}</head>`);
	return insertAfterHeadOpen(html, snippet);
}
function normalizeHeadContext(ctx = {}) {
	const cwd = ctx.cwd ?? process.cwd();
	const site = applyCustomCardFromFs(ctx.site !== void 0 ? ctx.site : snapshotOgIdentity(cwd).site, cwd);
	return {
		appName: resolveOgTitle(site, ctx.appName ?? "Grok App", ctx.host ?? ""),
		projectId: ctx.projectId ?? readGrokProjectId(),
		creator: ctx.creator ?? readXCreator(),
		creatorId: ctx.creatorId ?? readXCreatorId(),
		host: ctx.host ?? "",
		cwd,
		site
	};
}
function injectGrokPwaHead(html, ctx = {}) {
	if (typeof html !== "string") return html;
	const { site, projectId, creator, creatorId, host, cwd } = normalizeHeadContext(ctx);
	const documentTitle = titleFromDocument(html);
	const appName = resolveOgTitle(site, ctx.appName ?? "Grok App", host, documentTitle);
	let next = stripShareMetaTags(html);
	if (!readGrokExtensionsEnabled()) next = stripGrokExtensionsScript(next);
	const missing = grokPwaHeadTags(appName).filter(([key]) => {
		if (key === "manifest") return !next.includes("href=\"/__grok/manifest.webmanifest\"");
		if (key === "apple-touch-icon") return !next.includes("href=\"/__grok/icon-180.png\"");
		return !next.includes(`name="${key}"`);
	}).map(([, tag]) => tag);
	next = insertAfterHeadOpen(next, grokOgHeadTags({
		host,
		appName,
		site,
		documentTitle,
		cwd
	}).join(""));
	if (readGrokExtensionsEnabled() && !next.includes("/grok-app-builder/extensions.js")) missing.push(...grokExtensionsHeadTags(projectId));
	else if (projectId && !next.includes("name=\"grok-project-id\"")) missing.push(`<meta name="grok-project-id" content="${escapeHtml(projectId)}">`);
	if (projectId && !next.includes("property=\"grok:app_id\"") && !next.includes("property='grok:app_id'")) missing.push(`<meta property="grok:app_id" content="${escapeHtml(projectId)}">`);
	const creatorTags = grokXCreatorHeadTags(creator, creatorId);
	if (creatorTags.length > 0) {
		if (!(next.includes("property=\"x:creator\" content=") || next.includes("property='x:creator' content="))) missing.push(creatorTags[0]);
		if (!next.includes("property=\"x:creator:id\"")) missing.push(creatorTags[1]);
	}
	if (missing.length === 0) return next;
	return insertBeforeHeadClose(next, missing.join(""));
}
function findHeadClose(buf) {
	return buf.toString("latin1").search(/<\/head>/i);
}
/**
* Streaming head injector: buffers only until `</head>` (ASCII marker; never
* appears inside a UTF-8 continuation byte), overwrites share-card metas,
* then passes later chunks through so streaming SSR keeps streaming.
*/
function createHeadInjector(ctx = {}) {
	const normalized = normalizeHeadContext(ctx);
	/** @type {Buffer[]} */
	let pending = [];
	let done = false;
	const apply = (html) => injectGrokPwaHead(html, {
		appName: normalized.appName,
		projectId: normalized.projectId,
		creator: normalized.creator,
		creatorId: normalized.creatorId,
		host: normalized.host,
		cwd: normalized.cwd,
		site: normalized.site
	});
	return {
		/** @param {Uint8Array | string} chunk @returns {Buffer[]} chunks ready to emit */
		push(chunk) {
			const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
			if (done) return [buf];
			pending.push(buf);
			const joined = Buffer.concat(pending);
			const at = findHeadClose(joined);
			if (at === -1) return [];
			done = true;
			pending = [];
			const closeLen = joined.toString("latin1", at).match(/^<\/head>/i)[0].length;
			const head = apply(joined.subarray(0, at + closeLen).toString("utf8"));
			return [Buffer.concat([Buffer.from(head, "utf8"), joined.subarray(at + closeLen)])];
		},
		/** @returns {Buffer[]} whatever is still buffered (no `</head>` seen) */
		flush() {
			if (done || pending.length === 0) return [];
			const rest = Buffer.concat(pending);
			pending = [];
			done = true;
			return [Buffer.from(apply(rest.toString("utf8")), "utf8")];
		}
	};
}
// server/middleware/grok-pwa.ts
/**
* Deployed-app (Nitro) half of the platform PWA chrome. Auto-registered as
* global h3 middleware because vite.config.ts sets `serverDir: "./server"` —
* without that option Nitro v3 never scans this directory.
*
* - `?install=1&platform=ios` on a document path → the Home Screen tutorial,
*   bundled into the server build via `?raw` (the public/ directory is CDN
*   static output on Vercel and not readable from the function).
* - `/__grok/manifest.webmanifest` → per-app-named manifest (kept out of
*   public/ so this dynamic response is the only one).
* - Other HTML documents → stream-inject PWA + OG head tags at `</head>`.
*   OG identity is baked via `virtual:grok-og-identity` at `vite build`
*   (this function cannot read `src/lib/og/site.json` or `public/og.jpg`).
*   This must be a middleware transforming `next()`: h3 discards the `response`
*   runtime hook's return value, and `render:html` does not exist in Nitro v3.
*/
function requestHost(event) {
	return event.req.headers.get("x-forwarded-host") ?? event.req.headers.get("host") ?? event.url.host;
}
function injectHeadStreaming(response, host) {
	const injector = createHeadInjector({
		host,
		site: grokOgIdentity.site
	});
	const transformed = response.body.pipeThrough(new TransformStream({
		transform(chunk, controller) {
			for (const out of injector.push(chunk)) controller.enqueue(out);
		},
		flush(controller) {
			for (const out of injector.flush()) controller.enqueue(out);
		}
	}));
	const headers = new Headers(response.headers);
	headers.delete("content-length");
	return new Response(transformed, {
		status: response.status,
		statusText: response.statusText,
		headers
	});
}
async function grokPwaMiddleware(event, next) {
	if ((event.req.method ?? "GET").toUpperCase() !== "GET") return next();
	const path = event.url.pathname;
	const urlWithQuery = path + event.url.search;
	if (path === "/__grok/manifest.webmanifest" || path === "/__grok/manifest.json") return new Response(renderWebManifest(requestHost(event)), { headers: {
		"content-type": "application/manifest+json; charset=utf-8",
		"cache-control": "no-cache"
	} });
	if (isInstallQuery(urlWithQuery) && isDocumentPath(path) && acceptsHtml(event.req.headers.get("accept"))) {
		const html = renderInstallPageHtml(install_page_default, {
			host: requestHost(event),
			url: urlWithQuery
		});
		return new Response(html, { headers: {
			"content-type": "text/html; charset=utf-8",
			"cache-control": "no-cache"
		} });
	}
	if (!isDocumentPath(path)) return next();
	const result = await next();
	if (result instanceof Response && result.body && String(result.headers.get("content-type") ?? "").includes("text/html") && !result.headers.get("content-encoding")) return injectHeadStreaming(result, requestHost(event));
	return result;
}
// #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "cache",
		route: "/api/telegram/evidence",
		handler: cache,
		options: false
	}], $1 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		if (p === "/api/telegram/evidence") r.unshift({ data: $0 });
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $1,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_lQgpUL = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_lQgpUL
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default), toEventHandler(grokPwaMiddleware)].filter(Boolean);
// node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
// #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
// node_modules/nitro/dist/runtime/internal/plugin.mjs
function defineNitroPlugin(def) {
	return def;
}
// server/plugins/http-guards.ts
function installHttpGuards() {
	const proto = nodeHTTP.Server.prototype;
	if (proto.emit !== EventEmitter.prototype.emit) return false;
	const FLOOD_WINDOW = 1e4;
	const FLOOD_MAX = Number(process.env.EPB_FLOOD_MAX || 500);
	const FLOOD_BLOCK = 6e4;
	const floodHits = /* @__PURE__ */ new Map();
	function clientIp(req) {
		const cf = String(req.headers["cf-connecting-ip"] || "").trim();
		if (cf) return cf;
		const real = String(req.headers["x-real-ip"] || "").trim();
		if (real) return real;
		const xff = String(req.headers["x-forwarded-for"] || "").split(",").map((s) => s.trim()).filter(Boolean);
		if (xff.length) return xff[xff.length - 1];
		const direct = String(req.socket?.remoteAddress || "").replace(/^::ffff:/, "");
		if (/^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1$|f[cd][0-9a-f]{2}:)/i.test(direct)) return "";
		return direct;
	}
	function floodBlocked(req) {
		if ((req.url || "").startsWith("/api/telegram/webhook")) return false;
		const ip = clientIp(req);
		if (!ip) return false;
		const now = Date.now();
		let h = floodHits.get(ip);
		if (!h || now - h.start > FLOOD_WINDOW) {
			if (h && h.blockedUntil > now) return true;
			h = {
				start: now,
				n: 0,
				blockedUntil: h?.blockedUntil || 0
			};
			floodHits.set(ip, h);
		}
		if (h.blockedUntil > now) return true;
		h.n += 1;
		if (h.n > FLOOD_MAX) {
			h.blockedUntil = now + FLOOD_BLOCK;
			return true;
		}
		if (floodHits.size > 5e4) floodHits.clear();
		return false;
	}
	const SHED_LAG_MS = Number(process.env.EPB_SHED_LAG_MS || 150);
	const SHED_HARD_LAG_MS = Number(process.env.EPB_SHED_HARD_LAG_MS || 600);
	const SHED_INFLIGHT = Number(process.env.EPB_SHED_INFLIGHT || 300);
	const SHED_HARD_INFLIGHT = Number(process.env.EPB_SHED_HARD_INFLIGHT || 800);
	const SHED_BUSY_IP = 40;
	let loopLag = 0;
	let inflight = 0;
	{
		let last = Date.now();
		setInterval(() => {
			const now = Date.now();
			const lag = Math.max(0, now - last - 100);
			last = now;
			loopLag = lag > loopLag ? lag : loopLag * .8 + lag * .2;
		}, 100).unref?.();
	}
	function shouldShed(req) {
		if ((req.url || "").startsWith("/api/telegram/webhook")) return false;
		if (loopLag > SHED_HARD_LAG_MS || inflight > SHED_HARD_INFLIGHT) return true;
		if (!(loopLag > SHED_LAG_MS || inflight > SHED_INFLIGHT)) return false;
		const h = floodHits.get(clientIp(req));
		return Boolean(h && h.n > SHED_BUSY_IP);
	}
	const MAX_BODY_BYTES = 3145728;
	const origListen = proto.listen;
	proto.listen = function(...args) {
		try {
			this.headersTimeout = 15e3;
			this.requestTimeout = 12e4;
			this.keepAliveTimeout = 5e3;
			this.maxHeadersCount = 100;
			if (!this.maxConnections) this.maxConnections = 4e3;
		} catch {}
		return origListen.apply(this, args);
	};
	const stats = {
		total: 0,
		r429: 0,
		r503: 0,
		r413: 0,
		maxLag: 0,
		maxInflight: 0
	};
	setInterval(() => {
		stats.maxLag = Math.max(stats.maxLag, loopLag);
		if (stats.total > 600 || stats.r429 || stats.r503) {
			let top = "";
			let topN = 0;
			for (const [ip, h] of floodHits) if (h.n > topN) [top, topN] = [ip, h.n];
			console.log(`[epb] http last minute: ${stats.total} requests, 429: ${stats.r429}, 503: ${stats.r503}, 413: ${stats.r413}, max lag ${Math.round(stats.maxLag)} ms, max in flight ${stats.maxInflight}, busiest address ${top || "-"} (${topN}/10s)`);
		}
		stats.total = stats.r429 = stats.r503 = stats.r413 = stats.maxLag = stats.maxInflight = 0;
	}, 6e4).unref?.();
	setInterval(() => stats.maxLag = Math.max(stats.maxLag, loopLag), 1e3).unref?.();
	function reject(res, code, text, extra = {}) {
		try {
			res.statusCode = code;
			for (const [k, v] of Object.entries(extra)) res.setHeader(k, v);
			res.setHeader("connection", "close");
			res.end(text);
		} catch {}
		return true;
	}
	const origEmit = proto.emit;
	const guardedEmit = function(event, req, res, ...rest) {
		if (event === "request" && req && typeof req.url === "string") {
			stats.total += 1;
			if (Number(req.headers["content-length"] || 0) > MAX_BODY_BYTES) {
				stats.r413 += 1;
				return reject(res, 413, "too large");
			}
			if (shouldShed(req)) {
				stats.r503 += 1;
				return reject(res, 503, "busy, try again shortly", { "retry-after": "10" });
			}
			inflight += 1;
			if (inflight > stats.maxInflight) stats.maxInflight = inflight;
			let done = false;
			const finish = () => {
				if (!done) {
					done = true;
					inflight -= 1;
				}
			};
			res.once("close", finish);
			res.once("finish", finish);
			if (floodBlocked(req)) {
				stats.r429 += 1;
				try {
					res.statusCode = 429;
					res.setHeader("retry-after", "60");
					res.end("too many requests");
				} catch {}
				return true;
			}
			try {
				decodeURI(req.url.split("?")[0]);
			} catch {
				try {
					res.statusCode = 400;
					res.end("bad request");
				} catch {}
				return true;
			}
		}
		return origEmit.call(this, event, req, res, ...rest);
	};
	guardedEmit.__epbGuard = true;
	proto.emit = guardedEmit;
	return true;
}
var http_guards_default = defineNitroPlugin(() => {
	if (installHttpGuards()) console.log("[epb] HTTP guards on");
});
// server/plugins/ignore-aborts.ts
var NOISE = /AbortError|aborted|ECONNRESET|EPIPE|socket hang up|premature close|Invalid server action param for serverFnId/i;
function isNoise(args) {
	return args.some((item) => {
		if (!item) return false;
		try {
			return NOISE.test(typeof item === "string" ? item : inspect(item, {
				depth: 3,
				breakLength: Infinity
			}));
		} catch {
			return false;
		}
	});
}
if (!console.error.__epbQuiet) {
	const orig = console.error.bind(console);
	const quiet = (...args) => {
		if (isNoise(args)) return;
		orig(...args);
	};
	quiet.__epbQuiet = true;
	console.error = quiet;
}
function isDisconnect(err) {
	const any = err;
	const text = `${any?.code || ""} ${any?.message || ""} ${any?.cause?.code || ""} ${any?.cause?.message || ""}`;
	return /aborted|ECONNRESET|EPIPE|socket hang up|premature close/i.test(text);
}
// #nitro/virtual/plugins
var plugins = [
	http_guards_default,
	defineNitroPlugin((nitroApp) => {
		const app = nitroApp.h3;
		if (app?.config) {
			const prev = app.config.onError;
			app.config.onError = (error) => {
				if (isDisconnect(error)) return new Response("ok");
				return prev?.(error);
			};
		}
		nitroApp.hooks.hook("error", (error) => {
			if (isDisconnect(error)) return;
		});
	}),
	defineNitroPlugin((nitroApp) => {
		const app = nitroApp;
		if (typeof app.fetch !== "function") return;
		const warm = async (attempt) => {
			try {
				await app.fetch(new Request("http://localhost/api/telegram/webhook", { method: "GET" }));
			} catch {
				if (attempt < 5) setTimeout(() => void warm(attempt + 1), 5e3 * (attempt + 1));
			}
		};
		setTimeout(() => void warm(0), 1500);
	})
];
// #nitro/virtual/app
function createNitroApp() {
	const hooks = new HookableCore();
	const captureError = (error, errorCtx) => {
		const promise = hooks.callHook("error", error, errorCtx)?.catch?.((hookError) => {
			console.error("Error while capturing another error", hookError);
		});
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
			if (promise && typeof errorCtx.event.req.waitUntil === "function") errorCtx.event.req.waitUntil(promise);
		}
	};
	const h3App = createH3App({ onError(error, event) {
		captureError(error, { event });
		return error_handler_default(error, event);
	} });
	h3App.config.onRequest = (event) => {
		return hooks.callHook("request", event)?.catch?.((error) => {
			captureError(error, {
				event,
				tags: ["request"]
			});
		});
	};
	h3App.config.onResponse = (res, event) => {
		return hooks.callHook("response", res, event)?.catch?.((error) => {
			captureError(error, {
				event,
				tags: ["response"]
			});
		});
	};
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks,
		captureError
	};
}
function initNitroPlugins(app) {
	for (const plugin of plugins) try {
		plugin(app);
	} catch (error) {
		app.captureError?.(error, { tags: ["plugin"] });
		throw error;
	}
	return app;
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
// node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	initNitroPlugins(instance);
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
// node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
// #nitro/virtual/tracing
var tracingSrvxPlugins = [];
// node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
export { node_server_default as default };
