//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJmV0Zfc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-C-FVMbDG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C-FVMbDG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-jzci5UHN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
