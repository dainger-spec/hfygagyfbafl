//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CmU_f92j.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DhI0zjn2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DhI0zjn2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DhX7WPp0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
