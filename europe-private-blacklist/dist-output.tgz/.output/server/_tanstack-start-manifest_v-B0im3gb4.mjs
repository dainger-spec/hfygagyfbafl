//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B0im3gb4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DkE5TCFl.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DkE5TCFl.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BUvX4cCN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
