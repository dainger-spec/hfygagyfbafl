//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DmSW9wzV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-C95QAv17.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C95QAv17.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CaCoaP0a.js"]
	}
} });
//#endregion
export { tsrStartManifest };
