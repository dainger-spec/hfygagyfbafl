import { a as __toCommonJS, t as __commonJSMin } from "../_runtime.mjs";
import { a as init_legacy, c as init_entities, i as xml_exports, l as require_decode_codepoint, n as require_lib$1, o as legacy_exports, r as init_xml, s as entities_exports } from "./dom-serializer+[...].mjs";
import { t as require_lib$2 } from "./domhandler.mjs";
import { t as require_lib$3 } from "./domutils.mjs";
//#region node_modules/htmlparser2/lib/Tokenizer.js
var require_Tokenizer = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	var decode_codepoint_1 = __importDefault(require_decode_codepoint());
	var entities_json_1 = __importDefault((init_entities(), __toCommonJS(entities_exports).default));
	var legacy_json_1 = __importDefault((init_legacy(), __toCommonJS(legacy_exports).default));
	var xml_json_1 = __importDefault((init_xml(), __toCommonJS(xml_exports).default));
	function whitespace(c) {
		return c === " " || c === "\n" || c === "	" || c === "\f" || c === "\r";
	}
	function isASCIIAlpha(c) {
		return c >= "a" && c <= "z" || c >= "A" && c <= "Z";
	}
	function ifElseState(upper, SUCCESS, FAILURE) {
		var lower = upper.toLowerCase();
		if (upper === lower) return function(t, c) {
			if (c === lower) t._state = SUCCESS;
			else {
				t._state = FAILURE;
				t._index--;
			}
		};
		return function(t, c) {
			if (c === lower || c === upper) t._state = SUCCESS;
			else {
				t._state = FAILURE;
				t._index--;
			}
		};
	}
	function consumeSpecialNameChar(upper, NEXT_STATE) {
		var lower = upper.toLowerCase();
		return function(t, c) {
			if (c === lower || c === upper) t._state = NEXT_STATE;
			else {
				t._state = 3;
				t._index--;
			}
		};
	}
	var stateBeforeCdata1 = ifElseState("C", 24, 16);
	var stateBeforeCdata2 = ifElseState("D", 25, 16);
	var stateBeforeCdata3 = ifElseState("A", 26, 16);
	var stateBeforeCdata4 = ifElseState("T", 27, 16);
	var stateBeforeCdata5 = ifElseState("A", 28, 16);
	var stateBeforeScript1 = consumeSpecialNameChar("R", 35);
	var stateBeforeScript2 = consumeSpecialNameChar("I", 36);
	var stateBeforeScript3 = consumeSpecialNameChar("P", 37);
	var stateBeforeScript4 = consumeSpecialNameChar("T", 38);
	var stateAfterScript1 = ifElseState("R", 40, 1);
	var stateAfterScript2 = ifElseState("I", 41, 1);
	var stateAfterScript3 = ifElseState("P", 42, 1);
	var stateAfterScript4 = ifElseState("T", 43, 1);
	var stateBeforeStyle1 = consumeSpecialNameChar("Y", 45);
	var stateBeforeStyle2 = consumeSpecialNameChar("L", 46);
	var stateBeforeStyle3 = consumeSpecialNameChar("E", 47);
	var stateAfterStyle1 = ifElseState("Y", 49, 1);
	var stateAfterStyle2 = ifElseState("L", 50, 1);
	var stateAfterStyle3 = ifElseState("E", 51, 1);
	var stateBeforeSpecialT = consumeSpecialNameChar("I", 54);
	var stateBeforeTitle1 = consumeSpecialNameChar("T", 55);
	var stateBeforeTitle2 = consumeSpecialNameChar("L", 56);
	var stateBeforeTitle3 = consumeSpecialNameChar("E", 57);
	var stateAfterSpecialTEnd = ifElseState("I", 58, 1);
	var stateAfterTitle1 = ifElseState("T", 59, 1);
	var stateAfterTitle2 = ifElseState("L", 60, 1);
	var stateAfterTitle3 = ifElseState("E", 61, 1);
	var stateBeforeEntity = ifElseState("#", 63, 64);
	var stateBeforeNumericEntity = ifElseState("X", 66, 65);
	exports.default = function() {
		function Tokenizer(options, cbs) {
			var _a;
			/** The current state the tokenizer is in. */
			this._state = 1;
			/** The read buffer. */
			this.buffer = "";
			/** The beginning of the section that is currently being read. */
			this.sectionStart = 0;
			/** The index within the buffer that we are currently looking at. */
			this._index = 0;
			/**
			* Data that has already been processed will be removed from the buffer occasionally.
			* `_bufferOffset` keeps track of how many characters have been removed, to make sure position information is accurate.
			*/
			this.bufferOffset = 0;
			/** Some behavior, eg. when decoding entities, is done while we are in another state. This keeps track of the other state type. */
			this.baseState = 1;
			/** For special parsing behavior inside of script and style tags. */
			this.special = 1;
			/** Indicates whether the tokenizer has been paused. */
			this.running = true;
			/** Indicates whether the tokenizer has finished running / `.end` has been called. */
			this.ended = false;
			this.cbs = cbs;
			this.xmlMode = !!(options === null || options === void 0 ? void 0 : options.xmlMode);
			this.decodeEntities = (_a = options === null || options === void 0 ? void 0 : options.decodeEntities) !== null && _a !== void 0 ? _a : true;
		}
		Tokenizer.prototype.reset = function() {
			this._state = 1;
			this.buffer = "";
			this.sectionStart = 0;
			this._index = 0;
			this.bufferOffset = 0;
			this.baseState = 1;
			this.special = 1;
			this.running = true;
			this.ended = false;
		};
		Tokenizer.prototype.write = function(chunk) {
			if (this.ended) this.cbs.onerror(Error(".write() after done!"));
			this.buffer += chunk;
			this.parse();
		};
		Tokenizer.prototype.end = function(chunk) {
			if (this.ended) this.cbs.onerror(Error(".end() after done!"));
			if (chunk) this.write(chunk);
			this.ended = true;
			if (this.running) this.finish();
		};
		Tokenizer.prototype.pause = function() {
			this.running = false;
		};
		Tokenizer.prototype.resume = function() {
			this.running = true;
			if (this._index < this.buffer.length) this.parse();
			if (this.ended) this.finish();
		};
		/**
		* The current index within all of the written data.
		*/
		Tokenizer.prototype.getAbsoluteIndex = function() {
			return this.bufferOffset + this._index;
		};
		Tokenizer.prototype.stateText = function(c) {
			if (c === "<") {
				if (this._index > this.sectionStart) this.cbs.ontext(this.getSection());
				this._state = 2;
				this.sectionStart = this._index;
			} else if (this.decodeEntities && c === "&" && (this.special === 1 || this.special === 4)) {
				if (this._index > this.sectionStart) this.cbs.ontext(this.getSection());
				this.baseState = 1;
				this._state = 62;
				this.sectionStart = this._index;
			}
		};
		/**
		* HTML only allows ASCII alpha characters (a-z and A-Z) at the beginning of a tag name.
		*
		* XML allows a lot more characters here (@see https://www.w3.org/TR/REC-xml/#NT-NameStartChar).
		* We allow anything that wouldn't end the tag.
		*/
		Tokenizer.prototype.isTagStartChar = function(c) {
			return isASCIIAlpha(c) || this.xmlMode && !whitespace(c) && c !== "/" && c !== ">";
		};
		Tokenizer.prototype.stateBeforeTagName = function(c) {
			if (c === "/") this._state = 5;
			else if (c === "<") {
				this.cbs.ontext(this.getSection());
				this.sectionStart = this._index;
			} else if (c === ">" || this.special !== 1 || whitespace(c)) this._state = 1;
			else if (c === "!") {
				this._state = 15;
				this.sectionStart = this._index + 1;
			} else if (c === "?") {
				this._state = 17;
				this.sectionStart = this._index + 1;
			} else if (!this.isTagStartChar(c)) this._state = 1;
			else {
				this._state = !this.xmlMode && (c === "s" || c === "S") ? 32 : !this.xmlMode && (c === "t" || c === "T") ? 52 : 3;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateInTagName = function(c) {
			if (c === "/" || c === ">" || whitespace(c)) {
				this.emitToken("onopentagname");
				this._state = 8;
				this._index--;
			}
		};
		Tokenizer.prototype.stateBeforeClosingTagName = function(c) {
			if (whitespace(c)) {} else if (c === ">") this._state = 1;
			else if (this.special !== 1) {
				if (this.special !== 4 && (c === "s" || c === "S")) this._state = 33;
				else if (this.special === 4 && (c === "t" || c === "T")) this._state = 53;
				else {
					this._state = 1;
					this._index--;
				}
			} else if (!this.isTagStartChar(c)) {
				this._state = 20;
				this.sectionStart = this._index;
			} else {
				this._state = 6;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateInClosingTagName = function(c) {
			if (c === ">" || whitespace(c)) {
				this.emitToken("onclosetag");
				this._state = 7;
				this._index--;
			}
		};
		Tokenizer.prototype.stateAfterClosingTagName = function(c) {
			if (c === ">") {
				this._state = 1;
				this.sectionStart = this._index + 1;
			}
		};
		Tokenizer.prototype.stateBeforeAttributeName = function(c) {
			if (c === ">") {
				this.cbs.onopentagend();
				this._state = 1;
				this.sectionStart = this._index + 1;
			} else if (c === "/") this._state = 4;
			else if (!whitespace(c)) {
				this._state = 9;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateInSelfClosingTag = function(c) {
			if (c === ">") {
				this.cbs.onselfclosingtag();
				this._state = 1;
				this.sectionStart = this._index + 1;
				this.special = 1;
			} else if (!whitespace(c)) {
				this._state = 8;
				this._index--;
			}
		};
		Tokenizer.prototype.stateInAttributeName = function(c) {
			if (c === "=" || c === "/" || c === ">" || whitespace(c)) {
				this.cbs.onattribname(this.getSection());
				this.sectionStart = -1;
				this._state = 10;
				this._index--;
			}
		};
		Tokenizer.prototype.stateAfterAttributeName = function(c) {
			if (c === "=") this._state = 11;
			else if (c === "/" || c === ">") {
				this.cbs.onattribend(void 0);
				this._state = 8;
				this._index--;
			} else if (!whitespace(c)) {
				this.cbs.onattribend(void 0);
				this._state = 9;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateBeforeAttributeValue = function(c) {
			if (c === "\"") {
				this._state = 12;
				this.sectionStart = this._index + 1;
			} else if (c === "'") {
				this._state = 13;
				this.sectionStart = this._index + 1;
			} else if (!whitespace(c)) {
				this._state = 14;
				this.sectionStart = this._index;
				this._index--;
			}
		};
		Tokenizer.prototype.handleInAttributeValue = function(c, quote) {
			if (c === quote) {
				this.emitToken("onattribdata");
				this.cbs.onattribend(quote);
				this._state = 8;
			} else if (this.decodeEntities && c === "&") {
				this.emitToken("onattribdata");
				this.baseState = this._state;
				this._state = 62;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateInAttributeValueDoubleQuotes = function(c) {
			this.handleInAttributeValue(c, "\"");
		};
		Tokenizer.prototype.stateInAttributeValueSingleQuotes = function(c) {
			this.handleInAttributeValue(c, "'");
		};
		Tokenizer.prototype.stateInAttributeValueNoQuotes = function(c) {
			if (whitespace(c) || c === ">") {
				this.emitToken("onattribdata");
				this.cbs.onattribend(null);
				this._state = 8;
				this._index--;
			} else if (this.decodeEntities && c === "&") {
				this.emitToken("onattribdata");
				this.baseState = this._state;
				this._state = 62;
				this.sectionStart = this._index;
			}
		};
		Tokenizer.prototype.stateBeforeDeclaration = function(c) {
			this._state = c === "[" ? 23 : c === "-" ? 18 : 16;
		};
		Tokenizer.prototype.stateInDeclaration = function(c) {
			if (c === ">") {
				this.cbs.ondeclaration(this.getSection());
				this._state = 1;
				this.sectionStart = this._index + 1;
			}
		};
		Tokenizer.prototype.stateInProcessingInstruction = function(c) {
			if (c === ">") {
				this.cbs.onprocessinginstruction(this.getSection());
				this._state = 1;
				this.sectionStart = this._index + 1;
			}
		};
		Tokenizer.prototype.stateBeforeComment = function(c) {
			if (c === "-") {
				this._state = 19;
				this.sectionStart = this._index + 1;
			} else this._state = 16;
		};
		Tokenizer.prototype.stateInComment = function(c) {
			if (c === "-") this._state = 21;
		};
		Tokenizer.prototype.stateInSpecialComment = function(c) {
			if (c === ">") {
				this.cbs.oncomment(this.buffer.substring(this.sectionStart, this._index));
				this._state = 1;
				this.sectionStart = this._index + 1;
			}
		};
		Tokenizer.prototype.stateAfterComment1 = function(c) {
			if (c === "-") this._state = 22;
			else this._state = 19;
		};
		Tokenizer.prototype.stateAfterComment2 = function(c) {
			if (c === ">") {
				this.cbs.oncomment(this.buffer.substring(this.sectionStart, this._index - 2));
				this._state = 1;
				this.sectionStart = this._index + 1;
			} else if (c !== "-") this._state = 19;
		};
		Tokenizer.prototype.stateBeforeCdata6 = function(c) {
			if (c === "[") {
				this._state = 29;
				this.sectionStart = this._index + 1;
			} else {
				this._state = 16;
				this._index--;
			}
		};
		Tokenizer.prototype.stateInCdata = function(c) {
			if (c === "]") this._state = 30;
		};
		Tokenizer.prototype.stateAfterCdata1 = function(c) {
			if (c === "]") this._state = 31;
			else this._state = 29;
		};
		Tokenizer.prototype.stateAfterCdata2 = function(c) {
			if (c === ">") {
				this.cbs.oncdata(this.buffer.substring(this.sectionStart, this._index - 2));
				this._state = 1;
				this.sectionStart = this._index + 1;
			} else if (c !== "]") this._state = 29;
		};
		Tokenizer.prototype.stateBeforeSpecialS = function(c) {
			if (c === "c" || c === "C") this._state = 34;
			else if (c === "t" || c === "T") this._state = 44;
			else {
				this._state = 3;
				this._index--;
			}
		};
		Tokenizer.prototype.stateBeforeSpecialSEnd = function(c) {
			if (this.special === 2 && (c === "c" || c === "C")) this._state = 39;
			else if (this.special === 3 && (c === "t" || c === "T")) this._state = 48;
			else this._state = 1;
		};
		Tokenizer.prototype.stateBeforeSpecialLast = function(c, special) {
			if (c === "/" || c === ">" || whitespace(c)) this.special = special;
			this._state = 3;
			this._index--;
		};
		Tokenizer.prototype.stateAfterSpecialLast = function(c, sectionStartOffset) {
			if (c === ">" || whitespace(c)) {
				this.special = 1;
				this._state = 6;
				this.sectionStart = this._index - sectionStartOffset;
				this._index--;
			} else this._state = 1;
		};
		Tokenizer.prototype.parseFixedEntity = function(map) {
			if (map === void 0) map = this.xmlMode ? xml_json_1.default : entities_json_1.default;
			if (this.sectionStart + 1 < this._index) {
				var entity = this.buffer.substring(this.sectionStart + 1, this._index);
				if (Object.prototype.hasOwnProperty.call(map, entity)) {
					this.emitPartial(map[entity]);
					this.sectionStart = this._index + 1;
				}
			}
		};
		Tokenizer.prototype.parseLegacyEntity = function() {
			var start = this.sectionStart + 1;
			var limit = Math.min(this._index - start, 6);
			while (limit >= 2) {
				var entity = this.buffer.substr(start, limit);
				if (Object.prototype.hasOwnProperty.call(legacy_json_1.default, entity)) {
					this.emitPartial(legacy_json_1.default[entity]);
					this.sectionStart += limit + 1;
					return;
				}
				limit--;
			}
		};
		Tokenizer.prototype.stateInNamedEntity = function(c) {
			if (c === ";") {
				this.parseFixedEntity();
				if (this.baseState === 1 && this.sectionStart + 1 < this._index && !this.xmlMode) this.parseLegacyEntity();
				this._state = this.baseState;
			} else if ((c < "0" || c > "9") && !isASCIIAlpha(c)) {
				if (this.xmlMode || this.sectionStart + 1 === this._index) {} else if (this.baseState !== 1) {
					if (c !== "=") this.parseFixedEntity(legacy_json_1.default);
				} else this.parseLegacyEntity();
				this._state = this.baseState;
				this._index--;
			}
		};
		Tokenizer.prototype.decodeNumericEntity = function(offset, base, strict) {
			var sectionStart = this.sectionStart + offset;
			if (sectionStart !== this._index) {
				var entity = this.buffer.substring(sectionStart, this._index);
				var parsed = parseInt(entity, base);
				this.emitPartial(decode_codepoint_1.default(parsed));
				this.sectionStart = strict ? this._index + 1 : this._index;
			}
			this._state = this.baseState;
		};
		Tokenizer.prototype.stateInNumericEntity = function(c) {
			if (c === ";") this.decodeNumericEntity(2, 10, true);
			else if (c < "0" || c > "9") {
				if (!this.xmlMode) this.decodeNumericEntity(2, 10, false);
				else this._state = this.baseState;
				this._index--;
			}
		};
		Tokenizer.prototype.stateInHexEntity = function(c) {
			if (c === ";") this.decodeNumericEntity(3, 16, true);
			else if ((c < "a" || c > "f") && (c < "A" || c > "F") && (c < "0" || c > "9")) {
				if (!this.xmlMode) this.decodeNumericEntity(3, 16, false);
				else this._state = this.baseState;
				this._index--;
			}
		};
		Tokenizer.prototype.cleanup = function() {
			if (this.sectionStart < 0) {
				this.buffer = "";
				this.bufferOffset += this._index;
				this._index = 0;
			} else if (this.running) {
				if (this._state === 1) {
					if (this.sectionStart !== this._index) this.cbs.ontext(this.buffer.substr(this.sectionStart));
					this.buffer = "";
					this.bufferOffset += this._index;
					this._index = 0;
				} else if (this.sectionStart === this._index) {
					this.buffer = "";
					this.bufferOffset += this._index;
					this._index = 0;
				} else {
					this.buffer = this.buffer.substr(this.sectionStart);
					this._index -= this.sectionStart;
					this.bufferOffset += this.sectionStart;
				}
				this.sectionStart = 0;
			}
		};
		/**
		* Iterates through the buffer, calling the function corresponding to the current state.
		*
		* States that are more likely to be hit are higher up, as a performance improvement.
		*/
		Tokenizer.prototype.parse = function() {
			while (this._index < this.buffer.length && this.running) {
				var c = this.buffer.charAt(this._index);
				if (this._state === 1) this.stateText(c);
				else if (this._state === 12) this.stateInAttributeValueDoubleQuotes(c);
				else if (this._state === 9) this.stateInAttributeName(c);
				else if (this._state === 19) this.stateInComment(c);
				else if (this._state === 20) this.stateInSpecialComment(c);
				else if (this._state === 8) this.stateBeforeAttributeName(c);
				else if (this._state === 3) this.stateInTagName(c);
				else if (this._state === 6) this.stateInClosingTagName(c);
				else if (this._state === 2) this.stateBeforeTagName(c);
				else if (this._state === 10) this.stateAfterAttributeName(c);
				else if (this._state === 13) this.stateInAttributeValueSingleQuotes(c);
				else if (this._state === 11) this.stateBeforeAttributeValue(c);
				else if (this._state === 5) this.stateBeforeClosingTagName(c);
				else if (this._state === 7) this.stateAfterClosingTagName(c);
				else if (this._state === 32) this.stateBeforeSpecialS(c);
				else if (this._state === 21) this.stateAfterComment1(c);
				else if (this._state === 14) this.stateInAttributeValueNoQuotes(c);
				else if (this._state === 4) this.stateInSelfClosingTag(c);
				else if (this._state === 16) this.stateInDeclaration(c);
				else if (this._state === 15) this.stateBeforeDeclaration(c);
				else if (this._state === 22) this.stateAfterComment2(c);
				else if (this._state === 18) this.stateBeforeComment(c);
				else if (this._state === 33) this.stateBeforeSpecialSEnd(c);
				else if (this._state === 53) stateAfterSpecialTEnd(this, c);
				else if (this._state === 39) stateAfterScript1(this, c);
				else if (this._state === 40) stateAfterScript2(this, c);
				else if (this._state === 41) stateAfterScript3(this, c);
				else if (this._state === 34) stateBeforeScript1(this, c);
				else if (this._state === 35) stateBeforeScript2(this, c);
				else if (this._state === 36) stateBeforeScript3(this, c);
				else if (this._state === 37) stateBeforeScript4(this, c);
				else if (this._state === 38) this.stateBeforeSpecialLast(c, 2);
				else if (this._state === 42) stateAfterScript4(this, c);
				else if (this._state === 43) this.stateAfterSpecialLast(c, 6);
				else if (this._state === 44) stateBeforeStyle1(this, c);
				else if (this._state === 29) this.stateInCdata(c);
				else if (this._state === 45) stateBeforeStyle2(this, c);
				else if (this._state === 46) stateBeforeStyle3(this, c);
				else if (this._state === 47) this.stateBeforeSpecialLast(c, 3);
				else if (this._state === 48) stateAfterStyle1(this, c);
				else if (this._state === 49) stateAfterStyle2(this, c);
				else if (this._state === 50) stateAfterStyle3(this, c);
				else if (this._state === 51) this.stateAfterSpecialLast(c, 5);
				else if (this._state === 52) stateBeforeSpecialT(this, c);
				else if (this._state === 54) stateBeforeTitle1(this, c);
				else if (this._state === 55) stateBeforeTitle2(this, c);
				else if (this._state === 56) stateBeforeTitle3(this, c);
				else if (this._state === 57) this.stateBeforeSpecialLast(c, 4);
				else if (this._state === 58) stateAfterTitle1(this, c);
				else if (this._state === 59) stateAfterTitle2(this, c);
				else if (this._state === 60) stateAfterTitle3(this, c);
				else if (this._state === 61) this.stateAfterSpecialLast(c, 5);
				else if (this._state === 17) this.stateInProcessingInstruction(c);
				else if (this._state === 64) this.stateInNamedEntity(c);
				else if (this._state === 23) stateBeforeCdata1(this, c);
				else if (this._state === 62) stateBeforeEntity(this, c);
				else if (this._state === 24) stateBeforeCdata2(this, c);
				else if (this._state === 25) stateBeforeCdata3(this, c);
				else if (this._state === 30) this.stateAfterCdata1(c);
				else if (this._state === 31) this.stateAfterCdata2(c);
				else if (this._state === 26) stateBeforeCdata4(this, c);
				else if (this._state === 27) stateBeforeCdata5(this, c);
				else if (this._state === 28) this.stateBeforeCdata6(c);
				else if (this._state === 66) this.stateInHexEntity(c);
				else if (this._state === 65) this.stateInNumericEntity(c);
				else if (this._state === 63) stateBeforeNumericEntity(this, c);
				else this.cbs.onerror(Error("unknown _state"), this._state);
				this._index++;
			}
			this.cleanup();
		};
		Tokenizer.prototype.finish = function() {
			if (this.sectionStart < this._index) this.handleTrailingData();
			this.cbs.onend();
		};
		Tokenizer.prototype.handleTrailingData = function() {
			var data = this.buffer.substr(this.sectionStart);
			if (this._state === 29 || this._state === 30 || this._state === 31) this.cbs.oncdata(data);
			else if (this._state === 19 || this._state === 21 || this._state === 22) this.cbs.oncomment(data);
			else if (this._state === 64 && !this.xmlMode) {
				this.parseLegacyEntity();
				if (this.sectionStart < this._index) {
					this._state = this.baseState;
					this.handleTrailingData();
				}
			} else if (this._state === 65 && !this.xmlMode) {
				this.decodeNumericEntity(2, 10, false);
				if (this.sectionStart < this._index) {
					this._state = this.baseState;
					this.handleTrailingData();
				}
			} else if (this._state === 66 && !this.xmlMode) {
				this.decodeNumericEntity(3, 16, false);
				if (this.sectionStart < this._index) {
					this._state = this.baseState;
					this.handleTrailingData();
				}
			} else if (this._state !== 3 && this._state !== 8 && this._state !== 11 && this._state !== 10 && this._state !== 9 && this._state !== 13 && this._state !== 12 && this._state !== 14 && this._state !== 6) this.cbs.ontext(data);
		};
		Tokenizer.prototype.getSection = function() {
			return this.buffer.substring(this.sectionStart, this._index);
		};
		Tokenizer.prototype.emitToken = function(name) {
			this.cbs[name](this.getSection());
			this.sectionStart = -1;
		};
		Tokenizer.prototype.emitPartial = function(value) {
			if (this.baseState !== 1) this.cbs.onattribdata(value);
			else this.cbs.ontext(value);
		};
		return Tokenizer;
	}();
}));
//#endregion
//#region node_modules/htmlparser2/lib/Parser.js
var require_Parser = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Parser = void 0;
	var Tokenizer_1 = __importDefault(require_Tokenizer());
	var formTags = /* @__PURE__ */ new Set([
		"input",
		"option",
		"optgroup",
		"select",
		"button",
		"datalist",
		"textarea"
	]);
	var pTag = /* @__PURE__ */ new Set(["p"]);
	var openImpliesClose = {
		tr: /* @__PURE__ */ new Set([
			"tr",
			"th",
			"td"
		]),
		th: /* @__PURE__ */ new Set(["th"]),
		td: /* @__PURE__ */ new Set([
			"thead",
			"th",
			"td"
		]),
		body: /* @__PURE__ */ new Set([
			"head",
			"link",
			"script"
		]),
		li: /* @__PURE__ */ new Set(["li"]),
		p: pTag,
		h1: pTag,
		h2: pTag,
		h3: pTag,
		h4: pTag,
		h5: pTag,
		h6: pTag,
		select: formTags,
		input: formTags,
		output: formTags,
		button: formTags,
		datalist: formTags,
		textarea: formTags,
		option: /* @__PURE__ */ new Set(["option"]),
		optgroup: /* @__PURE__ */ new Set(["optgroup", "option"]),
		dd: /* @__PURE__ */ new Set(["dt", "dd"]),
		dt: /* @__PURE__ */ new Set(["dt", "dd"]),
		address: pTag,
		article: pTag,
		aside: pTag,
		blockquote: pTag,
		details: pTag,
		div: pTag,
		dl: pTag,
		fieldset: pTag,
		figcaption: pTag,
		figure: pTag,
		footer: pTag,
		form: pTag,
		header: pTag,
		hr: pTag,
		main: pTag,
		nav: pTag,
		ol: pTag,
		pre: pTag,
		section: pTag,
		table: pTag,
		ul: pTag,
		rt: /* @__PURE__ */ new Set(["rt", "rp"]),
		rp: /* @__PURE__ */ new Set(["rt", "rp"]),
		tbody: /* @__PURE__ */ new Set(["thead", "tbody"]),
		tfoot: /* @__PURE__ */ new Set(["thead", "tbody"])
	};
	var voidElements = /* @__PURE__ */ new Set([
		"area",
		"base",
		"basefont",
		"br",
		"col",
		"command",
		"embed",
		"frame",
		"hr",
		"img",
		"input",
		"isindex",
		"keygen",
		"link",
		"meta",
		"param",
		"source",
		"track",
		"wbr"
	]);
	var foreignContextElements = /* @__PURE__ */ new Set(["math", "svg"]);
	var htmlIntegrationElements = /* @__PURE__ */ new Set([
		"mi",
		"mo",
		"mn",
		"ms",
		"mtext",
		"annotation-xml",
		"foreignObject",
		"desc",
		"title"
	]);
	var reNameEnd = /\s|\//;
	exports.Parser = function() {
		function Parser(cbs, options) {
			if (options === void 0) options = {};
			var _a, _b, _c, _d, _e;
			/** The start index of the last event. */
			this.startIndex = 0;
			/** The end index of the last event. */
			this.endIndex = null;
			this.tagname = "";
			this.attribname = "";
			this.attribvalue = "";
			this.attribs = null;
			this.stack = [];
			this.foreignContext = [];
			this.options = options;
			this.cbs = cbs !== null && cbs !== void 0 ? cbs : {};
			this.lowerCaseTagNames = (_a = options.lowerCaseTags) !== null && _a !== void 0 ? _a : !options.xmlMode;
			this.lowerCaseAttributeNames = (_b = options.lowerCaseAttributeNames) !== null && _b !== void 0 ? _b : !options.xmlMode;
			this.tokenizer = new ((_c = options.Tokenizer) !== null && _c !== void 0 ? _c : Tokenizer_1.default)(this.options, this);
			(_e = (_d = this.cbs).onparserinit) === null || _e === void 0 || _e.call(_d, this);
		}
		Parser.prototype.updatePosition = function(initialOffset) {
			if (this.endIndex === null) {
				if (this.tokenizer.sectionStart <= initialOffset) this.startIndex = 0;
				else this.startIndex = this.tokenizer.sectionStart - initialOffset;
			} else this.startIndex = this.endIndex + 1;
			this.endIndex = this.tokenizer.getAbsoluteIndex();
		};
		Parser.prototype.ontext = function(data) {
			var _a, _b;
			this.updatePosition(1);
			this.endIndex--;
			(_b = (_a = this.cbs).ontext) === null || _b === void 0 || _b.call(_a, data);
		};
		Parser.prototype.onopentagname = function(name) {
			var _a, _b;
			if (this.lowerCaseTagNames) name = name.toLowerCase();
			this.tagname = name;
			if (!this.options.xmlMode && Object.prototype.hasOwnProperty.call(openImpliesClose, name)) {
				var el = void 0;
				while (this.stack.length > 0 && openImpliesClose[name].has(el = this.stack[this.stack.length - 1])) this.onclosetag(el);
			}
			if (this.options.xmlMode || !voidElements.has(name)) {
				this.stack.push(name);
				if (foreignContextElements.has(name)) this.foreignContext.push(true);
				else if (htmlIntegrationElements.has(name)) this.foreignContext.push(false);
			}
			(_b = (_a = this.cbs).onopentagname) === null || _b === void 0 || _b.call(_a, name);
			if (this.cbs.onopentag) this.attribs = {};
		};
		Parser.prototype.onopentagend = function() {
			var _a, _b;
			this.updatePosition(1);
			if (this.attribs) {
				(_b = (_a = this.cbs).onopentag) === null || _b === void 0 || _b.call(_a, this.tagname, this.attribs);
				this.attribs = null;
			}
			if (!this.options.xmlMode && this.cbs.onclosetag && voidElements.has(this.tagname)) this.cbs.onclosetag(this.tagname);
			this.tagname = "";
		};
		Parser.prototype.onclosetag = function(name) {
			this.updatePosition(1);
			if (this.lowerCaseTagNames) name = name.toLowerCase();
			if (foreignContextElements.has(name) || htmlIntegrationElements.has(name)) this.foreignContext.pop();
			if (this.stack.length && (this.options.xmlMode || !voidElements.has(name))) {
				var pos = this.stack.lastIndexOf(name);
				if (pos !== -1) {
					if (this.cbs.onclosetag) {
						pos = this.stack.length - pos;
						while (pos--) this.cbs.onclosetag(this.stack.pop());
					} else this.stack.length = pos;
				} else if (name === "p" && !this.options.xmlMode) {
					this.onopentagname(name);
					this.closeCurrentTag();
				}
			} else if (!this.options.xmlMode && (name === "br" || name === "p")) {
				this.onopentagname(name);
				this.closeCurrentTag();
			}
		};
		Parser.prototype.onselfclosingtag = function() {
			if (this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1]) this.closeCurrentTag();
			else this.onopentagend();
		};
		Parser.prototype.closeCurrentTag = function() {
			var _a, _b;
			var name = this.tagname;
			this.onopentagend();
			if (this.stack[this.stack.length - 1] === name) {
				(_b = (_a = this.cbs).onclosetag) === null || _b === void 0 || _b.call(_a, name);
				this.stack.pop();
			}
		};
		Parser.prototype.onattribname = function(name) {
			if (this.lowerCaseAttributeNames) name = name.toLowerCase();
			this.attribname = name;
		};
		Parser.prototype.onattribdata = function(value) {
			this.attribvalue += value;
		};
		Parser.prototype.onattribend = function(quote) {
			var _a, _b;
			(_b = (_a = this.cbs).onattribute) === null || _b === void 0 || _b.call(_a, this.attribname, this.attribvalue, quote);
			if (this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname)) this.attribs[this.attribname] = this.attribvalue;
			this.attribname = "";
			this.attribvalue = "";
		};
		Parser.prototype.getInstructionName = function(value) {
			var idx = value.search(reNameEnd);
			var name = idx < 0 ? value : value.substr(0, idx);
			if (this.lowerCaseTagNames) name = name.toLowerCase();
			return name;
		};
		Parser.prototype.ondeclaration = function(value) {
			if (this.cbs.onprocessinginstruction) {
				var name_1 = this.getInstructionName(value);
				this.cbs.onprocessinginstruction("!" + name_1, "!" + value);
			}
		};
		Parser.prototype.onprocessinginstruction = function(value) {
			if (this.cbs.onprocessinginstruction) {
				var name_2 = this.getInstructionName(value);
				this.cbs.onprocessinginstruction("?" + name_2, "?" + value);
			}
		};
		Parser.prototype.oncomment = function(value) {
			var _a, _b, _c, _d;
			this.updatePosition(4);
			(_b = (_a = this.cbs).oncomment) === null || _b === void 0 || _b.call(_a, value);
			(_d = (_c = this.cbs).oncommentend) === null || _d === void 0 || _d.call(_c);
		};
		Parser.prototype.oncdata = function(value) {
			var _a, _b, _c, _d, _e, _f;
			this.updatePosition(1);
			if (this.options.xmlMode || this.options.recognizeCDATA) {
				(_b = (_a = this.cbs).oncdatastart) === null || _b === void 0 || _b.call(_a);
				(_d = (_c = this.cbs).ontext) === null || _d === void 0 || _d.call(_c, value);
				(_f = (_e = this.cbs).oncdataend) === null || _f === void 0 || _f.call(_e);
			} else this.oncomment("[CDATA[" + value + "]]");
		};
		Parser.prototype.onerror = function(err) {
			var _a, _b;
			(_b = (_a = this.cbs).onerror) === null || _b === void 0 || _b.call(_a, err);
		};
		Parser.prototype.onend = function() {
			var _a, _b;
			if (this.cbs.onclosetag) for (var i = this.stack.length; i > 0; this.cbs.onclosetag(this.stack[--i]));
			(_b = (_a = this.cbs).onend) === null || _b === void 0 || _b.call(_a);
		};
		/**
		* Resets the parser to a blank state, ready to parse a new HTML document
		*/
		Parser.prototype.reset = function() {
			var _a, _b, _c, _d;
			(_b = (_a = this.cbs).onreset) === null || _b === void 0 || _b.call(_a);
			this.tokenizer.reset();
			this.tagname = "";
			this.attribname = "";
			this.attribs = null;
			this.stack = [];
			(_d = (_c = this.cbs).onparserinit) === null || _d === void 0 || _d.call(_c, this);
		};
		/**
		* Resets the parser, then parses a complete document and
		* pushes it to the handler.
		*
		* @param data Document to parse.
		*/
		Parser.prototype.parseComplete = function(data) {
			this.reset();
			this.end(data);
		};
		/**
		* Parses a chunk of data and calls the corresponding callbacks.
		*
		* @param chunk Chunk to parse.
		*/
		Parser.prototype.write = function(chunk) {
			this.tokenizer.write(chunk);
		};
		/**
		* Parses the end of the buffer and clears the stack, calls onend.
		*
		* @param chunk Optional final chunk to parse.
		*/
		Parser.prototype.end = function(chunk) {
			this.tokenizer.end(chunk);
		};
		/**
		* Pauses parsing. The parser won't emit events until `resume` is called.
		*/
		Parser.prototype.pause = function() {
			this.tokenizer.pause();
		};
		/**
		* Resumes parsing after `pause` was called.
		*/
		Parser.prototype.resume = function() {
			this.tokenizer.resume();
		};
		/**
		* Alias of `write`, for backwards compatibility.
		*
		* @param chunk Chunk to parse.
		* @deprecated
		*/
		Parser.prototype.parseChunk = function(chunk) {
			this.write(chunk);
		};
		/**
		* Alias of `end`, for backwards compatibility.
		*
		* @param chunk Optional final chunk to parse.
		* @deprecated
		*/
		Parser.prototype.done = function(chunk) {
			this.end(chunk);
		};
		return Parser;
	}();
}));
//#endregion
//#region node_modules/htmlparser2/lib/FeedHandler.js
var require_FeedHandler = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __extends = exports && exports.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		Object.defineProperty(o, k2, {
			enumerable: true,
			get: function() {
				return m[k];
			}
		});
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.parseFeed = exports.FeedHandler = void 0;
	var domhandler_1 = __importDefault(require_lib$2());
	var DomUtils = __importStar(require_lib$3());
	var Parser_1 = require_Parser();
	var FeedItemMediaMedium;
	(function(FeedItemMediaMedium) {
		FeedItemMediaMedium[FeedItemMediaMedium["image"] = 0] = "image";
		FeedItemMediaMedium[FeedItemMediaMedium["audio"] = 1] = "audio";
		FeedItemMediaMedium[FeedItemMediaMedium["video"] = 2] = "video";
		FeedItemMediaMedium[FeedItemMediaMedium["document"] = 3] = "document";
		FeedItemMediaMedium[FeedItemMediaMedium["executable"] = 4] = "executable";
	})(FeedItemMediaMedium || (FeedItemMediaMedium = {}));
	var FeedItemMediaExpression;
	(function(FeedItemMediaExpression) {
		FeedItemMediaExpression[FeedItemMediaExpression["sample"] = 0] = "sample";
		FeedItemMediaExpression[FeedItemMediaExpression["full"] = 1] = "full";
		FeedItemMediaExpression[FeedItemMediaExpression["nonstop"] = 2] = "nonstop";
	})(FeedItemMediaExpression || (FeedItemMediaExpression = {}));
	var FeedHandler = function(_super) {
		__extends(FeedHandler, _super);
		/**
		*
		* @param callback
		* @param options
		*/
		function FeedHandler(callback, options) {
			var _this = this;
			if (typeof callback === "object") {
				callback = void 0;
				options = callback;
			}
			_this = _super.call(this, callback, options) || this;
			return _this;
		}
		FeedHandler.prototype.onend = function() {
			var _a, _b;
			var feedRoot = getOneElement(isValidFeed, this.dom);
			if (!feedRoot) {
				this.handleCallback(/* @__PURE__ */ new Error("couldn't find root of feed"));
				return;
			}
			var feed = {};
			if (feedRoot.name === "feed") {
				var childs = feedRoot.children;
				feed.type = "atom";
				addConditionally(feed, "id", "id", childs);
				addConditionally(feed, "title", "title", childs);
				var href = getAttribute("href", getOneElement("link", childs));
				if (href) feed.link = href;
				addConditionally(feed, "description", "subtitle", childs);
				var updated = fetch("updated", childs);
				if (updated) feed.updated = new Date(updated);
				addConditionally(feed, "author", "email", childs, true);
				feed.items = getElements("entry", childs).map(function(item) {
					var entry = {};
					var children = item.children;
					addConditionally(entry, "id", "id", children);
					addConditionally(entry, "title", "title", children);
					var href = getAttribute("href", getOneElement("link", children));
					if (href) entry.link = href;
					var description = fetch("summary", children) || fetch("content", children);
					if (description) entry.description = description;
					var pubDate = fetch("updated", children);
					if (pubDate) entry.pubDate = new Date(pubDate);
					entry.media = getMediaElements(children);
					return entry;
				});
			} else {
				var childs = (_b = (_a = getOneElement("channel", feedRoot.children)) === null || _a === void 0 ? void 0 : _a.children) !== null && _b !== void 0 ? _b : [];
				feed.type = feedRoot.name.substr(0, 3);
				feed.id = "";
				addConditionally(feed, "title", "title", childs);
				addConditionally(feed, "link", "link", childs);
				addConditionally(feed, "description", "description", childs);
				var updated = fetch("lastBuildDate", childs);
				if (updated) feed.updated = new Date(updated);
				addConditionally(feed, "author", "managingEditor", childs, true);
				feed.items = getElements("item", feedRoot.children).map(function(item) {
					var entry = {};
					var children = item.children;
					addConditionally(entry, "id", "guid", children);
					addConditionally(entry, "title", "title", children);
					addConditionally(entry, "link", "link", children);
					addConditionally(entry, "description", "description", children);
					var pubDate = fetch("pubDate", children);
					if (pubDate) entry.pubDate = new Date(pubDate);
					entry.media = getMediaElements(children);
					return entry;
				});
			}
			this.feed = feed;
			this.handleCallback(null);
		};
		return FeedHandler;
	}(domhandler_1.default);
	exports.FeedHandler = FeedHandler;
	function getMediaElements(where) {
		return getElements("media:content", where).map(function(elem) {
			var media = {
				medium: elem.attribs.medium,
				isDefault: !!elem.attribs.isDefault
			};
			if (elem.attribs.url) media.url = elem.attribs.url;
			if (elem.attribs.fileSize) media.fileSize = parseInt(elem.attribs.fileSize, 10);
			if (elem.attribs.type) media.type = elem.attribs.type;
			if (elem.attribs.expression) media.expression = elem.attribs.expression;
			if (elem.attribs.bitrate) media.bitrate = parseInt(elem.attribs.bitrate, 10);
			if (elem.attribs.framerate) media.framerate = parseInt(elem.attribs.framerate, 10);
			if (elem.attribs.samplingrate) media.samplingrate = parseInt(elem.attribs.samplingrate, 10);
			if (elem.attribs.channels) media.channels = parseInt(elem.attribs.channels, 10);
			if (elem.attribs.duration) media.duration = parseInt(elem.attribs.duration, 10);
			if (elem.attribs.height) media.height = parseInt(elem.attribs.height, 10);
			if (elem.attribs.width) media.width = parseInt(elem.attribs.width, 10);
			if (elem.attribs.lang) media.lang = elem.attribs.lang;
			return media;
		});
	}
	function getElements(tagName, where) {
		return DomUtils.getElementsByTagName(tagName, where, true);
	}
	function getOneElement(tagName, node) {
		return DomUtils.getElementsByTagName(tagName, node, true, 1)[0];
	}
	function fetch(tagName, where, recurse) {
		if (recurse === void 0) recurse = false;
		return DomUtils.getText(DomUtils.getElementsByTagName(tagName, where, recurse, 1)).trim();
	}
	function getAttribute(name, elem) {
		if (!elem) return null;
		return elem.attribs[name];
	}
	function addConditionally(obj, prop, what, where, recurse) {
		if (recurse === void 0) recurse = false;
		var tmp = fetch(what, where, recurse);
		if (tmp) obj[prop] = tmp;
	}
	function isValidFeed(value) {
		return value === "rss" || value === "feed" || value === "rdf:RDF";
	}
	/**
	* Parse a feed.
	*
	* @param feed The feed that should be parsed, as a string.
	* @param options Optionally, options for parsing. When using this option, you should set `xmlMode` to `true`.
	*/
	function parseFeed(feed, options) {
		if (options === void 0) options = { xmlMode: true };
		var handler = new FeedHandler(options);
		new Parser_1.Parser(handler, options).end(feed);
		return handler.feed;
	}
	exports.parseFeed = parseFeed;
}));
//#endregion
//#region node_modules/htmlparser2/lib/index.js
var require_lib = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		Object.defineProperty(o, k2, {
			enumerable: true,
			get: function() {
				return m[k];
			}
		});
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	var __exportStar = exports && exports.__exportStar || function(m, exports$1) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$1, p)) __createBinding(exports$1, m, p);
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.RssHandler = exports.DefaultHandler = exports.DomUtils = exports.ElementType = exports.Tokenizer = exports.createDomStream = exports.parseDOM = exports.parseDocument = exports.DomHandler = exports.Parser = void 0;
	var Parser_1 = require_Parser();
	Object.defineProperty(exports, "Parser", {
		enumerable: true,
		get: function() {
			return Parser_1.Parser;
		}
	});
	var domhandler_1 = require_lib$2();
	Object.defineProperty(exports, "DomHandler", {
		enumerable: true,
		get: function() {
			return domhandler_1.DomHandler;
		}
	});
	Object.defineProperty(exports, "DefaultHandler", {
		enumerable: true,
		get: function() {
			return domhandler_1.DomHandler;
		}
	});
	/**
	* Parses the data, returns the resulting document.
	*
	* @param data The data that should be parsed.
	* @param options Optional options for the parser and DOM builder.
	*/
	function parseDocument(data, options) {
		var handler = new domhandler_1.DomHandler(void 0, options);
		new Parser_1.Parser(handler, options).end(data);
		return handler.root;
	}
	exports.parseDocument = parseDocument;
	/**
	* Parses data, returns an array of the root nodes.
	*
	* Note that the root nodes still have a `Document` node as their parent.
	* Use `parseDocument` to get the `Document` node instead.
	*
	* @param data The data that should be parsed.
	* @param options Optional options for the parser and DOM builder.
	* @deprecated Use `parseDocument` instead.
	*/
	function parseDOM(data, options) {
		return parseDocument(data, options).children;
	}
	exports.parseDOM = parseDOM;
	/**
	* Creates a parser instance, with an attached DOM handler.
	*
	* @param cb A callback that will be called once parsing has been completed.
	* @param options Optional options for the parser and DOM builder.
	* @param elementCb An optional callback that will be called every time a tag has been completed inside of the DOM.
	*/
	function createDomStream(cb, options, elementCb) {
		var handler = new domhandler_1.DomHandler(cb, options, elementCb);
		return new Parser_1.Parser(handler, options);
	}
	exports.createDomStream = createDomStream;
	var Tokenizer_1 = require_Tokenizer();
	Object.defineProperty(exports, "Tokenizer", {
		enumerable: true,
		get: function() {
			return __importDefault(Tokenizer_1).default;
		}
	});
	exports.ElementType = __importStar(require_lib$1());
	__exportStar(require_FeedHandler(), exports);
	exports.DomUtils = __importStar(require_lib$3());
	var FeedHandler_1 = require_FeedHandler();
	Object.defineProperty(exports, "RssHandler", {
		enumerable: true,
		get: function() {
			return FeedHandler_1.FeedHandler;
		}
	});
}));
//#endregion
export { require_lib as t };
