import { i as __require, t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/async-mutex/lib/errors.js
var require_errors = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.E_CANCELED = exports.E_ALREADY_LOCKED = exports.E_TIMEOUT = void 0;
	exports.E_TIMEOUT = /* @__PURE__ */ new Error("timeout while waiting for mutex to become available");
	exports.E_ALREADY_LOCKED = /* @__PURE__ */ new Error("mutex already locked");
	exports.E_CANCELED = /* @__PURE__ */ new Error("request for lock canceled");
}));
//#endregion
//#region node_modules/async-mutex/lib/Semaphore.js
var require_Semaphore = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var tslib_1$3 = __require("tslib");
	var errors_1 = require_errors();
	exports.default = function() {
		function Semaphore(_maxConcurrency, _cancelError) {
			if (_cancelError === void 0) _cancelError = errors_1.E_CANCELED;
			this._maxConcurrency = _maxConcurrency;
			this._cancelError = _cancelError;
			this._queue = [];
			this._waiters = [];
			if (_maxConcurrency <= 0) throw new Error("semaphore must be initialized to a positive value");
			this._value = _maxConcurrency;
		}
		Semaphore.prototype.acquire = function() {
			var _this = this;
			var locked = this.isLocked();
			var ticketPromise = new Promise(function(resolve, reject) {
				return _this._queue.push({
					resolve,
					reject
				});
			});
			if (!locked) this._dispatch();
			return ticketPromise;
		};
		Semaphore.prototype.runExclusive = function(callback) {
			return (0, tslib_1$3.__awaiter)(this, void 0, void 0, function() {
				var _a, value, release;
				return (0, tslib_1$3.__generator)(this, function(_b) {
					switch (_b.label) {
						case 0: return [4, this.acquire()];
						case 1:
							_a = _b.sent(), value = _a[0], release = _a[1];
							_b.label = 2;
						case 2:
							_b.trys.push([
								2,
								,
								4,
								5
							]);
							return [4, callback(value)];
						case 3: return [2, _b.sent()];
						case 4:
							release();
							return [7];
						case 5: return [2];
					}
				});
			});
		};
		Semaphore.prototype.waitForUnlock = function() {
			return (0, tslib_1$3.__awaiter)(this, void 0, void 0, function() {
				var waitPromise;
				var _this = this;
				return (0, tslib_1$3.__generator)(this, function(_a) {
					if (!this.isLocked()) return [2, Promise.resolve()];
					waitPromise = new Promise(function(resolve) {
						return _this._waiters.push({ resolve });
					});
					return [2, waitPromise];
				});
			});
		};
		Semaphore.prototype.isLocked = function() {
			return this._value <= 0;
		};
		/** @deprecated Deprecated in 0.3.0, will be removed in 0.4.0. Use runExclusive instead. */
		Semaphore.prototype.release = function() {
			if (this._maxConcurrency > 1) throw new Error("this method is unavailable on semaphores with concurrency > 1; use the scoped release returned by acquire instead");
			if (this._currentReleaser) {
				var releaser = this._currentReleaser;
				this._currentReleaser = void 0;
				releaser();
			}
		};
		Semaphore.prototype.cancel = function() {
			var _this = this;
			this._queue.forEach(function(ticket) {
				return ticket.reject(_this._cancelError);
			});
			this._queue = [];
		};
		Semaphore.prototype._dispatch = function() {
			var _this = this;
			var nextTicket = this._queue.shift();
			if (!nextTicket) return;
			var released = false;
			this._currentReleaser = function() {
				if (released) return;
				released = true;
				_this._value++;
				_this._resolveWaiters();
				_this._dispatch();
			};
			nextTicket.resolve([this._value--, this._currentReleaser]);
		};
		Semaphore.prototype._resolveWaiters = function() {
			this._waiters.forEach(function(waiter) {
				return waiter.resolve();
			});
			this._waiters = [];
		};
		return Semaphore;
	}();
}));
//#endregion
//#region node_modules/async-mutex/lib/Mutex.js
var require_Mutex = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var tslib_1$2 = __require("tslib");
	var Semaphore_1 = require_Semaphore();
	exports.default = function() {
		function Mutex(cancelError) {
			this._semaphore = new Semaphore_1.default(1, cancelError);
		}
		Mutex.prototype.acquire = function() {
			return (0, tslib_1$2.__awaiter)(this, void 0, void 0, function() {
				var _a, releaser;
				return (0, tslib_1$2.__generator)(this, function(_b) {
					switch (_b.label) {
						case 0: return [4, this._semaphore.acquire()];
						case 1:
							_a = _b.sent(), releaser = _a[1];
							return [2, releaser];
					}
				});
			});
		};
		Mutex.prototype.runExclusive = function(callback) {
			return this._semaphore.runExclusive(function() {
				return callback();
			});
		};
		Mutex.prototype.isLocked = function() {
			return this._semaphore.isLocked();
		};
		Mutex.prototype.waitForUnlock = function() {
			return this._semaphore.waitForUnlock();
		};
		/** @deprecated Deprecated in 0.3.0, will be removed in 0.4.0. Use runExclusive instead. */
		Mutex.prototype.release = function() {
			this._semaphore.release();
		};
		Mutex.prototype.cancel = function() {
			return this._semaphore.cancel();
		};
		return Mutex;
	}();
}));
//#endregion
//#region node_modules/async-mutex/lib/withTimeout.js
var require_withTimeout = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.withTimeout = void 0;
	var tslib_1$1 = __require("tslib");
	var errors_1 = require_errors();
	function withTimeout(sync, timeout, timeoutError) {
		var _this = this;
		if (timeoutError === void 0) timeoutError = errors_1.E_TIMEOUT;
		return {
			acquire: function() {
				return new Promise(function(resolve, reject) {
					return (0, tslib_1$1.__awaiter)(_this, void 0, void 0, function() {
						var isTimeout, handle, ticket, release, e_1;
						return (0, tslib_1$1.__generator)(this, function(_a) {
							switch (_a.label) {
								case 0:
									isTimeout = false;
									handle = setTimeout(function() {
										isTimeout = true;
										reject(timeoutError);
									}, timeout);
									_a.label = 1;
								case 1:
									_a.trys.push([
										1,
										3,
										,
										4
									]);
									return [4, sync.acquire()];
								case 2:
									ticket = _a.sent();
									if (isTimeout) {
										release = Array.isArray(ticket) ? ticket[1] : ticket;
										release();
									} else {
										clearTimeout(handle);
										resolve(ticket);
									}
									return [3, 4];
								case 3:
									e_1 = _a.sent();
									if (!isTimeout) {
										clearTimeout(handle);
										reject(e_1);
									}
									return [3, 4];
								case 4: return [2];
							}
						});
					});
				});
			},
			runExclusive: function(callback) {
				return (0, tslib_1$1.__awaiter)(this, void 0, void 0, function() {
					var release, ticket;
					return (0, tslib_1$1.__generator)(this, function(_a) {
						switch (_a.label) {
							case 0:
								release = function() {};
								_a.label = 1;
							case 1:
								_a.trys.push([
									1,
									,
									7,
									8
								]);
								return [4, this.acquire()];
							case 2:
								ticket = _a.sent();
								if (!Array.isArray(ticket)) return [3, 4];
								release = ticket[1];
								return [4, callback(ticket[0])];
							case 3: return [2, _a.sent()];
							case 4:
								release = ticket;
								return [4, callback()];
							case 5: return [2, _a.sent()];
							case 6: return [3, 8];
							case 7:
								release();
								return [7];
							case 8: return [2];
						}
					});
				});
			},
			/** @deprecated Deprecated in 0.3.0, will be removed in 0.4.0. Use runExclusive instead. */
			release: function() {
				sync.release();
			},
			cancel: function() {
				return sync.cancel();
			},
			waitForUnlock: function() {
				return sync.waitForUnlock();
			},
			isLocked: function() {
				return sync.isLocked();
			}
		};
	}
	exports.withTimeout = withTimeout;
}));
//#endregion
//#region node_modules/async-mutex/lib/tryAcquire.js
var require_tryAcquire = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.tryAcquire = void 0;
	var errors_1 = require_errors();
	var withTimeout_1 = require_withTimeout();
	function tryAcquire(sync, alreadyAcquiredError) {
		if (alreadyAcquiredError === void 0) alreadyAcquiredError = errors_1.E_ALREADY_LOCKED;
		return (0, withTimeout_1.withTimeout)(sync, 0, alreadyAcquiredError);
	}
	exports.tryAcquire = tryAcquire;
}));
//#endregion
//#region node_modules/async-mutex/lib/index.js
var require_lib = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.tryAcquire = exports.withTimeout = exports.Semaphore = exports.Mutex = void 0;
	var tslib_1 = __require("tslib");
	var Mutex_1 = require_Mutex();
	Object.defineProperty(exports, "Mutex", {
		enumerable: true,
		get: function() {
			return Mutex_1.default;
		}
	});
	var Semaphore_1 = require_Semaphore();
	Object.defineProperty(exports, "Semaphore", {
		enumerable: true,
		get: function() {
			return Semaphore_1.default;
		}
	});
	var withTimeout_1 = require_withTimeout();
	Object.defineProperty(exports, "withTimeout", {
		enumerable: true,
		get: function() {
			return withTimeout_1.withTimeout;
		}
	});
	var tryAcquire_1 = require_tryAcquire();
	Object.defineProperty(exports, "tryAcquire", {
		enumerable: true,
		get: function() {
			return tryAcquire_1.tryAcquire;
		}
	});
	(0, tslib_1.__exportStar)(require_errors(), exports);
}));
//#endregion
export { require_lib as t };
