import { t as __commonJSMin } from "../_runtime.mjs";
import { n as require_lib$1 } from "./dom-serializer+[...].mjs";
//#region node_modules/domhandler/lib/node.js
var require_node = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __extends = exports && exports.__extends || (function() {
		var extendStatics = function(d, b) {
			extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	})();
	var __assign = exports && exports.__assign || function() {
		__assign = Object.assign || function(t) {
			for (var s, i = 1, n = arguments.length; i < n; i++) {
				s = arguments[i];
				for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
			}
			return t;
		};
		return __assign.apply(this, arguments);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.cloneNode = exports.hasChildren = exports.isDocument = exports.isDirective = exports.isComment = exports.isText = exports.isCDATA = exports.isTag = exports.Element = exports.Document = exports.NodeWithChildren = exports.ProcessingInstruction = exports.Comment = exports.Text = exports.DataNode = exports.Node = void 0;
	var domelementtype_1 = require_lib$1();
	var nodeTypes = /* @__PURE__ */ new Map([
		[domelementtype_1.ElementType.Tag, 1],
		[domelementtype_1.ElementType.Script, 1],
		[domelementtype_1.ElementType.Style, 1],
		[domelementtype_1.ElementType.Directive, 1],
		[domelementtype_1.ElementType.Text, 3],
		[domelementtype_1.ElementType.CDATA, 4],
		[domelementtype_1.ElementType.Comment, 8],
		[domelementtype_1.ElementType.Root, 9]
	]);
	/**
	* This object will be used as the prototype for Nodes when creating a
	* DOM-Level-1-compliant structure.
	*/
	var Node = function() {
		/**
		*
		* @param type The type of the node.
		*/
		function Node(type) {
			this.type = type;
			/** Parent of the node */
			this.parent = null;
			/** Previous sibling */
			this.prev = null;
			/** Next sibling */
			this.next = null;
			/** The start index of the node. Requires `withStartIndices` on the handler to be `true. */
			this.startIndex = null;
			/** The end index of the node. Requires `withEndIndices` on the handler to be `true. */
			this.endIndex = null;
		}
		Object.defineProperty(Node.prototype, "nodeType", {
			/**
			* [DOM spec](https://dom.spec.whatwg.org/#dom-node-nodetype)-compatible
			* node {@link type}.
			*/
			get: function() {
				var _a;
				return (_a = nodeTypes.get(this.type)) !== null && _a !== void 0 ? _a : 1;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(Node.prototype, "parentNode", {
			/**
			* Same as {@link parent}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.parent;
			},
			set: function(parent) {
				this.parent = parent;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(Node.prototype, "previousSibling", {
			/**
			* Same as {@link prev}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.prev;
			},
			set: function(prev) {
				this.prev = prev;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(Node.prototype, "nextSibling", {
			/**
			* Same as {@link next}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.next;
			},
			set: function(next) {
				this.next = next;
			},
			enumerable: false,
			configurable: true
		});
		/**
		* Clone this node, and optionally its children.
		*
		* @param recursive Clone child nodes as well.
		* @returns A clone of the node.
		*/
		Node.prototype.cloneNode = function(recursive) {
			if (recursive === void 0) recursive = false;
			return cloneNode(this, recursive);
		};
		return Node;
	}();
	exports.Node = Node;
	/**
	* A node that contains some data.
	*/
	var DataNode = function(_super) {
		__extends(DataNode, _super);
		/**
		* @param type The type of the node
		* @param data The content of the data node
		*/
		function DataNode(type, data) {
			var _this = _super.call(this, type) || this;
			_this.data = data;
			return _this;
		}
		Object.defineProperty(DataNode.prototype, "nodeValue", {
			/**
			* Same as {@link data}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.data;
			},
			set: function(data) {
				this.data = data;
			},
			enumerable: false,
			configurable: true
		});
		return DataNode;
	}(Node);
	exports.DataNode = DataNode;
	/**
	* Text within the document.
	*/
	var Text = function(_super) {
		__extends(Text, _super);
		function Text(data) {
			return _super.call(this, domelementtype_1.ElementType.Text, data) || this;
		}
		return Text;
	}(DataNode);
	exports.Text = Text;
	/**
	* Comments within the document.
	*/
	var Comment = function(_super) {
		__extends(Comment, _super);
		function Comment(data) {
			return _super.call(this, domelementtype_1.ElementType.Comment, data) || this;
		}
		return Comment;
	}(DataNode);
	exports.Comment = Comment;
	/**
	* Processing instructions, including doc types.
	*/
	var ProcessingInstruction = function(_super) {
		__extends(ProcessingInstruction, _super);
		function ProcessingInstruction(name, data) {
			var _this = _super.call(this, domelementtype_1.ElementType.Directive, data) || this;
			_this.name = name;
			return _this;
		}
		return ProcessingInstruction;
	}(DataNode);
	exports.ProcessingInstruction = ProcessingInstruction;
	/**
	* A `Node` that can have children.
	*/
	var NodeWithChildren = function(_super) {
		__extends(NodeWithChildren, _super);
		/**
		* @param type Type of the node.
		* @param children Children of the node. Only certain node types can have children.
		*/
		function NodeWithChildren(type, children) {
			var _this = _super.call(this, type) || this;
			_this.children = children;
			return _this;
		}
		Object.defineProperty(NodeWithChildren.prototype, "firstChild", {
			/** First child of the node. */
			get: function() {
				var _a;
				return (_a = this.children[0]) !== null && _a !== void 0 ? _a : null;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(NodeWithChildren.prototype, "lastChild", {
			/** Last child of the node. */
			get: function() {
				return this.children.length > 0 ? this.children[this.children.length - 1] : null;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(NodeWithChildren.prototype, "childNodes", {
			/**
			* Same as {@link children}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.children;
			},
			set: function(children) {
				this.children = children;
			},
			enumerable: false,
			configurable: true
		});
		return NodeWithChildren;
	}(Node);
	exports.NodeWithChildren = NodeWithChildren;
	/**
	* The root node of the document.
	*/
	var Document = function(_super) {
		__extends(Document, _super);
		function Document(children) {
			return _super.call(this, domelementtype_1.ElementType.Root, children) || this;
		}
		return Document;
	}(NodeWithChildren);
	exports.Document = Document;
	/**
	* An element within the DOM.
	*/
	var Element = function(_super) {
		__extends(Element, _super);
		/**
		* @param name Name of the tag, eg. `div`, `span`.
		* @param attribs Object mapping attribute names to attribute values.
		* @param children Children of the node.
		*/
		function Element(name, attribs, children, type) {
			if (children === void 0) children = [];
			if (type === void 0) type = name === "script" ? domelementtype_1.ElementType.Script : name === "style" ? domelementtype_1.ElementType.Style : domelementtype_1.ElementType.Tag;
			var _this = _super.call(this, type, children) || this;
			_this.name = name;
			_this.attribs = attribs;
			return _this;
		}
		Object.defineProperty(Element.prototype, "tagName", {
			/**
			* Same as {@link name}.
			* [DOM spec](https://dom.spec.whatwg.org)-compatible alias.
			*/
			get: function() {
				return this.name;
			},
			set: function(name) {
				this.name = name;
			},
			enumerable: false,
			configurable: true
		});
		Object.defineProperty(Element.prototype, "attributes", {
			get: function() {
				var _this = this;
				return Object.keys(this.attribs).map(function(name) {
					var _a, _b;
					return {
						name,
						value: _this.attribs[name],
						namespace: (_a = _this["x-attribsNamespace"]) === null || _a === void 0 ? void 0 : _a[name],
						prefix: (_b = _this["x-attribsPrefix"]) === null || _b === void 0 ? void 0 : _b[name]
					};
				});
			},
			enumerable: false,
			configurable: true
		});
		return Element;
	}(NodeWithChildren);
	exports.Element = Element;
	/**
	* @param node Node to check.
	* @returns `true` if the node is a `Element`, `false` otherwise.
	*/
	function isTag(node) {
		return (0, domelementtype_1.isTag)(node);
	}
	exports.isTag = isTag;
	/**
	* @param node Node to check.
	* @returns `true` if the node has the type `CDATA`, `false` otherwise.
	*/
	function isCDATA(node) {
		return node.type === domelementtype_1.ElementType.CDATA;
	}
	exports.isCDATA = isCDATA;
	/**
	* @param node Node to check.
	* @returns `true` if the node has the type `Text`, `false` otherwise.
	*/
	function isText(node) {
		return node.type === domelementtype_1.ElementType.Text;
	}
	exports.isText = isText;
	/**
	* @param node Node to check.
	* @returns `true` if the node has the type `Comment`, `false` otherwise.
	*/
	function isComment(node) {
		return node.type === domelementtype_1.ElementType.Comment;
	}
	exports.isComment = isComment;
	/**
	* @param node Node to check.
	* @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
	*/
	function isDirective(node) {
		return node.type === domelementtype_1.ElementType.Directive;
	}
	exports.isDirective = isDirective;
	/**
	* @param node Node to check.
	* @returns `true` if the node has the type `ProcessingInstruction`, `false` otherwise.
	*/
	function isDocument(node) {
		return node.type === domelementtype_1.ElementType.Root;
	}
	exports.isDocument = isDocument;
	/**
	* @param node Node to check.
	* @returns `true` if the node is a `NodeWithChildren` (has children), `false` otherwise.
	*/
	function hasChildren(node) {
		return Object.prototype.hasOwnProperty.call(node, "children");
	}
	exports.hasChildren = hasChildren;
	/**
	* Clone a node, and optionally its children.
	*
	* @param recursive Clone child nodes as well.
	* @returns A clone of the node.
	*/
	function cloneNode(node, recursive) {
		if (recursive === void 0) recursive = false;
		var result;
		if (isText(node)) result = new Text(node.data);
		else if (isComment(node)) result = new Comment(node.data);
		else if (isTag(node)) {
			var children = recursive ? cloneChildren(node.children) : [];
			var clone_1 = new Element(node.name, __assign({}, node.attribs), children);
			children.forEach(function(child) {
				return child.parent = clone_1;
			});
			if (node.namespace != null) clone_1.namespace = node.namespace;
			if (node["x-attribsNamespace"]) clone_1["x-attribsNamespace"] = __assign({}, node["x-attribsNamespace"]);
			if (node["x-attribsPrefix"]) clone_1["x-attribsPrefix"] = __assign({}, node["x-attribsPrefix"]);
			result = clone_1;
		} else if (isCDATA(node)) {
			var children = recursive ? cloneChildren(node.children) : [];
			var clone_2 = new NodeWithChildren(domelementtype_1.ElementType.CDATA, children);
			children.forEach(function(child) {
				return child.parent = clone_2;
			});
			result = clone_2;
		} else if (isDocument(node)) {
			var children = recursive ? cloneChildren(node.children) : [];
			var clone_3 = new Document(children);
			children.forEach(function(child) {
				return child.parent = clone_3;
			});
			if (node["x-mode"]) clone_3["x-mode"] = node["x-mode"];
			result = clone_3;
		} else if (isDirective(node)) {
			var instruction = new ProcessingInstruction(node.name, node.data);
			if (node["x-name"] != null) {
				instruction["x-name"] = node["x-name"];
				instruction["x-publicId"] = node["x-publicId"];
				instruction["x-systemId"] = node["x-systemId"];
			}
			result = instruction;
		} else throw new Error("Not implemented yet: ".concat(node.type));
		result.startIndex = node.startIndex;
		result.endIndex = node.endIndex;
		if (node.sourceCodeLocation != null) result.sourceCodeLocation = node.sourceCodeLocation;
		return result;
	}
	exports.cloneNode = cloneNode;
	function cloneChildren(childs) {
		var children = childs.map(function(child) {
			return cloneNode(child, true);
		});
		for (var i = 1; i < children.length; i++) {
			children[i].prev = children[i - 1];
			children[i - 1].next = children[i];
		}
		return children;
	}
}));
//#endregion
//#region node_modules/domhandler/lib/index.js
var require_lib = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$1) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$1, p)) __createBinding(exports$1, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DomHandler = void 0;
	var domelementtype_1 = require_lib$1();
	var node_1 = require_node();
	__exportStar(require_node(), exports);
	var reWhitespace = /\s+/g;
	var defaultOpts = {
		normalizeWhitespace: false,
		withStartIndices: false,
		withEndIndices: false,
		xmlMode: false
	};
	var DomHandler = function() {
		/**
		* @param callback Called once parsing has completed.
		* @param options Settings for the handler.
		* @param elementCB Callback whenever a tag is closed.
		*/
		function DomHandler(callback, options, elementCB) {
			/** The elements of the DOM */
			this.dom = [];
			/** The root element for the DOM */
			this.root = new node_1.Document(this.dom);
			/** Indicated whether parsing has been completed. */
			this.done = false;
			/** Stack of open tags. */
			this.tagStack = [this.root];
			/** A data node that is still being written to. */
			this.lastNode = null;
			/** Reference to the parser instance. Used for location information. */
			this.parser = null;
			if (typeof options === "function") {
				elementCB = options;
				options = defaultOpts;
			}
			if (typeof callback === "object") {
				options = callback;
				callback = void 0;
			}
			this.callback = callback !== null && callback !== void 0 ? callback : null;
			this.options = options !== null && options !== void 0 ? options : defaultOpts;
			this.elementCB = elementCB !== null && elementCB !== void 0 ? elementCB : null;
		}
		DomHandler.prototype.onparserinit = function(parser) {
			this.parser = parser;
		};
		DomHandler.prototype.onreset = function() {
			this.dom = [];
			this.root = new node_1.Document(this.dom);
			this.done = false;
			this.tagStack = [this.root];
			this.lastNode = null;
			this.parser = null;
		};
		DomHandler.prototype.onend = function() {
			if (this.done) return;
			this.done = true;
			this.parser = null;
			this.handleCallback(null);
		};
		DomHandler.prototype.onerror = function(error) {
			this.handleCallback(error);
		};
		DomHandler.prototype.onclosetag = function() {
			this.lastNode = null;
			var elem = this.tagStack.pop();
			if (this.options.withEndIndices) elem.endIndex = this.parser.endIndex;
			if (this.elementCB) this.elementCB(elem);
		};
		DomHandler.prototype.onopentag = function(name, attribs) {
			var type = this.options.xmlMode ? domelementtype_1.ElementType.Tag : void 0;
			var element = new node_1.Element(name, attribs, void 0, type);
			this.addNode(element);
			this.tagStack.push(element);
		};
		DomHandler.prototype.ontext = function(data) {
			var normalizeWhitespace = this.options.normalizeWhitespace;
			var lastNode = this.lastNode;
			if (lastNode && lastNode.type === domelementtype_1.ElementType.Text) {
				if (normalizeWhitespace) lastNode.data = (lastNode.data + data).replace(reWhitespace, " ");
				else lastNode.data += data;
				if (this.options.withEndIndices) lastNode.endIndex = this.parser.endIndex;
			} else {
				if (normalizeWhitespace) data = data.replace(reWhitespace, " ");
				var node = new node_1.Text(data);
				this.addNode(node);
				this.lastNode = node;
			}
		};
		DomHandler.prototype.oncomment = function(data) {
			if (this.lastNode && this.lastNode.type === domelementtype_1.ElementType.Comment) {
				this.lastNode.data += data;
				return;
			}
			var node = new node_1.Comment(data);
			this.addNode(node);
			this.lastNode = node;
		};
		DomHandler.prototype.oncommentend = function() {
			this.lastNode = null;
		};
		DomHandler.prototype.oncdatastart = function() {
			var text = new node_1.Text("");
			var node = new node_1.NodeWithChildren(domelementtype_1.ElementType.CDATA, [text]);
			this.addNode(node);
			text.parent = node;
			this.lastNode = text;
		};
		DomHandler.prototype.oncdataend = function() {
			this.lastNode = null;
		};
		DomHandler.prototype.onprocessinginstruction = function(name, data) {
			var node = new node_1.ProcessingInstruction(name, data);
			this.addNode(node);
		};
		DomHandler.prototype.handleCallback = function(error) {
			if (typeof this.callback === "function") this.callback(error, this.dom);
			else if (error) throw error;
		};
		DomHandler.prototype.addNode = function(node) {
			var parent = this.tagStack[this.tagStack.length - 1];
			var previousSibling = parent.children[parent.children.length - 1];
			if (this.options.withStartIndices) node.startIndex = this.parser.startIndex;
			if (this.options.withEndIndices) node.endIndex = this.parser.endIndex;
			parent.children.push(node);
			if (previousSibling) {
				node.prev = previousSibling;
				previousSibling.next = node;
			}
			node.parent = parent;
			this.lastNode = null;
		};
		return DomHandler;
	}();
	exports.DomHandler = DomHandler;
	exports.default = DomHandler;
}));
//#endregion
export { require_lib as t };
