import { a as __toCommonJS, i as __require, n as __esmMin, r as __exportAll, t as __commonJSMin } from "../_runtime.mjs";
import { t as require_BigInteger } from "./big-integer.mjs";
import { t as require_mime } from "./mime.mjs";
import { t as require_lib } from "./htmlparser2.mjs";
import { t as require_pako } from "./pako.mjs";
import { t as require_src } from "./debug+ms.mjs";
import { t as require_is_typedarray } from "./is-typedarray.mjs";
import { t as require_lib$1 } from "./async-mutex.mjs";
import { t as require_build } from "./socks.mjs";
import { n as init_aes, t as aes_exports } from "./cryptography__aes.mjs";
import { t as require_store2 } from "./store2.mjs";
import { t as require_LocalStorage } from "./node-localstorage+[...].mjs";
//#region node_modules/telegram/inspect.js
var require_inspect = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.inspect = void 0;
	var util_1 = __require("util");
	Object.defineProperty(exports, "inspect", {
		enumerable: true,
		get: function() {
			return util_1.inspect;
		}
	});
}));
//#endregion
//#region node_modules/telegram/CryptoFile.js
var require_CryptoFile = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = __importStar(__require("crypto"));
}));
//#endregion
//#region node_modules/telegram/platform.js
var require_platform = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.isNode = exports.isBrowser = exports.isDeno = void 0;
	exports.isDeno = "Deno" in globalThis;
	exports.isBrowser = !exports.isDeno && typeof window !== "undefined";
	exports.isNode = !exports.isBrowser;
}));
//#endregion
//#region node_modules/telegram/Helpers.js
var require_Helpers = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports._EntityType = exports.TotalList = exports.sleep = exports.isArrayLike = void 0;
	exports.readBigIntFromBuffer = readBigIntFromBuffer;
	exports.generateRandomBigInt = generateRandomBigInt;
	exports.escapeRegex = escapeRegex;
	exports.groupBy = groupBy;
	exports.betterConsoleLog = betterConsoleLog;
	exports.toSignedLittleBuffer = toSignedLittleBuffer;
	exports.readBufferFromBigInt = readBufferFromBigInt;
	exports.generateRandomLong = generateRandomLong;
	exports.mod = mod;
	exports.bigIntMod = bigIntMod;
	exports.generateRandomBytes = generateRandomBytes;
	exports.stripText = stripText;
	exports.generateKeyDataFromNonce = generateKeyDataFromNonce;
	exports.convertToLittle = convertToLittle;
	exports.sha1 = sha1;
	exports.sha256 = sha256;
	exports.modExp = modExp;
	exports.getByteArray = getByteArray;
	exports.returnBigInt = returnBigInt;
	exports.getMinBigInt = getMinBigInt;
	exports.getRandomInt = getRandomInt;
	exports.bufferXor = bufferXor;
	exports.crc32 = crc32;
	exports._entityType = _entityType;
	var big_integer_1 = __importDefault(require_BigInteger());
	var CryptoFile_1 = __importDefault(require_CryptoFile());
	var platform_1 = require_platform();
	/**
	* converts a buffer to big int
	* @param buffer
	* @param little
	* @param signed
	* @returns {bigInt.BigInteger}
	*/
	function readBigIntFromBuffer(buffer, little = true, signed = false) {
		let randBuffer = Buffer.from(buffer);
		const bytesNumber = randBuffer.length;
		if (little) randBuffer = randBuffer.reverse();
		let bigIntVar = (0, big_integer_1.default)(randBuffer.toString("hex"), 16);
		if (signed && Math.floor(bigIntVar.toString(2).length / 8) >= bytesNumber) bigIntVar = bigIntVar.subtract((0, big_integer_1.default)(2).pow((0, big_integer_1.default)(bytesNumber * 8)));
		return bigIntVar;
	}
	function generateRandomBigInt() {
		return readBigIntFromBuffer(generateRandomBytes(8), false);
	}
	function escapeRegex(string) {
		return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
	}
	function groupBy(list, keyGetter) {
		const map = /* @__PURE__ */ new Map();
		list.forEach((item) => {
			const key = keyGetter(item);
			const collection = map.get(key);
			if (!collection) map.set(key, [item]);
			else collection.push(item);
		});
		return map;
	}
	/**
	* Outputs the object in a better way by hiding all the private methods/attributes.
	* @param object - the class to use
	*/
	function betterConsoleLog(object) {
		const toPrint = {};
		for (const key in object) if (object.hasOwnProperty(key)) {
			if (!key.startsWith("_") && key != "originalArgs") toPrint[key] = object[key];
		}
		return toPrint;
	}
	/**
	* Helper to find if a given object is an array (or similar)
	*/
	var isArrayLike = (x) => x && typeof x.length === "number" && typeof x !== "function" && typeof x !== "string";
	exports.isArrayLike = isArrayLike;
	/**
	* Special case signed little ints
	* @param big
	* @param number
	* @returns {Buffer}
	*/
	function toSignedLittleBuffer(big, number = 8) {
		const bigNumber = returnBigInt(big);
		const byteArray = [];
		for (let i = 0; i < number; i++) byteArray[i] = bigNumber.shiftRight(8 * i).and(255);
		return Buffer.from(byteArray);
	}
	/**
	* converts a big int to a buffer
	* @param bigIntVar {BigInteger}
	* @param bytesNumber
	* @param little
	* @param signed
	* @returns {Buffer}
	*/
	function readBufferFromBigInt(bigIntVar, bytesNumber, little = true, signed = false) {
		bigIntVar = (0, big_integer_1.default)(bigIntVar);
		const bitLength = bigIntVar.bitLength().toJSNumber();
		if (bytesNumber < Math.ceil(bitLength / 8)) throw new Error("OverflowError: int too big to convert");
		if (!signed && bigIntVar.lesser((0, big_integer_1.default)(0))) throw new Error("Cannot convert to unsigned");
		if (signed && bigIntVar.lesser((0, big_integer_1.default)(0))) bigIntVar = (0, big_integer_1.default)(2).pow((0, big_integer_1.default)(bytesNumber).multiply(8)).add(bigIntVar);
		const hex = bigIntVar.toString(16).padStart(bytesNumber * 2, "0");
		let buffer = Buffer.from(hex, "hex");
		if (little) buffer = buffer.reverse();
		return buffer;
	}
	/**
	* Generates a random long integer (8 bytes), which is optionally signed
	* @returns {BigInteger}
	*/
	function generateRandomLong(signed = true) {
		return readBigIntFromBuffer(generateRandomBytes(8), true, signed);
	}
	/**
	* .... really javascript
	* @param n {number}
	* @param m {number}
	* @returns {number}
	*/
	function mod(n, m) {
		return (n % m + m) % m;
	}
	/**
	* returns a positive bigInt
	* @param n {bigInt.BigInteger}
	* @param m {bigInt.BigInteger}
	* @returns {bigInt.BigInteger}
	*/
	function bigIntMod(n, m) {
		return n.remainder(m).add(m).remainder(m);
	}
	/**
	* Generates a random bytes array
	* @param count
	* @returns {Buffer}
	*/
	function generateRandomBytes(count) {
		return Buffer.from(CryptoFile_1.default.randomBytes(count));
	}
	/**
	* Calculate the key based on Telegram guidelines, specifying whether it's the client or not
	* @param sharedKey
	* @param msgKey
	* @param client
	* @returns {{iv: Buffer, key: Buffer}}
	*/
	function stripText(text, entities) {
		if (!entities || !entities.length) return text.trim();
		while (text && text[text.length - 1].trim() === "") {
			const e = entities[entities.length - 1];
			if (e.offset + e.length == text.length) {
				if (e.length == 1) {
					entities.pop();
					if (!entities.length) return text.trim();
				} else e.length -= 1;
			}
			text = text.slice(0, -1);
		}
		while (text && text[0].trim() === "") {
			for (let i = 0; i < entities.length; i++) {
				const e = entities[i];
				if (e.offset != 0) {
					e.offset--;
					continue;
				}
				if (e.length == 1) {
					entities.shift();
					if (!entities.length) return text.trimLeft();
				} else e.length -= 1;
			}
			text = text.slice(1);
		}
		return text;
	}
	/**
	* Generates the key data corresponding to the given nonces
	* @param serverNonceBigInt
	* @param newNonceBigInt
	* @returns {{key: Buffer, iv: Buffer}}
	*/
	async function generateKeyDataFromNonce(serverNonceBigInt, newNonceBigInt) {
		const serverNonce = toSignedLittleBuffer(serverNonceBigInt, 16);
		const newNonce = toSignedLittleBuffer(newNonceBigInt, 32);
		const [hash1, hash2, hash3] = await Promise.all([
			sha1(Buffer.concat([newNonce, serverNonce])),
			sha1(Buffer.concat([serverNonce, newNonce])),
			sha1(Buffer.concat([newNonce, newNonce]))
		]);
		return {
			key: Buffer.concat([hash1, hash2.slice(0, 12)]),
			iv: Buffer.concat([
				hash2.slice(12, 20),
				hash3,
				newNonce.slice(0, 4)
			])
		};
	}
	function convertToLittle(buf) {
		const correct = Buffer.alloc(buf.length * 4);
		for (let i = 0; i < buf.length; i++) correct.writeUInt32BE(buf[i], i * 4);
		return correct;
	}
	/**
	* Calculates the SHA1 digest for the given data
	* @param data
	* @returns {Promise}
	*/
	function sha1(data) {
		const shaSum = CryptoFile_1.default.createHash("sha1");
		shaSum.update(data);
		return shaSum.digest();
	}
	/**
	* Calculates the SHA256 digest for the given data
	* @param data
	* @returns {Promise}
	*/
	function sha256(data) {
		const shaSum = CryptoFile_1.default.createHash("sha256");
		shaSum.update(data);
		return shaSum.digest();
	}
	/**
	* Fast mod pow for RSA calculation. a^b % n
	* @param a
	* @param b
	* @param n
	* @returns {bigInt.BigInteger}
	*/
	function modExp(a, b, n) {
		a = a.remainder(n);
		let result = big_integer_1.default.one;
		let x = a;
		while (b.greater(big_integer_1.default.zero)) {
			const leastSignificantBit = b.remainder((0, big_integer_1.default)(2));
			b = b.divide((0, big_integer_1.default)(2));
			if (leastSignificantBit.eq(big_integer_1.default.one)) {
				result = result.multiply(x);
				result = result.remainder(n);
			}
			x = x.multiply(x);
			x = x.remainder(n);
		}
		return result;
	}
	/**
	* Gets the arbitrary-length byte array corresponding to the given integer
	* @param integer {number,BigInteger}
	* @param signed {boolean}
	* @returns {Buffer}
	*/
	function getByteArray(integer, signed = false) {
		const bits = integer.toString(2).length;
		const byteLength = Math.floor((bits + 8 - 1) / 8);
		return readBufferFromBigInt(typeof integer == "number" ? (0, big_integer_1.default)(integer) : integer, byteLength, false, signed);
	}
	function returnBigInt(num) {
		if (big_integer_1.default.isInstance(num)) return num;
		if (typeof num == "number") return (0, big_integer_1.default)(num);
		if (typeof num == "bigint") return (0, big_integer_1.default)(num);
		return (0, big_integer_1.default)(num);
	}
	/**
	* Helper function to return the smaller big int in an array
	* @param arrayOfBigInts
	*/
	function getMinBigInt(arrayOfBigInts) {
		if (arrayOfBigInts.length == 0) return big_integer_1.default.zero;
		if (arrayOfBigInts.length == 1) return returnBigInt(arrayOfBigInts[0]);
		let smallest = returnBigInt(arrayOfBigInts[0]);
		for (let i = 1; i < arrayOfBigInts.length; i++) if (returnBigInt(arrayOfBigInts[i]).lesser(smallest)) smallest = returnBigInt(arrayOfBigInts[i]);
		return smallest;
	}
	/**
	* returns a random int from min (inclusive) and max (inclusive)
	* @param min
	* @param max
	* @returns {number}
	*/
	function getRandomInt(min, max) {
		min = Math.ceil(min);
		max = Math.floor(max);
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}
	/**
	* Sleeps a specified amount of time
	* @param ms time in milliseconds
	* @param isUnref make a timer unref'ed
	* @returns {Promise}
	*/
	var sleep = (ms, isUnref = false) => new Promise((resolve) => isUnref && platform_1.isNode ? setTimeout(resolve, ms).unref() : setTimeout(resolve, ms));
	exports.sleep = sleep;
	/**
	* Helper to export two buffers of same length
	* @returns {Buffer}
	*/
	function bufferXor(a, b) {
		const res = [];
		for (let i = 0; i < a.length; i++) res.push(a[i] ^ b[i]);
		return Buffer.from(res);
	}
	function makeCRCTable() {
		let c;
		const crcTable = [];
		for (let n = 0; n < 256; n++) {
			c = n;
			for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
			crcTable[n] = c;
		}
		return crcTable;
	}
	var crcTable = void 0;
	function crc32(buf) {
		if (!crcTable) crcTable = makeCRCTable();
		if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
		let crc = -1;
		for (let index = 0; index < buf.length; index++) {
			const byte = buf[index];
			crc = crcTable[(crc ^ byte) & 255] ^ crc >>> 8;
		}
		return (crc ^ -1) >>> 0;
	}
	var TotalList = class extends Array {
		constructor() {
			super();
			this.total = 0;
		}
	};
	exports.TotalList = TotalList;
	exports._EntityType = {
		USER: 0,
		CHAT: 1,
		CHANNEL: 2
	};
	Object.freeze(exports._EntityType);
	function _entityType(entity) {
		if (typeof entity !== "object" || !("SUBCLASS_OF_ID" in entity)) throw new Error(`${entity} is not a TLObject, cannot determine entity type`);
		if (![
			47470215,
			3374092470,
			3865689926,
			1089602301,
			765557111,
			3316604308,
			524706233,
			3566872215
		].includes(entity.SUBCLASS_OF_ID)) throw new Error(`${entity} does not have any entity type`);
		const name = entity.className;
		if (name.includes("User")) return exports._EntityType.USER;
		else if (name.includes("Chat")) return exports._EntityType.CHAT;
		else if (name.includes("Channel")) return exports._EntityType.CHANNEL;
		else if (name.includes("Self")) return exports._EntityType.USER;
		throw new Error(`${entity} does not have any entity type`);
	}
}));
//#endregion
//#region node_modules/telegram/tl/apiTl.js
var require_apiTl = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = `boolFalse#bc799737 = Bool;
boolTrue#997275b5 = Bool;
true#3fedd339 = True;
vector#1cb5c415 {t:Type} # [ t ] = Vector t;
error#c4b9f9bb code:int text:string = Error;
null#56730bcc = Null;
inputPeerEmpty#7f3b18ea = InputPeer;
inputPeerSelf#7da07ec9 = InputPeer;
inputPeerChat#35a95cb9 chat_id:long = InputPeer;
inputPeerUser#dde8a54c user_id:long access_hash:long = InputPeer;
inputPeerChannel#27bcbbfc channel_id:long access_hash:long = InputPeer;
inputPeerUserFromMessage#a87b0a1c peer:InputPeer msg_id:int user_id:long = InputPeer;
inputPeerChannelFromMessage#bd2a0840 peer:InputPeer msg_id:int channel_id:long = InputPeer;
inputUserEmpty#b98886cf = InputUser;
inputUserSelf#f7c1b13f = InputUser;
inputUser#f21158c6 user_id:long access_hash:long = InputUser;
inputUserFromMessage#1da448e2 peer:InputPeer msg_id:int user_id:long = InputUser;
inputPhoneContact#f392b7f4 client_id:long phone:string first_name:string last_name:string = InputContact;
inputFile#f52ff27f id:long parts:int name:string md5_checksum:string = InputFile;
inputFileBig#fa4f0bb5 id:long parts:int name:string = InputFile;
inputFileStoryDocument#62dc8b48 id:InputDocument = InputFile;
inputMediaEmpty#9664f57f = InputMedia;
inputMediaUploadedPhoto#1e287d04 flags:# spoiler:flags.2?true file:InputFile stickers:flags.0?Vector<InputDocument> ttl_seconds:flags.1?int = InputMedia;
inputMediaPhoto#b3ba0635 flags:# spoiler:flags.1?true id:InputPhoto ttl_seconds:flags.0?int = InputMedia;
inputMediaGeoPoint#f9c44144 geo_point:InputGeoPoint = InputMedia;
inputMediaContact#f8ab7dfb phone_number:string first_name:string last_name:string vcard:string = InputMedia;
inputMediaUploadedDocument#37c9330 flags:# nosound_video:flags.3?true force_file:flags.4?true spoiler:flags.5?true file:InputFile thumb:flags.2?InputFile mime_type:string attributes:Vector<DocumentAttribute> stickers:flags.0?Vector<InputDocument> video_cover:flags.6?InputPhoto video_timestamp:flags.7?int ttl_seconds:flags.1?int = InputMedia;
inputMediaDocument#a8763ab5 flags:# spoiler:flags.2?true id:InputDocument video_cover:flags.3?InputPhoto video_timestamp:flags.4?int ttl_seconds:flags.0?int query:flags.1?string = InputMedia;
inputMediaVenue#c13d1c11 geo_point:InputGeoPoint title:string address:string provider:string venue_id:string venue_type:string = InputMedia;
inputMediaPhotoExternal#e5bbfe1a flags:# spoiler:flags.1?true url:string ttl_seconds:flags.0?int = InputMedia;
inputMediaDocumentExternal#779600f9 flags:# spoiler:flags.1?true url:string ttl_seconds:flags.0?int video_cover:flags.2?InputPhoto video_timestamp:flags.3?int = InputMedia;
inputMediaGame#d33f43f3 id:InputGame = InputMedia;
inputMediaInvoice#405fef0d flags:# title:string description:string photo:flags.0?InputWebDocument invoice:Invoice payload:bytes provider:flags.3?string provider_data:DataJSON start_param:flags.1?string extended_media:flags.2?InputMedia = InputMedia;
inputMediaGeoLive#971fa843 flags:# stopped:flags.0?true geo_point:InputGeoPoint heading:flags.2?int period:flags.1?int proximity_notification_radius:flags.3?int = InputMedia;
inputMediaPoll#f94e5f1 flags:# poll:Poll correct_answers:flags.0?Vector<bytes> solution:flags.1?string solution_entities:flags.1?Vector<MessageEntity> = InputMedia;
inputMediaDice#e66fbf7b emoticon:string = InputMedia;
inputMediaStory#89fdd778 peer:InputPeer id:int = InputMedia;
inputMediaWebPage#c21b8849 flags:# force_large_media:flags.0?true force_small_media:flags.1?true optional:flags.2?true url:string = InputMedia;
inputMediaPaidMedia#c4103386 flags:# stars_amount:long extended_media:Vector<InputMedia> payload:flags.0?string = InputMedia;
inputChatPhotoEmpty#1ca48f57 = InputChatPhoto;
inputChatUploadedPhoto#bdcdaec0 flags:# file:flags.0?InputFile video:flags.1?InputFile video_start_ts:flags.2?double video_emoji_markup:flags.3?VideoSize = InputChatPhoto;
inputChatPhoto#8953ad37 id:InputPhoto = InputChatPhoto;
inputGeoPointEmpty#e4c123d6 = InputGeoPoint;
inputGeoPoint#48222faf flags:# lat:double long:double accuracy_radius:flags.0?int = InputGeoPoint;
inputPhotoEmpty#1cd7bf0d = InputPhoto;
inputPhoto#3bb3b94a id:long access_hash:long file_reference:bytes = InputPhoto;
inputFileLocation#dfdaabe1 volume_id:long local_id:int secret:long file_reference:bytes = InputFileLocation;
inputEncryptedFileLocation#f5235d55 id:long access_hash:long = InputFileLocation;
inputDocumentFileLocation#bad07584 id:long access_hash:long file_reference:bytes thumb_size:string = InputFileLocation;
inputSecureFileLocation#cbc7ee28 id:long access_hash:long = InputFileLocation;
inputTakeoutFileLocation#29be5899 = InputFileLocation;
inputPhotoFileLocation#40181ffe id:long access_hash:long file_reference:bytes thumb_size:string = InputFileLocation;
inputPhotoLegacyFileLocation#d83466f3 id:long access_hash:long file_reference:bytes volume_id:long local_id:int secret:long = InputFileLocation;
inputPeerPhotoFileLocation#37257e99 flags:# big:flags.0?true peer:InputPeer photo_id:long = InputFileLocation;
inputStickerSetThumb#9d84f3db stickerset:InputStickerSet thumb_version:int = InputFileLocation;
inputGroupCallStream#598a92a flags:# call:InputGroupCall time_ms:long scale:int video_channel:flags.0?int video_quality:flags.0?int = InputFileLocation;
peerUser#59511722 user_id:long = Peer;
peerChat#36c6019a chat_id:long = Peer;
peerChannel#a2a5371e channel_id:long = Peer;
storage.fileUnknown#aa963b05 = storage.FileType;
storage.filePartial#40bc6f52 = storage.FileType;
storage.fileJpeg#7efe0e = storage.FileType;
storage.fileGif#cae1aadf = storage.FileType;
storage.filePng#a4f63c0 = storage.FileType;
storage.filePdf#ae1e508d = storage.FileType;
storage.fileMp3#528a0677 = storage.FileType;
storage.fileMov#4b09ebbc = storage.FileType;
storage.fileMp4#b3cea0e4 = storage.FileType;
storage.fileWebp#1081464c = storage.FileType;
userEmpty#d3bc4b7a id:long = User;
user#4b46c37e flags:# self:flags.10?true contact:flags.11?true mutual_contact:flags.12?true deleted:flags.13?true bot:flags.14?true bot_chat_history:flags.15?true bot_nochats:flags.16?true verified:flags.17?true restricted:flags.18?true min:flags.20?true bot_inline_geo:flags.21?true support:flags.23?true scam:flags.24?true apply_min_photo:flags.25?true fake:flags.26?true bot_attach_menu:flags.27?true premium:flags.28?true attach_menu_enabled:flags.29?true flags2:# bot_can_edit:flags2.1?true close_friend:flags2.2?true stories_hidden:flags2.3?true stories_unavailable:flags2.4?true contact_require_premium:flags2.10?true bot_business:flags2.11?true bot_has_main_app:flags2.13?true id:long access_hash:flags.0?long first_name:flags.1?string last_name:flags.2?string username:flags.3?string phone:flags.4?string photo:flags.5?UserProfilePhoto status:flags.6?UserStatus bot_info_version:flags.14?int restriction_reason:flags.18?Vector<RestrictionReason> bot_inline_placeholder:flags.19?string lang_code:flags.22?string emoji_status:flags.30?EmojiStatus usernames:flags2.0?Vector<Username> stories_max_id:flags2.5?int color:flags2.8?PeerColor profile_color:flags2.9?PeerColor bot_active_users:flags2.12?int bot_verification_icon:flags2.14?long = User;
userProfilePhotoEmpty#4f11bae1 = UserProfilePhoto;
userProfilePhoto#82d1f706 flags:# has_video:flags.0?true personal:flags.2?true photo_id:long stripped_thumb:flags.1?bytes dc_id:int = UserProfilePhoto;
userStatusEmpty#9d05049 = UserStatus;
userStatusOnline#edb93949 expires:int = UserStatus;
userStatusOffline#8c703f was_online:int = UserStatus;
userStatusRecently#7b197dc8 flags:# by_me:flags.0?true = UserStatus;
userStatusLastWeek#541a1d1a flags:# by_me:flags.0?true = UserStatus;
userStatusLastMonth#65899777 flags:# by_me:flags.0?true = UserStatus;
chatEmpty#29562865 id:long = Chat;
chat#41cbf256 flags:# creator:flags.0?true left:flags.2?true deactivated:flags.5?true call_active:flags.23?true call_not_empty:flags.24?true noforwards:flags.25?true id:long title:string photo:ChatPhoto participants_count:int date:int version:int migrated_to:flags.6?InputChannel admin_rights:flags.14?ChatAdminRights default_banned_rights:flags.18?ChatBannedRights = Chat;
chatForbidden#6592a1a7 id:long title:string = Chat;
channel#e00998b7 flags:# creator:flags.0?true left:flags.2?true broadcast:flags.5?true verified:flags.7?true megagroup:flags.8?true restricted:flags.9?true signatures:flags.11?true min:flags.12?true scam:flags.19?true has_link:flags.20?true has_geo:flags.21?true slowmode_enabled:flags.22?true call_active:flags.23?true call_not_empty:flags.24?true fake:flags.25?true gigagroup:flags.26?true noforwards:flags.27?true join_to_send:flags.28?true join_request:flags.29?true forum:flags.30?true flags2:# stories_hidden:flags2.1?true stories_hidden_min:flags2.2?true stories_unavailable:flags2.3?true signature_profiles:flags2.12?true id:long access_hash:flags.13?long title:string username:flags.6?string photo:ChatPhoto date:int restriction_reason:flags.9?Vector<RestrictionReason> admin_rights:flags.14?ChatAdminRights banned_rights:flags.15?ChatBannedRights default_banned_rights:flags.18?ChatBannedRights participants_count:flags.17?int usernames:flags2.0?Vector<Username> stories_max_id:flags2.4?int color:flags2.7?PeerColor profile_color:flags2.8?PeerColor emoji_status:flags2.9?EmojiStatus level:flags2.10?int subscription_until_date:flags2.11?int bot_verification_icon:flags2.13?long = Chat;
channelForbidden#17d493d5 flags:# broadcast:flags.5?true megagroup:flags.8?true id:long access_hash:long title:string until_date:flags.16?int = Chat;
chatFull#2633421b flags:# can_set_username:flags.7?true has_scheduled:flags.8?true translations_disabled:flags.19?true id:long about:string participants:ChatParticipants chat_photo:flags.2?Photo notify_settings:PeerNotifySettings exported_invite:flags.13?ExportedChatInvite bot_info:flags.3?Vector<BotInfo> pinned_msg_id:flags.6?int folder_id:flags.11?int call:flags.12?InputGroupCall ttl_period:flags.14?int groupcall_default_join_as:flags.15?Peer theme_emoticon:flags.16?string requests_pending:flags.17?int recent_requesters:flags.17?Vector<long> available_reactions:flags.18?ChatReactions reactions_limit:flags.20?int = ChatFull;
channelFull#52d6806b flags:# can_view_participants:flags.3?true can_set_username:flags.6?true can_set_stickers:flags.7?true hidden_prehistory:flags.10?true can_set_location:flags.16?true has_scheduled:flags.19?true can_view_stats:flags.20?true blocked:flags.22?true flags2:# can_delete_channel:flags2.0?true antispam:flags2.1?true participants_hidden:flags2.2?true translations_disabled:flags2.3?true stories_pinned_available:flags2.5?true view_forum_as_messages:flags2.6?true restricted_sponsored:flags2.11?true can_view_revenue:flags2.12?true paid_media_allowed:flags2.14?true can_view_stars_revenue:flags2.15?true paid_reactions_available:flags2.16?true stargifts_available:flags2.19?true id:long about:string participants_count:flags.0?int admins_count:flags.1?int kicked_count:flags.2?int banned_count:flags.2?int online_count:flags.13?int read_inbox_max_id:int read_outbox_max_id:int unread_count:int chat_photo:Photo notify_settings:PeerNotifySettings exported_invite:flags.23?ExportedChatInvite bot_info:Vector<BotInfo> migrated_from_chat_id:flags.4?long migrated_from_max_id:flags.4?int pinned_msg_id:flags.5?int stickerset:flags.8?StickerSet available_min_id:flags.9?int folder_id:flags.11?int linked_chat_id:flags.14?long location:flags.15?ChannelLocation slowmode_seconds:flags.17?int slowmode_next_send_date:flags.18?int stats_dc:flags.12?int pts:int call:flags.21?InputGroupCall ttl_period:flags.24?int pending_suggestions:flags.25?Vector<string> groupcall_default_join_as:flags.26?Peer theme_emoticon:flags.27?string requests_pending:flags.28?int recent_requesters:flags.28?Vector<long> default_send_as:flags.29?Peer available_reactions:flags.30?ChatReactions reactions_limit:flags2.13?int stories:flags2.4?PeerStories wallpaper:flags2.7?WallPaper boosts_applied:flags2.8?int boosts_unrestrict:flags2.9?int emojiset:flags2.10?StickerSet bot_verification:flags2.17?BotVerification stargifts_count:flags2.18?int = ChatFull;
chatParticipant#c02d4007 user_id:long inviter_id:long date:int = ChatParticipant;
chatParticipantCreator#e46bcee4 user_id:long = ChatParticipant;
chatParticipantAdmin#a0933f5b user_id:long inviter_id:long date:int = ChatParticipant;
chatParticipantsForbidden#8763d3e1 flags:# chat_id:long self_participant:flags.0?ChatParticipant = ChatParticipants;
chatParticipants#3cbc93f8 chat_id:long participants:Vector<ChatParticipant> version:int = ChatParticipants;
chatPhotoEmpty#37c1011c = ChatPhoto;
chatPhoto#1c6e1c11 flags:# has_video:flags.0?true photo_id:long stripped_thumb:flags.1?bytes dc_id:int = ChatPhoto;
messageEmpty#90a6ca84 flags:# id:int peer_id:flags.0?Peer = Message;
message#96fdbbe9 flags:# out:flags.1?true mentioned:flags.4?true media_unread:flags.5?true silent:flags.13?true post:flags.14?true from_scheduled:flags.18?true legacy:flags.19?true edit_hide:flags.21?true pinned:flags.24?true noforwards:flags.26?true invert_media:flags.27?true flags2:# offline:flags2.1?true video_processing_pending:flags2.4?true id:int from_id:flags.8?Peer from_boosts_applied:flags.29?int peer_id:Peer saved_peer_id:flags.28?Peer fwd_from:flags.2?MessageFwdHeader via_bot_id:flags.11?long via_business_bot_id:flags2.0?long reply_to:flags.3?MessageReplyHeader date:int message:string media:flags.9?MessageMedia reply_markup:flags.6?ReplyMarkup entities:flags.7?Vector<MessageEntity> views:flags.10?int forwards:flags.10?int replies:flags.23?MessageReplies edit_date:flags.15?int post_author:flags.16?string grouped_id:flags.17?long reactions:flags.20?MessageReactions restriction_reason:flags.22?Vector<RestrictionReason> ttl_period:flags.25?int quick_reply_shortcut_id:flags.30?int effect:flags2.2?long factcheck:flags2.3?FactCheck report_delivery_until_date:flags2.5?int = Message;
messageService#d3d28540 flags:# out:flags.1?true mentioned:flags.4?true media_unread:flags.5?true reactions_are_possible:flags.9?true silent:flags.13?true post:flags.14?true legacy:flags.19?true id:int from_id:flags.8?Peer peer_id:Peer reply_to:flags.3?MessageReplyHeader date:int action:MessageAction reactions:flags.20?MessageReactions ttl_period:flags.25?int = Message;
messageMediaEmpty#3ded6320 = MessageMedia;
messageMediaPhoto#695150d7 flags:# spoiler:flags.3?true photo:flags.0?Photo ttl_seconds:flags.2?int = MessageMedia;
messageMediaGeo#56e0d474 geo:GeoPoint = MessageMedia;
messageMediaContact#70322949 phone_number:string first_name:string last_name:string vcard:string user_id:long = MessageMedia;
messageMediaUnsupported#9f84f49e = MessageMedia;
messageMediaDocument#52d8ccd9 flags:# nopremium:flags.3?true spoiler:flags.4?true video:flags.6?true round:flags.7?true voice:flags.8?true document:flags.0?Document alt_documents:flags.5?Vector<Document> video_cover:flags.9?Photo video_timestamp:flags.10?int ttl_seconds:flags.2?int = MessageMedia;
messageMediaWebPage#ddf10c3b flags:# force_large_media:flags.0?true force_small_media:flags.1?true manual:flags.3?true safe:flags.4?true webpage:WebPage = MessageMedia;
messageMediaVenue#2ec0533f geo:GeoPoint title:string address:string provider:string venue_id:string venue_type:string = MessageMedia;
messageMediaGame#fdb19008 game:Game = MessageMedia;
messageMediaInvoice#f6a548d3 flags:# shipping_address_requested:flags.1?true test:flags.3?true title:string description:string photo:flags.0?WebDocument receipt_msg_id:flags.2?int currency:string total_amount:long start_param:string extended_media:flags.4?MessageExtendedMedia = MessageMedia;
messageMediaGeoLive#b940c666 flags:# geo:GeoPoint heading:flags.0?int period:int proximity_notification_radius:flags.1?int = MessageMedia;
messageMediaPoll#4bd6e798 poll:Poll results:PollResults = MessageMedia;
messageMediaDice#3f7ee58b value:int emoticon:string = MessageMedia;
messageMediaStory#68cb6283 flags:# via_mention:flags.1?true peer:Peer id:int story:flags.0?StoryItem = MessageMedia;
messageMediaGiveaway#aa073beb flags:# only_new_subscribers:flags.0?true winners_are_visible:flags.2?true channels:Vector<long> countries_iso2:flags.1?Vector<string> prize_description:flags.3?string quantity:int months:flags.4?int stars:flags.5?long until_date:int = MessageMedia;
messageMediaGiveawayResults#ceaa3ea1 flags:# only_new_subscribers:flags.0?true refunded:flags.2?true channel_id:long additional_peers_count:flags.3?int launch_msg_id:int winners_count:int unclaimed_count:int winners:Vector<long> months:flags.4?int stars:flags.5?long prize_description:flags.1?string until_date:int = MessageMedia;
messageMediaPaidMedia#a8852491 stars_amount:long extended_media:Vector<MessageExtendedMedia> = MessageMedia;
messageActionEmpty#b6aef7b0 = MessageAction;
messageActionChatCreate#bd47cbad title:string users:Vector<long> = MessageAction;
messageActionChatEditTitle#b5a1ce5a title:string = MessageAction;
messageActionChatEditPhoto#7fcb13a8 photo:Photo = MessageAction;
messageActionChatDeletePhoto#95e3fbef = MessageAction;
messageActionChatAddUser#15cefd00 users:Vector<long> = MessageAction;
messageActionChatDeleteUser#a43f30cc user_id:long = MessageAction;
messageActionChatJoinedByLink#31224c3 inviter_id:long = MessageAction;
messageActionChannelCreate#95d2ac92 title:string = MessageAction;
messageActionChatMigrateTo#e1037f92 channel_id:long = MessageAction;
messageActionChannelMigrateFrom#ea3948e9 title:string chat_id:long = MessageAction;
messageActionPinMessage#94bd38ed = MessageAction;
messageActionHistoryClear#9fbab604 = MessageAction;
messageActionGameScore#92a72876 game_id:long score:int = MessageAction;
messageActionPaymentSentMe#ffa00ccc flags:# recurring_init:flags.2?true recurring_used:flags.3?true currency:string total_amount:long payload:bytes info:flags.0?PaymentRequestedInfo shipping_option_id:flags.1?string charge:PaymentCharge subscription_until_date:flags.4?int = MessageAction;
messageActionPaymentSent#c624b16e flags:# recurring_init:flags.2?true recurring_used:flags.3?true currency:string total_amount:long invoice_slug:flags.0?string subscription_until_date:flags.4?int = MessageAction;
messageActionPhoneCall#80e11a7f flags:# video:flags.2?true call_id:long reason:flags.0?PhoneCallDiscardReason duration:flags.1?int = MessageAction;
messageActionScreenshotTaken#4792929b = MessageAction;
messageActionCustomAction#fae69f56 message:string = MessageAction;
messageActionBotAllowed#c516d679 flags:# attach_menu:flags.1?true from_request:flags.3?true domain:flags.0?string app:flags.2?BotApp = MessageAction;
messageActionSecureValuesSentMe#1b287353 values:Vector<SecureValue> credentials:SecureCredentialsEncrypted = MessageAction;
messageActionSecureValuesSent#d95c6154 types:Vector<SecureValueType> = MessageAction;
messageActionContactSignUp#f3f25f76 = MessageAction;
messageActionGeoProximityReached#98e0d697 from_id:Peer to_id:Peer distance:int = MessageAction;
messageActionGroupCall#7a0d7f42 flags:# call:InputGroupCall duration:flags.0?int = MessageAction;
messageActionInviteToGroupCall#502f92f7 call:InputGroupCall users:Vector<long> = MessageAction;
messageActionSetMessagesTTL#3c134d7b flags:# period:int auto_setting_from:flags.0?long = MessageAction;
messageActionGroupCallScheduled#b3a07661 call:InputGroupCall schedule_date:int = MessageAction;
messageActionSetChatTheme#aa786345 emoticon:string = MessageAction;
messageActionChatJoinedByRequest#ebbca3cb = MessageAction;
messageActionWebViewDataSentMe#47dd8079 text:string data:string = MessageAction;
messageActionWebViewDataSent#b4c38cb5 text:string = MessageAction;
messageActionGiftPremium#6c6274fa flags:# currency:string amount:long months:int crypto_currency:flags.0?string crypto_amount:flags.0?long message:flags.1?TextWithEntities = MessageAction;
messageActionTopicCreate#d999256 flags:# title:string icon_color:int icon_emoji_id:flags.0?long = MessageAction;
messageActionTopicEdit#c0944820 flags:# title:flags.0?string icon_emoji_id:flags.1?long closed:flags.2?Bool hidden:flags.3?Bool = MessageAction;
messageActionSuggestProfilePhoto#57de635e photo:Photo = MessageAction;
messageActionRequestedPeer#31518e9b button_id:int peers:Vector<Peer> = MessageAction;
messageActionSetChatWallPaper#5060a3f4 flags:# same:flags.0?true for_both:flags.1?true wallpaper:WallPaper = MessageAction;
messageActionGiftCode#56d03994 flags:# via_giveaway:flags.0?true unclaimed:flags.2?true boost_peer:flags.1?Peer months:int slug:string currency:flags.2?string amount:flags.2?long crypto_currency:flags.3?string crypto_amount:flags.3?long message:flags.4?TextWithEntities = MessageAction;
messageActionGiveawayLaunch#a80f51e4 flags:# stars:flags.0?long = MessageAction;
messageActionGiveawayResults#87e2f155 flags:# stars:flags.0?true winners_count:int unclaimed_count:int = MessageAction;
messageActionBoostApply#cc02aa6d boosts:int = MessageAction;
messageActionRequestedPeerSentMe#93b31848 button_id:int peers:Vector<RequestedPeer> = MessageAction;
messageActionPaymentRefunded#41b3e202 flags:# peer:Peer currency:string total_amount:long payload:flags.0?bytes charge:PaymentCharge = MessageAction;
messageActionGiftStars#45d5b021 flags:# currency:string amount:long stars:long crypto_currency:flags.0?string crypto_amount:flags.0?long transaction_id:flags.1?string = MessageAction;
messageActionPrizeStars#b00c47a2 flags:# unclaimed:flags.0?true stars:long transaction_id:string boost_peer:Peer giveaway_msg_id:int = MessageAction;
messageActionStarGift#4717e8a4 flags:# name_hidden:flags.0?true saved:flags.2?true converted:flags.3?true upgraded:flags.5?true refunded:flags.9?true can_upgrade:flags.10?true gift:StarGift message:flags.1?TextWithEntities convert_stars:flags.4?long upgrade_msg_id:flags.5?int upgrade_stars:flags.8?long from_id:flags.11?Peer peer:flags.12?Peer saved_id:flags.12?long = MessageAction;
messageActionStarGiftUnique#acdfcb81 flags:# upgrade:flags.0?true transferred:flags.1?true saved:flags.2?true refunded:flags.5?true gift:StarGift can_export_at:flags.3?int transfer_stars:flags.4?long from_id:flags.6?Peer peer:flags.7?Peer saved_id:flags.7?long = MessageAction;
dialog#d58a08c6 flags:# pinned:flags.2?true unread_mark:flags.3?true view_forum_as_messages:flags.6?true peer:Peer top_message:int read_inbox_max_id:int read_outbox_max_id:int unread_count:int unread_mentions_count:int unread_reactions_count:int notify_settings:PeerNotifySettings pts:flags.0?int draft:flags.1?DraftMessage folder_id:flags.4?int ttl_period:flags.5?int = Dialog;
dialogFolder#71bd134c flags:# pinned:flags.2?true folder:Folder peer:Peer top_message:int unread_muted_peers_count:int unread_unmuted_peers_count:int unread_muted_messages_count:int unread_unmuted_messages_count:int = Dialog;
photoEmpty#2331b22d id:long = Photo;
photo#fb197a65 flags:# has_stickers:flags.0?true id:long access_hash:long file_reference:bytes date:int sizes:Vector<PhotoSize> video_sizes:flags.1?Vector<VideoSize> dc_id:int = Photo;
photoSizeEmpty#e17e23c type:string = PhotoSize;
photoSize#75c78e60 type:string w:int h:int size:int = PhotoSize;
photoCachedSize#21e1ad6 type:string w:int h:int bytes:bytes = PhotoSize;
photoStrippedSize#e0b0bc2e type:string bytes:bytes = PhotoSize;
photoSizeProgressive#fa3efb95 type:string w:int h:int sizes:Vector<int> = PhotoSize;
photoPathSize#d8214d41 type:string bytes:bytes = PhotoSize;
geoPointEmpty#1117dd5f = GeoPoint;
geoPoint#b2a2f663 flags:# long:double lat:double access_hash:long accuracy_radius:flags.0?int = GeoPoint;
auth.sentCode#5e002502 flags:# type:auth.SentCodeType phone_code_hash:string next_type:flags.1?auth.CodeType timeout:flags.2?int = auth.SentCode;
auth.sentCodeSuccess#2390fe44 authorization:auth.Authorization = auth.SentCode;
auth.authorization#2ea2c0d4 flags:# setup_password_required:flags.1?true otherwise_relogin_days:flags.1?int tmp_sessions:flags.0?int future_auth_token:flags.2?bytes user:User = auth.Authorization;
auth.authorizationSignUpRequired#44747e9a flags:# terms_of_service:flags.0?help.TermsOfService = auth.Authorization;
auth.exportedAuthorization#b434e2b8 id:long bytes:bytes = auth.ExportedAuthorization;
inputNotifyPeer#b8bc5b0c peer:InputPeer = InputNotifyPeer;
inputNotifyUsers#193b4417 = InputNotifyPeer;
inputNotifyChats#4a95e84e = InputNotifyPeer;
inputNotifyBroadcasts#b1db7c7e = InputNotifyPeer;
inputNotifyForumTopic#5c467992 peer:InputPeer top_msg_id:int = InputNotifyPeer;
inputPeerNotifySettings#cacb6ae2 flags:# show_previews:flags.0?Bool silent:flags.1?Bool mute_until:flags.2?int sound:flags.3?NotificationSound stories_muted:flags.6?Bool stories_hide_sender:flags.7?Bool stories_sound:flags.8?NotificationSound = InputPeerNotifySettings;
peerNotifySettings#99622c0c flags:# show_previews:flags.0?Bool silent:flags.1?Bool mute_until:flags.2?int ios_sound:flags.3?NotificationSound android_sound:flags.4?NotificationSound other_sound:flags.5?NotificationSound stories_muted:flags.6?Bool stories_hide_sender:flags.7?Bool stories_ios_sound:flags.8?NotificationSound stories_android_sound:flags.9?NotificationSound stories_other_sound:flags.10?NotificationSound = PeerNotifySettings;
peerSettings#acd66c5e flags:# report_spam:flags.0?true add_contact:flags.1?true block_contact:flags.2?true share_contact:flags.3?true need_contacts_exception:flags.4?true report_geo:flags.5?true autoarchived:flags.7?true invite_members:flags.8?true request_chat_broadcast:flags.10?true business_bot_paused:flags.11?true business_bot_can_reply:flags.12?true geo_distance:flags.6?int request_chat_title:flags.9?string request_chat_date:flags.9?int business_bot_id:flags.13?long business_bot_manage_url:flags.13?string = PeerSettings;
wallPaper#a437c3ed id:long flags:# creator:flags.0?true default:flags.1?true pattern:flags.3?true dark:flags.4?true access_hash:long slug:string document:Document settings:flags.2?WallPaperSettings = WallPaper;
wallPaperNoFile#e0804116 id:long flags:# default:flags.1?true dark:flags.4?true settings:flags.2?WallPaperSettings = WallPaper;
inputReportReasonSpam#58dbcab8 = ReportReason;
inputReportReasonViolence#1e22c78d = ReportReason;
inputReportReasonPornography#2e59d922 = ReportReason;
inputReportReasonChildAbuse#adf44ee3 = ReportReason;
inputReportReasonOther#c1e4a2b1 = ReportReason;
inputReportReasonCopyright#9b89f93a = ReportReason;
inputReportReasonGeoIrrelevant#dbd4feed = ReportReason;
inputReportReasonFake#f5ddd6e7 = ReportReason;
inputReportReasonIllegalDrugs#a8eb2be = ReportReason;
inputReportReasonPersonalDetails#9ec7863d = ReportReason;
userFull#4d975bbc flags:# blocked:flags.0?true phone_calls_available:flags.4?true phone_calls_private:flags.5?true can_pin_message:flags.7?true has_scheduled:flags.12?true video_calls_available:flags.13?true voice_messages_forbidden:flags.20?true translations_disabled:flags.23?true stories_pinned_available:flags.26?true blocked_my_stories_from:flags.27?true wallpaper_overridden:flags.28?true contact_require_premium:flags.29?true read_dates_private:flags.30?true flags2:# sponsored_enabled:flags2.7?true can_view_revenue:flags2.9?true bot_can_manage_emoji_status:flags2.10?true id:long about:flags.1?string settings:PeerSettings personal_photo:flags.21?Photo profile_photo:flags.2?Photo fallback_photo:flags.22?Photo notify_settings:PeerNotifySettings bot_info:flags.3?BotInfo pinned_msg_id:flags.6?int common_chats_count:int folder_id:flags.11?int ttl_period:flags.14?int theme_emoticon:flags.15?string private_forward_name:flags.16?string bot_group_admin_rights:flags.17?ChatAdminRights bot_broadcast_admin_rights:flags.18?ChatAdminRights premium_gifts:flags.19?Vector<PremiumGiftOption> wallpaper:flags.24?WallPaper stories:flags.25?PeerStories business_work_hours:flags2.0?BusinessWorkHours business_location:flags2.1?BusinessLocation business_greeting_message:flags2.2?BusinessGreetingMessage business_away_message:flags2.3?BusinessAwayMessage business_intro:flags2.4?BusinessIntro birthday:flags2.5?Birthday personal_channel_id:flags2.6?long personal_channel_message:flags2.6?int stargifts_count:flags2.8?int starref_program:flags2.11?StarRefProgram bot_verification:flags2.12?BotVerification = UserFull;
contact#145ade0b user_id:long mutual:Bool = Contact;
importedContact#c13e3c50 user_id:long client_id:long = ImportedContact;
contactStatus#16d9703b user_id:long status:UserStatus = ContactStatus;
contacts.contactsNotModified#b74ba9d2 = contacts.Contacts;
contacts.contacts#eae87e42 contacts:Vector<Contact> saved_count:int users:Vector<User> = contacts.Contacts;
contacts.importedContacts#77d01c3b imported:Vector<ImportedContact> popular_invites:Vector<PopularContact> retry_contacts:Vector<long> users:Vector<User> = contacts.ImportedContacts;
contacts.blocked#ade1591 blocked:Vector<PeerBlocked> chats:Vector<Chat> users:Vector<User> = contacts.Blocked;
contacts.blockedSlice#e1664194 count:int blocked:Vector<PeerBlocked> chats:Vector<Chat> users:Vector<User> = contacts.Blocked;
messages.dialogs#15ba6c40 dialogs:Vector<Dialog> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.Dialogs;
messages.dialogsSlice#71e094f3 count:int dialogs:Vector<Dialog> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.Dialogs;
messages.dialogsNotModified#f0e3e596 count:int = messages.Dialogs;
messages.messages#8c718e87 messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.Messages;
messages.messagesSlice#3a54685e flags:# inexact:flags.1?true count:int next_rate:flags.0?int offset_id_offset:flags.2?int messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.Messages;
messages.channelMessages#c776ba4e flags:# inexact:flags.1?true pts:int count:int offset_id_offset:flags.2?int messages:Vector<Message> topics:Vector<ForumTopic> chats:Vector<Chat> users:Vector<User> = messages.Messages;
messages.messagesNotModified#74535f21 count:int = messages.Messages;
messages.chats#64ff9fd5 chats:Vector<Chat> = messages.Chats;
messages.chatsSlice#9cd81144 count:int chats:Vector<Chat> = messages.Chats;
messages.chatFull#e5d7d19c full_chat:ChatFull chats:Vector<Chat> users:Vector<User> = messages.ChatFull;
messages.affectedHistory#b45c69d1 pts:int pts_count:int offset:int = messages.AffectedHistory;
inputMessagesFilterEmpty#57e2f66c = MessagesFilter;
inputMessagesFilterPhotos#9609a51c = MessagesFilter;
inputMessagesFilterVideo#9fc00e65 = MessagesFilter;
inputMessagesFilterPhotoVideo#56e9f0e4 = MessagesFilter;
inputMessagesFilterDocument#9eddf188 = MessagesFilter;
inputMessagesFilterUrl#7ef0dd87 = MessagesFilter;
inputMessagesFilterGif#ffc86587 = MessagesFilter;
inputMessagesFilterVoice#50f5c392 = MessagesFilter;
inputMessagesFilterMusic#3751b49e = MessagesFilter;
inputMessagesFilterChatPhotos#3a20ecb8 = MessagesFilter;
inputMessagesFilterPhoneCalls#80c99768 flags:# missed:flags.0?true = MessagesFilter;
inputMessagesFilterRoundVoice#7a7c17a4 = MessagesFilter;
inputMessagesFilterRoundVideo#b549da53 = MessagesFilter;
inputMessagesFilterMyMentions#c1f8e69a = MessagesFilter;
inputMessagesFilterGeo#e7026d0d = MessagesFilter;
inputMessagesFilterContacts#e062db83 = MessagesFilter;
inputMessagesFilterPinned#1bb00451 = MessagesFilter;
updateNewMessage#1f2b0afd message:Message pts:int pts_count:int = Update;
updateMessageID#4e90bfd6 id:int random_id:long = Update;
updateDeleteMessages#a20db0e5 messages:Vector<int> pts:int pts_count:int = Update;
updateUserTyping#c01e857f user_id:long action:SendMessageAction = Update;
updateChatUserTyping#83487af0 chat_id:long from_id:Peer action:SendMessageAction = Update;
updateChatParticipants#7761198 participants:ChatParticipants = Update;
updateUserStatus#e5bdf8de user_id:long status:UserStatus = Update;
updateUserName#a7848924 user_id:long first_name:string last_name:string usernames:Vector<Username> = Update;
updateNewAuthorization#8951abef flags:# unconfirmed:flags.0?true hash:long date:flags.0?int device:flags.0?string location:flags.0?string = Update;
updateNewEncryptedMessage#12bcbd9a message:EncryptedMessage qts:int = Update;
updateEncryptedChatTyping#1710f156 chat_id:int = Update;
updateEncryption#b4a2e88d chat:EncryptedChat date:int = Update;
updateEncryptedMessagesRead#38fe25b7 chat_id:int max_date:int date:int = Update;
updateChatParticipantAdd#3dda5451 chat_id:long user_id:long inviter_id:long date:int version:int = Update;
updateChatParticipantDelete#e32f3d77 chat_id:long user_id:long version:int = Update;
updateDcOptions#8e5e9873 dc_options:Vector<DcOption> = Update;
updateNotifySettings#bec268ef peer:NotifyPeer notify_settings:PeerNotifySettings = Update;
updateServiceNotification#ebe46819 flags:# popup:flags.0?true invert_media:flags.2?true inbox_date:flags.1?int type:string message:string media:MessageMedia entities:Vector<MessageEntity> = Update;
updatePrivacy#ee3b272a key:PrivacyKey rules:Vector<PrivacyRule> = Update;
updateUserPhone#5492a13 user_id:long phone:string = Update;
updateReadHistoryInbox#9c974fdf flags:# folder_id:flags.0?int peer:Peer max_id:int still_unread_count:int pts:int pts_count:int = Update;
updateReadHistoryOutbox#2f2f21bf peer:Peer max_id:int pts:int pts_count:int = Update;
updateWebPage#7f891213 webpage:WebPage pts:int pts_count:int = Update;
updateReadMessagesContents#f8227181 flags:# messages:Vector<int> pts:int pts_count:int date:flags.0?int = Update;
updateChannelTooLong#108d941f flags:# channel_id:long pts:flags.0?int = Update;
updateChannel#635b4c09 channel_id:long = Update;
updateNewChannelMessage#62ba04d9 message:Message pts:int pts_count:int = Update;
updateReadChannelInbox#922e6e10 flags:# folder_id:flags.0?int channel_id:long max_id:int still_unread_count:int pts:int = Update;
updateDeleteChannelMessages#c32d5b12 channel_id:long messages:Vector<int> pts:int pts_count:int = Update;
updateChannelMessageViews#f226ac08 channel_id:long id:int views:int = Update;
updateChatParticipantAdmin#d7ca61a2 chat_id:long user_id:long is_admin:Bool version:int = Update;
updateNewStickerSet#688a30aa stickerset:messages.StickerSet = Update;
updateStickerSetsOrder#bb2d201 flags:# masks:flags.0?true emojis:flags.1?true order:Vector<long> = Update;
updateStickerSets#31c24808 flags:# masks:flags.0?true emojis:flags.1?true = Update;
updateSavedGifs#9375341e = Update;
updateBotInlineQuery#496f379c flags:# query_id:long user_id:long query:string geo:flags.0?GeoPoint peer_type:flags.1?InlineQueryPeerType offset:string = Update;
updateBotInlineSend#12f12a07 flags:# user_id:long query:string geo:flags.0?GeoPoint id:string msg_id:flags.1?InputBotInlineMessageID = Update;
updateEditChannelMessage#1b3f4df7 message:Message pts:int pts_count:int = Update;
updateBotCallbackQuery#b9cfc48d flags:# query_id:long user_id:long peer:Peer msg_id:int chat_instance:long data:flags.0?bytes game_short_name:flags.1?string = Update;
updateEditMessage#e40370a3 message:Message pts:int pts_count:int = Update;
updateInlineBotCallbackQuery#691e9052 flags:# query_id:long user_id:long msg_id:InputBotInlineMessageID chat_instance:long data:flags.0?bytes game_short_name:flags.1?string = Update;
updateReadChannelOutbox#b75f99a9 channel_id:long max_id:int = Update;
updateDraftMessage#1b49ec6d flags:# peer:Peer top_msg_id:flags.0?int draft:DraftMessage = Update;
updateReadFeaturedStickers#571d2742 = Update;
updateRecentStickers#9a422c20 = Update;
updateConfig#a229dd06 = Update;
updatePtsChanged#3354678f = Update;
updateChannelWebPage#2f2ba99f channel_id:long webpage:WebPage pts:int pts_count:int = Update;
updateDialogPinned#6e6fe51c flags:# pinned:flags.0?true folder_id:flags.1?int peer:DialogPeer = Update;
updatePinnedDialogs#fa0f3ca2 flags:# folder_id:flags.1?int order:flags.0?Vector<DialogPeer> = Update;
updateBotWebhookJSON#8317c0c3 data:DataJSON = Update;
updateBotWebhookJSONQuery#9b9240a6 query_id:long data:DataJSON timeout:int = Update;
updateBotShippingQuery#b5aefd7d query_id:long user_id:long payload:bytes shipping_address:PostAddress = Update;
updateBotPrecheckoutQuery#8caa9a96 flags:# query_id:long user_id:long payload:bytes info:flags.0?PaymentRequestedInfo shipping_option_id:flags.1?string currency:string total_amount:long = Update;
updatePhoneCall#ab0f6b1e phone_call:PhoneCall = Update;
updateLangPackTooLong#46560264 lang_code:string = Update;
updateLangPack#56022f4d difference:LangPackDifference = Update;
updateFavedStickers#e511996d = Update;
updateChannelReadMessagesContents#ea29055d flags:# channel_id:long top_msg_id:flags.0?int messages:Vector<int> = Update;
updateContactsReset#7084a7be = Update;
updateChannelAvailableMessages#b23fc698 channel_id:long available_min_id:int = Update;
updateDialogUnreadMark#e16459c3 flags:# unread:flags.0?true peer:DialogPeer = Update;
updateMessagePoll#aca1657b flags:# poll_id:long poll:flags.0?Poll results:PollResults = Update;
updateChatDefaultBannedRights#54c01850 peer:Peer default_banned_rights:ChatBannedRights version:int = Update;
updateFolderPeers#19360dc0 folder_peers:Vector<FolderPeer> pts:int pts_count:int = Update;
updatePeerSettings#6a7e7366 peer:Peer settings:PeerSettings = Update;
updatePeerLocated#b4afcfb0 peers:Vector<PeerLocated> = Update;
updateNewScheduledMessage#39a51dfb message:Message = Update;
updateDeleteScheduledMessages#f2a71983 flags:# peer:Peer messages:Vector<int> sent_messages:flags.0?Vector<int> = Update;
updateTheme#8216fba3 theme:Theme = Update;
updateGeoLiveViewed#871fb939 peer:Peer msg_id:int = Update;
updateLoginToken#564fe691 = Update;
updateMessagePollVote#24f40e77 poll_id:long peer:Peer options:Vector<bytes> qts:int = Update;
updateDialogFilter#26ffde7d flags:# id:int filter:flags.0?DialogFilter = Update;
updateDialogFilterOrder#a5d72105 order:Vector<int> = Update;
updateDialogFilters#3504914f = Update;
updatePhoneCallSignalingData#2661bf09 phone_call_id:long data:bytes = Update;
updateChannelMessageForwards#d29a27f4 channel_id:long id:int forwards:int = Update;
updateReadChannelDiscussionInbox#d6b19546 flags:# channel_id:long top_msg_id:int read_max_id:int broadcast_id:flags.0?long broadcast_post:flags.0?int = Update;
updateReadChannelDiscussionOutbox#695c9e7c channel_id:long top_msg_id:int read_max_id:int = Update;
updatePeerBlocked#ebe07752 flags:# blocked:flags.0?true blocked_my_stories_from:flags.1?true peer_id:Peer = Update;
updateChannelUserTyping#8c88c923 flags:# channel_id:long top_msg_id:flags.0?int from_id:Peer action:SendMessageAction = Update;
updatePinnedMessages#ed85eab5 flags:# pinned:flags.0?true peer:Peer messages:Vector<int> pts:int pts_count:int = Update;
updatePinnedChannelMessages#5bb98608 flags:# pinned:flags.0?true channel_id:long messages:Vector<int> pts:int pts_count:int = Update;
updateChat#f89a6a4e chat_id:long = Update;
updateGroupCallParticipants#f2ebdb4e call:InputGroupCall participants:Vector<GroupCallParticipant> version:int = Update;
updateGroupCall#97d64341 flags:# chat_id:flags.0?long call:GroupCall = Update;
updatePeerHistoryTTL#bb9bb9a5 flags:# peer:Peer ttl_period:flags.0?int = Update;
updateChatParticipant#d087663a flags:# chat_id:long date:int actor_id:long user_id:long prev_participant:flags.0?ChatParticipant new_participant:flags.1?ChatParticipant invite:flags.2?ExportedChatInvite qts:int = Update;
updateChannelParticipant#985d3abb flags:# via_chatlist:flags.3?true channel_id:long date:int actor_id:long user_id:long prev_participant:flags.0?ChannelParticipant new_participant:flags.1?ChannelParticipant invite:flags.2?ExportedChatInvite qts:int = Update;
updateBotStopped#c4870a49 user_id:long date:int stopped:Bool qts:int = Update;
updateGroupCallConnection#b783982 flags:# presentation:flags.0?true params:DataJSON = Update;
updateBotCommands#4d712f2e peer:Peer bot_id:long commands:Vector<BotCommand> = Update;
updatePendingJoinRequests#7063c3db peer:Peer requests_pending:int recent_requesters:Vector<long> = Update;
updateBotChatInviteRequester#11dfa986 peer:Peer date:int user_id:long about:string invite:ExportedChatInvite qts:int = Update;
updateMessageReactions#5e1b3cb8 flags:# peer:Peer msg_id:int top_msg_id:flags.0?int reactions:MessageReactions = Update;
updateAttachMenuBots#17b7a20b = Update;
updateWebViewResultSent#1592b79d query_id:long = Update;
updateBotMenuButton#14b85813 bot_id:long button:BotMenuButton = Update;
updateSavedRingtones#74d8be99 = Update;
updateTranscribedAudio#84cd5a flags:# pending:flags.0?true peer:Peer msg_id:int transcription_id:long text:string = Update;
updateReadFeaturedEmojiStickers#fb4c496c = Update;
updateUserEmojiStatus#28373599 user_id:long emoji_status:EmojiStatus = Update;
updateRecentEmojiStatuses#30f443db = Update;
updateRecentReactions#6f7863f4 = Update;
updateMoveStickerSetToTop#86fccf85 flags:# masks:flags.0?true emojis:flags.1?true stickerset:long = Update;
updateMessageExtendedMedia#d5a41724 peer:Peer msg_id:int extended_media:Vector<MessageExtendedMedia> = Update;
updateChannelPinnedTopic#192efbe3 flags:# pinned:flags.0?true channel_id:long topic_id:int = Update;
updateChannelPinnedTopics#fe198602 flags:# channel_id:long order:flags.0?Vector<int> = Update;
updateUser#20529438 user_id:long = Update;
updateAutoSaveSettings#ec05b097 = Update;
updateStory#75b3b798 peer:Peer story:StoryItem = Update;
updateReadStories#f74e932b peer:Peer max_id:int = Update;
updateStoryID#1bf335b9 id:int random_id:long = Update;
updateStoriesStealthMode#2c084dc1 stealth_mode:StoriesStealthMode = Update;
updateSentStoryReaction#7d627683 peer:Peer story_id:int reaction:Reaction = Update;
updateBotChatBoost#904dd49c peer:Peer boost:Boost qts:int = Update;
updateChannelViewForumAsMessages#7b68920 channel_id:long enabled:Bool = Update;
updatePeerWallpaper#ae3f101d flags:# wallpaper_overridden:flags.1?true peer:Peer wallpaper:flags.0?WallPaper = Update;
updateBotMessageReaction#ac21d3ce peer:Peer msg_id:int date:int actor:Peer old_reactions:Vector<Reaction> new_reactions:Vector<Reaction> qts:int = Update;
updateBotMessageReactions#9cb7759 peer:Peer msg_id:int date:int reactions:Vector<ReactionCount> qts:int = Update;
updateSavedDialogPinned#aeaf9e74 flags:# pinned:flags.0?true peer:DialogPeer = Update;
updatePinnedSavedDialogs#686c85a6 flags:# order:flags.0?Vector<DialogPeer> = Update;
updateSavedReactionTags#39c67432 = Update;
updateSmsJob#f16269d4 job_id:string = Update;
updateQuickReplies#f9470ab2 quick_replies:Vector<QuickReply> = Update;
updateNewQuickReply#f53da717 quick_reply:QuickReply = Update;
updateDeleteQuickReply#53e6f1ec shortcut_id:int = Update;
updateQuickReplyMessage#3e050d0f message:Message = Update;
updateDeleteQuickReplyMessages#566fe7cd shortcut_id:int messages:Vector<int> = Update;
updateBotBusinessConnect#8ae5c97a connection:BotBusinessConnection qts:int = Update;
updateBotNewBusinessMessage#9ddb347c flags:# connection_id:string message:Message reply_to_message:flags.0?Message qts:int = Update;
updateBotEditBusinessMessage#7df587c flags:# connection_id:string message:Message reply_to_message:flags.0?Message qts:int = Update;
updateBotDeleteBusinessMessage#a02a982e connection_id:string peer:Peer messages:Vector<int> qts:int = Update;
updateNewStoryReaction#1824e40b story_id:int peer:Peer reaction:Reaction = Update;
updateBroadcastRevenueTransactions#dfd961f5 peer:Peer balances:BroadcastRevenueBalances = Update;
updateStarsBalance#4e80a379 balance:StarsAmount = Update;
updateBusinessBotCallbackQuery#1ea2fda7 flags:# query_id:long user_id:long connection_id:string message:Message reply_to_message:flags.2?Message chat_instance:long data:flags.0?bytes = Update;
updateStarsRevenueStatus#a584b019 peer:Peer status:StarsRevenueStatus = Update;
updateBotPurchasedPaidMedia#283bd312 user_id:long payload:string qts:int = Update;
updatePaidReactionPrivacy#51ca7aec private:Bool = Update;
updates.state#a56c2a3e pts:int qts:int date:int seq:int unread_count:int = updates.State;
updates.differenceEmpty#5d75a138 date:int seq:int = updates.Difference;
updates.difference#f49ca0 new_messages:Vector<Message> new_encrypted_messages:Vector<EncryptedMessage> other_updates:Vector<Update> chats:Vector<Chat> users:Vector<User> state:updates.State = updates.Difference;
updates.differenceSlice#a8fb1981 new_messages:Vector<Message> new_encrypted_messages:Vector<EncryptedMessage> other_updates:Vector<Update> chats:Vector<Chat> users:Vector<User> intermediate_state:updates.State = updates.Difference;
updates.differenceTooLong#4afe8f6d pts:int = updates.Difference;
updatesTooLong#e317af7e = Updates;
updateShortMessage#313bc7f8 flags:# out:flags.1?true mentioned:flags.4?true media_unread:flags.5?true silent:flags.13?true id:int user_id:long message:string pts:int pts_count:int date:int fwd_from:flags.2?MessageFwdHeader via_bot_id:flags.11?long reply_to:flags.3?MessageReplyHeader entities:flags.7?Vector<MessageEntity> ttl_period:flags.25?int = Updates;
updateShortChatMessage#4d6deea5 flags:# out:flags.1?true mentioned:flags.4?true media_unread:flags.5?true silent:flags.13?true id:int from_id:long chat_id:long message:string pts:int pts_count:int date:int fwd_from:flags.2?MessageFwdHeader via_bot_id:flags.11?long reply_to:flags.3?MessageReplyHeader entities:flags.7?Vector<MessageEntity> ttl_period:flags.25?int = Updates;
updateShort#78d4dec1 update:Update date:int = Updates;
updatesCombined#725b04c3 updates:Vector<Update> users:Vector<User> chats:Vector<Chat> date:int seq_start:int seq:int = Updates;
updates#74ae4240 updates:Vector<Update> users:Vector<User> chats:Vector<Chat> date:int seq:int = Updates;
updateShortSentMessage#9015e101 flags:# out:flags.1?true id:int pts:int pts_count:int date:int media:flags.9?MessageMedia entities:flags.7?Vector<MessageEntity> ttl_period:flags.25?int = Updates;
photos.photos#8dca6aa5 photos:Vector<Photo> users:Vector<User> = photos.Photos;
photos.photosSlice#15051f54 count:int photos:Vector<Photo> users:Vector<User> = photos.Photos;
photos.photo#20212ca8 photo:Photo users:Vector<User> = photos.Photo;
upload.file#96a18d5 type:storage.FileType mtime:int bytes:bytes = upload.File;
upload.fileCdnRedirect#f18cda44 dc_id:int file_token:bytes encryption_key:bytes encryption_iv:bytes file_hashes:Vector<FileHash> = upload.File;
dcOption#18b7a10d flags:# ipv6:flags.0?true media_only:flags.1?true tcpo_only:flags.2?true cdn:flags.3?true static:flags.4?true this_port_only:flags.5?true id:int ip_address:string port:int secret:flags.10?bytes = DcOption;
config#cc1a241e flags:# default_p2p_contacts:flags.3?true preload_featured_stickers:flags.4?true revoke_pm_inbox:flags.6?true blocked_mode:flags.8?true force_try_ipv6:flags.14?true date:int expires:int test_mode:Bool this_dc:int dc_options:Vector<DcOption> dc_txt_domain_name:string chat_size_max:int megagroup_size_max:int forwarded_count_max:int online_update_period_ms:int offline_blur_timeout_ms:int offline_idle_timeout_ms:int online_cloud_timeout_ms:int notify_cloud_delay_ms:int notify_default_delay_ms:int push_chat_period_ms:int push_chat_limit:int edit_time_limit:int revoke_time_limit:int revoke_pm_time_limit:int rating_e_decay:int stickers_recent_limit:int channels_read_media_period:int tmp_sessions:flags.0?int call_receive_timeout_ms:int call_ring_timeout_ms:int call_connect_timeout_ms:int call_packet_timeout_ms:int me_url_prefix:string autoupdate_url_prefix:flags.7?string gif_search_username:flags.9?string venue_search_username:flags.10?string img_search_username:flags.11?string static_maps_provider:flags.12?string caption_length_max:int message_length_max:int webfile_dc_id:int suggested_lang_code:flags.2?string lang_pack_version:flags.2?int base_lang_pack_version:flags.2?int reactions_default:flags.15?Reaction autologin_token:flags.16?string = Config;
nearestDc#8e1a1775 country:string this_dc:int nearest_dc:int = NearestDc;
help.appUpdate#ccbbce30 flags:# can_not_skip:flags.0?true id:int version:string text:string entities:Vector<MessageEntity> document:flags.1?Document url:flags.2?string sticker:flags.3?Document = help.AppUpdate;
help.noAppUpdate#c45a6536 = help.AppUpdate;
help.inviteText#18cb9f78 message:string = help.InviteText;
encryptedChatEmpty#ab7ec0a0 id:int = EncryptedChat;
encryptedChatWaiting#66b25953 id:int access_hash:long date:int admin_id:long participant_id:long = EncryptedChat;
encryptedChatRequested#48f1d94c flags:# folder_id:flags.0?int id:int access_hash:long date:int admin_id:long participant_id:long g_a:bytes = EncryptedChat;
encryptedChat#61f0d4c7 id:int access_hash:long date:int admin_id:long participant_id:long g_a_or_b:bytes key_fingerprint:long = EncryptedChat;
encryptedChatDiscarded#1e1c7c45 flags:# history_deleted:flags.0?true id:int = EncryptedChat;
inputEncryptedChat#f141b5e1 chat_id:int access_hash:long = InputEncryptedChat;
encryptedFileEmpty#c21f497e = EncryptedFile;
encryptedFile#a8008cd8 id:long access_hash:long size:long dc_id:int key_fingerprint:int = EncryptedFile;
inputEncryptedFileEmpty#1837c364 = InputEncryptedFile;
inputEncryptedFileUploaded#64bd0306 id:long parts:int md5_checksum:string key_fingerprint:int = InputEncryptedFile;
inputEncryptedFile#5a17b5e5 id:long access_hash:long = InputEncryptedFile;
inputEncryptedFileBigUploaded#2dc173c8 id:long parts:int key_fingerprint:int = InputEncryptedFile;
encryptedMessage#ed18c118 random_id:long chat_id:int date:int bytes:bytes file:EncryptedFile = EncryptedMessage;
encryptedMessageService#23734b06 random_id:long chat_id:int date:int bytes:bytes = EncryptedMessage;
messages.dhConfigNotModified#c0e24635 random:bytes = messages.DhConfig;
messages.dhConfig#2c221edd g:int p:bytes version:int random:bytes = messages.DhConfig;
messages.sentEncryptedMessage#560f8935 date:int = messages.SentEncryptedMessage;
messages.sentEncryptedFile#9493ff32 date:int file:EncryptedFile = messages.SentEncryptedMessage;
inputDocumentEmpty#72f0eaae = InputDocument;
inputDocument#1abfb575 id:long access_hash:long file_reference:bytes = InputDocument;
documentEmpty#36f8c871 id:long = Document;
document#8fd4c4d8 flags:# id:long access_hash:long file_reference:bytes date:int mime_type:string size:long thumbs:flags.0?Vector<PhotoSize> video_thumbs:flags.1?Vector<VideoSize> dc_id:int attributes:Vector<DocumentAttribute> = Document;
help.support#17c6b5f6 phone_number:string user:User = help.Support;
notifyPeer#9fd40bd8 peer:Peer = NotifyPeer;
notifyUsers#b4c83b4c = NotifyPeer;
notifyChats#c007cec3 = NotifyPeer;
notifyBroadcasts#d612e8ef = NotifyPeer;
notifyForumTopic#226e6308 peer:Peer top_msg_id:int = NotifyPeer;
sendMessageTypingAction#16bf744e = SendMessageAction;
sendMessageCancelAction#fd5ec8f5 = SendMessageAction;
sendMessageRecordVideoAction#a187d66f = SendMessageAction;
sendMessageUploadVideoAction#e9763aec progress:int = SendMessageAction;
sendMessageRecordAudioAction#d52f73f7 = SendMessageAction;
sendMessageUploadAudioAction#f351d7ab progress:int = SendMessageAction;
sendMessageUploadPhotoAction#d1d34a26 progress:int = SendMessageAction;
sendMessageUploadDocumentAction#aa0cd9e4 progress:int = SendMessageAction;
sendMessageGeoLocationAction#176f8ba1 = SendMessageAction;
sendMessageChooseContactAction#628cbc6f = SendMessageAction;
sendMessageGamePlayAction#dd6a8f48 = SendMessageAction;
sendMessageRecordRoundAction#88f27fbc = SendMessageAction;
sendMessageUploadRoundAction#243e1c66 progress:int = SendMessageAction;
speakingInGroupCallAction#d92c2285 = SendMessageAction;
sendMessageHistoryImportAction#dbda9246 progress:int = SendMessageAction;
sendMessageChooseStickerAction#b05ac6b1 = SendMessageAction;
sendMessageEmojiInteraction#25972bcb emoticon:string msg_id:int interaction:DataJSON = SendMessageAction;
sendMessageEmojiInteractionSeen#b665902e emoticon:string = SendMessageAction;
contacts.found#b3134d9d my_results:Vector<Peer> results:Vector<Peer> chats:Vector<Chat> users:Vector<User> = contacts.Found;
inputPrivacyKeyStatusTimestamp#4f96cb18 = InputPrivacyKey;
inputPrivacyKeyChatInvite#bdfb0426 = InputPrivacyKey;
inputPrivacyKeyPhoneCall#fabadc5f = InputPrivacyKey;
inputPrivacyKeyPhoneP2P#db9e70d2 = InputPrivacyKey;
inputPrivacyKeyForwards#a4dd4c08 = InputPrivacyKey;
inputPrivacyKeyProfilePhoto#5719bacc = InputPrivacyKey;
inputPrivacyKeyPhoneNumber#352dafa = InputPrivacyKey;
inputPrivacyKeyAddedByPhone#d1219bdd = InputPrivacyKey;
inputPrivacyKeyVoiceMessages#aee69d68 = InputPrivacyKey;
inputPrivacyKeyAbout#3823cc40 = InputPrivacyKey;
inputPrivacyKeyBirthday#d65a11cc = InputPrivacyKey;
inputPrivacyKeyStarGiftsAutoSave#e1732341 = InputPrivacyKey;
privacyKeyStatusTimestamp#bc2eab30 = PrivacyKey;
privacyKeyChatInvite#500e6dfa = PrivacyKey;
privacyKeyPhoneCall#3d662b7b = PrivacyKey;
privacyKeyPhoneP2P#39491cc8 = PrivacyKey;
privacyKeyForwards#69ec56a3 = PrivacyKey;
privacyKeyProfilePhoto#96151fed = PrivacyKey;
privacyKeyPhoneNumber#d19ae46d = PrivacyKey;
privacyKeyAddedByPhone#42ffd42b = PrivacyKey;
privacyKeyVoiceMessages#697f414 = PrivacyKey;
privacyKeyAbout#a486b761 = PrivacyKey;
privacyKeyBirthday#2000a518 = PrivacyKey;
privacyKeyStarGiftsAutoSave#2ca4fdf8 = PrivacyKey;
inputPrivacyValueAllowContacts#d09e07b = InputPrivacyRule;
inputPrivacyValueAllowAll#184b35ce = InputPrivacyRule;
inputPrivacyValueAllowUsers#131cc67f users:Vector<InputUser> = InputPrivacyRule;
inputPrivacyValueDisallowContacts#ba52007 = InputPrivacyRule;
inputPrivacyValueDisallowAll#d66b66c9 = InputPrivacyRule;
inputPrivacyValueDisallowUsers#90110467 users:Vector<InputUser> = InputPrivacyRule;
inputPrivacyValueAllowChatParticipants#840649cf chats:Vector<long> = InputPrivacyRule;
inputPrivacyValueDisallowChatParticipants#e94f0f86 chats:Vector<long> = InputPrivacyRule;
inputPrivacyValueAllowCloseFriends#2f453e49 = InputPrivacyRule;
inputPrivacyValueAllowPremium#77cdc9f1 = InputPrivacyRule;
inputPrivacyValueAllowBots#5a4fcce5 = InputPrivacyRule;
inputPrivacyValueDisallowBots#c4e57915 = InputPrivacyRule;
privacyValueAllowContacts#fffe1bac = PrivacyRule;
privacyValueAllowAll#65427b82 = PrivacyRule;
privacyValueAllowUsers#b8905fb2 users:Vector<long> = PrivacyRule;
privacyValueDisallowContacts#f888fa1a = PrivacyRule;
privacyValueDisallowAll#8b73e763 = PrivacyRule;
privacyValueDisallowUsers#e4621141 users:Vector<long> = PrivacyRule;
privacyValueAllowChatParticipants#6b134e8e chats:Vector<long> = PrivacyRule;
privacyValueDisallowChatParticipants#41c87565 chats:Vector<long> = PrivacyRule;
privacyValueAllowCloseFriends#f7e8d89b = PrivacyRule;
privacyValueAllowPremium#ece9814b = PrivacyRule;
privacyValueAllowBots#21461b5d = PrivacyRule;
privacyValueDisallowBots#f6a5f82f = PrivacyRule;
account.privacyRules#50a04e45 rules:Vector<PrivacyRule> chats:Vector<Chat> users:Vector<User> = account.PrivacyRules;
accountDaysTTL#b8d0afdf days:int = AccountDaysTTL;
documentAttributeImageSize#6c37c15c w:int h:int = DocumentAttribute;
documentAttributeAnimated#11b58939 = DocumentAttribute;
documentAttributeSticker#6319d612 flags:# mask:flags.1?true alt:string stickerset:InputStickerSet mask_coords:flags.0?MaskCoords = DocumentAttribute;
documentAttributeVideo#43c57c48 flags:# round_message:flags.0?true supports_streaming:flags.1?true nosound:flags.3?true duration:double w:int h:int preload_prefix_size:flags.2?int video_start_ts:flags.4?double video_codec:flags.5?string = DocumentAttribute;
documentAttributeAudio#9852f9c6 flags:# voice:flags.10?true duration:int title:flags.0?string performer:flags.1?string waveform:flags.2?bytes = DocumentAttribute;
documentAttributeFilename#15590068 file_name:string = DocumentAttribute;
documentAttributeHasStickers#9801d2f7 = DocumentAttribute;
documentAttributeCustomEmoji#fd149899 flags:# free:flags.0?true text_color:flags.1?true alt:string stickerset:InputStickerSet = DocumentAttribute;
messages.stickersNotModified#f1749a22 = messages.Stickers;
messages.stickers#30a6ec7e hash:long stickers:Vector<Document> = messages.Stickers;
stickerPack#12b299d4 emoticon:string documents:Vector<long> = StickerPack;
messages.allStickersNotModified#e86602c3 = messages.AllStickers;
messages.allStickers#cdbbcebb hash:long sets:Vector<StickerSet> = messages.AllStickers;
messages.affectedMessages#84d19185 pts:int pts_count:int = messages.AffectedMessages;
webPageEmpty#211a1788 flags:# id:long url:flags.0?string = WebPage;
webPagePending#b0d13e47 flags:# id:long url:flags.0?string date:int = WebPage;
webPage#e89c45b2 flags:# has_large_media:flags.13?true id:long url:string display_url:string hash:int type:flags.0?string site_name:flags.1?string title:flags.2?string description:flags.3?string photo:flags.4?Photo embed_url:flags.5?string embed_type:flags.5?string embed_width:flags.6?int embed_height:flags.6?int duration:flags.7?int author:flags.8?string document:flags.9?Document cached_page:flags.10?Page attributes:flags.12?Vector<WebPageAttribute> = WebPage;
webPageNotModified#7311ca11 flags:# cached_page_views:flags.0?int = WebPage;
authorization#ad01d61d flags:# current:flags.0?true official_app:flags.1?true password_pending:flags.2?true encrypted_requests_disabled:flags.3?true call_requests_disabled:flags.4?true unconfirmed:flags.5?true hash:long device_model:string platform:string system_version:string api_id:int app_name:string app_version:string date_created:int date_active:int ip:string country:string region:string = Authorization;
account.authorizations#4bff8ea0 authorization_ttl_days:int authorizations:Vector<Authorization> = account.Authorizations;
account.password#957b50fb flags:# has_recovery:flags.0?true has_secure_values:flags.1?true has_password:flags.2?true current_algo:flags.2?PasswordKdfAlgo srp_B:flags.2?bytes srp_id:flags.2?long hint:flags.3?string email_unconfirmed_pattern:flags.4?string new_algo:PasswordKdfAlgo new_secure_algo:SecurePasswordKdfAlgo secure_random:bytes pending_reset_date:flags.5?int login_email_pattern:flags.6?string = account.Password;
account.passwordSettings#9a5c33e5 flags:# email:flags.0?string secure_settings:flags.1?SecureSecretSettings = account.PasswordSettings;
account.passwordInputSettings#c23727c9 flags:# new_algo:flags.0?PasswordKdfAlgo new_password_hash:flags.0?bytes hint:flags.0?string email:flags.1?string new_secure_settings:flags.2?SecureSecretSettings = account.PasswordInputSettings;
auth.passwordRecovery#137948a5 email_pattern:string = auth.PasswordRecovery;
receivedNotifyMessage#a384b779 id:int flags:int = ReceivedNotifyMessage;
chatInviteExported#a22cbd96 flags:# revoked:flags.0?true permanent:flags.5?true request_needed:flags.6?true link:string admin_id:long date:int start_date:flags.4?int expire_date:flags.1?int usage_limit:flags.2?int usage:flags.3?int requested:flags.7?int subscription_expired:flags.10?int title:flags.8?string subscription_pricing:flags.9?StarsSubscriptionPricing = ExportedChatInvite;
chatInvitePublicJoinRequests#ed107ab7 = ExportedChatInvite;
chatInviteAlready#5a686d7c chat:Chat = ChatInvite;
chatInvite#5c9d3702 flags:# channel:flags.0?true broadcast:flags.1?true public:flags.2?true megagroup:flags.3?true request_needed:flags.6?true verified:flags.7?true scam:flags.8?true fake:flags.9?true can_refulfill_subscription:flags.11?true title:string about:flags.5?string photo:Photo participants_count:int participants:flags.4?Vector<User> color:int subscription_pricing:flags.10?StarsSubscriptionPricing subscription_form_id:flags.12?long bot_verification:flags.13?BotVerification = ChatInvite;
chatInvitePeek#61695cb0 chat:Chat expires:int = ChatInvite;
inputStickerSetEmpty#ffb62b95 = InputStickerSet;
inputStickerSetID#9de7a269 id:long access_hash:long = InputStickerSet;
inputStickerSetShortName#861cc8a0 short_name:string = InputStickerSet;
inputStickerSetAnimatedEmoji#28703c8 = InputStickerSet;
inputStickerSetDice#e67f520e emoticon:string = InputStickerSet;
inputStickerSetAnimatedEmojiAnimations#cde3739 = InputStickerSet;
inputStickerSetPremiumGifts#c88b3b02 = InputStickerSet;
inputStickerSetEmojiGenericAnimations#4c4d4ce = InputStickerSet;
inputStickerSetEmojiDefaultStatuses#29d0f5ee = InputStickerSet;
inputStickerSetEmojiDefaultTopicIcons#44c1f8e9 = InputStickerSet;
inputStickerSetEmojiChannelDefaultStatuses#49748553 = InputStickerSet;
stickerSet#2dd14edc flags:# archived:flags.1?true official:flags.2?true masks:flags.3?true emojis:flags.7?true text_color:flags.9?true channel_emoji_status:flags.10?true creator:flags.11?true installed_date:flags.0?int id:long access_hash:long title:string short_name:string thumbs:flags.4?Vector<PhotoSize> thumb_dc_id:flags.4?int thumb_version:flags.4?int thumb_document_id:flags.8?long count:int hash:int = StickerSet;
messages.stickerSet#6e153f16 set:StickerSet packs:Vector<StickerPack> keywords:Vector<StickerKeyword> documents:Vector<Document> = messages.StickerSet;
messages.stickerSetNotModified#d3f924eb = messages.StickerSet;
botCommand#c27ac8c7 command:string description:string = BotCommand;
botInfo#4d8a0299 flags:# has_preview_medias:flags.6?true user_id:flags.0?long description:flags.1?string description_photo:flags.4?Photo description_document:flags.5?Document commands:flags.2?Vector<BotCommand> menu_button:flags.3?BotMenuButton privacy_policy_url:flags.7?string app_settings:flags.8?BotAppSettings verifier_settings:flags.9?BotVerifierSettings = BotInfo;
keyboardButton#a2fa4880 text:string = KeyboardButton;
keyboardButtonUrl#258aff05 text:string url:string = KeyboardButton;
keyboardButtonCallback#35bbdb6b flags:# requires_password:flags.0?true text:string data:bytes = KeyboardButton;
keyboardButtonRequestPhone#b16a6c29 text:string = KeyboardButton;
keyboardButtonRequestGeoLocation#fc796b3f text:string = KeyboardButton;
keyboardButtonSwitchInline#93b9fbb5 flags:# same_peer:flags.0?true text:string query:string peer_types:flags.1?Vector<InlineQueryPeerType> = KeyboardButton;
keyboardButtonGame#50f41ccf text:string = KeyboardButton;
keyboardButtonBuy#afd93fbb text:string = KeyboardButton;
keyboardButtonUrlAuth#10b78d29 flags:# text:string fwd_text:flags.0?string url:string button_id:int = KeyboardButton;
inputKeyboardButtonUrlAuth#d02e7fd4 flags:# request_write_access:flags.0?true text:string fwd_text:flags.1?string url:string bot:InputUser = KeyboardButton;
keyboardButtonRequestPoll#bbc7515d flags:# quiz:flags.0?Bool text:string = KeyboardButton;
inputKeyboardButtonUserProfile#e988037b text:string user_id:InputUser = KeyboardButton;
keyboardButtonUserProfile#308660c1 text:string user_id:long = KeyboardButton;
keyboardButtonWebView#13767230 text:string url:string = KeyboardButton;
keyboardButtonSimpleWebView#a0c0505c text:string url:string = KeyboardButton;
keyboardButtonRequestPeer#53d7bfd8 text:string button_id:int peer_type:RequestPeerType max_quantity:int = KeyboardButton;
inputKeyboardButtonRequestPeer#c9662d05 flags:# name_requested:flags.0?true username_requested:flags.1?true photo_requested:flags.2?true text:string button_id:int peer_type:RequestPeerType max_quantity:int = KeyboardButton;
keyboardButtonCopy#75d2698e text:string copy_text:string = KeyboardButton;
keyboardButtonRow#77608b83 buttons:Vector<KeyboardButton> = KeyboardButtonRow;
replyKeyboardHide#a03e5b85 flags:# selective:flags.2?true = ReplyMarkup;
replyKeyboardForceReply#86b40b08 flags:# single_use:flags.1?true selective:flags.2?true placeholder:flags.3?string = ReplyMarkup;
replyKeyboardMarkup#85dd99d1 flags:# resize:flags.0?true single_use:flags.1?true selective:flags.2?true persistent:flags.4?true rows:Vector<KeyboardButtonRow> placeholder:flags.3?string = ReplyMarkup;
replyInlineMarkup#48a30254 rows:Vector<KeyboardButtonRow> = ReplyMarkup;
messageEntityUnknown#bb92ba95 offset:int length:int = MessageEntity;
messageEntityMention#fa04579d offset:int length:int = MessageEntity;
messageEntityHashtag#6f635b0d offset:int length:int = MessageEntity;
messageEntityBotCommand#6cef8ac7 offset:int length:int = MessageEntity;
messageEntityUrl#6ed02538 offset:int length:int = MessageEntity;
messageEntityEmail#64e475c2 offset:int length:int = MessageEntity;
messageEntityBold#bd610bc9 offset:int length:int = MessageEntity;
messageEntityItalic#826f8b60 offset:int length:int = MessageEntity;
messageEntityCode#28a20571 offset:int length:int = MessageEntity;
messageEntityPre#73924be0 offset:int length:int language:string = MessageEntity;
messageEntityTextUrl#76a6d327 offset:int length:int url:string = MessageEntity;
messageEntityMentionName#dc7b1140 offset:int length:int user_id:long = MessageEntity;
inputMessageEntityMentionName#208e68c9 offset:int length:int user_id:InputUser = MessageEntity;
messageEntityPhone#9b69e34b offset:int length:int = MessageEntity;
messageEntityCashtag#4c4e743f offset:int length:int = MessageEntity;
messageEntityUnderline#9c4e7e8b offset:int length:int = MessageEntity;
messageEntityStrike#bf0693d4 offset:int length:int = MessageEntity;
messageEntityBankCard#761e6af4 offset:int length:int = MessageEntity;
messageEntitySpoiler#32ca960f offset:int length:int = MessageEntity;
messageEntityCustomEmoji#c8cf05f8 offset:int length:int document_id:long = MessageEntity;
messageEntityBlockquote#f1ccaaac flags:# collapsed:flags.0?true offset:int length:int = MessageEntity;
inputChannelEmpty#ee8c1e86 = InputChannel;
inputChannel#f35aec28 channel_id:long access_hash:long = InputChannel;
inputChannelFromMessage#5b934f9d peer:InputPeer msg_id:int channel_id:long = InputChannel;
contacts.resolvedPeer#7f077ad9 peer:Peer chats:Vector<Chat> users:Vector<User> = contacts.ResolvedPeer;
messageRange#ae30253 min_id:int max_id:int = MessageRange;
updates.channelDifferenceEmpty#3e11affb flags:# final:flags.0?true pts:int timeout:flags.1?int = updates.ChannelDifference;
updates.channelDifferenceTooLong#a4bcc6fe flags:# final:flags.0?true timeout:flags.1?int dialog:Dialog messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = updates.ChannelDifference;
updates.channelDifference#2064674e flags:# final:flags.0?true pts:int timeout:flags.1?int new_messages:Vector<Message> other_updates:Vector<Update> chats:Vector<Chat> users:Vector<User> = updates.ChannelDifference;
channelMessagesFilterEmpty#94d42ee7 = ChannelMessagesFilter;
channelMessagesFilter#cd77d957 flags:# exclude_new_messages:flags.1?true ranges:Vector<MessageRange> = ChannelMessagesFilter;
channelParticipant#cb397619 flags:# user_id:long date:int subscription_until_date:flags.0?int = ChannelParticipant;
channelParticipantSelf#4f607bef flags:# via_request:flags.0?true user_id:long inviter_id:long date:int subscription_until_date:flags.1?int = ChannelParticipant;
channelParticipantCreator#2fe601d3 flags:# user_id:long admin_rights:ChatAdminRights rank:flags.0?string = ChannelParticipant;
channelParticipantAdmin#34c3bb53 flags:# can_edit:flags.0?true self:flags.1?true user_id:long inviter_id:flags.1?long promoted_by:long date:int admin_rights:ChatAdminRights rank:flags.2?string = ChannelParticipant;
channelParticipantBanned#6df8014e flags:# left:flags.0?true peer:Peer kicked_by:long date:int banned_rights:ChatBannedRights = ChannelParticipant;
channelParticipantLeft#1b03f006 peer:Peer = ChannelParticipant;
channelParticipantsRecent#de3f3c79 = ChannelParticipantsFilter;
channelParticipantsAdmins#b4608969 = ChannelParticipantsFilter;
channelParticipantsKicked#a3b54985 q:string = ChannelParticipantsFilter;
channelParticipantsBots#b0d1865b = ChannelParticipantsFilter;
channelParticipantsBanned#1427a5e1 q:string = ChannelParticipantsFilter;
channelParticipantsSearch#656ac4b q:string = ChannelParticipantsFilter;
channelParticipantsContacts#bb6ae88d q:string = ChannelParticipantsFilter;
channelParticipantsMentions#e04b5ceb flags:# q:flags.0?string top_msg_id:flags.1?int = ChannelParticipantsFilter;
channels.channelParticipants#9ab0feaf count:int participants:Vector<ChannelParticipant> chats:Vector<Chat> users:Vector<User> = channels.ChannelParticipants;
channels.channelParticipantsNotModified#f0173fe9 = channels.ChannelParticipants;
channels.channelParticipant#dfb80317 participant:ChannelParticipant chats:Vector<Chat> users:Vector<User> = channels.ChannelParticipant;
help.termsOfService#780a0310 flags:# popup:flags.0?true id:DataJSON text:string entities:Vector<MessageEntity> min_age_confirm:flags.1?int = help.TermsOfService;
messages.savedGifsNotModified#e8025ca2 = messages.SavedGifs;
messages.savedGifs#84a02a0d hash:long gifs:Vector<Document> = messages.SavedGifs;
inputBotInlineMessageMediaAuto#3380c786 flags:# invert_media:flags.3?true message:string entities:flags.1?Vector<MessageEntity> reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageText#3dcd7a87 flags:# no_webpage:flags.0?true invert_media:flags.3?true message:string entities:flags.1?Vector<MessageEntity> reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageMediaGeo#96929a85 flags:# geo_point:InputGeoPoint heading:flags.0?int period:flags.1?int proximity_notification_radius:flags.3?int reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageMediaVenue#417bbf11 flags:# geo_point:InputGeoPoint title:string address:string provider:string venue_id:string venue_type:string reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageMediaContact#a6edbffd flags:# phone_number:string first_name:string last_name:string vcard:string reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageGame#4b425864 flags:# reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageMediaInvoice#d7e78225 flags:# title:string description:string photo:flags.0?InputWebDocument invoice:Invoice payload:bytes provider:string provider_data:DataJSON reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineMessageMediaWebPage#bddcc510 flags:# invert_media:flags.3?true force_large_media:flags.4?true force_small_media:flags.5?true optional:flags.6?true message:string entities:flags.1?Vector<MessageEntity> url:string reply_markup:flags.2?ReplyMarkup = InputBotInlineMessage;
inputBotInlineResult#88bf9319 flags:# id:string type:string title:flags.1?string description:flags.2?string url:flags.3?string thumb:flags.4?InputWebDocument content:flags.5?InputWebDocument send_message:InputBotInlineMessage = InputBotInlineResult;
inputBotInlineResultPhoto#a8d864a7 id:string type:string photo:InputPhoto send_message:InputBotInlineMessage = InputBotInlineResult;
inputBotInlineResultDocument#fff8fdc4 flags:# id:string type:string title:flags.1?string description:flags.2?string document:InputDocument send_message:InputBotInlineMessage = InputBotInlineResult;
inputBotInlineResultGame#4fa417f2 id:string short_name:string send_message:InputBotInlineMessage = InputBotInlineResult;
botInlineMessageMediaAuto#764cf810 flags:# invert_media:flags.3?true message:string entities:flags.1?Vector<MessageEntity> reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageText#8c7f65e2 flags:# no_webpage:flags.0?true invert_media:flags.3?true message:string entities:flags.1?Vector<MessageEntity> reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageMediaGeo#51846fd flags:# geo:GeoPoint heading:flags.0?int period:flags.1?int proximity_notification_radius:flags.3?int reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageMediaVenue#8a86659c flags:# geo:GeoPoint title:string address:string provider:string venue_id:string venue_type:string reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageMediaContact#18d1cdc2 flags:# phone_number:string first_name:string last_name:string vcard:string reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageMediaInvoice#354a9b09 flags:# shipping_address_requested:flags.1?true test:flags.3?true title:string description:string photo:flags.0?WebDocument currency:string total_amount:long reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineMessageMediaWebPage#809ad9a6 flags:# invert_media:flags.3?true force_large_media:flags.4?true force_small_media:flags.5?true manual:flags.7?true safe:flags.8?true message:string entities:flags.1?Vector<MessageEntity> url:string reply_markup:flags.2?ReplyMarkup = BotInlineMessage;
botInlineResult#11965f3a flags:# id:string type:string title:flags.1?string description:flags.2?string url:flags.3?string thumb:flags.4?WebDocument content:flags.5?WebDocument send_message:BotInlineMessage = BotInlineResult;
botInlineMediaResult#17db940b flags:# id:string type:string photo:flags.0?Photo document:flags.1?Document title:flags.2?string description:flags.3?string send_message:BotInlineMessage = BotInlineResult;
messages.botResults#e021f2f6 flags:# gallery:flags.0?true query_id:long next_offset:flags.1?string switch_pm:flags.2?InlineBotSwitchPM switch_webview:flags.3?InlineBotWebView results:Vector<BotInlineResult> cache_time:int users:Vector<User> = messages.BotResults;
exportedMessageLink#5dab1af4 link:string html:string = ExportedMessageLink;
messageFwdHeader#4e4df4bb flags:# imported:flags.7?true saved_out:flags.11?true from_id:flags.0?Peer from_name:flags.5?string date:int channel_post:flags.2?int post_author:flags.3?string saved_from_peer:flags.4?Peer saved_from_msg_id:flags.4?int saved_from_id:flags.8?Peer saved_from_name:flags.9?string saved_date:flags.10?int psa_type:flags.6?string = MessageFwdHeader;
auth.codeTypeSms#72a3158c = auth.CodeType;
auth.codeTypeCall#741cd3e3 = auth.CodeType;
auth.codeTypeFlashCall#226ccefb = auth.CodeType;
auth.codeTypeMissedCall#d61ad6ee = auth.CodeType;
auth.codeTypeFragmentSms#6ed998c = auth.CodeType;
auth.sentCodeTypeApp#3dbb5986 length:int = auth.SentCodeType;
auth.sentCodeTypeSms#c000bba2 length:int = auth.SentCodeType;
auth.sentCodeTypeCall#5353e5a7 length:int = auth.SentCodeType;
auth.sentCodeTypeFlashCall#ab03c6d9 pattern:string = auth.SentCodeType;
auth.sentCodeTypeMissedCall#82006484 prefix:string length:int = auth.SentCodeType;
auth.sentCodeTypeEmailCode#f450f59b flags:# apple_signin_allowed:flags.0?true google_signin_allowed:flags.1?true email_pattern:string length:int reset_available_period:flags.3?int reset_pending_date:flags.4?int = auth.SentCodeType;
auth.sentCodeTypeSetUpEmailRequired#a5491dea flags:# apple_signin_allowed:flags.0?true google_signin_allowed:flags.1?true = auth.SentCodeType;
auth.sentCodeTypeFragmentSms#d9565c39 url:string length:int = auth.SentCodeType;
auth.sentCodeTypeFirebaseSms#9fd736 flags:# nonce:flags.0?bytes play_integrity_project_id:flags.2?long play_integrity_nonce:flags.2?bytes receipt:flags.1?string push_timeout:flags.1?int length:int = auth.SentCodeType;
auth.sentCodeTypeSmsWord#a416ac81 flags:# beginning:flags.0?string = auth.SentCodeType;
auth.sentCodeTypeSmsPhrase#b37794af flags:# beginning:flags.0?string = auth.SentCodeType;
messages.botCallbackAnswer#36585ea4 flags:# alert:flags.1?true has_url:flags.3?true native_ui:flags.4?true message:flags.0?string url:flags.2?string cache_time:int = messages.BotCallbackAnswer;
messages.messageEditData#26b5dde6 flags:# caption:flags.0?true = messages.MessageEditData;
inputBotInlineMessageID#890c3d89 dc_id:int id:long access_hash:long = InputBotInlineMessageID;
inputBotInlineMessageID64#b6d915d7 dc_id:int owner_id:long id:int access_hash:long = InputBotInlineMessageID;
inlineBotSwitchPM#3c20629f text:string start_param:string = InlineBotSwitchPM;
messages.peerDialogs#3371c354 dialogs:Vector<Dialog> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> state:updates.State = messages.PeerDialogs;
topPeer#edcdc05b peer:Peer rating:double = TopPeer;
topPeerCategoryBotsPM#ab661b5b = TopPeerCategory;
topPeerCategoryBotsInline#148677e2 = TopPeerCategory;
topPeerCategoryCorrespondents#637b7ed = TopPeerCategory;
topPeerCategoryGroups#bd17a14a = TopPeerCategory;
topPeerCategoryChannels#161d9628 = TopPeerCategory;
topPeerCategoryPhoneCalls#1e76a78c = TopPeerCategory;
topPeerCategoryForwardUsers#a8406ca9 = TopPeerCategory;
topPeerCategoryForwardChats#fbeec0f0 = TopPeerCategory;
topPeerCategoryBotsApp#fd9e7bec = TopPeerCategory;
topPeerCategoryPeers#fb834291 category:TopPeerCategory count:int peers:Vector<TopPeer> = TopPeerCategoryPeers;
contacts.topPeersNotModified#de266ef5 = contacts.TopPeers;
contacts.topPeers#70b772a8 categories:Vector<TopPeerCategoryPeers> chats:Vector<Chat> users:Vector<User> = contacts.TopPeers;
contacts.topPeersDisabled#b52c939d = contacts.TopPeers;
draftMessageEmpty#1b0c841a flags:# date:flags.0?int = DraftMessage;
draftMessage#2d65321f flags:# no_webpage:flags.1?true invert_media:flags.6?true reply_to:flags.4?InputReplyTo message:string entities:flags.3?Vector<MessageEntity> media:flags.5?InputMedia date:int effect:flags.7?long = DraftMessage;
messages.featuredStickersNotModified#c6dc0c66 count:int = messages.FeaturedStickers;
messages.featuredStickers#be382906 flags:# premium:flags.0?true hash:long count:int sets:Vector<StickerSetCovered> unread:Vector<long> = messages.FeaturedStickers;
messages.recentStickersNotModified#b17f890 = messages.RecentStickers;
messages.recentStickers#88d37c56 hash:long packs:Vector<StickerPack> stickers:Vector<Document> dates:Vector<int> = messages.RecentStickers;
messages.archivedStickers#4fcba9c8 count:int sets:Vector<StickerSetCovered> = messages.ArchivedStickers;
messages.stickerSetInstallResultSuccess#38641628 = messages.StickerSetInstallResult;
messages.stickerSetInstallResultArchive#35e410a8 sets:Vector<StickerSetCovered> = messages.StickerSetInstallResult;
stickerSetCovered#6410a5d2 set:StickerSet cover:Document = StickerSetCovered;
stickerSetMultiCovered#3407e51b set:StickerSet covers:Vector<Document> = StickerSetCovered;
stickerSetFullCovered#40d13c0e set:StickerSet packs:Vector<StickerPack> keywords:Vector<StickerKeyword> documents:Vector<Document> = StickerSetCovered;
stickerSetNoCovered#77b15d1c set:StickerSet = StickerSetCovered;
maskCoords#aed6dbb2 n:int x:double y:double zoom:double = MaskCoords;
inputStickeredMediaPhoto#4a992157 id:InputPhoto = InputStickeredMedia;
inputStickeredMediaDocument#438865b id:InputDocument = InputStickeredMedia;
game#bdf9653b flags:# id:long access_hash:long short_name:string title:string description:string photo:Photo document:flags.0?Document = Game;
inputGameID#32c3e77 id:long access_hash:long = InputGame;
inputGameShortName#c331e80a bot_id:InputUser short_name:string = InputGame;
highScore#73a379eb pos:int user_id:long score:int = HighScore;
messages.highScores#9a3bfd99 scores:Vector<HighScore> users:Vector<User> = messages.HighScores;
textEmpty#dc3d824f = RichText;
textPlain#744694e0 text:string = RichText;
textBold#6724abc4 text:RichText = RichText;
textItalic#d912a59c text:RichText = RichText;
textUnderline#c12622c4 text:RichText = RichText;
textStrike#9bf8bb95 text:RichText = RichText;
textFixed#6c3f19b9 text:RichText = RichText;
textUrl#3c2884c1 text:RichText url:string webpage_id:long = RichText;
textEmail#de5a0dd6 text:RichText email:string = RichText;
textConcat#7e6260d7 texts:Vector<RichText> = RichText;
textSubscript#ed6a8504 text:RichText = RichText;
textSuperscript#c7fb5e01 text:RichText = RichText;
textMarked#34b8621 text:RichText = RichText;
textPhone#1ccb966a text:RichText phone:string = RichText;
textImage#81ccf4f document_id:long w:int h:int = RichText;
textAnchor#35553762 text:RichText name:string = RichText;
pageBlockUnsupported#13567e8a = PageBlock;
pageBlockTitle#70abc3fd text:RichText = PageBlock;
pageBlockSubtitle#8ffa9a1f text:RichText = PageBlock;
pageBlockAuthorDate#baafe5e0 author:RichText published_date:int = PageBlock;
pageBlockHeader#bfd064ec text:RichText = PageBlock;
pageBlockSubheader#f12bb6e1 text:RichText = PageBlock;
pageBlockParagraph#467a0766 text:RichText = PageBlock;
pageBlockPreformatted#c070d93e text:RichText language:string = PageBlock;
pageBlockFooter#48870999 text:RichText = PageBlock;
pageBlockDivider#db20b188 = PageBlock;
pageBlockAnchor#ce0d37b0 name:string = PageBlock;
pageBlockList#e4e88011 items:Vector<PageListItem> = PageBlock;
pageBlockBlockquote#263d7c26 text:RichText caption:RichText = PageBlock;
pageBlockPullquote#4f4456d3 text:RichText caption:RichText = PageBlock;
pageBlockPhoto#1759c560 flags:# photo_id:long caption:PageCaption url:flags.0?string webpage_id:flags.0?long = PageBlock;
pageBlockVideo#7c8fe7b6 flags:# autoplay:flags.0?true loop:flags.1?true video_id:long caption:PageCaption = PageBlock;
pageBlockCover#39f23300 cover:PageBlock = PageBlock;
pageBlockEmbed#a8718dc5 flags:# full_width:flags.0?true allow_scrolling:flags.3?true url:flags.1?string html:flags.2?string poster_photo_id:flags.4?long w:flags.5?int h:flags.5?int caption:PageCaption = PageBlock;
pageBlockEmbedPost#f259a80b url:string webpage_id:long author_photo_id:long author:string date:int blocks:Vector<PageBlock> caption:PageCaption = PageBlock;
pageBlockCollage#65a0fa4d items:Vector<PageBlock> caption:PageCaption = PageBlock;
pageBlockSlideshow#31f9590 items:Vector<PageBlock> caption:PageCaption = PageBlock;
pageBlockChannel#ef1751b5 channel:Chat = PageBlock;
pageBlockAudio#804361ea audio_id:long caption:PageCaption = PageBlock;
pageBlockKicker#1e148390 text:RichText = PageBlock;
pageBlockTable#bf4dea82 flags:# bordered:flags.0?true striped:flags.1?true title:RichText rows:Vector<PageTableRow> = PageBlock;
pageBlockOrderedList#9a8ae1e1 items:Vector<PageListOrderedItem> = PageBlock;
pageBlockDetails#76768bed flags:# open:flags.0?true blocks:Vector<PageBlock> title:RichText = PageBlock;
pageBlockRelatedArticles#16115a96 title:RichText articles:Vector<PageRelatedArticle> = PageBlock;
pageBlockMap#a44f3ef6 geo:GeoPoint zoom:int w:int h:int caption:PageCaption = PageBlock;
phoneCallDiscardReasonMissed#85e42301 = PhoneCallDiscardReason;
phoneCallDiscardReasonDisconnect#e095c1a0 = PhoneCallDiscardReason;
phoneCallDiscardReasonHangup#57adc690 = PhoneCallDiscardReason;
phoneCallDiscardReasonBusy#faf7e8c9 = PhoneCallDiscardReason;
phoneCallDiscardReasonAllowGroupCall#afe2b839 encrypted_key:bytes = PhoneCallDiscardReason;
dataJSON#7d748d04 data:string = DataJSON;
labeledPrice#cb296bf8 label:string amount:long = LabeledPrice;
invoice#49ee584 flags:# test:flags.0?true name_requested:flags.1?true phone_requested:flags.2?true email_requested:flags.3?true shipping_address_requested:flags.4?true flexible:flags.5?true phone_to_provider:flags.6?true email_to_provider:flags.7?true recurring:flags.9?true currency:string prices:Vector<LabeledPrice> max_tip_amount:flags.8?long suggested_tip_amounts:flags.8?Vector<long> terms_url:flags.10?string subscription_period:flags.11?int = Invoice;
paymentCharge#ea02c27e id:string provider_charge_id:string = PaymentCharge;
postAddress#1e8caaeb street_line1:string street_line2:string city:string state:string country_iso2:string post_code:string = PostAddress;
paymentRequestedInfo#909c3f94 flags:# name:flags.0?string phone:flags.1?string email:flags.2?string shipping_address:flags.3?PostAddress = PaymentRequestedInfo;
paymentSavedCredentialsCard#cdc27a1f id:string title:string = PaymentSavedCredentials;
webDocument#1c570ed1 url:string access_hash:long size:int mime_type:string attributes:Vector<DocumentAttribute> = WebDocument;
webDocumentNoProxy#f9c8bcc6 url:string size:int mime_type:string attributes:Vector<DocumentAttribute> = WebDocument;
inputWebDocument#9bed434d url:string size:int mime_type:string attributes:Vector<DocumentAttribute> = InputWebDocument;
inputWebFileLocation#c239d686 url:string access_hash:long = InputWebFileLocation;
inputWebFileGeoPointLocation#9f2221c9 geo_point:InputGeoPoint access_hash:long w:int h:int zoom:int scale:int = InputWebFileLocation;
inputWebFileAudioAlbumThumbLocation#f46fe924 flags:# small:flags.2?true document:flags.0?InputDocument title:flags.1?string performer:flags.1?string = InputWebFileLocation;
upload.webFile#21e753bc size:int mime_type:string file_type:storage.FileType mtime:int bytes:bytes = upload.WebFile;
payments.paymentForm#a0058751 flags:# can_save_credentials:flags.2?true password_missing:flags.3?true form_id:long bot_id:long title:string description:string photo:flags.5?WebDocument invoice:Invoice provider_id:long url:string native_provider:flags.4?string native_params:flags.4?DataJSON additional_methods:flags.6?Vector<PaymentFormMethod> saved_info:flags.0?PaymentRequestedInfo saved_credentials:flags.1?Vector<PaymentSavedCredentials> users:Vector<User> = payments.PaymentForm;
payments.paymentFormStars#7bf6b15c flags:# form_id:long bot_id:long title:string description:string photo:flags.5?WebDocument invoice:Invoice users:Vector<User> = payments.PaymentForm;
payments.paymentFormStarGift#b425cfe1 form_id:long invoice:Invoice = payments.PaymentForm;
payments.validatedRequestedInfo#d1451883 flags:# id:flags.0?string shipping_options:flags.1?Vector<ShippingOption> = payments.ValidatedRequestedInfo;
payments.paymentResult#4e5f810d updates:Updates = payments.PaymentResult;
payments.paymentVerificationNeeded#d8411139 url:string = payments.PaymentResult;
payments.paymentReceipt#70c4fe03 flags:# date:int bot_id:long provider_id:long title:string description:string photo:flags.2?WebDocument invoice:Invoice info:flags.0?PaymentRequestedInfo shipping:flags.1?ShippingOption tip_amount:flags.3?long currency:string total_amount:long credentials_title:string users:Vector<User> = payments.PaymentReceipt;
payments.paymentReceiptStars#dabbf83a flags:# date:int bot_id:long title:string description:string photo:flags.2?WebDocument invoice:Invoice currency:string total_amount:long transaction_id:string users:Vector<User> = payments.PaymentReceipt;
payments.savedInfo#fb8fe43c flags:# has_saved_credentials:flags.1?true saved_info:flags.0?PaymentRequestedInfo = payments.SavedInfo;
inputPaymentCredentialsSaved#c10eb2cf id:string tmp_password:bytes = InputPaymentCredentials;
inputPaymentCredentials#3417d728 flags:# save:flags.0?true data:DataJSON = InputPaymentCredentials;
inputPaymentCredentialsApplePay#aa1c39f payment_data:DataJSON = InputPaymentCredentials;
inputPaymentCredentialsGooglePay#8ac32801 payment_token:DataJSON = InputPaymentCredentials;
account.tmpPassword#db64fd34 tmp_password:bytes valid_until:int = account.TmpPassword;
shippingOption#b6213cdf id:string title:string prices:Vector<LabeledPrice> = ShippingOption;
inputStickerSetItem#32da9e9c flags:# document:InputDocument emoji:string mask_coords:flags.0?MaskCoords keywords:flags.1?string = InputStickerSetItem;
inputPhoneCall#1e36fded id:long access_hash:long = InputPhoneCall;
phoneCallEmpty#5366c915 id:long = PhoneCall;
phoneCallWaiting#eed42858 flags:# video:flags.6?true id:long access_hash:long date:int admin_id:long participant_id:long protocol:PhoneCallProtocol receive_date:flags.0?int conference_call:flags.8?InputGroupCall = PhoneCall;
phoneCallRequested#45361c63 flags:# video:flags.6?true id:long access_hash:long date:int admin_id:long participant_id:long g_a_hash:bytes protocol:PhoneCallProtocol conference_call:flags.8?InputGroupCall = PhoneCall;
phoneCallAccepted#22fd7181 flags:# video:flags.6?true id:long access_hash:long date:int admin_id:long participant_id:long g_b:bytes protocol:PhoneCallProtocol conference_call:flags.8?InputGroupCall = PhoneCall;
phoneCall#3ba5940c flags:# p2p_allowed:flags.5?true video:flags.6?true id:long access_hash:long date:int admin_id:long participant_id:long g_a_or_b:bytes key_fingerprint:long protocol:PhoneCallProtocol connections:Vector<PhoneConnection> start_date:int custom_parameters:flags.7?DataJSON conference_call:flags.8?InputGroupCall = PhoneCall;
phoneCallDiscarded#f9d25503 flags:# need_rating:flags.2?true need_debug:flags.3?true video:flags.6?true id:long reason:flags.0?PhoneCallDiscardReason duration:flags.1?int conference_call:flags.8?InputGroupCall = PhoneCall;
phoneConnection#9cc123c7 flags:# tcp:flags.0?true id:long ip:string ipv6:string port:int peer_tag:bytes = PhoneConnection;
phoneConnectionWebrtc#635fe375 flags:# turn:flags.0?true stun:flags.1?true id:long ip:string ipv6:string port:int username:string password:string = PhoneConnection;
phoneCallProtocol#fc878fc8 flags:# udp_p2p:flags.0?true udp_reflector:flags.1?true min_layer:int max_layer:int library_versions:Vector<string> = PhoneCallProtocol;
phone.phoneCall#ec82e140 phone_call:PhoneCall users:Vector<User> = phone.PhoneCall;
upload.cdnFileReuploadNeeded#eea8e46e request_token:bytes = upload.CdnFile;
upload.cdnFile#a99fca4f bytes:bytes = upload.CdnFile;
cdnPublicKey#c982eaba dc_id:int public_key:string = CdnPublicKey;
cdnConfig#5725e40a public_keys:Vector<CdnPublicKey> = CdnConfig;
langPackString#cad181f6 key:string value:string = LangPackString;
langPackStringPluralized#6c47ac9f flags:# key:string zero_value:flags.0?string one_value:flags.1?string two_value:flags.2?string few_value:flags.3?string many_value:flags.4?string other_value:string = LangPackString;
langPackStringDeleted#2979eeb2 key:string = LangPackString;
langPackDifference#f385c1f6 lang_code:string from_version:int version:int strings:Vector<LangPackString> = LangPackDifference;
langPackLanguage#eeca5ce3 flags:# official:flags.0?true rtl:flags.2?true beta:flags.3?true name:string native_name:string lang_code:string base_lang_code:flags.1?string plural_code:string strings_count:int translated_count:int translations_url:string = LangPackLanguage;
channelAdminLogEventActionChangeTitle#e6dfb825 prev_value:string new_value:string = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeAbout#55188a2e prev_value:string new_value:string = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeUsername#6a4afc38 prev_value:string new_value:string = ChannelAdminLogEventAction;
channelAdminLogEventActionChangePhoto#434bd2af prev_photo:Photo new_photo:Photo = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleInvites#1b7907ae new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleSignatures#26ae0971 new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionUpdatePinned#e9e82c18 message:Message = ChannelAdminLogEventAction;
channelAdminLogEventActionEditMessage#709b2405 prev_message:Message new_message:Message = ChannelAdminLogEventAction;
channelAdminLogEventActionDeleteMessage#42e047bb message:Message = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantJoin#183040d3 = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantLeave#f89777f2 = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantInvite#e31c34d8 participant:ChannelParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantToggleBan#e6d83d7e prev_participant:ChannelParticipant new_participant:ChannelParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantToggleAdmin#d5676710 prev_participant:ChannelParticipant new_participant:ChannelParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeStickerSet#b1c3caa7 prev_stickerset:InputStickerSet new_stickerset:InputStickerSet = ChannelAdminLogEventAction;
channelAdminLogEventActionTogglePreHistoryHidden#5f5c95f1 new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionDefaultBannedRights#2df5fc0a prev_banned_rights:ChatBannedRights new_banned_rights:ChatBannedRights = ChannelAdminLogEventAction;
channelAdminLogEventActionStopPoll#8f079643 message:Message = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeLinkedChat#50c7ac8 prev_value:long new_value:long = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeLocation#e6b76ae prev_value:ChannelLocation new_value:ChannelLocation = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleSlowMode#53909779 prev_value:int new_value:int = ChannelAdminLogEventAction;
channelAdminLogEventActionStartGroupCall#23209745 call:InputGroupCall = ChannelAdminLogEventAction;
channelAdminLogEventActionDiscardGroupCall#db9f9140 call:InputGroupCall = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantMute#f92424d2 participant:GroupCallParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantUnmute#e64429c0 participant:GroupCallParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleGroupCallSetting#56d6a247 join_muted:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantJoinByInvite#fe9fc158 flags:# via_chatlist:flags.0?true invite:ExportedChatInvite = ChannelAdminLogEventAction;
channelAdminLogEventActionExportedInviteDelete#5a50fca4 invite:ExportedChatInvite = ChannelAdminLogEventAction;
channelAdminLogEventActionExportedInviteRevoke#410a134e invite:ExportedChatInvite = ChannelAdminLogEventAction;
channelAdminLogEventActionExportedInviteEdit#e90ebb59 prev_invite:ExportedChatInvite new_invite:ExportedChatInvite = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantVolume#3e7f6847 participant:GroupCallParticipant = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeHistoryTTL#6e941a38 prev_value:int new_value:int = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantJoinByRequest#afb6144a invite:ExportedChatInvite approved_by:long = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleNoForwards#cb2ac766 new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionSendMessage#278f2868 message:Message = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeAvailableReactions#be4e0ef8 prev_value:ChatReactions new_value:ChatReactions = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeUsernames#f04fb3a9 prev_value:Vector<string> new_value:Vector<string> = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleForum#2cc6383 new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionCreateTopic#58707d28 topic:ForumTopic = ChannelAdminLogEventAction;
channelAdminLogEventActionEditTopic#f06fe208 prev_topic:ForumTopic new_topic:ForumTopic = ChannelAdminLogEventAction;
channelAdminLogEventActionDeleteTopic#ae168909 topic:ForumTopic = ChannelAdminLogEventAction;
channelAdminLogEventActionPinTopic#5d8d353b flags:# prev_topic:flags.0?ForumTopic new_topic:flags.1?ForumTopic = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleAntiSpam#64f36dfc new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionChangePeerColor#5796e780 prev_value:PeerColor new_value:PeerColor = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeProfilePeerColor#5e477b25 prev_value:PeerColor new_value:PeerColor = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeWallpaper#31bb5d52 prev_value:WallPaper new_value:WallPaper = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeEmojiStatus#3ea9feb1 prev_value:EmojiStatus new_value:EmojiStatus = ChannelAdminLogEventAction;
channelAdminLogEventActionChangeEmojiStickerSet#46d840ab prev_stickerset:InputStickerSet new_stickerset:InputStickerSet = ChannelAdminLogEventAction;
channelAdminLogEventActionToggleSignatureProfiles#60a79c79 new_value:Bool = ChannelAdminLogEventAction;
channelAdminLogEventActionParticipantSubExtend#64642db3 prev_participant:ChannelParticipant new_participant:ChannelParticipant = ChannelAdminLogEventAction;
channelAdminLogEvent#1fad68cd id:long date:int user_id:long action:ChannelAdminLogEventAction = ChannelAdminLogEvent;
channels.adminLogResults#ed8af74d events:Vector<ChannelAdminLogEvent> chats:Vector<Chat> users:Vector<User> = channels.AdminLogResults;
channelAdminLogEventsFilter#ea107ae4 flags:# join:flags.0?true leave:flags.1?true invite:flags.2?true ban:flags.3?true unban:flags.4?true kick:flags.5?true unkick:flags.6?true promote:flags.7?true demote:flags.8?true info:flags.9?true settings:flags.10?true pinned:flags.11?true edit:flags.12?true delete:flags.13?true group_call:flags.14?true invites:flags.15?true send:flags.16?true forums:flags.17?true sub_extend:flags.18?true = ChannelAdminLogEventsFilter;
popularContact#5ce14175 client_id:long importers:int = PopularContact;
messages.favedStickersNotModified#9e8fa6d3 = messages.FavedStickers;
messages.favedStickers#2cb51097 hash:long packs:Vector<StickerPack> stickers:Vector<Document> = messages.FavedStickers;
recentMeUrlUnknown#46e1d13d url:string = RecentMeUrl;
recentMeUrlUser#b92c09e2 url:string user_id:long = RecentMeUrl;
recentMeUrlChat#b2da71d2 url:string chat_id:long = RecentMeUrl;
recentMeUrlChatInvite#eb49081d url:string chat_invite:ChatInvite = RecentMeUrl;
recentMeUrlStickerSet#bc0a57dc url:string set:StickerSetCovered = RecentMeUrl;
help.recentMeUrls#e0310d7 urls:Vector<RecentMeUrl> chats:Vector<Chat> users:Vector<User> = help.RecentMeUrls;
inputSingleMedia#1cc6e91f flags:# media:InputMedia random_id:long message:string entities:flags.0?Vector<MessageEntity> = InputSingleMedia;
webAuthorization#a6f8f452 hash:long bot_id:long domain:string browser:string platform:string date_created:int date_active:int ip:string region:string = WebAuthorization;
account.webAuthorizations#ed56c9fc authorizations:Vector<WebAuthorization> users:Vector<User> = account.WebAuthorizations;
inputMessageID#a676a322 id:int = InputMessage;
inputMessageReplyTo#bad88395 id:int = InputMessage;
inputMessagePinned#86872538 = InputMessage;
inputMessageCallbackQuery#acfa1a7e id:int query_id:long = InputMessage;
inputDialogPeer#fcaafeb7 peer:InputPeer = InputDialogPeer;
inputDialogPeerFolder#64600527 folder_id:int = InputDialogPeer;
dialogPeer#e56dbf05 peer:Peer = DialogPeer;
dialogPeerFolder#514519e2 folder_id:int = DialogPeer;
messages.foundStickerSetsNotModified#d54b65d = messages.FoundStickerSets;
messages.foundStickerSets#8af09dd2 hash:long sets:Vector<StickerSetCovered> = messages.FoundStickerSets;
fileHash#f39b035c offset:long limit:int hash:bytes = FileHash;
inputClientProxy#75588b3f address:string port:int = InputClientProxy;
help.termsOfServiceUpdateEmpty#e3309f7f expires:int = help.TermsOfServiceUpdate;
help.termsOfServiceUpdate#28ecf961 expires:int terms_of_service:help.TermsOfService = help.TermsOfServiceUpdate;
inputSecureFileUploaded#3334b0f0 id:long parts:int md5_checksum:string file_hash:bytes secret:bytes = InputSecureFile;
inputSecureFile#5367e5be id:long access_hash:long = InputSecureFile;
secureFileEmpty#64199744 = SecureFile;
secureFile#7d09c27e id:long access_hash:long size:long dc_id:int date:int file_hash:bytes secret:bytes = SecureFile;
secureData#8aeabec3 data:bytes data_hash:bytes secret:bytes = SecureData;
securePlainPhone#7d6099dd phone:string = SecurePlainData;
securePlainEmail#21ec5a5f email:string = SecurePlainData;
secureValueTypePersonalDetails#9d2a81e3 = SecureValueType;
secureValueTypePassport#3dac6a00 = SecureValueType;
secureValueTypeDriverLicense#6e425c4 = SecureValueType;
secureValueTypeIdentityCard#a0d0744b = SecureValueType;
secureValueTypeInternalPassport#99a48f23 = SecureValueType;
secureValueTypeAddress#cbe31e26 = SecureValueType;
secureValueTypeUtilityBill#fc36954e = SecureValueType;
secureValueTypeBankStatement#89137c0d = SecureValueType;
secureValueTypeRentalAgreement#8b883488 = SecureValueType;
secureValueTypePassportRegistration#99e3806a = SecureValueType;
secureValueTypeTemporaryRegistration#ea02ec33 = SecureValueType;
secureValueTypePhone#b320aadb = SecureValueType;
secureValueTypeEmail#8e3ca7ee = SecureValueType;
secureValue#187fa0ca flags:# type:SecureValueType data:flags.0?SecureData front_side:flags.1?SecureFile reverse_side:flags.2?SecureFile selfie:flags.3?SecureFile translation:flags.6?Vector<SecureFile> files:flags.4?Vector<SecureFile> plain_data:flags.5?SecurePlainData hash:bytes = SecureValue;
inputSecureValue#db21d0a7 flags:# type:SecureValueType data:flags.0?SecureData front_side:flags.1?InputSecureFile reverse_side:flags.2?InputSecureFile selfie:flags.3?InputSecureFile translation:flags.6?Vector<InputSecureFile> files:flags.4?Vector<InputSecureFile> plain_data:flags.5?SecurePlainData = InputSecureValue;
secureValueHash#ed1ecdb0 type:SecureValueType hash:bytes = SecureValueHash;
secureValueErrorData#e8a40bd9 type:SecureValueType data_hash:bytes field:string text:string = SecureValueError;
secureValueErrorFrontSide#be3dfa type:SecureValueType file_hash:bytes text:string = SecureValueError;
secureValueErrorReverseSide#868a2aa5 type:SecureValueType file_hash:bytes text:string = SecureValueError;
secureValueErrorSelfie#e537ced6 type:SecureValueType file_hash:bytes text:string = SecureValueError;
secureValueErrorFile#7a700873 type:SecureValueType file_hash:bytes text:string = SecureValueError;
secureValueErrorFiles#666220e9 type:SecureValueType file_hash:Vector<bytes> text:string = SecureValueError;
secureValueError#869d758f type:SecureValueType hash:bytes text:string = SecureValueError;
secureValueErrorTranslationFile#a1144770 type:SecureValueType file_hash:bytes text:string = SecureValueError;
secureValueErrorTranslationFiles#34636dd8 type:SecureValueType file_hash:Vector<bytes> text:string = SecureValueError;
secureCredentialsEncrypted#33f0ea47 data:bytes hash:bytes secret:bytes = SecureCredentialsEncrypted;
account.authorizationForm#ad2e1cd8 flags:# required_types:Vector<SecureRequiredType> values:Vector<SecureValue> errors:Vector<SecureValueError> users:Vector<User> privacy_policy_url:flags.0?string = account.AuthorizationForm;
account.sentEmailCode#811f854f email_pattern:string length:int = account.SentEmailCode;
help.deepLinkInfoEmpty#66afa166 = help.DeepLinkInfo;
help.deepLinkInfo#6a4ee832 flags:# update_app:flags.0?true message:string entities:flags.1?Vector<MessageEntity> = help.DeepLinkInfo;
savedPhoneContact#1142bd56 phone:string first_name:string last_name:string date:int = SavedContact;
account.takeout#4dba4501 id:long = account.Takeout;
passwordKdfAlgoUnknown#d45ab096 = PasswordKdfAlgo;
passwordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow#3a912d4a salt1:bytes salt2:bytes g:int p:bytes = PasswordKdfAlgo;
securePasswordKdfAlgoUnknown#4a8537 = SecurePasswordKdfAlgo;
securePasswordKdfAlgoPBKDF2HMACSHA512iter100000#bbf2dda0 salt:bytes = SecurePasswordKdfAlgo;
securePasswordKdfAlgoSHA512#86471d92 salt:bytes = SecurePasswordKdfAlgo;
secureSecretSettings#1527bcac secure_algo:SecurePasswordKdfAlgo secure_secret:bytes secure_secret_id:long = SecureSecretSettings;
inputCheckPasswordEmpty#9880f658 = InputCheckPasswordSRP;
inputCheckPasswordSRP#d27ff082 srp_id:long A:bytes M1:bytes = InputCheckPasswordSRP;
secureRequiredType#829d99da flags:# native_names:flags.0?true selfie_required:flags.1?true translation_required:flags.2?true type:SecureValueType = SecureRequiredType;
secureRequiredTypeOneOf#27477b4 types:Vector<SecureRequiredType> = SecureRequiredType;
help.passportConfigNotModified#bfb9f457 = help.PassportConfig;
help.passportConfig#a098d6af hash:int countries_langs:DataJSON = help.PassportConfig;
inputAppEvent#1d1b1245 time:double type:string peer:long data:JSONValue = InputAppEvent;
jsonObjectValue#c0de1bd9 key:string value:JSONValue = JSONObjectValue;
jsonNull#3f6d7b68 = JSONValue;
jsonBool#c7345e6a value:Bool = JSONValue;
jsonNumber#2be0dfa4 value:double = JSONValue;
jsonString#b71e767a value:string = JSONValue;
jsonArray#f7444763 value:Vector<JSONValue> = JSONValue;
jsonObject#99c1d49d value:Vector<JSONObjectValue> = JSONValue;
pageTableCell#34566b6a flags:# header:flags.0?true align_center:flags.3?true align_right:flags.4?true valign_middle:flags.5?true valign_bottom:flags.6?true text:flags.7?RichText colspan:flags.1?int rowspan:flags.2?int = PageTableCell;
pageTableRow#e0c0c5e5 cells:Vector<PageTableCell> = PageTableRow;
pageCaption#6f747657 text:RichText credit:RichText = PageCaption;
pageListItemText#b92fb6cd text:RichText = PageListItem;
pageListItemBlocks#25e073fc blocks:Vector<PageBlock> = PageListItem;
pageListOrderedItemText#5e068047 num:string text:RichText = PageListOrderedItem;
pageListOrderedItemBlocks#98dd8936 num:string blocks:Vector<PageBlock> = PageListOrderedItem;
pageRelatedArticle#b390dc08 flags:# url:string webpage_id:long title:flags.0?string description:flags.1?string photo_id:flags.2?long author:flags.3?string published_date:flags.4?int = PageRelatedArticle;
page#98657f0d flags:# part:flags.0?true rtl:flags.1?true v2:flags.2?true url:string blocks:Vector<PageBlock> photos:Vector<Photo> documents:Vector<Document> views:flags.3?int = Page;
help.supportName#8c05f1c9 name:string = help.SupportName;
help.userInfoEmpty#f3ae2eed = help.UserInfo;
help.userInfo#1eb3758 message:string entities:Vector<MessageEntity> author:string date:int = help.UserInfo;
pollAnswer#ff16e2ca text:TextWithEntities option:bytes = PollAnswer;
poll#58747131 id:long flags:# closed:flags.0?true public_voters:flags.1?true multiple_choice:flags.2?true quiz:flags.3?true question:TextWithEntities answers:Vector<PollAnswer> close_period:flags.4?int close_date:flags.5?int = Poll;
pollAnswerVoters#3b6ddad2 flags:# chosen:flags.0?true correct:flags.1?true option:bytes voters:int = PollAnswerVoters;
pollResults#7adf2420 flags:# min:flags.0?true results:flags.1?Vector<PollAnswerVoters> total_voters:flags.2?int recent_voters:flags.3?Vector<Peer> solution:flags.4?string solution_entities:flags.4?Vector<MessageEntity> = PollResults;
chatOnlines#f041e250 onlines:int = ChatOnlines;
statsURL#47a971e0 url:string = StatsURL;
chatAdminRights#5fb224d5 flags:# change_info:flags.0?true post_messages:flags.1?true edit_messages:flags.2?true delete_messages:flags.3?true ban_users:flags.4?true invite_users:flags.5?true pin_messages:flags.7?true add_admins:flags.9?true anonymous:flags.10?true manage_call:flags.11?true other:flags.12?true manage_topics:flags.13?true post_stories:flags.14?true edit_stories:flags.15?true delete_stories:flags.16?true = ChatAdminRights;
chatBannedRights#9f120418 flags:# view_messages:flags.0?true send_messages:flags.1?true send_media:flags.2?true send_stickers:flags.3?true send_gifs:flags.4?true send_games:flags.5?true send_inline:flags.6?true embed_links:flags.7?true send_polls:flags.8?true change_info:flags.10?true invite_users:flags.15?true pin_messages:flags.17?true manage_topics:flags.18?true send_photos:flags.19?true send_videos:flags.20?true send_roundvideos:flags.21?true send_audios:flags.22?true send_voices:flags.23?true send_docs:flags.24?true send_plain:flags.25?true until_date:int = ChatBannedRights;
inputWallPaper#e630b979 id:long access_hash:long = InputWallPaper;
inputWallPaperSlug#72091c80 slug:string = InputWallPaper;
inputWallPaperNoFile#967a462e id:long = InputWallPaper;
account.wallPapersNotModified#1c199183 = account.WallPapers;
account.wallPapers#cdc3858c hash:long wallpapers:Vector<WallPaper> = account.WallPapers;
codeSettings#ad253d78 flags:# allow_flashcall:flags.0?true current_number:flags.1?true allow_app_hash:flags.4?true allow_missed_call:flags.5?true allow_firebase:flags.7?true unknown_number:flags.9?true logout_tokens:flags.6?Vector<bytes> token:flags.8?string app_sandbox:flags.8?Bool = CodeSettings;
wallPaperSettings#372efcd0 flags:# blur:flags.1?true motion:flags.2?true background_color:flags.0?int second_background_color:flags.4?int third_background_color:flags.5?int fourth_background_color:flags.6?int intensity:flags.3?int rotation:flags.4?int emoticon:flags.7?string = WallPaperSettings;
autoDownloadSettings#baa57628 flags:# disabled:flags.0?true video_preload_large:flags.1?true audio_preload_next:flags.2?true phonecalls_less_data:flags.3?true stories_preload:flags.4?true photo_size_max:int video_size_max:long file_size_max:long video_upload_maxbitrate:int small_queue_active_operations_max:int large_queue_active_operations_max:int = AutoDownloadSettings;
account.autoDownloadSettings#63cacf26 low:AutoDownloadSettings medium:AutoDownloadSettings high:AutoDownloadSettings = account.AutoDownloadSettings;
emojiKeyword#d5b3b9f9 keyword:string emoticons:Vector<string> = EmojiKeyword;
emojiKeywordDeleted#236df622 keyword:string emoticons:Vector<string> = EmojiKeyword;
emojiKeywordsDifference#5cc761bd lang_code:string from_version:int version:int keywords:Vector<EmojiKeyword> = EmojiKeywordsDifference;
emojiURL#a575739d url:string = EmojiURL;
emojiLanguage#b3fb5361 lang_code:string = EmojiLanguage;
folder#ff544e65 flags:# autofill_new_broadcasts:flags.0?true autofill_public_groups:flags.1?true autofill_new_correspondents:flags.2?true id:int title:string photo:flags.3?ChatPhoto = Folder;
inputFolderPeer#fbd2c296 peer:InputPeer folder_id:int = InputFolderPeer;
folderPeer#e9baa668 peer:Peer folder_id:int = FolderPeer;
messages.searchCounter#e844ebff flags:# inexact:flags.1?true filter:MessagesFilter count:int = messages.SearchCounter;
urlAuthResultRequest#92d33a0e flags:# request_write_access:flags.0?true bot:User domain:string = UrlAuthResult;
urlAuthResultAccepted#8f8c0e4e url:string = UrlAuthResult;
urlAuthResultDefault#a9d6db1f = UrlAuthResult;
channelLocationEmpty#bfb5ad8b = ChannelLocation;
channelLocation#209b82db geo_point:GeoPoint address:string = ChannelLocation;
peerLocated#ca461b5d peer:Peer expires:int distance:int = PeerLocated;
peerSelfLocated#f8ec284b expires:int = PeerLocated;
restrictionReason#d072acb4 platform:string reason:string text:string = RestrictionReason;
inputTheme#3c5693e9 id:long access_hash:long = InputTheme;
inputThemeSlug#f5890df1 slug:string = InputTheme;
theme#a00e67d6 flags:# creator:flags.0?true default:flags.1?true for_chat:flags.5?true id:long access_hash:long slug:string title:string document:flags.2?Document settings:flags.3?Vector<ThemeSettings> emoticon:flags.6?string installs_count:flags.4?int = Theme;
account.themesNotModified#f41eb622 = account.Themes;
account.themes#9a3d8c6d hash:long themes:Vector<Theme> = account.Themes;
auth.loginToken#629f1980 expires:int token:bytes = auth.LoginToken;
auth.loginTokenMigrateTo#68e9916 dc_id:int token:bytes = auth.LoginToken;
auth.loginTokenSuccess#390d5c5e authorization:auth.Authorization = auth.LoginToken;
account.contentSettings#57e28221 flags:# sensitive_enabled:flags.0?true sensitive_can_change:flags.1?true = account.ContentSettings;
messages.inactiveChats#a927fec5 dates:Vector<int> chats:Vector<Chat> users:Vector<User> = messages.InactiveChats;
baseThemeClassic#c3a12462 = BaseTheme;
baseThemeDay#fbd81688 = BaseTheme;
baseThemeNight#b7b31ea8 = BaseTheme;
baseThemeTinted#6d5f77ee = BaseTheme;
baseThemeArctic#5b11125a = BaseTheme;
inputThemeSettings#8fde504f flags:# message_colors_animated:flags.2?true base_theme:BaseTheme accent_color:int outbox_accent_color:flags.3?int message_colors:flags.0?Vector<int> wallpaper:flags.1?InputWallPaper wallpaper_settings:flags.1?WallPaperSettings = InputThemeSettings;
themeSettings#fa58b6d4 flags:# message_colors_animated:flags.2?true base_theme:BaseTheme accent_color:int outbox_accent_color:flags.3?int message_colors:flags.0?Vector<int> wallpaper:flags.1?WallPaper = ThemeSettings;
webPageAttributeTheme#54b56617 flags:# documents:flags.0?Vector<Document> settings:flags.1?ThemeSettings = WebPageAttribute;
webPageAttributeStory#2e94c3e7 flags:# peer:Peer id:int story:flags.0?StoryItem = WebPageAttribute;
webPageAttributeStickerSet#50cc03d3 flags:# emojis:flags.0?true text_color:flags.1?true stickers:Vector<Document> = WebPageAttribute;
webPageAttributeUniqueStarGift#cf6f6db8 gift:StarGift = WebPageAttribute;
messages.votesList#4899484e flags:# count:int votes:Vector<MessagePeerVote> chats:Vector<Chat> users:Vector<User> next_offset:flags.0?string = messages.VotesList;
bankCardOpenUrl#f568028a url:string name:string = BankCardOpenUrl;
payments.bankCardData#3e24e573 title:string open_urls:Vector<BankCardOpenUrl> = payments.BankCardData;
dialogFilter#aa472651 flags:# contacts:flags.0?true non_contacts:flags.1?true groups:flags.2?true broadcasts:flags.3?true bots:flags.4?true exclude_muted:flags.11?true exclude_read:flags.12?true exclude_archived:flags.13?true title_noanimate:flags.28?true id:int title:TextWithEntities emoticon:flags.25?string color:flags.27?int pinned_peers:Vector<InputPeer> include_peers:Vector<InputPeer> exclude_peers:Vector<InputPeer> = DialogFilter;
dialogFilterDefault#363293ae = DialogFilter;
dialogFilterChatlist#96537bd7 flags:# has_my_invites:flags.26?true title_noanimate:flags.28?true id:int title:TextWithEntities emoticon:flags.25?string color:flags.27?int pinned_peers:Vector<InputPeer> include_peers:Vector<InputPeer> = DialogFilter;
dialogFilterSuggested#77744d4a filter:DialogFilter description:string = DialogFilterSuggested;
statsDateRangeDays#b637edaf min_date:int max_date:int = StatsDateRangeDays;
statsAbsValueAndPrev#cb43acde current:double previous:double = StatsAbsValueAndPrev;
statsPercentValue#cbce2fe0 part:double total:double = StatsPercentValue;
statsGraphAsync#4a27eb2d token:string = StatsGraph;
statsGraphError#bedc9822 error:string = StatsGraph;
statsGraph#8ea464b6 flags:# json:DataJSON zoom_token:flags.0?string = StatsGraph;
stats.broadcastStats#396ca5fc period:StatsDateRangeDays followers:StatsAbsValueAndPrev views_per_post:StatsAbsValueAndPrev shares_per_post:StatsAbsValueAndPrev reactions_per_post:StatsAbsValueAndPrev views_per_story:StatsAbsValueAndPrev shares_per_story:StatsAbsValueAndPrev reactions_per_story:StatsAbsValueAndPrev enabled_notifications:StatsPercentValue growth_graph:StatsGraph followers_graph:StatsGraph mute_graph:StatsGraph top_hours_graph:StatsGraph interactions_graph:StatsGraph iv_interactions_graph:StatsGraph views_by_source_graph:StatsGraph new_followers_by_source_graph:StatsGraph languages_graph:StatsGraph reactions_by_emotion_graph:StatsGraph story_interactions_graph:StatsGraph story_reactions_by_emotion_graph:StatsGraph recent_posts_interactions:Vector<PostInteractionCounters> = stats.BroadcastStats;
help.promoDataEmpty#98f6ac75 expires:int = help.PromoData;
help.promoData#8c39793f flags:# proxy:flags.0?true expires:int peer:Peer chats:Vector<Chat> users:Vector<User> psa_type:flags.1?string psa_message:flags.2?string = help.PromoData;
videoSize#de33b094 flags:# type:string w:int h:int size:int video_start_ts:flags.0?double = VideoSize;
videoSizeEmojiMarkup#f85c413c emoji_id:long background_colors:Vector<int> = VideoSize;
videoSizeStickerMarkup#da082fe stickerset:InputStickerSet sticker_id:long background_colors:Vector<int> = VideoSize;
statsGroupTopPoster#9d04af9b user_id:long messages:int avg_chars:int = StatsGroupTopPoster;
statsGroupTopAdmin#d7584c87 user_id:long deleted:int kicked:int banned:int = StatsGroupTopAdmin;
statsGroupTopInviter#535f779d user_id:long invitations:int = StatsGroupTopInviter;
stats.megagroupStats#ef7ff916 period:StatsDateRangeDays members:StatsAbsValueAndPrev messages:StatsAbsValueAndPrev viewers:StatsAbsValueAndPrev posters:StatsAbsValueAndPrev growth_graph:StatsGraph members_graph:StatsGraph new_members_by_source_graph:StatsGraph languages_graph:StatsGraph messages_graph:StatsGraph actions_graph:StatsGraph top_hours_graph:StatsGraph weekdays_graph:StatsGraph top_posters:Vector<StatsGroupTopPoster> top_admins:Vector<StatsGroupTopAdmin> top_inviters:Vector<StatsGroupTopInviter> users:Vector<User> = stats.MegagroupStats;
globalPrivacySettings#734c4ccb flags:# archive_and_mute_new_noncontact_peers:flags.0?true keep_archived_unmuted:flags.1?true keep_archived_folders:flags.2?true hide_read_marks:flags.3?true new_noncontact_peers_require_premium:flags.4?true = GlobalPrivacySettings;
help.countryCode#4203c5ef flags:# country_code:string prefixes:flags.0?Vector<string> patterns:flags.1?Vector<string> = help.CountryCode;
help.country#c3878e23 flags:# hidden:flags.0?true iso2:string default_name:string name:flags.1?string country_codes:Vector<help.CountryCode> = help.Country;
help.countriesListNotModified#93cc1f32 = help.CountriesList;
help.countriesList#87d0759e countries:Vector<help.Country> hash:int = help.CountriesList;
messageViews#455b853d flags:# views:flags.0?int forwards:flags.1?int replies:flags.2?MessageReplies = MessageViews;
messages.messageViews#b6c4f543 views:Vector<MessageViews> chats:Vector<Chat> users:Vector<User> = messages.MessageViews;
messages.discussionMessage#a6341782 flags:# messages:Vector<Message> max_id:flags.0?int read_inbox_max_id:flags.1?int read_outbox_max_id:flags.2?int unread_count:int chats:Vector<Chat> users:Vector<User> = messages.DiscussionMessage;
messageReplyHeader#afbc09db flags:# reply_to_scheduled:flags.2?true forum_topic:flags.3?true quote:flags.9?true reply_to_msg_id:flags.4?int reply_to_peer_id:flags.0?Peer reply_from:flags.5?MessageFwdHeader reply_media:flags.8?MessageMedia reply_to_top_id:flags.1?int quote_text:flags.6?string quote_entities:flags.7?Vector<MessageEntity> quote_offset:flags.10?int = MessageReplyHeader;
messageReplyStoryHeader#e5af939 peer:Peer story_id:int = MessageReplyHeader;
messageReplies#83d60fc2 flags:# comments:flags.0?true replies:int replies_pts:int recent_repliers:flags.1?Vector<Peer> channel_id:flags.0?long max_id:flags.2?int read_max_id:flags.3?int = MessageReplies;
peerBlocked#e8fd8014 peer_id:Peer date:int = PeerBlocked;
stats.messageStats#7fe91c14 views_graph:StatsGraph reactions_by_emotion_graph:StatsGraph = stats.MessageStats;
groupCallDiscarded#7780bcb4 id:long access_hash:long duration:int = GroupCall;
groupCall#cdf8d3e3 flags:# join_muted:flags.1?true can_change_join_muted:flags.2?true join_date_asc:flags.6?true schedule_start_subscribed:flags.8?true can_start_video:flags.9?true record_video_active:flags.11?true rtmp_stream:flags.12?true listeners_hidden:flags.13?true id:long access_hash:long participants_count:int title:flags.3?string stream_dc_id:flags.4?int record_start_date:flags.5?int schedule_date:flags.7?int unmuted_video_count:flags.10?int unmuted_video_limit:int version:int conference_from_call:flags.14?long = GroupCall;
inputGroupCall#d8aa840f id:long access_hash:long = InputGroupCall;
groupCallParticipant#eba636fe flags:# muted:flags.0?true left:flags.1?true can_self_unmute:flags.2?true just_joined:flags.4?true versioned:flags.5?true min:flags.8?true muted_by_you:flags.9?true volume_by_admin:flags.10?true self:flags.12?true video_joined:flags.15?true peer:Peer date:int active_date:flags.3?int source:int volume:flags.7?int about:flags.11?string raise_hand_rating:flags.13?long video:flags.6?GroupCallParticipantVideo presentation:flags.14?GroupCallParticipantVideo = GroupCallParticipant;
phone.groupCall#9e727aad call:GroupCall participants:Vector<GroupCallParticipant> participants_next_offset:string chats:Vector<Chat> users:Vector<User> = phone.GroupCall;
phone.groupParticipants#f47751b6 count:int participants:Vector<GroupCallParticipant> next_offset:string chats:Vector<Chat> users:Vector<User> version:int = phone.GroupParticipants;
inlineQueryPeerTypeSameBotPM#3081ed9d = InlineQueryPeerType;
inlineQueryPeerTypePM#833c0fac = InlineQueryPeerType;
inlineQueryPeerTypeChat#d766c50a = InlineQueryPeerType;
inlineQueryPeerTypeMegagroup#5ec4be43 = InlineQueryPeerType;
inlineQueryPeerTypeBroadcast#6334ee9a = InlineQueryPeerType;
inlineQueryPeerTypeBotPM#e3b2d0c = InlineQueryPeerType;
messages.historyImport#1662af0b id:long = messages.HistoryImport;
messages.historyImportParsed#5e0fb7b9 flags:# pm:flags.0?true group:flags.1?true title:flags.2?string = messages.HistoryImportParsed;
messages.affectedFoundMessages#ef8d3e6c pts:int pts_count:int offset:int messages:Vector<int> = messages.AffectedFoundMessages;
chatInviteImporter#8c5adfd9 flags:# requested:flags.0?true via_chatlist:flags.3?true user_id:long date:int about:flags.2?string approved_by:flags.1?long = ChatInviteImporter;
messages.exportedChatInvites#bdc62dcc count:int invites:Vector<ExportedChatInvite> users:Vector<User> = messages.ExportedChatInvites;
messages.exportedChatInvite#1871be50 invite:ExportedChatInvite users:Vector<User> = messages.ExportedChatInvite;
messages.exportedChatInviteReplaced#222600ef invite:ExportedChatInvite new_invite:ExportedChatInvite users:Vector<User> = messages.ExportedChatInvite;
messages.chatInviteImporters#81b6b00a count:int importers:Vector<ChatInviteImporter> users:Vector<User> = messages.ChatInviteImporters;
chatAdminWithInvites#f2ecef23 admin_id:long invites_count:int revoked_invites_count:int = ChatAdminWithInvites;
messages.chatAdminsWithInvites#b69b72d7 admins:Vector<ChatAdminWithInvites> users:Vector<User> = messages.ChatAdminsWithInvites;
messages.checkedHistoryImportPeer#a24de717 confirm_text:string = messages.CheckedHistoryImportPeer;
phone.joinAsPeers#afe5623f peers:Vector<Peer> chats:Vector<Chat> users:Vector<User> = phone.JoinAsPeers;
phone.exportedGroupCallInvite#204bd158 link:string = phone.ExportedGroupCallInvite;
groupCallParticipantVideoSourceGroup#dcb118b7 semantics:string sources:Vector<int> = GroupCallParticipantVideoSourceGroup;
groupCallParticipantVideo#67753ac8 flags:# paused:flags.0?true endpoint:string source_groups:Vector<GroupCallParticipantVideoSourceGroup> audio_source:flags.1?int = GroupCallParticipantVideo;
stickers.suggestedShortName#85fea03f short_name:string = stickers.SuggestedShortName;
botCommandScopeDefault#2f6cb2ab = BotCommandScope;
botCommandScopeUsers#3c4f04d8 = BotCommandScope;
botCommandScopeChats#6fe1a881 = BotCommandScope;
botCommandScopeChatAdmins#b9aa606a = BotCommandScope;
botCommandScopePeer#db9d897d peer:InputPeer = BotCommandScope;
botCommandScopePeerAdmins#3fd863d1 peer:InputPeer = BotCommandScope;
botCommandScopePeerUser#a1321f3 peer:InputPeer user_id:InputUser = BotCommandScope;
account.resetPasswordFailedWait#e3779861 retry_date:int = account.ResetPasswordResult;
account.resetPasswordRequestedWait#e9effc7d until_date:int = account.ResetPasswordResult;
account.resetPasswordOk#e926d63e = account.ResetPasswordResult;
sponsoredMessage#4d93a990 flags:# recommended:flags.5?true can_report:flags.12?true random_id:bytes url:string title:string message:string entities:flags.1?Vector<MessageEntity> photo:flags.6?Photo media:flags.14?MessageMedia color:flags.13?PeerColor button_text:string sponsor_info:flags.7?string additional_info:flags.8?string = SponsoredMessage;
messages.sponsoredMessages#c9ee1d87 flags:# posts_between:flags.0?int messages:Vector<SponsoredMessage> chats:Vector<Chat> users:Vector<User> = messages.SponsoredMessages;
messages.sponsoredMessagesEmpty#1839490f = messages.SponsoredMessages;
searchResultsCalendarPeriod#c9b0539f date:int min_msg_id:int max_msg_id:int count:int = SearchResultsCalendarPeriod;
messages.searchResultsCalendar#147ee23c flags:# inexact:flags.0?true count:int min_date:int min_msg_id:int offset_id_offset:flags.1?int periods:Vector<SearchResultsCalendarPeriod> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.SearchResultsCalendar;
searchResultPosition#7f648b67 msg_id:int date:int offset:int = SearchResultsPosition;
messages.searchResultsPositions#53b22baf count:int positions:Vector<SearchResultsPosition> = messages.SearchResultsPositions;
channels.sendAsPeers#f496b0c6 peers:Vector<SendAsPeer> chats:Vector<Chat> users:Vector<User> = channels.SendAsPeers;
users.userFull#3b6d152e full_user:UserFull chats:Vector<Chat> users:Vector<User> = users.UserFull;
messages.peerSettings#6880b94d settings:PeerSettings chats:Vector<Chat> users:Vector<User> = messages.PeerSettings;
auth.loggedOut#c3a2835f flags:# future_auth_token:flags.0?bytes = auth.LoggedOut;
reactionCount#a3d1cb80 flags:# chosen_order:flags.0?int reaction:Reaction count:int = ReactionCount;
messageReactions#a339f0b flags:# min:flags.0?true can_see_list:flags.2?true reactions_as_tags:flags.3?true results:Vector<ReactionCount> recent_reactions:flags.1?Vector<MessagePeerReaction> top_reactors:flags.4?Vector<MessageReactor> = MessageReactions;
messages.messageReactionsList#31bd492d flags:# count:int reactions:Vector<MessagePeerReaction> chats:Vector<Chat> users:Vector<User> next_offset:flags.0?string = messages.MessageReactionsList;
availableReaction#c077ec01 flags:# inactive:flags.0?true premium:flags.2?true reaction:string title:string static_icon:Document appear_animation:Document select_animation:Document activate_animation:Document effect_animation:Document around_animation:flags.1?Document center_icon:flags.1?Document = AvailableReaction;
messages.availableReactionsNotModified#9f071957 = messages.AvailableReactions;
messages.availableReactions#768e3aad hash:int reactions:Vector<AvailableReaction> = messages.AvailableReactions;
messagePeerReaction#8c79b63c flags:# big:flags.0?true unread:flags.1?true my:flags.2?true peer_id:Peer date:int reaction:Reaction = MessagePeerReaction;
groupCallStreamChannel#80eb48af channel:int scale:int last_timestamp_ms:long = GroupCallStreamChannel;
phone.groupCallStreamChannels#d0e482b2 channels:Vector<GroupCallStreamChannel> = phone.GroupCallStreamChannels;
phone.groupCallStreamRtmpUrl#2dbf3432 url:string key:string = phone.GroupCallStreamRtmpUrl;
attachMenuBotIconColor#4576f3f0 name:string color:int = AttachMenuBotIconColor;
attachMenuBotIcon#b2a7386b flags:# name:string icon:Document colors:flags.0?Vector<AttachMenuBotIconColor> = AttachMenuBotIcon;
attachMenuBot#d90d8dfe flags:# inactive:flags.0?true has_settings:flags.1?true request_write_access:flags.2?true show_in_attach_menu:flags.3?true show_in_side_menu:flags.4?true side_menu_disclaimer_needed:flags.5?true bot_id:long short_name:string peer_types:flags.3?Vector<AttachMenuPeerType> icons:Vector<AttachMenuBotIcon> = AttachMenuBot;
attachMenuBotsNotModified#f1d88a5c = AttachMenuBots;
attachMenuBots#3c4301c0 hash:long bots:Vector<AttachMenuBot> users:Vector<User> = AttachMenuBots;
attachMenuBotsBot#93bf667f bot:AttachMenuBot users:Vector<User> = AttachMenuBotsBot;
webViewResultUrl#4d22ff98 flags:# fullsize:flags.1?true fullscreen:flags.2?true query_id:flags.0?long url:string = WebViewResult;
webViewMessageSent#c94511c flags:# msg_id:flags.0?InputBotInlineMessageID = WebViewMessageSent;
botMenuButtonDefault#7533a588 = BotMenuButton;
botMenuButtonCommands#4258c205 = BotMenuButton;
botMenuButton#c7b57ce6 text:string url:string = BotMenuButton;
account.savedRingtonesNotModified#fbf6e8b1 = account.SavedRingtones;
account.savedRingtones#c1e92cc5 hash:long ringtones:Vector<Document> = account.SavedRingtones;
notificationSoundDefault#97e8bebe = NotificationSound;
notificationSoundNone#6f0c34df = NotificationSound;
notificationSoundLocal#830b9ae4 title:string data:string = NotificationSound;
notificationSoundRingtone#ff6c8049 id:long = NotificationSound;
account.savedRingtone#b7263f6d = account.SavedRingtone;
account.savedRingtoneConverted#1f307eb7 document:Document = account.SavedRingtone;
attachMenuPeerTypeSameBotPM#7d6be90e = AttachMenuPeerType;
attachMenuPeerTypeBotPM#c32bfa1a = AttachMenuPeerType;
attachMenuPeerTypePM#f146d31f = AttachMenuPeerType;
attachMenuPeerTypeChat#509113f = AttachMenuPeerType;
attachMenuPeerTypeBroadcast#7bfbdefc = AttachMenuPeerType;
inputInvoiceMessage#c5b56859 peer:InputPeer msg_id:int = InputInvoice;
inputInvoiceSlug#c326caef slug:string = InputInvoice;
inputInvoicePremiumGiftCode#98986c0d purpose:InputStorePaymentPurpose option:PremiumGiftCodeOption = InputInvoice;
inputInvoiceStars#65f00ce3 purpose:InputStorePaymentPurpose = InputInvoice;
inputInvoiceChatInviteSubscription#34e793f1 hash:string = InputInvoice;
inputInvoiceStarGift#e8625e92 flags:# hide_name:flags.0?true include_upgrade:flags.2?true peer:InputPeer gift_id:long message:flags.1?TextWithEntities = InputInvoice;
inputInvoiceStarGiftUpgrade#4d818d5d flags:# keep_original_details:flags.0?true stargift:InputSavedStarGift = InputInvoice;
inputInvoiceStarGiftTransfer#4a5f5bd9 stargift:InputSavedStarGift to_id:InputPeer = InputInvoice;
payments.exportedInvoice#aed0cbd9 url:string = payments.ExportedInvoice;
messages.transcribedAudio#cfb9d957 flags:# pending:flags.0?true transcription_id:long text:string trial_remains_num:flags.1?int trial_remains_until_date:flags.1?int = messages.TranscribedAudio;
help.premiumPromo#5334759c status_text:string status_entities:Vector<MessageEntity> video_sections:Vector<string> videos:Vector<Document> period_options:Vector<PremiumSubscriptionOption> users:Vector<User> = help.PremiumPromo;
inputStorePaymentPremiumSubscription#a6751e66 flags:# restore:flags.0?true upgrade:flags.1?true = InputStorePaymentPurpose;
inputStorePaymentGiftPremium#616f7fe8 user_id:InputUser currency:string amount:long = InputStorePaymentPurpose;
inputStorePaymentPremiumGiftCode#fb790393 flags:# users:Vector<InputUser> boost_peer:flags.0?InputPeer currency:string amount:long message:flags.1?TextWithEntities = InputStorePaymentPurpose;
inputStorePaymentPremiumGiveaway#160544ca flags:# only_new_subscribers:flags.0?true winners_are_visible:flags.3?true boost_peer:InputPeer additional_peers:flags.1?Vector<InputPeer> countries_iso2:flags.2?Vector<string> prize_description:flags.4?string random_id:long until_date:int currency:string amount:long = InputStorePaymentPurpose;
inputStorePaymentStarsTopup#dddd0f56 stars:long currency:string amount:long = InputStorePaymentPurpose;
inputStorePaymentStarsGift#1d741ef7 user_id:InputUser stars:long currency:string amount:long = InputStorePaymentPurpose;
inputStorePaymentStarsGiveaway#751f08fa flags:# only_new_subscribers:flags.0?true winners_are_visible:flags.3?true stars:long boost_peer:InputPeer additional_peers:flags.1?Vector<InputPeer> countries_iso2:flags.2?Vector<string> prize_description:flags.4?string random_id:long until_date:int currency:string amount:long users:int = InputStorePaymentPurpose;
premiumGiftOption#74c34319 flags:# months:int currency:string amount:long bot_url:string store_product:flags.0?string = PremiumGiftOption;
paymentFormMethod#88f8f21b url:string title:string = PaymentFormMethod;
emojiStatusEmpty#2de11aae = EmojiStatus;
emojiStatus#e7ff068a flags:# document_id:long until:flags.0?int = EmojiStatus;
emojiStatusCollectible#7184603b flags:# collectible_id:long document_id:long title:string slug:string pattern_document_id:long center_color:int edge_color:int pattern_color:int text_color:int until:flags.0?int = EmojiStatus;
inputEmojiStatusCollectible#7141dbf flags:# collectible_id:long until:flags.0?int = EmojiStatus;
account.emojiStatusesNotModified#d08ce645 = account.EmojiStatuses;
account.emojiStatuses#90c467d1 hash:long statuses:Vector<EmojiStatus> = account.EmojiStatuses;
reactionEmpty#79f5d419 = Reaction;
reactionEmoji#1b2286b8 emoticon:string = Reaction;
reactionCustomEmoji#8935fc73 document_id:long = Reaction;
reactionPaid#523da4eb = Reaction;
chatReactionsNone#eafc32bc = ChatReactions;
chatReactionsAll#52928bca flags:# allow_custom:flags.0?true = ChatReactions;
chatReactionsSome#661d4037 reactions:Vector<Reaction> = ChatReactions;
messages.reactionsNotModified#b06fdbdf = messages.Reactions;
messages.reactions#eafdf716 hash:long reactions:Vector<Reaction> = messages.Reactions;
emailVerifyPurposeLoginSetup#4345be73 phone_number:string phone_code_hash:string = EmailVerifyPurpose;
emailVerifyPurposeLoginChange#527d22eb = EmailVerifyPurpose;
emailVerifyPurposePassport#bbf51685 = EmailVerifyPurpose;
emailVerificationCode#922e55a9 code:string = EmailVerification;
emailVerificationGoogle#db909ec2 token:string = EmailVerification;
emailVerificationApple#96d074fd token:string = EmailVerification;
account.emailVerified#2b96cd1b email:string = account.EmailVerified;
account.emailVerifiedLogin#e1bb0d61 email:string sent_code:auth.SentCode = account.EmailVerified;
premiumSubscriptionOption#5f2d1df2 flags:# current:flags.1?true can_purchase_upgrade:flags.2?true transaction:flags.3?string months:int currency:string amount:long bot_url:string store_product:flags.0?string = PremiumSubscriptionOption;
sendAsPeer#b81c7034 flags:# premium_required:flags.0?true peer:Peer = SendAsPeer;
messageExtendedMediaPreview#ad628cc8 flags:# w:flags.0?int h:flags.0?int thumb:flags.1?PhotoSize video_duration:flags.2?int = MessageExtendedMedia;
messageExtendedMedia#ee479c64 media:MessageMedia = MessageExtendedMedia;
stickerKeyword#fcfeb29c document_id:long keyword:Vector<string> = StickerKeyword;
username#b4073647 flags:# editable:flags.0?true active:flags.1?true username:string = Username;
forumTopicDeleted#23f109b id:int = ForumTopic;
forumTopic#71701da9 flags:# my:flags.1?true closed:flags.2?true pinned:flags.3?true short:flags.5?true hidden:flags.6?true id:int date:int title:string icon_color:int icon_emoji_id:flags.0?long top_message:int read_inbox_max_id:int read_outbox_max_id:int unread_count:int unread_mentions_count:int unread_reactions_count:int from_id:Peer notify_settings:PeerNotifySettings draft:flags.4?DraftMessage = ForumTopic;
messages.forumTopics#367617d3 flags:# order_by_create_date:flags.0?true count:int topics:Vector<ForumTopic> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> pts:int = messages.ForumTopics;
defaultHistoryTTL#43b46b20 period:int = DefaultHistoryTTL;
exportedContactToken#41bf109b url:string expires:int = ExportedContactToken;
requestPeerTypeUser#5f3b8a00 flags:# bot:flags.0?Bool premium:flags.1?Bool = RequestPeerType;
requestPeerTypeChat#c9f06e1b flags:# creator:flags.0?true bot_participant:flags.5?true has_username:flags.3?Bool forum:flags.4?Bool user_admin_rights:flags.1?ChatAdminRights bot_admin_rights:flags.2?ChatAdminRights = RequestPeerType;
requestPeerTypeBroadcast#339bef6c flags:# creator:flags.0?true has_username:flags.3?Bool user_admin_rights:flags.1?ChatAdminRights bot_admin_rights:flags.2?ChatAdminRights = RequestPeerType;
emojiListNotModified#481eadfa = EmojiList;
emojiList#7a1e11d1 hash:long document_id:Vector<long> = EmojiList;
emojiGroup#7a9abda9 title:string icon_emoji_id:long emoticons:Vector<string> = EmojiGroup;
emojiGroupGreeting#80d26cc7 title:string icon_emoji_id:long emoticons:Vector<string> = EmojiGroup;
emojiGroupPremium#93bcf34 title:string icon_emoji_id:long = EmojiGroup;
messages.emojiGroupsNotModified#6fb4ad87 = messages.EmojiGroups;
messages.emojiGroups#881fb94b hash:int groups:Vector<EmojiGroup> = messages.EmojiGroups;
textWithEntities#751f3146 text:string entities:Vector<MessageEntity> = TextWithEntities;
messages.translateResult#33db32f8 result:Vector<TextWithEntities> = messages.TranslatedText;
autoSaveSettings#c84834ce flags:# photos:flags.0?true videos:flags.1?true video_max_size:flags.2?long = AutoSaveSettings;
autoSaveException#81602d47 peer:Peer settings:AutoSaveSettings = AutoSaveException;
account.autoSaveSettings#4c3e069d users_settings:AutoSaveSettings chats_settings:AutoSaveSettings broadcasts_settings:AutoSaveSettings exceptions:Vector<AutoSaveException> chats:Vector<Chat> users:Vector<User> = account.AutoSaveSettings;
help.appConfigNotModified#7cde641d = help.AppConfig;
help.appConfig#dd18782e hash:int config:JSONValue = help.AppConfig;
inputBotAppID#a920bd7a id:long access_hash:long = InputBotApp;
inputBotAppShortName#908c0407 bot_id:InputUser short_name:string = InputBotApp;
botAppNotModified#5da674b7 = BotApp;
botApp#95fcd1d6 flags:# id:long access_hash:long short_name:string title:string description:string photo:Photo document:flags.0?Document hash:long = BotApp;
messages.botApp#eb50adf5 flags:# inactive:flags.0?true request_write_access:flags.1?true has_settings:flags.2?true app:BotApp = messages.BotApp;
inlineBotWebView#b57295d5 text:string url:string = InlineBotWebView;
readParticipantDate#4a4ff172 user_id:long date:int = ReadParticipantDate;
inputChatlistDialogFilter#f3e0da33 filter_id:int = InputChatlist;
exportedChatlistInvite#c5181ac flags:# title:string url:string peers:Vector<Peer> = ExportedChatlistInvite;
chatlists.exportedChatlistInvite#10e6e3a6 filter:DialogFilter invite:ExportedChatlistInvite = chatlists.ExportedChatlistInvite;
chatlists.exportedInvites#10ab6dc7 invites:Vector<ExportedChatlistInvite> chats:Vector<Chat> users:Vector<User> = chatlists.ExportedInvites;
chatlists.chatlistInviteAlready#fa87f659 filter_id:int missing_peers:Vector<Peer> already_peers:Vector<Peer> chats:Vector<Chat> users:Vector<User> = chatlists.ChatlistInvite;
chatlists.chatlistInvite#f10ece2f flags:# title_noanimate:flags.1?true title:TextWithEntities emoticon:flags.0?string peers:Vector<Peer> chats:Vector<Chat> users:Vector<User> = chatlists.ChatlistInvite;
chatlists.chatlistUpdates#93bd878d missing_peers:Vector<Peer> chats:Vector<Chat> users:Vector<User> = chatlists.ChatlistUpdates;
bots.botInfo#e8a775b0 name:string about:string description:string = bots.BotInfo;
messagePeerVote#b6cc2d5c peer:Peer option:bytes date:int = MessagePeerVote;
messagePeerVoteInputOption#74cda504 peer:Peer date:int = MessagePeerVote;
messagePeerVoteMultiple#4628f6e6 peer:Peer options:Vector<bytes> date:int = MessagePeerVote;
storyViews#8d595cd6 flags:# has_viewers:flags.1?true views_count:int forwards_count:flags.2?int reactions:flags.3?Vector<ReactionCount> reactions_count:flags.4?int recent_viewers:flags.0?Vector<long> = StoryViews;
storyItemDeleted#51e6ee4f id:int = StoryItem;
storyItemSkipped#ffadc913 flags:# close_friends:flags.8?true id:int date:int expire_date:int = StoryItem;
storyItem#79b26a24 flags:# pinned:flags.5?true public:flags.7?true close_friends:flags.8?true min:flags.9?true noforwards:flags.10?true edited:flags.11?true contacts:flags.12?true selected_contacts:flags.13?true out:flags.16?true id:int date:int from_id:flags.18?Peer fwd_from:flags.17?StoryFwdHeader expire_date:int caption:flags.0?string entities:flags.1?Vector<MessageEntity> media:MessageMedia media_areas:flags.14?Vector<MediaArea> privacy:flags.2?Vector<PrivacyRule> views:flags.3?StoryViews sent_reaction:flags.15?Reaction = StoryItem;
stories.allStoriesNotModified#1158fe3e flags:# state:string stealth_mode:StoriesStealthMode = stories.AllStories;
stories.allStories#6efc5e81 flags:# has_more:flags.0?true count:int state:string peer_stories:Vector<PeerStories> chats:Vector<Chat> users:Vector<User> stealth_mode:StoriesStealthMode = stories.AllStories;
stories.stories#63c3dd0a flags:# count:int stories:Vector<StoryItem> pinned_to_top:flags.0?Vector<int> chats:Vector<Chat> users:Vector<User> = stories.Stories;
storyView#b0bdeac5 flags:# blocked:flags.0?true blocked_my_stories_from:flags.1?true user_id:long date:int reaction:flags.2?Reaction = StoryView;
storyViewPublicForward#9083670b flags:# blocked:flags.0?true blocked_my_stories_from:flags.1?true message:Message = StoryView;
storyViewPublicRepost#bd74cf49 flags:# blocked:flags.0?true blocked_my_stories_from:flags.1?true peer_id:Peer story:StoryItem = StoryView;
stories.storyViewsList#59d78fc5 flags:# count:int views_count:int forwards_count:int reactions_count:int views:Vector<StoryView> chats:Vector<Chat> users:Vector<User> next_offset:flags.0?string = stories.StoryViewsList;
stories.storyViews#de9eed1d views:Vector<StoryViews> users:Vector<User> = stories.StoryViews;
inputReplyToMessage#22c0f6d5 flags:# reply_to_msg_id:int top_msg_id:flags.0?int reply_to_peer_id:flags.1?InputPeer quote_text:flags.2?string quote_entities:flags.3?Vector<MessageEntity> quote_offset:flags.4?int = InputReplyTo;
inputReplyToStory#5881323a peer:InputPeer story_id:int = InputReplyTo;
exportedStoryLink#3fc9053b link:string = ExportedStoryLink;
storiesStealthMode#712e27fd flags:# active_until_date:flags.0?int cooldown_until_date:flags.1?int = StoriesStealthMode;
mediaAreaCoordinates#cfc9e002 flags:# x:double y:double w:double h:double rotation:double radius:flags.0?double = MediaAreaCoordinates;
mediaAreaVenue#be82db9c coordinates:MediaAreaCoordinates geo:GeoPoint title:string address:string provider:string venue_id:string venue_type:string = MediaArea;
inputMediaAreaVenue#b282217f coordinates:MediaAreaCoordinates query_id:long result_id:string = MediaArea;
mediaAreaGeoPoint#cad5452d flags:# coordinates:MediaAreaCoordinates geo:GeoPoint address:flags.0?GeoPointAddress = MediaArea;
mediaAreaSuggestedReaction#14455871 flags:# dark:flags.0?true flipped:flags.1?true coordinates:MediaAreaCoordinates reaction:Reaction = MediaArea;
mediaAreaChannelPost#770416af coordinates:MediaAreaCoordinates channel_id:long msg_id:int = MediaArea;
inputMediaAreaChannelPost#2271f2bf coordinates:MediaAreaCoordinates channel:InputChannel msg_id:int = MediaArea;
mediaAreaUrl#37381085 coordinates:MediaAreaCoordinates url:string = MediaArea;
mediaAreaWeather#49a6549c coordinates:MediaAreaCoordinates emoji:string temperature_c:double color:int = MediaArea;
mediaAreaStarGift#5787686d coordinates:MediaAreaCoordinates slug:string = MediaArea;
peerStories#9a35e999 flags:# peer:Peer max_read_id:flags.0?int stories:Vector<StoryItem> = PeerStories;
stories.peerStories#cae68768 stories:PeerStories chats:Vector<Chat> users:Vector<User> = stories.PeerStories;
messages.webPage#fd5e12bd webpage:WebPage chats:Vector<Chat> users:Vector<User> = messages.WebPage;
premiumGiftCodeOption#257e962b flags:# users:int months:int store_product:flags.0?string store_quantity:flags.1?int currency:string amount:long = PremiumGiftCodeOption;
payments.checkedGiftCode#284a1096 flags:# via_giveaway:flags.2?true from_id:flags.4?Peer giveaway_msg_id:flags.3?int to_id:flags.0?long date:int months:int used_date:flags.1?int chats:Vector<Chat> users:Vector<User> = payments.CheckedGiftCode;
payments.giveawayInfo#4367daa0 flags:# participating:flags.0?true preparing_results:flags.3?true start_date:int joined_too_early_date:flags.1?int admin_disallowed_chat_id:flags.2?long disallowed_country:flags.4?string = payments.GiveawayInfo;
payments.giveawayInfoResults#e175e66f flags:# winner:flags.0?true refunded:flags.1?true start_date:int gift_code_slug:flags.3?string stars_prize:flags.4?long finish_date:int winners_count:int activated_count:flags.2?int = payments.GiveawayInfo;
prepaidGiveaway#b2539d54 id:long months:int quantity:int date:int = PrepaidGiveaway;
prepaidStarsGiveaway#9a9d77e0 id:long stars:long quantity:int boosts:int date:int = PrepaidGiveaway;
boost#4b3e14d6 flags:# gift:flags.1?true giveaway:flags.2?true unclaimed:flags.3?true id:string user_id:flags.0?long giveaway_msg_id:flags.2?int date:int expires:int used_gift_slug:flags.4?string multiplier:flags.5?int stars:flags.6?long = Boost;
premium.boostsList#86f8613c flags:# count:int boosts:Vector<Boost> next_offset:flags.0?string users:Vector<User> = premium.BoostsList;
myBoost#c448415c flags:# slot:int peer:flags.0?Peer date:int expires:int cooldown_until_date:flags.1?int = MyBoost;
premium.myBoosts#9ae228e2 my_boosts:Vector<MyBoost> chats:Vector<Chat> users:Vector<User> = premium.MyBoosts;
premium.boostsStatus#4959427a flags:# my_boost:flags.2?true level:int current_level_boosts:int boosts:int gift_boosts:flags.4?int next_level_boosts:flags.0?int premium_audience:flags.1?StatsPercentValue boost_url:string prepaid_giveaways:flags.3?Vector<PrepaidGiveaway> my_boost_slots:flags.2?Vector<int> = premium.BoostsStatus;
storyFwdHeader#b826e150 flags:# modified:flags.3?true from:flags.0?Peer from_name:flags.1?string story_id:flags.2?int = StoryFwdHeader;
postInteractionCountersMessage#e7058e7f msg_id:int views:int forwards:int reactions:int = PostInteractionCounters;
postInteractionCountersStory#8a480e27 story_id:int views:int forwards:int reactions:int = PostInteractionCounters;
stats.storyStats#50cd067c views_graph:StatsGraph reactions_by_emotion_graph:StatsGraph = stats.StoryStats;
publicForwardMessage#1f2bf4a message:Message = PublicForward;
publicForwardStory#edf3add0 peer:Peer story:StoryItem = PublicForward;
stats.publicForwards#93037e20 flags:# count:int forwards:Vector<PublicForward> next_offset:flags.0?string chats:Vector<Chat> users:Vector<User> = stats.PublicForwards;
peerColor#b54b5acf flags:# color:flags.0?int background_emoji_id:flags.1?long = PeerColor;
help.peerColorSet#26219a58 colors:Vector<int> = help.PeerColorSet;
help.peerColorProfileSet#767d61eb palette_colors:Vector<int> bg_colors:Vector<int> story_colors:Vector<int> = help.PeerColorSet;
help.peerColorOption#adec6ebe flags:# hidden:flags.0?true color_id:int colors:flags.1?help.PeerColorSet dark_colors:flags.2?help.PeerColorSet channel_min_level:flags.3?int group_min_level:flags.4?int = help.PeerColorOption;
help.peerColorsNotModified#2ba1f5ce = help.PeerColors;
help.peerColors#f8ed08 hash:int colors:Vector<help.PeerColorOption> = help.PeerColors;
storyReaction#6090d6d5 peer_id:Peer date:int reaction:Reaction = StoryReaction;
storyReactionPublicForward#bbab2643 message:Message = StoryReaction;
storyReactionPublicRepost#cfcd0f13 peer_id:Peer story:StoryItem = StoryReaction;
stories.storyReactionsList#aa5f789c flags:# count:int reactions:Vector<StoryReaction> chats:Vector<Chat> users:Vector<User> next_offset:flags.0?string = stories.StoryReactionsList;
savedDialog#bd87cb6c flags:# pinned:flags.2?true peer:Peer top_message:int = SavedDialog;
messages.savedDialogs#f83ae221 dialogs:Vector<SavedDialog> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.SavedDialogs;
messages.savedDialogsSlice#44ba9dd9 count:int dialogs:Vector<SavedDialog> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.SavedDialogs;
messages.savedDialogsNotModified#c01f6fe8 count:int = messages.SavedDialogs;
savedReactionTag#cb6ff828 flags:# reaction:Reaction title:flags.0?string count:int = SavedReactionTag;
messages.savedReactionTagsNotModified#889b59ef = messages.SavedReactionTags;
messages.savedReactionTags#3259950a tags:Vector<SavedReactionTag> hash:long = messages.SavedReactionTags;
outboxReadDate#3bb842ac date:int = OutboxReadDate;
smsjobs.eligibleToJoin#dc8b44cf terms_url:string monthly_sent_sms:int = smsjobs.EligibilityToJoin;
smsjobs.status#2aee9191 flags:# allow_international:flags.0?true recent_sent:int recent_since:int recent_remains:int total_sent:int total_since:int last_gift_slug:flags.1?string terms_url:string = smsjobs.Status;
smsJob#e6a1eeb8 job_id:string phone_number:string text:string = SmsJob;
businessWeeklyOpen#120b1ab9 start_minute:int end_minute:int = BusinessWeeklyOpen;
businessWorkHours#8c92b098 flags:# open_now:flags.0?true timezone_id:string weekly_open:Vector<BusinessWeeklyOpen> = BusinessWorkHours;
businessLocation#ac5c1af7 flags:# geo_point:flags.0?GeoPoint address:string = BusinessLocation;
inputBusinessRecipients#6f8b32aa flags:# existing_chats:flags.0?true new_chats:flags.1?true contacts:flags.2?true non_contacts:flags.3?true exclude_selected:flags.5?true users:flags.4?Vector<InputUser> = InputBusinessRecipients;
businessRecipients#21108ff7 flags:# existing_chats:flags.0?true new_chats:flags.1?true contacts:flags.2?true non_contacts:flags.3?true exclude_selected:flags.5?true users:flags.4?Vector<long> = BusinessRecipients;
businessAwayMessageScheduleAlways#c9b9e2b9 = BusinessAwayMessageSchedule;
businessAwayMessageScheduleOutsideWorkHours#c3f2f501 = BusinessAwayMessageSchedule;
businessAwayMessageScheduleCustom#cc4d9ecc start_date:int end_date:int = BusinessAwayMessageSchedule;
inputBusinessGreetingMessage#194cb3b shortcut_id:int recipients:InputBusinessRecipients no_activity_days:int = InputBusinessGreetingMessage;
businessGreetingMessage#e519abab shortcut_id:int recipients:BusinessRecipients no_activity_days:int = BusinessGreetingMessage;
inputBusinessAwayMessage#832175e0 flags:# offline_only:flags.0?true shortcut_id:int schedule:BusinessAwayMessageSchedule recipients:InputBusinessRecipients = InputBusinessAwayMessage;
businessAwayMessage#ef156a5c flags:# offline_only:flags.0?true shortcut_id:int schedule:BusinessAwayMessageSchedule recipients:BusinessRecipients = BusinessAwayMessage;
timezone#ff9289f5 id:string name:string utc_offset:int = Timezone;
help.timezonesListNotModified#970708cc = help.TimezonesList;
help.timezonesList#7b74ed71 timezones:Vector<Timezone> hash:int = help.TimezonesList;
quickReply#697102b shortcut_id:int shortcut:string top_message:int count:int = QuickReply;
inputQuickReplyShortcut#24596d41 shortcut:string = InputQuickReplyShortcut;
inputQuickReplyShortcutId#1190cf1 shortcut_id:int = InputQuickReplyShortcut;
messages.quickReplies#c68d6695 quick_replies:Vector<QuickReply> messages:Vector<Message> chats:Vector<Chat> users:Vector<User> = messages.QuickReplies;
messages.quickRepliesNotModified#5f91eb5b = messages.QuickReplies;
connectedBot#bd068601 flags:# can_reply:flags.0?true bot_id:long recipients:BusinessBotRecipients = ConnectedBot;
account.connectedBots#17d7f87b connected_bots:Vector<ConnectedBot> users:Vector<User> = account.ConnectedBots;
messages.dialogFilters#2ad93719 flags:# tags_enabled:flags.0?true filters:Vector<DialogFilter> = messages.DialogFilters;
birthday#6c8e1e06 flags:# day:int month:int year:flags.0?int = Birthday;
botBusinessConnection#896433b4 flags:# can_reply:flags.0?true disabled:flags.1?true connection_id:string user_id:long dc_id:int date:int = BotBusinessConnection;
inputBusinessIntro#9c469cd flags:# title:string description:string sticker:flags.0?InputDocument = InputBusinessIntro;
businessIntro#5a0a066d flags:# title:string description:string sticker:flags.0?Document = BusinessIntro;
messages.myStickers#faff629d count:int sets:Vector<StickerSetCovered> = messages.MyStickers;
inputCollectibleUsername#e39460a9 username:string = InputCollectible;
inputCollectiblePhone#a2e214a4 phone:string = InputCollectible;
fragment.collectibleInfo#6ebdff91 purchase_date:int currency:string amount:long crypto_currency:string crypto_amount:long url:string = fragment.CollectibleInfo;
inputBusinessBotRecipients#c4e5921e flags:# existing_chats:flags.0?true new_chats:flags.1?true contacts:flags.2?true non_contacts:flags.3?true exclude_selected:flags.5?true users:flags.4?Vector<InputUser> exclude_users:flags.6?Vector<InputUser> = InputBusinessBotRecipients;
businessBotRecipients#b88cf373 flags:# existing_chats:flags.0?true new_chats:flags.1?true contacts:flags.2?true non_contacts:flags.3?true exclude_selected:flags.5?true users:flags.4?Vector<long> exclude_users:flags.6?Vector<long> = BusinessBotRecipients;
contactBirthday#1d998733 contact_id:long birthday:Birthday = ContactBirthday;
contacts.contactBirthdays#114ff30d contacts:Vector<ContactBirthday> users:Vector<User> = contacts.ContactBirthdays;
missingInvitee#628c9224 flags:# premium_would_allow_invite:flags.0?true premium_required_for_pm:flags.1?true user_id:long = MissingInvitee;
messages.invitedUsers#7f5defa6 updates:Updates missing_invitees:Vector<MissingInvitee> = messages.InvitedUsers;
inputBusinessChatLink#11679fa7 flags:# message:string entities:flags.0?Vector<MessageEntity> title:flags.1?string = InputBusinessChatLink;
businessChatLink#b4ae666f flags:# link:string message:string entities:flags.0?Vector<MessageEntity> title:flags.1?string views:int = BusinessChatLink;
account.businessChatLinks#ec43a2d1 links:Vector<BusinessChatLink> chats:Vector<Chat> users:Vector<User> = account.BusinessChatLinks;
account.resolvedBusinessChatLinks#9a23af21 flags:# peer:Peer message:string entities:flags.0?Vector<MessageEntity> chats:Vector<Chat> users:Vector<User> = account.ResolvedBusinessChatLinks;
requestedPeerUser#d62ff46a flags:# user_id:long first_name:flags.0?string last_name:flags.0?string username:flags.1?string photo:flags.2?Photo = RequestedPeer;
requestedPeerChat#7307544f flags:# chat_id:long title:flags.0?string photo:flags.2?Photo = RequestedPeer;
requestedPeerChannel#8ba403e4 flags:# channel_id:long title:flags.0?string username:flags.1?string photo:flags.2?Photo = RequestedPeer;
sponsoredMessageReportOption#430d3150 text:string option:bytes = SponsoredMessageReportOption;
channels.sponsoredMessageReportResultChooseOption#846f9e42 title:string options:Vector<SponsoredMessageReportOption> = channels.SponsoredMessageReportResult;
channels.sponsoredMessageReportResultAdsHidden#3e3bcf2f = channels.SponsoredMessageReportResult;
channels.sponsoredMessageReportResultReported#ad798849 = channels.SponsoredMessageReportResult;
stats.broadcastRevenueStats#5407e297 top_hours_graph:StatsGraph revenue_graph:StatsGraph balances:BroadcastRevenueBalances usd_rate:double = stats.BroadcastRevenueStats;
stats.broadcastRevenueWithdrawalUrl#ec659737 url:string = stats.BroadcastRevenueWithdrawalUrl;
broadcastRevenueTransactionProceeds#557e2cc4 amount:long from_date:int to_date:int = BroadcastRevenueTransaction;
broadcastRevenueTransactionWithdrawal#5a590978 flags:# pending:flags.0?true failed:flags.2?true amount:long date:int provider:string transaction_date:flags.1?int transaction_url:flags.1?string = BroadcastRevenueTransaction;
broadcastRevenueTransactionRefund#42d30d2e amount:long date:int provider:string = BroadcastRevenueTransaction;
stats.broadcastRevenueTransactions#87158466 count:int transactions:Vector<BroadcastRevenueTransaction> = stats.BroadcastRevenueTransactions;
reactionNotificationsFromContacts#bac3a61a = ReactionNotificationsFrom;
reactionNotificationsFromAll#4b9e22a0 = ReactionNotificationsFrom;
reactionsNotifySettings#56e34970 flags:# messages_notify_from:flags.0?ReactionNotificationsFrom stories_notify_from:flags.1?ReactionNotificationsFrom sound:NotificationSound show_previews:Bool = ReactionsNotifySettings;
broadcastRevenueBalances#c3ff71e7 flags:# withdrawal_enabled:flags.0?true current_balance:long available_balance:long overall_revenue:long = BroadcastRevenueBalances;
availableEffect#93c3e27e flags:# premium_required:flags.2?true id:long emoticon:string static_icon_id:flags.0?long effect_sticker_id:long effect_animation_id:flags.1?long = AvailableEffect;
messages.availableEffectsNotModified#d1ed9a5b = messages.AvailableEffects;
messages.availableEffects#bddb616e hash:int effects:Vector<AvailableEffect> documents:Vector<Document> = messages.AvailableEffects;
factCheck#b89bfccf flags:# need_check:flags.0?true country:flags.1?string text:flags.1?TextWithEntities hash:long = FactCheck;
starsTransactionPeerUnsupported#95f2bfe4 = StarsTransactionPeer;
starsTransactionPeerAppStore#b457b375 = StarsTransactionPeer;
starsTransactionPeerPlayMarket#7b560a0b = StarsTransactionPeer;
starsTransactionPeerPremiumBot#250dbaf8 = StarsTransactionPeer;
starsTransactionPeerFragment#e92fd902 = StarsTransactionPeer;
starsTransactionPeer#d80da15d peer:Peer = StarsTransactionPeer;
starsTransactionPeerAds#60682812 = StarsTransactionPeer;
starsTransactionPeerAPI#f9677aad = StarsTransactionPeer;
starsTopupOption#bd915c0 flags:# extended:flags.1?true stars:long store_product:flags.0?string currency:string amount:long = StarsTopupOption;
starsTransaction#64dfc926 flags:# refund:flags.3?true pending:flags.4?true failed:flags.6?true gift:flags.10?true reaction:flags.11?true stargift_upgrade:flags.18?true id:string stars:StarsAmount date:int peer:StarsTransactionPeer title:flags.0?string description:flags.1?string photo:flags.2?WebDocument transaction_date:flags.5?int transaction_url:flags.5?string bot_payload:flags.7?bytes msg_id:flags.8?int extended_media:flags.9?Vector<MessageMedia> subscription_period:flags.12?int giveaway_post_id:flags.13?int stargift:flags.14?StarGift floodskip_number:flags.15?int starref_commission_permille:flags.16?int starref_peer:flags.17?Peer starref_amount:flags.17?StarsAmount = StarsTransaction;
payments.starsStatus#6c9ce8ed flags:# balance:StarsAmount subscriptions:flags.1?Vector<StarsSubscription> subscriptions_next_offset:flags.2?string subscriptions_missing_balance:flags.4?long history:flags.3?Vector<StarsTransaction> next_offset:flags.0?string chats:Vector<Chat> users:Vector<User> = payments.StarsStatus;
foundStory#e87acbc0 peer:Peer story:StoryItem = FoundStory;
stories.foundStories#e2de7737 flags:# count:int stories:Vector<FoundStory> next_offset:flags.0?string chats:Vector<Chat> users:Vector<User> = stories.FoundStories;
geoPointAddress#de4c5d93 flags:# country_iso2:string state:flags.0?string city:flags.1?string street:flags.2?string = GeoPointAddress;
starsRevenueStatus#febe5491 flags:# withdrawal_enabled:flags.0?true current_balance:StarsAmount available_balance:StarsAmount overall_revenue:StarsAmount next_withdrawal_at:flags.1?int = StarsRevenueStatus;
payments.starsRevenueStats#c92bb73b revenue_graph:StatsGraph status:StarsRevenueStatus usd_rate:double = payments.StarsRevenueStats;
payments.starsRevenueWithdrawalUrl#1dab80b7 url:string = payments.StarsRevenueWithdrawalUrl;
payments.starsRevenueAdsAccountUrl#394e7f21 url:string = payments.StarsRevenueAdsAccountUrl;
inputStarsTransaction#206ae6d1 flags:# refund:flags.0?true id:string = InputStarsTransaction;
starsGiftOption#5e0589f1 flags:# extended:flags.1?true stars:long store_product:flags.0?string currency:string amount:long = StarsGiftOption;
bots.popularAppBots#1991b13b flags:# next_offset:flags.0?string users:Vector<User> = bots.PopularAppBots;
botPreviewMedia#23e91ba3 date:int media:MessageMedia = BotPreviewMedia;
bots.previewInfo#ca71d64 media:Vector<BotPreviewMedia> lang_codes:Vector<string> = bots.PreviewInfo;
starsSubscriptionPricing#5416d58 period:int amount:long = StarsSubscriptionPricing;
starsSubscription#2e6eab1a flags:# canceled:flags.0?true can_refulfill:flags.1?true missing_balance:flags.2?true bot_canceled:flags.7?true id:string peer:Peer until_date:int pricing:StarsSubscriptionPricing chat_invite_hash:flags.3?string title:flags.4?string photo:flags.5?WebDocument invoice_slug:flags.6?string = StarsSubscription;
messageReactor#4ba3a95a flags:# top:flags.0?true my:flags.1?true anonymous:flags.2?true peer_id:flags.3?Peer count:int = MessageReactor;
starsGiveawayOption#94ce852a flags:# extended:flags.0?true default:flags.1?true stars:long yearly_boosts:int store_product:flags.2?string currency:string amount:long winners:Vector<StarsGiveawayWinnersOption> = StarsGiveawayOption;
starsGiveawayWinnersOption#54236209 flags:# default:flags.0?true users:int per_user_stars:long = StarsGiveawayWinnersOption;
starGift#2cc73c8 flags:# limited:flags.0?true sold_out:flags.1?true birthday:flags.2?true id:long sticker:Document stars:long availability_remains:flags.0?int availability_total:flags.0?int convert_stars:long first_sale_date:flags.1?int last_sale_date:flags.1?int upgrade_stars:flags.3?long = StarGift;
starGiftUnique#f2fe7e4a flags:# id:long title:string slug:string num:int owner_id:flags.0?Peer owner_name:flags.1?string owner_address:flags.2?string attributes:Vector<StarGiftAttribute> availability_issued:int availability_total:int = StarGift;
payments.starGiftsNotModified#a388a368 = payments.StarGifts;
payments.starGifts#901689ea hash:int gifts:Vector<StarGift> = payments.StarGifts;
messageReportOption#7903e3d9 text:string option:bytes = MessageReportOption;
reportResultChooseOption#f0e4e0b6 title:string options:Vector<MessageReportOption> = ReportResult;
reportResultAddComment#6f09ac31 flags:# optional:flags.0?true option:bytes = ReportResult;
reportResultReported#8db33c4b = ReportResult;
messages.botPreparedInlineMessage#8ecf0511 id:string expire_date:int = messages.BotPreparedInlineMessage;
messages.preparedInlineMessage#ff57708d query_id:long result:BotInlineResult peer_types:Vector<InlineQueryPeerType> cache_time:int users:Vector<User> = messages.PreparedInlineMessage;
botAppSettings#c99b1950 flags:# placeholder_path:flags.0?bytes background_color:flags.1?int background_dark_color:flags.2?int header_color:flags.3?int header_dark_color:flags.4?int = BotAppSettings;
starRefProgram#dd0c66f2 flags:# bot_id:long commission_permille:int duration_months:flags.0?int end_date:flags.1?int daily_revenue_per_user:flags.2?StarsAmount = StarRefProgram;
connectedBotStarRef#19a13f71 flags:# revoked:flags.1?true url:string date:int bot_id:long commission_permille:int duration_months:flags.0?int participants:long revenue:long = ConnectedBotStarRef;
payments.connectedStarRefBots#98d5ea1d count:int connected_bots:Vector<ConnectedBotStarRef> users:Vector<User> = payments.ConnectedStarRefBots;
payments.suggestedStarRefBots#b4d5d859 flags:# count:int suggested_bots:Vector<StarRefProgram> users:Vector<User> next_offset:flags.0?string = payments.SuggestedStarRefBots;
starsAmount#bbb6b4a3 amount:long nanos:int = StarsAmount;
messages.foundStickersNotModified#6010c534 flags:# next_offset:flags.0?int = messages.FoundStickers;
messages.foundStickers#82c9e290 flags:# next_offset:flags.0?int hash:long stickers:Vector<Document> = messages.FoundStickers;
botVerifierSettings#b0cd6617 flags:# can_modify_custom_description:flags.1?true icon:long company:string custom_description:flags.0?string = BotVerifierSettings;
botVerification#f93cd45c bot_id:long icon:long description:string = BotVerification;
starGiftAttributeModel#39d99013 name:string document:Document rarity_permille:int = StarGiftAttribute;
starGiftAttributePattern#13acff19 name:string document:Document rarity_permille:int = StarGiftAttribute;
starGiftAttributeBackdrop#94271762 name:string center_color:int edge_color:int pattern_color:int text_color:int rarity_permille:int = StarGiftAttribute;
starGiftAttributeOriginalDetails#e0bff26c flags:# sender_id:flags.0?Peer recipient_id:Peer date:int message:flags.1?TextWithEntities = StarGiftAttribute;
payments.starGiftUpgradePreview#167bd90b sample_attributes:Vector<StarGiftAttribute> = payments.StarGiftUpgradePreview;
users.users#62d706b8 users:Vector<User> = users.Users;
users.usersSlice#315a4974 count:int users:Vector<User> = users.Users;
payments.uniqueStarGift#caa2f60b gift:StarGift users:Vector<User> = payments.UniqueStarGift;
messages.webPagePreview#b53e8b21 media:MessageMedia users:Vector<User> = messages.WebPagePreview;
savedStarGift#6056dba5 flags:# name_hidden:flags.0?true unsaved:flags.5?true refunded:flags.9?true can_upgrade:flags.10?true from_id:flags.1?Peer date:int gift:StarGift message:flags.2?TextWithEntities msg_id:flags.3?int saved_id:flags.11?long convert_stars:flags.4?long upgrade_stars:flags.6?long can_export_at:flags.7?int transfer_stars:flags.8?long = SavedStarGift;
payments.savedStarGifts#95f389b1 flags:# count:int chat_notifications_enabled:flags.1?Bool gifts:Vector<SavedStarGift> next_offset:flags.0?string chats:Vector<Chat> users:Vector<User> = payments.SavedStarGifts;
inputSavedStarGiftUser#69279795 msg_id:int = InputSavedStarGift;
inputSavedStarGiftChat#f101aa7f peer:InputPeer saved_id:long = InputSavedStarGift;
payments.starGiftWithdrawalUrl#84aa3a9c url:string = payments.StarGiftWithdrawalUrl;
---functions---
invokeAfterMsg#cb9f372d {X:Type} msg_id:long query:!X = X;
invokeAfterMsgs#3dc4b4f0 {X:Type} msg_ids:Vector<long> query:!X = X;
initConnection#c1cd5ea9 {X:Type} flags:# api_id:int device_model:string system_version:string app_version:string system_lang_code:string lang_pack:string lang_code:string proxy:flags.0?InputClientProxy params:flags.1?JSONValue query:!X = X;
invokeWithLayer#da9b0d0d {X:Type} layer:int query:!X = X;
invokeWithoutUpdates#bf9459b7 {X:Type} query:!X = X;
invokeWithMessagesRange#365275f2 {X:Type} range:MessageRange query:!X = X;
invokeWithTakeout#aca9fd2e {X:Type} takeout_id:long query:!X = X;
invokeWithBusinessConnection#dd289f8e {X:Type} connection_id:string query:!X = X;
invokeWithGooglePlayIntegrity#1df92984 {X:Type} nonce:string token:string query:!X = X;
invokeWithApnsSecret#0dae54f8 {X:Type} nonce:string secret:string query:!X = X;
auth.sendCode#a677244f phone_number:string api_id:int api_hash:string settings:CodeSettings = auth.SentCode;
auth.signUp#aac7b717 flags:# no_joined_notifications:flags.0?true phone_number:string phone_code_hash:string first_name:string last_name:string = auth.Authorization;
auth.signIn#8d52a951 flags:# phone_number:string phone_code_hash:string phone_code:flags.0?string email_verification:flags.1?EmailVerification = auth.Authorization;
auth.logOut#3e72ba19 = auth.LoggedOut;
auth.resetAuthorizations#9fab0d1a = Bool;
auth.exportAuthorization#e5bfffcd dc_id:int = auth.ExportedAuthorization;
auth.importAuthorization#a57a7dad id:long bytes:bytes = auth.Authorization;
auth.bindTempAuthKey#cdd42a05 perm_auth_key_id:long nonce:long expires_at:int encrypted_message:bytes = Bool;
auth.importBotAuthorization#67a3ff2c flags:int api_id:int api_hash:string bot_auth_token:string = auth.Authorization;
auth.checkPassword#d18b4d16 password:InputCheckPasswordSRP = auth.Authorization;
auth.requestPasswordRecovery#d897bc66 = auth.PasswordRecovery;
auth.recoverPassword#37096c70 flags:# code:string new_settings:flags.0?account.PasswordInputSettings = auth.Authorization;
auth.resendCode#cae47523 flags:# phone_number:string phone_code_hash:string reason:flags.0?string = auth.SentCode;
auth.cancelCode#1f040578 phone_number:string phone_code_hash:string = Bool;
auth.dropTempAuthKeys#8e48a188 except_auth_keys:Vector<long> = Bool;
auth.exportLoginToken#b7e085fe api_id:int api_hash:string except_ids:Vector<long> = auth.LoginToken;
auth.importLoginToken#95ac5ce4 token:bytes = auth.LoginToken;
auth.acceptLoginToken#e894ad4d token:bytes = Authorization;
auth.checkRecoveryPassword#d36bf79 code:string = Bool;
auth.importWebTokenAuthorization#2db873a9 api_id:int api_hash:string web_auth_token:string = auth.Authorization;
auth.requestFirebaseSms#8e39261e flags:# phone_number:string phone_code_hash:string safety_net_token:flags.0?string play_integrity_token:flags.2?string ios_push_secret:flags.1?string = Bool;
auth.resetLoginEmail#7e960193 phone_number:string phone_code_hash:string = auth.SentCode;
auth.reportMissingCode#cb9deff6 phone_number:string phone_code_hash:string mnc:string = Bool;
account.registerDevice#ec86017a flags:# no_muted:flags.0?true token_type:int token:string app_sandbox:Bool secret:bytes other_uids:Vector<long> = Bool;
account.unregisterDevice#6a0d3206 token_type:int token:string other_uids:Vector<long> = Bool;
account.updateNotifySettings#84be5b93 peer:InputNotifyPeer settings:InputPeerNotifySettings = Bool;
account.getNotifySettings#12b3ad31 peer:InputNotifyPeer = PeerNotifySettings;
account.resetNotifySettings#db7e1747 = Bool;
account.updateProfile#78515775 flags:# first_name:flags.0?string last_name:flags.1?string about:flags.2?string = User;
account.updateStatus#6628562c offline:Bool = Bool;
account.getWallPapers#7967d36 hash:long = account.WallPapers;
account.reportPeer#c5ba3d86 peer:InputPeer reason:ReportReason message:string = Bool;
account.checkUsername#2714d86c username:string = Bool;
account.updateUsername#3e0bdd7c username:string = User;
account.getPrivacy#dadbc950 key:InputPrivacyKey = account.PrivacyRules;
account.setPrivacy#c9f81ce8 key:InputPrivacyKey rules:Vector<InputPrivacyRule> = account.PrivacyRules;
account.deleteAccount#a2c0cf74 flags:# reason:string password:flags.0?InputCheckPasswordSRP = Bool;
account.getAccountTTL#8fc711d = AccountDaysTTL;
account.setAccountTTL#2442485e ttl:AccountDaysTTL = Bool;
account.sendChangePhoneCode#82574ae5 phone_number:string settings:CodeSettings = auth.SentCode;
account.changePhone#70c32edb phone_number:string phone_code_hash:string phone_code:string = User;
account.updateDeviceLocked#38df3532 period:int = Bool;
account.getAuthorizations#e320c158 = account.Authorizations;
account.resetAuthorization#df77f3bc hash:long = Bool;
account.getPassword#548a30f5 = account.Password;
account.getPasswordSettings#9cd4eaf9 password:InputCheckPasswordSRP = account.PasswordSettings;
account.updatePasswordSettings#a59b102f password:InputCheckPasswordSRP new_settings:account.PasswordInputSettings = Bool;
account.sendConfirmPhoneCode#1b3faa88 hash:string settings:CodeSettings = auth.SentCode;
account.confirmPhone#5f2178c3 phone_code_hash:string phone_code:string = Bool;
account.getTmpPassword#449e0b51 password:InputCheckPasswordSRP period:int = account.TmpPassword;
account.getWebAuthorizations#182e6d6f = account.WebAuthorizations;
account.resetWebAuthorization#2d01b9ef hash:long = Bool;
account.resetWebAuthorizations#682d2594 = Bool;
account.getAllSecureValues#b288bc7d = Vector<SecureValue>;
account.getSecureValue#73665bc2 types:Vector<SecureValueType> = Vector<SecureValue>;
account.saveSecureValue#899fe31d value:InputSecureValue secure_secret_id:long = SecureValue;
account.deleteSecureValue#b880bc4b types:Vector<SecureValueType> = Bool;
account.getAuthorizationForm#a929597a bot_id:long scope:string public_key:string = account.AuthorizationForm;
account.acceptAuthorization#f3ed4c73 bot_id:long scope:string public_key:string value_hashes:Vector<SecureValueHash> credentials:SecureCredentialsEncrypted = Bool;
account.sendVerifyPhoneCode#a5a356f9 phone_number:string settings:CodeSettings = auth.SentCode;
account.verifyPhone#4dd3a7f6 phone_number:string phone_code_hash:string phone_code:string = Bool;
account.sendVerifyEmailCode#98e037bb purpose:EmailVerifyPurpose email:string = account.SentEmailCode;
account.verifyEmail#32da4cf purpose:EmailVerifyPurpose verification:EmailVerification = account.EmailVerified;
account.initTakeoutSession#8ef3eab0 flags:# contacts:flags.0?true message_users:flags.1?true message_chats:flags.2?true message_megagroups:flags.3?true message_channels:flags.4?true files:flags.5?true file_max_size:flags.5?long = account.Takeout;
account.finishTakeoutSession#1d2652ee flags:# success:flags.0?true = Bool;
account.confirmPasswordEmail#8fdf1920 code:string = Bool;
account.resendPasswordEmail#7a7f2a15 = Bool;
account.cancelPasswordEmail#c1cbd5b6 = Bool;
account.getContactSignUpNotification#9f07c728 = Bool;
account.setContactSignUpNotification#cff43f61 silent:Bool = Bool;
account.getNotifyExceptions#53577479 flags:# compare_sound:flags.1?true compare_stories:flags.2?true peer:flags.0?InputNotifyPeer = Updates;
account.getWallPaper#fc8ddbea wallpaper:InputWallPaper = WallPaper;
account.uploadWallPaper#e39a8f03 flags:# for_chat:flags.0?true file:InputFile mime_type:string settings:WallPaperSettings = WallPaper;
account.saveWallPaper#6c5a5b37 wallpaper:InputWallPaper unsave:Bool settings:WallPaperSettings = Bool;
account.installWallPaper#feed5769 wallpaper:InputWallPaper settings:WallPaperSettings = Bool;
account.resetWallPapers#bb3b9804 = Bool;
account.getAutoDownloadSettings#56da0b3f = account.AutoDownloadSettings;
account.saveAutoDownloadSettings#76f36233 flags:# low:flags.0?true high:flags.1?true settings:AutoDownloadSettings = Bool;
account.uploadTheme#1c3db333 flags:# file:InputFile thumb:flags.0?InputFile file_name:string mime_type:string = Document;
account.createTheme#652e4400 flags:# slug:string title:string document:flags.2?InputDocument settings:flags.3?Vector<InputThemeSettings> = Theme;
account.updateTheme#2bf40ccc flags:# format:string theme:InputTheme slug:flags.0?string title:flags.1?string document:flags.2?InputDocument settings:flags.3?Vector<InputThemeSettings> = Theme;
account.saveTheme#f257106c theme:InputTheme unsave:Bool = Bool;
account.installTheme#c727bb3b flags:# dark:flags.0?true theme:flags.1?InputTheme format:flags.2?string base_theme:flags.3?BaseTheme = Bool;
account.getTheme#3a5869ec format:string theme:InputTheme = Theme;
account.getThemes#7206e458 format:string hash:long = account.Themes;
account.setContentSettings#b574b16b flags:# sensitive_enabled:flags.0?true = Bool;
account.getContentSettings#8b9b4dae = account.ContentSettings;
account.getMultiWallPapers#65ad71dc wallpapers:Vector<InputWallPaper> = Vector<WallPaper>;
account.getGlobalPrivacySettings#eb2b4cf6 = GlobalPrivacySettings;
account.setGlobalPrivacySettings#1edaaac2 settings:GlobalPrivacySettings = GlobalPrivacySettings;
account.reportProfilePhoto#fa8cc6f5 peer:InputPeer photo_id:InputPhoto reason:ReportReason message:string = Bool;
account.resetPassword#9308ce1b = account.ResetPasswordResult;
account.declinePasswordReset#4c9409f6 = Bool;
account.getChatThemes#d638de89 hash:long = account.Themes;
account.setAuthorizationTTL#bf899aa0 authorization_ttl_days:int = Bool;
account.changeAuthorizationSettings#40f48462 flags:# confirmed:flags.3?true hash:long encrypted_requests_disabled:flags.0?Bool call_requests_disabled:flags.1?Bool = Bool;
account.getSavedRingtones#e1902288 hash:long = account.SavedRingtones;
account.saveRingtone#3dea5b03 id:InputDocument unsave:Bool = account.SavedRingtone;
account.uploadRingtone#831a83a2 file:InputFile file_name:string mime_type:string = Document;
account.updateEmojiStatus#fbd3de6b emoji_status:EmojiStatus = Bool;
account.getDefaultEmojiStatuses#d6753386 hash:long = account.EmojiStatuses;
account.getRecentEmojiStatuses#f578105 hash:long = account.EmojiStatuses;
account.clearRecentEmojiStatuses#18201aae = Bool;
account.reorderUsernames#ef500eab order:Vector<string> = Bool;
account.toggleUsername#58d6b376 username:string active:Bool = Bool;
account.getDefaultProfilePhotoEmojis#e2750328 hash:long = EmojiList;
account.getDefaultGroupPhotoEmojis#915860ae hash:long = EmojiList;
account.getAutoSaveSettings#adcbbcda = account.AutoSaveSettings;
account.saveAutoSaveSettings#d69b8361 flags:# users:flags.0?true chats:flags.1?true broadcasts:flags.2?true peer:flags.3?InputPeer settings:AutoSaveSettings = Bool;
account.deleteAutoSaveExceptions#53bc0020 = Bool;
account.invalidateSignInCodes#ca8ae8ba codes:Vector<string> = Bool;
account.updateColor#7cefa15d flags:# for_profile:flags.1?true color:flags.2?int background_emoji_id:flags.0?long = Bool;
account.getDefaultBackgroundEmojis#a60ab9ce hash:long = EmojiList;
account.getChannelDefaultEmojiStatuses#7727a7d5 hash:long = account.EmojiStatuses;
account.getChannelRestrictedStatusEmojis#35a9e0d5 hash:long = EmojiList;
account.updateBusinessWorkHours#4b00e066 flags:# business_work_hours:flags.0?BusinessWorkHours = Bool;
account.updateBusinessLocation#9e6b131a flags:# geo_point:flags.1?InputGeoPoint address:flags.0?string = Bool;
account.updateBusinessGreetingMessage#66cdafc4 flags:# message:flags.0?InputBusinessGreetingMessage = Bool;
account.updateBusinessAwayMessage#a26a7fa5 flags:# message:flags.0?InputBusinessAwayMessage = Bool;
account.updateConnectedBot#43d8521d flags:# can_reply:flags.0?true deleted:flags.1?true bot:InputUser recipients:InputBusinessBotRecipients = Updates;
account.getConnectedBots#4ea4c80f = account.ConnectedBots;
account.getBotBusinessConnection#76a86270 connection_id:string = Updates;
account.updateBusinessIntro#a614d034 flags:# intro:flags.0?InputBusinessIntro = Bool;
account.toggleConnectedBotPaused#646e1097 peer:InputPeer paused:Bool = Bool;
account.disablePeerConnectedBot#5e437ed9 peer:InputPeer = Bool;
account.updateBirthday#cc6e0c11 flags:# birthday:flags.0?Birthday = Bool;
account.createBusinessChatLink#8851e68e link:InputBusinessChatLink = BusinessChatLink;
account.editBusinessChatLink#8c3410af slug:string link:InputBusinessChatLink = BusinessChatLink;
account.deleteBusinessChatLink#60073674 slug:string = Bool;
account.getBusinessChatLinks#6f70dde1 = account.BusinessChatLinks;
account.resolveBusinessChatLink#5492e5ee slug:string = account.ResolvedBusinessChatLinks;
account.updatePersonalChannel#d94305e0 channel:InputChannel = Bool;
account.toggleSponsoredMessages#b9d9a38d enabled:Bool = Bool;
account.getReactionsNotifySettings#6dd654c = ReactionsNotifySettings;
account.setReactionsNotifySettings#316ce548 settings:ReactionsNotifySettings = ReactionsNotifySettings;
account.getCollectibleEmojiStatuses#2e7b4543 hash:long = account.EmojiStatuses;
users.getUsers#d91a548 id:Vector<InputUser> = Vector<User>;
users.getFullUser#b60f5918 id:InputUser = users.UserFull;
users.setSecureValueErrors#90c894b5 id:InputUser errors:Vector<SecureValueError> = Bool;
users.getIsPremiumRequiredToContact#a622aa10 id:Vector<InputUser> = Vector<Bool>;
contacts.getContactIDs#7adc669d hash:long = Vector<int>;
contacts.getStatuses#c4a353ee = Vector<ContactStatus>;
contacts.getContacts#5dd69e12 hash:long = contacts.Contacts;
contacts.importContacts#2c800be5 contacts:Vector<InputContact> = contacts.ImportedContacts;
contacts.deleteContacts#96a0e00 id:Vector<InputUser> = Updates;
contacts.deleteByPhones#1013fd9e phones:Vector<string> = Bool;
contacts.block#2e2e8734 flags:# my_stories_from:flags.0?true id:InputPeer = Bool;
contacts.unblock#b550d328 flags:# my_stories_from:flags.0?true id:InputPeer = Bool;
contacts.getBlocked#9a868f80 flags:# my_stories_from:flags.0?true offset:int limit:int = contacts.Blocked;
contacts.search#11f812d8 q:string limit:int = contacts.Found;
contacts.resolveUsername#725afbbc flags:# username:string referer:flags.0?string = contacts.ResolvedPeer;
contacts.getTopPeers#973478b6 flags:# correspondents:flags.0?true bots_pm:flags.1?true bots_inline:flags.2?true phone_calls:flags.3?true forward_users:flags.4?true forward_chats:flags.5?true groups:flags.10?true channels:flags.15?true bots_app:flags.16?true offset:int limit:int hash:long = contacts.TopPeers;
contacts.resetTopPeerRating#1ae373ac category:TopPeerCategory peer:InputPeer = Bool;
contacts.resetSaved#879537f1 = Bool;
contacts.getSaved#82f1e39f = Vector<SavedContact>;
contacts.toggleTopPeers#8514bdda enabled:Bool = Bool;
contacts.addContact#e8f463d0 flags:# add_phone_privacy_exception:flags.0?true id:InputUser first_name:string last_name:string phone:string = Updates;
contacts.acceptContact#f831a20f id:InputUser = Updates;
contacts.getLocated#d348bc44 flags:# background:flags.1?true geo_point:InputGeoPoint self_expires:flags.0?int = Updates;
contacts.blockFromReplies#29a8962c flags:# delete_message:flags.0?true delete_history:flags.1?true report_spam:flags.2?true msg_id:int = Updates;
contacts.resolvePhone#8af94344 phone:string = contacts.ResolvedPeer;
contacts.exportContactToken#f8654027 = ExportedContactToken;
contacts.importContactToken#13005788 token:string = User;
contacts.editCloseFriends#ba6705f0 id:Vector<long> = Bool;
contacts.setBlocked#94c65c76 flags:# my_stories_from:flags.0?true id:Vector<InputPeer> limit:int = Bool;
contacts.getBirthdays#daeda864 = contacts.ContactBirthdays;
messages.getMessages#63c66506 id:Vector<InputMessage> = messages.Messages;
messages.getDialogs#a0f4cb4f flags:# exclude_pinned:flags.0?true folder_id:flags.1?int offset_date:int offset_id:int offset_peer:InputPeer limit:int hash:long = messages.Dialogs;
messages.getHistory#4423e6c5 peer:InputPeer offset_id:int offset_date:int add_offset:int limit:int max_id:int min_id:int hash:long = messages.Messages;
messages.search#29ee847a flags:# peer:InputPeer q:string from_id:flags.0?InputPeer saved_peer_id:flags.2?InputPeer saved_reaction:flags.3?Vector<Reaction> top_msg_id:flags.1?int filter:MessagesFilter min_date:int max_date:int offset_id:int add_offset:int limit:int max_id:int min_id:int hash:long = messages.Messages;
messages.readHistory#e306d3a peer:InputPeer max_id:int = messages.AffectedMessages;
messages.deleteHistory#b08f922a flags:# just_clear:flags.0?true revoke:flags.1?true peer:InputPeer max_id:int min_date:flags.2?int max_date:flags.3?int = messages.AffectedHistory;
messages.deleteMessages#e58e95d2 flags:# revoke:flags.0?true id:Vector<int> = messages.AffectedMessages;
messages.receivedMessages#5a954c0 max_id:int = Vector<ReceivedNotifyMessage>;
messages.setTyping#58943ee2 flags:# peer:InputPeer top_msg_id:flags.0?int action:SendMessageAction = Bool;
messages.sendMessage#983f9745 flags:# no_webpage:flags.1?true silent:flags.5?true background:flags.6?true clear_draft:flags.7?true noforwards:flags.14?true update_stickersets_order:flags.15?true invert_media:flags.16?true allow_paid_floodskip:flags.19?true peer:InputPeer reply_to:flags.0?InputReplyTo message:string random_id:long reply_markup:flags.2?ReplyMarkup entities:flags.3?Vector<MessageEntity> schedule_date:flags.10?int send_as:flags.13?InputPeer quick_reply_shortcut:flags.17?InputQuickReplyShortcut effect:flags.18?long = Updates;
messages.sendMedia#7852834e flags:# silent:flags.5?true background:flags.6?true clear_draft:flags.7?true noforwards:flags.14?true update_stickersets_order:flags.15?true invert_media:flags.16?true allow_paid_floodskip:flags.19?true peer:InputPeer reply_to:flags.0?InputReplyTo media:InputMedia message:string random_id:long reply_markup:flags.2?ReplyMarkup entities:flags.3?Vector<MessageEntity> schedule_date:flags.10?int send_as:flags.13?InputPeer quick_reply_shortcut:flags.17?InputQuickReplyShortcut effect:flags.18?long = Updates;
messages.forwardMessages#6d74da08 flags:# silent:flags.5?true background:flags.6?true with_my_score:flags.8?true drop_author:flags.11?true drop_media_captions:flags.12?true noforwards:flags.14?true allow_paid_floodskip:flags.19?true from_peer:InputPeer id:Vector<int> random_id:Vector<long> to_peer:InputPeer top_msg_id:flags.9?int schedule_date:flags.10?int send_as:flags.13?InputPeer quick_reply_shortcut:flags.17?InputQuickReplyShortcut video_timestamp:flags.20?int = Updates;
messages.reportSpam#cf1592db peer:InputPeer = Bool;
messages.getPeerSettings#efd9a6a2 peer:InputPeer = messages.PeerSettings;
messages.report#fc78af9b peer:InputPeer id:Vector<int> option:bytes message:string = ReportResult;
messages.getChats#49e9528f id:Vector<long> = messages.Chats;
messages.getFullChat#aeb00b34 chat_id:long = messages.ChatFull;
messages.editChatTitle#73783ffd chat_id:long title:string = Updates;
messages.editChatPhoto#35ddd674 chat_id:long photo:InputChatPhoto = Updates;
messages.addChatUser#cbc6d107 chat_id:long user_id:InputUser fwd_limit:int = messages.InvitedUsers;
messages.deleteChatUser#a2185cab flags:# revoke_history:flags.0?true chat_id:long user_id:InputUser = Updates;
messages.createChat#92ceddd4 flags:# users:Vector<InputUser> title:string ttl_period:flags.0?int = messages.InvitedUsers;
messages.getDhConfig#26cf8950 version:int random_length:int = messages.DhConfig;
messages.requestEncryption#f64daf43 user_id:InputUser random_id:int g_a:bytes = EncryptedChat;
messages.acceptEncryption#3dbc0415 peer:InputEncryptedChat g_b:bytes key_fingerprint:long = EncryptedChat;
messages.discardEncryption#f393aea0 flags:# delete_history:flags.0?true chat_id:int = Bool;
messages.setEncryptedTyping#791451ed peer:InputEncryptedChat typing:Bool = Bool;
messages.readEncryptedHistory#7f4b690a peer:InputEncryptedChat max_date:int = Bool;
messages.sendEncrypted#44fa7a15 flags:# silent:flags.0?true peer:InputEncryptedChat random_id:long data:bytes = messages.SentEncryptedMessage;
messages.sendEncryptedFile#5559481d flags:# silent:flags.0?true peer:InputEncryptedChat random_id:long data:bytes file:InputEncryptedFile = messages.SentEncryptedMessage;
messages.sendEncryptedService#32d439a4 peer:InputEncryptedChat random_id:long data:bytes = messages.SentEncryptedMessage;
messages.receivedQueue#55a5bb66 max_qts:int = Vector<long>;
messages.reportEncryptedSpam#4b0c8c0f peer:InputEncryptedChat = Bool;
messages.readMessageContents#36a73f77 id:Vector<int> = messages.AffectedMessages;
messages.getStickers#d5a5d3a1 emoticon:string hash:long = messages.Stickers;
messages.getAllStickers#b8a0a1a8 hash:long = messages.AllStickers;
messages.getWebPagePreview#570d6f6f flags:# message:string entities:flags.3?Vector<MessageEntity> = messages.WebPagePreview;
messages.exportChatInvite#a455de90 flags:# legacy_revoke_permanent:flags.2?true request_needed:flags.3?true peer:InputPeer expire_date:flags.0?int usage_limit:flags.1?int title:flags.4?string subscription_pricing:flags.5?StarsSubscriptionPricing = ExportedChatInvite;
messages.checkChatInvite#3eadb1bb hash:string = ChatInvite;
messages.importChatInvite#6c50051c hash:string = Updates;
messages.getStickerSet#c8a0ec74 stickerset:InputStickerSet hash:int = messages.StickerSet;
messages.installStickerSet#c78fe460 stickerset:InputStickerSet archived:Bool = messages.StickerSetInstallResult;
messages.uninstallStickerSet#f96e55de stickerset:InputStickerSet = Bool;
messages.startBot#e6df7378 bot:InputUser peer:InputPeer random_id:long start_param:string = Updates;
messages.getMessagesViews#5784d3e1 peer:InputPeer id:Vector<int> increment:Bool = messages.MessageViews;
messages.editChatAdmin#a85bd1c2 chat_id:long user_id:InputUser is_admin:Bool = Bool;
messages.migrateChat#a2875319 chat_id:long = Updates;
messages.searchGlobal#4bc6589a flags:# broadcasts_only:flags.1?true groups_only:flags.2?true users_only:flags.3?true folder_id:flags.0?int q:string filter:MessagesFilter min_date:int max_date:int offset_rate:int offset_peer:InputPeer offset_id:int limit:int = messages.Messages;
messages.reorderStickerSets#78337739 flags:# masks:flags.0?true emojis:flags.1?true order:Vector<long> = Bool;
messages.getDocumentByHash#b1f2061f sha256:bytes size:long mime_type:string = Document;
messages.getSavedGifs#5cf09635 hash:long = messages.SavedGifs;
messages.saveGif#327a30cb id:InputDocument unsave:Bool = Bool;
messages.getInlineBotResults#514e999d flags:# bot:InputUser peer:InputPeer geo_point:flags.0?InputGeoPoint query:string offset:string = messages.BotResults;
messages.setInlineBotResults#bb12a419 flags:# gallery:flags.0?true private:flags.1?true query_id:long results:Vector<InputBotInlineResult> cache_time:int next_offset:flags.2?string switch_pm:flags.3?InlineBotSwitchPM switch_webview:flags.4?InlineBotWebView = Bool;
messages.sendInlineBotResult#3ebee86a flags:# silent:flags.5?true background:flags.6?true clear_draft:flags.7?true hide_via:flags.11?true peer:InputPeer reply_to:flags.0?InputReplyTo random_id:long query_id:long id:string schedule_date:flags.10?int send_as:flags.13?InputPeer quick_reply_shortcut:flags.17?InputQuickReplyShortcut = Updates;
messages.getMessageEditData#fda68d36 peer:InputPeer id:int = messages.MessageEditData;
messages.editMessage#dfd14005 flags:# no_webpage:flags.1?true invert_media:flags.16?true peer:InputPeer id:int message:flags.11?string media:flags.14?InputMedia reply_markup:flags.2?ReplyMarkup entities:flags.3?Vector<MessageEntity> schedule_date:flags.15?int quick_reply_shortcut_id:flags.17?int = Updates;
messages.editInlineBotMessage#83557dba flags:# no_webpage:flags.1?true invert_media:flags.16?true id:InputBotInlineMessageID message:flags.11?string media:flags.14?InputMedia reply_markup:flags.2?ReplyMarkup entities:flags.3?Vector<MessageEntity> = Bool;
messages.getBotCallbackAnswer#9342ca07 flags:# game:flags.1?true peer:InputPeer msg_id:int data:flags.0?bytes password:flags.2?InputCheckPasswordSRP = messages.BotCallbackAnswer;
messages.setBotCallbackAnswer#d58f130a flags:# alert:flags.1?true query_id:long message:flags.0?string url:flags.2?string cache_time:int = Bool;
messages.getPeerDialogs#e470bcfd peers:Vector<InputDialogPeer> = messages.PeerDialogs;
messages.saveDraft#d372c5ce flags:# no_webpage:flags.1?true invert_media:flags.6?true reply_to:flags.4?InputReplyTo peer:InputPeer message:string entities:flags.3?Vector<MessageEntity> media:flags.5?InputMedia effect:flags.7?long = Bool;
messages.getAllDrafts#6a3f8d65 = Updates;
messages.getFeaturedStickers#64780b14 hash:long = messages.FeaturedStickers;
messages.readFeaturedStickers#5b118126 id:Vector<long> = Bool;
messages.getRecentStickers#9da9403b flags:# attached:flags.0?true hash:long = messages.RecentStickers;
messages.saveRecentSticker#392718f8 flags:# attached:flags.0?true id:InputDocument unsave:Bool = Bool;
messages.clearRecentStickers#8999602d flags:# attached:flags.0?true = Bool;
messages.getArchivedStickers#57f17692 flags:# masks:flags.0?true emojis:flags.1?true offset_id:long limit:int = messages.ArchivedStickers;
messages.getMaskStickers#640f82b8 hash:long = messages.AllStickers;
messages.getAttachedStickers#cc5b67cc media:InputStickeredMedia = Vector<StickerSetCovered>;
messages.setGameScore#8ef8ecc0 flags:# edit_message:flags.0?true force:flags.1?true peer:InputPeer id:int user_id:InputUser score:int = Updates;
messages.setInlineGameScore#15ad9f64 flags:# edit_message:flags.0?true force:flags.1?true id:InputBotInlineMessageID user_id:InputUser score:int = Bool;
messages.getGameHighScores#e822649d peer:InputPeer id:int user_id:InputUser = messages.HighScores;
messages.getInlineGameHighScores#f635e1b id:InputBotInlineMessageID user_id:InputUser = messages.HighScores;
messages.getCommonChats#e40ca104 user_id:InputUser max_id:long limit:int = messages.Chats;
messages.getWebPage#8d9692a3 url:string hash:int = messages.WebPage;
messages.toggleDialogPin#a731e257 flags:# pinned:flags.0?true peer:InputDialogPeer = Bool;
messages.reorderPinnedDialogs#3b1adf37 flags:# force:flags.0?true folder_id:int order:Vector<InputDialogPeer> = Bool;
messages.getPinnedDialogs#d6b94df2 folder_id:int = messages.PeerDialogs;
messages.setBotShippingResults#e5f672fa flags:# query_id:long error:flags.0?string shipping_options:flags.1?Vector<ShippingOption> = Bool;
messages.setBotPrecheckoutResults#9c2dd95 flags:# success:flags.1?true query_id:long error:flags.0?string = Bool;
messages.uploadMedia#14967978 flags:# business_connection_id:flags.0?string peer:InputPeer media:InputMedia = MessageMedia;
messages.sendScreenshotNotification#a1405817 peer:InputPeer reply_to:InputReplyTo random_id:long = Updates;
messages.getFavedStickers#4f1aaa9 hash:long = messages.FavedStickers;
messages.faveSticker#b9ffc55b id:InputDocument unfave:Bool = Bool;
messages.getUnreadMentions#f107e790 flags:# peer:InputPeer top_msg_id:flags.0?int offset_id:int add_offset:int limit:int max_id:int min_id:int = messages.Messages;
messages.readMentions#36e5bf4d flags:# peer:InputPeer top_msg_id:flags.0?int = messages.AffectedHistory;
messages.getRecentLocations#702a40e0 peer:InputPeer limit:int hash:long = messages.Messages;
messages.sendMultiMedia#37b74355 flags:# silent:flags.5?true background:flags.6?true clear_draft:flags.7?true noforwards:flags.14?true update_stickersets_order:flags.15?true invert_media:flags.16?true allow_paid_floodskip:flags.19?true peer:InputPeer reply_to:flags.0?InputReplyTo multi_media:Vector<InputSingleMedia> schedule_date:flags.10?int send_as:flags.13?InputPeer quick_reply_shortcut:flags.17?InputQuickReplyShortcut effect:flags.18?long = Updates;
messages.uploadEncryptedFile#5057c497 peer:InputEncryptedChat file:InputEncryptedFile = EncryptedFile;
messages.searchStickerSets#35705b8a flags:# exclude_featured:flags.0?true q:string hash:long = messages.FoundStickerSets;
messages.getSplitRanges#1cff7e08 = Vector<MessageRange>;
messages.markDialogUnread#c286d98f flags:# unread:flags.0?true peer:InputDialogPeer = Bool;
messages.getDialogUnreadMarks#22e24e22 = Vector<DialogPeer>;
messages.clearAllDrafts#7e58ee9c = Bool;
messages.updatePinnedMessage#d2aaf7ec flags:# silent:flags.0?true unpin:flags.1?true pm_oneside:flags.2?true peer:InputPeer id:int = Updates;
messages.sendVote#10ea6184 peer:InputPeer msg_id:int options:Vector<bytes> = Updates;
messages.getPollResults#73bb643b peer:InputPeer msg_id:int = Updates;
messages.getOnlines#6e2be050 peer:InputPeer = ChatOnlines;
messages.editChatAbout#def60797 peer:InputPeer about:string = Bool;
messages.editChatDefaultBannedRights#a5866b41 peer:InputPeer banned_rights:ChatBannedRights = Updates;
messages.getEmojiKeywords#35a0e062 lang_code:string = EmojiKeywordsDifference;
messages.getEmojiKeywordsDifference#1508b6af lang_code:string from_version:int = EmojiKeywordsDifference;
messages.getEmojiKeywordsLanguages#4e9963b2 lang_codes:Vector<string> = Vector<EmojiLanguage>;
messages.getEmojiURL#d5b10c26 lang_code:string = EmojiURL;
messages.getSearchCounters#1bbcf300 flags:# peer:InputPeer saved_peer_id:flags.2?InputPeer top_msg_id:flags.0?int filters:Vector<MessagesFilter> = Vector<messages.SearchCounter>;
messages.requestUrlAuth#198fb446 flags:# peer:flags.1?InputPeer msg_id:flags.1?int button_id:flags.1?int url:flags.2?string = UrlAuthResult;
messages.acceptUrlAuth#b12c7125 flags:# write_allowed:flags.0?true peer:flags.1?InputPeer msg_id:flags.1?int button_id:flags.1?int url:flags.2?string = UrlAuthResult;
messages.hidePeerSettingsBar#4facb138 peer:InputPeer = Bool;
messages.getScheduledHistory#f516760b peer:InputPeer hash:long = messages.Messages;
messages.getScheduledMessages#bdbb0464 peer:InputPeer id:Vector<int> = messages.Messages;
messages.sendScheduledMessages#bd38850a peer:InputPeer id:Vector<int> = Updates;
messages.deleteScheduledMessages#59ae2b16 peer:InputPeer id:Vector<int> = Updates;
messages.getPollVotes#b86e380e flags:# peer:InputPeer id:int option:flags.0?bytes offset:flags.1?string limit:int = messages.VotesList;
messages.toggleStickerSets#b5052fea flags:# uninstall:flags.0?true archive:flags.1?true unarchive:flags.2?true stickersets:Vector<InputStickerSet> = Bool;
messages.getDialogFilters#efd48c89 = messages.DialogFilters;
messages.getSuggestedDialogFilters#a29cd42c = Vector<DialogFilterSuggested>;
messages.updateDialogFilter#1ad4a04a flags:# id:int filter:flags.0?DialogFilter = Bool;
messages.updateDialogFiltersOrder#c563c1e4 order:Vector<int> = Bool;
messages.getOldFeaturedStickers#7ed094a1 offset:int limit:int hash:long = messages.FeaturedStickers;
messages.getReplies#22ddd30c peer:InputPeer msg_id:int offset_id:int offset_date:int add_offset:int limit:int max_id:int min_id:int hash:long = messages.Messages;
messages.getDiscussionMessage#446972fd peer:InputPeer msg_id:int = messages.DiscussionMessage;
messages.readDiscussion#f731a9f4 peer:InputPeer msg_id:int read_max_id:int = Bool;
messages.unpinAllMessages#ee22b9a8 flags:# peer:InputPeer top_msg_id:flags.0?int = messages.AffectedHistory;
messages.deleteChat#5bd0ee50 chat_id:long = Bool;
messages.deletePhoneCallHistory#f9cbe409 flags:# revoke:flags.0?true = messages.AffectedFoundMessages;
messages.checkHistoryImport#43fe19f3 import_head:string = messages.HistoryImportParsed;
messages.initHistoryImport#34090c3b peer:InputPeer file:InputFile media_count:int = messages.HistoryImport;
messages.uploadImportedMedia#2a862092 peer:InputPeer import_id:long file_name:string media:InputMedia = MessageMedia;
messages.startHistoryImport#b43df344 peer:InputPeer import_id:long = Bool;
messages.getExportedChatInvites#a2b5a3f6 flags:# revoked:flags.3?true peer:InputPeer admin_id:InputUser offset_date:flags.2?int offset_link:flags.2?string limit:int = messages.ExportedChatInvites;
messages.getExportedChatInvite#73746f5c peer:InputPeer link:string = messages.ExportedChatInvite;
messages.editExportedChatInvite#bdca2f75 flags:# revoked:flags.2?true peer:InputPeer link:string expire_date:flags.0?int usage_limit:flags.1?int request_needed:flags.3?Bool title:flags.4?string = messages.ExportedChatInvite;
messages.deleteRevokedExportedChatInvites#56987bd5 peer:InputPeer admin_id:InputUser = Bool;
messages.deleteExportedChatInvite#d464a42b peer:InputPeer link:string = Bool;
messages.getAdminsWithInvites#3920e6ef peer:InputPeer = messages.ChatAdminsWithInvites;
messages.getChatInviteImporters#df04dd4e flags:# requested:flags.0?true subscription_expired:flags.3?true peer:InputPeer link:flags.1?string q:flags.2?string offset_date:int offset_user:InputUser limit:int = messages.ChatInviteImporters;
messages.setHistoryTTL#b80e5fe4 peer:InputPeer period:int = Updates;
messages.checkHistoryImportPeer#5dc60f03 peer:InputPeer = messages.CheckedHistoryImportPeer;
messages.setChatTheme#e63be13f peer:InputPeer emoticon:string = Updates;
messages.getMessageReadParticipants#31c1c44f peer:InputPeer msg_id:int = Vector<ReadParticipantDate>;
messages.getSearchResultsCalendar#6aa3f6bd flags:# peer:InputPeer saved_peer_id:flags.2?InputPeer filter:MessagesFilter offset_id:int offset_date:int = messages.SearchResultsCalendar;
messages.getSearchResultsPositions#9c7f2f10 flags:# peer:InputPeer saved_peer_id:flags.2?InputPeer filter:MessagesFilter offset_id:int limit:int = messages.SearchResultsPositions;
messages.hideChatJoinRequest#7fe7e815 flags:# approved:flags.0?true peer:InputPeer user_id:InputUser = Updates;
messages.hideAllChatJoinRequests#e085f4ea flags:# approved:flags.0?true peer:InputPeer link:flags.1?string = Updates;
messages.toggleNoForwards#b11eafa2 peer:InputPeer enabled:Bool = Updates;
messages.saveDefaultSendAs#ccfddf96 peer:InputPeer send_as:InputPeer = Bool;
messages.sendReaction#d30d78d4 flags:# big:flags.1?true add_to_recent:flags.2?true peer:InputPeer msg_id:int reaction:flags.0?Vector<Reaction> = Updates;
messages.getMessagesReactions#8bba90e6 peer:InputPeer id:Vector<int> = Updates;
messages.getMessageReactionsList#461b3f48 flags:# peer:InputPeer id:int reaction:flags.0?Reaction offset:flags.1?string limit:int = messages.MessageReactionsList;
messages.setChatAvailableReactions#864b2581 flags:# peer:InputPeer available_reactions:ChatReactions reactions_limit:flags.0?int paid_enabled:flags.1?Bool = Updates;
messages.getAvailableReactions#18dea0ac hash:int = messages.AvailableReactions;
messages.setDefaultReaction#4f47a016 reaction:Reaction = Bool;
messages.translateText#63183030 flags:# peer:flags.0?InputPeer id:flags.0?Vector<int> text:flags.1?Vector<TextWithEntities> to_lang:string = messages.TranslatedText;
messages.getUnreadReactions#3223495b flags:# peer:InputPeer top_msg_id:flags.0?int offset_id:int add_offset:int limit:int max_id:int min_id:int = messages.Messages;
messages.readReactions#54aa7f8e flags:# peer:InputPeer top_msg_id:flags.0?int = messages.AffectedHistory;
messages.searchSentMedia#107e31a0 q:string filter:MessagesFilter limit:int = messages.Messages;
messages.getAttachMenuBots#16fcc2cb hash:long = AttachMenuBots;
messages.getAttachMenuBot#77216192 bot:InputUser = AttachMenuBotsBot;
messages.toggleBotInAttachMenu#69f59d69 flags:# write_allowed:flags.0?true bot:InputUser enabled:Bool = Bool;
messages.requestWebView#269dc2c1 flags:# from_bot_menu:flags.4?true silent:flags.5?true compact:flags.7?true fullscreen:flags.8?true peer:InputPeer bot:InputUser url:flags.1?string start_param:flags.3?string theme_params:flags.2?DataJSON platform:string reply_to:flags.0?InputReplyTo send_as:flags.13?InputPeer = WebViewResult;
messages.prolongWebView#b0d81a83 flags:# silent:flags.5?true peer:InputPeer bot:InputUser query_id:long reply_to:flags.0?InputReplyTo send_as:flags.13?InputPeer = Bool;
messages.requestSimpleWebView#413a3e73 flags:# from_switch_webview:flags.1?true from_side_menu:flags.2?true compact:flags.7?true fullscreen:flags.8?true bot:InputUser url:flags.3?string start_param:flags.4?string theme_params:flags.0?DataJSON platform:string = WebViewResult;
messages.sendWebViewResultMessage#a4314f5 bot_query_id:string result:InputBotInlineResult = WebViewMessageSent;
messages.sendWebViewData#dc0242c8 bot:InputUser random_id:long button_text:string data:string = Updates;
messages.transcribeAudio#269e9a49 peer:InputPeer msg_id:int = messages.TranscribedAudio;
messages.rateTranscribedAudio#7f1d072f peer:InputPeer msg_id:int transcription_id:long good:Bool = Bool;
messages.getCustomEmojiDocuments#d9ab0f54 document_id:Vector<long> = Vector<Document>;
messages.getEmojiStickers#fbfca18f hash:long = messages.AllStickers;
messages.getFeaturedEmojiStickers#ecf6736 hash:long = messages.FeaturedStickers;
messages.reportReaction#3f64c076 peer:InputPeer id:int reaction_peer:InputPeer = Bool;
messages.getTopReactions#bb8125ba limit:int hash:long = messages.Reactions;
messages.getRecentReactions#39461db2 limit:int hash:long = messages.Reactions;
messages.clearRecentReactions#9dfeefb4 = Bool;
messages.getExtendedMedia#84f80814 peer:InputPeer id:Vector<int> = Updates;
messages.setDefaultHistoryTTL#9eb51445 period:int = Bool;
messages.getDefaultHistoryTTL#658b7188 = DefaultHistoryTTL;
messages.sendBotRequestedPeer#91b2d060 peer:InputPeer msg_id:int button_id:int requested_peers:Vector<InputPeer> = Updates;
messages.getEmojiGroups#7488ce5b hash:int = messages.EmojiGroups;
messages.getEmojiStatusGroups#2ecd56cd hash:int = messages.EmojiGroups;
messages.getEmojiProfilePhotoGroups#21a548f3 hash:int = messages.EmojiGroups;
messages.searchCustomEmoji#2c11c0d7 emoticon:string hash:long = EmojiList;
messages.togglePeerTranslations#e47cb579 flags:# disabled:flags.0?true peer:InputPeer = Bool;
messages.getBotApp#34fdc5c3 app:InputBotApp hash:long = messages.BotApp;
messages.requestAppWebView#53618bce flags:# write_allowed:flags.0?true compact:flags.7?true fullscreen:flags.8?true peer:InputPeer app:InputBotApp start_param:flags.1?string theme_params:flags.2?DataJSON platform:string = WebViewResult;
messages.setChatWallPaper#8ffacae1 flags:# for_both:flags.3?true revert:flags.4?true peer:InputPeer wallpaper:flags.0?InputWallPaper settings:flags.2?WallPaperSettings id:flags.1?int = Updates;
messages.searchEmojiStickerSets#92b4494c flags:# exclude_featured:flags.0?true q:string hash:long = messages.FoundStickerSets;
messages.getSavedDialogs#5381d21a flags:# exclude_pinned:flags.0?true offset_date:int offset_id:int offset_peer:InputPeer limit:int hash:long = messages.SavedDialogs;
messages.getSavedHistory#3d9a414d peer:InputPeer offset_id:int offset_date:int add_offset:int limit:int max_id:int min_id:int hash:long = messages.Messages;
messages.deleteSavedHistory#6e98102b flags:# peer:InputPeer max_id:int min_date:flags.2?int max_date:flags.3?int = messages.AffectedHistory;
messages.getPinnedSavedDialogs#d63d94e0 = messages.SavedDialogs;
messages.toggleSavedDialogPin#ac81bbde flags:# pinned:flags.0?true peer:InputDialogPeer = Bool;
messages.reorderPinnedSavedDialogs#8b716587 flags:# force:flags.0?true order:Vector<InputDialogPeer> = Bool;
messages.getSavedReactionTags#3637e05b flags:# peer:flags.0?InputPeer hash:long = messages.SavedReactionTags;
messages.updateSavedReactionTag#60297dec flags:# reaction:Reaction title:flags.0?string = Bool;
messages.getDefaultTagReactions#bdf93428 hash:long = messages.Reactions;
messages.getOutboxReadDate#8c4bfe5d peer:InputPeer msg_id:int = OutboxReadDate;
messages.getQuickReplies#d483f2a8 hash:long = messages.QuickReplies;
messages.reorderQuickReplies#60331907 order:Vector<int> = Bool;
messages.checkQuickReplyShortcut#f1d0fbd3 shortcut:string = Bool;
messages.editQuickReplyShortcut#5c003cef shortcut_id:int shortcut:string = Bool;
messages.deleteQuickReplyShortcut#3cc04740 shortcut_id:int = Bool;
messages.getQuickReplyMessages#94a495c3 flags:# shortcut_id:int id:flags.0?Vector<int> hash:long = messages.Messages;
messages.sendQuickReplyMessages#6c750de1 peer:InputPeer shortcut_id:int id:Vector<int> random_id:Vector<long> = Updates;
messages.deleteQuickReplyMessages#e105e910 shortcut_id:int id:Vector<int> = Updates;
messages.toggleDialogFilterTags#fd2dda49 enabled:Bool = Bool;
messages.getMyStickers#d0b5e1fc offset_id:long limit:int = messages.MyStickers;
messages.getEmojiStickerGroups#1dd840f5 hash:int = messages.EmojiGroups;
messages.getAvailableEffects#dea20a39 hash:int = messages.AvailableEffects;
messages.editFactCheck#589ee75 peer:InputPeer msg_id:int text:TextWithEntities = Updates;
messages.deleteFactCheck#d1da940c peer:InputPeer msg_id:int = Updates;
messages.getFactCheck#b9cdc5ee peer:InputPeer msg_id:Vector<int> = Vector<FactCheck>;
messages.requestMainWebView#c9e01e7b flags:# compact:flags.7?true fullscreen:flags.8?true peer:InputPeer bot:InputUser start_param:flags.1?string theme_params:flags.0?DataJSON platform:string = WebViewResult;
messages.sendPaidReaction#9dd6a67b flags:# peer:InputPeer msg_id:int count:int random_id:long private:flags.0?Bool = Updates;
messages.togglePaidReactionPrivacy#849ad397 peer:InputPeer msg_id:int private:Bool = Bool;
messages.getPaidReactionPrivacy#472455aa = Updates;
messages.viewSponsoredMessage#673ad8f1 peer:InputPeer random_id:bytes = Bool;
messages.clickSponsoredMessage#f093465 flags:# media:flags.0?true fullscreen:flags.1?true peer:InputPeer random_id:bytes = Bool;
messages.reportSponsoredMessage#1af3dbb8 peer:InputPeer random_id:bytes option:bytes = channels.SponsoredMessageReportResult;
messages.getSponsoredMessages#9bd2f439 peer:InputPeer = messages.SponsoredMessages;
messages.savePreparedInlineMessage#f21f7f2f flags:# result:InputBotInlineResult user_id:InputUser peer_types:flags.0?Vector<InlineQueryPeerType> = messages.BotPreparedInlineMessage;
messages.getPreparedInlineMessage#857ebdb8 bot:InputUser id:string = messages.PreparedInlineMessage;
messages.searchStickers#29b1c66a flags:# emojis:flags.0?true q:string emoticon:string lang_code:Vector<string> offset:int limit:int hash:long = messages.FoundStickers;
messages.reportMessagesDelivery#5a6d7395 flags:# push:flags.0?true peer:InputPeer id:Vector<int> = Bool;
updates.getState#edd4882a = updates.State;
updates.getDifference#19c2f763 flags:# pts:int pts_limit:flags.1?int pts_total_limit:flags.0?int date:int qts:int qts_limit:flags.2?int = updates.Difference;
updates.getChannelDifference#3173d78 flags:# force:flags.0?true channel:InputChannel filter:ChannelMessagesFilter pts:int limit:int = updates.ChannelDifference;
photos.updateProfilePhoto#9e82039 flags:# fallback:flags.0?true bot:flags.1?InputUser id:InputPhoto = photos.Photo;
photos.uploadProfilePhoto#388a3b5 flags:# fallback:flags.3?true bot:flags.5?InputUser file:flags.0?InputFile video:flags.1?InputFile video_start_ts:flags.2?double video_emoji_markup:flags.4?VideoSize = photos.Photo;
photos.deletePhotos#87cf7f2f id:Vector<InputPhoto> = Vector<long>;
photos.getUserPhotos#91cd32a8 user_id:InputUser offset:int max_id:long limit:int = photos.Photos;
photos.uploadContactProfilePhoto#e14c4a71 flags:# suggest:flags.3?true save:flags.4?true user_id:InputUser file:flags.0?InputFile video:flags.1?InputFile video_start_ts:flags.2?double video_emoji_markup:flags.5?VideoSize = photos.Photo;
upload.saveFilePart#b304a621 file_id:long file_part:int bytes:bytes = Bool;
upload.getFile#be5335be flags:# precise:flags.0?true cdn_supported:flags.1?true location:InputFileLocation offset:long limit:int = upload.File;
upload.saveBigFilePart#de7b673d file_id:long file_part:int file_total_parts:int bytes:bytes = Bool;
upload.getWebFile#24e6818d location:InputWebFileLocation offset:int limit:int = upload.WebFile;
upload.getCdnFile#395f69da file_token:bytes offset:long limit:int = upload.CdnFile;
upload.reuploadCdnFile#9b2754a8 file_token:bytes request_token:bytes = Vector<FileHash>;
upload.getCdnFileHashes#91dc3f31 file_token:bytes offset:long = Vector<FileHash>;
upload.getFileHashes#9156982a location:InputFileLocation offset:long = Vector<FileHash>;
help.getConfig#c4f9186b = Config;
help.getNearestDc#1fb33026 = NearestDc;
help.getAppUpdate#522d5a7d source:string = help.AppUpdate;
help.getInviteText#4d392343 = help.InviteText;
help.getSupport#9cdf08cd = help.Support;
help.setBotUpdatesStatus#ec22cfcd pending_updates_count:int message:string = Bool;
help.getCdnConfig#52029342 = CdnConfig;
help.getRecentMeUrls#3dc0f114 referer:string = help.RecentMeUrls;
help.getTermsOfServiceUpdate#2ca51fd1 = help.TermsOfServiceUpdate;
help.acceptTermsOfService#ee72f79a id:DataJSON = Bool;
help.getDeepLinkInfo#3fedc75f path:string = help.DeepLinkInfo;
help.getAppConfig#61e3f854 hash:int = help.AppConfig;
help.saveAppLog#6f02f748 events:Vector<InputAppEvent> = Bool;
help.getPassportConfig#c661ad08 hash:int = help.PassportConfig;
help.getSupportName#d360e72c = help.SupportName;
help.getUserInfo#38a08d3 user_id:InputUser = help.UserInfo;
help.editUserInfo#66b91b70 user_id:InputUser message:string entities:Vector<MessageEntity> = help.UserInfo;
help.getPromoData#c0977421 = help.PromoData;
help.hidePromoData#1e251c95 peer:InputPeer = Bool;
help.dismissSuggestion#f50dbaa1 peer:InputPeer suggestion:string = Bool;
help.getCountriesList#735787a8 lang_code:string hash:int = help.CountriesList;
help.getPremiumPromo#b81b93d4 = help.PremiumPromo;
help.getPeerColors#da80f42f hash:int = help.PeerColors;
help.getPeerProfileColors#abcfa9fd hash:int = help.PeerColors;
help.getTimezonesList#49b30240 hash:int = help.TimezonesList;
channels.readHistory#cc104937 channel:InputChannel max_id:int = Bool;
channels.deleteMessages#84c1fd4e channel:InputChannel id:Vector<int> = messages.AffectedMessages;
channels.reportSpam#f44a8315 channel:InputChannel participant:InputPeer id:Vector<int> = Bool;
channels.getMessages#ad8c9a23 channel:InputChannel id:Vector<InputMessage> = messages.Messages;
channels.getParticipants#77ced9d0 channel:InputChannel filter:ChannelParticipantsFilter offset:int limit:int hash:long = channels.ChannelParticipants;
channels.getParticipant#a0ab6cc6 channel:InputChannel participant:InputPeer = channels.ChannelParticipant;
channels.getChannels#a7f6bbb id:Vector<InputChannel> = messages.Chats;
channels.getFullChannel#8736a09 channel:InputChannel = messages.ChatFull;
channels.createChannel#91006707 flags:# broadcast:flags.0?true megagroup:flags.1?true for_import:flags.3?true forum:flags.5?true title:string about:string geo_point:flags.2?InputGeoPoint address:flags.2?string ttl_period:flags.4?int = Updates;
channels.editAdmin#d33c8902 channel:InputChannel user_id:InputUser admin_rights:ChatAdminRights rank:string = Updates;
channels.editTitle#566decd0 channel:InputChannel title:string = Updates;
channels.editPhoto#f12e57c9 channel:InputChannel photo:InputChatPhoto = Updates;
channels.checkUsername#10e6bd2c channel:InputChannel username:string = Bool;
channels.updateUsername#3514b3de channel:InputChannel username:string = Bool;
channels.joinChannel#24b524c5 channel:InputChannel = Updates;
channels.leaveChannel#f836aa95 channel:InputChannel = Updates;
channels.inviteToChannel#c9e33d54 channel:InputChannel users:Vector<InputUser> = messages.InvitedUsers;
channels.deleteChannel#c0111fe3 channel:InputChannel = Updates;
channels.exportMessageLink#e63fadeb flags:# grouped:flags.0?true thread:flags.1?true channel:InputChannel id:int = ExportedMessageLink;
channels.toggleSignatures#418d549c flags:# signatures_enabled:flags.0?true profiles_enabled:flags.1?true channel:InputChannel = Updates;
channels.getAdminedPublicChannels#f8b036af flags:# by_location:flags.0?true check_limit:flags.1?true for_personal:flags.2?true = messages.Chats;
channels.editBanned#96e6cd81 channel:InputChannel participant:InputPeer banned_rights:ChatBannedRights = Updates;
channels.getAdminLog#33ddf480 flags:# channel:InputChannel q:string events_filter:flags.0?ChannelAdminLogEventsFilter admins:flags.1?Vector<InputUser> max_id:long min_id:long limit:int = channels.AdminLogResults;
channels.setStickers#ea8ca4f9 channel:InputChannel stickerset:InputStickerSet = Bool;
channels.readMessageContents#eab5dc38 channel:InputChannel id:Vector<int> = Bool;
channels.deleteHistory#9baa9647 flags:# for_everyone:flags.0?true channel:InputChannel max_id:int = Updates;
channels.togglePreHistoryHidden#eabbb94c channel:InputChannel enabled:Bool = Updates;
channels.getLeftChannels#8341ecc0 offset:int = messages.Chats;
channels.getGroupsForDiscussion#f5dad378 = messages.Chats;
channels.setDiscussionGroup#40582bb2 broadcast:InputChannel group:InputChannel = Bool;
channels.editCreator#8f38cd1f channel:InputChannel user_id:InputUser password:InputCheckPasswordSRP = Updates;
channels.editLocation#58e63f6d channel:InputChannel geo_point:InputGeoPoint address:string = Bool;
channels.toggleSlowMode#edd49ef0 channel:InputChannel seconds:int = Updates;
channels.getInactiveChannels#11e831ee = messages.InactiveChats;
channels.convertToGigagroup#b290c69 channel:InputChannel = Updates;
channels.getSendAs#dc770ee peer:InputPeer = channels.SendAsPeers;
channels.deleteParticipantHistory#367544db channel:InputChannel participant:InputPeer = messages.AffectedHistory;
channels.toggleJoinToSend#e4cb9580 channel:InputChannel enabled:Bool = Updates;
channels.toggleJoinRequest#4c2985b6 channel:InputChannel enabled:Bool = Updates;
channels.reorderUsernames#b45ced1d channel:InputChannel order:Vector<string> = Bool;
channels.toggleUsername#50f24105 channel:InputChannel username:string active:Bool = Bool;
channels.deactivateAllUsernames#a245dd3 channel:InputChannel = Bool;
channels.toggleForum#a4298b29 channel:InputChannel enabled:Bool = Updates;
channels.createForumTopic#f40c0224 flags:# channel:InputChannel title:string icon_color:flags.0?int icon_emoji_id:flags.3?long random_id:long send_as:flags.2?InputPeer = Updates;
channels.getForumTopics#de560d1 flags:# channel:InputChannel q:flags.0?string offset_date:int offset_id:int offset_topic:int limit:int = messages.ForumTopics;
channels.getForumTopicsByID#b0831eb9 channel:InputChannel topics:Vector<int> = messages.ForumTopics;
channels.editForumTopic#f4dfa185 flags:# channel:InputChannel topic_id:int title:flags.0?string icon_emoji_id:flags.1?long closed:flags.2?Bool hidden:flags.3?Bool = Updates;
channels.updatePinnedForumTopic#6c2d9026 channel:InputChannel topic_id:int pinned:Bool = Updates;
channels.deleteTopicHistory#34435f2d channel:InputChannel top_msg_id:int = messages.AffectedHistory;
channels.reorderPinnedForumTopics#2950a18f flags:# force:flags.0?true channel:InputChannel order:Vector<int> = Updates;
channels.toggleAntiSpam#68f3e4eb channel:InputChannel enabled:Bool = Updates;
channels.reportAntiSpamFalsePositive#a850a693 channel:InputChannel msg_id:int = Bool;
channels.toggleParticipantsHidden#6a6e7854 channel:InputChannel enabled:Bool = Updates;
channels.updateColor#d8aa3671 flags:# for_profile:flags.1?true channel:InputChannel color:flags.2?int background_emoji_id:flags.0?long = Updates;
channels.toggleViewForumAsMessages#9738bb15 channel:InputChannel enabled:Bool = Updates;
channels.getChannelRecommendations#25a71742 flags:# channel:flags.0?InputChannel = messages.Chats;
channels.updateEmojiStatus#f0d3e6a8 channel:InputChannel emoji_status:EmojiStatus = Updates;
channels.setBoostsToUnblockRestrictions#ad399cee channel:InputChannel boosts:int = Updates;
channels.setEmojiStickers#3cd930b7 channel:InputChannel stickerset:InputStickerSet = Bool;
channels.restrictSponsoredMessages#9ae91519 channel:InputChannel restricted:Bool = Updates;
channels.searchPosts#d19f987b hashtag:string offset_rate:int offset_peer:InputPeer offset_id:int limit:int = messages.Messages;
bots.sendCustomRequest#aa2769ed custom_method:string params:DataJSON = DataJSON;
bots.answerWebhookJSONQuery#e6213f4d query_id:long data:DataJSON = Bool;
bots.setBotCommands#517165a scope:BotCommandScope lang_code:string commands:Vector<BotCommand> = Bool;
bots.resetBotCommands#3d8de0f9 scope:BotCommandScope lang_code:string = Bool;
bots.getBotCommands#e34c0dd6 scope:BotCommandScope lang_code:string = Vector<BotCommand>;
bots.setBotMenuButton#4504d54f user_id:InputUser button:BotMenuButton = Bool;
bots.getBotMenuButton#9c60eb28 user_id:InputUser = BotMenuButton;
bots.setBotBroadcastDefaultAdminRights#788464e1 admin_rights:ChatAdminRights = Bool;
bots.setBotGroupDefaultAdminRights#925ec9ea admin_rights:ChatAdminRights = Bool;
bots.setBotInfo#10cf3123 flags:# bot:flags.2?InputUser lang_code:string name:flags.3?string about:flags.0?string description:flags.1?string = Bool;
bots.getBotInfo#dcd914fd flags:# bot:flags.0?InputUser lang_code:string = bots.BotInfo;
bots.reorderUsernames#9709b1c2 bot:InputUser order:Vector<string> = Bool;
bots.toggleUsername#53ca973 bot:InputUser username:string active:Bool = Bool;
bots.canSendMessage#1359f4e6 bot:InputUser = Bool;
bots.allowSendMessage#f132e3ef bot:InputUser = Updates;
bots.invokeWebViewCustomMethod#87fc5e7 bot:InputUser custom_method:string params:DataJSON = DataJSON;
bots.getPopularAppBots#c2510192 offset:string limit:int = bots.PopularAppBots;
bots.addPreviewMedia#17aeb75a bot:InputUser lang_code:string media:InputMedia = BotPreviewMedia;
bots.editPreviewMedia#8525606f bot:InputUser lang_code:string media:InputMedia new_media:InputMedia = BotPreviewMedia;
bots.deletePreviewMedia#2d0135b3 bot:InputUser lang_code:string media:Vector<InputMedia> = Bool;
bots.reorderPreviewMedias#b627f3aa bot:InputUser lang_code:string order:Vector<InputMedia> = Bool;
bots.getPreviewInfo#423ab3ad bot:InputUser lang_code:string = bots.PreviewInfo;
bots.getPreviewMedias#a2a5594d bot:InputUser = Vector<BotPreviewMedia>;
bots.updateUserEmojiStatus#ed9f30c5 user_id:InputUser emoji_status:EmojiStatus = Bool;
bots.toggleUserEmojiStatusPermission#6de6392 bot:InputUser enabled:Bool = Bool;
bots.checkDownloadFileParams#50077589 bot:InputUser file_name:string url:string = Bool;
bots.getAdminedBots#b0711d83 = Vector<User>;
bots.updateStarRefProgram#778b5ab3 flags:# bot:InputUser commission_permille:int duration_months:flags.0?int = StarRefProgram;
bots.setCustomVerification#8b89dfbd flags:# enabled:flags.1?true bot:flags.0?InputUser peer:InputPeer custom_description:flags.2?string = Bool;
bots.getBotRecommendations#a1b70815 bot:InputUser = users.Users;
payments.getPaymentForm#37148dbb flags:# invoice:InputInvoice theme_params:flags.0?DataJSON = payments.PaymentForm;
payments.getPaymentReceipt#2478d1cc peer:InputPeer msg_id:int = payments.PaymentReceipt;
payments.validateRequestedInfo#b6c8f12b flags:# save:flags.0?true invoice:InputInvoice info:PaymentRequestedInfo = payments.ValidatedRequestedInfo;
payments.sendPaymentForm#2d03522f flags:# form_id:long invoice:InputInvoice requested_info_id:flags.0?string shipping_option_id:flags.1?string credentials:InputPaymentCredentials tip_amount:flags.2?long = payments.PaymentResult;
payments.getSavedInfo#227d824b = payments.SavedInfo;
payments.clearSavedInfo#d83d70c1 flags:# credentials:flags.0?true info:flags.1?true = Bool;
payments.getBankCardData#2e79d779 number:string = payments.BankCardData;
payments.exportInvoice#f91b065 invoice_media:InputMedia = payments.ExportedInvoice;
payments.assignAppStoreTransaction#80ed747d receipt:bytes purpose:InputStorePaymentPurpose = Updates;
payments.assignPlayMarketTransaction#dffd50d3 receipt:DataJSON purpose:InputStorePaymentPurpose = Updates;
payments.canPurchasePremium#9fc19eb6 purpose:InputStorePaymentPurpose = Bool;
payments.getPremiumGiftCodeOptions#2757ba54 flags:# boost_peer:flags.0?InputPeer = Vector<PremiumGiftCodeOption>;
payments.checkGiftCode#8e51b4c1 slug:string = payments.CheckedGiftCode;
payments.applyGiftCode#f6e26854 slug:string = Updates;
payments.getGiveawayInfo#f4239425 peer:InputPeer msg_id:int = payments.GiveawayInfo;
payments.launchPrepaidGiveaway#5ff58f20 peer:InputPeer giveaway_id:long purpose:InputStorePaymentPurpose = Updates;
payments.getStarsTopupOptions#c00ec7d3 = Vector<StarsTopupOption>;
payments.getStarsStatus#104fcfa7 peer:InputPeer = payments.StarsStatus;
payments.getStarsTransactions#69da4557 flags:# inbound:flags.0?true outbound:flags.1?true ascending:flags.2?true subscription_id:flags.3?string peer:InputPeer offset:string limit:int = payments.StarsStatus;
payments.sendStarsForm#7998c914 form_id:long invoice:InputInvoice = payments.PaymentResult;
payments.refundStarsCharge#25ae8f4a user_id:InputUser charge_id:string = Updates;
payments.getStarsRevenueStats#d91ffad6 flags:# dark:flags.0?true peer:InputPeer = payments.StarsRevenueStats;
payments.getStarsRevenueWithdrawalUrl#13bbe8b3 peer:InputPeer stars:long password:InputCheckPasswordSRP = payments.StarsRevenueWithdrawalUrl;
payments.getStarsRevenueAdsAccountUrl#d1d7efc5 peer:InputPeer = payments.StarsRevenueAdsAccountUrl;
payments.getStarsTransactionsByID#27842d2e peer:InputPeer id:Vector<InputStarsTransaction> = payments.StarsStatus;
payments.getStarsGiftOptions#d3c96bc8 flags:# user_id:flags.0?InputUser = Vector<StarsGiftOption>;
payments.getStarsSubscriptions#32512c5 flags:# missing_balance:flags.0?true peer:InputPeer offset:string = payments.StarsStatus;
payments.changeStarsSubscription#c7770878 flags:# peer:InputPeer subscription_id:string canceled:flags.0?Bool = Bool;
payments.fulfillStarsSubscription#cc5bebb3 peer:InputPeer subscription_id:string = Bool;
payments.getStarsGiveawayOptions#bd1efd3e = Vector<StarsGiveawayOption>;
payments.getStarGifts#c4563590 hash:int = payments.StarGifts;
payments.saveStarGift#2a2a697c flags:# unsave:flags.0?true stargift:InputSavedStarGift = Bool;
payments.convertStarGift#74bf076b stargift:InputSavedStarGift = Bool;
payments.botCancelStarsSubscription#6dfa0622 flags:# restore:flags.0?true user_id:InputUser charge_id:string = Bool;
payments.getConnectedStarRefBots#5869a553 flags:# peer:InputPeer offset_date:flags.2?int offset_link:flags.2?string limit:int = payments.ConnectedStarRefBots;
payments.getConnectedStarRefBot#b7d998f0 peer:InputPeer bot:InputUser = payments.ConnectedStarRefBots;
payments.getSuggestedStarRefBots#d6b48f7 flags:# order_by_revenue:flags.0?true order_by_date:flags.1?true peer:InputPeer offset:string limit:int = payments.SuggestedStarRefBots;
payments.connectStarRefBot#7ed5348a peer:InputPeer bot:InputUser = payments.ConnectedStarRefBots;
payments.editConnectedStarRefBot#e4fca4a3 flags:# revoked:flags.0?true peer:InputPeer link:string = payments.ConnectedStarRefBots;
payments.getStarGiftUpgradePreview#9c9abcb1 gift_id:long = payments.StarGiftUpgradePreview;
payments.upgradeStarGift#aed6e4f5 flags:# keep_original_details:flags.0?true stargift:InputSavedStarGift = Updates;
payments.transferStarGift#7f18176a stargift:InputSavedStarGift to_id:InputPeer = Updates;
payments.getUniqueStarGift#a1974d72 slug:string = payments.UniqueStarGift;
payments.getSavedStarGifts#23830de9 flags:# exclude_unsaved:flags.0?true exclude_saved:flags.1?true exclude_unlimited:flags.2?true exclude_limited:flags.3?true exclude_unique:flags.4?true sort_by_value:flags.5?true peer:InputPeer offset:string limit:int = payments.SavedStarGifts;
payments.getSavedStarGift#b455a106 stargift:Vector<InputSavedStarGift> = payments.SavedStarGifts;
payments.getStarGiftWithdrawalUrl#d06e93a8 stargift:InputSavedStarGift password:InputCheckPasswordSRP = payments.StarGiftWithdrawalUrl;
payments.toggleChatStarGiftNotifications#60eaefa1 flags:# enabled:flags.0?true peer:InputPeer = Bool;
stickers.createStickerSet#9021ab67 flags:# masks:flags.0?true emojis:flags.5?true text_color:flags.6?true user_id:InputUser title:string short_name:string thumb:flags.2?InputDocument stickers:Vector<InputStickerSetItem> software:flags.3?string = messages.StickerSet;
stickers.removeStickerFromSet#f7760f51 sticker:InputDocument = messages.StickerSet;
stickers.changeStickerPosition#ffb6d4ca sticker:InputDocument position:int = messages.StickerSet;
stickers.addStickerToSet#8653febe stickerset:InputStickerSet sticker:InputStickerSetItem = messages.StickerSet;
stickers.setStickerSetThumb#a76a5392 flags:# stickerset:InputStickerSet thumb:flags.0?InputDocument thumb_document_id:flags.1?long = messages.StickerSet;
stickers.checkShortName#284b3639 short_name:string = Bool;
stickers.suggestShortName#4dafc503 title:string = stickers.SuggestedShortName;
stickers.changeSticker#f5537ebc flags:# sticker:InputDocument emoji:flags.0?string mask_coords:flags.1?MaskCoords keywords:flags.2?string = messages.StickerSet;
stickers.renameStickerSet#124b1c00 stickerset:InputStickerSet title:string = messages.StickerSet;
stickers.deleteStickerSet#87704394 stickerset:InputStickerSet = Bool;
stickers.replaceSticker#4696459a sticker:InputDocument new_sticker:InputStickerSetItem = messages.StickerSet;
phone.getCallConfig#55451fa9 = DataJSON;
phone.requestCall#a6c4600c flags:# video:flags.0?true user_id:InputUser conference_call:flags.1?InputGroupCall random_id:int g_a_hash:bytes protocol:PhoneCallProtocol = phone.PhoneCall;
phone.acceptCall#3bd2b4a0 peer:InputPhoneCall g_b:bytes protocol:PhoneCallProtocol = phone.PhoneCall;
phone.confirmCall#2efe1722 peer:InputPhoneCall g_a:bytes key_fingerprint:long protocol:PhoneCallProtocol = phone.PhoneCall;
phone.receivedCall#17d54f61 peer:InputPhoneCall = Bool;
phone.discardCall#b2cbc1c0 flags:# video:flags.0?true peer:InputPhoneCall duration:int reason:PhoneCallDiscardReason connection_id:long = Updates;
phone.setCallRating#59ead627 flags:# user_initiative:flags.0?true peer:InputPhoneCall rating:int comment:string = Updates;
phone.saveCallDebug#277add7e peer:InputPhoneCall debug:DataJSON = Bool;
phone.sendSignalingData#ff7a9383 peer:InputPhoneCall data:bytes = Bool;
phone.createGroupCall#48cdc6d8 flags:# rtmp_stream:flags.2?true peer:InputPeer random_id:int title:flags.0?string schedule_date:flags.1?int = Updates;
phone.joinGroupCall#d61e1df3 flags:# muted:flags.0?true video_stopped:flags.2?true call:InputGroupCall join_as:InputPeer invite_hash:flags.1?string key_fingerprint:flags.3?long params:DataJSON = Updates;
phone.leaveGroupCall#500377f9 call:InputGroupCall source:int = Updates;
phone.inviteToGroupCall#7b393160 call:InputGroupCall users:Vector<InputUser> = Updates;
phone.discardGroupCall#7a777135 call:InputGroupCall = Updates;
phone.toggleGroupCallSettings#74bbb43d flags:# reset_invite_hash:flags.1?true call:InputGroupCall join_muted:flags.0?Bool = Updates;
phone.getGroupCall#41845db call:InputGroupCall limit:int = phone.GroupCall;
phone.getGroupParticipants#c558d8ab call:InputGroupCall ids:Vector<InputPeer> sources:Vector<int> offset:string limit:int = phone.GroupParticipants;
phone.checkGroupCall#b59cf977 call:InputGroupCall sources:Vector<int> = Vector<int>;
phone.toggleGroupCallRecord#f128c708 flags:# start:flags.0?true video:flags.2?true call:InputGroupCall title:flags.1?string video_portrait:flags.2?Bool = Updates;
phone.editGroupCallParticipant#a5273abf flags:# call:InputGroupCall participant:InputPeer muted:flags.0?Bool volume:flags.1?int raise_hand:flags.2?Bool video_stopped:flags.3?Bool video_paused:flags.4?Bool presentation_paused:flags.5?Bool = Updates;
phone.editGroupCallTitle#1ca6ac0a call:InputGroupCall title:string = Updates;
phone.getGroupCallJoinAs#ef7c213a peer:InputPeer = phone.JoinAsPeers;
phone.exportGroupCallInvite#e6aa647f flags:# can_self_unmute:flags.0?true call:InputGroupCall = phone.ExportedGroupCallInvite;
phone.toggleGroupCallStartSubscription#219c34e6 call:InputGroupCall subscribed:Bool = Updates;
phone.startScheduledGroupCall#5680e342 call:InputGroupCall = Updates;
phone.saveDefaultGroupCallJoinAs#575e1f8c peer:InputPeer join_as:InputPeer = Bool;
phone.joinGroupCallPresentation#cbea6bc4 call:InputGroupCall params:DataJSON = Updates;
phone.leaveGroupCallPresentation#1c50d144 call:InputGroupCall = Updates;
phone.getGroupCallStreamChannels#1ab21940 call:InputGroupCall = phone.GroupCallStreamChannels;
phone.getGroupCallStreamRtmpUrl#deb3abbf peer:InputPeer revoke:Bool = phone.GroupCallStreamRtmpUrl;
phone.saveCallLog#41248786 peer:InputPhoneCall file:InputFile = Bool;
phone.createConferenceCall#dfc909ab peer:InputPhoneCall key_fingerprint:long = phone.PhoneCall;
langpack.getLangPack#f2f2330a lang_pack:string lang_code:string = LangPackDifference;
langpack.getStrings#efea3803 lang_pack:string lang_code:string keys:Vector<string> = Vector<LangPackString>;
langpack.getDifference#cd984aa5 lang_pack:string lang_code:string from_version:int = LangPackDifference;
langpack.getLanguages#42c6978f lang_pack:string = Vector<LangPackLanguage>;
langpack.getLanguage#6a596502 lang_pack:string lang_code:string = LangPackLanguage;
folders.editPeerFolders#6847d0ab folder_peers:Vector<InputFolderPeer> = Updates;
stats.getBroadcastStats#ab42441a flags:# dark:flags.0?true channel:InputChannel = stats.BroadcastStats;
stats.loadAsyncGraph#621d5fa0 flags:# token:string x:flags.0?long = StatsGraph;
stats.getMegagroupStats#dcdf8607 flags:# dark:flags.0?true channel:InputChannel = stats.MegagroupStats;
stats.getMessagePublicForwards#5f150144 channel:InputChannel msg_id:int offset:string limit:int = stats.PublicForwards;
stats.getMessageStats#b6e0a3f5 flags:# dark:flags.0?true channel:InputChannel msg_id:int = stats.MessageStats;
stats.getStoryStats#374fef40 flags:# dark:flags.0?true peer:InputPeer id:int = stats.StoryStats;
stats.getStoryPublicForwards#a6437ef6 peer:InputPeer id:int offset:string limit:int = stats.PublicForwards;
stats.getBroadcastRevenueStats#f788ee19 flags:# dark:flags.0?true peer:InputPeer = stats.BroadcastRevenueStats;
stats.getBroadcastRevenueWithdrawalUrl#9df4faad peer:InputPeer password:InputCheckPasswordSRP = stats.BroadcastRevenueWithdrawalUrl;
stats.getBroadcastRevenueTransactions#70990b6d peer:InputPeer offset:int limit:int = stats.BroadcastRevenueTransactions;
chatlists.exportChatlistInvite#8472478e chatlist:InputChatlist title:string peers:Vector<InputPeer> = chatlists.ExportedChatlistInvite;
chatlists.deleteExportedInvite#719c5c5e chatlist:InputChatlist slug:string = Bool;
chatlists.editExportedInvite#653db63d flags:# chatlist:InputChatlist slug:string title:flags.1?string peers:flags.2?Vector<InputPeer> = ExportedChatlistInvite;
chatlists.getExportedInvites#ce03da83 chatlist:InputChatlist = chatlists.ExportedInvites;
chatlists.checkChatlistInvite#41c10fff slug:string = chatlists.ChatlistInvite;
chatlists.joinChatlistInvite#a6b1e39a slug:string peers:Vector<InputPeer> = Updates;
chatlists.getChatlistUpdates#89419521 chatlist:InputChatlist = chatlists.ChatlistUpdates;
chatlists.joinChatlistUpdates#e089f8f5 chatlist:InputChatlist peers:Vector<InputPeer> = Updates;
chatlists.hideChatlistUpdates#66e486fb chatlist:InputChatlist = Bool;
chatlists.getLeaveChatlistSuggestions#fdbcd714 chatlist:InputChatlist = Vector<Peer>;
chatlists.leaveChatlist#74fae13a chatlist:InputChatlist peers:Vector<InputPeer> = Updates;
stories.canSendStory#c7dfdfdd peer:InputPeer = Bool;
stories.sendStory#e4e6694b flags:# pinned:flags.2?true noforwards:flags.4?true fwd_modified:flags.7?true peer:InputPeer media:InputMedia media_areas:flags.5?Vector<MediaArea> caption:flags.0?string entities:flags.1?Vector<MessageEntity> privacy_rules:Vector<InputPrivacyRule> random_id:long period:flags.3?int fwd_from_id:flags.6?InputPeer fwd_from_story:flags.6?int = Updates;
stories.editStory#b583ba46 flags:# peer:InputPeer id:int media:flags.0?InputMedia media_areas:flags.3?Vector<MediaArea> caption:flags.1?string entities:flags.1?Vector<MessageEntity> privacy_rules:flags.2?Vector<InputPrivacyRule> = Updates;
stories.deleteStories#ae59db5f peer:InputPeer id:Vector<int> = Vector<int>;
stories.togglePinned#9a75a1ef peer:InputPeer id:Vector<int> pinned:Bool = Vector<int>;
stories.getAllStories#eeb0d625 flags:# next:flags.1?true hidden:flags.2?true state:flags.0?string = stories.AllStories;
stories.getPinnedStories#5821a5dc peer:InputPeer offset_id:int limit:int = stories.Stories;
stories.getStoriesArchive#b4352016 peer:InputPeer offset_id:int limit:int = stories.Stories;
stories.getStoriesByID#5774ca74 peer:InputPeer id:Vector<int> = stories.Stories;
stories.toggleAllStoriesHidden#7c2557c4 hidden:Bool = Bool;
stories.readStories#a556dac8 peer:InputPeer max_id:int = Vector<int>;
stories.incrementStoryViews#b2028afb peer:InputPeer id:Vector<int> = Bool;
stories.getStoryViewsList#7ed23c57 flags:# just_contacts:flags.0?true reactions_first:flags.2?true forwards_first:flags.3?true peer:InputPeer q:flags.1?string id:int offset:string limit:int = stories.StoryViewsList;
stories.getStoriesViews#28e16cc8 peer:InputPeer id:Vector<int> = stories.StoryViews;
stories.exportStoryLink#7b8def20 peer:InputPeer id:int = ExportedStoryLink;
stories.report#19d8eb45 peer:InputPeer id:Vector<int> option:bytes message:string = ReportResult;
stories.activateStealthMode#57bbd166 flags:# past:flags.0?true future:flags.1?true = Updates;
stories.sendReaction#7fd736b2 flags:# add_to_recent:flags.0?true peer:InputPeer story_id:int reaction:Reaction = Updates;
stories.getPeerStories#2c4ada50 peer:InputPeer = stories.PeerStories;
stories.getAllReadPeerStories#9b5ae7f9 = Updates;
stories.getPeerMaxIDs#535983c3 id:Vector<InputPeer> = Vector<int>;
stories.getChatsToSend#a56a8b60 = messages.Chats;
stories.togglePeerStoriesHidden#bd0415c4 peer:InputPeer hidden:Bool = Bool;
stories.getStoryReactionsList#b9b2881f flags:# forwards_first:flags.2?true peer:InputPeer id:int reaction:flags.0?Reaction offset:flags.1?string limit:int = stories.StoryReactionsList;
stories.togglePinnedToTop#b297e9b peer:InputPeer id:Vector<int> = Bool;
stories.searchPosts#d1810907 flags:# hashtag:flags.0?string area:flags.1?MediaArea peer:flags.2?InputPeer offset:string limit:int = stories.FoundStories;
premium.getBoostsList#60f67660 flags:# gifts:flags.0?true peer:InputPeer offset:string limit:int = premium.BoostsList;
premium.getMyBoosts#be77b4a = premium.MyBoosts;
premium.applyBoost#6b7da746 flags:# slots:flags.0?Vector<int> peer:InputPeer = premium.MyBoosts;
premium.getBoostsStatus#42f1f61 peer:InputPeer = premium.BoostsStatus;
premium.getUserBoosts#39854d1f peer:InputPeer user_id:InputUser = premium.BoostsList;
smsjobs.isEligibleToJoin#edc39d0 = smsjobs.EligibilityToJoin;
smsjobs.join#a74ece2d = Bool;
smsjobs.leave#9898ad73 = Bool;
smsjobs.updateSettings#93fa0bf flags:# allow_international:flags.0?true = Bool;
smsjobs.getStatus#10a698e8 = smsjobs.Status;
smsjobs.getSmsJob#778d902f job_id:string = SmsJob;
smsjobs.finishJob#4f1ebf24 flags:# job_id:string error:flags.0?string = Bool;
fragment.getCollectibleInfo#be1e85ba collectible:InputCollectible = fragment.CollectibleInfo;
`;
}));
//#endregion
//#region node_modules/telegram/tl/schemaTl.js
var require_schemaTl = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = `
resPQ#05162463 nonce:int128 server_nonce:int128 pq:string server_public_key_fingerprints:Vector<long> = ResPQ;
p_q_inner_data#83c95aec pq:string p:string q:string nonce:int128 server_nonce:int128 new_nonce:int256 = P_Q_inner_data;
p_q_inner_data_dc#a9f55f95 pq:string p:string q:string nonce:int128 server_nonce:int128 new_nonce:int256 dc:int = P_Q_inner_data;
p_q_inner_data_temp#3c6a84d4 pq:string p:string q:string nonce:int128 server_nonce:int128 new_nonce:int256 expires_in:int = P_Q_inner_data;
p_q_inner_data_temp_dc#56fddf88 pq:string p:string q:string nonce:int128 server_nonce:int128 new_nonce:int256 dc:int expires_in:int = P_Q_inner_data;
bind_auth_key_inner#75a3f765 nonce:long temp_auth_key_id:long perm_auth_key_id:long temp_session_id:long expires_at:int = BindAuthKeyInner;
server_DH_params_fail#79cb045d nonce:int128 server_nonce:int128 new_nonce_hash:int128 = Server_DH_Params;
server_DH_params_ok#d0e8075c nonce:int128 server_nonce:int128 encrypted_answer:string = Server_DH_Params;
server_DH_inner_data#b5890dba nonce:int128 server_nonce:int128 g:int dh_prime:string g_a:string server_time:int = Server_DH_inner_data;
client_DH_inner_data#6643b654 nonce:int128 server_nonce:int128 retry_id:long g_b:string = Client_DH_Inner_Data;
dh_gen_ok#3bcbf734 nonce:int128 server_nonce:int128 new_nonce_hash1:int128 = Set_client_DH_params_answer;
dh_gen_retry#46dc1fb9 nonce:int128 server_nonce:int128 new_nonce_hash2:int128 = Set_client_DH_params_answer;
dh_gen_fail#a69dae02 nonce:int128 server_nonce:int128 new_nonce_hash3:int128 = Set_client_DH_params_answer;
destroy_auth_key_ok#f660e1d4 = DestroyAuthKeyRes;
destroy_auth_key_none#0a9f2259 = DestroyAuthKeyRes;
destroy_auth_key_fail#ea109b13 = DestroyAuthKeyRes;
---functions---
req_pq#60469778 nonce:int128 = ResPQ;
req_pq_multi#be7e8ef1 nonce:int128 = ResPQ;
req_DH_params#d712e4be nonce:int128 server_nonce:int128 p:string q:string public_key_fingerprint:long encrypted_data:string = Server_DH_Params;
set_client_DH_params#f5045f1f nonce:int128 server_nonce:int128 encrypted_data:string = Set_client_DH_params_answer;
destroy_auth_key#d1435160 = DestroyAuthKeyRes;
---types---
msgs_ack#62d6b459 msg_ids:Vector<long> = MsgsAck;
bad_msg_notification#a7eff811 bad_msg_id:long bad_msg_seqno:int error_code:int = BadMsgNotification;
bad_server_salt#edab447b bad_msg_id:long bad_msg_seqno:int error_code:int new_server_salt:long = BadMsgNotification;
msgs_state_req#da69fb52 msg_ids:Vector<long> = MsgsStateReq;
msgs_state_info#04deb57d req_msg_id:long info:string = MsgsStateInfo;
msgs_all_info#8cc0d131 msg_ids:Vector<long> info:string = MsgsAllInfo;
msg_detailed_info#276d3ec6 msg_id:long answer_msg_id:long bytes:int status:int = MsgDetailedInfo;
msg_new_detailed_info#809db6df answer_msg_id:long bytes:int status:int = MsgDetailedInfo;
msg_resend_req#7d861a08 msg_ids:Vector<long> = MsgResendReq;
rpc_error#2144ca19 error_code:int error_message:string = RpcError;
rpc_answer_unknown#5e2ad36e = RpcDropAnswer;
rpc_answer_dropped_running#cd78e586 = RpcDropAnswer;
rpc_answer_dropped#a43ad8b7 msg_id:long seq_no:int bytes:int = RpcDropAnswer;
future_salt#0949d9dc valid_since:int valid_until:int salt:long = FutureSalt;
future_salts#ae500895 req_msg_id:long now:int salts:vector<future_salt> = FutureSalts;
pong#347773c5 msg_id:long ping_id:long = Pong;
destroy_session_ok#e22045fc session_id:long = DestroySessionRes;
destroy_session_none#62d350c9 session_id:long = DestroySessionRes;
new_session_created#9ec20908 first_msg_id:long unique_id:long server_salt:long = NewSession;
http_wait#9299359f max_delay:int wait_after:int max_wait:int = HttpWait;
ipPort#d433ad73 ipv4:int port:int = IpPort;
ipPortSecret#37982646 ipv4:int port:int secret:bytes = IpPort;
accessPointRule#4679b65f phone_prefix_rules:string dc_id:int ips:vector<IpPort> = AccessPointRule;
help.configSimple#5a592a6c date:int expires:int rules:vector<AccessPointRule> = help.ConfigSimple;
tlsClientHello blocks:vector<TlsBlock> = TlsClientHello;
tlsBlockString data:string = TlsBlock;
tlsBlockRandom length:int = TlsBlock;
tlsBlockZero length:int = TlsBlock;
tlsBlockDomain = TlsBlock;
tlsBlockGrease seed:int = TlsBlock;
tlsBlockPublicKey = TlsBlock;
tlsBlockScope entries:Vector<TlsBlock> = TlsBlock;
tlsBlockPermutation entries:Vector<Vector<TlsBlock>> = TlsBlock;
---functions---
rpc_drop_answer#58e4a740 req_msg_id:long = RpcDropAnswer;
get_future_salts#b921bd04 num:int = FutureSalts;
ping#7abe77ec ping_id:long = Pong;
ping_delay_disconnect#f3427b8c ping_id:long disconnect_delay:int = Pong;
destroy_session#e7512126 session_id:long = DestroySessionRes;
`;
}));
//#endregion
//#region node_modules/telegram/tl/generationHelpers.js
var require_generationHelpers = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.variableSnakeToCamelCase = exports.snakeToCamelCase = exports.CORE_TYPES = exports.fromLine = exports.parseTl = exports.findAll = void 0;
	exports.serializeBytes = serializeBytes;
	exports.serializeDate = serializeDate;
	exports.buildArgConfig = buildArgConfig;
	var Helpers_1 = require_Helpers();
	var snakeToCamelCase = (name) => {
		return name.replace(/(?:^|_)([a-z])/g, (_, g) => g.toUpperCase()).replace(/_/g, "");
	};
	exports.snakeToCamelCase = snakeToCamelCase;
	var variableSnakeToCamelCase = (str) => str.replace(/([-_][a-z])/g, (group) => group.toUpperCase().replace("-", "").replace("_", ""));
	exports.variableSnakeToCamelCase = variableSnakeToCamelCase;
	var CORE_TYPES = /* @__PURE__ */ new Set([
		3162085175,
		2574415285,
		1072550713,
		3300522427,
		1450380236
	]);
	exports.CORE_TYPES = CORE_TYPES;
	var AUTH_KEY_TYPES = /* @__PURE__ */ new Set([
		85337187,
		2211011308,
		2851430293,
		1013613780,
		1459478408,
		3504867164,
		3045658042,
		1715713620,
		3608339646,
		4110704415,
		812830625
	]);
	var fromLine = (line, isFunction) => {
		const match = line.match(/([\w.]+)(?:#([0-9a-fA-F]+))?(?:\s{?\w+:[\w\d<>#.?!]+}?)*\s=\s([\w\d<>#.?]+);$/);
		if (!match) throw new Error(`Cannot parse TLObject ${line}`);
		const argsMatch = findAll(/({)?(\w+):([\w\d<>#.?!]+)}?/, line);
		const currentConfig = {
			name: match[1],
			constructorId: parseInt(match[2], 16),
			argsConfig: {},
			subclassOfId: (0, Helpers_1.crc32)(match[3]),
			result: match[3],
			isFunction,
			namespace: void 0
		};
		if (!currentConfig.constructorId) {
			const hexId = "";
			let args;
			if (Object.values(currentConfig.argsConfig).length) args = ` ${Object.keys(currentConfig.argsConfig).map((arg) => arg.toString()).join(" ")}`;
			else args = "";
			const representation = `${currentConfig.name}${hexId}${args} = ${currentConfig.result}`.replace(/(:|\?)bytes /g, "$1string ").replace(/</g, " ").replace(/>|{|}/g, "").replace(/ \w+:flags(\d+)?\.\d+\?true/g, "");
			if (currentConfig.name === "inputMediaInvoice") {
				if (currentConfig.name === "inputMediaInvoice") {}
			}
			currentConfig.constructorId = (0, Helpers_1.crc32)(Buffer.from(representation, "utf8"));
		}
		for (const [brace, name, argType] of argsMatch) if (brace === void 0) currentConfig.argsConfig[variableSnakeToCamelCase(name)] = buildArgConfig(name, argType);
		if (currentConfig.name.includes(".")) [currentConfig.namespace, currentConfig.name] = currentConfig.name.split(/\.(.+)/);
		currentConfig.name = snakeToCamelCase(currentConfig.name);
		return currentConfig;
	};
	exports.fromLine = fromLine;
	function buildArgConfig(name, argType) {
		name = name === "self" ? "is_self" : name;
		const currentConfig = {
			isVector: false,
			isFlag: false,
			skipConstructorId: false,
			flagName: null,
			flagIndex: -1,
			flagIndicator: true,
			type: null,
			useVectorId: null
		};
		if (argType !== "#") {
			currentConfig.flagIndicator = false;
			currentConfig.type = argType.replace(/^!+/, "");
			const flagMatch = currentConfig.type.match(/(flags(?:\d+)?).(\d+)\?([\w<>.]+)/);
			if (flagMatch) {
				currentConfig.isFlag = true;
				currentConfig.flagName = flagMatch[1];
				currentConfig.flagIndex = Number(flagMatch[2]);
				currentConfig.type = flagMatch[3];
			}
			const vectorMatch = currentConfig.type.match(/[Vv]ector<([\w\d.]+)>/);
			if (vectorMatch) {
				currentConfig.isVector = true;
				currentConfig.useVectorId = currentConfig.type.charAt(0) === "V";
				[, currentConfig.type] = vectorMatch;
			}
			if (/^[a-z]$/.test(currentConfig.type.split(".").pop().charAt(0))) currentConfig.skipConstructorId = true;
		}
		if (currentConfig.type == "future_salt") currentConfig.type = "FutureSalt";
		return currentConfig;
	}
	var parseTl = function* (content, layer, methods = [], ignoreIds = CORE_TYPES) {
		(methods || []).reduce((o, m) => Object.assign(Object.assign({}, o), { [m.name]: m }), {});
		const objAll = [];
		const objByName = {};
		const objByType = {};
		const file = content;
		let isFunction = false;
		for (let line of file.split("\n")) {
			const commentIndex = line.indexOf("//");
			if (commentIndex !== -1) line = line.slice(0, commentIndex);
			line = line.trim();
			if (!line) continue;
			const match = line.match(/---(\w+)---/);
			if (match) {
				const [, followingTypes] = match;
				isFunction = followingTypes === "functions";
				continue;
			}
			try {
				const result = fromLine(line, isFunction);
				if (ignoreIds.has(result.constructorId)) continue;
				objAll.push(result);
				if (!result.isFunction) {
					if (!objByType[result.result]) objByType[result.result] = [];
					objByName[result.name] = result;
					objByType[result.result].push(result);
				}
			} catch (e) {
				if (!e.toString().includes("vector#1cb5c415")) throw e;
			}
		}
		for (const obj of objAll) if (AUTH_KEY_TYPES.has(obj.constructorId)) {
			for (const arg in obj.argsConfig) if (obj.argsConfig[arg].type === "string") obj.argsConfig[arg].type = "bytes";
		}
		for (const obj of objAll) yield obj;
	};
	exports.parseTl = parseTl;
	var findAll = (regex, str, matches = []) => {
		if (!regex.flags.includes("g")) regex = new RegExp(regex.source, "g");
		const res = regex.exec(str);
		if (res) {
			matches.push(res.slice(1));
			findAll(regex, str, matches);
		}
		return matches;
	};
	exports.findAll = findAll;
	function serializeBytes(data) {
		if (!(data instanceof Buffer)) {
			if (typeof data == "string") data = Buffer.from(data);
			else throw Error(`Bytes or str expected, not ${data.constructor.name}`);
		}
		const r = [];
		let padding;
		if (data.length < 254) {
			padding = (data.length + 1) % 4;
			if (padding !== 0) padding = 4 - padding;
			r.push(Buffer.from([data.length]));
			r.push(data);
		} else {
			padding = data.length % 4;
			if (padding !== 0) padding = 4 - padding;
			r.push(Buffer.from([
				254,
				data.length % 256,
				(data.length >> 8) % 256,
				(data.length >> 16) % 256
			]));
			r.push(data);
		}
		r.push(Buffer.alloc(padding).fill(0));
		return Buffer.concat(r);
	}
	function serializeDate(dt) {
		if (!dt) return Buffer.alloc(4).fill(0);
		if (dt instanceof Date) dt = Math.floor((Date.now() - dt.getTime()) / 1e3);
		if (typeof dt == "number") {
			const t = Buffer.alloc(4);
			t.writeInt32LE(dt, 0);
			return t;
		}
		throw Error(`Cannot interpret "${dt}" as a date`);
	}
}));
//#endregion
//#region node_modules/telegram/tl/api.js
var require_api = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var { inspect } = require_inspect();
	var bigInt = require_BigInteger();
	var { generateRandomBytes, readBigIntFromBuffer, isArrayLike, betterConsoleLog } = require_Helpers();
	var tlContent = require_apiTl();
	var schemeContent = require_schemaTl();
	function generateRandomBigInt() {
		return readBigIntFromBuffer(generateRandomBytes(8), false, true);
	}
	var { parseTl, serializeBytes, serializeDate } = require_generationHelpers();
	var { toSignedLittleBuffer } = require_Helpers();
	var NAMED_AUTO_CASTS = /* @__PURE__ */ new Set(["chatId,int"]);
	var AUTO_CASTS = /* @__PURE__ */ new Set([
		"InputPeer",
		"InputChannel",
		"InputUser",
		"InputDialogPeer",
		"InputNotifyPeer",
		"InputMedia",
		"InputPhoto",
		"InputMessage",
		"InputDocument",
		"InputChatPhoto"
	]);
	var CastError = class CastError extends Error {
		constructor(objectName, expected, actual, ...params) {
			const message = "Found wrong type for " + objectName + ". expected " + expected + " but received " + actual + ".If you think this is a mistake please report it.";
			super(message, ...params);
			if (Error.captureStackTrace) Error.captureStackTrace(this, CastError);
			this.name = "CastError";
		}
	};
	var CACHING_SUPPORTED = typeof self !== "undefined" && self.localStorage !== void 0;
	var CACHE_KEY = "GramJs:apiCache";
	function buildApiFromTlSchema() {
		let definitions;
		const fromCache = CACHING_SUPPORTED && loadFromCache();
		if (fromCache) definitions = fromCache;
		else {
			definitions = loadFromTlSchemas();
			if (CACHING_SUPPORTED) localStorage.setItem(CACHE_KEY, JSON.stringify(definitions));
		}
		return createClasses("all", definitions);
	}
	function loadFromCache() {
		const jsonCache = localStorage.getItem(CACHE_KEY);
		return jsonCache && JSON.parse(jsonCache);
	}
	function loadFromTlSchemas() {
		const [constructorParamsApi, functionParamsApi] = extractParams(tlContent);
		const [constructorParamsSchema, functionParamsSchema] = extractParams(schemeContent);
		const constructors = [].concat(constructorParamsApi, constructorParamsSchema);
		const requests = [].concat(functionParamsApi, functionParamsSchema);
		return [].concat(constructors, requests);
	}
	function extractParams(fileContent) {
		const f = parseTl(fileContent, 109);
		const constructors = [];
		const functions = [];
		for (const d of f) d.isFunction ? functions.push(d) : constructors.push(d);
		return [constructors, functions];
	}
	function argToBytes(x, type, argName, requestName) {
		switch (type) {
			case "int":
				const i = Buffer.alloc(4);
				i.writeInt32LE(x, 0);
				return i;
			case "long": return toSignedLittleBuffer(x, 8);
			case "int128": return toSignedLittleBuffer(x, 16);
			case "int256": return toSignedLittleBuffer(x, 32);
			case "double":
				const d = Buffer.alloc(8);
				d.writeDoubleLE(x, 0);
				return d;
			case "string": return serializeBytes(x);
			case "Bool": return x ? Buffer.from("b5757299", "hex") : Buffer.from("379779bc", "hex");
			case "true": return Buffer.alloc(0);
			case "bytes": return serializeBytes(x);
			case "date": return serializeDate(x);
			default:
				if (x === void 0 || typeof x.getBytes !== "function") throw new Error(`Required object ${argName} of ${requestName} is undefined`);
				return x.getBytes();
		}
	}
	async function getInputFromResolve(utils, client, peer, peerType) {
		switch (peerType) {
			case "InputPeer": return utils.getInputPeer(await client.getInputEntity(peer));
			case "InputChannel": return utils.getInputChannel(await client.getInputEntity(peer));
			case "InputUser": return utils.getInputUser(await client.getInputEntity(peer));
			case "InputDialogPeer": return await client._getInputDialog(peer);
			case "InputNotifyPeer": return await client._getInputNotify(peer);
			case "InputMedia": return utils.getInputMedia(peer);
			case "InputPhoto": return utils.getInputPhoto(peer);
			case "InputMessage": return utils.getInputMessage(peer);
			case "InputDocument": return utils.getInputDocument(peer);
			case "InputChatPhoto": return utils.getInputChatPhoto(peer);
			case "chatId,int": return await client.getPeerId(peer, false);
			default: throw new Error("unsupported peer type : " + peerType);
		}
	}
	function getArgFromReader(reader, arg) {
		if (arg.isVector) {
			if (arg.useVectorId) reader.readInt();
			const temp = [];
			const len = reader.readInt();
			arg.isVector = false;
			for (let i = 0; i < len; i++) temp.push(getArgFromReader(reader, arg));
			arg.isVector = true;
			return temp;
		} else if (arg.flagIndicator) return reader.readInt();
		else switch (arg.type) {
			case "int": return reader.readInt();
			case "long": return reader.readLong();
			case "int128": return reader.readLargeInt(128);
			case "int256": return reader.readLargeInt(256);
			case "double": return reader.readDouble();
			case "string": return reader.tgReadString();
			case "Bool": return reader.tgReadBool();
			case "true": return true;
			case "bytes": return reader.tgReadBytes();
			case "date": return reader.tgReadDate();
			default: if (!arg.skipConstructorId) return reader.tgReadObject();
			else return api.constructors[arg.type].fromReader(reader);
		}
	}
	function compareType(value, type) {
		let correct = true;
		switch (type) {
			case "number":
				correct = typeof value === "number" || value === void 0;
				break;
			case "string":
			case "boolean":
				correct = typeof value === type;
				break;
			case "bigInt":
				correct = bigInt.isInstance(value) || typeof value === "bigint" || typeof value === "number" || typeof value === "string" || value === void 0;
				break;
			case "true": break;
			case "buffer":
				correct = Buffer.isBuffer(value);
				break;
			case "date":
				correct = value && Object.prototype.toString.call(value) === "[object Date]" && !isNaN(value) || typeof value === "number";
				break;
			default: console.error(/* @__PURE__ */ new Error("Unknown type." + type));
		}
		return correct;
	}
	function createClasses(classesType, params) {
		const classes = {};
		for (const classParams of params) {
			const { name, constructorId, subclassOfId, argsConfig, namespace, isFunction, result } = classParams;
			const fullName = [namespace, name].join(".").replace(/^\./, "");
			class VirtualClass {
				constructor(args) {
					this.CONSTRUCTOR_ID = constructorId;
					this.SUBCLASS_OF_ID = subclassOfId;
					this.className = fullName;
					this.classType = isFunction ? "request" : "constructor";
					args = args || {};
					this.originalArgs = args;
					this.init(args);
					for (const argName in argsConfig) if (argName === "randomId" && !args[argName]) {
						if (argsConfig[argName].isVector) {
							const rands = [];
							for (let i = 0; i < args["id"].length; i++) rands.push(generateRandomBigInt());
							this[argName] = rands;
						} else this[argName] = generateRandomBigInt();
					} else this[argName] = args[argName];
				}
				init(args) {}
				static fromReader(reader) {
					const args = {};
					for (const argName in argsConfig) if (argsConfig.hasOwnProperty(argName)) {
						const arg = argsConfig[argName];
						if (arg.isFlag) {
							if (arg.type === "true") {
								args[argName] = Boolean(args[arg.flagName] & 1 << arg.flagIndex);
								continue;
							}
							if (args[arg.flagName] & 1 << arg.flagIndex) args[argName] = getArgFromReader(reader, arg);
							else args[argName] = null;
						} else {
							if (arg.flagIndicator) arg.name = argName;
							args[argName] = getArgFromReader(reader, arg);
						}
					}
					return new this(args);
				}
				validate() {
					for (const arg in argsConfig) if (argsConfig.hasOwnProperty(arg)) {
						if (argsConfig[arg].flagIndicator || argsConfig[arg].isFlag) continue;
						const currentValue = this[arg];
						this.assertType(arg, argsConfig[arg], currentValue);
					}
				}
				assertType(objectName, object, value) {
					let expected;
					if (object["isVector"]) {
						if (!isArrayLike(value)) console.error(new CastError(objectName, "array", value));
						if (value == void 0) value = [];
						for (const o of value) this.assertType(objectName, Object.assign(Object.assign({}, object), { isVector: false }), o);
					} else {
						switch (object["type"]) {
							case "int":
								expected = "number";
								break;
							case "long":
							case "int128":
							case "int256":
								expected = "bigInt";
								break;
							case "double":
								expected = "number";
								break;
							case "string":
								expected = "string";
								break;
							case "Bool":
								expected = "boolean";
								break;
							case "true":
								expected = "true";
								break;
							case "bytes":
								expected = "buffer";
								break;
							case "date":
								expected = "date";
								break;
							default: expected = "object";
						}
						if (expected === "object") {} else if (compareType(value, expected) !== true) console.error(new CastError(objectName, expected, value));
					}
				}
				getBytes() {
					try {
						this.validate();
					} catch (e) {}
					const idForBytes = this.CONSTRUCTOR_ID;
					const c = Buffer.alloc(4);
					c.writeUInt32LE(idForBytes, 0);
					const buffers = [c];
					for (const arg in argsConfig) if (argsConfig.hasOwnProperty(arg)) {
						if (argsConfig[arg].isFlag) {
							if (this[arg] === false && argsConfig[arg].type !== "Bool" || this[arg] === null || this[arg] === void 0 || argsConfig[arg].type === "true") continue;
						}
						if (argsConfig[arg].isVector) {
							if (argsConfig[arg].useVectorId) buffers.push(Buffer.from("15c4b51c", "hex"));
							const l = Buffer.alloc(4);
							l.writeInt32LE(this[arg].length, 0);
							buffers.push(l, Buffer.concat(this[arg].map((x) => argToBytes(x, argsConfig[arg].type, fullName))));
						} else if (argsConfig[arg].flagIndicator) {
							if (!Object.values(argsConfig).some((f) => f.isFlag)) buffers.push(Buffer.alloc(4));
							else {
								let flagCalculate = 0;
								for (const f in argsConfig) if (argsConfig[f].isFlag && arg === argsConfig[f].flagName) {
									if (this[f] === false && argsConfig[f].type !== "Bool" || this[f] === void 0 || this[f] === null) flagCalculate |= 0;
									else flagCalculate |= 1 << argsConfig[f].flagIndex;
								}
								const f = Buffer.alloc(4);
								f.writeUInt32LE(flagCalculate, 0);
								buffers.push(f);
							}
						} else {
							buffers.push(argToBytes(this[arg], argsConfig[arg].type, arg, fullName));
							if (this[arg] && typeof this[arg].getBytes === "function") {
								let boxed = argsConfig[arg].type.charAt(argsConfig[arg].type.indexOf(".") + 1);
								boxed = boxed === boxed.toUpperCase();
								if (!boxed) buffers.shift();
							}
						}
					}
					return Buffer.concat(buffers);
				}
				readResult(reader) {
					if (!isFunction) throw new Error("`readResult()` called for non-request instance");
					const m = result.match(/Vector<(int|long)>/);
					if (m) {
						reader.readInt();
						const temp = [];
						const len = reader.readInt();
						if (m[1] === "int") for (let i = 0; i < len; i++) temp.push(reader.readInt());
						else for (let i = 0; i < len; i++) temp.push(reader.readLong());
						return temp;
					} else return reader.tgReadObject();
				}
				async resolve(client, utils) {
					if (!isFunction) throw new Error("`resolve()` called for non-request instance");
					for (const arg in argsConfig) if (argsConfig.hasOwnProperty(arg)) {
						if (!AUTO_CASTS.has(argsConfig[arg].type)) {
							if (!NAMED_AUTO_CASTS.has(`${argsConfig[arg].name},${argsConfig[arg].type}`)) continue;
						}
						if (argsConfig[arg].isFlag) {
							if (!this[arg]) continue;
						}
						if (argsConfig[arg].isVector) {
							const temp = [];
							for (const x of this[arg]) temp.push(await getInputFromResolve(utils, client, x, argsConfig[arg].type));
							this[arg] = temp;
						} else this[arg] = await getInputFromResolve(utils, client, this[arg], argsConfig[arg].type);
					}
				}
				[inspect.custom]() {
					return betterConsoleLog(this);
				}
				toJSON() {
					return Object.assign(Object.assign({}, this.originalArgs), { className: fullName });
				}
			}
			VirtualClass.CONSTRUCTOR_ID = constructorId;
			VirtualClass.SUBCLASS_OF_ID = subclassOfId;
			VirtualClass.className = fullName;
			VirtualClass.classType = isFunction ? "request" : "constructor";
			if (namespace) {
				if (!classes[namespace]) classes[namespace] = {};
				classes[namespace][name] = VirtualClass;
			} else classes[name] = VirtualClass;
		}
		return classes;
	}
	var api = buildApiFromTlSchema();
	module.exports = { Api: api };
}));
//#endregion
//#region node_modules/telegram/tl/custom/chatGetter.js
var require_chatGetter = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __asyncValues = exports && exports.__asyncValues || function(o) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var m = o[Symbol.asyncIterator], i;
		return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i);
		function verb(n) {
			i[n] = o[n] && function(v) {
				return new Promise(function(resolve, reject) {
					v = o[n](v), settle(resolve, reject, v.done, v.value);
				});
			};
		}
		function settle(resolve, reject, d, v) {
			Promise.resolve(v).then(function(v) {
				resolve({
					value: v,
					done: d
				});
			}, reject);
		}
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ChatGetter = void 0;
	var __1 = require_telegram();
	var api_1 = require_api();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var ChatGetter = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		static initChatClass(c, { chatPeer, inputChat, chat, broadcast }) {
			c._chatPeer = chatPeer;
			c._inputChat = inputChat;
			c._chat = chat;
			c._broadcast = broadcast;
			c._client = void 0;
		}
		get chat() {
			return this._chat;
		}
		async getChat() {
			var _a;
			if (!this._chat || "min" in this._chat && await this.getInputChat()) try {
				if (this._inputChat) this._chat = await ((_a = this._client) === null || _a === void 0 ? void 0 : _a.getEntity(this._inputChat));
			} catch (e) {
				await this._refetchChat();
			}
			return this._chat;
		}
		get inputChat() {
			if (!this._inputChat && this._chatPeer && this._client) try {
				this._inputChat = this._client._entityCache.get(__1.utils.getPeerId(this._chatPeer));
			} catch (e) {}
			return this._inputChat;
		}
		async getInputChat() {
			var _a, e_1, _b, _c;
			if (!this.inputChat && this.chatId && this._client) {
				try {
					const target = this.chatId;
					try {
						for (var _d = true, _e = __asyncValues(this._client.iterDialogs({ limit: 100 })), _f; _f = await _e.next(), _a = _f.done, !_a; _d = true) {
							_c = _f.value;
							_d = false;
							const dialog = _c;
							if (dialog.id.eq(target)) {
								this._chat = dialog.entity;
								this._inputChat = dialog.inputEntity;
								break;
							}
						}
					} catch (e_1_1) {
						e_1 = { error: e_1_1 };
					} finally {
						try {
							if (!_d && !_a && (_b = _e.return)) await _b.call(_e);
						} finally {
							if (e_1) throw e_1.error;
						}
					}
				} catch (e) {}
				return this._inputChat;
			}
			return this._inputChat;
		}
		get chatId() {
			return this._chatPeer ? (0, Helpers_1.returnBigInt)(__1.utils.getPeerId(this._chatPeer)) : void 0;
		}
		get isPrivate() {
			return this._chatPeer ? this._chatPeer instanceof api_1.Api.PeerUser : void 0;
		}
		get isGroup() {
			if (!this._broadcast && this.chat && "broadcast" in this.chat) this._broadcast = Boolean(this.chat.broadcast);
			if (this._chatPeer instanceof api_1.Api.PeerChannel) {
				if (this._broadcast === void 0) return;
				else return !this._broadcast;
			}
			return this._chatPeer instanceof api_1.Api.PeerChat;
		}
		get isChannel() {
			return this._chatPeer instanceof api_1.Api.PeerChannel;
		}
		async _refetchChat() {}
	};
	exports.ChatGetter = ChatGetter;
}));
//#endregion
//#region node_modules/telegram/tl/custom/senderGetter.js
var require_senderGetter = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SenderGetter = void 0;
	var api_1 = require_api();
	var Helpers_1 = require_Helpers();
	var chatGetter_1 = require_chatGetter();
	var inspect_1 = require_inspect();
	var SenderGetter = class extends chatGetter_1.ChatGetter {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		static initSenderClass(c, { senderId, sender, inputSender }) {
			c._senderId = senderId;
			c._sender = sender;
			c._inputSender = inputSender;
			c._client = void 0;
		}
		get sender() {
			return this._sender;
		}
		async getSender() {
			if (this._client && (!this._sender || this._sender instanceof api_1.Api.Channel && this._sender.min) && await this.getInputSender()) try {
				this._sender = await this._client.getEntity(this._inputSender);
			} catch (e) {
				await this._refetchSender();
			}
			return this._sender;
		}
		get inputSender() {
			if (!this._inputSender && this._senderId && this._client) try {
				this._inputSender = this._client._entityCache.get(this._senderId);
			} catch (e) {}
			return this._inputSender;
		}
		async getInputSender() {
			if (!this.inputSender && this._senderId && this._client) await this._refetchSender();
			return this._inputSender;
		}
		get senderId() {
			return this._senderId;
		}
		async _refetchSender() {}
	};
	exports.SenderGetter = SenderGetter;
}));
//#endregion
//#region node_modules/telegram/extensions/html.js
var require_html = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.HTMLParser = void 0;
	var htmlparser2_1 = require_lib();
	var tl_1 = require_tl();
	var index_1 = require_telegram();
	var HTMLToTelegramParser = class {
		constructor() {
			this.text = "";
			this.entities = [];
			this._buildingEntities = /* @__PURE__ */ new Map();
			this._openTags = [];
			this._openTagsMeta = [];
		}
		onopentag(name, attributes) {
			this._openTags.unshift(name);
			this._openTagsMeta.unshift(void 0);
			let EntityType;
			const args = {};
			if (name == "strong" || name == "b") EntityType = tl_1.Api.MessageEntityBold;
			else if (name == "spoiler") EntityType = tl_1.Api.MessageEntitySpoiler;
			else if (name == "em" || name == "i") EntityType = tl_1.Api.MessageEntityItalic;
			else if (name == "u") EntityType = tl_1.Api.MessageEntityUnderline;
			else if (name == "del" || name == "s") EntityType = tl_1.Api.MessageEntityStrike;
			else if (name == "blockquote") {
				EntityType = tl_1.Api.MessageEntityBlockquote;
				if (attributes.expandable !== void 0) args.collapsed = true;
			} else if (name == "code") {
				const pre = this._buildingEntities.get("pre");
				if (pre && pre instanceof tl_1.Api.MessageEntityPre) try {
					pre.language = attributes.class.slice(9, attributes.class.length);
				} catch (e) {}
				else EntityType = tl_1.Api.MessageEntityCode;
			} else if (name == "pre") {
				EntityType = tl_1.Api.MessageEntityPre;
				args["language"] = "";
			} else if (name == "a") {
				let url = attributes.href;
				if (!url) return;
				if (url.startsWith("mailto:")) {
					url = url.slice(7, url.length);
					EntityType = tl_1.Api.MessageEntityEmail;
				} else {
					EntityType = tl_1.Api.MessageEntityTextUrl;
					args["url"] = url;
					url = void 0;
				}
				this._openTagsMeta.shift();
				this._openTagsMeta.unshift(url);
			} else if (name == "tg-emoji") {
				EntityType = tl_1.Api.MessageEntityCustomEmoji;
				args["documentId"] = attributes["emoji-id"];
			}
			if (EntityType && !this._buildingEntities.has(name)) this._buildingEntities.set(name, new EntityType(Object.assign({
				offset: this.text.length,
				length: 0
			}, args)));
		}
		ontext(text) {
			if ((this._openTags.length > 0 ? this._openTags[0] : "") == "a") {
				const url = this._openTagsMeta[0];
				if (url) text = url;
			}
			for (let [tag, entity] of this._buildingEntities) entity.length += text.length;
			this.text += text;
		}
		onclosetag(tagname) {
			this._openTagsMeta.shift();
			this._openTags.shift();
			const entity = this._buildingEntities.get(tagname);
			if (entity) {
				this._buildingEntities.delete(tagname);
				this.entities.push(entity);
			}
		}
		onattribute(name, value, quote) {}
		oncdataend() {}
		oncdatastart() {}
		oncomment(data) {}
		oncommentend() {}
		onend() {}
		onerror(error) {}
		onopentagname(name) {}
		onparserinit(parser) {}
		onprocessinginstruction(name, data) {}
		onreset() {}
	};
	var HTMLParser = class {
		static parse(html) {
			if (!html) return [html, []];
			const handler = new HTMLToTelegramParser();
			const parser = new htmlparser2_1.Parser(handler);
			parser.write(html);
			parser.end();
			return [index_1.helpers.stripText(handler.text, handler.entities), handler.entities];
		}
		static unparse(text, entities, _offset = 0, _length) {
			if (!text || !entities || !entities.length) return text;
			if (_length == void 0) _length = text.length;
			const html = [];
			let lastOffset = 0;
			for (let i = 0; i < entities.length; i++) {
				const entity = entities[i];
				if (entity.offset >= _offset + _length) break;
				let relativeOffset = entity.offset - _offset;
				if (relativeOffset > lastOffset) html.push(text.slice(lastOffset, relativeOffset));
				else if (relativeOffset < lastOffset) continue;
				let skipEntity = false;
				let length = entity.length;
				let entityText = this.unparse(text.slice(relativeOffset, relativeOffset + length), entities.slice(i + 1, entities.length), entity.offset, length);
				if (entity instanceof tl_1.Api.MessageEntityBold) html.push(`<strong>${entityText}</strong>`);
				else if (entity instanceof tl_1.Api.MessageEntitySpoiler) html.push(`<spoiler>${entityText}</spoiler>`);
				else if (entity instanceof tl_1.Api.MessageEntityItalic) html.push(`<em>${entityText}</em>`);
				else if (entity instanceof tl_1.Api.MessageEntityCode) html.push(`<code>${entityText}</code>`);
				else if (entity instanceof tl_1.Api.MessageEntityUnderline) html.push(`<u>${entityText}</u>`);
				else if (entity instanceof tl_1.Api.MessageEntityStrike) html.push(`<del>${entityText}</del>`);
				else if (entity instanceof tl_1.Api.MessageEntityBlockquote) html.push(`<blockquote>${entityText}</blockquote>`);
				else if (entity instanceof tl_1.Api.MessageEntityPre) {
					if (entity.language) html.push(`<pre><code class="language-${entity.language}">${entityText}</code></pre>`);
					else html.push(`<pre>${entityText}</pre>`);
				} else if (entity instanceof tl_1.Api.MessageEntityEmail) html.push(`<a href="mailto:${entityText}">${entityText}</a>`);
				else if (entity instanceof tl_1.Api.MessageEntityUrl) html.push(`<a href="${entityText}">${entityText}</a>`);
				else if (entity instanceof tl_1.Api.MessageEntityTextUrl) html.push(`<a href="${entity.url}">${entityText}</a>`);
				else if (entity instanceof tl_1.Api.MessageEntityMentionName) html.push(`<a href="tg://user?id=${entity.userId}">${entityText}</a>`);
				else if (entity instanceof tl_1.Api.MessageEntityCustomEmoji) html.push(`<tg-emoji emoji-id="${entity.documentId}">${entityText}</tg-emoji>`);
				else skipEntity = true;
				lastOffset = relativeOffset + (skipEntity ? 0 : length);
			}
			html.push(text.slice(lastOffset, text.length));
			return html.join("");
		}
	};
	exports.HTMLParser = HTMLParser;
}));
//#endregion
//#region node_modules/telegram/client/messageParse.js
var require_messageParse = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.DEFAULT_DELIMITERS = void 0;
	exports._replaceWithMention = _replaceWithMention;
	exports._parseMessageText = _parseMessageText;
	exports._getResponseMessage = _getResponseMessage;
	var Utils_1 = require_Utils();
	var api_1 = require_api();
	var index_1 = require_telegram();
	var Helpers_1 = require_Helpers();
	var big_integer_1 = __importDefault(require_BigInteger());
	exports.DEFAULT_DELIMITERS = {
		"**": api_1.Api.MessageEntityBold,
		__: api_1.Api.MessageEntityItalic,
		"~~": api_1.Api.MessageEntityStrike,
		"`": api_1.Api.MessageEntityCode,
		"```": api_1.Api.MessageEntityPre
	};
	/** @hidden */
	async function _replaceWithMention(client, entities, i, user) {
		try {
			entities[i] = new api_1.Api.InputMessageEntityMentionName({
				offset: entities[i].offset,
				length: entities[i].length,
				userId: await client.getInputEntity(user)
			});
			return true;
		} catch (e) {
			return false;
		}
	}
	/** @hidden */
	async function _parseMessageText(client, message, parseMode) {
		if (parseMode == false) return [message, []];
		if (parseMode == void 0) {
			if (client.parseMode == void 0) return [message, []];
			parseMode = client.parseMode;
		} else if (typeof parseMode === "string") parseMode = (0, Utils_1.sanitizeParseMode)(parseMode);
		const [rawMessage, msgEntities] = parseMode.parse(message);
		for (let i = msgEntities.length - 1; i >= 0; i--) {
			const e = msgEntities[i];
			if (e instanceof api_1.Api.MessageEntityTextUrl) {
				const m = /^@|\+|tg:\/\/user\?id=(\d+)/.exec(e.url);
				if (m) {
					const userIdOrUsername = m[1] ? Number(m[1]) : e.url;
					if (!await _replaceWithMention(client, msgEntities, i, userIdOrUsername)) msgEntities.splice(i, 1);
				}
			}
		}
		return [rawMessage, msgEntities];
	}
	/** @hidden */
	function _getResponseMessage(client, request, result, inputChat) {
		let updates = [];
		let entities = /* @__PURE__ */ new Map();
		if (result instanceof api_1.Api.UpdateShort) updates = [result.update];
		else if (result instanceof api_1.Api.Updates || result instanceof api_1.Api.UpdatesCombined) {
			updates = result.updates;
			for (const x of [...result.users, ...result.chats]) entities.set(index_1.utils.getPeerId(x), x);
		} else return;
		const randomToId = /* @__PURE__ */ new Map();
		const idToMessage = /* @__PURE__ */ new Map();
		let schedMessage;
		for (const update of updates) if (update instanceof api_1.Api.UpdateMessageID) randomToId.set(update.randomId.toString(), update.id);
		else if (update instanceof api_1.Api.UpdateNewChannelMessage || update instanceof api_1.Api.UpdateNewMessage) {
			update.message._finishInit(client, entities, inputChat);
			if ("randomId" in request || (0, Helpers_1.isArrayLike)(request)) idToMessage.set(update.message.id, update.message);
			else return update.message;
		} else if (update instanceof api_1.Api.UpdateEditMessage && "peer" in request && (0, Helpers_1._entityType)(request.peer) != Helpers_1._EntityType.CHANNEL) {
			update.message._finishInit(client, entities, inputChat);
			if ("randomId" in request) idToMessage.set(update.message.id, update.message);
			else if ("id" in request && request.id === update.message.id) return update.message;
		} else if (update instanceof api_1.Api.UpdateEditChannelMessage && "peer" in request && (0, Utils_1.getPeerId)(request.peer) == (0, Utils_1.getPeerId)(update.message.peerId)) {
			if (request.id == update.message.id) {
				update.message._finishInit(client, entities, inputChat);
				return update.message;
			}
		} else if (update instanceof api_1.Api.UpdateNewScheduledMessage) {
			update.message._finishInit(client, entities, inputChat);
			schedMessage = update.message;
			idToMessage.set(update.message.id, update.message);
		} else if (update instanceof api_1.Api.UpdateMessagePoll) {
			if (request.media.poll.id == update.pollId) {
				const m = new api_1.Api.Message({
					id: request.id,
					peerId: index_1.utils.getPeerId(request.peer),
					media: new api_1.Api.MessageMediaPoll({
						poll: update.poll,
						results: update.results
					}),
					message: "",
					date: 0
				});
				m._finishInit(client, entities, inputChat);
				return m;
			}
		}
		if (request == void 0) return idToMessage;
		let randomId;
		if ((0, Helpers_1.isArrayLike)(request) || typeof request == "number" || big_integer_1.default.isInstance(request)) randomId = request;
		else randomId = request.randomId;
		if (!randomId) {
			if (schedMessage) return schedMessage;
			client._log.warn(`No randomId in ${request} to map to. returning undefined for ${result} (Message was empty)`);
			return;
		}
		if (!(0, Helpers_1.isArrayLike)(randomId)) {
			let msg = idToMessage.get(randomToId.get(randomId.toString()));
			if (!msg) client._log.warn(`Request ${request.className} had missing message mapping ${result.className} (Message was empty)`);
			return msg;
		}
		const final = [];
		let warned = false;
		for (const rnd of randomId) {
			const tmp = randomToId.get(rnd.toString());
			if (!tmp) {
				warned = true;
				break;
			}
			const tmp2 = idToMessage.get(tmp);
			if (!tmp2) {
				warned = true;
				break;
			}
			final.push(tmp2);
		}
		if (warned) client._log.warn(`Request ${request.className} had missing message mapping ${result.className} (Message was empty)`);
		const finalToReturn = [];
		for (const rnd of randomId) finalToReturn.push(idToMessage.get(randomToId.get(rnd.toString())));
		return finalToReturn;
	}
}));
//#endregion
//#region node_modules/telegram/extensions/markdown.js
var require_markdown = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MarkdownParser = void 0;
	var messageParse_1 = require_messageParse();
	var MarkdownParser = class {
		static parse(message) {
			let i = 0;
			const keys = {};
			for (const k in messageParse_1.DEFAULT_DELIMITERS) keys[k] = false;
			const entities = [];
			const tempEntities = {};
			while (i < message.length) {
				let foundIndex = -1;
				let foundDelim = void 0;
				for (const key of Object.keys(messageParse_1.DEFAULT_DELIMITERS)) {
					const index = message.indexOf(key, i);
					if (index > -1 && (foundIndex === -1 || index < foundIndex)) {
						foundIndex = index;
						foundDelim = key;
					}
				}
				if (foundIndex === -1 || foundDelim == void 0) break;
				if (!keys[foundDelim]) {
					tempEntities[foundDelim] = new messageParse_1.DEFAULT_DELIMITERS[foundDelim]({
						offset: foundIndex,
						length: -1,
						language: ""
					});
					keys[foundDelim] = true;
				} else {
					keys[foundDelim] = false;
					tempEntities[foundDelim].length = foundIndex - tempEntities[foundDelim].offset;
					entities.push(tempEntities[foundDelim]);
				}
				message = message.toString().replace(foundDelim, "");
				i = foundIndex;
			}
			return [message, entities];
		}
		static unparse(text, entities) {
			const delimiters = messageParse_1.DEFAULT_DELIMITERS;
			if (!text || !entities) return text;
			let insertAt = [];
			const tempDelimiters = /* @__PURE__ */ new Map();
			Object.keys(delimiters).forEach((key) => {
				tempDelimiters.set(delimiters[key].className, key);
			});
			for (const entity of entities) {
				const s = entity.offset;
				const e = entity.offset + entity.length;
				const delimiter = tempDelimiters.get(entity.className);
				if (delimiter) {
					insertAt.push([s, delimiter]);
					insertAt.push([e, delimiter]);
				}
			}
			insertAt = insertAt.sort((a, b) => {
				return a[0] - b[0];
			});
			while (insertAt.length) {
				const [at, what] = insertAt.pop();
				text = text.slice(0, at) + what + text.slice(at);
			}
			return text;
		}
	};
	exports.MarkdownParser = MarkdownParser;
}));
//#endregion
//#region node_modules/telegram/extensions/markdownv2.js
var require_markdownv2 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MarkdownV2Parser = void 0;
	var html_1 = require_html();
	var MarkdownV2Parser = class {
		static parse(message) {
			message = message.replace(/\*(.*?)\*/g, "<b>$1</b>");
			message = message.replace(/__(.*?)__/g, "<u>$1</u>");
			message = message.replace(/~(.*?)~/g, "<s>$1</s>");
			message = message.replace(/-(.*?)-/g, "<i>$1</i>");
			message = message.replace(/```([\s\S]*?)```/g, "<pre>$1</pre>");
			message = message.replace(/`(.*?)`/g, "<code>$1</code>");
			message = message.replace(/\|\|(.*?)\|\|/g, "<spoiler>$1</spoiler>");
			message = message.replace(/(?<!\!)\[([^\]]+)\]\(([^)]+)\)/g, "<a href=\"$2\">$1</a>");
			message = message.replace(/!\[([^\]]+)\]\(tg:\/\/emoji\?id=(\d+)\)/g, "<tg-emoji emoji-id=\"$2\">$1</tg-emoji>");
			return html_1.HTMLParser.parse(message);
		}
		static unparse(text, entities) {
			text = html_1.HTMLParser.unparse(text, entities);
			text = text.replace(/<b>(.*?)<\/b>/g, "*$1*");
			text = text.replace(/<u>(.*?)<\/u>/g, "__$1__");
			text = text.replace(/<code>(.*?)<\/code>/g, "`$1`");
			text = text.replace(/<pre>(.*?)<\/pre>/g, "```$1```");
			text = text.replace(/<s>(.*?)<\/s>/g, "~$1~");
			text = text.replace(/<i>(.*?)<\/i>/g, "-$1-");
			text = text.replace(/<spoiler>(.*?)<\/spoiler>/g, "||$1||");
			text = text.replace(/<a href="([^"]+)">([^<]+)<\/a>/g, "[$2]($1)");
			text = text.replace(/<tg-emoji emoji-id="(\d+)">([^<]+)<\/tg-emoji>/g, "![$2](tg://emoji?id=$1)");
			return text;
		}
	};
	exports.MarkdownV2Parser = MarkdownV2Parser;
}));
//#endregion
//#region node_modules/telegram/Utils.js
var require_Utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.getFileInfo = getFileInfo;
	exports.chunks = chunks;
	exports.getInputPeer = getInputPeer;
	exports._photoSizeByteCount = _photoSizeByteCount;
	exports._getEntityPair = _getEntityPair;
	exports.getInnerText = getInnerText;
	exports.getInputChannel = getInputChannel;
	exports.getInputUser = getInputUser;
	exports.getInputMessage = getInputMessage;
	exports.getInputChatPhoto = getInputChatPhoto;
	exports.strippedPhotoToJpg = strippedPhotoToJpg;
	exports.getInputPhoto = getInputPhoto;
	exports.getInputDocument = getInputDocument;
	exports.isAudio = isAudio;
	exports.isImage = isImage;
	exports.getExtension = getExtension;
	exports.getAttributes = getAttributes;
	exports.getInputGeo = getInputGeo;
	exports.getInputMedia = getInputMedia;
	exports.getAppropriatedPartSize = getAppropriatedPartSize;
	exports.getPeer = getPeer;
	exports.sanitizeParseMode = sanitizeParseMode;
	exports.getPeerId = getPeerId;
	exports.resolveId = resolveId;
	exports.getMessageId = getMessageId;
	exports.parsePhone = parsePhone;
	exports.parseID = parseID;
	exports.resolveInviteLink = resolveInviteLink;
	exports.parseUsername = parseUsername;
	exports.rtrim = rtrim;
	exports.getDisplayName = getDisplayName;
	var big_integer_1 = __importDefault(require_BigInteger());
	var mime_1 = __importDefault(require_mime());
	var html_1 = require_html();
	var markdown_1 = require_markdown();
	var markdownv2_1 = require_markdownv2();
	var Helpers_1 = require_Helpers();
	var tl_1 = require_tl();
	function getFileInfo(fileLocation) {
		if (!fileLocation || !fileLocation.SUBCLASS_OF_ID) _raiseCastFail(fileLocation, "InputFileLocation");
		if (fileLocation.SUBCLASS_OF_ID == 354669666) return {
			dcId: void 0,
			location: fileLocation,
			size: void 0
		};
		let location;
		if (fileLocation instanceof tl_1.Api.Message) location = fileLocation.media;
		if (fileLocation instanceof tl_1.Api.MessageMediaDocument) location = fileLocation.document;
		else if (fileLocation instanceof tl_1.Api.MessageMediaPhoto) location = fileLocation.photo;
		if (location instanceof tl_1.Api.Document) return {
			dcId: location.dcId,
			location: new tl_1.Api.InputDocumentFileLocation({
				id: location.id,
				accessHash: location.accessHash,
				fileReference: location.fileReference,
				thumbSize: ""
			}),
			size: location.size
		};
		else if (location instanceof tl_1.Api.Photo) return {
			dcId: location.dcId,
			location: new tl_1.Api.InputPhotoFileLocation({
				id: location.id,
				accessHash: location.accessHash,
				fileReference: location.fileReference,
				thumbSize: location.sizes[location.sizes.length - 1].type
			}),
			size: (0, big_integer_1.default)(_photoSizeByteCount(location.sizes[location.sizes.length - 1]) || 0)
		};
		_raiseCastFail(fileLocation, "InputFileLocation");
	}
	/**
	* Turns the given iterable into chunks of the specified size,
	* which is 100 by default since that's what Telegram uses the most.
	*/
	function* chunks(arr, size = 100) {
		for (let i = 0; i < arr.length; i += size) yield arr.slice(i, i + size);
	}
	var USERNAME_RE = /* @__PURE__ */ new RegExp("@|(?:https?:\\/\\/)?(?:www\\.)?(?:telegram\\.(?:me|dog)|t\\.me)\\/(@|joinchat\\/)?", "i");
	var JPEG_HEADER = Buffer.from("ffd8ffe000104a46494600010100000100010000ffdb004300281c1e231e19282321232d2b28303c64413c37373c7b585d4964918099968f808c8aa0b4e6c3a0aadaad8a8cc8ffcbdaeef5ffffff9bc1fffffffaffe6fdfff8ffdb0043012b2d2d3c353c76414176f8a58ca5f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8f8ffc00011080000000003012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00", "hex");
	var JPEG_FOOTER = Buffer.from("ffd9", "hex");
	var TG_JOIN_RE = /* @__PURE__ */ new RegExp("tg:\\/\\/(join)\\?invite=", "i");
	var VALID_USERNAME_RE = /* @__PURE__ */ new RegExp("^([a-z]((?!__)[\\w\\d]){3,30}[a-z\\d]|gif|vid|pic|bing|wiki|imdb|bold|vote|like|coub)$", "i");
	function _raiseCastFail(entity, target) {
		let toWrite = entity;
		if (typeof entity === "object" && "className" in entity) toWrite = entity.className;
		throw new Error(`Cannot cast ${toWrite} to any kind of ${target}`);
	}
	/**
	Gets the input peer for the given "entity" (user, chat or channel).
	
	A ``TypeError`` is raised if the given entity isn't a supported type
	or if ``check_hash is True`` but the entity's ``accessHash is None``
	*or* the entity contains ``min`` information. In this case, the hash
	cannot be used for general purposes, and thus is not returned to avoid
	any issues which can derive from invalid access hashes.
	
	Note that ``checkHash`` **is ignored** if an input peer is already
	passed since in that case we assume the user knows what they're doing.
	This is key to getting entities by explicitly passing ``hash = 0``.
	
	* @param entity
	* @param allowSelf
	* @param checkHash
	*/
	function getInputPeer(entity, allowSelf = true, checkHash = true) {
		if (entity.SUBCLASS_OF_ID === void 0) {
			if (allowSelf && "inputEntity" in entity) return entity.inputEntity;
			else if ("entity" in entity) return getInputPeer(entity.entity);
			else _raiseCastFail(entity, "InputPeer");
		}
		if (entity.SUBCLASS_OF_ID === 3374092470) return entity;
		if (entity instanceof tl_1.Api.User) {
			if (entity.self && allowSelf) return new tl_1.Api.InputPeerSelf();
			else if (entity.accessHash !== void 0 && !entity.min || !checkHash) return new tl_1.Api.InputPeerUser({
				userId: entity.id,
				accessHash: entity.accessHash || (0, big_integer_1.default)(0)
			});
			else throw new Error("User without accessHash or min cannot be input");
		}
		if (entity instanceof tl_1.Api.Chat || entity instanceof tl_1.Api.ChatEmpty || entity instanceof tl_1.Api.ChatForbidden) return new tl_1.Api.InputPeerChat({ chatId: entity.id });
		if (entity instanceof tl_1.Api.Channel) {
			if (entity.accessHash !== void 0 && !entity.min || !checkHash) return new tl_1.Api.InputPeerChannel({
				channelId: entity.id,
				accessHash: entity.accessHash || (0, big_integer_1.default)(0)
			});
			else throw new TypeError("Channel without accessHash or min info cannot be input");
		}
		if (entity instanceof tl_1.Api.ChannelForbidden) return new tl_1.Api.InputPeerChannel({
			channelId: entity.id,
			accessHash: entity.accessHash
		});
		if (entity instanceof tl_1.Api.InputUser) return new tl_1.Api.InputPeerUser({
			userId: entity.userId,
			accessHash: entity.accessHash
		});
		if (entity instanceof tl_1.Api.InputChannel) return new tl_1.Api.InputPeerChannel({
			channelId: entity.channelId,
			accessHash: entity.accessHash
		});
		if (entity instanceof tl_1.Api.UserEmpty) return new tl_1.Api.InputPeerEmpty();
		if (entity instanceof tl_1.Api.UserFull) return getInputPeer(entity.id);
		if (entity instanceof tl_1.Api.ChatFull) return new tl_1.Api.InputPeerChat({ chatId: entity.id });
		if (entity instanceof tl_1.Api.PeerChat) return new tl_1.Api.InputPeerChat({ chatId: entity.chatId });
		_raiseCastFail(entity, "InputPeer");
	}
	function _photoSizeByteCount(size) {
		if (size instanceof tl_1.Api.PhotoSize) return size.size;
		else if (size instanceof tl_1.Api.PhotoStrippedSize) {
			if (size.bytes.length < 3 || size.bytes[0] != 1) return size.bytes.length;
			return size.bytes.length + 622;
		} else if (size instanceof tl_1.Api.PhotoCachedSize) return size.bytes.length;
		else if (size instanceof tl_1.Api.PhotoSizeEmpty) return 0;
		else if (size instanceof tl_1.Api.PhotoSizeProgressive) return size.sizes[size.sizes.length - 1];
		else return;
	}
	function _getEntityPair(entityId, entities, cache, getInputPeerFunction = getInputPeer) {
		const entity = entities.get(entityId);
		let inputEntity;
		try {
			inputEntity = cache.get(entityId);
		} catch (e) {
			try {
				inputEntity = getInputPeerFunction(inputEntity);
			} catch (e) {}
		}
		return [entity, inputEntity];
	}
	function getInnerText(text, entities) {
		const result = [];
		entities.forEach(function(value, key) {
			const start = value.offset;
			const end = value.offset + value.length;
			result.push(text.slice(start, end));
		});
		return result;
	}
	/**
	Similar to :meth:`get_input_peer`, but for :tl:`InputChannel`'s alone.
	
	.. important::
	
	This method does not validate for invalid general-purpose access
	hashes, unlike `get_input_peer`. Consider using instead:
	``get_input_channel(get_input_peer(channel))``.
	
	* @param entity
	* @returns {InputChannel|*}
	*/
	function getInputChannel(entity) {
		if (typeof entity === "string" || typeof entity == "number" || typeof entity == "bigint" || big_integer_1.default.isInstance(entity)) _raiseCastFail(entity, "InputChannel");
		if (entity.SUBCLASS_OF_ID === void 0) _raiseCastFail(entity, "InputChannel");
		if (entity.SUBCLASS_OF_ID === 1089602301) return entity;
		if (entity instanceof tl_1.Api.Channel || entity instanceof tl_1.Api.ChannelForbidden) return new tl_1.Api.InputChannel({
			channelId: entity.id,
			accessHash: entity.accessHash || big_integer_1.default.zero
		});
		if (entity instanceof tl_1.Api.InputPeerChannel) return new tl_1.Api.InputChannel({
			channelId: entity.channelId,
			accessHash: entity.accessHash
		});
		_raiseCastFail(entity, "InputChannel");
	}
	/**
	Similar to :meth:`getInputPeer`, but for :tl:`InputUser`'s alone.
	
	.. important::
	
	This method does not validate for invalid general-purpose access
	hashes, unlike `get_input_peer`. Consider using instead:
	``get_input_channel(get_input_peer(channel))``.
	
	* @param entity
	*/
	function getInputUser(entity) {
		if (typeof entity === "string" || typeof entity == "number" || typeof entity == "bigint" || big_integer_1.default.isInstance(entity)) _raiseCastFail(entity, "InputUser");
		if (entity.SUBCLASS_OF_ID === void 0) _raiseCastFail(entity, "InputUser");
		if (entity.SUBCLASS_OF_ID === 3865689926) return entity;
		if (entity instanceof tl_1.Api.User) {
			if (entity.self) return new tl_1.Api.InputUserSelf();
			else return new tl_1.Api.InputUser({
				userId: entity.id,
				accessHash: entity.accessHash || big_integer_1.default.zero
			});
		}
		if (entity instanceof tl_1.Api.InputPeerSelf) return new tl_1.Api.InputUserSelf();
		if (entity instanceof tl_1.Api.UserEmpty || entity instanceof tl_1.Api.InputPeerEmpty) return new tl_1.Api.InputUserEmpty();
		if (entity instanceof tl_1.Api.UserFull) return getInputUser(entity);
		if (entity instanceof tl_1.Api.InputPeerUser) return new tl_1.Api.InputUser({
			userId: entity.userId,
			accessHash: entity.accessHash
		});
		if (entity instanceof tl_1.Api.InputPeerUserFromMessage) return new tl_1.Api.InputUserFromMessage({
			userId: entity.userId,
			peer: entity.peer,
			msgId: entity.msgId
		});
		_raiseCastFail(entity, "InputUser");
	}
	/**
	Similar to :meth:`get_input_peer`, but for dialogs
	* @param dialog
	*/
	/**
	*  Similar to :meth:`get_input_peer`, but for input messages.
	*/
	function getInputMessage(message) {
		if (typeof message === "number") return new tl_1.Api.InputMessageID({ id: message });
		if (message === void 0 || message.SUBCLASS_OF_ID === void 0) _raiseCastFail(message, "InputMessage");
		if (message.SUBCLASS_OF_ID === 1421262021) return message;
		else if (message.SUBCLASS_OF_ID === 2030045667) return new tl_1.Api.InputMessageID({ id: message.id });
		_raiseCastFail(message, "InputMessage");
	}
	/**
	*  Similar to :meth:`get_input_peer`, but for input messages.
	*/
	function getInputChatPhoto(photo) {
		if (photo === void 0 || photo.SUBCLASS_OF_ID === void 0) _raiseCastFail(photo, "InputChatPhoto");
		if (photo.SUBCLASS_OF_ID === 3572182388) return photo;
		else if (photo.SUBCLASS_OF_ID === 3882180383) return new tl_1.Api.InputChatUploadedPhoto({ file: photo });
		photo = getInputPhoto(photo);
		if (photo instanceof tl_1.Api.InputPhoto) return new tl_1.Api.InputChatPhoto({ id: photo });
		else if (photo instanceof tl_1.Api.InputPhotoEmpty) return new tl_1.Api.InputChatPhotoEmpty();
		_raiseCastFail(photo, "InputChatPhoto");
	}
	/**
	* Adds the JPG header and footer to a stripped image.
	* Ported from https://github.com/telegramdesktop/tdesktop/blob/bec39d89e19670eb436dc794a8f20b657cb87c71/Telegram/SourceFiles/ui/image/image.cpp#L225
	
	* @param stripped{Buffer}
	* @returns {Buffer}
	*/
	function strippedPhotoToJpg(stripped) {
		if (stripped.length < 3 || stripped[0] !== 1) return stripped;
		const header = Buffer.from(JPEG_HEADER);
		header[164] = stripped[1];
		header[166] = stripped[2];
		return Buffer.concat([
			header,
			stripped.slice(3),
			JPEG_FOOTER
		]);
	}
	/**
	*  Similar to :meth:`get_input_peer`, but for photos
	*/
	function getInputPhoto(photo) {
		if (photo.SUBCLASS_OF_ID === void 0) _raiseCastFail(photo, "InputPhoto");
		if (photo.SUBCLASS_OF_ID === 2221106144) return photo;
		if (photo instanceof tl_1.Api.Message) photo = photo.media;
		if (photo instanceof tl_1.Api.photos.Photo || photo instanceof tl_1.Api.MessageMediaPhoto) photo = photo.photo;
		if (photo instanceof tl_1.Api.Photo) return new tl_1.Api.InputPhoto({
			id: photo.id,
			accessHash: photo.accessHash,
			fileReference: photo.fileReference
		});
		if (photo instanceof tl_1.Api.PhotoEmpty) return new tl_1.Api.InputPhotoEmpty();
		if (photo instanceof tl_1.Api.messages.ChatFull) photo = photo.fullChat;
		if (photo instanceof tl_1.Api.ChannelFull) return getInputPhoto(photo.chatPhoto);
		else if (photo instanceof tl_1.Api.UserFull) return getInputPhoto(photo.profilePhoto);
		else if (photo instanceof tl_1.Api.Channel || photo instanceof tl_1.Api.Chat || photo instanceof tl_1.Api.User) return getInputPhoto(photo.photo);
		if (photo instanceof tl_1.Api.UserEmpty || photo instanceof tl_1.Api.ChatEmpty || photo instanceof tl_1.Api.ChatForbidden || photo instanceof tl_1.Api.ChannelForbidden) return new tl_1.Api.InputPhotoEmpty();
		_raiseCastFail(photo, "InputPhoto");
	}
	/**
	*  Similar to :meth:`get_input_peer`, but for documents
	*/
	function getInputDocument(document) {
		if (document.SUBCLASS_OF_ID === void 0) _raiseCastFail(document, "InputDocument");
		if (document.SUBCLASS_OF_ID === 4081048424) return document;
		if (document instanceof tl_1.Api.Document) return new tl_1.Api.InputDocument({
			id: document.id,
			accessHash: document.accessHash,
			fileReference: document.fileReference
		});
		if (document instanceof tl_1.Api.DocumentEmpty) return new tl_1.Api.InputDocumentEmpty();
		if (document instanceof tl_1.Api.MessageMediaDocument) return getInputDocument(document.document);
		if (document instanceof tl_1.Api.Message) return getInputDocument(document.media);
		_raiseCastFail(document, "InputDocument");
	}
	/**
	*  Returns `True` if the file has an audio mime type.
	*/
	function isAudio(file) {
		const ext = _getExtension(file);
		if (!ext) return (_getMetadata(file).get("mimeType") || "").startsWith("audio/");
		else {
			file = "a" + ext;
			return (mime_1.default.getType(file) || "").startsWith("audio/");
		}
	}
	/**
	*  Returns `True` if the file has an image mime type.
	*/
	function isImage(file) {
		const ext = _getExtension(file).toLowerCase();
		return ext.endsWith(".png") || ext.endsWith(".jpg") || ext.endsWith(".jpeg");
	}
	function getExtension(media) {
		try {
			getInputPhoto(media);
			return ".jpg";
		} catch (e) {}
		if (media instanceof tl_1.Api.UserProfilePhoto || media instanceof tl_1.Api.ChatPhoto) return ".jpg";
		if (media instanceof tl_1.Api.MessageMediaDocument) media = media.document;
		if (media instanceof tl_1.Api.Document || media instanceof tl_1.Api.WebDocument || media instanceof tl_1.Api.WebDocumentNoProxy) {
			if (media.mimeType === "application/octet-stream") return "";
			else return mime_1.default.getExtension(media.mimeType) || "";
		}
		return "";
	}
	/**
	* Gets the extension for the given file, which can be either a
	* str or an ``open()``'ed file (which has a ``.name`` attribute).
	*/
	function _getExtension(file) {
		if (typeof file === "string") return "." + file.split(".").pop();
		else if ("name" in file) return _getExtension(file.name);
		else return getExtension(file);
	}
	function _getMetadata(file) {
		return /* @__PURE__ */ new Map();
	}
	function isVideo(file) {
		var _a;
		const ext = _getExtension(file);
		if (!ext) {
			const metadata = _getMetadata(file);
			if (metadata.has("mimeType")) return ((_a = metadata.get("mimeType")) === null || _a === void 0 ? void 0 : _a.startsWith("video/")) || false;
			else return false;
		} else {
			file = "a" + ext;
			return (mime_1.default.getType(file) || "").startsWith("video/");
		}
	}
	/**
	Get a list of attributes for the given file and
	the mime type as a tuple ([attribute], mime_type).
	*/
	function getAttributes(file, { attributes = null, mimeType = void 0, forceDocument = false, voiceNote = false, videoNote = false, supportsStreaming = false, thumb = null }) {
		var _a, _b, _c, _d;
		const name = typeof file == "string" ? file : "name" in file ? file.name || "unnamed" : "unnamed";
		if (mimeType === void 0) mimeType = mime_1.default.getType(name) || "application/octet-stream";
		const attrObj = /* @__PURE__ */ new Map();
		attrObj.set(tl_1.Api.DocumentAttributeFilename, new tl_1.Api.DocumentAttributeFilename({ fileName: name.split(/[\\/]/).pop() || "" }));
		if (isAudio(file)) {
			const m = _getMetadata(file);
			attrObj.set(tl_1.Api.DocumentAttributeAudio, new tl_1.Api.DocumentAttributeAudio({
				voice: voiceNote,
				title: m.has("title") ? m.get("title") : void 0,
				performer: m.has("author") ? m.get("author") : void 0,
				duration: Number.parseInt((_a = m.get("duration")) !== null && _a !== void 0 ? _a : "0")
			}));
		}
		if (!forceDocument && isVideo(file)) {
			let doc;
			if (thumb) {
				const t_m = _getMetadata(thumb);
				const width = Number.parseInt((t_m === null || t_m === void 0 ? void 0 : t_m.get("width")) || "1");
				const height = Number.parseInt((t_m === null || t_m === void 0 ? void 0 : t_m.get("height")) || "1");
				doc = new tl_1.Api.DocumentAttributeVideo({
					duration: 0,
					h: height,
					w: width,
					roundMessage: videoNote,
					supportsStreaming
				});
			} else {
				const m = _getMetadata(file);
				doc = new tl_1.Api.DocumentAttributeVideo({
					roundMessage: videoNote,
					w: Number.parseInt((_b = m.get("width")) !== null && _b !== void 0 ? _b : "1"),
					h: Number.parseInt((_c = m.get("height")) !== null && _c !== void 0 ? _c : "1"),
					duration: Number.parseInt((_d = m.get("duration")) !== null && _d !== void 0 ? _d : "0"),
					supportsStreaming
				});
			}
			attrObj.set(tl_1.Api.DocumentAttributeVideo, doc);
		}
		if (videoNote) {
			if (attrObj.has(tl_1.Api.DocumentAttributeAudio)) attrObj.get(tl_1.Api.DocumentAttributeAudio).voice = true;
			else attrObj.set(tl_1.Api.DocumentAttributeAudio, new tl_1.Api.DocumentAttributeAudio({
				duration: 0,
				voice: true
			}));
		}
		if (attributes) for (const a of attributes) attrObj.set(a.constructor, a);
		return {
			attrs: Array.from(attrObj.values()),
			mimeType
		};
	}
	/**
	*  Similar to :meth:`get_input_peer`, but for geo points
	*/
	function getInputGeo(geo) {
		if (geo === void 0 || geo.SUBCLASS_OF_ID === void 0) _raiseCastFail(geo, "InputGeoPoint");
		if (geo.SUBCLASS_OF_ID === 70308389) return geo;
		if (geo instanceof tl_1.Api.GeoPoint) return new tl_1.Api.InputGeoPoint({
			lat: geo.lat,
			long: geo.long
		});
		if (geo instanceof tl_1.Api.GeoPointEmpty) return new tl_1.Api.InputGeoPointEmpty();
		if (geo instanceof tl_1.Api.MessageMediaGeo) return getInputGeo(geo.geo);
		if (geo instanceof tl_1.Api.Message) return getInputGeo(geo.media);
		_raiseCastFail(geo, "InputGeoPoint");
	}
	/**
	*
	Similar to :meth:`get_input_peer`, but for media.
	
	If the media is :tl:`InputFile` and ``is_photo`` is known to be `True`,
	it will be treated as an :tl:`InputMediaUploadedPhoto`. Else, the rest
	of parameters will indicate how to treat it.
	* @param media
	* @param isPhoto - whether it's a photo or not
	* @param attributes
	* @param forceDocument
	* @param voiceNote
	* @param videoNote
	* @param supportsStreaming
	*/
	function getInputMedia(media, { isPhoto = false, attributes = void 0, forceDocument = false, voiceNote = false, videoNote = false, supportsStreaming = false } = {}) {
		if (media.SUBCLASS_OF_ID === void 0) _raiseCastFail(media, "InputMedia");
		if (media.SUBCLASS_OF_ID === 4210575092) return media;
		else if (media.SUBCLASS_OF_ID === 2221106144) return new tl_1.Api.InputMediaPhoto({ id: media });
		else if (media.SUBCLASS_OF_ID === 4081048424) return new tl_1.Api.InputMediaDocument({ id: media });
		if (media instanceof tl_1.Api.MessageMediaPhoto) return new tl_1.Api.InputMediaPhoto({
			id: getInputPhoto(media.photo),
			ttlSeconds: media.ttlSeconds
		});
		if (media instanceof tl_1.Api.Photo || media instanceof tl_1.Api.photos.Photo || media instanceof tl_1.Api.PhotoEmpty) return new tl_1.Api.InputMediaPhoto({ id: getInputPhoto(media) });
		if (media instanceof tl_1.Api.MessageMediaDocument) return new tl_1.Api.InputMediaDocument({
			id: getInputDocument(media.document),
			ttlSeconds: media.ttlSeconds
		});
		if (media instanceof tl_1.Api.Document || media instanceof tl_1.Api.DocumentEmpty) return new tl_1.Api.InputMediaDocument({ id: getInputDocument(media) });
		if (media instanceof tl_1.Api.InputFile || media instanceof tl_1.Api.InputFileBig) {
			if (isPhoto) return new tl_1.Api.InputMediaUploadedPhoto({ file: media });
			else {
				const { attrs, mimeType } = getAttributes(media, {
					attributes,
					forceDocument,
					voiceNote,
					videoNote,
					supportsStreaming
				});
				return new tl_1.Api.InputMediaUploadedDocument({
					file: media,
					mimeType,
					attributes: attrs,
					forceFile: forceDocument
				});
			}
		}
		if (media instanceof tl_1.Api.MessageMediaGame) return new tl_1.Api.InputMediaGame({ id: new tl_1.Api.InputGameID({
			id: media.game.id,
			accessHash: media.game.accessHash
		}) });
		if (media instanceof tl_1.Api.MessageMediaContact) return new tl_1.Api.InputMediaContact({
			phoneNumber: media.phoneNumber,
			firstName: media.firstName,
			lastName: media.lastName,
			vcard: ""
		});
		if (media instanceof tl_1.Api.MessageMediaGeo) return new tl_1.Api.InputMediaGeoPoint({ geoPoint: getInputGeo(media.geo) });
		if (media instanceof tl_1.Api.MessageMediaVenue) return new tl_1.Api.InputMediaVenue({
			geoPoint: getInputGeo(media.geo),
			title: media.title,
			address: media.address,
			provider: media.provider,
			venueId: media.venueId,
			venueType: ""
		});
		if (media instanceof tl_1.Api.MessageMediaDice) return new tl_1.Api.InputMediaDice({ emoticon: media.emoticon });
		if (media instanceof tl_1.Api.MessageMediaEmpty || media instanceof tl_1.Api.MessageMediaUnsupported || media instanceof tl_1.Api.ChatPhotoEmpty || media instanceof tl_1.Api.UserProfilePhotoEmpty || media instanceof tl_1.Api.ChatPhoto || media instanceof tl_1.Api.UserProfilePhoto) return new tl_1.Api.InputMediaEmpty();
		if (media instanceof tl_1.Api.Message) return getInputMedia(media.media, { isPhoto });
		if (media instanceof tl_1.Api.MessageMediaPoll) {
			let correctAnswers;
			if (media.poll.quiz) {
				if (!media.results.results) throw new Error("Cannot cast unanswered quiz to any kind of InputMedia.");
				correctAnswers = [];
				for (const r of media.results.results) if (r.correct) correctAnswers.push(r.option);
			} else correctAnswers = void 0;
			return new tl_1.Api.InputMediaPoll({
				poll: media.poll,
				correctAnswers,
				solution: media.results.solution,
				solutionEntities: media.results.solutionEntities
			});
		}
		if (media instanceof tl_1.Api.Poll) return new tl_1.Api.InputMediaPoll({ poll: media });
		_raiseCastFail(media, "InputMedia");
	}
	/**
	* Gets the appropriated part size when uploading or downloading files,
	* given an initial file size.
	* @param fileSize
	* @returns {Number}
	*/
	function getAppropriatedPartSize(fileSize) {
		if (fileSize.lesser(104857600)) return 128;
		if (fileSize.lesser(786432e3)) return 256;
		return 512;
	}
	function getPeer(peer) {
		if (!peer) _raiseCastFail(peer, "undefined");
		if (typeof peer === "string") _raiseCastFail(peer, "peer");
		if (typeof peer == "number" || typeof peer == "bigint") peer = (0, Helpers_1.returnBigInt)(peer);
		try {
			if (big_integer_1.default.isInstance(peer)) {
				const res = resolveId(peer);
				if (res[1] === tl_1.Api.PeerChannel) return new tl_1.Api.PeerChannel({ channelId: res[0] });
				else if (res[1] === tl_1.Api.PeerChat) return new tl_1.Api.PeerChat({ chatId: res[0] });
				else return new tl_1.Api.PeerUser({ userId: res[0] });
			}
			if (peer.SUBCLASS_OF_ID === void 0) throw new Error();
			if (peer.SUBCLASS_OF_ID === 47470215) return peer;
			else if (peer instanceof tl_1.Api.contacts.ResolvedPeer || peer instanceof tl_1.Api.InputNotifyPeer || peer instanceof tl_1.Api.TopPeer || peer instanceof tl_1.Api.Dialog || peer instanceof tl_1.Api.DialogPeer) return peer.peer;
			else if (peer instanceof tl_1.Api.ChannelFull) return new tl_1.Api.PeerChannel({ channelId: peer.id });
			if (peer.SUBCLASS_OF_ID === 2105307014 || peer.SUBCLASS_OF_ID === 3653762072) {
				if ("userId" in peer) return new tl_1.Api.PeerUser({ userId: peer.userId });
			}
			peer = getInputPeer(peer, false, false);
			if (peer instanceof tl_1.Api.InputPeerUser) return new tl_1.Api.PeerUser({ userId: peer.userId });
			else if (peer instanceof tl_1.Api.InputPeerChat) return new tl_1.Api.PeerChat({ chatId: peer.chatId });
			else if (peer instanceof tl_1.Api.InputPeerChannel) return new tl_1.Api.PeerChannel({ channelId: peer.channelId });
		} catch (e) {}
		_raiseCastFail(peer, "peer");
	}
	function sanitizeParseMode(mode) {
		if (mode === "md" || mode === "markdown") return markdown_1.MarkdownParser;
		if (mode === "md2" || mode === "markdownv2") return markdownv2_1.MarkdownV2Parser;
		if (mode == "html") return html_1.HTMLParser;
		if (typeof mode == "object") {
			if ("parse" in mode && "unparse" in mode) return mode;
		}
		throw new Error(`Invalid parse mode type ${mode}`);
	}
	/**
	Convert the given peer into its marked ID by default.
	
	This "mark" comes from the "bot api" format, and with it the peer type
	can be identified back. User ID is left unmodified, chat ID is negated,
	and channel ID is prefixed with -100:
	
	* ``userId``
	* ``-chatId``
	* ``-100channel_id``
	
	The original ID and the peer type class can be returned with
	a call to :meth:`resolve_id(marked_id)`.
	* @param peer
	* @param addMark
	*/
	function getPeerId(peer, addMark = true) {
		if (typeof peer == "string" && parseID(peer)) peer = (0, Helpers_1.returnBigInt)(peer);
		if (big_integer_1.default.isInstance(peer)) return addMark ? peer.toString() : resolveId(peer)[0].toString();
		if (peer instanceof tl_1.Api.InputPeerSelf) _raiseCastFail(peer, "int (you might want to use client.get_peer_id)");
		try {
			peer = getPeer(peer);
		} catch (e) {
			_raiseCastFail(peer, "int");
		}
		if (peer instanceof tl_1.Api.PeerUser) return peer.userId.toString();
		else if (peer instanceof tl_1.Api.PeerChat) {
			peer.chatId = resolveId((0, Helpers_1.returnBigInt)(peer.chatId))[0];
			return addMark ? peer.chatId.negate().toString() : peer.chatId.toString();
		} else if (typeof peer == "object" && "channelId" in peer) {
			peer.channelId = resolveId((0, Helpers_1.returnBigInt)(peer.channelId))[0];
			if (!addMark) return peer.channelId.toString();
			return "-100" + peer.channelId.toString();
		}
		_raiseCastFail(peer, "int");
	}
	/**
	* Given a marked ID, returns the original ID and its :tl:`Peer` type.
	* @param markedId
	*/
	function resolveId(markedId) {
		if (markedId.greaterOrEquals(big_integer_1.default.zero)) return [markedId, tl_1.Api.PeerUser];
		const m = markedId.toString().match(/-100([^0]\d*)/);
		if (m) return [(0, big_integer_1.default)(m[1]), tl_1.Api.PeerChannel];
		return [markedId.negate(), tl_1.Api.PeerChat];
	}
	/**
	* returns an entity pair
	* @param entityId
	* @param entities
	* @param cache
	* @param getInputPeer
	* @returns {{inputEntity: *, entity: *}}
	* @private
	*/
	function getMessageId(message) {
		if (!message) return;
		else if (typeof message === "number") return message;
		else if (message.SUBCLASS_OF_ID === 2030045667 || "id" in message) return message.id;
		else throw new Error(`Invalid message type: ${message.constructor.name}`);
	}
	/**
	* Parses the given phone, or returns `undefined` if it's invalid.
	* @param phone
	*/
	function parsePhone(phone) {
		phone = phone.toString().replace(/[()\s-]/gm, "");
		if (phone.startsWith("+") && phone.split("+").length - 1 == 1) return !isNaN(Number(phone)) ? phone.replace("+", "") : void 0;
	}
	/**
	* Parses a string ID into a big int
	* @param id
	*/
	function parseID(id) {
		return /^(-?[0-9][0-9]*)$/.test(id) ? (0, big_integer_1.default)(id) : void 0;
	}
	function resolveInviteLink(link) {
		throw new Error("not implemented");
	}
	/**
	Parses the given username or channel access hash, given
	a string, username or URL. Returns a tuple consisting of
	both the stripped, lowercase username and whether it is
	a joinchat/ hash (in which case is not lowercase'd).
	
	Returns ``(undefined, false)`` if the ``username`` or link is not valid.
	
	* @param username {string}
	*/
	function parseUsername(username) {
		username = username.trim();
		const m = username.match(USERNAME_RE) || username.match(TG_JOIN_RE);
		if (m) {
			username = username.replace(m[0], "");
			if (m[1]) return {
				username,
				isInvite: true
			};
			else username = rtrim(username, "/");
		}
		if (username.match(VALID_USERNAME_RE)) return {
			username: username.toLowerCase(),
			isInvite: false
		};
		else return {
			username: void 0,
			isInvite: false
		};
	}
	function rtrim(s, mask) {
		while (~mask.indexOf(s[s.length - 1])) s = s.slice(0, -1);
		return s;
	}
	/**
	* Gets the display name for the given :tl:`User`,
	:tl:`Chat` or :tl:`Channel`. Returns an empty string otherwise
	* @param entity
	*/
	function getDisplayName(entity) {
		if (entity instanceof tl_1.Api.User) {
			if (entity.lastName && entity.firstName) return `${entity.firstName} ${entity.lastName}`;
			else if (entity.firstName) return entity.firstName;
			else if (entity.lastName) return entity.lastName;
			else return "";
		} else if (entity instanceof tl_1.Api.Chat || entity instanceof tl_1.Api.Channel) return entity.title;
		return "";
	}
}));
/**
* check if a given item is an array like or not
* @param item
* @returns {boolean}
*/
//#endregion
//#region node_modules/telegram/tl/custom/forward.js
var require_forward = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Forward = void 0;
	var chatGetter_1 = require_chatGetter();
	var senderGetter_1 = require_senderGetter();
	var Helpers_1 = require_Helpers();
	var Utils_1 = require_Utils();
	var inspect_1 = require_inspect();
	var Forward = class extends senderGetter_1.SenderGetter {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, original, entities) {
			super();
			this.originalFwd = original;
			let senderId = void 0;
			let sender = void 0;
			let inputSender = void 0;
			let peer = void 0;
			let chat = void 0;
			let inputChat = void 0;
			if (original.fromId) {
				const ty = (0, Helpers_1._entityType)(original.fromId);
				if (ty === Helpers_1._EntityType.USER) {
					senderId = (0, Utils_1.getPeerId)(original.fromId);
					[sender, inputSender] = (0, Utils_1._getEntityPair)(senderId, entities, client._entityCache);
				} else if (ty === Helpers_1._EntityType.CHANNEL || ty === Helpers_1._EntityType.CHAT) {
					peer = original.fromId;
					[chat, inputChat] = (0, Utils_1._getEntityPair)((0, Utils_1.getPeerId)(peer), entities, client._entityCache);
				}
			}
			chatGetter_1.ChatGetter.initChatClass(this, {
				chatPeer: peer,
				chat,
				inputChat
			});
			senderGetter_1.SenderGetter.initSenderClass(this, {
				senderId: senderId ? (0, Helpers_1.returnBigInt)(senderId) : void 0,
				sender,
				inputSender
			});
			this._client = client;
		}
	};
	exports.Forward = Forward;
}));
//#endregion
//#region node_modules/telegram/tl/custom/file.js
var require_file = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.File = void 0;
	var api_1 = require_api();
	var Utils_1 = require_Utils();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var File = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(media) {
			this.media = media;
		}
		get id() {
			throw new Error("Unsupported");
		}
		get name() {
			return this._fromAttr(api_1.Api.DocumentAttributeFilename, "fileName");
		}
		get mimeType() {
			if (this.media instanceof api_1.Api.Photo) return "image/jpeg";
			else if (this.media instanceof api_1.Api.Document) return this.media.mimeType;
		}
		get width() {
			return this._fromAttr([api_1.Api.DocumentAttributeImageSize, api_1.Api.DocumentAttributeVideo], "w");
		}
		get height() {
			return this._fromAttr([api_1.Api.DocumentAttributeImageSize, api_1.Api.DocumentAttributeVideo], "h");
		}
		get duration() {
			return this._fromAttr([api_1.Api.DocumentAttributeAudio, api_1.Api.DocumentAttributeVideo], "duration");
		}
		get title() {
			return this._fromAttr(api_1.Api.DocumentAttributeAudio, "title");
		}
		get performer() {
			return this._fromAttr(api_1.Api.DocumentAttributeAudio, "performer");
		}
		get emoji() {
			return this._fromAttr(api_1.Api.DocumentAttributeSticker, "alt");
		}
		get stickerSet() {
			return this._fromAttr(api_1.Api.DocumentAttributeSticker, "stickerset");
		}
		get size() {
			if (this.media instanceof api_1.Api.Photo) return (0, Utils_1._photoSizeByteCount)(this.media.sizes[this.media.sizes.length - 1]);
			else if (this.media instanceof api_1.Api.Document) return this.media.size;
		}
		_fromAttr(cls, field) {
			if (this.media instanceof api_1.Api.Document) {
				for (const attr of this.media.attributes) if (attr instanceof cls) return attr[field];
			}
		}
	};
	exports.File = File;
}));
//#endregion
//#region node_modules/telegram/extensions/Logger.js
var require_Logger = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Logger = exports.LogLevel = void 0;
	var platform_1 = require_platform();
	var LogLevel;
	(function(LogLevel) {
		LogLevel["NONE"] = "none";
		LogLevel["ERROR"] = "error";
		LogLevel["WARN"] = "warn";
		LogLevel["INFO"] = "info";
		LogLevel["DEBUG"] = "debug";
	})(LogLevel || (exports.LogLevel = LogLevel = {}));
	var Logger = class {
		constructor(level) {
			this.levels = [
				"error",
				"warn",
				"info",
				"debug"
			];
			this._logLevel = level || LogLevel.INFO;
			this.isBrowser = !platform_1.isNode;
			if (!this.isBrowser) this.colors = {
				start: "\x1B[2m",
				warn: "\x1B[35m",
				info: "\x1B[33m",
				debug: "\x1B[36m",
				error: "\x1B[31m",
				end: "\x1B[0m"
			};
			else this.colors = {
				start: "%c",
				warn: "color : #ff00ff",
				info: "color : #ffff00",
				debug: "color : #00ffff",
				error: "color : #ff0000",
				end: ""
			};
			this.messageFormat = "[%t] [%l] - [%m]";
			this.tzOffset = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 6e4;
		}
		/**
		*
		* @param level {string}
		* @returns {boolean}
		*/
		canSend(level) {
			return this._logLevel ? this.levels.indexOf(this._logLevel) >= this.levels.indexOf(level) : false;
		}
		/**
		* @param message {string}
		*/
		warn(message) {
			this._log(LogLevel.WARN, message, this.colors.warn);
		}
		/**
		* @param message {string}
		*/
		info(message) {
			this._log(LogLevel.INFO, message, this.colors.info);
		}
		/**
		* @param message {string}
		*/
		debug(message) {
			this._log(LogLevel.DEBUG, message, this.colors.debug);
		}
		/**
		* @param message {string}
		*/
		error(message) {
			this._log(LogLevel.ERROR, message, this.colors.error);
		}
		format(message, level) {
			return this.messageFormat.replace("%t", this.getDateTime()).replace("%l", level.toUpperCase()).replace("%m", message);
		}
		get logLevel() {
			return this._logLevel;
		}
		setLevel(level) {
			this._logLevel = level;
		}
		static setLevel(level) {
			console.log("Logger.setLevel is deprecated, it will has no effect. Please, use client.setLogLevel instead.");
		}
		/**
		* @param level {string}
		* @param message {string}
		* @param color {string}
		*/
		_log(level, message, color) {
			if (this.canSend(level)) this.log(level, message, color);
			else return;
		}
		/**
		* Override this function for custom Logger. <br />
		*
		* @remarks use `this.isBrowser` to check and handle for different environment.
		* @param level {string}
		* @param message {string}
		* @param color {string}
		*/
		log(level, message, color) {
			if (!this.isBrowser) console.log(color + this.format(message, level) + this.colors.end);
			else console.log(this.colors.start + this.format(message, level), color);
		}
		getDateTime() {
			return new Date(Date.now() - this.tzOffset).toISOString().slice(0, -1);
		}
	};
	exports.Logger = Logger;
}));
//#endregion
//#region node_modules/telegram/extensions/Deferred.js
var require_Deferred = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = class Deferred {
		constructor() {
			this.promise = new Promise((resolve, reject) => {
				this.reject = reject;
				this.resolve = resolve;
			});
		}
		static resolved(value) {
			const deferred = new Deferred();
			deferred.resolve(value);
			return deferred;
		}
	};
}));
//#endregion
//#region node_modules/telegram/network/RequestState.js
var require_RequestState = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.RequestState = void 0;
	var Deferred_1 = __importDefault(require_Deferred());
	var RequestState = class {
		constructor(request) {
			this.containerId = void 0;
			this.msgId = void 0;
			this.request = request;
			this.data = request.getBytes();
			this.after = void 0;
			this.result = void 0;
			this.finished = new Deferred_1.default();
			this.resetPromise();
		}
		isReady() {
			if (!this.after) return true;
			return this.after.finished.promise;
		}
		resetPromise() {
			var _a;
			(_a = this.reject) === null || _a === void 0 || _a.call(this);
			this.promise = new Promise((resolve, reject) => {
				this.resolve = resolve;
				this.reject = reject;
			});
		}
	};
	exports.RequestState = RequestState;
}));
//#endregion
//#region node_modules/telegram/client/users.js
var require_users = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.invoke = invoke;
	exports.getMe = getMe;
	exports.isBot = isBot;
	exports.isUserAuthorized = isUserAuthorized;
	exports.getEntity = getEntity;
	exports.getInputEntity = getInputEntity;
	exports._getEntityFromString = _getEntityFromString;
	exports.getPeerId = getPeerId;
	exports._getPeer = _getPeer;
	exports._getInputDialog = _getInputDialog;
	exports._getInputNotify = _getInputNotify;
	exports._selfId = _selfId;
	var tl_1 = require_tl();
	var Utils_1 = require_Utils();
	var Helpers_1 = require_Helpers();
	var __1 = require_telegram();
	var big_integer_1 = __importDefault(require_BigInteger());
	var Logger_1 = require_Logger();
	var RequestState_1 = require_RequestState();
	/** @hidden */
	async function invoke(client, request, dcId, otherSender) {
		if (request.classType !== "request") throw new Error("You can only invoke MTProtoRequests");
		let sender = client._sender;
		if (dcId) sender = await client.getSender(dcId);
		if (otherSender != void 0) sender = otherSender;
		if (sender == void 0) throw new Error("Cannot send requests while disconnected. You need to call .connect()");
		if (sender.userDisconnected) throw new Error("Cannot send requests while disconnected. Please reconnect.");
		await client._connectedDeferred.promise;
		await request.resolve(client, __1.utils);
		client._lastRequest = (/* @__PURE__ */ new Date()).getTime();
		const state = new RequestState_1.RequestState(request);
		let attempt = 0;
		for (attempt = 0; attempt < client._requestRetries; attempt++) {
			sender.addStateToQueue(state);
			try {
				const result = await state.promise;
				state.finished.resolve();
				client.session.processEntities(result);
				client._entityCache.add(result);
				return result;
			} catch (e) {
				if (e instanceof __1.errors.ServerError || e.errorMessage === "RPC_CALL_FAIL" || e.errorMessage === "RPC_MCGET_FAIL") {
					client._log.warn(`Telegram is having internal issues ${e.constructor.name}`);
					await (0, Helpers_1.sleep)(2e3);
				} else if (e instanceof __1.errors.FloodWaitError || e instanceof __1.errors.FloodTestPhoneWaitError) {
					if (e.seconds <= client.floodSleepThreshold) {
						client._log.info(`Sleeping for ${e.seconds}s on flood wait (Caused by ${request.className})`);
						await (0, Helpers_1.sleep)(e.seconds * 1e3);
					} else {
						state.finished.resolve();
						throw e;
					}
				} else if (e instanceof __1.errors.PhoneMigrateError || e instanceof __1.errors.NetworkMigrateError || e instanceof __1.errors.UserMigrateError) {
					client._log.info(`Phone migrated to ${e.newDc}`);
					if ((e instanceof __1.errors.PhoneMigrateError || e instanceof __1.errors.NetworkMigrateError) && await client.isUserAuthorized()) {
						state.finished.resolve();
						throw e;
					}
					await client._switchDC(e.newDc);
					sender = dcId === void 0 ? client._sender : await client.getSender(dcId);
				} else if (e instanceof __1.errors.MsgWaitError) {
					await state.isReady();
					state.after = void 0;
				} else if (e.message === "CONNECTION_NOT_INITED") {
					await client.disconnect();
					await (0, Helpers_1.sleep)(2e3);
					await client.connect();
				} else {
					state.finished.resolve();
					throw e;
				}
			}
			state.resetPromise();
		}
		throw new Error(`Request was unsuccessful ${attempt} time(s)`);
	}
	/** @hidden */
	async function getMe(client, inputPeer) {
		if (inputPeer && client._selfInputPeer) return client._selfInputPeer;
		const me = (await client.invoke(new tl_1.Api.users.GetUsers({ id: [new tl_1.Api.InputUserSelf()] })))[0];
		client._bot = me.bot;
		if (!client._selfInputPeer) client._selfInputPeer = __1.utils.getInputPeer(me, false);
		return inputPeer ? client._selfInputPeer : me;
	}
	/** @hidden */
	async function isBot(client) {
		if (client._bot === void 0) {
			const me = await client.getMe();
			if (me) return !(me instanceof tl_1.Api.InputPeerUser) ? me.bot : void 0;
		}
		return client._bot;
	}
	/** @hidden */
	async function isUserAuthorized(client) {
		try {
			await client.invoke(new tl_1.Api.updates.GetState());
			return true;
		} catch (e) {
			return false;
		}
	}
	/** @hidden */
	async function getEntity(client, entity) {
		const single = !(0, Helpers_1.isArrayLike)(entity);
		let entityArray = [];
		if ((0, Helpers_1.isArrayLike)(entity)) entityArray = entity;
		else entityArray.push(entity);
		const inputs = [];
		for (const x of entityArray) if (typeof x === "string") {
			const valid = (0, Utils_1.parseID)(x);
			if (valid) inputs.push(await client.getInputEntity(valid));
			else inputs.push(x);
		} else inputs.push(await client.getInputEntity(x));
		const lists = /* @__PURE__ */ new Map([
			[Helpers_1._EntityType.USER, []],
			[Helpers_1._EntityType.CHAT, []],
			[Helpers_1._EntityType.CHANNEL, []]
		]);
		for (const x of inputs) try {
			lists.get((0, Helpers_1._entityType)(x)).push(x);
		} catch (e) {}
		let users = lists.get(Helpers_1._EntityType.USER);
		let chats = lists.get(Helpers_1._EntityType.CHAT);
		let channels = lists.get(Helpers_1._EntityType.CHANNEL);
		if (users.length) users = await client.invoke(new tl_1.Api.users.GetUsers({ id: users }));
		if (chats.length) {
			const chatIds = chats.map((x) => x.chatId);
			chats = (await client.invoke(new tl_1.Api.messages.GetChats({ id: chatIds }))).chats;
		}
		if (channels.length) channels = (await client.invoke(new tl_1.Api.channels.GetChannels({ id: channels }))).chats;
		const idEntity = /* @__PURE__ */ new Map();
		for (const user of users) idEntity.set((0, Utils_1.getPeerId)(user), user);
		for (const channel of channels) idEntity.set((0, Utils_1.getPeerId)(channel), channel);
		for (const chat of chats) idEntity.set((0, Utils_1.getPeerId)(chat), chat);
		const result = [];
		for (const x of inputs) if (typeof x === "string") result.push(await _getEntityFromString(client, x));
		else if (!(x instanceof tl_1.Api.InputPeerSelf)) result.push(idEntity.get((0, Utils_1.getPeerId)(x)));
		else for (const [key, u] of idEntity.entries()) if (u instanceof tl_1.Api.User && u.self) {
			result.push(u);
			break;
		}
		return single ? result[0] : result;
	}
	/** @hidden */
	async function getInputEntity(client, peer) {
		try {
			return __1.utils.getInputPeer(peer);
		} catch (e) {}
		try {
			if (typeof peer == "string") {
				if ((0, Utils_1.parseID)(peer)) {
					const res = client._entityCache.get(peer);
					if (res) return res;
				}
			}
			if (typeof peer === "number" || typeof peer === "bigint" || big_integer_1.default.isInstance(peer)) {
				const res = client._entityCache.get(peer.toString());
				if (res) return res;
			}
			if (typeof peer == "object" && !big_integer_1.default.isInstance(peer) && peer.SUBCLASS_OF_ID === 47470215) {
				const res = client._entityCache.get(__1.utils.getPeerId(peer));
				if (res) return res;
			}
		} catch (e) {}
		if (typeof peer == "string") {
			if ([
				"me",
				"this",
				"self"
			].includes(peer)) return new tl_1.Api.InputPeerSelf();
		}
		try {
			if (peer != void 0) return client.session.getInputEntity(peer);
		} catch (e) {}
		if (typeof peer === "string") return __1.utils.getInputPeer(await _getEntityFromString(client, peer));
		if (typeof peer === "number") peer = (0, Helpers_1.returnBigInt)(peer);
		peer = __1.utils.getPeer(peer);
		if (peer instanceof tl_1.Api.PeerUser) {
			const users = await client.invoke(new tl_1.Api.users.GetUsers({ id: [new tl_1.Api.InputUser({
				userId: peer.userId,
				accessHash: big_integer_1.default.zero
			})] }));
			if (users.length && !(users[0] instanceof tl_1.Api.UserEmpty)) return __1.utils.getInputPeer(users[0]);
		} else if (peer instanceof tl_1.Api.PeerChat) return new tl_1.Api.InputPeerChat({ chatId: peer.chatId });
		else if (peer instanceof tl_1.Api.PeerChannel) try {
			const channels = await client.invoke(new tl_1.Api.channels.GetChannels({ id: [new tl_1.Api.InputChannel({
				channelId: peer.channelId,
				accessHash: big_integer_1.default.zero
			})] }));
			return __1.utils.getInputPeer(channels.chats[0]);
		} catch (e) {
			if (client._errorHandler) await client._errorHandler(e);
			if (client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
		}
		throw new Error(`Could not find the input entity for ${JSON.stringify(peer)}.
         Please read https://docs.telethon.dev/en/stable/concepts/entities.html to find out more details.`);
	}
	/** @hidden */
	async function _getEntityFromString(client, string) {
		const phone = __1.utils.parsePhone(string);
		if (phone) try {
			const result = await client.invoke(new tl_1.Api.contacts.GetContacts({ hash: big_integer_1.default.zero }));
			if (!(result instanceof tl_1.Api.contacts.ContactsNotModified)) {
				for (const user of result.users) if (user instanceof tl_1.Api.User && user.phone === phone) return user;
			}
		} catch (e) {
			if (e.errorMessage === "BOT_METHOD_INVALID") throw new Error("Cannot get entity by phone number as a bot (try using integer IDs, not strings)");
			throw e;
		}
		const id = __1.utils.parseID(string);
		if (id != void 0) return getInputEntity(client, id);
		else if (["me", "this"].includes(string.toLowerCase())) return client.getMe();
		else {
			const { username, isInvite } = __1.utils.parseUsername(string);
			if (isInvite) {
				const invite = await client.invoke(new tl_1.Api.messages.CheckChatInvite({ hash: username }));
				if (invite instanceof tl_1.Api.ChatInvite) throw new Error("Cannot get entity from a channel (or group) that you are not part of. Join the group and retry");
				else if (invite instanceof tl_1.Api.ChatInviteAlready) return invite.chat;
			} else if (username) try {
				const result = await client.invoke(new tl_1.Api.contacts.ResolveUsername({ username }));
				const pid = __1.utils.getPeerId(result.peer, false);
				if (result.peer instanceof tl_1.Api.PeerUser) {
					for (const x of result.users) if ((0, Helpers_1.returnBigInt)(x.id).equals((0, Helpers_1.returnBigInt)(pid))) return x;
				} else for (const x of result.chats) if ((0, Helpers_1.returnBigInt)(x.id).equals((0, Helpers_1.returnBigInt)(pid))) return x;
			} catch (e) {
				if (e.errorMessage === "USERNAME_NOT_OCCUPIED") throw new Error(`No user has "${username}" as username`);
				throw e;
			}
		}
		throw new Error(`Cannot find any entity corresponding to "${string}"`);
	}
	/** @hidden */
	async function getPeerId(client, peer, addMark = true) {
		if (typeof peer == "string") {
			if ((0, Utils_1.parseID)(peer)) return __1.utils.getPeerId(peer, addMark);
			else peer = await client.getInputEntity(peer);
		}
		if (typeof peer == "number" || typeof peer == "bigint" || big_integer_1.default.isInstance(peer)) return __1.utils.getPeerId(peer, addMark);
		if (peer.SUBCLASS_OF_ID == 47470215 || peer.SUBCLASS_OF_ID == 3374092470) peer = await client.getInputEntity(peer);
		if (peer instanceof tl_1.Api.InputPeerSelf) peer = await client.getMe(true);
		return __1.utils.getPeerId(peer, addMark);
	}
	/** @hidden */
	async function _getPeer(client, peer) {
		if (!peer) return;
		const [i, cls] = __1.utils.resolveId((0, Helpers_1.returnBigInt)(await client.getPeerId(peer)));
		return new cls({
			userId: i,
			channelId: i,
			chatId: i
		});
	}
	/** @hidden */
	async function _getInputDialog(client, dialog) {
		try {
			if (dialog.SUBCLASS_OF_ID == 2719782805) {
				dialog.peer = await client.getInputEntity(dialog.peer);
				return dialog;
			} else if (dialog.SUBCLASS_OF_ID == 3374092470) return new tl_1.Api.InputDialogPeer({ peer: dialog });
		} catch (e) {}
		return new tl_1.Api.InputDialogPeer({ peer: dialog });
	}
	/** @hidden */
	async function _getInputNotify(client, notify) {
		try {
			if (notify.SUBCLASS_OF_ID == 1486362133) {
				if (notify instanceof tl_1.Api.InputNotifyPeer) notify.peer = await client.getInputEntity(notify.peer);
				return notify;
			}
		} catch (e) {}
		return new tl_1.Api.InputNotifyPeer({ peer: await client.getInputEntity(notify) });
	}
	/** @hidden */
	function _selfId(client) {
		return client._selfInputPeer ? client._selfInputPeer.userId : void 0;
	}
}));
//#endregion
//#region node_modules/telegram/tl/custom/button.js
var require_button = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Button = void 0;
	var api_1 = require_api();
	var __1 = require_telegram();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var Button = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(button, resize, singleUse, selective) {
			this.button = button;
			this.resize = resize;
			this.singleUse = singleUse;
			this.selective = selective;
		}
		static _isInline(button) {
			return button instanceof api_1.Api.KeyboardButtonCallback || button instanceof api_1.Api.KeyboardButtonSwitchInline || button instanceof api_1.Api.KeyboardButtonUrl || button instanceof api_1.Api.KeyboardButtonUrlAuth || button instanceof api_1.Api.InputKeyboardButtonUrlAuth;
		}
		static inline(text, data) {
			if (!data) data = Buffer.from(text, "utf-8");
			if (data.length > 64) throw new Error("Too many bytes for the data");
			return new api_1.Api.KeyboardButtonCallback({
				text,
				data
			});
		}
		static switchInline(text, query = "", samePeer = false) {
			return new api_1.Api.KeyboardButtonSwitchInline({
				text,
				query,
				samePeer
			});
		}
		static url(text, url) {
			return new api_1.Api.KeyboardButtonUrl({
				text,
				url: url || text
			});
		}
		static auth(text, url, bot, writeAccess, fwdText) {
			return new api_1.Api.InputKeyboardButtonUrlAuth({
				text,
				url: url || text,
				bot: __1.utils.getInputUser(bot || new api_1.Api.InputUserSelf()),
				requestWriteAccess: writeAccess,
				fwdText
			});
		}
		static text(text, resize, singleUse, selective) {
			return new this(new api_1.Api.KeyboardButton({ text }), resize, singleUse, selective);
		}
		static requestLocation(text, resize, singleUse, selective) {
			return new this(new api_1.Api.KeyboardButtonRequestGeoLocation({ text }), resize, singleUse, selective);
		}
		static requestPhone(text, resize, singleUse, selective) {
			return new this(new api_1.Api.KeyboardButtonRequestPhone({ text }), resize, singleUse, selective);
		}
		static requestPoll(text, resize, singleUse, selective) {
			return new this(new api_1.Api.KeyboardButtonRequestPoll({ text }), resize, singleUse, selective);
		}
		static clear() {
			return new api_1.Api.ReplyKeyboardHide({});
		}
		static forceReply() {
			return new api_1.Api.ReplyKeyboardForceReply({});
		}
	};
	exports.Button = Button;
}));
//#endregion
//#region node_modules/telegram/Password.js
var require_Password = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.computeCheck = computeCheck;
	exports.computeDigest = computeDigest;
	var tl_1 = require_tl();
	var Helpers_1 = require_Helpers();
	var big_integer_1 = __importDefault(require_BigInteger());
	var CryptoFile_1 = __importDefault(require_CryptoFile());
	var SIZE_FOR_HASH = 256;
	/**
	*
	*
	* @param prime{BigInteger}
	* @param g{BigInteger}
	*/
	/**
	*
	* @param primeBytes{Buffer}
	* @param g{number}
	*/
	function checkPrimeAndGood(primeBytes, g) {
		if (Buffer.from([
			199,
			28,
			174,
			185,
			198,
			177,
			201,
			4,
			142,
			108,
			82,
			47,
			112,
			241,
			63,
			115,
			152,
			13,
			64,
			35,
			142,
			62,
			33,
			193,
			73,
			52,
			208,
			55,
			86,
			61,
			147,
			15,
			72,
			25,
			138,
			10,
			167,
			193,
			64,
			88,
			34,
			148,
			147,
			210,
			37,
			48,
			244,
			219,
			250,
			51,
			111,
			110,
			10,
			201,
			37,
			19,
			149,
			67,
			174,
			212,
			76,
			206,
			124,
			55,
			32,
			253,
			81,
			246,
			148,
			88,
			112,
			90,
			198,
			140,
			212,
			254,
			107,
			107,
			19,
			171,
			220,
			151,
			70,
			81,
			41,
			105,
			50,
			132,
			84,
			241,
			143,
			175,
			140,
			89,
			95,
			100,
			36,
			119,
			254,
			150,
			187,
			42,
			148,
			29,
			91,
			205,
			29,
			74,
			200,
			204,
			73,
			136,
			7,
			8,
			250,
			155,
			55,
			142,
			60,
			79,
			58,
			144,
			96,
			190,
			230,
			124,
			249,
			164,
			164,
			166,
			149,
			129,
			16,
			81,
			144,
			126,
			22,
			39,
			83,
			181,
			107,
			15,
			107,
			65,
			13,
			186,
			116,
			216,
			168,
			75,
			42,
			20,
			179,
			20,
			78,
			14,
			241,
			40,
			71,
			84,
			253,
			23,
			237,
			149,
			13,
			89,
			101,
			180,
			185,
			221,
			70,
			88,
			45,
			177,
			23,
			141,
			22,
			156,
			107,
			196,
			101,
			176,
			214,
			255,
			156,
			163,
			146,
			143,
			239,
			91,
			154,
			228,
			228,
			24,
			252,
			21,
			232,
			62,
			190,
			160,
			248,
			127,
			169,
			255,
			94,
			237,
			112,
			5,
			13,
			237,
			40,
			73,
			244,
			123,
			249,
			89,
			217,
			86,
			133,
			12,
			233,
			41,
			133,
			31,
			13,
			129,
			21,
			246,
			53,
			177,
			5,
			238,
			46,
			78,
			21,
			208,
			75,
			36,
			84,
			191,
			111,
			79,
			173,
			240,
			52,
			177,
			4,
			3,
			17,
			156,
			216,
			227,
			185,
			47,
			204,
			91
		]).equals(primeBytes)) {
			if ([
				3,
				4,
				5,
				7
			].includes(g)) return;
		}
		throw new Error("Changing passwords unsupported");
	}
	/**
	*
	* @param number{BigInteger}
	* @param p{BigInteger}
	* @returns {boolean}
	*/
	function isGoodLarge(number, p) {
		return number.greater((0, big_integer_1.default)(0)) && p.subtract(number).greater((0, big_integer_1.default)(0));
	}
	/**
	*
	* @param number {Buffer}
	* @returns {Buffer}
	*/
	function numBytesForHash(number) {
		return Buffer.concat([Buffer.alloc(SIZE_FOR_HASH - number.length), number]);
	}
	/**
	*
	* @param g {bigInt}
	* @returns {Buffer}
	*/
	function bigNumForHash(g) {
		return (0, Helpers_1.readBufferFromBigInt)(g, SIZE_FOR_HASH, false);
	}
	/**
	*
	* @param modexp {BigInteger}
	* @param prime {BigInteger}
	* @returns {Boolean}
	*/
	function isGoodModExpFirst(modexp, prime) {
		const diff = prime.subtract(modexp);
		const minDiffBitsCount = 1984;
		return !(diff.lesser((0, big_integer_1.default)(0)) || diff.bitLength().toJSNumber() < minDiffBitsCount || modexp.bitLength().toJSNumber() < minDiffBitsCount || Math.floor((modexp.bitLength().toJSNumber() + 7) / 8) > 256);
	}
	function xor(a, b) {
		const length = Math.min(a.length, b.length);
		for (let i = 0; i < length; i++) a[i] = a[i] ^ b[i];
		return a;
	}
	/**
	*
	* @param password{Buffer}
	* @param salt{Buffer}
	* @param iterations{number}
	* @returns {*}
	*/
	function pbkdf2sha512(password, salt, iterations) {
		return CryptoFile_1.default.pbkdf2Sync(password, salt, iterations, 64, "sha512");
	}
	/**
	*
	* @param algo {constructors.PasswordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow}
	* @param password
	* @returns {Buffer|*}
	*/
	async function computeHash(algo, password) {
		const hash1 = await (0, Helpers_1.sha256)(Buffer.concat([
			algo.salt1,
			Buffer.from(password, "utf-8"),
			algo.salt1
		]));
		const hash3 = await pbkdf2sha512(await (0, Helpers_1.sha256)(Buffer.concat([
			algo.salt2,
			hash1,
			algo.salt2
		])), algo.salt1, 1e5);
		return (0, Helpers_1.sha256)(Buffer.concat([
			algo.salt2,
			hash3,
			algo.salt2
		]));
	}
	/**
	*
	* @param algo {constructors.PasswordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow}
	* @param password
	*/
	async function computeDigest(algo, password) {
		try {
			checkPrimeAndGood(algo.p, algo.g);
		} catch (e) {
			throw new Error("bad p/g in password");
		}
		return bigNumForHash((0, Helpers_1.modExp)((0, big_integer_1.default)(algo.g), (0, Helpers_1.readBigIntFromBuffer)(await computeHash(algo, password), false), (0, Helpers_1.readBigIntFromBuffer)(algo.p, false)));
	}
	/**
	*
	* @param request {constructors.account.Password}
	* @param password {string}
	*/
	async function computeCheck(request, password) {
		const algo = request.currentAlgo;
		if (!(algo instanceof tl_1.Api.PasswordKdfAlgoSHA256SHA256PBKDF2HMACSHA512iter100000SHA256ModPow)) throw new Error(`Unsupported password algorithm ${algo === null || algo === void 0 ? void 0 : algo.className}`);
		const srp_B = request.srp_B;
		const srpId = request.srpId;
		if (!srp_B || !srpId) throw new Error(`Undefined srp_b  ${request}`);
		const pwHash = await computeHash(algo, password);
		const p = (0, Helpers_1.readBigIntFromBuffer)(algo.p, false);
		const g = algo.g;
		const B = (0, Helpers_1.readBigIntFromBuffer)(srp_B, false);
		try {
			checkPrimeAndGood(algo.p, g);
		} catch (e) {
			throw new Error("bad /g in password");
		}
		if (!isGoodLarge(B, p)) throw new Error("bad b in check");
		const x = (0, Helpers_1.readBigIntFromBuffer)(pwHash, false);
		const pForHash = numBytesForHash(algo.p);
		const gForHash = bigNumForHash((0, big_integer_1.default)(g));
		const bForHash = numBytesForHash(srp_B);
		const gX = (0, Helpers_1.modExp)((0, big_integer_1.default)(g), x, p);
		const k = (0, Helpers_1.readBigIntFromBuffer)(await (0, Helpers_1.sha256)(Buffer.concat([pForHash, gForHash])), false);
		const kgX = (0, Helpers_1.bigIntMod)(k.multiply(gX), p);
		const generateAndCheckRandom = async () => {
			const randomSize = 256;
			while (true) {
				const random = (0, Helpers_1.generateRandomBytes)(randomSize);
				const a = (0, Helpers_1.readBigIntFromBuffer)(random, false);
				const A = (0, Helpers_1.modExp)((0, big_integer_1.default)(g), a, p);
				if (isGoodModExpFirst(A, p)) {
					const aForHash = bigNumForHash(A);
					const u = (0, Helpers_1.readBigIntFromBuffer)(await (0, Helpers_1.sha256)(Buffer.concat([aForHash, bForHash])), false);
					if (u.greater((0, big_integer_1.default)(0))) return {
						a,
						aForHash,
						u
					};
				}
			}
		};
		const { a, aForHash, u } = await generateAndCheckRandom();
		const gB = (0, Helpers_1.bigIntMod)(B.subtract(kgX), p);
		if (!isGoodModExpFirst(gB, p)) throw new Error("bad gB");
		const ux = u.multiply(x);
		const aUx = a.add(ux);
		const S = (0, Helpers_1.modExp)(gB, aUx, p);
		const [K, pSha, gSha, salt1Sha, salt2Sha] = await Promise.all([
			(0, Helpers_1.sha256)(bigNumForHash(S)),
			(0, Helpers_1.sha256)(pForHash),
			(0, Helpers_1.sha256)(gForHash),
			(0, Helpers_1.sha256)(algo.salt1),
			(0, Helpers_1.sha256)(algo.salt2)
		]);
		const M1 = await (0, Helpers_1.sha256)(Buffer.concat([
			xor(pSha, gSha),
			salt1Sha,
			salt2Sha,
			aForHash,
			bForHash,
			K
		]));
		return new tl_1.Api.InputCheckPasswordSRP({
			srpId,
			A: Buffer.from(aForHash),
			M1
		});
	}
}));
//#endregion
//#region node_modules/telegram/tl/custom/messageButton.js
var require_messageButton = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MessageButton = void 0;
	var api_1 = require_api();
	var button_1 = require_button();
	var Helpers_1 = require_Helpers();
	var Password_1 = require_Password();
	var inspect_1 = require_inspect();
	var MessageButton = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, original, chat, bot, msgId) {
			this.button = original;
			this._bot = bot;
			this._chat = chat;
			this._msgId = msgId;
			this._client = client;
		}
		get client() {
			return this._client;
		}
		get text() {
			return !(this.button instanceof button_1.Button) ? this.button.text : "";
		}
		get data() {
			if (this.button instanceof api_1.Api.KeyboardButtonCallback) return this.button.data;
		}
		get inlineQuery() {
			if (this.button instanceof api_1.Api.KeyboardButtonSwitchInline) return this.button.query;
		}
		get url() {
			if (this.button instanceof api_1.Api.KeyboardButtonUrl) return this.button.url;
		}
		/**
		* Emulates the behaviour of clicking this button.
		
		If it's a normal `KeyboardButton` with text, a message will be
		sent, and the sent `Message <Message>` returned.
		
		If it's an inline `KeyboardButtonCallback` with text and data,
		it will be "clicked" and the `BotCallbackAnswer` returned.
		
		If it's an inline `KeyboardButtonSwitchInline` button, the
		`StartBot` will be invoked and the resulting updates
		returned.
		
		If it's a `KeyboardButtonUrl`, the URL of the button will
		be returned.
		
		If it's a `KeyboardButtonRequestPhone`, you must indicate that you
		want to ``sharePhone=True`` in order to share it. Sharing it is not a
		default because it is a privacy concern and could happen accidentally.
		
		You may also use ``sharePhone=phone`` to share a specific number, in
		which case either `str` or `InputMediaContact` should be used.
		
		If it's a `KeyboardButtonRequestGeoLocation`, you must pass a
		tuple in ``shareGeo=[longitude, latitude]``. Note that Telegram seems
		to have some heuristics to determine impossible locations, so changing
		this value a lot quickly may not work as expected. You may also pass a
		`InputGeoPoint` if you find the order confusing.
		*/
		async click({ sharePhone = false, shareGeo = [0, 0], password }) {
			if (this.button instanceof api_1.Api.KeyboardButton) return this._client.sendMessage(this._chat, {
				message: this.button.text,
				parseMode: void 0
			});
			else if (this.button instanceof api_1.Api.KeyboardButtonCallback) {
				let encryptedPassword;
				if (password != void 0) {
					const pwd = await this.client.invoke(new api_1.Api.account.GetPassword());
					encryptedPassword = await (0, Password_1.computeCheck)(pwd, password);
				}
				const request = new api_1.Api.messages.GetBotCallbackAnswer({
					peer: this._chat,
					msgId: this._msgId,
					data: this.button.data,
					password: encryptedPassword
				});
				try {
					return await this._client.invoke(request);
				} catch (e) {
					if (e.errorMessage == "BOT_RESPONSE_TIMEOUT") return null;
					throw e;
				}
			} else if (this.button instanceof api_1.Api.KeyboardButtonSwitchInline) return this._client.invoke(new api_1.Api.messages.StartBot({
				bot: this._bot,
				peer: this._chat,
				startParam: this.button.query
			}));
			else if (this.button instanceof api_1.Api.KeyboardButtonUrl) return this.button.url;
			else if (this.button instanceof api_1.Api.KeyboardButtonGame) {
				const request = new api_1.Api.messages.GetBotCallbackAnswer({
					peer: this._chat,
					msgId: this._msgId,
					game: true
				});
				try {
					return await this._client.invoke(request);
				} catch (e) {
					if (e.errorMessage == "BOT_RESPONSE_TIMEOUT") return null;
					throw e;
				}
			} else if (this.button instanceof api_1.Api.KeyboardButtonRequestPhone) {
				if (!sharePhone) throw new Error("cannot click on phone buttons unless sharePhone=true");
				if (sharePhone == true || typeof sharePhone == "string") {
					const me = await this._client.getMe();
					sharePhone = new api_1.Api.InputMediaContact({
						phoneNumber: (sharePhone == true ? me.phone : sharePhone) || "",
						firstName: me.firstName || "",
						lastName: me.lastName || "",
						vcard: ""
					});
				}
				throw new Error("Not supported for now");
			} else if (this.button instanceof api_1.Api.InputWebFileGeoPointLocation) {
				if (!shareGeo) throw new Error("cannot click on geo buttons unless shareGeo=[longitude, latitude]");
				throw new Error("Not supported for now");
			}
		}
	};
	exports.MessageButton = MessageButton;
}));
//#endregion
//#region node_modules/telegram/tl/custom/message.js
var require_message = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.CustomMessage = void 0;
	var senderGetter_1 = require_senderGetter();
	var api_1 = require_api();
	var chatGetter_1 = require_chatGetter();
	var utils = __importStar(require_Utils());
	var forward_1 = require_forward();
	var file_1 = require_file();
	var Helpers_1 = require_Helpers();
	var users_1 = require_users();
	var Logger_1 = require_Logger();
	var messageButton_1 = require_messageButton();
	var inspect_1 = require_inspect();
	/**
	* This custom class aggregates both {@link Api.Message} and {@link Api.MessageService} to ease accessing their members.<br/>
	* <br/>
	* Remember that this class implements {@link ChatGetter} and {@link SenderGetter}<br/>
	* which means you have access to all their sender and chat properties and methods.
	*/
	var CustomMessage = class extends senderGetter_1.SenderGetter {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		init({ id, peerId = void 0, date = void 0, out = void 0, mentioned = void 0, mediaUnread = void 0, silent = void 0, post = void 0, fromId = void 0, replyTo = void 0, message = void 0, fwdFrom = void 0, viaBotId = void 0, media = void 0, replyMarkup = void 0, entities = void 0, views = void 0, editDate = void 0, postAuthor = void 0, groupedId = void 0, fromScheduled = void 0, legacy = void 0, editHide = void 0, pinned = void 0, restrictionReason = void 0, forwards = void 0, replies = void 0, action = void 0, reactions = void 0, noforwards = void 0, ttlPeriod = void 0, _entities = /* @__PURE__ */ new Map() }) {
			if (!id) throw new Error("id is a required attribute for Message");
			let senderId = void 0;
			if (fromId) senderId = utils.getPeerId(fromId);
			else if (peerId) {
				if (post || !out && peerId instanceof api_1.Api.PeerUser) senderId = utils.getPeerId(peerId);
			}
			this._entities = _entities;
			this.out = out;
			this.mentioned = mentioned;
			this.mediaUnread = mediaUnread;
			this.silent = silent;
			this.post = post;
			this.post = post;
			this.fromScheduled = fromScheduled;
			this.legacy = legacy;
			this.editHide = editHide;
			this.ttlPeriod = ttlPeriod;
			this.id = id;
			this.fromId = fromId;
			this.peerId = peerId;
			this.fwdFrom = fwdFrom;
			this.viaBotId = viaBotId;
			this.replyTo = replyTo;
			this.date = date;
			this.message = message;
			this.media = media instanceof api_1.Api.MessageMediaEmpty ? media : void 0;
			this.replyMarkup = replyMarkup;
			this.entities = entities;
			this.views = views;
			this.forwards = forwards;
			this.replies = replies;
			this.editDate = editDate;
			this.pinned = pinned;
			this.postAuthor = postAuthor;
			this.groupedId = groupedId;
			this.restrictionReason = restrictionReason;
			this.action = action;
			this.noforwards = noforwards;
			this.reactions = reactions;
			this._client = void 0;
			this._text = void 0;
			this._file = void 0;
			this._replyMessage = void 0;
			this._buttons = void 0;
			this._buttonsFlat = void 0;
			this._buttonsCount = 0;
			this._viaBot = void 0;
			this._viaInputBot = void 0;
			this._actionEntities = void 0;
			chatGetter_1.ChatGetter.initChatClass(this, {
				chatPeer: peerId,
				broadcast: post
			});
			senderGetter_1.SenderGetter.initSenderClass(this, { senderId: senderId ? (0, Helpers_1.returnBigInt)(senderId) : void 0 });
			this._forward = void 0;
		}
		constructor(args) {
			super();
			this.init(args);
		}
		_finishInit(client, entities, inputChat) {
			this._client = client;
			const cache = client._entityCache;
			if (this.senderId) [this._sender, this._inputSender] = utils._getEntityPair(this.senderId.toString(), entities, cache);
			if (this.chatId) [this._chat, this._inputChat] = utils._getEntityPair(this.chatId.toString(), entities, cache);
			if (inputChat) this._inputChat = inputChat;
			if (this.viaBotId) [this._viaBot, this._viaInputBot] = utils._getEntityPair(this.viaBotId.toString(), entities, cache);
			if (this.fwdFrom) this._forward = new forward_1.Forward(this._client, this.fwdFrom, entities);
			if (this.action) {
				if (this.action instanceof api_1.Api.MessageActionChatAddUser || this.action instanceof api_1.Api.MessageActionChatCreate) this._actionEntities = this.action.users.map((i) => entities.get(i.toString()));
				else if (this.action instanceof api_1.Api.MessageActionChatDeleteUser) this._actionEntities = [entities.get(this.action.userId.toString())];
				else if (this.action instanceof api_1.Api.MessageActionChatJoinedByLink) this._actionEntities = [entities.get(utils.getPeerId(new api_1.Api.PeerChannel({ channelId: this.action.inviterId })))];
				else if (this.action instanceof api_1.Api.MessageActionChannelMigrateFrom) this._actionEntities = [entities.get(utils.getPeerId(new api_1.Api.PeerChat({ chatId: this.action.chatId })))];
			}
		}
		get client() {
			return this._client;
		}
		get text() {
			if (this._text === void 0 && this._client) {
				if (!this._client.parseMode) this._text = this.message;
				else this._text = this._client.parseMode.unparse(this.message || "", this.entities || []);
			}
			return this._text || "";
		}
		set text(value) {
			this._text = value;
			if (this._client && this._client.parseMode) [this.message, this.entities] = this._client.parseMode.parse(value);
			else {
				this.message = value;
				this.entities = [];
			}
		}
		get rawText() {
			return this.message || "";
		}
		/**
		* @param {string} value
		*/
		set rawText(value) {
			this.message = value;
			this.entities = [];
			this._text = "";
		}
		get isReply() {
			return !!this.replyTo;
		}
		get forward() {
			return this._forward;
		}
		async _refetchSender() {
			await this._reloadMessage();
		}
		/**
		* Re-fetches this message to reload the sender and chat entities,
		* along with their input versions.
		* @private
		*/
		async _reloadMessage() {
			if (!this._client) return;
			let msg = void 0;
			try {
				const chat = this.isChannel ? await this.getInputChat() : void 0;
				let temp = await this._client.getMessages(chat, { ids: this.id });
				if (temp) msg = temp[0];
			} catch (e) {
				this._client._log.error("Got error while trying to finish init message with id " + this.id);
				if (this._client._errorHandler) await this._client._errorHandler(e);
				if (this._client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
			}
			if (msg == void 0) return;
			this._sender = msg._sender;
			this._inputSender = msg._inputSender;
			this._chat = msg._chat;
			this._inputChat = msg._inputChat;
			this._viaBot = msg._viaBot;
			this._viaInputBot = msg._viaInputBot;
			this._forward = msg._forward;
			this._actionEntities = msg._actionEntities;
		}
		/**
		* Returns a list of lists of `MessageButton <MessageButton>`, if any.
		* Otherwise, it returns `undefined`.
		*/
		get buttons() {
			if (!this._buttons && this.replyMarkup) {
				if (!this.inputChat) return;
				try {
					const bot = this._neededMarkupBot();
					this._setButtons(this.inputChat, bot);
				} catch (e) {
					return;
				}
			}
			return this._buttons;
		}
		/**
		* Returns `buttons` when that property fails (this is rarely needed).
		*/
		async getButtons() {
			if (!this.buttons && this.replyMarkup) {
				const chat = await this.getInputChat();
				if (!chat) return;
				let bot;
				try {
					bot = this._neededMarkupBot();
				} catch (e) {
					await this._reloadMessage();
					bot = this._neededMarkupBot();
				}
				this._setButtons(chat, bot);
			}
			return this._buttons;
		}
		get buttonCount() {
			if (!this._buttonsCount) {
				if (this.replyMarkup instanceof api_1.Api.ReplyInlineMarkup || this.replyMarkup instanceof api_1.Api.ReplyKeyboardMarkup) this._buttonsCount = this.replyMarkup.rows.map((r) => r.buttons.length).reduce(function(a, b) {
					return a + b;
				}, 0);
				else this._buttonsCount = 0;
			}
			return this._buttonsCount;
		}
		get file() {
			if (!this._file) {
				const media = this.photo || this.document;
				if (media) this._file = new file_1.File(media);
			}
			return this._file;
		}
		get photo() {
			if (this.media instanceof api_1.Api.MessageMediaPhoto) {
				if (this.media.photo instanceof api_1.Api.Photo) return this.media.photo;
			} else if (this.action instanceof api_1.Api.MessageActionChatEditPhoto) return this.action.photo;
			else return this.webPreview && this.webPreview.photo instanceof api_1.Api.Photo ? this.webPreview.photo : void 0;
		}
		get document() {
			if (this.media instanceof api_1.Api.MessageMediaDocument) {
				if (this.media.document instanceof api_1.Api.Document) return this.media.document;
			} else {
				const web = this.webPreview;
				return web && web.document instanceof api_1.Api.Document ? web.document : void 0;
			}
		}
		get webPreview() {
			if (this.media instanceof api_1.Api.MessageMediaWebPage) {
				if (this.media.webpage instanceof api_1.Api.WebPage) return this.media.webpage;
			}
		}
		get audio() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeAudio, (attr) => !attr.voice);
		}
		get voice() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeAudio, (attr) => !!attr.voice);
		}
		get video() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeVideo);
		}
		get videoNote() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeVideo, (attr) => !!attr.roundMessage);
		}
		get gif() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeAnimated);
		}
		get sticker() {
			return this._documentByAttribute(api_1.Api.DocumentAttributeSticker);
		}
		get contact() {
			if (this.media instanceof api_1.Api.MessageMediaContact) return this.media;
		}
		get game() {
			if (this.media instanceof api_1.Api.MessageMediaGame) return this.media.game;
		}
		get geo() {
			if (this.media instanceof api_1.Api.MessageMediaGeo || this.media instanceof api_1.Api.MessageMediaGeoLive || this.media instanceof api_1.Api.MessageMediaVenue) return this.media.geo;
		}
		get invoice() {
			if (this.media instanceof api_1.Api.MessageMediaInvoice) return this.media;
		}
		get poll() {
			if (this.media instanceof api_1.Api.MessageMediaPoll) return this.media;
		}
		get venue() {
			if (this.media instanceof api_1.Api.MessageMediaVenue) return this.media;
		}
		get dice() {
			if (this.media instanceof api_1.Api.MessageMediaDice) return this.media;
		}
		get actionEntities() {
			return this._actionEntities;
		}
		get viaBot() {
			return this._viaBot;
		}
		get viaInputBot() {
			return this._viaInputBot;
		}
		get replyToMsgId() {
			var _a;
			return (_a = this.replyTo) === null || _a === void 0 ? void 0 : _a.replyToMsgId;
		}
		get toId() {
			if (this._client && !this.out && this.isPrivate) return new api_1.Api.PeerUser({ userId: (0, users_1._selfId)(this._client) });
			return this.peerId;
		}
		getEntitiesText(cls) {
			let ent = this.entities;
			if (!ent || ent.length == 0) return;
			if (cls) ent = ent.filter((v) => v instanceof cls);
			const texts = utils.getInnerText(this.message || "", ent);
			const zip = (rows) => rows[0].map((_, c) => rows.map((row) => row[c]));
			return zip([ent, texts]);
		}
		async getReplyMessage() {
			if (!this._replyMessage && this._client) {
				if (!this.replyTo) return void 0;
				this._replyMessage = (await this._client.getMessages(this.isChannel ? await this.getInputChat() : void 0, { ids: new api_1.Api.InputMessageReplyTo({ id: this.id }) }))[0];
				if (!this._replyMessage) this._replyMessage = (await this._client.getMessages(this.isChannel ? this._inputChat : void 0, { ids: this.replyToMsgId }))[0];
			}
			return this._replyMessage;
		}
		async respond(params) {
			if (this._client) return this._client.sendMessage(await this.getInputChat(), params);
		}
		async reply(params) {
			if (this._client) {
				params.replyTo = this.id;
				return this._client.sendMessage(await this.getInputChat(), params);
			}
		}
		async forwardTo(entity) {
			if (this._client) {
				entity = await this._client.getInputEntity(entity);
				const params = {
					messages: [this.id],
					fromPeer: await this.getInputChat()
				};
				return this._client.forwardMessages(entity, params);
			}
		}
		async edit(params) {
			const param = params;
			if (this.fwdFrom || !this._client) return void 0;
			if (param.linkPreview == void 0) param.linkPreview = !!this.webPreview;
			if (param.buttons == void 0) param.buttons = this.replyMarkup;
			param.message = this.id;
			return this._client.editMessage(await this.getInputChat(), param);
		}
		async delete({ revoke } = { revoke: false }) {
			if (this._client) return this._client.deleteMessages(await this.getInputChat(), [this.id], { revoke });
		}
		async pin(params) {
			if (this._client) {
				const entity = await this.getInputChat();
				if (entity === void 0) throw Error("Failed to pin message due to cannot get input chat.");
				return this._client.pinMessage(entity, this.id, params);
			}
		}
		async unpin(params) {
			if (this._client) {
				const entity = await this.getInputChat();
				if (entity === void 0) throw Error("Failed to unpin message due to cannot get input chat.");
				return this._client.unpinMessage(entity, this.id, params);
			}
		}
		async downloadMedia(params) {
			if (this._client) return this._client.downloadMedia(this, params || {});
		}
		async markAsRead() {
			if (this._client) {
				const entity = await this.getInputChat();
				if (entity === void 0) throw Error(`Failed to mark message id ${this.id} as read due to cannot get input chat.`);
				return this._client.markAsRead(entity, this.id);
			}
		}
		async click({ i, j, text, filter, data, sharePhone, shareGeo, password }) {
			if (!this.client) return;
			if (data) {
				const chat = await this.getInputChat();
				if (!chat) return;
				const button = new api_1.Api.KeyboardButtonCallback({
					text: "",
					data
				});
				return await new messageButton_1.MessageButton(this.client, button, chat, void 0, this.id).click({
					sharePhone,
					shareGeo,
					password
				});
			}
			if (this.poll) {
				function findPoll(answers) {
					if (i != void 0) {
						if (Array.isArray(i)) {
							const corrects = [];
							for (let x = 0; x < i.length; x++) corrects.push(answers[x].option);
							return corrects;
						}
						return [answers[i].option];
					}
					if (text != void 0) {
						if (typeof text == "function") {
							for (const answer of answers) if (text(answer.text)) return [answer.option];
						} else for (const answer of answers) if (answer.text.text == text) return [answer.option];
						return;
					}
					if (filter != void 0) {
						for (const answer of answers) if (filter(answer)) return [answer.option];
						return;
					}
				}
				const options = findPoll(this.poll.poll.answers) || [];
				return await this.client.invoke(new api_1.Api.messages.SendVote({
					peer: this.inputChat,
					msgId: this.id,
					options
				}));
			}
			if (!await this.getButtons()) return;
			function findButton(self) {
				if (!self._buttonsFlat || !self._buttons) return;
				if (Array.isArray(i)) i = i[0];
				if (text != void 0) {
					if (typeof text == "function") {
						for (const button of self._buttonsFlat) if (text(button.text)) return button;
					} else for (const button of self._buttonsFlat) if (button.text == text) return button;
					return;
				}
				if (filter != void 0) {
					for (const button of self._buttonsFlat) if (filter(button)) return button;
					return;
				}
				if (i == void 0) i = 0;
				if (j == void 0) return self._buttonsFlat[i];
				else return self._buttons[i][j];
			}
			const button = findButton(this);
			if (button) return await button.click({
				sharePhone,
				shareGeo,
				password
			});
		}
		/**
		* Helper methods to set the buttons given the input sender and chat.
		*/
		_setButtons(chat, bot) {
			if (this.client && (this.replyMarkup instanceof api_1.Api.ReplyInlineMarkup || this.replyMarkup instanceof api_1.Api.ReplyKeyboardMarkup)) {
				this._buttons = [];
				this._buttonsFlat = [];
				for (const row of this.replyMarkup.rows) {
					const tmp = [];
					for (const button of row.buttons) {
						const btn = new messageButton_1.MessageButton(this.client, button, chat, bot, this.id);
						tmp.push(btn);
						this._buttonsFlat.push(btn);
					}
					this._buttons.push(tmp);
				}
			}
		}
		/**
		*Returns the input peer of the bot that's needed for the reply markup.
		
		This is necessary for `KeyboardButtonSwitchInline` since we need
		to know what bot we want to start. Raises ``Error`` if the bot
		cannot be found but is needed. Returns `None` if it's not needed.
		*/
		_neededMarkupBot() {
			if (!this.client || this.replyMarkup == void 0) return;
			if (!(this.replyMarkup instanceof api_1.Api.ReplyInlineMarkup || this.replyMarkup instanceof api_1.Api.ReplyKeyboardMarkup)) return;
			for (const row of this.replyMarkup.rows) for (const button of row.buttons) if (button instanceof api_1.Api.KeyboardButtonSwitchInline) {
				if (button.samePeer || !this.viaBotId) {
					const bot = this._inputSender;
					if (!bot) throw new Error("No input sender");
					return bot;
				} else {
					const ent = this.client._entityCache.get(this.viaBotId);
					if (!ent) throw new Error("No input sender");
					return ent;
				}
			}
		}
		_documentByAttribute(kind, condition) {
			const doc = this.document;
			if (doc) {
				for (const attr of doc.attributes) if (attr instanceof kind) {
					if (condition == void 0 || typeof condition == "function" && condition(attr)) return doc;
					return;
				}
			}
		}
	};
	exports.CustomMessage = CustomMessage;
}));
//#endregion
//#region node_modules/telegram/tl/patched/index.js
var require_patched = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.patchAll = patchAll;
	var api_1 = require_api();
	var message_1 = require_message();
	function getGetter(obj, prop) {
		while (obj) {
			let getter = Object.getOwnPropertyDescriptor(obj, prop);
			if (getter && getter.get) return getter.get;
			obj = Object.getPrototypeOf(obj);
		}
	}
	function getSetter(obj, prop) {
		while (obj) {
			let getter = Object.getOwnPropertyDescriptor(obj, prop);
			if (getter && getter.set) return getter.set;
			obj = Object.getPrototypeOf(obj);
		}
	}
	var getInstanceMethods = (obj) => {
		let keys = {
			methods: /* @__PURE__ */ new Set(),
			setters: /* @__PURE__ */ new Set(),
			getters: /* @__PURE__ */ new Set()
		};
		let topObject = obj;
		const mapAllMethods = (property) => {
			const getter = getGetter(topObject, property);
			const setter = getSetter(topObject, property);
			if (getter) keys["getters"].add(property);
			else if (setter) keys["setters"].add(property);
			else if (!(property == "constructor")) keys["methods"].add(property);
		};
		do {
			Object.getOwnPropertyNames(obj).map(mapAllMethods);
			obj = Object.getPrototypeOf(obj);
		} while (obj && Object.getPrototypeOf(obj));
		return keys;
	};
	function patchClass(clazz) {
		const { getters, setters, methods } = getInstanceMethods(message_1.CustomMessage.prototype);
		for (const getter of getters) Object.defineProperty(clazz.prototype, getter, { get: getGetter(message_1.CustomMessage.prototype, getter) });
		for (const setter of setters) Object.defineProperty(clazz.prototype, setter, { set: getSetter(message_1.CustomMessage.prototype, setter) });
		for (const method of methods) clazz.prototype[method] = message_1.CustomMessage.prototype[method];
	}
	function patchAll() {
		patchClass(api_1.Api.Message);
		patchClass(api_1.Api.MessageService);
		patchClass(api_1.Api.MessageEmpty);
	}
}));
//#endregion
//#region node_modules/telegram/tl/index.js
var require_tl = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.serializeDate = exports.serializeBytes = exports.Api = void 0;
	var api_1 = require_api();
	Object.defineProperty(exports, "Api", {
		enumerable: true,
		get: function() {
			return api_1.Api;
		}
	});
	(0, require_patched().patchAll)();
	var generationHelpers_1 = require_generationHelpers();
	Object.defineProperty(exports, "serializeBytes", {
		enumerable: true,
		get: function() {
			return generationHelpers_1.serializeBytes;
		}
	});
	Object.defineProperty(exports, "serializeDate", {
		enumerable: true,
		get: function() {
			return generationHelpers_1.serializeDate;
		}
	});
}));
//#endregion
//#region node_modules/telegram/extensions/BinaryWriter.js
var require_BinaryWriter = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BinaryWriter = void 0;
	var BinaryWriter = class {
		constructor(stream) {
			this._buffers = [stream];
		}
		write(buffer) {
			this._buffers.push(buffer);
		}
		getValue() {
			return Buffer.concat(this._buffers);
		}
	};
	exports.BinaryWriter = BinaryWriter;
}));
//#endregion
//#region node_modules/ts-custom-error/dist/custom-error.mjs
var custom_error_exports = /* @__PURE__ */ __exportAll({
	CustomError: () => CustomError,
	customErrorFactory: () => customErrorFactory
});
function fixProto(target, prototype) {
	var setPrototypeOf = Object.setPrototypeOf;
	setPrototypeOf ? setPrototypeOf(target, prototype) : target.__proto__ = prototype;
}
function fixStack(target, fn) {
	if (fn === void 0) fn = target.constructor;
	var captureStackTrace = Error.captureStackTrace;
	captureStackTrace && captureStackTrace(target, fn);
}
function customErrorFactory(fn, parent) {
	if (parent === void 0) parent = Error;
	function CustomError() {
		var args = [];
		for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
		if (!(this instanceof CustomError)) return new (CustomError.bind.apply(CustomError, __spreadArray([void 0], args, false)))();
		parent.apply(this, args);
		Object.defineProperty(this, "name", {
			value: fn.name || parent.name,
			enumerable: false,
			configurable: true
		});
		fn.apply(this, args);
		fixStack(this, CustomError);
	}
	return Object.defineProperties(CustomError, { prototype: { value: Object.create(parent.prototype, { constructor: {
		value: CustomError,
		writable: true,
		configurable: true
	} }) } });
}
var __extends, CustomError, __spreadArray;
var init_custom_error = __esmMin((() => {
	__extends = function() {
		var _extendStatics = function extendStatics(d, b) {
			_extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
				d.__proto__ = b;
			} || function(d, b) {
				for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
			};
			return _extendStatics(d, b);
		};
		return function(d, b) {
			if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
			_extendStatics(d, b);
			function __() {
				this.constructor = d;
			}
			d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
		};
	}();
	CustomError = function(_super) {
		__extends(CustomError, _super);
		function CustomError(message, options) {
			var _newTarget = this.constructor;
			var _this = _super.call(this, message, options) || this;
			Object.defineProperty(_this, "name", {
				value: _newTarget.name,
				enumerable: false,
				configurable: true
			});
			fixProto(_this, _newTarget.prototype);
			fixStack(_this);
			return _this;
		}
		return CustomError;
	}(Error);
	__spreadArray = function(to, from, pack) {
		if (pack || arguments.length === 2) {
			for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
				if (!ar) ar = Array.prototype.slice.call(from, 0, i);
				ar[i] = from[i];
			}
		}
		return to.concat(ar || Array.prototype.slice.call(from));
	};
}));
//#endregion
//#region node_modules/telegram/errors/RPCBaseErrors.js
var require_RPCBaseErrors = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TimedOutError = exports.ServerError = exports.FloodError = exports.AuthKeyError = exports.NotFoundError = exports.ForbiddenError = exports.UnauthorizedError = exports.BadRequestError = exports.InvalidDCError = exports.RPCError = void 0;
	var ts_custom_error_1 = (init_custom_error(), __toCommonJS(custom_error_exports));
	var RPCError = class RPCError extends ts_custom_error_1.CustomError {
		constructor(message, request, code) {
			super("{0}: {1}{2}".replace("{0}", (code === null || code === void 0 ? void 0 : code.toString()) || "").replace("{1}", message || "").replace("{2}", RPCError._fmtRequest(request)));
			this.code = code;
			this.errorMessage = message;
		}
		static _fmtRequest(request) {
			if (request) return ` (caused by ${request.className})`;
			else return "";
		}
	};
	exports.RPCError = RPCError;
	/**
	* The request must be repeated, but directed to a different data center.
	*/
	var InvalidDCError = class extends RPCError {
		constructor(message, request, code) {
			super(message, request, code);
			this.code = code || 303;
			this.errorMessage = message || "ERROR_SEE_OTHER";
		}
	};
	exports.InvalidDCError = InvalidDCError;
	/**
	* The query contains errors. In the event that a request was created
	* using a form and contains user generated data, the user should be
	* notified that the data must be corrected before the query is repeated.
	*/
	var BadRequestError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 400;
			this.errorMessage = "BAD_REQUEST";
		}
	};
	exports.BadRequestError = BadRequestError;
	/**
	* There was an unauthorized attempt to use functionality available only
	* to authorized users.
	*/
	var UnauthorizedError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 401;
			this.errorMessage = "UNAUTHORIZED";
		}
	};
	exports.UnauthorizedError = UnauthorizedError;
	/**
	* Privacy violation. For example, an attempt to write a message to
	* someone who has blacklisted the current user.
	*/
	var ForbiddenError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 403;
			this.errorMessage = "FORBIDDEN";
		}
	};
	exports.ForbiddenError = ForbiddenError;
	/**
	* An attempt to invoke a non-existent object, such as a method.
	*/
	var NotFoundError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 404;
			this.errorMessage = "NOT_FOUND";
		}
	};
	exports.NotFoundError = NotFoundError;
	/**
	* Errors related to invalid authorization key, like
	* AUTH_KEY_DUPLICATED which can cause the connection to fail.
	*/
	var AuthKeyError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 406;
			this.errorMessage = "AUTH_KEY";
		}
	};
	exports.AuthKeyError = AuthKeyError;
	/**
	* The maximum allowed number of attempts to invoke the given method
	* with the given input parameters has been exceeded. For example, in an
	* attempt to request a large number of text messages (SMS) for the same
	* phone number.
	*/
	var FloodError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 420;
			this.errorMessage = "FLOOD";
		}
	};
	exports.FloodError = FloodError;
	/**
	* An internal server error occurred while a request was being processed
	* for example, there was a disruption while accessing a database or file
	* storage
	*/
	var ServerError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 500;
			this.errorMessage = "INTERNAL";
		}
	};
	exports.ServerError = ServerError;
	/**
	* Clicking the inline buttons of bots that never (or take to long to)
	* call ``answerCallbackQuery`` will result in this "special" RPCError.
	*/
	var TimedOutError = class extends RPCError {
		constructor() {
			super(...arguments);
			this.code = 503;
			this.errorMessage = "Timeout";
		}
	};
	exports.TimedOutError = TimedOutError;
}));
//#endregion
//#region node_modules/telegram/errors/RPCErrorList.js
var require_RPCErrorList = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.rpcErrorRe = exports.MsgWaitError = exports.EmailUnconfirmedError = exports.NetworkMigrateError = exports.FileMigrateError = exports.FloodTestPhoneWaitError = exports.FloodWaitError = exports.SlowModeWaitError = exports.PhoneMigrateError = exports.UserMigrateError = void 0;
	var RPCBaseErrors_1 = require_RPCBaseErrors();
	var UserMigrateError = class extends RPCBaseErrors_1.InvalidDCError {
		constructor(args) {
			const newDc = Number(args.capture || 0);
			super(`The user whose identity is being used to execute queries is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `The user whose identity is being used to execute queries is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.newDc = newDc;
		}
	};
	exports.UserMigrateError = UserMigrateError;
	var PhoneMigrateError = class extends RPCBaseErrors_1.InvalidDCError {
		constructor(args) {
			const newDc = Number(args.capture || 0);
			super(`The phone number a user is trying to use for authorization is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `The phone number a user is trying to use for authorization is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.newDc = newDc;
		}
	};
	exports.PhoneMigrateError = PhoneMigrateError;
	var SlowModeWaitError = class extends RPCBaseErrors_1.FloodError {
		constructor(args) {
			const seconds = Number(args.capture || 0);
			super(`A wait of ${seconds} seconds is required before sending another message in this chat` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `A wait of ${seconds} seconds is required before sending another message in this chat` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.seconds = seconds;
		}
	};
	exports.SlowModeWaitError = SlowModeWaitError;
	var FloodWaitError = class extends RPCBaseErrors_1.FloodError {
		constructor(args) {
			const seconds = Number(args.capture || 0);
			super(`A wait of ${seconds} seconds is required` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `A wait of ${seconds} seconds is required` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.seconds = seconds;
		}
	};
	exports.FloodWaitError = FloodWaitError;
	var FloodTestPhoneWaitError = class extends RPCBaseErrors_1.FloodError {
		constructor(args) {
			const seconds = Number(args.capture || 0);
			super(`A wait of ${seconds} seconds is required in the test servers` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `A wait of ${seconds} seconds is required in the test servers` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.seconds = seconds;
		}
	};
	exports.FloodTestPhoneWaitError = FloodTestPhoneWaitError;
	var FileMigrateError = class extends RPCBaseErrors_1.InvalidDCError {
		constructor(args) {
			const newDc = Number(args.capture || 0);
			super(`The file to be accessed is currently stored in DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `The file to be accessed is currently stored in DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.newDc = newDc;
		}
	};
	exports.FileMigrateError = FileMigrateError;
	var NetworkMigrateError = class extends RPCBaseErrors_1.InvalidDCError {
		constructor(args) {
			const newDc = Number(args.capture || 0);
			super(`The source IP address is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request), args.request);
			this.message = `The source IP address is associated with DC ${newDc}` + RPCBaseErrors_1.RPCError._fmtRequest(args.request);
			this.newDc = newDc;
		}
	};
	exports.NetworkMigrateError = NetworkMigrateError;
	var EmailUnconfirmedError = class extends RPCBaseErrors_1.BadRequestError {
		constructor(args) {
			const codeLength = Number(args.capture || 0);
			super(`Email unconfirmed, the length of the code must be ${codeLength}${RPCBaseErrors_1.RPCError._fmtRequest(args.request)}`, args.request, 400);
			this.message = `Email unconfirmed, the length of the code must be ${codeLength}${RPCBaseErrors_1.RPCError._fmtRequest(args.request)}`;
			this.codeLength = codeLength;
		}
	};
	exports.EmailUnconfirmedError = EmailUnconfirmedError;
	var MsgWaitError = class extends RPCBaseErrors_1.FloodError {
		constructor(args) {
			super(`Message failed to be sent.${RPCBaseErrors_1.RPCError._fmtRequest(args.request)}`, args.request);
			this.message = `Message failed to be sent.${RPCBaseErrors_1.RPCError._fmtRequest(args.request)}`;
		}
	};
	exports.MsgWaitError = MsgWaitError;
	exports.rpcErrorRe = /* @__PURE__ */ new Map([
		[/FILE_MIGRATE_(\d+)/, FileMigrateError],
		[/FLOOD_TEST_PHONE_WAIT_(\d+)/, FloodTestPhoneWaitError],
		[/FLOOD_WAIT_(\d+)/, FloodWaitError],
		[/FLOOD_PREMIUM_WAIT_(\d+)/, FloodWaitError],
		[/MSG_WAIT_(.*)/, MsgWaitError],
		[/PHONE_MIGRATE_(\d+)/, PhoneMigrateError],
		[/SLOWMODE_WAIT_(\d+)/, SlowModeWaitError],
		[/USER_MIGRATE_(\d+)/, UserMigrateError],
		[/NETWORK_MIGRATE_(\d+)/, NetworkMigrateError],
		[/EMAIL_UNCONFIRMED_(\d+)/, EmailUnconfirmedError]
	]);
}));
//#endregion
//#region node_modules/telegram/errors/Common.js
var require_Common = /* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* Errors not related to the Telegram API itself
	*/
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BadMessageError = exports.CdnFileTamperedError = exports.SecurityError = exports.InvalidBufferError = exports.InvalidChecksumError = exports.TypeNotFoundError = exports.ReadCancelledError = void 0;
	/**
	* Occurs when a read operation was cancelled.
	*/
	var ReadCancelledError = class extends Error {
		constructor() {
			super("The read operation was cancelled.");
		}
	};
	exports.ReadCancelledError = ReadCancelledError;
	/**
	* Occurs when a type is not found, for example,
	* when trying to read a TLObject with an invalid constructor code.
	*/
	var TypeNotFoundError = class extends Error {
		constructor(invalidConstructorId, remaining) {
			super(`Could not find a matching Constructor ID for the TLObject that was supposed to be
        read with ID ${invalidConstructorId}. Most likely, a TLObject was trying to be read when
         it should not be read. Remaining bytes: ${remaining.length}`);
			if (typeof alert !== "undefined") alert(`Missing MTProto Entity: Please, make sure to add TL definition for ID ${invalidConstructorId}`);
			this.invalidConstructorId = invalidConstructorId;
			this.remaining = remaining;
		}
	};
	exports.TypeNotFoundError = TypeNotFoundError;
	/**
	* Occurs when using the TCP full mode and the checksum of a received
	* packet doesn't match the expected checksum.
	*/
	var InvalidChecksumError = class extends Error {
		constructor(checksum, validChecksum) {
			super(`Invalid checksum (${checksum} when ${validChecksum} was expected). This packet should be skipped.`);
			this.checksum = checksum;
			this.validChecksum = validChecksum;
		}
	};
	exports.InvalidChecksumError = InvalidChecksumError;
	/**
	* Occurs when the buffer is invalid, and may contain an HTTP error code.
	* For instance, 404 means "forgotten/broken authorization key", while
	*/
	var InvalidBufferError = class extends Error {
		constructor(payload) {
			let code = void 0;
			if (payload.length === 4) {
				code = -payload.readInt32LE(0);
				super(`Invalid response buffer (HTTP code ${code})`);
			} else super(`Invalid response buffer (too short ${payload})`);
			this.code = code;
			this.payload = payload;
		}
	};
	exports.InvalidBufferError = InvalidBufferError;
	/**
	* Generic security error, mostly used when generating a new AuthKey.
	*/
	var SecurityError = class extends Error {
		constructor(...args) {
			if (!args.length) args = ["A security check failed."];
			super(...args);
		}
	};
	exports.SecurityError = SecurityError;
	/**
	* Occurs when there's a hash mismatch between the decrypted CDN file
	* and its expected hash.
	*/
	var CdnFileTamperedError = class extends SecurityError {
		constructor() {
			super("The CDN file has been altered and its download cancelled.");
		}
	};
	exports.CdnFileTamperedError = CdnFileTamperedError;
	/**
	* Occurs when handling a badMessageNotification
	*/
	var BadMessageError = class BadMessageError extends Error {
		constructor(request, code) {
			let errorMessage = BadMessageError.ErrorMessages[code] || `Unknown error code (this should not happen): ${code}.`;
			errorMessage += `  Caused by ${request.className}`;
			super(errorMessage);
			this.errorMessage = errorMessage;
			this.code = code;
		}
	};
	exports.BadMessageError = BadMessageError;
	BadMessageError.ErrorMessages = {
		16: "msg_id too low (most likely, client time is wrong it would be worthwhile to synchronize it using msg_id notifications and re-send the original message with the “correct” msg_id or wrap it in a container with a new msg_id if the original message had waited too long on the client to be transmitted).",
		17: "msg_id too high (similar to the previous case, the client time has to be synchronized, and the message re-sent with the correct msg_id).",
		18: "Incorrect two lower order msg_id bits (the server expects client message msg_id to be divisible by 4).",
		19: "Container msg_id is the same as msg_id of a previously received message (this must never happen).",
		20: "Message too old, and it cannot be verified whether the server has received a message with this msg_id or not.",
		32: "msg_seqno too low (the server has already received a message with a lower msg_id but with either a higher or an equal and odd seqno).",
		33: "msg_seqno too high (similarly, there is a message with a higher msg_id but with either a lower or an equal and odd seqno).",
		34: "An even msg_seqno expected (irrelevant message), but odd received.",
		35: "Odd msg_seqno expected (relevant message), but even received.",
		48: "Incorrect server salt (in this case, the bad_server_salt response is received with the correct salt, and the message is to be re-sent with it).",
		64: "Invalid container."
	};
}));
//#endregion
//#region node_modules/telegram/errors/index.js
var require_errors = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$4) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$4, p)) __createBinding(exports$4, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.RPCMessageToError = RPCMessageToError;
	var RPCBaseErrors_1 = require_RPCBaseErrors();
	var RPCErrorList_1 = require_RPCErrorList();
	function RPCMessageToError(rpcError, request) {
		for (const [msgRegex, Cls] of RPCErrorList_1.rpcErrorRe) {
			const m = rpcError.errorMessage.match(msgRegex);
			if (m) return new Cls({
				request,
				capture: m.length === 2 ? parseInt(m[1]) : null
			});
		}
		return new RPCBaseErrors_1.RPCError(rpcError.errorMessage, request, rpcError.errorCode);
	}
	__exportStar(require_Common(), exports);
	__exportStar(require_RPCBaseErrors(), exports);
	__exportStar(require_RPCErrorList(), exports);
}));
//#endregion
//#region node_modules/telegram/tl/core/TLMessage.js
var require_TLMessage = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TLMessage = void 0;
	var TLMessage = class {
		constructor(msgId, seqNo, obj) {
			this.msgId = msgId;
			this.seqNo = seqNo;
			this.obj = obj;
			this.classType = "constructor";
		}
	};
	exports.TLMessage = TLMessage;
	TLMessage.SIZE_OVERHEAD = 12;
	TLMessage.classType = "constructor";
}));
//#endregion
//#region node_modules/telegram/tl/core/RPCResult.js
var require_RPCResult = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.RPCResult = void 0;
	var api_1 = require_api();
	var _1 = require_core();
	var RPCResult = class RPCResult {
		constructor(reqMsgId, body, error) {
			this.CONSTRUCTOR_ID = 4082920705;
			this.reqMsgId = reqMsgId;
			this.body = body;
			this.error = error;
			this.classType = "constructor";
		}
		static async fromReader(reader) {
			const msgId = reader.readLong();
			const innerCode = reader.readInt(false);
			if (innerCode === api_1.Api.RpcError.CONSTRUCTOR_ID) return new RPCResult(msgId, void 0, api_1.Api.RpcError.fromReader(reader));
			if (innerCode === _1.GZIPPacked.CONSTRUCTOR_ID) return new RPCResult(msgId, (await _1.GZIPPacked.fromReader(reader)).data);
			reader.seek(-4);
			return new RPCResult(msgId, reader.read(), void 0);
		}
	};
	exports.RPCResult = RPCResult;
	RPCResult.CONSTRUCTOR_ID = 4082920705;
	RPCResult.classType = "constructor";
}));
//#endregion
//#region node_modules/telegram/tl/core/MessageContainer.js
var require_MessageContainer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MessageContainer = void 0;
	var TLMessage_1 = require_TLMessage();
	var MessageContainer = class MessageContainer {
		constructor(messages) {
			this.CONSTRUCTOR_ID = 1945237724;
			this.messages = messages;
			this.classType = "constructor";
		}
		static async fromReader(reader) {
			const messages = [];
			const length = reader.readInt();
			for (let x = 0; x < length; x++) {
				const msgId = reader.readLong();
				const seqNo = reader.readInt();
				const length = reader.readInt();
				const before = reader.tellPosition();
				const obj = reader.tgReadObject();
				reader.setPosition(before + length);
				const tlMessage = new TLMessage_1.TLMessage(msgId, seqNo, obj);
				messages.push(tlMessage);
			}
			return new MessageContainer(messages);
		}
	};
	exports.MessageContainer = MessageContainer;
	MessageContainer.CONSTRUCTOR_ID = 1945237724;
	MessageContainer.classType = "constructor";
	MessageContainer.MAXIMUM_SIZE = 1044448;
	MessageContainer.MAXIMUM_LENGTH = 100;
}));
//#endregion
//#region node_modules/telegram/tl/core/GZIPPacked.js
var require_GZIPPacked = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.GZIPPacked = void 0;
	var __1 = require_tl();
	var pako_1 = require_pako();
	var GZIPPacked = class GZIPPacked {
		constructor(data) {
			this.data = data;
			this.CONSTRUCTOR_ID = 812830625;
			this.classType = "constructor";
		}
		static async gzipIfSmaller(contentRelated, data) {
			if (contentRelated && data.length > 512) {
				const gzipped = await new GZIPPacked(data).toBytes();
				if (gzipped.length < data.length) return gzipped;
			}
			return data;
		}
		static gzip(input) {
			return Buffer.from(input);
		}
		static ungzip(input) {
			return Buffer.from((0, pako_1.inflate)(input));
		}
		async toBytes() {
			const g = Buffer.alloc(4);
			g.writeUInt32LE(GZIPPacked.CONSTRUCTOR_ID, 0);
			return Buffer.concat([g, (0, __1.serializeBytes)(await GZIPPacked.gzip(this.data))]);
		}
		static async read(reader) {
			if (reader.readInt(false) !== GZIPPacked.CONSTRUCTOR_ID) throw new Error("not equal");
			return GZIPPacked.gzip(reader.tgReadBytes());
		}
		static async fromReader(reader) {
			const data = reader.tgReadBytes();
			return new GZIPPacked(await GZIPPacked.ungzip(data));
		}
	};
	exports.GZIPPacked = GZIPPacked;
	GZIPPacked.CONSTRUCTOR_ID = 812830625;
	GZIPPacked.classType = "constructor";
}));
//#endregion
//#region node_modules/telegram/tl/core/index.js
var require_core = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.GZIPPacked = exports.MessageContainer = exports.TLMessage = exports.RPCResult = exports.coreObjects = void 0;
	var TLMessage_1 = require_TLMessage();
	Object.defineProperty(exports, "TLMessage", {
		enumerable: true,
		get: function() {
			return TLMessage_1.TLMessage;
		}
	});
	var RPCResult_1 = require_RPCResult();
	Object.defineProperty(exports, "RPCResult", {
		enumerable: true,
		get: function() {
			return RPCResult_1.RPCResult;
		}
	});
	var MessageContainer_1 = require_MessageContainer();
	Object.defineProperty(exports, "MessageContainer", {
		enumerable: true,
		get: function() {
			return MessageContainer_1.MessageContainer;
		}
	});
	var GZIPPacked_1 = require_GZIPPacked();
	Object.defineProperty(exports, "GZIPPacked", {
		enumerable: true,
		get: function() {
			return GZIPPacked_1.GZIPPacked;
		}
	});
	exports.coreObjects = /* @__PURE__ */ new Map([
		[RPCResult_1.RPCResult.CONSTRUCTOR_ID, RPCResult_1.RPCResult],
		[GZIPPacked_1.GZIPPacked.CONSTRUCTOR_ID, GZIPPacked_1.GZIPPacked],
		[MessageContainer_1.MessageContainer.CONSTRUCTOR_ID, MessageContainer_1.MessageContainer]
	]);
}));
//#endregion
//#region node_modules/telegram/tl/AllTLObjects.js
var require_AllTLObjects = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.tlobjects = exports.LAYER = void 0;
	exports.LAYER = 198;
	var _1 = require_tl();
	var tlobjects = {};
	exports.tlobjects = tlobjects;
	for (const tl of Object.values(_1.Api)) if ("CONSTRUCTOR_ID" in tl) tlobjects[tl.CONSTRUCTOR_ID] = tl;
	else for (const sub of Object.values(tl)) tlobjects[sub.CONSTRUCTOR_ID] = sub;
}));
//#endregion
//#region node_modules/telegram/extensions/BinaryReader.js
var require_BinaryReader = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BinaryReader = void 0;
	var errors_1 = require_errors();
	var core_1 = require_core();
	var AllTLObjects_1 = require_AllTLObjects();
	var Helpers_1 = require_Helpers();
	var BinaryReader = class {
		/**
		* Small utility class to read binary data.
		* @param data {Buffer}
		*/
		constructor(data) {
			this.stream = data;
			this._last = void 0;
			this.offset = 0;
		}
		/**
		* Reads a single byte value.
		*/
		readByte() {
			return this.read(1)[0];
		}
		/**
		* Reads an integer (4 bytes or 32 bits) value.
		* @param signed {Boolean}
		*/
		readInt(signed = true) {
			let res;
			if (signed) res = this.stream.readInt32LE(this.offset);
			else res = this.stream.readUInt32LE(this.offset);
			this.offset += 4;
			return res;
		}
		/**
		* Reads a long integer (8 bytes or 64 bits) value.
		* @param signed
		* @returns {BigInteger}
		*/
		readLong(signed = true) {
			return this.readLargeInt(64, signed);
		}
		/**
		* Reads a real floating point (4 bytes) value.
		* @returns {number}
		*/
		readFloat() {
			return this.read(4).readFloatLE(0);
		}
		/**
		* Reads a real floating point (8 bytes) value.
		* @returns {BigInteger}
		*/
		readDouble() {
			return this.read(8).readDoubleLE(0);
		}
		/**
		* Reads a n-bits long integer value.
		* @param bits
		* @param signed {Boolean}
		*/
		readLargeInt(bits, signed = true) {
			const buffer = this.read(Math.floor(bits / 8));
			return (0, Helpers_1.readBigIntFromBuffer)(buffer, true, signed);
		}
		/**
		* Read the given amount of bytes, or -1 to read all remaining.
		* @param length {number}
		* @param checkLength {boolean} whether to check if the length overflows or not.
		*/
		read(length = -1, checkLength = true) {
			if (length === -1) length = this.stream.length - this.offset;
			const result = this.stream.slice(this.offset, this.offset + length);
			this.offset += length;
			if (checkLength && result.length !== length) throw Error(`No more data left to read (need ${length}, got ${result.length}: ${result}); last read ${this._last}`);
			this._last = result;
			return result;
		}
		/**
		* Gets the byte array representing the current buffer as a whole.
		* @returns {Buffer}
		*/
		getBuffer() {
			return this.stream;
		}
		/**
		* Reads a Telegram-encoded byte array, without the need of
		* specifying its length.
		* @returns {Buffer}
		*/
		tgReadBytes() {
			const firstByte = this.readByte();
			let padding;
			let length;
			if (firstByte === 254) {
				length = this.readByte() | this.readByte() << 8 | this.readByte() << 16;
				padding = length % 4;
			} else {
				length = firstByte;
				padding = (length + 1) % 4;
			}
			const data = this.read(length);
			if (padding > 0) {
				padding = 4 - padding;
				this.read(padding);
			}
			return data;
		}
		/**
		* Reads a Telegram-encoded string.
		* @returns {string}
		*/
		tgReadString() {
			return this.tgReadBytes().toString("utf-8");
		}
		/**
		* Reads a Telegram boolean value.
		* @returns {boolean}
		*/
		tgReadBool() {
			const value = this.readInt(false);
			if (value === 2574415285) return true;
			else if (value === 3162085175) return false;
			else throw new Error(`Invalid boolean code ${value.toString(16)}`);
		}
		/**
		* Reads and converts Unix time (used by Telegram)
		* into a Javascript {Date} object.
		* @returns {Date}
		*/
		tgReadDate() {
			const value = this.readInt();
			return /* @__PURE__ */ new Date(value * 1e3);
		}
		/**
		* Reads a Telegram object.
		*/
		tgReadObject() {
			const constructorId = this.readInt(false);
			let clazz = AllTLObjects_1.tlobjects[constructorId];
			if (clazz === void 0) {
				/**
				* The class was undefined, but there's still a
				* chance of it being a manually parsed value like bool!
				*/
				const value = constructorId;
				if (value === 2574415285) return true;
				else if (value === 3162085175) return false;
				else if (value === 481674261) {
					const temp = [];
					const length = this.readInt();
					for (let i = 0; i < length; i++) temp.push(this.tgReadObject());
					return temp;
				}
				clazz = core_1.coreObjects.get(constructorId);
				if (clazz === void 0) {
					this.seek(-4);
					const pos = this.tellPosition();
					const error = new errors_1.TypeNotFoundError(constructorId, this.read());
					this.setPosition(pos);
					throw error;
				}
			}
			return clazz.fromReader(this);
		}
		/**
		* Reads a vector (a list) of Telegram objects.
		* @returns {[Buffer]}
		*/
		tgReadVector() {
			if (this.readInt(false) !== 481674261) throw new Error("Invalid constructor code, vector was expected");
			const count = this.readInt();
			const temp = [];
			for (let i = 0; i < count; i++) temp.push(this.tgReadObject());
			return temp;
		}
		/**
		* Tells the current position on the stream.
		* @returns {number}
		*/
		tellPosition() {
			return this.offset;
		}
		/**
		* Sets the current position on the stream.
		* @param position
		*/
		setPosition(position) {
			this.offset = position;
		}
		/**
		* Seeks the stream position given an offset from the current position.
		* The offset may be negative.
		* @param offset
		*/
		seek(offset) {
			this.offset += offset;
		}
	};
	exports.BinaryReader = BinaryReader;
}));
//#endregion
//#region node_modules/websocket/lib/utils.js
var require_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	var noop = exports.noop = function() {};
	exports.extend = function extend(dest, source) {
		for (var prop in source) dest[prop] = source[prop];
	};
	exports.eventEmitterListenerCount = __require("events").EventEmitter.listenerCount || function(emitter, type) {
		return emitter.listeners(type).length;
	};
	exports.bufferAllocUnsafe = Buffer.allocUnsafe ? Buffer.allocUnsafe : function oldBufferAllocUnsafe(size) {
		return new Buffer(size);
	};
	exports.bufferFromString = Buffer.from ? Buffer.from : function oldBufferFromString(string, encoding) {
		return new Buffer(string, encoding);
	};
	exports.BufferingLogger = function createBufferingLogger(identifier, uniqueID) {
		var logFunction = require_src()(identifier);
		if (logFunction.enabled) {
			var logger = new BufferingLogger(identifier, uniqueID, logFunction);
			var debug = logger.log.bind(logger);
			debug.printOutput = logger.printOutput.bind(logger);
			debug.enabled = logFunction.enabled;
			return debug;
		}
		logFunction.printOutput = noop;
		return logFunction;
	};
	function BufferingLogger(identifier, uniqueID, logFunction) {
		this.logFunction = logFunction;
		this.identifier = identifier;
		this.uniqueID = uniqueID;
		this.buffer = [];
	}
	BufferingLogger.prototype.log = function() {
		this.buffer.push([/* @__PURE__ */ new Date(), Array.prototype.slice.call(arguments)]);
		return this;
	};
	BufferingLogger.prototype.clear = function() {
		this.buffer = [];
		return this;
	};
	BufferingLogger.prototype.printOutput = function(logFunction) {
		if (!logFunction) logFunction = this.logFunction;
		var uniqueID = this.uniqueID;
		this.buffer.forEach(function(entry) {
			var date = entry[0].toLocaleString();
			var args = entry[1].slice();
			var formatString = args[0];
			if (formatString !== void 0 && formatString !== null) {
				formatString = "%s - %s - " + formatString.toString();
				args.splice(0, 1, formatString, date, uniqueID);
				logFunction.apply(global, args);
			}
		});
	};
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketFrame.js
var require_WebSocketFrame = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var bufferUtil = __require("bufferutil");
	var bufferAllocUnsafe = require_utils().bufferAllocUnsafe;
	var DECODE_HEADER = 1;
	var WAITING_FOR_16_BIT_LENGTH = 2;
	var WAITING_FOR_64_BIT_LENGTH = 3;
	var WAITING_FOR_MASK_KEY = 4;
	var WAITING_FOR_PAYLOAD = 5;
	var COMPLETE = 6;
	function WebSocketFrame(maskBytes, frameHeader, config) {
		this.maskBytes = maskBytes;
		this.frameHeader = frameHeader;
		this.config = config;
		this.maxReceivedFrameSize = config.maxReceivedFrameSize;
		this.protocolError = false;
		this.frameTooLarge = false;
		this.invalidCloseFrameLength = false;
		this.parseState = DECODE_HEADER;
		this.closeStatus = -1;
	}
	WebSocketFrame.prototype.addData = function(bufferList) {
		if (this.parseState === DECODE_HEADER) {
			if (bufferList.length >= 2) {
				bufferList.joinInto(this.frameHeader, 0, 0, 2);
				bufferList.advance(2);
				var firstByte = this.frameHeader[0];
				var secondByte = this.frameHeader[1];
				this.fin = Boolean(firstByte & 128);
				this.rsv1 = Boolean(firstByte & 64);
				this.rsv2 = Boolean(firstByte & 32);
				this.rsv3 = Boolean(firstByte & 16);
				this.mask = Boolean(secondByte & 128);
				this.opcode = firstByte & 15;
				this.length = secondByte & 127;
				if (this.opcode >= 8) {
					if (this.length > 125) {
						this.protocolError = true;
						this.dropReason = "Illegal control frame longer than 125 bytes.";
						return true;
					}
					if (!this.fin) {
						this.protocolError = true;
						this.dropReason = "Control frames must not be fragmented.";
						return true;
					}
				}
				if (this.length === 126) this.parseState = WAITING_FOR_16_BIT_LENGTH;
				else if (this.length === 127) this.parseState = WAITING_FOR_64_BIT_LENGTH;
				else this.parseState = WAITING_FOR_MASK_KEY;
			}
		}
		if (this.parseState === WAITING_FOR_16_BIT_LENGTH) {
			if (bufferList.length >= 2) {
				bufferList.joinInto(this.frameHeader, 2, 0, 2);
				bufferList.advance(2);
				this.length = this.frameHeader.readUInt16BE(2);
				this.parseState = WAITING_FOR_MASK_KEY;
			}
		} else if (this.parseState === WAITING_FOR_64_BIT_LENGTH) {
			if (bufferList.length >= 8) {
				bufferList.joinInto(this.frameHeader, 2, 0, 8);
				bufferList.advance(8);
				var lengthPair = [this.frameHeader.readUInt32BE(2), this.frameHeader.readUInt32BE(6)];
				if (lengthPair[0] !== 0) {
					this.protocolError = true;
					this.dropReason = "Unsupported 64-bit length frame received";
					return true;
				}
				this.length = lengthPair[1];
				this.parseState = WAITING_FOR_MASK_KEY;
			}
		}
		if (this.parseState === WAITING_FOR_MASK_KEY) {
			if (this.mask) {
				if (bufferList.length >= 4) {
					bufferList.joinInto(this.maskBytes, 0, 0, 4);
					bufferList.advance(4);
					this.parseState = WAITING_FOR_PAYLOAD;
				}
			} else this.parseState = WAITING_FOR_PAYLOAD;
		}
		if (this.parseState === WAITING_FOR_PAYLOAD) {
			if (this.length > this.maxReceivedFrameSize) {
				this.frameTooLarge = true;
				this.dropReason = "Frame size of " + this.length.toString(10) + " bytes exceeds maximum accepted frame size";
				return true;
			}
			if (this.length === 0) {
				this.binaryPayload = bufferAllocUnsafe(0);
				this.parseState = COMPLETE;
				return true;
			}
			if (bufferList.length >= this.length) {
				this.binaryPayload = bufferList.take(this.length);
				bufferList.advance(this.length);
				if (this.mask) bufferUtil.unmask(this.binaryPayload, this.maskBytes);
				if (this.opcode === 8) {
					if (this.length === 1) {
						this.binaryPayload = bufferAllocUnsafe(0);
						this.invalidCloseFrameLength = true;
					}
					if (this.length >= 2) {
						this.closeStatus = this.binaryPayload.readUInt16BE(0);
						this.binaryPayload = this.binaryPayload.slice(2);
					}
				}
				this.parseState = COMPLETE;
				return true;
			}
		}
		return false;
	};
	WebSocketFrame.prototype.throwAwayPayload = function(bufferList) {
		if (bufferList.length >= this.length) {
			bufferList.advance(this.length);
			this.parseState = COMPLETE;
			return true;
		}
		return false;
	};
	WebSocketFrame.prototype.toBuffer = function(nullMask) {
		var maskKey;
		var headerLength = 2;
		var data;
		var outputPos;
		var firstByte = 0;
		var secondByte = 0;
		if (this.fin) firstByte |= 128;
		if (this.rsv1) firstByte |= 64;
		if (this.rsv2) firstByte |= 32;
		if (this.rsv3) firstByte |= 16;
		if (this.mask) secondByte |= 128;
		firstByte |= this.opcode & 15;
		if (this.opcode === 8) {
			this.length = 2;
			if (this.binaryPayload) this.length += this.binaryPayload.length;
			data = bufferAllocUnsafe(this.length);
			data.writeUInt16BE(this.closeStatus, 0);
			if (this.length > 2) this.binaryPayload.copy(data, 2);
		} else if (this.binaryPayload) {
			data = this.binaryPayload;
			this.length = data.length;
		} else this.length = 0;
		if (this.length <= 125) secondByte |= this.length & 127;
		else if (this.length > 125 && this.length <= 65535) {
			secondByte |= 126;
			headerLength += 2;
		} else if (this.length > 65535) {
			secondByte |= 127;
			headerLength += 8;
		}
		var output = bufferAllocUnsafe(this.length + headerLength + (this.mask ? 4 : 0));
		output[0] = firstByte;
		output[1] = secondByte;
		outputPos = 2;
		if (this.length > 125 && this.length <= 65535) {
			output.writeUInt16BE(this.length, outputPos);
			outputPos += 2;
		} else if (this.length > 65535) {
			output.writeUInt32BE(0, outputPos);
			output.writeUInt32BE(this.length, outputPos + 4);
			outputPos += 8;
		}
		if (this.mask) {
			maskKey = nullMask ? 0 : Math.random() * 4294967295 >>> 0;
			this.maskBytes.writeUInt32BE(maskKey, 0);
			this.maskBytes.copy(output, outputPos);
			outputPos += 4;
			if (data) bufferUtil.mask(data, this.maskBytes, output, outputPos, this.length);
		} else if (data) data.copy(output, outputPos);
		return output;
	};
	WebSocketFrame.prototype.toString = function() {
		return "Opcode: " + this.opcode + ", fin: " + this.fin + ", length: " + this.length + ", hasPayload: " + Boolean(this.binaryPayload) + ", masked: " + this.mask;
	};
	module.exports = WebSocketFrame;
}));
//#endregion
//#region node_modules/websocket/vendor/FastBufferList.js
var require_FastBufferList = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Buffer$1 = __require("buffer").Buffer;
	var EventEmitter$6 = __require("events").EventEmitter;
	var bufferAllocUnsafe = require_utils().bufferAllocUnsafe;
	module.exports = BufferList;
	module.exports.BufferList = BufferList;
	function BufferList(opts) {
		if (!(this instanceof BufferList)) return new BufferList(opts);
		EventEmitter$6.call(this);
		var self = this;
		if (typeof opts == "undefined") opts = {};
		self.encoding = opts.encoding;
		var head = {
			next: null,
			buffer: null
		};
		var last = {
			next: null,
			buffer: null
		};
		var length = 0;
		self.__defineGetter__("length", function() {
			return length;
		});
		var offset = 0;
		self.write = function(buf) {
			if (!head.buffer) {
				head.buffer = buf;
				last = head;
			} else {
				last.next = {
					next: null,
					buffer: buf
				};
				last = last.next;
			}
			length += buf.length;
			self.emit("write", buf);
			return true;
		};
		self.end = function(buf) {
			if (Buffer$1.isBuffer(buf)) self.write(buf);
		};
		self.push = function() {
			[].concat.apply([], arguments).forEach(self.write);
			return self;
		};
		self.forEach = function(fn) {
			if (!head.buffer) return bufferAllocUnsafe(0);
			if (head.buffer.length - offset <= 0) return self;
			var b = {
				buffer: head.buffer.slice(offset),
				next: head.next
			};
			while (b && b.buffer) {
				if (fn(b.buffer)) break;
				b = b.next;
			}
			return self;
		};
		self.join = function(start, end) {
			if (!head.buffer) return bufferAllocUnsafe(0);
			if (start == void 0) start = 0;
			if (end == void 0) end = self.length;
			var big = bufferAllocUnsafe(end - start);
			var ix = 0;
			self.forEach(function(buffer) {
				if (start < ix + buffer.length && ix < end) buffer.copy(big, Math.max(0, ix - start), Math.max(0, start - ix), Math.min(buffer.length, end - ix));
				ix += buffer.length;
				if (ix > end) return true;
			});
			return big;
		};
		self.joinInto = function(targetBuffer, targetStart, sourceStart, sourceEnd) {
			if (!head.buffer) return new bufferAllocUnsafe(0);
			if (sourceStart == void 0) sourceStart = 0;
			if (sourceEnd == void 0) sourceEnd = self.length;
			var big = targetBuffer;
			if (big.length - targetStart < sourceEnd - sourceStart) throw new Error("Insufficient space available in target Buffer.");
			var ix = 0;
			self.forEach(function(buffer) {
				if (sourceStart < ix + buffer.length && ix < sourceEnd) buffer.copy(big, Math.max(targetStart, targetStart + ix - sourceStart), Math.max(0, sourceStart - ix), Math.min(buffer.length, sourceEnd - ix));
				ix += buffer.length;
				if (ix > sourceEnd) return true;
			});
			return big;
		};
		self.advance = function(n) {
			offset += n;
			length -= n;
			while (head.buffer && offset >= head.buffer.length) {
				offset -= head.buffer.length;
				head = head.next ? head.next : {
					buffer: null,
					next: null
				};
			}
			if (head.buffer === null) last = {
				next: null,
				buffer: null
			};
			self.emit("advance", n);
			return self;
		};
		self.take = function(n, encoding) {
			if (n == void 0) n = self.length;
			else if (typeof n !== "number") {
				encoding = n;
				n = self.length;
			}
			if (!encoding) encoding = self.encoding;
			if (encoding) {
				var acc = "";
				self.forEach(function(buffer) {
					if (n <= 0) return true;
					acc += buffer.toString(encoding, 0, Math.min(n, buffer.length));
					n -= buffer.length;
				});
				return acc;
			} else return self.join(0, n);
		};
		self.toString = function() {
			return self.take("binary");
		};
	}
	__require("util").inherits(BufferList, EventEmitter$6);
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketConnection.js
var require_WebSocketConnection = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var util$5 = __require("util");
	var utils = require_utils();
	var EventEmitter$5 = __require("events").EventEmitter;
	var WebSocketFrame = require_WebSocketFrame();
	var BufferList = require_FastBufferList();
	var isValidUTF8 = __require("utf-8-validate");
	var bufferAllocUnsafe = utils.bufferAllocUnsafe;
	var bufferFromString = utils.bufferFromString;
	var STATE_OPEN = "open";
	var STATE_PEER_REQUESTED_CLOSE = "peer_requested_close";
	var STATE_ENDING = "ending";
	var STATE_CLOSED = "closed";
	var setImmediateImpl = "setImmediate" in global ? global.setImmediate.bind(global) : process.nextTick.bind(process);
	var idCounter = 0;
	function WebSocketConnection(socket, extensions, protocol, maskOutgoingPackets, config) {
		this._debug = utils.BufferingLogger("websocket:connection", ++idCounter);
		this._debug("constructor");
		if (this._debug.enabled) instrumentSocketForDebugging(this, socket);
		EventEmitter$5.call(this);
		this._pingListenerCount = 0;
		this.on("newListener", function(ev) {
			if (ev === "ping") this._pingListenerCount++;
		}).on("removeListener", function(ev) {
			if (ev === "ping") this._pingListenerCount--;
		});
		this.config = config;
		this.socket = socket;
		this.protocol = protocol;
		this.extensions = extensions;
		this.remoteAddress = socket.remoteAddress;
		this.closeReasonCode = -1;
		this.closeDescription = null;
		this.closeEventEmitted = false;
		this.maskOutgoingPackets = maskOutgoingPackets;
		this.maskBytes = bufferAllocUnsafe(4);
		this.frameHeader = bufferAllocUnsafe(10);
		this.bufferList = new BufferList();
		this.currentFrame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		this.fragmentationSize = 0;
		this.frameQueue = [];
		this.connected = true;
		this.state = STATE_OPEN;
		this.waitingForCloseResponse = false;
		this.receivedEnd = false;
		this.closeTimeout = this.config.closeTimeout;
		this.assembleFragments = this.config.assembleFragments;
		this.maxReceivedMessageSize = this.config.maxReceivedMessageSize;
		this.outputBufferFull = false;
		this.inputPaused = false;
		this.receivedDataHandler = this.processReceivedData.bind(this);
		this._closeTimerHandler = this.handleCloseTimer.bind(this);
		this.socket.setNoDelay(this.config.disableNagleAlgorithm);
		this.socket.setTimeout(0);
		if (this.config.keepalive && !this.config.useNativeKeepalive) {
			if (typeof this.config.keepaliveInterval !== "number") throw new Error("keepaliveInterval must be specified and numeric if keepalive is true.");
			this._keepaliveTimerHandler = this.handleKeepaliveTimer.bind(this);
			this.setKeepaliveTimer();
			if (this.config.dropConnectionOnKeepaliveTimeout) {
				if (typeof this.config.keepaliveGracePeriod !== "number") throw new Error("keepaliveGracePeriod  must be specified and numeric if dropConnectionOnKeepaliveTimeout is true.");
				this._gracePeriodTimerHandler = this.handleGracePeriodTimer.bind(this);
			}
		} else if (this.config.keepalive && this.config.useNativeKeepalive) {
			if (!("setKeepAlive" in this.socket)) throw new Error("Unable to use native keepalive: unsupported by this version of Node.");
			this.socket.setKeepAlive(true, this.config.keepaliveInterval);
		}
		this.socket.removeAllListeners("error");
	}
	WebSocketConnection.CLOSE_REASON_NORMAL = 1e3;
	WebSocketConnection.CLOSE_REASON_GOING_AWAY = 1001;
	WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR = 1002;
	WebSocketConnection.CLOSE_REASON_UNPROCESSABLE_INPUT = 1003;
	WebSocketConnection.CLOSE_REASON_RESERVED = 1004;
	WebSocketConnection.CLOSE_REASON_NOT_PROVIDED = 1005;
	WebSocketConnection.CLOSE_REASON_ABNORMAL = 1006;
	WebSocketConnection.CLOSE_REASON_INVALID_DATA = 1007;
	WebSocketConnection.CLOSE_REASON_POLICY_VIOLATION = 1008;
	WebSocketConnection.CLOSE_REASON_MESSAGE_TOO_BIG = 1009;
	WebSocketConnection.CLOSE_REASON_EXTENSION_REQUIRED = 1010;
	WebSocketConnection.CLOSE_REASON_INTERNAL_SERVER_ERROR = 1011;
	WebSocketConnection.CLOSE_REASON_TLS_HANDSHAKE_FAILED = 1015;
	WebSocketConnection.CLOSE_DESCRIPTIONS = {
		1e3: "Normal connection closure",
		1001: "Remote peer is going away",
		1002: "Protocol error",
		1003: "Unprocessable input",
		1004: "Reserved",
		1005: "Reason not provided",
		1006: "Abnormal closure, no further detail available",
		1007: "Invalid data received",
		1008: "Policy violation",
		1009: "Message too big",
		1010: "Extension requested by client is required",
		1011: "Internal Server Error",
		1015: "TLS Handshake Failed"
	};
	function validateCloseReason(code) {
		if (code < 1e3) return false;
		if (code >= 1e3 && code <= 2999) return [
			1e3,
			1001,
			1002,
			1003,
			1007,
			1008,
			1009,
			1010,
			1011,
			1012,
			1013,
			1014,
			1015
		].indexOf(code) !== -1;
		if (code >= 3e3 && code <= 3999) return true;
		if (code >= 4e3 && code <= 4999) return true;
		if (code >= 5e3) return false;
	}
	util$5.inherits(WebSocketConnection, EventEmitter$5);
	WebSocketConnection.prototype._addSocketEventListeners = function() {
		this.socket.on("error", this.handleSocketError.bind(this));
		this.socket.on("end", this.handleSocketEnd.bind(this));
		this.socket.on("close", this.handleSocketClose.bind(this));
		this.socket.on("drain", this.handleSocketDrain.bind(this));
		this.socket.on("pause", this.handleSocketPause.bind(this));
		this.socket.on("resume", this.handleSocketResume.bind(this));
		this.socket.on("data", this.handleSocketData.bind(this));
	};
	WebSocketConnection.prototype.setKeepaliveTimer = function() {
		this._debug("setKeepaliveTimer");
		if (!this.config.keepalive || this.config.useNativeKeepalive) return;
		this.clearKeepaliveTimer();
		this.clearGracePeriodTimer();
		this._keepaliveTimeoutID = setTimeout(this._keepaliveTimerHandler, this.config.keepaliveInterval);
	};
	WebSocketConnection.prototype.clearKeepaliveTimer = function() {
		if (this._keepaliveTimeoutID) clearTimeout(this._keepaliveTimeoutID);
	};
	WebSocketConnection.prototype.handleKeepaliveTimer = function() {
		this._debug("handleKeepaliveTimer");
		this._keepaliveTimeoutID = null;
		this.ping();
		if (this.config.dropConnectionOnKeepaliveTimeout) this.setGracePeriodTimer();
		else this.setKeepaliveTimer();
	};
	WebSocketConnection.prototype.setGracePeriodTimer = function() {
		this._debug("setGracePeriodTimer");
		this.clearGracePeriodTimer();
		this._gracePeriodTimeoutID = setTimeout(this._gracePeriodTimerHandler, this.config.keepaliveGracePeriod);
	};
	WebSocketConnection.prototype.clearGracePeriodTimer = function() {
		if (this._gracePeriodTimeoutID) clearTimeout(this._gracePeriodTimeoutID);
	};
	WebSocketConnection.prototype.handleGracePeriodTimer = function() {
		this._debug("handleGracePeriodTimer");
		this._gracePeriodTimeoutID = null;
		this.drop(WebSocketConnection.CLOSE_REASON_ABNORMAL, "Peer not responding.", true);
	};
	WebSocketConnection.prototype.handleSocketData = function(data) {
		this._debug("handleSocketData");
		this.setKeepaliveTimer();
		this.bufferList.write(data);
		this.processReceivedData();
	};
	WebSocketConnection.prototype.processReceivedData = function() {
		this._debug("processReceivedData");
		if (!this.connected) return;
		if (this.inputPaused) return;
		var frame = this.currentFrame;
		if (!frame.addData(this.bufferList)) {
			this._debug("-- insufficient data for frame");
			return;
		}
		var self = this;
		if (frame.protocolError) {
			this._debug("-- protocol error");
			process.nextTick(function() {
				self.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, frame.dropReason);
			});
			return;
		} else if (frame.frameTooLarge) {
			this._debug("-- frame too large");
			process.nextTick(function() {
				self.drop(WebSocketConnection.CLOSE_REASON_MESSAGE_TOO_BIG, frame.dropReason);
			});
			return;
		}
		if (frame.rsv1 || frame.rsv2 || frame.rsv3) {
			this._debug("-- illegal rsv flag");
			process.nextTick(function() {
				self.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, "Unsupported usage of rsv bits without negotiated extension.");
			});
			return;
		}
		if (!this.assembleFragments) {
			this._debug("-- emitting frame");
			process.nextTick(function() {
				self.emit("frame", frame);
			});
		}
		process.nextTick(function() {
			self.processFrame(frame);
		});
		this.currentFrame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		if (this.bufferList.length > 0) setImmediateImpl(this.receivedDataHandler);
	};
	WebSocketConnection.prototype.handleSocketError = function(error) {
		this._debug("handleSocketError: %j", error);
		if (this.state === STATE_CLOSED) {
			this._debug("  --- Socket 'error' after 'close'");
			return;
		}
		this.closeReasonCode = WebSocketConnection.CLOSE_REASON_ABNORMAL;
		this.closeDescription = "Socket Error: " + error.syscall + " " + error.code;
		this.connected = false;
		this.state = STATE_CLOSED;
		this.fragmentationSize = 0;
		if (utils.eventEmitterListenerCount(this, "error") > 0) this.emit("error", error);
		this.socket.destroy();
		this._debug.printOutput();
	};
	WebSocketConnection.prototype.handleSocketEnd = function() {
		this._debug("handleSocketEnd: received socket end.  state = %s", this.state);
		this.receivedEnd = true;
		if (this.state === STATE_CLOSED) {
			this._debug("  --- Socket 'end' after 'close'");
			return;
		}
		if (this.state !== STATE_PEER_REQUESTED_CLOSE && this.state !== STATE_ENDING) {
			this._debug("  --- UNEXPECTED socket end.");
			this.socket.end();
		}
	};
	WebSocketConnection.prototype.handleSocketClose = function(hadError) {
		this._debug("handleSocketClose: received socket close");
		this.socketHadError = hadError;
		this.connected = false;
		this.state = STATE_CLOSED;
		if (this.closeReasonCode === -1) {
			this.closeReasonCode = WebSocketConnection.CLOSE_REASON_ABNORMAL;
			this.closeDescription = "Connection dropped by remote peer.";
		}
		this.clearCloseTimer();
		this.clearKeepaliveTimer();
		this.clearGracePeriodTimer();
		if (!this.closeEventEmitted) {
			this.closeEventEmitted = true;
			this._debug("-- Emitting WebSocketConnection close event");
			this.emit("close", this.closeReasonCode, this.closeDescription);
		}
	};
	WebSocketConnection.prototype.handleSocketDrain = function() {
		this._debug("handleSocketDrain: socket drain event");
		this.outputBufferFull = false;
		this.emit("drain");
	};
	WebSocketConnection.prototype.handleSocketPause = function() {
		this._debug("handleSocketPause: socket pause event");
		this.inputPaused = true;
		this.emit("pause");
	};
	WebSocketConnection.prototype.handleSocketResume = function() {
		this._debug("handleSocketResume: socket resume event");
		this.inputPaused = false;
		this.emit("resume");
		this.processReceivedData();
	};
	WebSocketConnection.prototype.pause = function() {
		this._debug("pause: pause requested");
		this.socket.pause();
	};
	WebSocketConnection.prototype.resume = function() {
		this._debug("resume: resume requested");
		this.socket.resume();
	};
	WebSocketConnection.prototype.close = function(reasonCode, description) {
		if (this.connected) {
			this._debug("close: Initating clean WebSocket close sequence.");
			if ("number" !== typeof reasonCode) reasonCode = WebSocketConnection.CLOSE_REASON_NORMAL;
			if (!validateCloseReason(reasonCode)) throw new Error("Close code " + reasonCode + " is not valid.");
			if ("string" !== typeof description) description = WebSocketConnection.CLOSE_DESCRIPTIONS[reasonCode];
			this.closeReasonCode = reasonCode;
			this.closeDescription = description;
			this.setCloseTimer();
			this.sendCloseFrame(this.closeReasonCode, this.closeDescription);
			this.state = STATE_ENDING;
			this.connected = false;
		}
	};
	WebSocketConnection.prototype.drop = function(reasonCode, description, skipCloseFrame) {
		this._debug("drop");
		if (typeof reasonCode !== "number") reasonCode = WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR;
		if (typeof description !== "string") description = WebSocketConnection.CLOSE_DESCRIPTIONS[reasonCode];
		this._debug("Forcefully dropping connection. skipCloseFrame: %s, code: %d, description: %s", skipCloseFrame, reasonCode, description);
		this.closeReasonCode = reasonCode;
		this.closeDescription = description;
		this.frameQueue = [];
		this.fragmentationSize = 0;
		if (!skipCloseFrame) this.sendCloseFrame(reasonCode, description);
		this.connected = false;
		this.state = STATE_CLOSED;
		this.clearCloseTimer();
		this.clearKeepaliveTimer();
		this.clearGracePeriodTimer();
		if (!this.closeEventEmitted) {
			this.closeEventEmitted = true;
			this._debug("Emitting WebSocketConnection close event");
			this.emit("close", this.closeReasonCode, this.closeDescription);
		}
		this._debug("Drop: destroying socket");
		this.socket.destroy();
	};
	WebSocketConnection.prototype.setCloseTimer = function() {
		this._debug("setCloseTimer");
		this.clearCloseTimer();
		this._debug("Setting close timer");
		this.waitingForCloseResponse = true;
		this.closeTimer = setTimeout(this._closeTimerHandler, this.closeTimeout);
	};
	WebSocketConnection.prototype.clearCloseTimer = function() {
		this._debug("clearCloseTimer");
		if (this.closeTimer) {
			this._debug("Clearing close timer");
			clearTimeout(this.closeTimer);
			this.waitingForCloseResponse = false;
			this.closeTimer = null;
		}
	};
	WebSocketConnection.prototype.handleCloseTimer = function() {
		this._debug("handleCloseTimer");
		this.closeTimer = null;
		if (this.waitingForCloseResponse) {
			this._debug("Close response not received from client.  Forcing socket end.");
			this.waitingForCloseResponse = false;
			this.state = STATE_CLOSED;
			this.socket.end();
		}
	};
	WebSocketConnection.prototype.processFrame = function(frame) {
		this._debug("processFrame");
		this._debug(" -- frame: %s", frame);
		if (this.frameQueue.length !== 0 && frame.opcode > 0 && frame.opcode < 8) {
			this.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, "Illegal frame opcode 0x" + frame.opcode.toString(16) + " received in middle of fragmented message.");
			return;
		}
		switch (frame.opcode) {
			case 2:
				this._debug("-- Binary Frame");
				if (this.assembleFragments) {
					if (frame.fin) {
						this._debug("---- Emitting 'message' event");
						this.emit("message", {
							type: "binary",
							binaryData: frame.binaryPayload
						});
					} else {
						this.frameQueue.push(frame);
						this.fragmentationSize = frame.length;
					}
				}
				break;
			case 1:
				this._debug("-- Text Frame");
				if (this.assembleFragments) {
					if (frame.fin) {
						if (!isValidUTF8(frame.binaryPayload)) {
							this.drop(WebSocketConnection.CLOSE_REASON_INVALID_DATA, "Invalid UTF-8 Data Received");
							return;
						}
						this._debug("---- Emitting 'message' event");
						this.emit("message", {
							type: "utf8",
							utf8Data: frame.binaryPayload.toString("utf8")
						});
					} else {
						this.frameQueue.push(frame);
						this.fragmentationSize = frame.length;
					}
				}
				break;
			case 0:
				this._debug("-- Continuation Frame");
				if (this.assembleFragments) {
					if (this.frameQueue.length === 0) {
						this.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, "Unexpected Continuation Frame");
						return;
					}
					this.fragmentationSize += frame.length;
					if (this.fragmentationSize > this.maxReceivedMessageSize) {
						this.drop(WebSocketConnection.CLOSE_REASON_MESSAGE_TOO_BIG, "Maximum message size exceeded.");
						return;
					}
					this.frameQueue.push(frame);
					if (frame.fin) {
						var bytesCopied = 0;
						var binaryPayload = bufferAllocUnsafe(this.fragmentationSize);
						var opcode = this.frameQueue[0].opcode;
						this.frameQueue.forEach(function(currentFrame) {
							currentFrame.binaryPayload.copy(binaryPayload, bytesCopied);
							bytesCopied += currentFrame.binaryPayload.length;
						});
						this.frameQueue = [];
						this.fragmentationSize = 0;
						switch (opcode) {
							case 2:
								this.emit("message", {
									type: "binary",
									binaryData: binaryPayload
								});
								break;
							case 1:
								if (!isValidUTF8(binaryPayload)) {
									this.drop(WebSocketConnection.CLOSE_REASON_INVALID_DATA, "Invalid UTF-8 Data Received");
									return;
								}
								this.emit("message", {
									type: "utf8",
									utf8Data: binaryPayload.toString("utf8")
								});
								break;
							default:
								this.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, "Unexpected first opcode in fragmentation sequence: 0x" + opcode.toString(16));
								return;
						}
					}
				}
				break;
			case 9:
				this._debug("-- Ping Frame");
				if (this._pingListenerCount > 0) {
					var cancelled = false;
					var cancel = function() {
						cancelled = true;
					};
					this.emit("ping", cancel, frame.binaryPayload);
					if (!cancelled) this.pong(frame.binaryPayload);
				} else this.pong(frame.binaryPayload);
				break;
			case 10:
				this._debug("-- Pong Frame");
				this.emit("pong", frame.binaryPayload);
				break;
			case 8:
				this._debug("-- Close Frame");
				if (this.waitingForCloseResponse) {
					this._debug("---- Got close response from peer.  Completing closing handshake.");
					this.clearCloseTimer();
					this.waitingForCloseResponse = false;
					this.state = STATE_CLOSED;
					this.socket.end();
					return;
				}
				this._debug("---- Closing handshake initiated by peer.");
				this.state = STATE_PEER_REQUESTED_CLOSE;
				var respondCloseReasonCode;
				if (frame.invalidCloseFrameLength) {
					this.closeReasonCode = 1005;
					respondCloseReasonCode = WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR;
				} else if (frame.closeStatus === -1 || validateCloseReason(frame.closeStatus)) {
					this.closeReasonCode = frame.closeStatus;
					respondCloseReasonCode = WebSocketConnection.CLOSE_REASON_NORMAL;
				} else {
					this.closeReasonCode = frame.closeStatus;
					respondCloseReasonCode = WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR;
				}
				if (frame.binaryPayload.length > 1) {
					if (!isValidUTF8(frame.binaryPayload)) {
						this.drop(WebSocketConnection.CLOSE_REASON_INVALID_DATA, "Invalid UTF-8 Data Received");
						return;
					}
					this.closeDescription = frame.binaryPayload.toString("utf8");
				} else this.closeDescription = WebSocketConnection.CLOSE_DESCRIPTIONS[this.closeReasonCode];
				this._debug("------ Remote peer %s - code: %d - %s - close frame payload length: %d", this.remoteAddress, this.closeReasonCode, this.closeDescription, frame.length);
				this._debug("------ responding to remote peer's close request.");
				this.sendCloseFrame(respondCloseReasonCode, null);
				this.connected = false;
				break;
			default:
				this._debug("-- Unrecognized Opcode %d", frame.opcode);
				this.drop(WebSocketConnection.CLOSE_REASON_PROTOCOL_ERROR, "Unrecognized Opcode: 0x" + frame.opcode.toString(16));
		}
	};
	WebSocketConnection.prototype.send = function(data, cb) {
		this._debug("send");
		if (Buffer.isBuffer(data)) this.sendBytes(data, cb);
		else if (typeof data["toString"] === "function") this.sendUTF(data, cb);
		else throw new Error("Data provided must either be a Node Buffer or implement toString()");
	};
	WebSocketConnection.prototype.sendUTF = function(data, cb) {
		data = bufferFromString(data.toString(), "utf8");
		this._debug("sendUTF: %d bytes", data.length);
		var frame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		frame.opcode = 1;
		frame.binaryPayload = data;
		this.fragmentAndSend(frame, cb);
	};
	WebSocketConnection.prototype.sendBytes = function(data, cb) {
		this._debug("sendBytes");
		if (!Buffer.isBuffer(data)) throw new Error("You must pass a Node Buffer object to WebSocketConnection.prototype.sendBytes()");
		var frame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		frame.opcode = 2;
		frame.binaryPayload = data;
		this.fragmentAndSend(frame, cb);
	};
	WebSocketConnection.prototype.ping = function(data) {
		this._debug("ping");
		var frame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		frame.opcode = 9;
		frame.fin = true;
		if (data) {
			if (!Buffer.isBuffer(data)) data = bufferFromString(data.toString(), "utf8");
			if (data.length > 125) {
				this._debug("WebSocket: Data for ping is longer than 125 bytes.  Truncating.");
				data = data.slice(0, 124);
			}
			frame.binaryPayload = data;
		}
		this.sendFrame(frame);
	};
	WebSocketConnection.prototype.pong = function(binaryPayload) {
		this._debug("pong");
		var frame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		frame.opcode = 10;
		if (Buffer.isBuffer(binaryPayload) && binaryPayload.length > 125) {
			this._debug("WebSocket: Data for pong is longer than 125 bytes.  Truncating.");
			binaryPayload = binaryPayload.slice(0, 124);
		}
		frame.binaryPayload = binaryPayload;
		frame.fin = true;
		this.sendFrame(frame);
	};
	WebSocketConnection.prototype.fragmentAndSend = function(frame, cb) {
		this._debug("fragmentAndSend");
		if (frame.opcode > 7) throw new Error("You cannot fragment control frames.");
		var threshold = this.config.fragmentationThreshold;
		var length = frame.binaryPayload.length;
		if (!this.config.fragmentOutgoingMessages || frame.binaryPayload && length <= threshold) {
			frame.fin = true;
			this.sendFrame(frame, cb);
			return;
		}
		var numFragments = Math.ceil(length / threshold);
		var sentFragments = 0;
		var sentCallback = function fragmentSentCallback(err) {
			if (err) {
				if (typeof cb === "function") {
					cb(err);
					cb = null;
				}
				return;
			}
			++sentFragments;
			if (sentFragments === numFragments && typeof cb === "function") cb();
		};
		for (var i = 1; i <= numFragments; i++) {
			var currentFrame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
			currentFrame.opcode = i === 1 ? frame.opcode : 0;
			currentFrame.fin = i === numFragments;
			var currentLength = i === numFragments ? length - threshold * (i - 1) : threshold;
			var sliceStart = threshold * (i - 1);
			currentFrame.binaryPayload = frame.binaryPayload.slice(sliceStart, sliceStart + currentLength);
			this.sendFrame(currentFrame, sentCallback);
		}
	};
	WebSocketConnection.prototype.sendCloseFrame = function(reasonCode, description, cb) {
		if (typeof reasonCode !== "number") reasonCode = WebSocketConnection.CLOSE_REASON_NORMAL;
		this._debug("sendCloseFrame state: %s, reasonCode: %d, description: %s", this.state, reasonCode, description);
		if (this.state !== STATE_OPEN && this.state !== STATE_PEER_REQUESTED_CLOSE) return;
		var frame = new WebSocketFrame(this.maskBytes, this.frameHeader, this.config);
		frame.fin = true;
		frame.opcode = 8;
		frame.closeStatus = reasonCode;
		if (typeof description === "string") frame.binaryPayload = bufferFromString(description, "utf8");
		this.sendFrame(frame, cb);
		this.socket.end();
	};
	WebSocketConnection.prototype.sendFrame = function(frame, cb) {
		this._debug("sendFrame");
		frame.mask = this.maskOutgoingPackets;
		var flushed = this.socket.write(frame.toBuffer(), cb);
		this.outputBufferFull = !flushed;
		return flushed;
	};
	module.exports = WebSocketConnection;
	function instrumentSocketForDebugging(connection, socket) {
		if (!connection._debug.enabled) return;
		var originalSocketEmit = socket.emit;
		socket.emit = function(event) {
			connection._debug("||| Socket Event  '%s'", event);
			originalSocketEmit.apply(this, arguments);
		};
		for (var key in socket) {
			if ("function" !== typeof socket[key]) continue;
			if (["emit"].indexOf(key) !== -1) continue;
			(function(key) {
				var original = socket[key];
				if (key === "on") {
					socket[key] = function proxyMethod__EventEmitter__On() {
						connection._debug("||| Socket method called:  %s (%s)", key, arguments[0]);
						return original.apply(this, arguments);
					};
					return;
				}
				socket[key] = function proxyMethod() {
					connection._debug("||| Socket method called:  %s", key);
					return original.apply(this, arguments);
				};
			})(key);
		}
	}
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketRequest.js
var require_WebSocketRequest = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var crypto$2 = __require("crypto");
	var util$4 = __require("util");
	var url$1 = __require("url");
	var EventEmitter$4 = __require("events").EventEmitter;
	var WebSocketConnection = require_WebSocketConnection();
	var headerValueSplitRegExp = /,\s*/;
	var headerParamSplitRegExp = /;\s*/;
	var headerSanitizeRegExp = /[\r\n]/g;
	var xForwardedForSeparatorRegExp = /,\s*/;
	var separators = [
		"(",
		")",
		"<",
		">",
		"@",
		",",
		";",
		":",
		"\\",
		"\"",
		"/",
		"[",
		"]",
		"?",
		"=",
		"{",
		"}",
		" ",
		String.fromCharCode(9)
	];
	var controlChars = [String.fromCharCode(127)];
	for (var i = 0; i < 31; i++) controlChars.push(String.fromCharCode(i));
	var cookieNameValidateRegEx = /([\x00-\x20\x22\x28\x29\x2c\x2f\x3a-\x3f\x40\x5b-\x5e\x7b\x7d\x7f])/;
	var cookieValueValidateRegEx = /[^\x21\x23-\x2b\x2d-\x3a\x3c-\x5b\x5d-\x7e]/;
	var cookieValueDQuoteValidateRegEx = /^"[^"]*"$/;
	var controlCharsAndSemicolonRegEx = /[\x00-\x20\x3b]/g;
	var cookieSeparatorRegEx = /[;,] */;
	var httpStatusDescriptions = {
		100: "Continue",
		101: "Switching Protocols",
		200: "OK",
		201: "Created",
		203: "Non-Authoritative Information",
		204: "No Content",
		205: "Reset Content",
		206: "Partial Content",
		300: "Multiple Choices",
		301: "Moved Permanently",
		302: "Found",
		303: "See Other",
		304: "Not Modified",
		305: "Use Proxy",
		307: "Temporary Redirect",
		400: "Bad Request",
		401: "Unauthorized",
		402: "Payment Required",
		403: "Forbidden",
		404: "Not Found",
		406: "Not Acceptable",
		407: "Proxy Authorization Required",
		408: "Request Timeout",
		409: "Conflict",
		410: "Gone",
		411: "Length Required",
		412: "Precondition Failed",
		413: "Request Entity Too Long",
		414: "Request-URI Too Long",
		415: "Unsupported Media Type",
		416: "Requested Range Not Satisfiable",
		417: "Expectation Failed",
		426: "Upgrade Required",
		500: "Internal Server Error",
		501: "Not Implemented",
		502: "Bad Gateway",
		503: "Service Unavailable",
		504: "Gateway Timeout",
		505: "HTTP Version Not Supported"
	};
	function WebSocketRequest(socket, httpRequest, serverConfig) {
		EventEmitter$4.call(this);
		this.socket = socket;
		this.httpRequest = httpRequest;
		this.resource = httpRequest.url;
		this.remoteAddress = socket.remoteAddress;
		this.remoteAddresses = [this.remoteAddress];
		this.serverConfig = serverConfig;
		this._socketIsClosing = false;
		this._socketCloseHandler = this._handleSocketCloseBeforeAccept.bind(this);
		this.socket.on("end", this._socketCloseHandler);
		this.socket.on("close", this._socketCloseHandler);
		this._resolved = false;
	}
	util$4.inherits(WebSocketRequest, EventEmitter$4);
	WebSocketRequest.prototype.readHandshake = function() {
		var self = this;
		var request = this.httpRequest;
		this.resourceURL = url$1.parse(this.resource, true);
		this.host = request.headers["host"];
		if (!this.host) throw new Error("Client must provide a Host header.");
		this.key = request.headers["sec-websocket-key"];
		if (!this.key) throw new Error("Client must provide a value for Sec-WebSocket-Key.");
		this.webSocketVersion = parseInt(request.headers["sec-websocket-version"], 10);
		if (!this.webSocketVersion || isNaN(this.webSocketVersion)) throw new Error("Client must provide a value for Sec-WebSocket-Version.");
		switch (this.webSocketVersion) {
			case 8:
			case 13: break;
			default:
				var e = /* @__PURE__ */ new Error("Unsupported websocket client version: " + this.webSocketVersion + "Only versions 8 and 13 are supported.");
				e.httpCode = 426;
				e.headers = { "Sec-WebSocket-Version": "13" };
				throw e;
		}
		if (this.webSocketVersion === 13) this.origin = request.headers["origin"];
		else if (this.webSocketVersion === 8) this.origin = request.headers["sec-websocket-origin"];
		var protocolString = request.headers["sec-websocket-protocol"];
		this.protocolFullCaseMap = {};
		this.requestedProtocols = [];
		if (protocolString) protocolString.split(headerValueSplitRegExp).forEach(function(protocol) {
			var lcProtocol = protocol.toLocaleLowerCase();
			self.requestedProtocols.push(lcProtocol);
			self.protocolFullCaseMap[lcProtocol] = protocol;
		});
		if (!this.serverConfig.ignoreXForwardedFor && request.headers["x-forwarded-for"]) {
			var immediatePeerIP = this.remoteAddress;
			this.remoteAddresses = request.headers["x-forwarded-for"].split(xForwardedForSeparatorRegExp);
			this.remoteAddresses.push(immediatePeerIP);
			this.remoteAddress = this.remoteAddresses[0];
		}
		if (this.serverConfig.parseExtensions) {
			var extensionsString = request.headers["sec-websocket-extensions"];
			this.requestedExtensions = this.parseExtensions(extensionsString);
		} else this.requestedExtensions = [];
		if (this.serverConfig.parseCookies) {
			var cookieString = request.headers["cookie"];
			this.cookies = this.parseCookies(cookieString);
		} else this.cookies = [];
	};
	WebSocketRequest.prototype.parseExtensions = function(extensionsString) {
		if (!extensionsString || extensionsString.length === 0) return [];
		var extensions = extensionsString.toLocaleLowerCase().split(headerValueSplitRegExp);
		extensions.forEach(function(extension, index, array) {
			var params = extension.split(headerParamSplitRegExp);
			var extensionName = params[0];
			var extensionParams = params.slice(1);
			extensionParams.forEach(function(rawParam, index, array) {
				var arr = rawParam.split("=");
				var obj = {
					name: arr[0],
					value: arr[1]
				};
				array.splice(index, 1, obj);
			});
			var obj = {
				name: extensionName,
				params: extensionParams
			};
			array.splice(index, 1, obj);
		});
		return extensions;
	};
	WebSocketRequest.prototype.parseCookies = function(str) {
		if (!str || typeof str !== "string") return [];
		var cookies = [];
		str.split(cookieSeparatorRegEx).forEach(function(pair) {
			var eq_idx = pair.indexOf("=");
			if (eq_idx === -1) {
				cookies.push({
					name: pair,
					value: null
				});
				return;
			}
			var key = pair.substr(0, eq_idx).trim();
			var val = pair.substr(++eq_idx, pair.length).trim();
			if ("\"" === val[0]) val = val.slice(1, -1);
			cookies.push({
				name: key,
				value: decodeURIComponent(val)
			});
		});
		return cookies;
	};
	WebSocketRequest.prototype.accept = function(acceptedProtocol, allowedOrigin, cookies) {
		this._verifyResolution();
		var protocolFullCase;
		if (acceptedProtocol) {
			protocolFullCase = this.protocolFullCaseMap[acceptedProtocol.toLocaleLowerCase()];
			if (typeof protocolFullCase === "undefined") protocolFullCase = acceptedProtocol;
		} else protocolFullCase = acceptedProtocol;
		this.protocolFullCaseMap = null;
		var sha1 = crypto$2.createHash("sha1");
		sha1.update(this.key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
		var response = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + sha1.digest("base64") + "\r\n";
		if (protocolFullCase) {
			for (var i = 0; i < protocolFullCase.length; i++) {
				var charCode = protocolFullCase.charCodeAt(i);
				var character = protocolFullCase.charAt(i);
				if (charCode < 33 || charCode > 126 || separators.indexOf(character) !== -1) {
					this.reject(500);
					throw new Error("Illegal character \"" + String.fromCharCode(character) + "\" in subprotocol.");
				}
			}
			if (this.requestedProtocols.indexOf(acceptedProtocol) === -1) {
				this.reject(500);
				throw new Error("Specified protocol was not requested by the client.");
			}
			protocolFullCase = protocolFullCase.replace(headerSanitizeRegExp, "");
			response += "Sec-WebSocket-Protocol: " + protocolFullCase + "\r\n";
		}
		this.requestedProtocols = null;
		if (allowedOrigin) {
			allowedOrigin = allowedOrigin.replace(headerSanitizeRegExp, "");
			if (this.webSocketVersion === 13) response += "Origin: " + allowedOrigin + "\r\n";
			else if (this.webSocketVersion === 8) response += "Sec-WebSocket-Origin: " + allowedOrigin + "\r\n";
		}
		if (cookies) {
			if (!Array.isArray(cookies)) {
				this.reject(500);
				throw new Error("Value supplied for \"cookies\" argument must be an array.");
			}
			var seenCookies = {};
			cookies.forEach(function(cookie) {
				if (!cookie.name || !cookie.value) {
					this.reject(500);
					throw new Error("Each cookie to set must at least provide a \"name\" and \"value\"");
				}
				cookie.name = cookie.name.replace(controlCharsAndSemicolonRegEx, "");
				cookie.value = cookie.value.replace(controlCharsAndSemicolonRegEx, "");
				if (seenCookies[cookie.name]) {
					this.reject(500);
					throw new Error("You may not specify the same cookie name twice.");
				}
				seenCookies[cookie.name] = true;
				var invalidChar = cookie.name.match(cookieNameValidateRegEx);
				if (invalidChar) {
					this.reject(500);
					throw new Error("Illegal character " + invalidChar[0] + " in cookie name");
				}
				if (cookie.value.match(cookieValueDQuoteValidateRegEx)) invalidChar = cookie.value.slice(1, -1).match(cookieValueValidateRegEx);
				else invalidChar = cookie.value.match(cookieValueValidateRegEx);
				if (invalidChar) {
					this.reject(500);
					throw new Error("Illegal character " + invalidChar[0] + " in cookie value");
				}
				var cookieParts = [cookie.name + "=" + cookie.value];
				if (cookie.path) {
					invalidChar = cookie.path.match(controlCharsAndSemicolonRegEx);
					if (invalidChar) {
						this.reject(500);
						throw new Error("Illegal character " + invalidChar[0] + " in cookie path");
					}
					cookieParts.push("Path=" + cookie.path);
				}
				if (cookie.domain) {
					if (typeof cookie.domain !== "string") {
						this.reject(500);
						throw new Error("Domain must be specified and must be a string.");
					}
					invalidChar = cookie.domain.match(controlCharsAndSemicolonRegEx);
					if (invalidChar) {
						this.reject(500);
						throw new Error("Illegal character " + invalidChar[0] + " in cookie domain");
					}
					cookieParts.push("Domain=" + cookie.domain.toLowerCase());
				}
				if (cookie.expires) {
					if (!(cookie.expires instanceof Date)) {
						this.reject(500);
						throw new Error("Value supplied for cookie \"expires\" must be a vaild date object");
					}
					cookieParts.push("Expires=" + cookie.expires.toGMTString());
				}
				if (cookie.maxage) {
					var maxage = cookie.maxage;
					if (typeof maxage === "string") maxage = parseInt(maxage, 10);
					if (isNaN(maxage) || maxage <= 0) {
						this.reject(500);
						throw new Error("Value supplied for cookie \"maxage\" must be a non-zero number");
					}
					maxage = Math.round(maxage);
					cookieParts.push("Max-Age=" + maxage.toString(10));
				}
				if (cookie.secure) {
					if (typeof cookie.secure !== "boolean") {
						this.reject(500);
						throw new Error("Value supplied for cookie \"secure\" must be of type boolean");
					}
					cookieParts.push("Secure");
				}
				if (cookie.httponly) {
					if (typeof cookie.httponly !== "boolean") {
						this.reject(500);
						throw new Error("Value supplied for cookie \"httponly\" must be of type boolean");
					}
					cookieParts.push("HttpOnly");
				}
				response += "Set-Cookie: " + cookieParts.join(";") + "\r\n";
			}.bind(this));
		}
		this._resolved = true;
		this.emit("requestResolved", this);
		response += "\r\n";
		var connection = new WebSocketConnection(this.socket, [], acceptedProtocol, false, this.serverConfig);
		connection.webSocketVersion = this.webSocketVersion;
		connection.remoteAddress = this.remoteAddress;
		connection.remoteAddresses = this.remoteAddresses;
		var self = this;
		if (this._socketIsClosing) cleanupFailedConnection(connection);
		else this.socket.write(response, "ascii", function(error) {
			if (error) {
				cleanupFailedConnection(connection);
				return;
			}
			self._removeSocketCloseListeners();
			connection._addSocketEventListeners();
		});
		this.emit("requestAccepted", connection);
		return connection;
	};
	WebSocketRequest.prototype.reject = function(status, reason, extraHeaders) {
		this._verifyResolution();
		this._resolved = true;
		this.emit("requestResolved", this);
		if (typeof status !== "number") status = 403;
		var response = "HTTP/1.1 " + status + " " + httpStatusDescriptions[status] + "\r\nConnection: close\r\n";
		if (reason) {
			reason = reason.replace(headerSanitizeRegExp, "");
			response += "X-WebSocket-Reject-Reason: " + reason + "\r\n";
		}
		if (extraHeaders) for (var key in extraHeaders) {
			var sanitizedValue = extraHeaders[key].toString().replace(headerSanitizeRegExp, "");
			var sanitizedKey = key.replace(headerSanitizeRegExp, "");
			response += sanitizedKey + ": " + sanitizedValue + "\r\n";
		}
		response += "\r\n";
		this.socket.end(response, "ascii");
		this.emit("requestRejected", this);
	};
	WebSocketRequest.prototype._handleSocketCloseBeforeAccept = function() {
		this._socketIsClosing = true;
		this._removeSocketCloseListeners();
	};
	WebSocketRequest.prototype._removeSocketCloseListeners = function() {
		this.socket.removeListener("end", this._socketCloseHandler);
		this.socket.removeListener("close", this._socketCloseHandler);
	};
	WebSocketRequest.prototype._verifyResolution = function() {
		if (this._resolved) throw new Error("WebSocketRequest may only be accepted or rejected one time.");
	};
	function cleanupFailedConnection(connection) {
		process.nextTick(function() {
			connection.drop(1006, "TCP connection lost before handshake completed.", true);
		});
	}
	module.exports = WebSocketRequest;
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketServer.js
var require_WebSocketServer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var extend = require_utils().extend;
	var utils = require_utils();
	var util$3 = __require("util");
	var debug = require_src()("websocket:server");
	var EventEmitter$3 = __require("events").EventEmitter;
	var WebSocketRequest = require_WebSocketRequest();
	var WebSocketServer = function WebSocketServer(config) {
		EventEmitter$3.call(this);
		this._handlers = {
			upgrade: this.handleUpgrade.bind(this),
			requestAccepted: this.handleRequestAccepted.bind(this),
			requestResolved: this.handleRequestResolved.bind(this)
		};
		this.connections = [];
		this.pendingRequests = [];
		if (config) this.mount(config);
	};
	util$3.inherits(WebSocketServer, EventEmitter$3);
	WebSocketServer.prototype.mount = function(config) {
		this.config = {
			httpServer: null,
			maxReceivedFrameSize: 65536,
			maxReceivedMessageSize: 1048576,
			fragmentOutgoingMessages: true,
			fragmentationThreshold: 16384,
			keepalive: true,
			keepaliveInterval: 2e4,
			dropConnectionOnKeepaliveTimeout: true,
			keepaliveGracePeriod: 1e4,
			useNativeKeepalive: false,
			assembleFragments: true,
			autoAcceptConnections: false,
			ignoreXForwardedFor: false,
			parseCookies: true,
			parseExtensions: true,
			disableNagleAlgorithm: true,
			closeTimeout: 5e3
		};
		extend(this.config, config);
		if (this.config.httpServer) {
			if (!Array.isArray(this.config.httpServer)) this.config.httpServer = [this.config.httpServer];
			var upgradeHandler = this._handlers.upgrade;
			this.config.httpServer.forEach(function(httpServer) {
				httpServer.on("upgrade", upgradeHandler);
			});
		} else throw new Error("You must specify an httpServer on which to mount the WebSocket server.");
	};
	WebSocketServer.prototype.unmount = function() {
		var upgradeHandler = this._handlers.upgrade;
		this.config.httpServer.forEach(function(httpServer) {
			httpServer.removeListener("upgrade", upgradeHandler);
		});
	};
	WebSocketServer.prototype.closeAllConnections = function() {
		this.connections.forEach(function(connection) {
			connection.close();
		});
		this.pendingRequests.forEach(function(request) {
			process.nextTick(function() {
				request.reject(503);
			});
		});
	};
	WebSocketServer.prototype.broadcast = function(data) {
		if (Buffer.isBuffer(data)) this.broadcastBytes(data);
		else if (typeof data.toString === "function") this.broadcastUTF(data);
	};
	WebSocketServer.prototype.broadcastUTF = function(utfData) {
		this.connections.forEach(function(connection) {
			connection.sendUTF(utfData);
		});
	};
	WebSocketServer.prototype.broadcastBytes = function(binaryData) {
		this.connections.forEach(function(connection) {
			connection.sendBytes(binaryData);
		});
	};
	WebSocketServer.prototype.shutDown = function() {
		this.unmount();
		this.closeAllConnections();
	};
	WebSocketServer.prototype.handleUpgrade = function(request, socket) {
		var self = this;
		var wsRequest = new WebSocketRequest(socket, request, this.config);
		try {
			wsRequest.readHandshake();
		} catch (e) {
			wsRequest.reject(e.httpCode ? e.httpCode : 400, e.message, e.headers);
			debug("Invalid handshake: %s", e.message);
			this.emit("upgradeError", e);
			return;
		}
		this.pendingRequests.push(wsRequest);
		wsRequest.once("requestAccepted", this._handlers.requestAccepted);
		wsRequest.once("requestResolved", this._handlers.requestResolved);
		socket.once("close", function() {
			self._handlers.requestResolved(wsRequest);
		});
		if (!this.config.autoAcceptConnections && utils.eventEmitterListenerCount(this, "request") > 0) this.emit("request", wsRequest);
		else if (this.config.autoAcceptConnections) wsRequest.accept(wsRequest.requestedProtocols[0], wsRequest.origin);
		else wsRequest.reject(404, "No handler is configured to accept the connection.");
	};
	WebSocketServer.prototype.handleRequestAccepted = function(connection) {
		var self = this;
		connection.once("close", function(closeReason, description) {
			self.handleConnectionClose(connection, closeReason, description);
		});
		this.connections.push(connection);
		this.emit("connect", connection);
	};
	WebSocketServer.prototype.handleConnectionClose = function(connection, closeReason, description) {
		var index = this.connections.indexOf(connection);
		if (index !== -1) this.connections.splice(index, 1);
		this.emit("close", connection, closeReason, description);
	};
	WebSocketServer.prototype.handleRequestResolved = function(request) {
		var index = this.pendingRequests.indexOf(request);
		if (index !== -1) this.pendingRequests.splice(index, 1);
	};
	module.exports = WebSocketServer;
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketClient.js
var require_WebSocketClient = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var utils = require_utils();
	var extend = utils.extend;
	var util$2 = __require("util");
	var EventEmitter$2 = __require("events").EventEmitter;
	var http = __require("http");
	var https = __require("https");
	var url = __require("url");
	var crypto$1 = __require("crypto");
	var WebSocketConnection = require_WebSocketConnection();
	var bufferAllocUnsafe = utils.bufferAllocUnsafe;
	var protocolSeparators = [
		"(",
		")",
		"<",
		">",
		"@",
		",",
		";",
		":",
		"\\",
		"\"",
		"/",
		"[",
		"]",
		"?",
		"=",
		"{",
		"}",
		" ",
		String.fromCharCode(9)
	];
	var excludedTlsOptions = [
		"hostname",
		"port",
		"method",
		"path",
		"headers"
	];
	function WebSocketClient(config) {
		EventEmitter$2.call(this);
		this.config = {
			maxReceivedFrameSize: 1048576,
			maxReceivedMessageSize: 8388608,
			fragmentOutgoingMessages: true,
			fragmentationThreshold: 16384,
			webSocketVersion: 13,
			assembleFragments: true,
			disableNagleAlgorithm: true,
			closeTimeout: 5e3,
			tlsOptions: {}
		};
		if (config) {
			var tlsOptions;
			if (config.tlsOptions) {
				tlsOptions = config.tlsOptions;
				delete config.tlsOptions;
			} else tlsOptions = {};
			extend(this.config, config);
			extend(this.config.tlsOptions, tlsOptions);
		}
		this._req = null;
		switch (this.config.webSocketVersion) {
			case 8:
			case 13: break;
			default: throw new Error("Requested webSocketVersion is not supported. Allowed values are 8 and 13.");
		}
	}
	util$2.inherits(WebSocketClient, EventEmitter$2);
	WebSocketClient.prototype.connect = function(requestUrl, protocols, origin, headers, extraRequestOptions) {
		var self = this;
		if (typeof protocols === "string") {
			if (protocols.length > 0) protocols = [protocols];
			else protocols = [];
		}
		if (!(protocols instanceof Array)) protocols = [];
		this.protocols = protocols;
		this.origin = origin;
		if (typeof requestUrl === "string") this.url = url.parse(requestUrl);
		else this.url = requestUrl;
		if (!this.url.protocol) throw new Error("You must specify a full WebSocket URL, including protocol.");
		if (!this.url.host) throw new Error("You must specify a full WebSocket URL, including hostname. Relative URLs are not supported.");
		this.secure = this.url.protocol === "wss:";
		this.protocols.forEach(function(protocol) {
			for (var i = 0; i < protocol.length; i++) {
				var charCode = protocol.charCodeAt(i);
				var character = protocol.charAt(i);
				if (charCode < 33 || charCode > 126 || protocolSeparators.indexOf(character) !== -1) throw new Error("Protocol list contains invalid character \"" + String.fromCharCode(charCode) + "\"");
			}
		});
		var defaultPorts = {
			"ws:": "80",
			"wss:": "443"
		};
		if (!this.url.port) this.url.port = defaultPorts[this.url.protocol];
		var nonce = bufferAllocUnsafe(16);
		for (var i = 0; i < 16; i++) nonce[i] = Math.round(Math.random() * 255);
		this.base64nonce = nonce.toString("base64");
		var hostHeaderValue = this.url.hostname;
		if (this.url.protocol === "ws:" && this.url.port !== "80" || this.url.protocol === "wss:" && this.url.port !== "443") hostHeaderValue += ":" + this.url.port;
		var reqHeaders = {};
		if (this.secure && this.config.tlsOptions.hasOwnProperty("headers")) extend(reqHeaders, this.config.tlsOptions.headers);
		if (headers) extend(reqHeaders, headers);
		extend(reqHeaders, {
			"Upgrade": "websocket",
			"Connection": "Upgrade",
			"Sec-WebSocket-Version": this.config.webSocketVersion.toString(10),
			"Sec-WebSocket-Key": this.base64nonce,
			"Host": reqHeaders.Host || hostHeaderValue
		});
		if (this.protocols.length > 0) reqHeaders["Sec-WebSocket-Protocol"] = this.protocols.join(", ");
		if (this.origin) {
			if (this.config.webSocketVersion === 13) reqHeaders["Origin"] = this.origin;
			else if (this.config.webSocketVersion === 8) reqHeaders["Sec-WebSocket-Origin"] = this.origin;
		}
		var pathAndQuery;
		if (this.url.pathname) pathAndQuery = this.url.path;
		else if (this.url.path) pathAndQuery = "/" + this.url.path;
		else pathAndQuery = "/";
		function handleRequestError(error) {
			self._req = null;
			self.emit("connectFailed", error);
		}
		var requestOptions = { agent: false };
		if (extraRequestOptions) extend(requestOptions, extraRequestOptions);
		extend(requestOptions, {
			hostname: this.url.hostname,
			port: this.url.port,
			method: "GET",
			path: pathAndQuery,
			headers: reqHeaders
		});
		if (this.secure) {
			var tlsOptions = this.config.tlsOptions;
			for (var key in tlsOptions) if (tlsOptions.hasOwnProperty(key) && excludedTlsOptions.indexOf(key) === -1) requestOptions[key] = tlsOptions[key];
		}
		var req = this._req = (this.secure ? https : http).request(requestOptions);
		req.on("upgrade", function handleRequestUpgrade(response, socket, head) {
			self._req = null;
			req.removeListener("error", handleRequestError);
			self.socket = socket;
			self.response = response;
			self.firstDataChunk = head;
			self.validateHandshake();
		});
		req.on("error", handleRequestError);
		req.on("response", function(response) {
			self._req = null;
			if (utils.eventEmitterListenerCount(self, "httpResponse") > 0) {
				self.emit("httpResponse", response, self);
				if (response.socket) response.socket.end();
			} else {
				var headerDumpParts = [];
				for (var headerName in response.headers) headerDumpParts.push(headerName + ": " + response.headers[headerName]);
				self.failHandshake("Server responded with a non-101 status: " + response.statusCode + " " + response.statusMessage + "\nResponse Headers Follow:\n" + headerDumpParts.join("\n") + "\n");
			}
		});
		req.end();
	};
	WebSocketClient.prototype.validateHandshake = function() {
		var headers = this.response.headers;
		if (this.protocols.length > 0) {
			this.protocol = headers["sec-websocket-protocol"];
			if (this.protocol) {
				if (this.protocols.indexOf(this.protocol) === -1) {
					this.failHandshake("Server did not respond with a requested protocol.");
					return;
				}
			} else {
				this.failHandshake("Expected a Sec-WebSocket-Protocol header.");
				return;
			}
		}
		if (!(headers["connection"] && headers["connection"].toLocaleLowerCase() === "upgrade")) {
			this.failHandshake("Expected a Connection: Upgrade header from the server");
			return;
		}
		if (!(headers["upgrade"] && headers["upgrade"].toLocaleLowerCase() === "websocket")) {
			this.failHandshake("Expected an Upgrade: websocket header from the server");
			return;
		}
		var sha1 = crypto$1.createHash("sha1");
		sha1.update(this.base64nonce + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11");
		var expectedKey = sha1.digest("base64");
		if (!headers["sec-websocket-accept"]) {
			this.failHandshake("Expected Sec-WebSocket-Accept header from server");
			return;
		}
		if (headers["sec-websocket-accept"] !== expectedKey) {
			this.failHandshake("Sec-WebSocket-Accept header from server didn't match expected value of " + expectedKey);
			return;
		}
		this.succeedHandshake();
	};
	WebSocketClient.prototype.failHandshake = function(errorDescription) {
		if (this.socket && this.socket.writable) this.socket.end();
		this.emit("connectFailed", new Error(errorDescription));
	};
	WebSocketClient.prototype.succeedHandshake = function() {
		var connection = new WebSocketConnection(this.socket, [], this.protocol, true, this.config);
		connection.webSocketVersion = this.config.webSocketVersion;
		connection._addSocketEventListeners();
		this.emit("connect", connection);
		if (this.firstDataChunk.length > 0) connection.handleSocketData(this.firstDataChunk);
		this.firstDataChunk = null;
	};
	WebSocketClient.prototype.abort = function() {
		if (this._req) this._req.abort();
	};
	module.exports = WebSocketClient;
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketRouterRequest.js
var require_WebSocketRouterRequest = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var util$1 = __require("util");
	var EventEmitter$1 = __require("events").EventEmitter;
	function WebSocketRouterRequest(webSocketRequest, resolvedProtocol) {
		EventEmitter$1.call(this);
		this.webSocketRequest = webSocketRequest;
		if (resolvedProtocol === "____no_protocol____") this.protocol = null;
		else this.protocol = resolvedProtocol;
		this.origin = webSocketRequest.origin;
		this.resource = webSocketRequest.resource;
		this.resourceURL = webSocketRequest.resourceURL;
		this.httpRequest = webSocketRequest.httpRequest;
		this.remoteAddress = webSocketRequest.remoteAddress;
		this.webSocketVersion = webSocketRequest.webSocketVersion;
		this.requestedExtensions = webSocketRequest.requestedExtensions;
		this.cookies = webSocketRequest.cookies;
	}
	util$1.inherits(WebSocketRouterRequest, EventEmitter$1);
	WebSocketRouterRequest.prototype.accept = function(origin, cookies) {
		var connection = this.webSocketRequest.accept(this.protocol, origin, cookies);
		this.emit("requestAccepted", connection);
		return connection;
	};
	WebSocketRouterRequest.prototype.reject = function(status, reason, extraHeaders) {
		this.webSocketRequest.reject(status, reason, extraHeaders);
		this.emit("requestRejected", this);
	};
	module.exports = WebSocketRouterRequest;
}));
//#endregion
//#region node_modules/websocket/lib/WebSocketRouter.js
var require_WebSocketRouter = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var extend = require_utils().extend;
	var util = __require("util");
	var EventEmitter = __require("events").EventEmitter;
	var WebSocketRouterRequest = require_WebSocketRouterRequest();
	function WebSocketRouter(config) {
		EventEmitter.call(this);
		this.config = { server: null };
		if (config) extend(this.config, config);
		this.handlers = [];
		this._requestHandler = this.handleRequest.bind(this);
		if (this.config.server) this.attachServer(this.config.server);
	}
	util.inherits(WebSocketRouter, EventEmitter);
	WebSocketRouter.prototype.attachServer = function(server) {
		if (server) {
			this.server = server;
			this.server.on("request", this._requestHandler);
		} else throw new Error("You must specify a WebSocketServer instance to attach to.");
	};
	WebSocketRouter.prototype.detachServer = function() {
		if (this.server) {
			this.server.removeListener("request", this._requestHandler);
			this.server = null;
		} else throw new Error("Cannot detach from server: not attached.");
	};
	WebSocketRouter.prototype.mount = function(path, protocol, callback) {
		if (!path) throw new Error("You must specify a path for this handler.");
		if (!protocol) protocol = "____no_protocol____";
		if (!callback) throw new Error("You must specify a callback for this handler.");
		path = this.pathToRegExp(path);
		if (!(path instanceof RegExp)) throw new Error("Path must be specified as either a string or a RegExp.");
		var pathString = path.toString();
		protocol = protocol.toLocaleLowerCase();
		if (this.findHandlerIndex(pathString, protocol) !== -1) throw new Error("You may only mount one handler per path/protocol combination.");
		this.handlers.push({
			"path": path,
			"pathString": pathString,
			"protocol": protocol,
			"callback": callback
		});
	};
	WebSocketRouter.prototype.unmount = function(path, protocol) {
		var index = this.findHandlerIndex(this.pathToRegExp(path).toString(), protocol);
		if (index !== -1) this.handlers.splice(index, 1);
		else throw new Error("Unable to find a route matching the specified path and protocol.");
	};
	WebSocketRouter.prototype.findHandlerIndex = function(pathString, protocol) {
		protocol = protocol.toLocaleLowerCase();
		for (var i = 0, len = this.handlers.length; i < len; i++) {
			var handler = this.handlers[i];
			if (handler.pathString === pathString && handler.protocol === protocol) return i;
		}
		return -1;
	};
	WebSocketRouter.prototype.pathToRegExp = function(path) {
		if (typeof path === "string") {
			if (path === "*") path = /^.*$/;
			else {
				path = path.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
				path = new RegExp("^" + path + "$");
			}
		}
		return path;
	};
	WebSocketRouter.prototype.handleRequest = function(request) {
		var requestedProtocols = request.requestedProtocols;
		if (requestedProtocols.length === 0) requestedProtocols = ["____no_protocol____"];
		for (var i = 0; i < requestedProtocols.length; i++) {
			var requestedProtocol = requestedProtocols[i].toLocaleLowerCase();
			for (var j = 0, len = this.handlers.length; j < len; j++) {
				var handler = this.handlers[j];
				if (handler.path.test(request.resourceURL.pathname)) {
					if (requestedProtocol === handler.protocol || handler.protocol === "*") {
						var routerRequest = new WebSocketRouterRequest(request, requestedProtocol);
						handler.callback(routerRequest);
						return;
					}
				}
			}
		}
		request.reject(404, "No handler is available for the given request.");
	};
	module.exports = WebSocketRouter;
}));
//#endregion
//#region node_modules/typedarray-to-buffer/index.js
var require_typedarray_to_buffer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Convert a typed array to a Buffer without a copy
	*
	* Author:   Feross Aboukhadijeh <https://feross.org>
	* License:  MIT
	*
	* `npm install typedarray-to-buffer`
	*/
	var isTypedArray = require_is_typedarray().strict;
	module.exports = function typedarrayToBuffer(arr) {
		if (isTypedArray(arr)) {
			var buf = Buffer.from(arr.buffer);
			if (arr.byteLength !== arr.buffer.byteLength) buf = buf.slice(arr.byteOffset, arr.byteOffset + arr.byteLength);
			return buf;
		} else return Buffer.from(arr);
	};
}));
//#endregion
//#region node_modules/yaeti/lib/EventTarget.js
var require_EventTarget = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Expose the _EventTarget class.
	*/
	module.exports = _EventTarget;
	function _EventTarget() {
		if (typeof this.addEventListener === "function") return;
		this._listeners = {};
		this.addEventListener = _addEventListener;
		this.removeEventListener = _removeEventListener;
		this.dispatchEvent = _dispatchEvent;
	}
	Object.defineProperties(_EventTarget.prototype, { listeners: { get: function() {
		return this._listeners;
	} } });
	function _addEventListener(type, newListener) {
		var listenersType, i, listener;
		if (!type || !newListener) return;
		listenersType = this._listeners[type];
		if (listenersType === void 0) this._listeners[type] = listenersType = [];
		for (i = 0; !!(listener = listenersType[i]); i++) if (listener === newListener) return;
		listenersType.push(newListener);
	}
	function _removeEventListener(type, oldListener) {
		var listenersType, i, listener;
		if (!type || !oldListener) return;
		listenersType = this._listeners[type];
		if (listenersType === void 0) return;
		for (i = 0; !!(listener = listenersType[i]); i++) if (listener === oldListener) {
			listenersType.splice(i, 1);
			break;
		}
		if (listenersType.length === 0) delete this._listeners[type];
	}
	function _dispatchEvent(event) {
		var type, listenersType, dummyListener, stopImmediatePropagation = false, i, listener;
		if (!event || typeof event.type !== "string") throw new Error("`event` must have a valid `type` property");
		if (event._yaeti) {
			event.target = this;
			event.cancelable = true;
		}
		try {
			event.stopImmediatePropagation = function() {
				stopImmediatePropagation = true;
			};
		} catch (error) {}
		type = event.type;
		listenersType = this._listeners[type] || [];
		dummyListener = this["on" + type];
		if (typeof dummyListener === "function") dummyListener.call(this, event);
		for (i = 0; !!(listener = listenersType[i]); i++) {
			if (stopImmediatePropagation) break;
			listener.call(this, event);
		}
		return !event.defaultPrevented;
	}
}));
//#endregion
//#region node_modules/yaeti/lib/Event.js
var require_Event = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Expose the Event class.
	*/
	module.exports = _Event;
	function _Event(type) {
		this.type = type;
		this.isTrusted = false;
		this._yaeti = true;
	}
}));
//#endregion
//#region node_modules/yaeti/index.js
var require_yaeti = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		EventTarget: require_EventTarget(),
		Event: require_Event()
	};
}));
//#endregion
//#region node_modules/websocket/lib/W3CWebSocket.js
var require_W3CWebSocket = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/************************************************************************
	*  Copyright 2010-2015 Brian McKelvey.
	*
	*  Licensed under the Apache License, Version 2.0 (the "License");
	*  you may not use this file except in compliance with the License.
	*  You may obtain a copy of the License at
	*
	*      http://www.apache.org/licenses/LICENSE-2.0
	*
	*  Unless required by applicable law or agreed to in writing, software
	*  distributed under the License is distributed on an "AS IS" BASIS,
	*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	*  See the License for the specific language governing permissions and
	*  limitations under the License.
	***********************************************************************/
	var WebSocketClient = require_WebSocketClient();
	var toBuffer = require_typedarray_to_buffer();
	var yaeti = require_yaeti();
	var CONNECTING = 0;
	var OPEN = 1;
	var CLOSING = 2;
	var CLOSED = 3;
	module.exports = W3CWebSocket;
	function W3CWebSocket(url, protocols, origin, headers, requestOptions, clientConfig) {
		yaeti.EventTarget.call(this);
		clientConfig = clientConfig || {};
		clientConfig.assembleFragments = true;
		var self = this;
		this._url = url;
		this._readyState = CONNECTING;
		this._protocol = void 0;
		this._extensions = "";
		this._bufferedAmount = 0;
		this._binaryType = "arraybuffer";
		this._connection = void 0;
		this._client = new WebSocketClient(clientConfig);
		this._client.on("connect", function(connection) {
			onConnect.call(self, connection);
		});
		this._client.on("connectFailed", function() {
			onConnectFailed.call(self);
		});
		this._client.connect(url, protocols, origin, headers, requestOptions);
	}
	Object.defineProperties(W3CWebSocket.prototype, {
		url: { get: function() {
			return this._url;
		} },
		readyState: { get: function() {
			return this._readyState;
		} },
		protocol: { get: function() {
			return this._protocol;
		} },
		extensions: { get: function() {
			return this._extensions;
		} },
		bufferedAmount: { get: function() {
			return this._bufferedAmount;
		} }
	});
	Object.defineProperties(W3CWebSocket.prototype, { binaryType: {
		get: function() {
			return this._binaryType;
		},
		set: function(type) {
			if (type !== "arraybuffer") throw new SyntaxError("just \"arraybuffer\" type allowed for \"binaryType\" attribute");
			this._binaryType = type;
		}
	} });
	[
		["CONNECTING", CONNECTING],
		["OPEN", OPEN],
		["CLOSING", CLOSING],
		["CLOSED", CLOSED]
	].forEach(function(property) {
		Object.defineProperty(W3CWebSocket.prototype, property[0], { get: function() {
			return property[1];
		} });
	});
	[
		["CONNECTING", CONNECTING],
		["OPEN", OPEN],
		["CLOSING", CLOSING],
		["CLOSED", CLOSED]
	].forEach(function(property) {
		Object.defineProperty(W3CWebSocket, property[0], { get: function() {
			return property[1];
		} });
	});
	W3CWebSocket.prototype.send = function(data) {
		if (this._readyState !== OPEN) throw new Error("cannot call send() while not connected");
		if (typeof data === "string" || data instanceof String) this._connection.sendUTF(data);
		else if (data instanceof Buffer) this._connection.sendBytes(data);
		else if (data.byteLength || data.byteLength === 0) {
			data = toBuffer(data);
			this._connection.sendBytes(data);
		} else throw new Error("unknown binary data:", data);
	};
	W3CWebSocket.prototype.close = function(code, reason) {
		switch (this._readyState) {
			case CONNECTING:
				onConnectFailed.call(this);
				this._client.on("connect", function(connection) {
					if (code) connection.close(code, reason);
					else connection.close();
				});
				break;
			case OPEN:
				this._readyState = CLOSING;
				if (code) this._connection.close(code, reason);
				else this._connection.close();
				break;
			case CLOSING:
			case CLOSED:
		}
	};
	/**
	* Private API.
	*/
	function createCloseEvent(code, reason) {
		var event = new yaeti.Event("close");
		event.code = code;
		event.reason = reason;
		event.wasClean = typeof code === "undefined" || code === 1e3;
		return event;
	}
	function createMessageEvent(data) {
		var event = new yaeti.Event("message");
		event.data = data;
		return event;
	}
	function onConnect(connection) {
		var self = this;
		this._readyState = OPEN;
		this._connection = connection;
		this._protocol = connection.protocol;
		this._extensions = connection.extensions;
		this._connection.on("close", function(code, reason) {
			onClose.call(self, code, reason);
		});
		this._connection.on("message", function(msg) {
			onMessage.call(self, msg);
		});
		this.dispatchEvent(new yaeti.Event("open"));
	}
	function onConnectFailed() {
		destroy.call(this);
		this._readyState = CLOSED;
		try {
			this.dispatchEvent(new yaeti.Event("error"));
		} finally {
			this.dispatchEvent(createCloseEvent(1006, "connection failed"));
		}
	}
	function onClose(code, reason) {
		destroy.call(this);
		this._readyState = CLOSED;
		this.dispatchEvent(createCloseEvent(code, reason || ""));
	}
	function onMessage(message) {
		if (message.utf8Data) this.dispatchEvent(createMessageEvent(message.utf8Data));
		else if (message.binaryData) {
			if (this.binaryType === "arraybuffer") {
				var buffer = message.binaryData;
				var arraybuffer = new ArrayBuffer(buffer.length);
				var view = new Uint8Array(arraybuffer);
				for (var i = 0, len = buffer.length; i < len; ++i) view[i] = buffer[i];
				this.dispatchEvent(createMessageEvent(arraybuffer));
			}
		}
	}
	function destroy() {
		this._client.removeAllListeners();
		if (this._connection) this._connection.removeAllListeners();
	}
}));
//#endregion
//#region node_modules/websocket/lib/Deprecation.js
var require_Deprecation = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		disableWarnings: false,
		deprecationWarningMap: {},
		warn: function(deprecationName) {
			if (!this.disableWarnings && this.deprecationWarningMap[deprecationName]) {
				console.warn("DEPRECATION WARNING: " + this.deprecationWarningMap[deprecationName]);
				this.deprecationWarningMap[deprecationName] = false;
			}
		}
	};
}));
//#endregion
//#region node_modules/websocket/package.json
var package_exports = /* @__PURE__ */ __exportAll({
	author: () => author,
	browser: () => browser,
	config: () => config,
	contributors: () => contributors,
	default: () => package_default,
	dependencies: () => dependencies,
	description: () => description,
	devDependencies: () => devDependencies,
	directories: () => directories,
	engines: () => engines,
	homepage: () => homepage,
	keywords: () => keywords,
	license: () => license,
	main: () => main,
	name: () => name,
	repository: () => repository,
	scripts: () => scripts,
	version: () => version
});
var name, description, keywords, author, contributors, version, repository, homepage, engines, dependencies, devDependencies, config, scripts, main, directories, browser, license, package_default;
var init_package = __esmMin((() => {
	name = "websocket";
	description = "Websocket Client & Server Library implementing the WebSocket protocol as specified in RFC 6455.";
	keywords = [
		"websocket",
		"websockets",
		"socket",
		"networking",
		"comet",
		"push",
		"RFC-6455",
		"realtime",
		"server",
		"client"
	];
	author = "Brian McKelvey <theturtle32@gmail.com> (https://github.com/theturtle32)";
	contributors = ["Iñaki Baz Castillo <ibc@aliax.net> (http://dev.sipdoc.net)"];
	version = "1.0.35";
	repository = {
		"type": "git",
		"url": "https://github.com/theturtle32/WebSocket-Node.git"
	};
	homepage = "https://github.com/theturtle32/WebSocket-Node";
	engines = { "node": ">=4.0.0" };
	dependencies = {
		"bufferutil": "^4.0.1",
		"debug": "^2.2.0",
		"es5-ext": "^0.10.63",
		"typedarray-to-buffer": "^3.1.5",
		"utf-8-validate": "^5.0.2",
		"yaeti": "^0.0.6"
	};
	devDependencies = {
		"buffer-equal": "^1.0.0",
		"gulp": "^4.0.2",
		"gulp-jshint": "^2.0.4",
		"jshint-stylish": "^2.2.1",
		"jshint": "^2.0.0",
		"tape": "^4.9.1"
	};
	config = { "verbose": false };
	scripts = {
		"test": "tape test/unit/*.js",
		"gulp": "gulp"
	};
	main = "index";
	directories = { "lib": "./lib" };
	browser = "lib/browser.js";
	license = "Apache-2.0";
	package_default = {
		name,
		description,
		keywords,
		author,
		contributors,
		version,
		repository,
		homepage,
		engines,
		dependencies,
		devDependencies,
		config,
		scripts,
		main,
		directories,
		browser,
		license
	};
}));
//#endregion
//#region node_modules/websocket/lib/version.js
var require_version = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = (init_package(), __toCommonJS(package_exports).default).version;
}));
//#endregion
//#region node_modules/websocket/lib/websocket.js
var require_websocket$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = {
		"server": require_WebSocketServer(),
		"client": require_WebSocketClient(),
		"router": require_WebSocketRouter(),
		"frame": require_WebSocketFrame(),
		"request": require_WebSocketRequest(),
		"connection": require_WebSocketConnection(),
		"w3cwebsocket": require_W3CWebSocket(),
		"deprecation": require_Deprecation(),
		"version": require_version()
	};
}));
//#endregion
//#region node_modules/websocket/index.js
var require_websocket = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_websocket$1();
}));
//#endregion
//#region node_modules/telegram/extensions/PromisedWebSockets.js
var require_PromisedWebSockets = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PromisedWebSockets = void 0;
	var websocket_1 = require_websocket();
	var async_mutex_1 = require_lib$1();
	var platform_1 = require_platform();
	var mutex = new async_mutex_1.Mutex();
	var closeError = /* @__PURE__ */ new Error("WebSocket was closed");
	var PromisedWebSockets = class {
		constructor() {
			this.client = void 0;
			this.stream = Buffer.alloc(0);
			this.closed = true;
		}
		async readExactly(number) {
			let readData = Buffer.alloc(0);
			while (true) {
				const thisTime = await this.read(number);
				readData = Buffer.concat([readData, thisTime]);
				number = number - thisTime.length;
				if (!number) return readData;
			}
		}
		async read(number) {
			if (this.closed) throw closeError;
			await this.canRead;
			if (this.closed) throw closeError;
			const toReturn = this.stream.slice(0, number);
			this.stream = this.stream.slice(number);
			if (this.stream.length === 0) this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			return toReturn;
		}
		async readAll() {
			if (this.closed || !await this.canRead) throw closeError;
			const toReturn = this.stream;
			this.stream = Buffer.alloc(0);
			this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			return toReturn;
		}
		getWebSocketLink(ip, port, testServers) {
			if (port === 443) return `wss://${ip}:${port}/apiws${testServers ? "_test" : ""}`;
			else return `ws://${ip}:${port}/apiws${testServers ? "_test" : ""}`;
		}
		async connect(port, ip, testServers = false) {
			this.stream = Buffer.alloc(0);
			this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			this.closed = false;
			this.website = this.getWebSocketLink(ip, port, testServers);
			this.client = new websocket_1.w3cwebsocket(this.website, "binary");
			return new Promise((resolve, reject) => {
				if (this.client) {
					this.client.onopen = () => {
						this.receive();
						resolve(this);
					};
					this.client.onerror = (error) => {
						reject(error);
					};
					this.client.onclose = () => {
						if (this.resolveRead) this.resolveRead(false);
						this.closed = true;
					};
					if (platform_1.isBrowser) window.addEventListener("offline", async () => {
						await this.close();
						if (this.resolveRead) this.resolveRead(false);
					});
				}
			});
		}
		write(data) {
			if (this.closed) throw closeError;
			if (this.client) this.client.send(data);
		}
		async close() {
			if (this.client) await this.client.close();
			this.closed = true;
		}
		async receive() {
			if (this.client) this.client.onmessage = async (message) => {
				const release = await mutex.acquire();
				try {
					let data;
					data = Buffer.from(await new Response(message.data).arrayBuffer());
					this.stream = Buffer.concat([this.stream, data]);
					if (this.resolveRead) this.resolveRead(true);
				} finally {
					release();
				}
			};
		}
		toString() {
			return "PromisedWebSocket";
		}
	};
	exports.PromisedWebSockets = PromisedWebSockets;
}));
//#endregion
//#region node_modules/telegram/extensions/net.js
var require_net = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$3) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$3, p)) __createBinding(exports$3, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	__exportStar(__require("net"), exports);
}));
//#endregion
//#region node_modules/telegram/extensions/socks.js
var require_socks = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$2) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$2, p)) __createBinding(exports$2, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	__exportStar(require_build(), exports);
}));
//#endregion
//#region node_modules/telegram/extensions/PromisedNetSockets.js
var require_PromisedNetSockets = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PromisedNetSockets = void 0;
	var net = __importStar(require_net());
	var socks_1 = require_socks();
	var mutex = new (require_lib$1()).Mutex();
	var closeError = /* @__PURE__ */ new Error("NetSocket was closed");
	var PromisedNetSockets = class {
		constructor(proxy) {
			this.client = void 0;
			this.closed = true;
			this.stream = Buffer.alloc(0);
			if (proxy) {
				if (!("MTProxy" in proxy)) {
					if (!proxy.ip || !proxy.port || !proxy.socksType) throw new Error(`Invalid sockets params: ip=${proxy.ip}, port=${proxy.port}, socksType=${proxy.socksType}`);
					this.proxy = proxy;
				}
			}
		}
		async readExactly(number) {
			let readData = Buffer.alloc(0);
			while (true) {
				const thisTime = await this.read(number);
				readData = Buffer.concat([readData, thisTime]);
				number = number - thisTime.length;
				if (!number || number === -437) return readData;
			}
		}
		async read(number) {
			if (this.closed) throw closeError;
			await this.canRead;
			if (this.closed) throw closeError;
			const toReturn = this.stream.slice(0, number);
			this.stream = this.stream.slice(number);
			if (this.stream.length === 0) this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			return toReturn;
		}
		async readAll() {
			if (this.closed || !await this.canRead) throw closeError;
			const toReturn = this.stream;
			this.stream = Buffer.alloc(0);
			this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			return toReturn;
		}
		/**
		* Creates a new connection
		* @param port
		* @param ip
		* @returns {Promise<void>}
		*/
		async connect(port, ip) {
			this.stream = Buffer.alloc(0);
			let connected = false;
			if (this.proxy) {
				const info = await socks_1.SocksClient.createConnection({
					proxy: {
						host: this.proxy.ip,
						port: this.proxy.port,
						type: this.proxy.socksType,
						userId: this.proxy.username,
						password: this.proxy.password
					},
					command: "connect",
					timeout: (this.proxy.timeout || 5) * 1e3,
					destination: {
						host: ip,
						port
					}
				});
				this.client = info.socket;
				connected = true;
			} else this.client = new net.Socket();
			this.canRead = new Promise((resolve) => {
				this.resolveRead = resolve;
			});
			this.closed = false;
			return new Promise((resolve, reject) => {
				if (this.client) {
					if (connected) {
						this.receive();
						resolve(this);
					} else this.client.connect(port, ip, () => {
						this.receive();
						resolve(this);
					});
					this.client.on("error", reject);
					this.client.on("close", () => {
						if (this.client && this.client.destroyed) {
							if (this.resolveRead) this.resolveRead(false);
							this.closed = true;
						}
					});
				}
			});
		}
		write(data) {
			if (this.closed) throw closeError;
			if (this.client) this.client.write(data);
		}
		async close() {
			if (this.client) {
				await this.client.destroy();
				this.client.unref();
			}
			this.closed = true;
		}
		async receive() {
			if (this.client) this.client.on("data", async (message) => {
				const release = await mutex.acquire();
				try {
					this.stream = Buffer.concat([this.stream, message]);
					if (this.resolveRead) this.resolveRead(true);
				} finally {
					release();
				}
			});
		}
		toString() {
			return "PromisedNetSocket";
		}
	};
	exports.PromisedNetSockets = PromisedNetSockets;
}));
//#endregion
//#region node_modules/telegram/extensions/MessagePacker.js
var require_MessagePacker = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MessagePacker = void 0;
	var core_1 = require_core();
	var core_2 = require_core();
	var BinaryWriter_1 = require_BinaryWriter();
	var USE_INVOKE_AFTER_WITH = /* @__PURE__ */ new Set([
		"messages.SendMessage",
		"messages.SendMedia",
		"messages.SendMultiMedia",
		"messages.ForwardMessages",
		"messages.SendInlineBotResult"
	]);
	var MessagePacker = class {
		constructor(state, logger) {
			this._state = state;
			this._queue = [];
			this._pendingStates = [];
			this._ready = new Promise((resolve) => {
				this.setReady = resolve;
			});
			this._log = logger;
		}
		values() {
			return this._queue;
		}
		append(state, setReady = true, atStart = false) {
			var _a, _b;
			if (state && USE_INVOKE_AFTER_WITH.has(state.request.className)) {
				if (atStart) {
					for (let i = 0; i < this._queue.length; i++) if (USE_INVOKE_AFTER_WITH.has((_a = this._queue[i]) === null || _a === void 0 ? void 0 : _a.request.className)) {
						this._queue[i].after = state;
						break;
					}
				} else for (let i = this._queue.length - 1; i >= 0; i--) if (USE_INVOKE_AFTER_WITH.has((_b = this._queue[i]) === null || _b === void 0 ? void 0 : _b.request.className)) {
					state.after = this._queue[i];
					break;
				}
			}
			if (atStart) this._queue.unshift(state);
			else this._queue.push(state);
			if (setReady && this.setReady) this.setReady(true);
			if (state && state.request.CONSTRUCTOR_ID !== 1658238041) {
				this._pendingStates.push(state);
				state.promise.catch((err) => {}).finally(() => {
					this._pendingStates = this._pendingStates.filter((s) => s !== state);
				});
			}
		}
		prepend(states) {
			states.reverse().forEach((state) => {
				this.append(state, false, true);
			});
			if (this.setReady) this.setReady(true);
		}
		extend(states) {
			states.forEach((state) => {
				this.append(state, false);
			});
			if (this.setReady) this.setReady(true);
		}
		clear() {
			this._queue = [];
			this.append(void 0);
		}
		async wait() {
			if (!this._queue.length) {
				this._ready = new Promise((resolve) => {
					this.setReady = resolve;
				});
				await this._ready;
			}
		}
		async get() {
			if (!this._queue[this._queue.length - 1]) {
				this._queue = this._queue.filter(Boolean);
				return;
			}
			let data;
			let buffer = new BinaryWriter_1.BinaryWriter(Buffer.alloc(0));
			const batch = [];
			let size = 0;
			while (this._queue.length && batch.length <= core_1.MessageContainer.MAXIMUM_LENGTH) {
				const state = this._queue.shift();
				if (!state) continue;
				size += state.data.length + core_2.TLMessage.SIZE_OVERHEAD;
				if (size <= core_1.MessageContainer.MAXIMUM_SIZE) {
					let afterId;
					if (state.after) afterId = state.after.msgId;
					if (state.after) afterId = state.after.msgId;
					state.msgId = await this._state.writeDataAsMessage(buffer, state.data, state.request.classType === "request", afterId);
					this._log.debug(`Assigned msgId = ${state.msgId} to ${state.request.className || state.request.constructor.name}`);
					batch.push(state);
					continue;
				}
				if (batch.length) {
					this._queue.unshift(state);
					break;
				}
				this._log.warn(`Message payload for ${state.request.className || state.request.constructor.name} is too long ${state.data.length} and cannot be sent`);
				state.promise.reject("Request Payload is too big");
				size = 0;
			}
			if (!batch.length) return null;
			if (batch.length > 1) {
				const b = Buffer.alloc(8);
				b.writeUInt32LE(core_1.MessageContainer.CONSTRUCTOR_ID, 0);
				b.writeInt32LE(batch.length, 4);
				data = Buffer.concat([b, buffer.getValue()]);
				buffer = new BinaryWriter_1.BinaryWriter(Buffer.alloc(0));
				const containerId = await this._state.writeDataAsMessage(buffer, data, false);
				for (const s of batch) s.containerId = containerId;
			}
			data = buffer.getValue();
			return {
				batch,
				data
			};
		}
	};
	exports.MessagePacker = MessagePacker;
}));
//#endregion
//#region node_modules/telegram/extensions/AsyncQueue.js
var require_AsyncQueue = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsyncQueue = void 0;
	var AsyncQueue = class {
		constructor() {
			this._queue = [];
			this.canPush = true;
			this.resolvePush = (value) => {};
			this.resolveGet = (value) => {};
			this.canGet = new Promise((resolve) => {
				this.resolveGet = resolve;
			});
		}
		async push(value) {
			await this.canPush;
			this._queue.push(value);
			this.resolveGet(true);
			this.canPush = new Promise((resolve) => {
				this.resolvePush = resolve;
			});
		}
		async pop() {
			await this.canGet;
			const returned = this._queue.pop();
			this.resolvePush(true);
			this.canGet = new Promise((resolve) => {
				this.resolveGet = resolve;
			});
			return returned;
		}
	};
	exports.AsyncQueue = AsyncQueue;
}));
//#endregion
//#region node_modules/telegram/extensions/index.js
var require_extensions = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AsyncQueue = exports.MessagePacker = exports.PromisedNetSockets = exports.PromisedWebSockets = exports.BinaryReader = exports.BinaryWriter = exports.Logger = void 0;
	var Logger_1 = require_Logger();
	Object.defineProperty(exports, "Logger", {
		enumerable: true,
		get: function() {
			return Logger_1.Logger;
		}
	});
	var BinaryWriter_1 = require_BinaryWriter();
	Object.defineProperty(exports, "BinaryWriter", {
		enumerable: true,
		get: function() {
			return BinaryWriter_1.BinaryWriter;
		}
	});
	var BinaryReader_1 = require_BinaryReader();
	Object.defineProperty(exports, "BinaryReader", {
		enumerable: true,
		get: function() {
			return BinaryReader_1.BinaryReader;
		}
	});
	var PromisedWebSockets_1 = require_PromisedWebSockets();
	Object.defineProperty(exports, "PromisedWebSockets", {
		enumerable: true,
		get: function() {
			return PromisedWebSockets_1.PromisedWebSockets;
		}
	});
	var PromisedNetSockets_1 = require_PromisedNetSockets();
	Object.defineProperty(exports, "PromisedNetSockets", {
		enumerable: true,
		get: function() {
			return PromisedNetSockets_1.PromisedNetSockets;
		}
	});
	var MessagePacker_1 = require_MessagePacker();
	Object.defineProperty(exports, "MessagePacker", {
		enumerable: true,
		get: function() {
			return MessagePacker_1.MessagePacker;
		}
	});
	var AsyncQueue_1 = require_AsyncQueue();
	Object.defineProperty(exports, "AsyncQueue", {
		enumerable: true,
		get: function() {
			return AsyncQueue_1.AsyncQueue;
		}
	});
}));
//#endregion
//#region node_modules/telegram/network/connection/Connection.js
var require_Connection = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ObfuscatedConnection = exports.PacketCodec = exports.Connection = void 0;
	var extensions_1 = require_extensions();
	/**
	* The `Connection` class is a wrapper around ``asyncio.open_connection``.
	*
	* Subclasses will implement different transport modes as atomic operations,
	* which this class eases doing since the exposed interface simply puts and
	* gets complete data payloads to and from queues.
	*
	* The only error that will raise from send and receive methods is
	* ``ConnectionError``, which will raise when attempting to send if
	* the client is disconnected (includes remote disconnections).
	*/
	var Connection = class {
		constructor({ ip, port, dcId, loggers, proxy, socket, testServers }) {
			this._ip = ip;
			this._port = port;
			this._dcId = dcId;
			this._log = loggers;
			this._proxy = proxy;
			this._connected = false;
			this._sendTask = void 0;
			this._recvTask = void 0;
			this._codec = void 0;
			this._obfuscation = void 0;
			this._sendArray = new extensions_1.AsyncQueue();
			this._recvArray = new extensions_1.AsyncQueue();
			this.socket = new socket(proxy);
			this._testServers = testServers;
		}
		async _connect() {
			this._log.debug("Connecting");
			this._codec = new this.PacketCodecClass(this);
			await this.socket.connect(this._port, this._ip, this._testServers);
			this._log.debug("Finished connecting");
			await this._initConn();
		}
		async connect() {
			await this._connect();
			this._connected = true;
			if (!this._sendTask) this._sendTask = this._sendLoop();
			this._recvTask = this._recvLoop();
		}
		async disconnect() {
			if (!this._connected) return;
			this._connected = false;
			this._recvArray.push(void 0);
			await this.socket.close();
		}
		async send(data) {
			if (!this._connected) throw new Error("Not connected");
			await this._sendArray.push(data);
		}
		async recv() {
			while (this._connected) {
				const result = await this._recvArray.pop();
				if (result) return result;
			}
			throw new Error("Not connected");
		}
		async _sendLoop() {
			try {
				while (this._connected) {
					const data = await this._sendArray.pop();
					if (!data) {
						this._sendTask = void 0;
						return;
					}
					await this._send(data);
				}
			} catch (e) {
				this._log.info("The server closed the connection while sending");
			}
		}
		isConnected() {
			return this._connected;
		}
		async _recvLoop() {
			let data;
			while (this._connected) {
				try {
					data = await this._recv();
					if (!data) throw new Error("no data received");
				} catch (e) {
					this._log.info("connection closed");
					this.disconnect();
					return;
				}
				await this._recvArray.push(data);
			}
		}
		async _initConn() {
			if (this._codec.tag) await this.socket.write(this._codec.tag);
		}
		async _send(data) {
			const encodedPacket = this._codec.encodePacket(data);
			this.socket.write(encodedPacket);
		}
		async _recv() {
			return await this._codec.readPacket(this.socket);
		}
		toString() {
			return `${this._ip}:${this._port}/${this.constructor.name.replace("Connection", "")}`;
		}
	};
	exports.Connection = Connection;
	var ObfuscatedConnection = class extends Connection {
		constructor() {
			super(...arguments);
			this.ObfuscatedIO = void 0;
		}
		async _initConn() {
			this._obfuscation = new this.ObfuscatedIO(this);
			await this._obfuscation.initHeader();
			this.socket.write(this._obfuscation.header);
		}
		async _send(data) {
			this._obfuscation.write(this._codec.encodePacket(data));
		}
		async _recv() {
			return await this._codec.readPacket(this._obfuscation);
		}
	};
	exports.ObfuscatedConnection = ObfuscatedConnection;
	var PacketCodec = class {
		constructor(connection) {
			this._conn = connection;
		}
		encodePacket(data) {
			throw new Error("Not Implemented");
		}
		async readPacket(reader) {
			throw new Error("Not Implemented");
		}
	};
	exports.PacketCodec = PacketCodec;
}));
//#endregion
//#region node_modules/telegram/network/connection/TCPFull.js
var require_TCPFull = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPFull = exports.FullPacketCodec = void 0;
	var Connection_1 = require_Connection();
	var Helpers_1 = require_Helpers();
	var errors_1 = require_errors();
	var FullPacketCodec = class extends Connection_1.PacketCodec {
		constructor(connection) {
			super(connection);
			this._sendCounter = 0;
		}
		encodePacket(data) {
			const length = data.length + 12;
			const e = Buffer.alloc(8);
			e.writeInt32LE(length, 0);
			e.writeInt32LE(this._sendCounter, 4);
			data = Buffer.concat([e, data]);
			const crc = Buffer.alloc(4);
			crc.writeUInt32LE((0, Helpers_1.crc32)(data), 0);
			this._sendCounter += 1;
			return Buffer.concat([data, crc]);
		}
		/**
		*
		* @param reader {PromisedWebSockets}
		* @returns {Promise<*>}
		*/
		async readPacket(reader) {
			const packetLenSeq = await reader.readExactly(8);
			if (packetLenSeq === void 0) return Buffer.alloc(0);
			const packetLen = packetLenSeq.readInt32LE(0);
			if (packetLen < 0) {
				const body = await reader.readExactly(4);
				throw new errors_1.InvalidBufferError(body);
			}
			let body = await reader.readExactly(packetLen - 8);
			const checksum = body.slice(-4).readUInt32LE(0);
			body = body.slice(0, -4);
			const validChecksum = (0, Helpers_1.crc32)(Buffer.concat([packetLenSeq, body]));
			if (!(validChecksum === checksum)) throw new errors_1.InvalidChecksumError(checksum, validChecksum);
			return body;
		}
	};
	exports.FullPacketCodec = FullPacketCodec;
	var ConnectionTCPFull = class extends Connection_1.Connection {
		constructor() {
			super(...arguments);
			this.PacketCodecClass = FullPacketCodec;
		}
	};
	exports.ConnectionTCPFull = ConnectionTCPFull;
}));
//#endregion
//#region node_modules/telegram/network/connection/TCPAbridged.js
var require_TCPAbridged = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPAbridged = exports.AbridgedPacketCodec = void 0;
	var Helpers_1 = require_Helpers();
	var Connection_1 = require_Connection();
	var big_integer_1 = __importDefault(require_BigInteger());
	var AbridgedPacketCodec = class AbridgedPacketCodec extends Connection_1.PacketCodec {
		constructor(props) {
			super(props);
			this.tag = AbridgedPacketCodec.tag;
			this.obfuscateTag = AbridgedPacketCodec.obfuscateTag;
		}
		encodePacket(data) {
			let length = data.length >> 2;
			let temp;
			if (length < 127) {
				const b = Buffer.alloc(1);
				b.writeUInt8(length, 0);
				temp = b;
			} else temp = Buffer.concat([Buffer.from("7f", "hex"), (0, Helpers_1.readBufferFromBigInt)((0, big_integer_1.default)(length), 3)]);
			return Buffer.concat([temp, data]);
		}
		async readPacket(reader) {
			let length = (await reader.read(1))[0];
			if (length >= 127) length = Buffer.concat([await reader.read(3), Buffer.alloc(1)]).readInt32LE(0);
			return reader.read(length << 2);
		}
	};
	exports.AbridgedPacketCodec = AbridgedPacketCodec;
	AbridgedPacketCodec.tag = Buffer.from("ef", "hex");
	AbridgedPacketCodec.obfuscateTag = Buffer.from("efefefef", "hex");
	/**
	* This is the mode with the lowest overhead, as it will
	* only require 1 byte if the packet length is less than
	* 508 bytes (127 << 2, which is very common).
	*/
	var ConnectionTCPAbridged = class extends Connection_1.Connection {
		constructor() {
			super(...arguments);
			this.PacketCodecClass = AbridgedPacketCodec;
		}
	};
	exports.ConnectionTCPAbridged = ConnectionTCPAbridged;
}));
//#endregion
//#region node_modules/telegram/crypto/converters.js
var require_converters = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ab2i = exports.i2ab = exports.isBigEndian = void 0;
	exports.i2abLow = i2abLow;
	exports.i2abBig = i2abBig;
	exports.ab2iLow = ab2iLow;
	exports.ab2iBig = ab2iBig;
	/**
	* Uint32Array -> ArrayBuffer (low-endian os)
	*/
	function i2abLow(buf) {
		const uint8 = new Uint8Array(buf.length * 4);
		let i = 0;
		for (let j = 0; j < buf.length; j++) {
			const int = buf[j];
			uint8[i++] = int >>> 24;
			uint8[i++] = int >> 16 & 255;
			uint8[i++] = int >> 8 & 255;
			uint8[i++] = int & 255;
		}
		return uint8.buffer;
	}
	/**
	* Uint32Array -> ArrayBuffer (big-endian os)
	*/
	function i2abBig(buf) {
		return buf.buffer;
	}
	/**
	* ArrayBuffer -> Uint32Array (low-endian os)
	*/
	function ab2iLow(ab) {
		const uint8 = new Uint8Array(ab);
		const buf = new Uint32Array(uint8.length / 4);
		for (let i = 0; i < uint8.length; i += 4) buf[i / 4] = uint8[i] << 24 ^ uint8[i + 1] << 16 ^ uint8[i + 2] << 8 ^ uint8[i + 3];
		return buf;
	}
	/**
	* ArrayBuffer -> Uint32Array (big-endian os)
	*/
	function ab2iBig(ab) {
		return new Uint32Array(ab);
	}
	exports.isBigEndian = new Uint8Array(new Uint32Array([16909060]))[0] === 1;
	exports.i2ab = exports.isBigEndian ? i2abBig : i2abLow;
	exports.ab2i = exports.isBigEndian ? ab2iBig : ab2iLow;
}));
//#endregion
//#region node_modules/telegram/crypto/words.js
var require_words = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.s2i = s2i;
	exports.getWords = getWords;
	exports.xor = xor;
	function s2i(str, pos) {
		return str.charCodeAt(pos) << 24 ^ str.charCodeAt(pos + 1) << 16 ^ str.charCodeAt(pos + 2) << 8 ^ str.charCodeAt(pos + 3);
	}
	/**
	* Helper function for transforming string key to Uint32Array
	*/
	function getWords(key) {
		if (key instanceof Uint32Array) return key;
		if (typeof key === "string") {
			if (key.length % 4 !== 0) for (let i = key.length % 4; i <= 4; i++) key += "\0x00";
			const buf = new Uint32Array(key.length / 4);
			for (let i = 0; i < key.length; i += 4) buf[i / 4] = s2i(key, i);
			return buf;
		}
		if (key instanceof Uint8Array) {
			const buf = new Uint32Array(key.length / 4);
			for (let i = 0; i < key.length; i += 4) buf[i / 4] = key[i] << 24 ^ key[i + 1] << 16 ^ key[i + 2] << 8 ^ key[i + 3];
			return buf;
		}
		throw new Error("Unable to create 32-bit words");
	}
	function xor(left, right, to = left) {
		for (let i = 0; i < left.length; i++) to[i] = left[i] ^ right[i];
	}
}));
//#endregion
//#region node_modules/telegram/crypto/crypto.js
var require_crypto = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Hash = exports.CTR = exports.Counter = void 0;
	exports.createDecipheriv = createDecipheriv;
	exports.createCipheriv = createCipheriv;
	exports.randomBytes = randomBytes;
	exports.pbkdf2Sync = pbkdf2Sync;
	exports.createHash = createHash;
	var aes_1 = __importDefault((init_aes(), __toCommonJS(aes_exports)));
	var converters_1 = require_converters();
	var words_1 = require_words();
	var Counter = class {
		constructor(initialValue) {
			this._counter = Buffer.from(initialValue);
		}
		increment() {
			for (let i = 15; i >= 0; i--) if (this._counter[i] === 255) this._counter[i] = 0;
			else {
				this._counter[i]++;
				break;
			}
		}
	};
	exports.Counter = Counter;
	var CTR = class {
		constructor(key, counter) {
			if (!(counter instanceof Counter)) counter = new Counter(counter);
			this._counter = counter;
			this._remainingCounter = void 0;
			this._remainingCounterIndex = 16;
			this._aes = new aes_1.default((0, words_1.getWords)(key));
		}
		update(plainText) {
			return this.encrypt(plainText);
		}
		encrypt(plainText) {
			const encrypted = Buffer.from(plainText);
			for (let i = 0; i < encrypted.length; i++) {
				if (this._remainingCounterIndex === 16) {
					this._remainingCounter = Buffer.from((0, converters_1.i2ab)(this._aes.encrypt((0, converters_1.ab2i)(this._counter._counter))));
					this._remainingCounterIndex = 0;
					this._counter.increment();
				}
				if (this._remainingCounter) encrypted[i] ^= this._remainingCounter[this._remainingCounterIndex++];
			}
			return encrypted;
		}
	};
	exports.CTR = CTR;
	function createDecipheriv(algorithm, key, iv) {
		if (algorithm.includes("ECB")) throw new Error("Not supported");
		else return new CTR(key, iv);
	}
	function createCipheriv(algorithm, key, iv) {
		if (algorithm.includes("ECB")) throw new Error("Not supported");
		else return new CTR(key, iv);
	}
	function randomBytes(count) {
		const bytes = new Uint8Array(count);
		crypto.getRandomValues(bytes);
		return bytes;
	}
	var Hash = class {
		constructor(algorithm) {
			this.algorithm = algorithm;
		}
		update(data) {
			this.data = new Uint8Array(data);
		}
		async digest() {
			if (this.data) {
				if (this.algorithm === "sha1") return Buffer.from(await self.crypto.subtle.digest("SHA-1", this.data));
				else if (this.algorithm === "sha256") return Buffer.from(await self.crypto.subtle.digest("SHA-256", this.data));
			}
			return Buffer.alloc(0);
		}
	};
	exports.Hash = Hash;
	async function pbkdf2Sync(password, salt, iterations, ...args) {
		const passwordKey = await crypto.subtle.importKey("raw", password, { name: "PBKDF2" }, false, ["deriveBits"]);
		return Buffer.from(await crypto.subtle.deriveBits({
			name: "PBKDF2",
			hash: "SHA-512",
			salt,
			iterations
		}, passwordKey, 512));
	}
	function createHash(algorithm) {
		return new Hash(algorithm);
	}
}));
//#endregion
//#region node_modules/telegram/crypto/CTR.js
var require_CTR = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.CTR = void 0;
	var crypto = __importStar(require_crypto());
	var CTR = class {
		constructor(key, iv) {
			if (!Buffer.isBuffer(key) || !Buffer.isBuffer(iv) || iv.length !== 16) throw new Error("Key and iv need to be a buffer");
			this.cipher = crypto.createCipheriv("AES-256-CTR", key, iv);
		}
		encrypt(data) {
			return Buffer.from(this.cipher.update(data));
		}
	};
	exports.CTR = CTR;
}));
//#endregion
//#region node_modules/telegram/network/connection/TCPObfuscated.js
var require_TCPObfuscated = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPObfuscated = void 0;
	var Helpers_1 = require_Helpers();
	var Connection_1 = require_Connection();
	var TCPAbridged_1 = require_TCPAbridged();
	var CTR_1 = require_CTR();
	var ObfuscatedIO = class {
		constructor(connection) {
			this.header = void 0;
			this.connection = connection.socket;
			this._packetClass = connection.PacketCodecClass;
		}
		async initHeader() {
			const keywords = [
				Buffer.from("50567247", "hex"),
				Buffer.from("474554", "hex"),
				Buffer.from("504f5354", "hex"),
				Buffer.from("eeeeeeee", "hex")
			];
			let random;
			while (true) {
				random = (0, Helpers_1.generateRandomBytes)(64);
				if (random[0] !== 239 && !random.slice(4, 8).equals(Buffer.alloc(4))) {
					let ok = true;
					for (const key of keywords) if (key.equals(random.slice(0, 4))) {
						ok = false;
						break;
					}
					if (ok) break;
				}
			}
			random = random.toJSON().data;
			const randomReversed = Buffer.from(random.slice(8, 56)).reverse();
			const encryptKey = Buffer.from(random.slice(8, 40));
			const encryptIv = Buffer.from(random.slice(40, 56));
			const decryptKey = Buffer.from(randomReversed.slice(0, 32));
			const decryptIv = Buffer.from(randomReversed.slice(32, 48));
			const encryptor = new CTR_1.CTR(encryptKey, encryptIv);
			const decryptor = new CTR_1.CTR(decryptKey, decryptIv);
			random = Buffer.concat([
				Buffer.from(random.slice(0, 56)),
				this._packetClass.obfuscateTag,
				Buffer.from(random.slice(60))
			]);
			random = Buffer.concat([
				Buffer.from(random.slice(0, 56)),
				Buffer.from(encryptor.encrypt(random).slice(56, 64)),
				Buffer.from(random.slice(64))
			]);
			this.header = random;
			this._encrypt = encryptor;
			this._decrypt = decryptor;
		}
		async read(n) {
			const data = await this.connection.readExactly(n);
			return this._decrypt.encrypt(data);
		}
		write(data) {
			this.connection.write(this._encrypt.encrypt(data));
		}
	};
	var ConnectionTCPObfuscated = class extends Connection_1.ObfuscatedConnection {
		constructor() {
			super(...arguments);
			this.ObfuscatedIO = ObfuscatedIO;
			this.PacketCodecClass = TCPAbridged_1.AbridgedPacketCodec;
		}
	};
	exports.ConnectionTCPObfuscated = ConnectionTCPObfuscated;
}));
//#endregion
//#region node_modules/telegram/network/connection/index.js
var require_connection = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPObfuscated = exports.ConnectionTCPAbridged = exports.ConnectionTCPFull = exports.Connection = void 0;
	var Connection_1 = require_Connection();
	Object.defineProperty(exports, "Connection", {
		enumerable: true,
		get: function() {
			return Connection_1.Connection;
		}
	});
	var TCPFull_1 = require_TCPFull();
	Object.defineProperty(exports, "ConnectionTCPFull", {
		enumerable: true,
		get: function() {
			return TCPFull_1.ConnectionTCPFull;
		}
	});
	var TCPAbridged_1 = require_TCPAbridged();
	Object.defineProperty(exports, "ConnectionTCPAbridged", {
		enumerable: true,
		get: function() {
			return TCPAbridged_1.ConnectionTCPAbridged;
		}
	});
	var TCPObfuscated_1 = require_TCPObfuscated();
	Object.defineProperty(exports, "ConnectionTCPObfuscated", {
		enumerable: true,
		get: function() {
			return TCPObfuscated_1.ConnectionTCPObfuscated;
		}
	});
}));
//#endregion
//#region node_modules/telegram/sessions/Abstract.js
var require_Abstract = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Session = void 0;
	var Session = class {};
	exports.Session = Session;
}));
//#endregion
//#region node_modules/telegram/sessions/Memory.js
var require_Memory = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MemorySession = void 0;
	var Abstract_1 = require_Abstract();
	var tl_1 = require_tl();
	var big_integer_1 = __importDefault(require_BigInteger());
	var Utils_1 = require_Utils();
	var Helpers_1 = require_Helpers();
	var __1 = require_telegram();
	var MemorySession = class extends Abstract_1.Session {
		constructor() {
			super();
			this._serverAddress = void 0;
			this._dcId = 0;
			this._port = void 0;
			this._takeoutId = void 0;
			this._entities = /* @__PURE__ */ new Set();
			this._updateStates = {};
		}
		setDC(dcId, serverAddress, port) {
			this._dcId = dcId | 0;
			this._serverAddress = serverAddress;
			this._port = port;
		}
		get dcId() {
			return this._dcId;
		}
		get serverAddress() {
			return this._serverAddress;
		}
		get port() {
			return this._port;
		}
		get authKey() {
			return this._authKey;
		}
		set authKey(value) {
			this._authKey = value;
		}
		get takeoutId() {
			return this._takeoutId;
		}
		set takeoutId(value) {
			this._takeoutId = value;
		}
		getAuthKey(dcId) {
			if (dcId && dcId !== this.dcId) return;
			return this.authKey;
		}
		setAuthKey(authKey, dcId) {
			if (dcId && dcId !== this.dcId) return;
			this.authKey = authKey;
		}
		close() {}
		save() {}
		async load() {}
		delete() {}
		_entityValuesToRow(id, hash, username, phone, name) {
			return [
				id,
				hash,
				username,
				phone,
				name
			];
		}
		_entityToRow(e) {
			if (!(e.classType === "constructor")) return;
			let p;
			let markedId;
			try {
				p = (0, Utils_1.getInputPeer)(e, false);
				markedId = (0, Utils_1.getPeerId)(p);
			} catch (e) {
				return;
			}
			let pHash;
			if (p instanceof tl_1.Api.InputPeerUser || p instanceof tl_1.Api.InputPeerChannel) pHash = p.accessHash;
			else if (p instanceof tl_1.Api.InputPeerChat) pHash = big_integer_1.default.zero;
			else return;
			let username = e.username;
			if (username) username = username.toLowerCase();
			const phone = e.phone;
			const name = (0, Utils_1.getDisplayName)(e);
			return this._entityValuesToRow(markedId, pHash, username, phone, name);
		}
		_entitiesToRows(tlo) {
			let entities = [];
			if (!(tlo.classType === "constructor") && (0, Helpers_1.isArrayLike)(tlo)) entities = tlo;
			else if (typeof tlo === "object") {
				if ("user" in tlo) entities.push(tlo.user);
				if ("chat" in tlo) entities.push(tlo.chat);
				if ("channel" in tlo) entities.push(tlo.channel);
				if ("chats" in tlo && (0, Helpers_1.isArrayLike)(tlo.chats)) entities = entities.concat(tlo.chats);
				if ("users" in tlo && (0, Helpers_1.isArrayLike)(tlo.users)) entities = entities.concat(tlo.users);
			}
			const rows = [];
			for (const e of entities) {
				const row = this._entityToRow(e);
				if (row) rows.push(row);
			}
			return rows;
		}
		processEntities(tlo) {
			const entitiesSet = this._entitiesToRows(tlo);
			for (const e of entitiesSet) this._entities.add(e);
		}
		getEntityRowsByPhone(phone) {
			for (const e of this._entities) if (e[3] === phone) return [e[0], e[1]];
		}
		getEntityRowsByUsername(username) {
			for (const e of this._entities) if (e[2] === username) return [e[0], e[1]];
		}
		getEntityRowsByName(name) {
			for (const e of this._entities) if (e[4] === name) return [e[0], e[1]];
		}
		getEntityRowsById(id, exact = true) {
			if (exact) {
				for (const e of this._entities) if (e[0] === id) return [e[0], e[1]];
			} else {
				const ids = [
					__1.utils.getPeerId(new tl_1.Api.PeerUser({ userId: (0, Helpers_1.returnBigInt)(id) })),
					__1.utils.getPeerId(new tl_1.Api.PeerChat({ chatId: (0, Helpers_1.returnBigInt)(id) })),
					__1.utils.getPeerId(new tl_1.Api.PeerChannel({ channelId: (0, Helpers_1.returnBigInt)(id) }))
				];
				for (const e of this._entities) if (ids.includes(e[0])) return [e[0], e[1]];
			}
		}
		getInputEntity(key) {
			let exact;
			if (typeof key === "object" && !big_integer_1.default.isInstance(key) && key.SUBCLASS_OF_ID) {
				if (key.SUBCLASS_OF_ID == 3374092470 || key.SUBCLASS_OF_ID == 3865689926 || key.SUBCLASS_OF_ID == 1089602301) return key;
				return __1.utils.getInputPeer(key);
			} else if (typeof key === "object") {
				key = __1.utils.getPeerId(key);
				exact = true;
			} else exact = false;
			if (big_integer_1.default.isInstance(key) || typeof key == "bigint" || typeof key == "number") key = key.toString();
			let result = void 0;
			if (typeof key === "string") {
				const phone = __1.utils.parsePhone(key);
				if (phone) result = this.getEntityRowsByPhone(phone);
				else {
					const { username, isInvite } = __1.utils.parseUsername(key);
					if (username && !isInvite) result = this.getEntityRowsByUsername(username);
				}
				if (!result) {
					const id = __1.utils.parseID(key);
					if (id) result = this.getEntityRowsById(id, exact);
				}
				if (!result) result = this.getEntityRowsByName(key);
			}
			if (result) {
				let entityId = result[0];
				const entityHash = (0, big_integer_1.default)(result[1]);
				const resolved = __1.utils.resolveId((0, Helpers_1.returnBigInt)(entityId));
				entityId = resolved[0];
				const kind = resolved[1];
				if (kind === tl_1.Api.PeerUser) return new tl_1.Api.InputPeerUser({
					userId: entityId,
					accessHash: entityHash
				});
				else if (kind === tl_1.Api.PeerChat) return new tl_1.Api.InputPeerChat({ chatId: entityId });
				else if (kind === tl_1.Api.PeerChannel) return new tl_1.Api.InputPeerChannel({
					channelId: entityId,
					accessHash: entityHash
				});
			} else throw new Error("Could not find input entity with key " + key);
			throw new Error("Could not find input entity with key " + key);
		}
	};
	exports.MemorySession = MemorySession;
}));
//#endregion
//#region node_modules/telegram/crypto/AuthKey.js
var require_AuthKey = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AuthKey = void 0;
	var Helpers_1 = require_Helpers();
	var extensions_1 = require_extensions();
	var Helpers_2 = require_Helpers();
	exports.AuthKey = class AuthKey {
		constructor(value, hash) {
			if (!hash || !value) return;
			this._key = value;
			this._hash = hash;
			const reader = new extensions_1.BinaryReader(hash);
			this.auxHash = reader.readLong(false);
			reader.read(4);
			this.keyId = reader.readLong(false);
		}
		async setKey(value) {
			if (!value) {
				this._key = this.auxHash = this.keyId = this._hash = void 0;
				return;
			}
			if (value instanceof AuthKey) {
				this._key = value._key;
				this.auxHash = value.auxHash;
				this.keyId = value.keyId;
				this._hash = value._hash;
				return;
			}
			this._key = value;
			this._hash = await (0, Helpers_1.sha1)(this._key);
			const reader = new extensions_1.BinaryReader(this._hash);
			this.auxHash = reader.readLong(false);
			reader.read(4);
			this.keyId = reader.readLong(false);
		}
		async waitForKey() {
			while (!this.keyId) await (0, Helpers_2.sleep)(20);
		}
		getKey() {
			return this._key;
		}
		/**
		* Calculates the new nonce hash based on the current class fields' values
		* @param newNonce
		* @param number
		* @returns {bigInt.BigInteger}
		*/
		async calcNewNonceHash(newNonce, number) {
			if (this.auxHash) {
				const nonce = (0, Helpers_1.toSignedLittleBuffer)(newNonce, 32);
				const n = Buffer.alloc(1);
				n.writeUInt8(number, 0);
				const data = Buffer.concat([nonce, Buffer.concat([n, (0, Helpers_1.readBufferFromBigInt)(this.auxHash, 8, true)])]);
				const shaData = (await (0, Helpers_1.sha1)(data)).slice(4, 20);
				return (0, Helpers_1.readBigIntFromBuffer)(shaData, true, true);
			}
			throw new Error("Auth key not set");
		}
		equals(other) {
			var _a;
			return other instanceof this.constructor && this._key && Buffer.isBuffer(other.getKey()) && ((_a = other.getKey()) === null || _a === void 0 ? void 0 : _a.equals(this._key));
		}
	};
}));
//#endregion
//#region node_modules/telegram/sessions/StringSession.js
var require_StringSession = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.StringSession = void 0;
	var Memory_1 = require_Memory();
	var extensions_1 = require_extensions();
	var AuthKey_1 = require_AuthKey();
	var CURRENT_VERSION = "1";
	exports.StringSession = class StringSession extends Memory_1.MemorySession {
		/**
		* This session file can be easily saved and loaded as a string. According
		* to the initial design, it contains only the data that is necessary for
		* successful connection and authentication, so takeout ID is not stored.
		
		* It is thought to be used where you don't want to create any on-disk
		* files but would still like to be able to save and load existing sessions
		* by other means.
		
		* You can use custom `encode` and `decode` functions, if present:
		
		* `encode` definition must be ``function encode(value: Buffer) -> string:``.
		* `decode` definition must be ``function decode(value: string) -> Buffer:``.
		* @param session {string|null}
		*/
		constructor(session) {
			super();
			if (session) {
				if (session[0] !== CURRENT_VERSION) throw new Error("Not a valid string");
				session = session.slice(1);
				const r = StringSession.decode(session);
				const reader = new extensions_1.BinaryReader(r);
				this._dcId = reader.read(1).readUInt8(0);
				if (session.length == 352) {
					const ip_v4 = reader.read(4);
					this._serverAddress = ip_v4[0].toString() + "." + ip_v4[1].toString() + "." + ip_v4[2].toString() + "." + ip_v4[3].toString();
				} else {
					const serverAddressLen = reader.read(2).readInt16BE(0);
					if (serverAddressLen > 100) {
						reader.offset -= 2;
						this._serverAddress = reader.read(16).toString("hex").match(/.{1,4}/g).map((val) => val.replace(/^0+/, "")).join(":").replace(/0000\:/g, ":").replace(/:{2,}/g, "::");
					} else this._serverAddress = reader.read(serverAddressLen).toString();
				}
				this._port = reader.read(2).readInt16BE(0);
				this._key = reader.read(-1);
			}
		}
		/**
		* @param x {Buffer}
		* @returns {string}
		*/
		static encode(x) {
			return x.toString("base64");
		}
		/**
		* @param x {string}
		* @returns {Buffer}
		*/
		static decode(x) {
			return Buffer.from(x, "base64");
		}
		async load() {
			if (this._key) {
				this._authKey = new AuthKey_1.AuthKey();
				await this._authKey.setKey(this._key);
			}
		}
		save() {
			if (!this.authKey || !this.serverAddress || !this.port) return "";
			const key = this.authKey.getKey();
			if (!key) return "";
			const dcBuffer = Buffer.from([this.dcId]);
			const addressBuffer = Buffer.from(this.serverAddress);
			const addressLengthBuffer = Buffer.alloc(2);
			addressLengthBuffer.writeInt16BE(addressBuffer.length, 0);
			const portBuffer = Buffer.alloc(2);
			portBuffer.writeInt16BE(this.port, 0);
			return CURRENT_VERSION + StringSession.encode(Buffer.concat([
				dcBuffer,
				addressLengthBuffer,
				addressBuffer,
				portBuffer,
				key
			]));
		}
	};
}));
//#endregion
//#region node_modules/telegram/sessions/localStorage.js
var require_localStorage = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.LocalStorage = void 0;
	exports.LocalStorage = require_LocalStorage().LocalStorage;
}));
//#endregion
//#region node_modules/telegram/sessions/StoreSession.js
var require_StoreSession = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.StoreSession = void 0;
	var Memory_1 = require_Memory();
	var store2_1 = __importDefault(require_store2());
	var AuthKey_1 = require_AuthKey();
	var StoreSession = class extends Memory_1.MemorySession {
		constructor(sessionName, divider = ":") {
			super();
			if (sessionName === "session") throw new Error("Session name can't be 'session'. Please use a different name.");
			if (typeof localStorage === "undefined" || localStorage === null) {
				const LocalStorage = require_localStorage().LocalStorage;
				this.store = store2_1.default.area(sessionName, new LocalStorage("./" + sessionName));
			} else this.store = store2_1.default.area(sessionName, localStorage);
			if (divider == void 0) divider = ":";
			this.sessionName = sessionName + divider;
		}
		async load() {
			let authKey = this.store.get(this.sessionName + "authKey");
			if (authKey && typeof authKey === "object") {
				this._authKey = new AuthKey_1.AuthKey();
				if ("data" in authKey) authKey = Buffer.from(authKey.data);
				await this._authKey.setKey(authKey);
			}
			const dcId = this.store.get(this.sessionName + "dcId");
			if (dcId) this._dcId = dcId;
			const port = this.store.get(this.sessionName + "port");
			if (port) this._port = port;
			const serverAddress = this.store.get(this.sessionName + "serverAddress");
			if (serverAddress) this._serverAddress = serverAddress;
		}
		setDC(dcId, serverAddress, port) {
			this.store.set(this.sessionName + "dcId", dcId);
			this.store.set(this.sessionName + "port", port);
			this.store.set(this.sessionName + "serverAddress", serverAddress);
			super.setDC(dcId, serverAddress, port);
		}
		set authKey(value) {
			this._authKey = value;
			this.store.set(this.sessionName + "authKey", value === null || value === void 0 ? void 0 : value.getKey());
		}
		get authKey() {
			return this._authKey;
		}
		processEntities(tlo) {
			const rows = this._entitiesToRows(tlo);
			if (!rows) return;
			for (const row of rows) {
				row.push((/* @__PURE__ */ new Date()).getTime().toString());
				this.store.set(this.sessionName + row[0], row);
			}
		}
		getEntityRowsById(id, exact = true) {
			return this.store.get(this.sessionName + id.toString());
		}
	};
	exports.StoreSession = StoreSession;
}));
//#endregion
//#region node_modules/telegram/sessions/index.js
var require_sessions = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Session = exports.StoreSession = exports.StringSession = exports.MemorySession = void 0;
	var Memory_1 = require_Memory();
	Object.defineProperty(exports, "MemorySession", {
		enumerable: true,
		get: function() {
			return Memory_1.MemorySession;
		}
	});
	var StringSession_1 = require_StringSession();
	Object.defineProperty(exports, "StringSession", {
		enumerable: true,
		get: function() {
			return StringSession_1.StringSession;
		}
	});
	var StoreSession_1 = require_StoreSession();
	Object.defineProperty(exports, "StoreSession", {
		enumerable: true,
		get: function() {
			return StoreSession_1.StoreSession;
		}
	});
	var Abstract_1 = require_Abstract();
	Object.defineProperty(exports, "Session", {
		enumerable: true,
		get: function() {
			return Abstract_1.Session;
		}
	});
}));
//#endregion
//#region node_modules/telegram/client/os.js
var require_os = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = __importStar(__require("os"));
}));
//#endregion
//#region node_modules/telegram/entityCache.js
var require_entityCache = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EntityCache = void 0;
	var Utils_1 = require_Utils();
	var Helpers_1 = require_Helpers();
	var tl_1 = require_tl();
	var big_integer_1 = __importDefault(require_BigInteger());
	var EntityCache = class {
		constructor() {
			this.cacheMap = /* @__PURE__ */ new Map();
		}
		add(entities) {
			const temp = [];
			if (!(0, Helpers_1.isArrayLike)(entities)) {
				if (entities != void 0) {
					if (typeof entities == "object") {
						if ("chats" in entities) temp.push(...entities.chats);
						if ("users" in entities) temp.push(...entities.users);
						if ("user" in entities) temp.push(entities.user);
					}
				}
				if (temp.length) entities = temp;
				else return;
			}
			for (const entity of entities) try {
				const pid = (0, Utils_1.getPeerId)(entity);
				if (!this.cacheMap.has(pid.toString())) this.cacheMap.set(pid.toString(), (0, Utils_1.getInputPeer)(entity));
			} catch (e) {}
		}
		get(item) {
			if (item == void 0) throw new Error("No cached entity for the given key");
			item = (0, Helpers_1.returnBigInt)(item);
			if (item.lesser(big_integer_1.default.zero)) {
				let res;
				try {
					res = this.cacheMap.get((0, Utils_1.getPeerId)(item).toString());
					if (res) return res;
				} catch (e) {
					throw new Error("Invalid key will not have entity");
				}
			}
			for (const cls of [
				tl_1.Api.PeerUser,
				tl_1.Api.PeerChat,
				tl_1.Api.PeerChannel
			]) {
				const result = this.cacheMap.get((0, Utils_1.getPeerId)(new cls({
					userId: item,
					chatId: item,
					channelId: item
				})).toString());
				if (result) return result;
			}
			throw new Error("No cached entity for the given key");
		}
	};
	exports.EntityCache = EntityCache;
}));
//#endregion
//#region node_modules/telegram/crypto/IGE.js
var require_IGE = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.IGE = void 0;
	var Helpers = require_Helpers();
	var { IGE: aes_ige } = (init_aes(), __toCommonJS(aes_exports));
	var IGENEW = class {
		constructor(key, iv) {
			this.ige = new aes_ige(key, iv);
		}
		/**
		* Decrypts the given text in 16-bytes blocks by using the given key and 32-bytes initialization vector
		* @param cipherText {Buffer}
		* @returns {Buffer}
		*/
		decryptIge(cipherText) {
			return Helpers.convertToLittle(this.ige.decrypt(cipherText));
		}
		/**
		* Encrypts the given text in 16-bytes blocks by using the given key and 32-bytes initialization vector
		* @param plainText {Buffer}
		* @returns {Buffer}
		*/
		encryptIge(plainText) {
			const padding = plainText.length % 16;
			if (padding) plainText = Buffer.concat([plainText, Helpers.generateRandomBytes(16 - padding)]);
			return Helpers.convertToLittle(this.ige.encrypt(plainText));
		}
	};
	exports.IGE = IGENEW;
}));
//#endregion
//#region node_modules/telegram/network/MTProtoState.js
var require_MTProtoState = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MTProtoState = void 0;
	var big_integer_1 = __importDefault(require_BigInteger());
	var __1 = require_telegram();
	var tl_1 = require_tl();
	var Helpers_1 = require_Helpers();
	var core_1 = require_core();
	var extensions_1 = require_extensions();
	var IGE_1 = require_IGE();
	var errors_1 = require_errors();
	var MTProtoState = class {
		/**
		*
		`telethon.network.mtprotosender.MTProtoSender` needs to hold a state
		in order to be able to encrypt and decrypt incoming/outgoing messages,
		as well as generating the message IDs. Instances of this class hold
		together all the required information.
		
		It doesn't make sense to use `telethon.sessions.abstract.Session` for
		the sender because the sender should *not* be concerned about storing
		this information to disk, as one may create as many senders as they
		desire to any other data center, or some CDN. Using the same session
		for all these is not a good idea as each need their own authkey, and
		the concept of "copying" sessions with the unnecessary entities or
		updates state for these connections doesn't make sense.
		
		While it would be possible to have a `MTProtoPlainState` that does no
		encryption so that it was usable through the `MTProtoLayer` and thus
		avoid the need for a `MTProtoPlainSender`, the `MTProtoLayer` is more
		focused to efficiency and this state is also more advanced (since it
		supports gzipping and invoking after other message IDs). There are too
		many methods that would be needed to make it convenient to use for the
		authentication process, at which point the `MTProtoPlainSender` is better
		* @param authKey
		* @param loggers
		* @param securityChecks
		*/
		constructor(authKey, loggers, securityChecks = true) {
			this.authKey = authKey;
			this._log = loggers;
			this.timeOffset = 0;
			this.salt = big_integer_1.default.zero;
			this._sequence = 0;
			this.id = this._lastMsgId = big_integer_1.default.zero;
			this.msgIds = [];
			this.securityChecks = securityChecks;
			this.reset();
		}
		/**
		* Resets the state
		*/
		reset() {
			this.id = __1.helpers.generateRandomLong(true);
			this._sequence = 0;
			this._lastMsgId = big_integer_1.default.zero;
			this.msgIds = [];
		}
		/**
		* Updates the message ID to a new one,
		* used when the time offset changed.
		* @param message
		*/
		updateMessageId(message) {
			message.msgId = this._getNewMsgId();
		}
		/**
		* Calculate the key based on Telegram guidelines, specifying whether it's the client or not
		* @param authKey
		* @param msgKey
		* @param client
		* @returns {{iv: Buffer, key: Buffer}}
		*/
		async _calcKey(authKey, msgKey, client) {
			const x = client ? 0 : 8;
			const [sha256a, sha256b] = await Promise.all([(0, Helpers_1.sha256)(Buffer.concat([msgKey, authKey.slice(x, x + 36)])), (0, Helpers_1.sha256)(Buffer.concat([authKey.slice(x + 40, x + 76), msgKey]))]);
			return {
				key: Buffer.concat([
					sha256a.slice(0, 8),
					sha256b.slice(8, 24),
					sha256a.slice(24, 32)
				]),
				iv: Buffer.concat([
					sha256b.slice(0, 8),
					sha256a.slice(8, 24),
					sha256b.slice(24, 32)
				])
			};
		}
		/**
		* Writes a message containing the given data into buffer.
		* Returns the message id.
		* @param buffer
		* @param data
		* @param contentRelated
		* @param afterId
		*/
		async writeDataAsMessage(buffer, data, contentRelated, afterId) {
			const msgId = this._getNewMsgId();
			const seqNo = this._getSeqNo(contentRelated);
			let body;
			if (!afterId) body = await core_1.GZIPPacked.gzipIfSmaller(contentRelated, data);
			else body = await core_1.GZIPPacked.gzipIfSmaller(contentRelated, new tl_1.Api.InvokeAfterMsg({
				msgId: afterId,
				query: { getBytes() {
					return data;
				} }
			}).getBytes());
			const s = Buffer.alloc(4);
			s.writeInt32LE(seqNo, 0);
			const b = Buffer.alloc(4);
			b.writeInt32LE(body.length, 0);
			const m = (0, Helpers_1.toSignedLittleBuffer)(msgId, 8);
			buffer.write(Buffer.concat([
				m,
				s,
				b
			]));
			buffer.write(body);
			return msgId;
		}
		/**
		* Encrypts the given message data using the current authorization key
		* following MTProto 2.0 guidelines core.telegram.org/mtproto/description.
		* @param data
		*/
		async encryptMessageData(data) {
			if (!this.authKey) throw new Error("Auth key unset");
			await this.authKey.waitForKey();
			const authKey = this.authKey.getKey();
			if (!authKey) throw new Error("Auth key unset");
			if (!this.salt || !this.id || !authKey || !this.authKey.keyId) throw new Error("Unset params");
			const s = (0, Helpers_1.toSignedLittleBuffer)(this.salt, 8);
			const i = (0, Helpers_1.toSignedLittleBuffer)(this.id, 8);
			data = Buffer.concat([Buffer.concat([s, i]), data]);
			const padding = __1.helpers.generateRandomBytes(__1.helpers.mod(-(data.length + 12), 16) + 12);
			const msgKey = (await (0, Helpers_1.sha256)(Buffer.concat([
				authKey.slice(88, 120),
				data,
				padding
			]))).slice(8, 24);
			const { iv, key } = await this._calcKey(authKey, msgKey, true);
			const keyId = __1.helpers.readBufferFromBigInt(this.authKey.keyId, 8);
			return Buffer.concat([
				keyId,
				msgKey,
				new IGE_1.IGE(key, iv).encryptIge(Buffer.concat([data, padding]))
			]);
		}
		/**
		* Inverse of `encrypt_message_data` for incoming server messages.
		* @param body
		*/
		async decryptMessageData(body) {
			if (!this.authKey) throw new Error("Auth key unset");
			if (body.length < 8) throw new errors_1.InvalidBufferError(body);
			const keyId = __1.helpers.readBigIntFromBuffer(body.slice(0, 8));
			if (!this.authKey.keyId || keyId.neq(this.authKey.keyId)) throw new errors_1.SecurityError("Server replied with an invalid auth key");
			const authKey = this.authKey.getKey();
			if (!authKey) throw new errors_1.SecurityError("Unset AuthKey");
			const msgKey = body.slice(8, 24);
			const { iv, key } = await this._calcKey(authKey, msgKey, false);
			body = new IGE_1.IGE(key, iv).decryptIge(body.slice(24));
			const ourKey = await (0, Helpers_1.sha256)(Buffer.concat([authKey.slice(96, 128), body]));
			if (!msgKey.equals(ourKey.slice(8, 24))) throw new errors_1.SecurityError("Received msg_key doesn't match with expected one");
			const reader = new extensions_1.BinaryReader(body);
			reader.readLong();
			if (reader.readLong().neq(this.id)) {}
			const remoteMsgId = reader.readLong();
			if (this.msgIds.includes(remoteMsgId.toString()) && this.securityChecks) throw new errors_1.SecurityError("Duplicate msgIds");
			if (this.msgIds.length > 500) this.msgIds.shift();
			this.msgIds.push(remoteMsgId.toString());
			const remoteSequence = reader.readInt();
			reader.readInt();
			const obj = reader.tgReadObject();
			return new core_1.TLMessage(remoteMsgId, remoteSequence, obj);
		}
		/**
		* Generates a new unique message ID based on the current
		* time (in ms) since epoch, applying a known time offset.
		* @private
		*/
		_getNewMsgId() {
			const now = (/* @__PURE__ */ new Date()).getTime() / 1e3 + this.timeOffset;
			const nanoseconds = Math.floor((now - Math.floor(now)) * 1e9);
			let newMsgId = (0, big_integer_1.default)(Math.floor(now)).shiftLeft((0, big_integer_1.default)(32)).or((0, big_integer_1.default)(nanoseconds).shiftLeft((0, big_integer_1.default)(2)));
			if (this._lastMsgId.greaterOrEquals(newMsgId)) newMsgId = this._lastMsgId.add((0, big_integer_1.default)(4));
			this._lastMsgId = newMsgId;
			return newMsgId;
		}
		/**
		* Updates the time offset to the correct
		* one given a known valid message ID.
		* @param correctMsgId {BigInteger}
		*/
		updateTimeOffset(correctMsgId) {
			const bad = this._getNewMsgId();
			const old = this.timeOffset;
			const now = Math.floor((/* @__PURE__ */ new Date()).getTime() / 1e3);
			const correct = correctMsgId.shiftRight((0, big_integer_1.default)(32)).toJSNumber();
			this.timeOffset = correct - now;
			if (this.timeOffset !== old) {
				this._lastMsgId = big_integer_1.default.zero;
				this._log.debug(`Updated time offset (old offset ${old}, bad ${bad}, good ${correctMsgId}, new ${this.timeOffset})`);
			}
			return this.timeOffset;
		}
		/**
		* Generates the next sequence number depending on whether
		* it should be for a content-related query or not.
		* @param contentRelated
		* @private
		*/
		_getSeqNo(contentRelated) {
			if (contentRelated) {
				const result = this._sequence * 2 + 1;
				this._sequence += 1;
				return result;
			} else return this._sequence * 2;
		}
	};
	exports.MTProtoState = MTProtoState;
}));
//#endregion
//#region node_modules/telegram/network/MTProtoPlainSender.js
var require_MTProtoPlainSender = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MTProtoPlainSender = void 0;
	/**
	*  This module contains the class used to communicate with Telegram's servers
	*  in plain text, when no authorization key has been created yet.
	*/
	var big_integer_1 = __importDefault(require_BigInteger());
	var MTProtoState_1 = require_MTProtoState();
	var Helpers_1 = require_Helpers();
	var errors_1 = require_errors();
	var extensions_1 = require_extensions();
	/**
	* MTProto Mobile Protocol plain sender (https://core.telegram.org/mtproto/description#unencrypted-messages)
	*/
	var MTProtoPlainSender = class {
		/**
		* Initializes the MTProto plain sender.
		* @param connection connection: the Connection to be used.
		* @param loggers
		*/
		constructor(connection, loggers) {
			this._state = new MTProtoState_1.MTProtoState(void 0, loggers);
			this._connection = connection;
		}
		/**
		* Sends and receives the result for the given request.
		* @param request
		*/
		async send(request) {
			let body = request.getBytes();
			let msgId = this._state._getNewMsgId();
			const m = (0, Helpers_1.toSignedLittleBuffer)(msgId, 8);
			const b = Buffer.alloc(4);
			b.writeInt32LE(body.length, 0);
			const res = Buffer.concat([Buffer.concat([
				Buffer.alloc(8),
				m,
				b
			]), body]);
			await this._connection.send(res);
			body = await this._connection.recv();
			if (body.length < 8) throw new errors_1.InvalidBufferError(body);
			const reader = new extensions_1.BinaryReader(body);
			if (reader.readLong().neq((0, big_integer_1.default)(0))) throw new Error("Bad authKeyId");
			msgId = reader.readLong();
			if (msgId.eq((0, big_integer_1.default)(0))) throw new Error("Bad msgId");
			if (reader.readInt() <= 0) throw new Error("Bad length");
			/**
			* We could read length bytes and use those in a new reader to read
			* the next TLObject without including the padding, but since the
			* reader isn't used for anything else after this, it's unnecessary.
			*/
			return reader.tgReadObject();
		}
	};
	exports.MTProtoPlainSender = MTProtoPlainSender;
}));
//#endregion
//#region node_modules/telegram/crypto/Factorizator.js
var require_Factorizator = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Factorizator = void 0;
	var big_integer_1 = __importDefault(require_BigInteger());
	var Helpers_1 = require_Helpers();
	exports.Factorizator = class Factorizator {
		/**
		* Calculates the greatest common divisor
		* @param a {BigInteger}
		* @param b {BigInteger}
		* @returns {BigInteger}
		*/
		static gcd(a, b) {
			while (b.neq(big_integer_1.default.zero)) {
				const temp = b;
				b = a.remainder(b);
				a = temp;
			}
			return a;
		}
		/**
		* Factorizes the given number and returns both the divisor and the number divided by the divisor
		* @param pq {BigInteger}
		* @returns {{p: *, q: *}}
		*/
		static factorize(pq) {
			if (pq.remainder(2).equals(big_integer_1.default.zero)) return {
				p: (0, big_integer_1.default)(2),
				q: pq.divide((0, big_integer_1.default)(2))
			};
			let y = big_integer_1.default.randBetween((0, big_integer_1.default)(1), pq.minus(1));
			const c = big_integer_1.default.randBetween((0, big_integer_1.default)(1), pq.minus(1));
			const m = big_integer_1.default.randBetween((0, big_integer_1.default)(1), pq.minus(1));
			let g = big_integer_1.default.one;
			let r = big_integer_1.default.one;
			let q = big_integer_1.default.one;
			let x = big_integer_1.default.zero;
			let ys = big_integer_1.default.zero;
			let k;
			while (g.eq(big_integer_1.default.one)) {
				x = y;
				for (let i = 0; (0, big_integer_1.default)(i).lesser(r); i++) y = (0, Helpers_1.modExp)(y, (0, big_integer_1.default)(2), pq).add(c).remainder(pq);
				k = big_integer_1.default.zero;
				while (k.lesser(r) && g.eq(big_integer_1.default.one)) {
					ys = y;
					const condition = big_integer_1.default.min(m, r.minus(k));
					for (let i = 0; (0, big_integer_1.default)(i).lesser(condition); i++) {
						y = (0, Helpers_1.modExp)(y, (0, big_integer_1.default)(2), pq).add(c).remainder(pq);
						q = q.multiply(x.minus(y).abs()).remainder(pq);
					}
					g = Factorizator.gcd(q, pq);
					k = k.add(m);
				}
				r = r.multiply(2);
			}
			if (g.eq(pq)) while (true) {
				ys = (0, Helpers_1.modExp)(ys, (0, big_integer_1.default)(2), pq).add(c).remainder(pq);
				g = Factorizator.gcd(x.minus(ys).abs(), pq);
				if (g.greater(1)) break;
			}
			const p = g;
			q = pq.divide(g);
			return p < q ? {
				p,
				q
			} : {
				p: q,
				q: p
			};
		}
	};
}));
//#endregion
//#region node_modules/telegram/crypto/RSA.js
var require_RSA = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __rest = exports && exports.__rest || function(s, e) {
		var t = {};
		for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
		if (s != null && typeof Object.getOwnPropertySymbols === "function") {
			for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
		}
		return t;
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports._serverKeys = void 0;
	exports.encrypt = encrypt;
	var big_integer_1 = __importDefault(require_BigInteger());
	var Helpers_1 = require_Helpers();
	var PUBLIC_KEYS = [{
		fingerprint: (0, big_integer_1.default)("-3414540481677951611"),
		n: (0, big_integer_1.default)("29379598170669337022986177149456128565388431120058863768162556424047512191330847455146576344487764408661701890505066208632169112269581063774293102577308490531282748465986139880977280302242772832972539403531316010870401287642763009136156734339538042419388722777357134487746169093539093850251243897188928735903389451772730245253062963384108812842079887538976360465290946139638691491496062099570836476454855996319192747663615955633778034897140982517446405334423701359108810182097749467210509584293428076654573384828809574217079944388301239431309115013843331317877374435868468779972014486325557807783825502498215169806323"),
		e: 65537
	}, {
		fingerprint: (0, big_integer_1.default)("-5595554452916591101"),
		n: (0, big_integer_1.default)("25342889448840415564971689590713473206898847759084779052582026594546022463853940585885215951168491965708222649399180603818074200620463776135424884632162512403163793083921641631564740959529419359595852941166848940585952337613333022396096584117954892216031229237302943701877588456738335398602461675225081791820393153757504952636234951323237820036543581047826906120927972487366805292115792231423684261262330394324750785450942589751755390156647751460719351439969059949569615302809050721500330239005077889855323917509948255722081644689442127297605422579707142646660768825302832201908302295573257427896031830742328565032949"),
		e: 65537
	}];
	exports._serverKeys = /* @__PURE__ */ new Map();
	PUBLIC_KEYS.forEach((_a) => {
		var { fingerprint } = _a, keyInfo = __rest(_a, ["fingerprint"]);
		exports._serverKeys.set(fingerprint.toString(), keyInfo);
	});
	/**
	* Encrypts the given data known the fingerprint to be used
	* in the way Telegram requires us to do so (sha1(data) + data + padding)
	
	* @param fingerprint the fingerprint of the RSA key.
	* @param data the data to be encrypted.
	* @returns {Buffer|*|undefined} the cipher text, or undefined if no key matching this fingerprint is found.
	*/
	async function encrypt(fingerprint, data) {
		const key = exports._serverKeys.get(fingerprint.toString());
		if (!key) return;
		const rand = (0, Helpers_1.generateRandomBytes)(235 - data.length);
		const toEncrypt = Buffer.concat([
			await (0, Helpers_1.sha1)(data),
			data,
			rand
		]);
		const payload = (0, Helpers_1.readBigIntFromBuffer)(toEncrypt, false);
		const encrypted = (0, Helpers_1.modExp)(payload, (0, big_integer_1.default)(key.e), key.n);
		return (0, Helpers_1.readBufferFromBigInt)(encrypted, 256, false);
	}
}));
//#endregion
//#region node_modules/telegram/network/Authenticator.js
var require_Authenticator = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.doAuthentication = doAuthentication;
	var Helpers_1 = require_Helpers();
	var tl_1 = require_tl();
	var errors_1 = require_errors();
	var Factorizator_1 = require_Factorizator();
	var RSA_1 = require_RSA();
	var IGE_1 = require_IGE();
	var big_integer_1 = __importDefault(require_BigInteger());
	var extensions_1 = require_extensions();
	var AuthKey_1 = require_AuthKey();
	var RETRIES = 20;
	async function doAuthentication(sender, log) {
		let bytes = (0, Helpers_1.generateRandomBytes)(16);
		const nonce = (0, Helpers_1.readBigIntFromBuffer)(bytes, false, true);
		const resPQ = await sender.send(new tl_1.Api.ReqPqMulti({ nonce }));
		log.debug("Starting authKey generation step 1");
		if (!(resPQ instanceof tl_1.Api.ResPQ)) throw new errors_1.SecurityError(`Step 1 answer was ${resPQ}`);
		if (resPQ.nonce.neq(nonce)) throw new errors_1.SecurityError("Step 1 invalid nonce from server");
		const pq = (0, Helpers_1.readBigIntFromBuffer)(resPQ.pq, false, true);
		log.debug("Finished authKey generation step 1");
		const { p, q } = Factorizator_1.Factorizator.factorize(pq);
		const pBuffer = (0, Helpers_1.getByteArray)(p);
		const qBuffer = (0, Helpers_1.getByteArray)(q);
		bytes = (0, Helpers_1.generateRandomBytes)(32);
		const newNonce = (0, Helpers_1.readBigIntFromBuffer)(bytes, true, true);
		const pqInnerData = new tl_1.Api.PQInnerData({
			pq: (0, Helpers_1.getByteArray)(pq),
			p: pBuffer,
			q: qBuffer,
			nonce: resPQ.nonce,
			serverNonce: resPQ.serverNonce,
			newNonce
		}).getBytes();
		if (pqInnerData.length > 144) throw new errors_1.SecurityError("Step 1 invalid nonce from server");
		let targetFingerprint;
		let targetKey;
		for (const fingerprint of resPQ.serverPublicKeyFingerprints) {
			targetKey = RSA_1._serverKeys.get(fingerprint.toString());
			if (targetKey !== void 0) {
				targetFingerprint = fingerprint;
				break;
			}
		}
		if (targetFingerprint === void 0 || targetKey === void 0) throw new errors_1.SecurityError("Step 2 could not find a valid key for fingerprints");
		const padding = (0, Helpers_1.generateRandomBytes)(192 - pqInnerData.length);
		const dataWithPadding = Buffer.concat([pqInnerData, padding]);
		const dataPadReversed = Buffer.from(dataWithPadding).reverse();
		let encryptedData;
		for (let i = 0; i < RETRIES; i++) {
			const tempKey = (0, Helpers_1.generateRandomBytes)(32);
			const shaDigestKeyWithData = await (0, Helpers_1.sha256)(Buffer.concat([tempKey, dataWithPadding]));
			const dataWithHash = Buffer.concat([dataPadReversed, shaDigestKeyWithData]);
			const aesEncrypted = new IGE_1.IGE(tempKey, Buffer.alloc(32)).encryptIge(dataWithHash);
			const tempKeyXor = (0, Helpers_1.bufferXor)(tempKey, await (0, Helpers_1.sha256)(aesEncrypted));
			const keyAesEncrypted = Buffer.concat([tempKeyXor, aesEncrypted]);
			const keyAesEncryptedInt = (0, Helpers_1.readBigIntFromBuffer)(keyAesEncrypted, false, false);
			if (keyAesEncryptedInt.greaterOrEquals(targetKey.n)) {
				log.debug("Aes key greater than RSA. retrying");
				continue;
			}
			const encryptedDataBuffer = (0, Helpers_1.modExp)(keyAesEncryptedInt, (0, big_integer_1.default)(targetKey.e), targetKey.n);
			encryptedData = (0, Helpers_1.readBufferFromBigInt)(encryptedDataBuffer, 256, false, false);
			break;
		}
		if (encryptedData === void 0) throw new errors_1.SecurityError("Step 2 could create a secure encrypted key");
		log.debug("Step 2 : Generated a secure aes encrypted data");
		const serverDhParams = await sender.send(new tl_1.Api.ReqDHParams({
			nonce: resPQ.nonce,
			serverNonce: resPQ.serverNonce,
			p: pBuffer,
			q: qBuffer,
			publicKeyFingerprint: targetFingerprint,
			encryptedData
		}));
		if (!(serverDhParams instanceof tl_1.Api.ServerDHParamsOk || serverDhParams instanceof tl_1.Api.ServerDHParamsFail)) throw new Error(`Step 2.1 answer was ${serverDhParams}`);
		if (serverDhParams.nonce.neq(resPQ.nonce)) throw new errors_1.SecurityError("Step 2 invalid nonce from server");
		if (serverDhParams.serverNonce.neq(resPQ.serverNonce)) throw new errors_1.SecurityError("Step 2 invalid server nonce from server");
		if (serverDhParams instanceof tl_1.Api.ServerDHParamsFail) {
			const sh = await (0, Helpers_1.sha1)((0, Helpers_1.toSignedLittleBuffer)(newNonce, 32).slice(4, 20));
			const nnh = (0, Helpers_1.readBigIntFromBuffer)(sh, true, true);
			if (serverDhParams.newNonceHash.neq(nnh)) throw new errors_1.SecurityError("Step 2 invalid DH fail nonce from server");
		}
		if (!(serverDhParams instanceof tl_1.Api.ServerDHParamsOk)) throw new Error(`Step 2.2 answer was ${serverDhParams}`);
		log.debug("Finished authKey generation step 2");
		log.debug("Starting authKey generation step 3");
		const { key, iv } = await (0, Helpers_1.generateKeyDataFromNonce)(resPQ.serverNonce, newNonce);
		if (serverDhParams.encryptedAnswer.length % 16 !== 0) throw new errors_1.SecurityError("Step 3 AES block size mismatch");
		const ige = new IGE_1.IGE(key, iv);
		const plainTextAnswer = ige.decryptIge(serverDhParams.encryptedAnswer);
		const reader = new extensions_1.BinaryReader(plainTextAnswer);
		reader.read(20);
		const serverDhInner = reader.tgReadObject();
		if (!(serverDhInner instanceof tl_1.Api.ServerDHInnerData)) throw new Error(`Step 3 answer was ${serverDhInner}`);
		if (serverDhInner.nonce.neq(resPQ.nonce)) throw new errors_1.SecurityError("Step 3 Invalid nonce in encrypted answer");
		if (serverDhInner.serverNonce.neq(resPQ.serverNonce)) throw new errors_1.SecurityError("Step 3 Invalid server nonce in encrypted answer");
		const dhPrime = (0, Helpers_1.readBigIntFromBuffer)(serverDhInner.dhPrime, false, false);
		const ga = (0, Helpers_1.readBigIntFromBuffer)(serverDhInner.gA, false, false);
		const timeOffset = serverDhInner.serverTime - Math.floor((/* @__PURE__ */ new Date()).getTime() / 1e3);
		const b = (0, Helpers_1.readBigIntFromBuffer)((0, Helpers_1.generateRandomBytes)(256), false, false);
		const gb = (0, Helpers_1.modExp)((0, big_integer_1.default)(serverDhInner.g), b, dhPrime);
		const gab = (0, Helpers_1.modExp)(ga, b, dhPrime);
		const clientDhInner = new tl_1.Api.ClientDHInnerData({
			nonce: resPQ.nonce,
			serverNonce: resPQ.serverNonce,
			retryId: big_integer_1.default.zero,
			gB: (0, Helpers_1.getByteArray)(gb, false)
		}).getBytes();
		const clientDdhInnerHashed = Buffer.concat([await (0, Helpers_1.sha1)(clientDhInner), clientDhInner]);
		const clientDhEncrypted = ige.encryptIge(clientDdhInnerHashed);
		const dhGen = await sender.send(new tl_1.Api.SetClientDHParams({
			nonce: resPQ.nonce,
			serverNonce: resPQ.serverNonce,
			encryptedData: clientDhEncrypted
		}));
		const nonceTypes = [
			tl_1.Api.DhGenOk,
			tl_1.Api.DhGenRetry,
			tl_1.Api.DhGenFail
		];
		const nonceTypesString = [
			"DhGenOk",
			"DhGenRetry",
			"DhGenFail"
		];
		if (!(dhGen instanceof nonceTypes[0] || dhGen instanceof nonceTypes[1] || dhGen instanceof nonceTypes[2])) throw new Error(`Step 3.1 answer was ${dhGen}`);
		const { name } = dhGen.constructor;
		if (dhGen.nonce.neq(resPQ.nonce)) throw new errors_1.SecurityError(`Step 3 invalid ${name} nonce from server`);
		if (dhGen.serverNonce.neq(resPQ.serverNonce)) throw new errors_1.SecurityError(`Step 3 invalid ${name} server nonce from server`);
		const authKey = new AuthKey_1.AuthKey();
		await authKey.setKey((0, Helpers_1.getByteArray)(gab));
		const nonceNumber = 1 + nonceTypesString.indexOf(dhGen.className);
		const newNonceHash = await authKey.calcNewNonceHash(newNonce, nonceNumber);
		if (dhGen[`newNonceHash${nonceNumber}`].neq(newNonceHash)) throw new errors_1.SecurityError("Step 3 invalid new nonce hash");
		if (!(dhGen instanceof tl_1.Api.DhGenOk)) throw new Error(`Step 3.2 answer was ${dhGen}`);
		log.debug("Finished authKey generation step 3");
		return {
			authKey,
			timeOffset
		};
	}
}));
//#endregion
//#region node_modules/telegram/extensions/PendingState.js
var require_PendingState = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PendingState = void 0;
	var PendingState = class {
		constructor() {
			this._pending = /* @__PURE__ */ new Map();
		}
		set(msgId, state) {
			this._pending.set(msgId.toString(), state);
		}
		get(msgId) {
			return this._pending.get(msgId.toString());
		}
		getAndDelete(msgId) {
			const state = this.get(msgId);
			this.delete(msgId);
			return state;
		}
		values() {
			return Array.from(this._pending.values());
		}
		delete(msgId) {
			this._pending.delete(msgId.toString());
		}
		clear() {
			this._pending.clear();
		}
	};
	exports.PendingState = PendingState;
}));
//#endregion
//#region node_modules/telegram/network/MTProtoSender.js
var require_MTProtoSender = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.MTProtoSender = void 0;
	/**
	* MTProto Mobile Protocol sender
	* (https://core.telegram.org/mtproto/description)
	* This class is responsible for wrapping requests into `TLMessage`'s,
	* sending them over the network and receiving them in a safe manner.
	*
	* Automatic reconnection due to temporary network issues is a concern
	* for this class as well, including retry of messages that could not
	* be sent successfully.
	*
	* A new authorization key will be generated on connection if no other
	* key exists yet.
	*/
	var AuthKey_1 = require_AuthKey();
	var MTProtoState_1 = require_MTProtoState();
	var extensions_1 = require_extensions();
	var core_1 = require_core();
	var tl_1 = require_tl();
	var big_integer_1 = __importDefault(require_BigInteger());
	var Helpers_1 = require_Helpers();
	var RequestState_1 = require_RequestState();
	var Authenticator_1 = require_Authenticator();
	var MTProtoPlainSender_1 = require_MTProtoPlainSender();
	var errors_1 = require_errors();
	var _1 = require_network();
	var Logger_1 = require_Logger();
	var async_mutex_1 = require_lib$1();
	var PendingState_1 = require_PendingState();
	var MsgsAck = tl_1.Api.MsgsAck;
	var MTProtoSender = class MTProtoSender {
		/**
		* @param authKey
		* @param opts
		*/
		constructor(authKey, opts) {
			this._exportedSenderPromises = /* @__PURE__ */ new Map();
			const args = Object.assign(Object.assign({}, MTProtoSender.DEFAULT_OPTIONS), opts);
			this._finishedConnecting = false;
			this._cancelSend = false;
			this._connection = void 0;
			this._log = args.logger;
			this._dcId = args.dcId;
			this._retries = args.retries;
			this._currentRetries = 0;
			this._reconnectRetries = args.reconnectRetries;
			this._delay = args.delay;
			this._autoReconnect = args.autoReconnect;
			this._connectTimeout = args.connectTimeout;
			this._authKeyCallback = args.authKeyCallback;
			this._updateCallback = args.updateCallback;
			this._autoReconnectCallback = args.autoReconnectCallback;
			this._isMainSender = args.isMainSender;
			this._senderCallback = args.senderCallback;
			this._client = args.client;
			this._onConnectionBreak = args.onConnectionBreak;
			this._securityChecks = args.securityChecks;
			this._connectMutex = new async_mutex_1.Mutex();
			this._exportedSenderPromises = args._exportedSenderPromises;
			/**
			* whether we disconnected ourself or telegram did it.
			*/
			this.userDisconnected = false;
			/**
			* If a disconnection happens for any other reason and it
			* was *not* user action then the pending messages won't
			* be cleared but on explicit user disconnection all the
			* pending futures should be cancelled.
			*/
			this.isConnecting = false;
			this._authenticated = false;
			this._userConnected = false;
			this.isReconnecting = false;
			this._reconnecting = false;
			this._disconnected = true;
			/**
			* We need to join the loops upon disconnection
			*/
			this._sendLoopHandle = null;
			this._recvLoopHandle = null;
			/**
			* Preserving the references of the AuthKey and state is important
			*/
			this.authKey = authKey || new AuthKey_1.AuthKey();
			this._state = new MTProtoState_1.MTProtoState(this.authKey, this._log, this._securityChecks);
			/**
			* Outgoing messages are put in a queue and sent in a batch.
			* Note that here we're also storing their ``_RequestState``.
			*/
			this._sendQueue = new extensions_1.MessagePacker(this._state, this._log);
			/**
			* Sent states are remembered until a response is received.
			*/
			this._pendingState = new PendingState_1.PendingState();
			/**
			* Responses must be acknowledged, and we can also batch these.
			*/
			this._pendingAck = /* @__PURE__ */ new Set();
			/**
			* Similar to pending_messages but only for the last acknowledges.
			* These can't go in pending_messages because no acknowledge for them
			* is received, but we may still need to resend their state on bad salts.
			*/
			this._lastAcks = [];
			/**
			* Jump table from response ID to method that handles it
			*/
			this._handlers = {
				[core_1.RPCResult.CONSTRUCTOR_ID.toString()]: this._handleRPCResult.bind(this),
				[core_1.MessageContainer.CONSTRUCTOR_ID.toString()]: this._handleContainer.bind(this),
				[core_1.GZIPPacked.CONSTRUCTOR_ID.toString()]: this._handleGzipPacked.bind(this),
				[tl_1.Api.Pong.CONSTRUCTOR_ID.toString()]: this._handlePong.bind(this),
				[tl_1.Api.BadServerSalt.CONSTRUCTOR_ID.toString()]: this._handleBadServerSalt.bind(this),
				[tl_1.Api.BadMsgNotification.CONSTRUCTOR_ID.toString()]: this._handleBadNotification.bind(this),
				[tl_1.Api.MsgDetailedInfo.CONSTRUCTOR_ID.toString()]: this._handleDetailedInfo.bind(this),
				[tl_1.Api.MsgNewDetailedInfo.CONSTRUCTOR_ID.toString()]: this._handleNewDetailedInfo.bind(this),
				[tl_1.Api.NewSessionCreated.CONSTRUCTOR_ID.toString()]: this._handleNewSessionCreated.bind(this),
				[tl_1.Api.MsgsAck.CONSTRUCTOR_ID.toString()]: this._handleAck.bind(this),
				[tl_1.Api.FutureSalts.CONSTRUCTOR_ID.toString()]: this._handleFutureSalts.bind(this),
				[tl_1.Api.MsgsStateReq.CONSTRUCTOR_ID.toString()]: this._handleStateForgotten.bind(this),
				[tl_1.Api.MsgResendReq.CONSTRUCTOR_ID.toString()]: this._handleStateForgotten.bind(this),
				[tl_1.Api.MsgsAllInfo.CONSTRUCTOR_ID.toString()]: this._handleMsgAll.bind(this)
			};
		}
		set dcId(dcId) {
			this._dcId = dcId;
		}
		get dcId() {
			return this._dcId;
		}
		/**
		* Connects to the specified given connection using the given auth key.
		*/
		async connect(connection, force) {
			this.userDisconnected = false;
			if (this._userConnected && !force) {
				this._log.info("User is already connected!");
				return false;
			}
			this.isConnecting = true;
			this._connection = connection;
			this._finishedConnecting = false;
			for (let attempt = 0; attempt < this._retries; attempt++) try {
				await this._connect();
				if (this._updateCallback) this._updateCallback(this._client, new _1.UpdateConnectionState(_1.UpdateConnectionState.connected));
				this._finishedConnecting = true;
				break;
			} catch (err) {
				if (this._updateCallback && attempt === 0) this._updateCallback(this._client, new _1.UpdateConnectionState(_1.UpdateConnectionState.disconnected));
				this._log.error(`WebSocket connection failed attempt: ${attempt + 1}`);
				if (this._client._errorHandler) await this._client._errorHandler(err);
				if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.error(err);
				await (0, Helpers_1.sleep)(this._delay);
			}
			this.isConnecting = false;
			return this._finishedConnecting;
		}
		isConnected() {
			return this._userConnected;
		}
		_transportConnected() {
			return !this._reconnecting && this._connection && this._connection._connected;
		}
		/**
		* Cleanly disconnects the instance from the network, cancels
		* all pending requests, and closes the send and receive loops.
		*/
		async disconnect() {
			this.userDisconnected = true;
			this._log.warn("Disconnecting...");
			await this._disconnect();
		}
		/**
		*
		This method enqueues the given request to be sent. Its send
		state will be saved until a response arrives, and a ``Future``
		that will be resolved when the response arrives will be returned:
		
		.. code-block:: javascript
		
		async def method():
		# Sending (enqueued for the send loop)
		future = sender.send(request)
		# Receiving (waits for the receive loop to read the result)
		result = await future
		
		Designed like this because Telegram may send the response at
		any point, and it can send other items while one waits for it.
		Once the response for this future arrives, it is set with the
		received result, quite similar to how a ``receive()`` call
		would otherwise work.
		
		Since the receiving part is "built in" the future, it's
		impossible to await receive a result that was never sent.
		* @param request
		* @returns {RequestState}
		*/
		send(request) {
			const state = new RequestState_1.RequestState(request);
			this._log.debug(`Send ${request.className}`);
			this._sendQueue.append(state);
			return state.promise;
		}
		addStateToQueue(state) {
			this._sendQueue.append(state);
		}
		/**
		* Performs the actual connection, retrying, generating the
		* authorization key if necessary, and starting the send and
		* receive loops.
		* @returns {Promise<void>}
		* @private
		*/
		async _connect() {
			const connection = this._connection;
			if (!connection.isConnected()) {
				this._log.info("Connecting to {0}...".replace("{0}", connection.toString()));
				await connection.connect();
				this._log.debug("Connection success!");
			}
			if (!this.authKey.getKey()) {
				const plain = new MTProtoPlainSender_1.MTProtoPlainSender(connection, this._log);
				this._log.debug("New auth_key attempt ...");
				const res = await (0, Authenticator_1.doAuthentication)(plain, this._log);
				this._log.debug("Generated new auth_key successfully");
				await this.authKey.setKey(res.authKey);
				this._state.timeOffset = res.timeOffset;
				if (this._authKeyCallback) await this._authKeyCallback(this.authKey, this._dcId);
			} else {
				this._authenticated = true;
				this._log.debug("Already have an auth key ...");
			}
			this._userConnected = true;
			this.isReconnecting = false;
			if (!this._sendLoopHandle) {
				this._log.debug("Starting send loop");
				this._sendLoopHandle = this._sendLoop();
			}
			if (!this._recvLoopHandle) {
				this._log.debug("Starting receive loop");
				this._recvLoopHandle = this._recvLoop();
			}
			this._log.info("Connection to %s complete!".replace("%s", connection.toString()));
		}
		async _disconnect() {
			const connection = this._connection;
			if (this._updateCallback) this._updateCallback(this._client, new _1.UpdateConnectionState(_1.UpdateConnectionState.disconnected));
			if (connection === void 0) {
				this._log.info("Not disconnecting (already have no connection)");
				return;
			}
			this._log.info("Disconnecting from %s...".replace("%s", connection.toString()));
			this._userConnected = false;
			this._log.debug("Closing current connection...");
			await connection.disconnect();
		}
		_cancelLoops() {
			this._cancelSend = true;
			this.cancellableRecvLoopPromise.cancel();
		}
		/**
		* This loop is responsible for popping items off the send
		* queue, encrypting them, and sending them over the network.
		* Besides `connect`, only this method ever sends data.
		* @returns {Promise<void>}
		* @private
		*/
		async _sendLoop() {
			this._sendQueue.prepend(this._pendingState.values());
			this._pendingState.clear();
			while (this._userConnected && !this.isReconnecting) {
				const appendAcks = () => {
					if (this._pendingAck.size) {
						const ack = new RequestState_1.RequestState(new MsgsAck({ msgIds: Array(...this._pendingAck) }));
						this._sendQueue.append(ack);
						this._lastAcks.push(ack);
						if (this._lastAcks.length >= 10) this._lastAcks.shift();
						this._pendingAck.clear();
					}
				};
				appendAcks();
				this._log.debug(`Waiting for messages to send... ${this.isReconnecting}`);
				await this._sendQueue.wait();
				appendAcks();
				const res = await this._sendQueue.get();
				this._log.debug(`Got ${res === null || res === void 0 ? void 0 : res.batch.length} message(s) to send`);
				if (this.isReconnecting) {
					this._log.debug("Reconnecting");
					this._sendLoopHandle = void 0;
					return;
				}
				if (!res) continue;
				let { data } = res;
				const { batch } = res;
				this._log.debug(`Encrypting ${batch.length} message(s) in ${data.length} bytes for sending`);
				this._log.debug(`Sending   ${batch.map((m) => m.request.className)}`);
				data = await this._state.encryptMessageData(data);
				for (const state of batch) if (!Array.isArray(state)) {
					if (state.request.classType === "request") this._pendingState.set(state.msgId, state);
				} else for (const s of state) if (s.request.classType === "request") this._pendingState.set(s.msgId, s);
				try {
					await this._connection.send(data);
				} catch (e) {
					/** when the server disconnects us we want to reconnect */
					if (!this.userDisconnected) {
						this._log.debug(`Connection closed while sending data ${e}`);
						if (this._log.canSend(Logger_1.LogLevel.DEBUG)) console.error(e);
						this.reconnect();
					}
					this._sendLoopHandle = void 0;
					return;
				}
				this._log.debug("Encrypted messages put in a queue to be sent");
			}
			this._sendLoopHandle = void 0;
		}
		async _recvLoop() {
			let body;
			let message;
			while (this._userConnected && !this.isReconnecting) {
				this._log.debug("Receiving items from the network...");
				try {
					body = await this._connection.recv();
				} catch (e) {
					if (this._currentRetries > this._reconnectRetries) {
						for (const state of this._pendingState.values()) state.reject("Maximum reconnection retries reached. Aborting!");
						this.userDisconnected = true;
						return;
					}
					/** when the server disconnects us we want to reconnect */
					if (!this.userDisconnected) {
						this._log.warn("Connection closed while receiving data");
						if (this._log.canSend(Logger_1.LogLevel.WARN)) console.error(e);
						this.reconnect();
					}
					this._recvLoopHandle = void 0;
					return;
				}
				try {
					message = await this._state.decryptMessageData(body);
				} catch (e) {
					this._log.debug(`Error while receiving items from the network ${e}`);
					if (e instanceof errors_1.TypeNotFoundError) {
						this._log.info(`Type ${e.invalidConstructorId} not found, remaining data ${e.remaining}`);
						continue;
					} else if (e instanceof errors_1.SecurityError) {
						this._log.warn(`Security error while unpacking a received message: ${e}`);
						continue;
					} else if (e instanceof errors_1.InvalidBufferError) {
						if (e.code === 404) this._handleBadAuthKey();
						else {
							this._log.warn(`Invalid buffer ${e.code} for dc ${this._dcId}`);
							this.reconnect();
						}
						this._recvLoopHandle = void 0;
						return;
					} else {
						this._log.error("Unhandled error while receiving data");
						if (this._client._errorHandler) await this._client._errorHandler(e);
						if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.log(e);
						this.reconnect();
						this._recvLoopHandle = void 0;
						return;
					}
				}
				try {
					await this._processMessage(message);
				} catch (e) {
					if (e instanceof errors_1.RPCError) {
						if (e.message === "AUTH_KEY_UNREGISTERED" || e.message === "SESSION_REVOKED") this._handleBadAuthKey(true);
					} else {
						this._log.error("Unhandled error while receiving data");
						if (this._client._errorHandler) await this._client._errorHandler(e);
						if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.log(e);
					}
				}
				this._currentRetries = 0;
			}
			this._recvLoopHandle = void 0;
		}
		_handleBadAuthKey(shouldSkipForMain = false) {
			if (shouldSkipForMain && this._isMainSender) return;
			this._log.warn(`Broken authorization key for dc ${this._dcId}, resetting...`);
			if (this._isMainSender && this._updateCallback) this._updateCallback(this._client, new _1.UpdateConnectionState(_1.UpdateConnectionState.broken));
			else if (!this._isMainSender && this._onConnectionBreak) this._onConnectionBreak(this._dcId);
		}
		/**
		* Adds the given message to the list of messages that must be
		* acknowledged and dispatches control to different ``_handle_*``
		* method based on its type.
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _processMessage(message) {
			this._pendingAck.add(message.msgId);
			message.obj = await message.obj;
			let handler = this._handlers[message.obj.CONSTRUCTOR_ID.toString()];
			if (!handler) handler = this._handleUpdate.bind(this);
			await handler(message);
		}
		/**
		* Pops the states known to match the given ID from pending messages.
		* This method should be used when the response isn't specific.
		* @param msgId
		* @returns {*[]}
		* @private
		*/
		_popStates(msgId) {
			var _a;
			const state = this._pendingState.getAndDelete(msgId);
			if (state) return [state];
			const toPop = [];
			for (const pendingState of this._pendingState.values()) if ((_a = pendingState.containerId) === null || _a === void 0 ? void 0 : _a.equals(msgId)) toPop.push(pendingState.msgId);
			if (toPop.length) {
				const temp = [];
				for (const x of toPop) temp.push(this._pendingState.getAndDelete(x));
				return temp;
			}
			for (const ack of this._lastAcks) if (ack.msgId === msgId) return [ack];
			return [];
		}
		/**
		* Handles the result for Remote Procedure Calls:
		* rpc_result#f35c6d01 req_msg_id:long result:bytes = RpcResult;
		* This is where the future results for sent requests are set.
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		_handleRPCResult(message) {
			const result = message.obj;
			const state = this._pendingState.getAndDelete(result.reqMsgId);
			this._log.debug(`Handling RPC result for message ${result.reqMsgId}`);
			if (!state) {
				try {
					if (!(new extensions_1.BinaryReader(result.body).tgReadObject() instanceof tl_1.Api.upload.File)) throw new errors_1.TypeNotFoundError(0, Buffer.alloc(0));
				} catch (e) {
					if (e instanceof errors_1.TypeNotFoundError) {
						this._log.info(`Received response without parent request: ${result.body}`);
						return;
					}
					throw e;
				}
				return;
			}
			if (result.error) {
				const error = (0, errors_1.RPCMessageToError)(result.error, state.request);
				this._sendQueue.append(new RequestState_1.RequestState(new MsgsAck({ msgIds: [state.msgId] })));
				state.reject(error);
				throw error;
			} else try {
				const reader = new extensions_1.BinaryReader(result.body);
				const read = state.request.readResult(reader);
				this._log.debug(`Handling RPC result ${read === null || read === void 0 ? void 0 : read.className}`);
				state.resolve(read);
			} catch (err) {
				state.reject(err);
				throw err;
			}
		}
		/**
		* Processes the inner messages of a container with many of them:
		* msg_container#73f1f8dc messages:vector<%Message> = MessageContainer;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleContainer(message) {
			this._log.debug("Handling container");
			for (const innerMessage of message.obj.messages) await this._processMessage(innerMessage);
		}
		/**
		* Unpacks the data from a gzipped object and processes it:
		* gzip_packed#3072cfa1 packed_data:bytes = Object;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleGzipPacked(message) {
			this._log.debug("Handling gzipped data");
			message.obj = new extensions_1.BinaryReader(message.obj.data).tgReadObject();
			await this._processMessage(message);
		}
		async _handleUpdate(message) {
			if (message.obj.SUBCLASS_OF_ID !== 2331323052) {
				this._log.warn(`Note: ${message.obj.className} is not an update, not dispatching it`);
				return;
			}
			this._log.debug("Handling update " + message.obj.className);
			if (this._updateCallback) this._updateCallback(this._client, message.obj);
		}
		/**
		* Handles pong results, which don't come inside a ``RPCResult``
		* but are still sent through a request:
		* pong#347773c5 msg_id:long ping_id:long = Pong;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handlePong(message) {
			const pong = message.obj;
			this._log.debug(`Handling pong for message ${pong.msgId}`);
			const state = this._pendingState.get(pong.msgId.toString());
			this._pendingState.delete(pong.msgId.toString());
			if (state) state.resolve(pong);
		}
		/**
		* Corrects the currently used server salt to use the right value
		* before enqueuing the rejected message to be re-sent:
		* bad_server_salt#edab447b bad_msg_id:long bad_msg_seqno:int
		* error_code:int new_server_salt:long = BadMsgNotification;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleBadServerSalt(message) {
			const badSalt = message.obj;
			this._log.debug(`Handling bad salt for message ${badSalt.badMsgId}`);
			this._state.salt = badSalt.newServerSalt;
			const states = this._popStates(badSalt.badMsgId);
			this._sendQueue.extend(states);
			this._log.debug(`${states.length} message(s) will be resent`);
		}
		/**
		* Adjusts the current state to be correct based on the
		* received bad message notification whenever possible:
		* bad_msg_notification#a7eff811 bad_msg_id:long bad_msg_seqno:int
		* error_code:int = BadMsgNotification;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleBadNotification(message) {
			const badMsg = message.obj;
			const states = this._popStates(badMsg.badMsgId);
			this._log.debug(`Handling bad msg ${JSON.stringify(badMsg)}`);
			if ([16, 17].includes(badMsg.errorCode)) {
				const to = this._state.updateTimeOffset((0, big_integer_1.default)(message.msgId));
				this._log.info(`System clock is wrong, set time offset to ${to}s`);
			} else if (badMsg.errorCode === 32) this._state._sequence += 64;
			else if (badMsg.errorCode === 33) this._state._sequence -= 16;
			else {
				for (const state of states) state.reject(new errors_1.BadMessageError(state.request, badMsg.errorCode));
				return;
			}
			this._sendQueue.extend(states);
			this._log.debug(`${states.length} messages will be resent due to bad msg`);
		}
		/**
		* Updates the current status with the received detailed information:
		* msg_detailed_info#276d3ec6 msg_id:long answer_msg_id:long
		* bytes:int status:int = MsgDetailedInfo;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleDetailedInfo(message) {
			const msgId = message.obj.answerMsgId;
			this._log.debug(`Handling detailed info for message ${msgId}`);
			this._pendingAck.add(msgId);
		}
		/**
		* Updates the current status with the received detailed information:
		* msg_new_detailed_info#809db6df answer_msg_id:long
		* bytes:int status:int = MsgDetailedInfo;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleNewDetailedInfo(message) {
			const msgId = message.obj.answerMsgId;
			this._log.debug(`Handling new detailed info for message ${msgId}`);
			this._pendingAck.add(msgId);
		}
		/**
		* Updates the current status with the received session information:
		* new_session_created#9ec20908 first_msg_id:long unique_id:long
		* server_salt:long = NewSession;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleNewSessionCreated(message) {
			this._log.debug("Handling new session created");
			this._state.salt = message.obj.serverSalt;
		}
		/**
		* Handles a server acknowledge about our messages. Normally these can be ignored
		*/
		_handleAck() {}
		/**
		* Handles future salt results, which don't come inside a
		* ``rpc_result`` but are still sent through a request:
		*     future_salts#ae500895 req_msg_id:long now:int
		*     salts:vector<future_salt> = FutureSalts;
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleFutureSalts(message) {
			this._log.debug(`Handling future salts for message ${message.msgId}`);
			const state = this._pendingState.getAndDelete(message.msgId);
			if (state) state.resolve(message.obj);
		}
		/**
		* Handles both :tl:`MsgsStateReq` and :tl:`MsgResendReq` by
		* enqueuing a :tl:`MsgsStateInfo` to be sent at a later point.
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleStateForgotten(message) {
			this._sendQueue.append(new RequestState_1.RequestState(new tl_1.Api.MsgsStateInfo({
				reqMsgId: message.msgId,
				info: String.fromCharCode(1).repeat(message.obj.msgIds)
			})));
		}
		/**
		* Handles :tl:`MsgsAllInfo` by doing nothing (yet).
		* @param message
		* @returns {Promise<void>}
		* @private
		*/
		async _handleMsgAll(message) {}
		reconnect() {
			if (this._userConnected && !this.isReconnecting) {
				this.isReconnecting = true;
				this._currentRetries++;
				if (this._isMainSender) {
					this._log.debug("Reconnecting all senders");
					for (const promise of this._exportedSenderPromises.values()) promise.then((sender) => {
						if (sender && !sender._isMainSender) sender.reconnect();
					}).catch((error) => {
						this._log.warn("Error getting sender to reconnect to");
					});
				}
				(0, Helpers_1.sleep)(1e3).then(() => {
					this._log.info("Started reconnecting");
					this._reconnect();
				});
			}
		}
		async _reconnect() {
			try {
				this._log.warn("[Reconnect] Closing current connection...");
				await this._disconnect();
			} catch (err) {
				this._log.warn("Error happened while disconnecting");
				if (this._client._errorHandler) await this._client._errorHandler(err);
				if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.error(err);
			}
			this._log.debug(`Adding ${this._sendQueue._pendingStates.length} old request to resend`);
			for (let i = 0; i < this._sendQueue._pendingStates.length; i++) if (this._sendQueue._pendingStates[i].msgId != void 0) this._pendingState.set(this._sendQueue._pendingStates[i].msgId, this._sendQueue._pendingStates[i]);
			this._sendQueue.clear();
			this._state.reset();
			const connection = this._connection;
			const newConnection = new connection.constructor({
				ip: connection._ip,
				port: connection._port,
				dcId: connection._dcId,
				loggers: connection._log,
				proxy: connection._proxy,
				testServers: connection._testServers,
				socket: this._client.networkSocket
			});
			await this.connect(newConnection, true);
			this.isReconnecting = false;
			this._sendQueue.prepend(this._pendingState.values());
			this._pendingState.clear();
			if (this._autoReconnectCallback) await this._autoReconnectCallback();
		}
	};
	exports.MTProtoSender = MTProtoSender;
	MTProtoSender.DEFAULT_OPTIONS = {
		logger: null,
		reconnectRetries: Infinity,
		retries: Infinity,
		delay: 2e3,
		autoReconnect: true,
		connectTimeout: null,
		authKeyCallback: null,
		updateCallback: null,
		autoReconnectCallback: null,
		isMainSender: null,
		senderCallback: null,
		onConnectionBreak: void 0,
		securityChecks: true
	};
}));
//#endregion
//#region node_modules/telegram/network/index.js
var require_network = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPObfuscated = exports.ConnectionTCPAbridged = exports.ConnectionTCPFull = exports.Connection = exports.UpdateConnectionState = exports.MTProtoSender = exports.doAuthentication = exports.MTProtoPlainSender = void 0;
	var MTProtoPlainSender_1 = require_MTProtoPlainSender();
	Object.defineProperty(exports, "MTProtoPlainSender", {
		enumerable: true,
		get: function() {
			return MTProtoPlainSender_1.MTProtoPlainSender;
		}
	});
	var Authenticator_1 = require_Authenticator();
	Object.defineProperty(exports, "doAuthentication", {
		enumerable: true,
		get: function() {
			return Authenticator_1.doAuthentication;
		}
	});
	var MTProtoSender_1 = require_MTProtoSender();
	Object.defineProperty(exports, "MTProtoSender", {
		enumerable: true,
		get: function() {
			return MTProtoSender_1.MTProtoSender;
		}
	});
	var UpdateConnectionState = class {
		constructor(state) {
			this.state = state;
		}
	};
	exports.UpdateConnectionState = UpdateConnectionState;
	UpdateConnectionState.disconnected = -1;
	UpdateConnectionState.connected = 1;
	UpdateConnectionState.broken = 0;
	var connection_1 = require_connection();
	Object.defineProperty(exports, "Connection", {
		enumerable: true,
		get: function() {
			return connection_1.Connection;
		}
	});
	Object.defineProperty(exports, "ConnectionTCPFull", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionTCPFull;
		}
	});
	Object.defineProperty(exports, "ConnectionTCPAbridged", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionTCPAbridged;
		}
	});
	Object.defineProperty(exports, "ConnectionTCPObfuscated", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionTCPObfuscated;
		}
	});
}));
//#endregion
//#region node_modules/telegram/network/connection/TCPMTProxy.js
var require_TCPMTProxy = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionTCPMTProxyAbridged = exports.TCPMTProxy = void 0;
	var Connection_1 = require_Connection();
	var TCPAbridged_1 = require_TCPAbridged();
	var Helpers_1 = require_Helpers();
	var CTR_1 = require_CTR();
	var MTProxyIO = class {
		constructor(connection) {
			this.header = void 0;
			this.connection = connection.socket;
			this._packetClass = connection.PacketCodecClass;
			this._secret = connection._secret;
			this._dcId = connection._dcId;
		}
		async initHeader() {
			let secret = this._secret;
			secret = secret.length == 17 && secret[0] == 221 ? secret.slice(1) : secret;
			if (secret.length != 16) throw new Error("MTProxy secret must be a hex-string representing 16 bytes");
			const keywords = [
				Buffer.from("50567247", "hex"),
				Buffer.from("474554", "hex"),
				Buffer.from("504f5354", "hex"),
				Buffer.from("eeeeeeee", "hex")
			];
			let random;
			while (true) {
				random = (0, Helpers_1.generateRandomBytes)(64);
				if (random[0] !== 239 && !random.slice(4, 8).equals(Buffer.alloc(4))) {
					let ok = true;
					for (const key of keywords) if (key.equals(random.slice(0, 4))) {
						ok = false;
						break;
					}
					if (ok) break;
				}
			}
			random = random.toJSON().data;
			const randomReversed = Buffer.from(random.slice(8, 56)).reverse();
			const encryptKey = await (0, Helpers_1.sha256)(Buffer.concat([Buffer.from(random.slice(8, 40)), secret]));
			const encryptIv = Buffer.from(random.slice(40, 56));
			const decryptKey = await (0, Helpers_1.sha256)(Buffer.concat([Buffer.from(randomReversed.slice(0, 32)), secret]));
			const decryptIv = Buffer.from(randomReversed.slice(32, 48));
			const encryptor = new CTR_1.CTR(encryptKey, encryptIv);
			const decryptor = new CTR_1.CTR(decryptKey, decryptIv);
			random = Buffer.concat([
				Buffer.from(random.slice(0, 56)),
				this._packetClass.obfuscateTag,
				Buffer.from(random.slice(60))
			]);
			const dcIdBytes = Buffer.alloc(2);
			dcIdBytes.writeInt8(this._dcId, 0);
			random = Buffer.concat([
				Buffer.from(random.slice(0, 60)),
				dcIdBytes,
				Buffer.from(random.slice(62))
			]);
			random = Buffer.concat([
				Buffer.from(random.slice(0, 56)),
				Buffer.from(encryptor.encrypt(random).slice(56, 64)),
				Buffer.from(random.slice(64))
			]);
			this.header = random;
			this._encrypt = encryptor;
			this._decrypt = decryptor;
		}
		async read(n) {
			const data = await this.connection.readExactly(n);
			return this._decrypt.encrypt(data);
		}
		write(data) {
			this.connection.write(this._encrypt.encrypt(data));
		}
	};
	var TCPMTProxy = class extends Connection_1.ObfuscatedConnection {
		constructor({ ip, port, dcId, loggers, proxy, socket, testServers }) {
			super({
				ip: proxy.ip,
				port: proxy.port,
				dcId,
				loggers,
				socket,
				proxy,
				testServers
			});
			this.ObfuscatedIO = MTProxyIO;
			if (!("MTProxy" in proxy)) throw new Error("This connection only supports MPTProxies");
			if (!proxy.secret) throw new Error("You need to provide the secret for the MTProxy");
			if (proxy.secret && proxy.secret.match(/^[0-9a-f]+$/i)) this._secret = Buffer.from(proxy.secret, "hex");
			else this._secret = Buffer.from(proxy.secret, "base64");
		}
	};
	exports.TCPMTProxy = TCPMTProxy;
	var ConnectionTCPMTProxyAbridged = class extends TCPMTProxy {
		constructor() {
			super(...arguments);
			this.PacketCodecClass = TCPAbridged_1.AbridgedPacketCodec;
		}
	};
	exports.ConnectionTCPMTProxyAbridged = ConnectionTCPMTProxyAbridged;
}));
//#endregion
//#region node_modules/telegram/client/telegramBaseClient.js
var require_telegramBaseClient = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TelegramBaseClient = void 0;
	var __1 = require_telegram();
	var Helpers_1 = require_Helpers();
	var connection_1 = require_connection();
	var sessions_1 = require_sessions();
	var extensions_1 = require_extensions();
	var tl_1 = require_tl();
	var os_1 = __importDefault(require_os());
	var entityCache_1 = require_entityCache();
	var markdown_1 = require_markdown();
	var network_1 = require_network();
	var AllTLObjects_1 = require_AllTLObjects();
	var TCPMTProxy_1 = require_TCPMTProxy();
	var async_mutex_1 = require_lib$1();
	var Logger_1 = require_Logger();
	var platform_1 = require_platform();
	var Deferred_1 = __importDefault(require_Deferred());
	var EXPORTED_SENDER_RECONNECT_TIMEOUT = 1e3;
	var EXPORTED_SENDER_RELEASE_TIMEOUT = 3e4;
	var DEFAULT_DC_ID = 4;
	var DEFAULT_IPV4_IP = platform_1.isNode ? "149.154.167.91" : "vesta.web.telegram.org";
	var DEFAULT_IPV6_IP = "2001:067c:04e8:f004:0000:0000:0000:000a";
	var clientParamsDefault = {
		connection: platform_1.isNode ? connection_1.ConnectionTCPFull : connection_1.ConnectionTCPObfuscated,
		networkSocket: platform_1.isNode ? extensions_1.PromisedNetSockets : extensions_1.PromisedWebSockets,
		useIPV6: false,
		timeout: 10,
		requestRetries: 5,
		connectionRetries: Infinity,
		retryDelay: 1e3,
		downloadRetries: 5,
		autoReconnect: true,
		sequentialUpdates: false,
		floodSleepThreshold: 60,
		deviceModel: "",
		systemVersion: "",
		appVersion: "",
		langCode: "en",
		systemLangCode: "en",
		_securityChecks: true,
		useWSS: platform_1.isBrowser ? window.location.protocol == "https:" : false,
		testServers: false
	};
	var TelegramBaseClient = class {
		constructor(session, apiId, apiHash, clientParams) {
			/** The current gramJS version. */
			this.__version__ = __1.version;
			/** @hidden */
			this._ALBUMS = /* @__PURE__ */ new Map();
			/** @hidden */
			this._exportedSenderPromises = /* @__PURE__ */ new Map();
			/** @hidden */
			this._exportedSenderReleaseTimeouts = /* @__PURE__ */ new Map();
			clientParams = Object.assign(Object.assign({}, clientParamsDefault), clientParams);
			if (!apiId || !apiHash) throw new Error("Your API ID or Hash cannot be empty or undefined");
			if (clientParams.baseLogger) this._log = clientParams.baseLogger;
			else this._log = new extensions_1.Logger();
			this._log.info("Running gramJS version " + __1.version);
			if (session && typeof session == "string") session = new sessions_1.StoreSession(session);
			if (!(session instanceof sessions_1.Session)) throw new Error("Only StringSession and StoreSessions are supported currently :( ");
			this._floodSleepThreshold = clientParams.floodSleepThreshold;
			this.session = session;
			this.apiId = apiId;
			this.apiHash = apiHash;
			this._useIPV6 = clientParams.useIPV6;
			this._requestRetries = clientParams.requestRetries;
			this._downloadRetries = clientParams.downloadRetries;
			this._connectionRetries = clientParams.connectionRetries;
			this._reconnectRetries = clientParams.reconnectRetries;
			this._retryDelay = clientParams.retryDelay || 0;
			this._timeout = clientParams.timeout;
			this._autoReconnect = clientParams.autoReconnect;
			this._proxy = clientParams.proxy;
			this._semaphore = new async_mutex_1.Semaphore(clientParams.maxConcurrentDownloads || 1);
			this.testServers = clientParams.testServers || false;
			this.networkSocket = clientParams.networkSocket || extensions_1.PromisedNetSockets;
			if (!(clientParams.connection instanceof Function)) throw new Error("Connection should be a class not an instance");
			this._connection = clientParams.connection;
			let initProxy;
			if (this._proxy && "MTProxy" in this._proxy) {
				this._connection = TCPMTProxy_1.ConnectionTCPMTProxyAbridged;
				initProxy = new tl_1.Api.InputClientProxy({
					address: this._proxy.ip,
					port: this._proxy.port
				});
			}
			this._initRequest = new tl_1.Api.InitConnection({
				apiId: this.apiId,
				deviceModel: clientParams.deviceModel || os_1.default.type().toString() || "Unknown",
				systemVersion: clientParams.systemVersion || os_1.default.release().toString() || "1.0",
				appVersion: clientParams.appVersion || "1.0",
				langCode: clientParams.langCode,
				langPack: "",
				systemLangCode: clientParams.systemLangCode,
				proxy: initProxy
			});
			this._eventBuilders = [];
			this._floodWaitedRequests = {};
			this._borrowedSenderPromises = {};
			this._bot = void 0;
			this._selfInputPeer = void 0;
			this.useWSS = clientParams.useWSS;
			this._securityChecks = !!clientParams.securityChecks;
			if (this.useWSS && this._proxy) throw new Error("Cannot use SSL with proxies. You need to disable the useWSS client param in TelegramClient");
			this._entityCache = new entityCache_1.EntityCache();
			this._config = void 0;
			this._loopStarted = false;
			this._reconnecting = false;
			this._destroyed = false;
			this._isSwitchingDc = false;
			this._connectedDeferred = new Deferred_1.default();
			this._parseMode = markdown_1.MarkdownParser;
		}
		get floodSleepThreshold() {
			return this._floodSleepThreshold;
		}
		set floodSleepThreshold(value) {
			this._floodSleepThreshold = Math.min(value || 0, 86400);
		}
		set maxConcurrentDownloads(value) {
			this._semaphore._value = value;
		}
		async _initSession() {
			await this.session.load();
			if (!this.session.serverAddress) this.session.setDC(DEFAULT_DC_ID, this._useIPV6 ? DEFAULT_IPV6_IP : DEFAULT_IPV4_IP, this.useWSS ? 443 : 80);
			else this._useIPV6 = this.session.serverAddress.includes(":");
		}
		get connected() {
			return this._sender && this._sender.isConnected();
		}
		async disconnect() {
			await this._disconnect();
			await Promise.all(Object.values(this._exportedSenderPromises).map((promises) => {
				return Object.values(promises).map((promise) => {
					return promise && promise.then((sender) => {
						if (sender) return sender.disconnect();
					});
				});
			}).flat());
			Object.values(this._exportedSenderReleaseTimeouts).forEach((timeouts) => {
				Object.values(timeouts).forEach((releaseTimeout) => {
					clearTimeout(releaseTimeout);
				});
			});
			this._exportedSenderPromises.clear();
		}
		get disconnected() {
			return !this._sender || this._sender._disconnected;
		}
		async _disconnect() {
			var _a;
			await ((_a = this._sender) === null || _a === void 0 ? void 0 : _a.disconnect());
		}
		/**
		* Disconnects all senders and removes all handlers
		* Disconnect is safer as it will not remove your event handlers
		*/
		async destroy() {
			this._destroyed = true;
			await Promise.all([this.disconnect(), ...Object.values(this._borrowedSenderPromises).map((promise) => {
				return promise.then((sender) => sender.disconnect());
			})]);
			this._eventBuilders = [];
		}
		/** @hidden */
		async _authKeyCallback(authKey, dcId) {
			this.session.setAuthKey(authKey, dcId);
			await this.session.save();
		}
		/** @hidden */
		async _cleanupExportedSender(dcId) {
			if (this.session.dcId !== dcId) this.session.setAuthKey(void 0, dcId);
			let sender = await this._exportedSenderPromises.get(dcId);
			this._exportedSenderPromises.delete(dcId);
			await (sender === null || sender === void 0 ? void 0 : sender.disconnect());
		}
		/** @hidden */
		async _connectSender(sender, dcId) {
			const dc = await this.getDC(dcId, !!sender.authKey.getKey());
			while (true) try {
				await sender.connect(new this._connection({
					ip: dc.ipAddress,
					port: dc.port,
					dcId,
					loggers: this._log,
					proxy: this._proxy,
					testServers: this.testServers,
					socket: this.networkSocket
				}), false);
				if (this.session.dcId !== dcId && !sender._authenticated) {
					this._log.info(`Exporting authorization for data center ${dc.ipAddress} with layer ${AllTLObjects_1.LAYER}`);
					const auth = await this.invoke(new tl_1.Api.auth.ExportAuthorization({ dcId }));
					this._initRequest.query = new tl_1.Api.auth.ImportAuthorization({
						id: auth.id,
						bytes: auth.bytes
					});
					const req = new tl_1.Api.InvokeWithLayer({
						layer: AllTLObjects_1.LAYER,
						query: this._initRequest
					});
					await sender.send(req);
					sender._authenticated = true;
				}
				sender.dcId = dcId;
				sender.userDisconnected = false;
				return sender;
			} catch (err) {
				if (err.errorMessage === "DC_ID_INVALID") {
					sender._authenticated = true;
					sender.userDisconnected = false;
					return sender;
				}
				if (this._errorHandler) await this._errorHandler(err);
				else if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.error(err);
				await (0, Helpers_1.sleep)(1e3);
				await sender.disconnect();
			}
		}
		/** @hidden */
		async _borrowExportedSender(dcId, shouldReconnect, existingSender) {
			if (!this._exportedSenderPromises.get(dcId) || shouldReconnect) this._exportedSenderPromises.set(dcId, this._connectSender(existingSender || this._createExportedSender(dcId), dcId));
			let sender;
			try {
				sender = await this._exportedSenderPromises.get(dcId);
				if (!sender.isConnected()) {
					if (sender.isConnecting) {
						await (0, Helpers_1.sleep)(EXPORTED_SENDER_RECONNECT_TIMEOUT);
						return this._borrowExportedSender(dcId, false, sender);
					} else return this._borrowExportedSender(dcId, true, sender);
				}
			} catch (err) {
				if (this._errorHandler) await this._errorHandler(err);
				if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.error(err);
				return this._borrowExportedSender(dcId, true);
			}
			if (this._exportedSenderReleaseTimeouts.get(dcId)) {
				clearTimeout(this._exportedSenderReleaseTimeouts.get(dcId));
				this._exportedSenderReleaseTimeouts.delete(dcId);
			}
			this._exportedSenderReleaseTimeouts.set(dcId, setTimeout(() => {
				this._exportedSenderReleaseTimeouts.delete(dcId);
				if (sender._pendingState.values().length) {
					console.log("sender already has some hanging states. reconnecting");
					sender._reconnect();
					this._borrowExportedSender(dcId, false, sender);
				} else sender.disconnect();
			}, EXPORTED_SENDER_RELEASE_TIMEOUT));
			return sender;
		}
		/** @hidden */
		_createExportedSender(dcId) {
			return new network_1.MTProtoSender(this.session.getAuthKey(dcId), {
				logger: this._log,
				dcId,
				retries: this._connectionRetries,
				delay: this._retryDelay,
				autoReconnect: this._autoReconnect,
				connectTimeout: this._timeout,
				authKeyCallback: this._authKeyCallback.bind(this),
				isMainSender: dcId === this.session.dcId,
				onConnectionBreak: this._cleanupExportedSender.bind(this),
				client: this,
				securityChecks: this._securityChecks,
				_exportedSenderPromises: this._exportedSenderPromises,
				reconnectRetries: this._reconnectRetries
			});
		}
		/** @hidden */
		getSender(dcId) {
			return dcId ? this._borrowExportedSender(dcId) : Promise.resolve(this._sender);
		}
		async getDC(dcId, download) {
			throw new Error("Cannot be called from here!");
		}
		invoke(request) {
			throw new Error("Cannot be called from here!");
		}
		setLogLevel(level) {
			this._log.setLevel(level);
		}
		get logger() {
			return this._log;
		}
		/**
		* Custom error handler for the client
		* @example
		* ```ts
		* client.onError = async (error)=>{
		*         console.log("error is",error)
		*     }
		* ```
		*/
		set onError(handler) {
			this._errorHandler = async (error) => {
				try {
					await handler(error);
				} catch (e) {
					if (this._log.canSend(Logger_1.LogLevel.ERROR)) {
						e.message = `Error ${e.message} thrown while handling top-level error: ${error.message}`;
						console.error(e);
					}
				}
			};
		}
	};
	exports.TelegramBaseClient = TelegramBaseClient;
}));
//#endregion
//#region node_modules/telegram/client/auth.js
var require_auth = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.start = start;
	exports.checkAuthorization = checkAuthorization;
	exports.signInUser = signInUser;
	exports.signInUserWithQrCode = signInUserWithQrCode;
	exports.sendCode = sendCode;
	exports.signInWithPassword = signInWithPassword;
	exports.signInBot = signInBot;
	exports._authFlow = _authFlow;
	var tl_1 = require_tl();
	var utils = __importStar(require_Utils());
	var Helpers_1 = require_Helpers();
	var Password_1 = require_Password();
	var QR_CODE_TIMEOUT = 3e4;
	/** @hidden */
	async function start(client, authParams) {
		if (!client.connected) await client.connect();
		if (await client.checkAuthorization()) return;
		await _authFlow(client, {
			apiId: client.apiId,
			apiHash: client.apiHash
		}, authParams);
	}
	/** @hidden */
	async function checkAuthorization(client) {
		try {
			await client.invoke(new tl_1.Api.updates.GetState());
			return true;
		} catch (e) {
			return false;
		}
	}
	/** @hidden */
	async function signInUser(client, apiCredentials, authParams) {
		let phoneNumber;
		let phoneCodeHash;
		let isCodeViaApp = false;
		while (1) try {
			if (typeof authParams.phoneNumber === "function") try {
				phoneNumber = await authParams.phoneNumber();
			} catch (err) {
				if (err.errorMessage === "RESTART_AUTH_WITH_QR") return client.signInUserWithQrCode(apiCredentials, authParams);
				throw err;
			}
			else phoneNumber = authParams.phoneNumber;
			const sendCodeResult = await client.sendCode(apiCredentials, phoneNumber, authParams.forceSMS);
			phoneCodeHash = sendCodeResult.phoneCodeHash;
			isCodeViaApp = sendCodeResult.isCodeViaApp;
			if (typeof phoneCodeHash !== "string") throw new Error("Failed to retrieve phone code hash");
			break;
		} catch (err) {
			if (typeof authParams.phoneNumber !== "function") throw err;
			if (await authParams.onError(err)) throw new Error("AUTH_USER_CANCEL");
		}
		let phoneCode;
		let isRegistrationRequired = false;
		let termsOfService;
		while (1) try {
			try {
				phoneCode = await authParams.phoneCode(isCodeViaApp);
			} catch (err) {
				if (err.errorMessage === "RESTART_AUTH") return client.signInUser(apiCredentials, authParams);
			}
			if (!phoneCode) throw new Error("Code is empty");
			const result = await client.invoke(new tl_1.Api.auth.SignIn({
				phoneNumber,
				phoneCodeHash,
				phoneCode
			}));
			if (result instanceof tl_1.Api.auth.AuthorizationSignUpRequired) {
				isRegistrationRequired = true;
				termsOfService = result.termsOfService;
				break;
			}
			return result.user;
		} catch (err) {
			if (err.errorMessage === "SESSION_PASSWORD_NEEDED") return client.signInWithPassword(apiCredentials, authParams);
			else if (await authParams.onError(err)) throw new Error("AUTH_USER_CANCEL");
		}
		if (isRegistrationRequired) while (1) try {
			let lastName;
			let firstName = "first name";
			if (authParams.firstAndLastNames) {
				const result = await authParams.firstAndLastNames();
				firstName = result[0];
				lastName = result[1];
			}
			if (!firstName) throw new Error("First name is required");
			const { user } = await client.invoke(new tl_1.Api.auth.SignUp({
				phoneNumber,
				phoneCodeHash,
				firstName,
				lastName
			}));
			if (termsOfService) await client.invoke(new tl_1.Api.help.AcceptTermsOfService({ id: termsOfService.id }));
			return user;
		} catch (err) {
			if (await authParams.onError(err)) throw new Error("AUTH_USER_CANCEL");
		}
		await authParams.onError(/* @__PURE__ */ new Error("Auth failed"));
		return client.signInUser(apiCredentials, authParams);
	}
	/** @hidden */
	async function signInUserWithQrCode(client, apiCredentials, authParams) {
		let isScanningComplete = false;
		if (authParams.qrCode == void 0) throw new Error("qrCode callback not defined");
		const inputPromise = (async () => {
			while (1) {
				if (isScanningComplete) break;
				const result = await client.invoke(new tl_1.Api.auth.ExportLoginToken({
					apiId: Number(apiCredentials.apiId),
					apiHash: apiCredentials.apiHash,
					exceptIds: []
				}));
				if (!(result instanceof tl_1.Api.auth.LoginToken)) throw new Error("Unexpected");
				const { token, expires } = result;
				await Promise.race([authParams.qrCode({
					token,
					expires
				}), (0, Helpers_1.sleep)(QR_CODE_TIMEOUT)]);
				await (0, Helpers_1.sleep)(QR_CODE_TIMEOUT);
			}
		})();
		const updatePromise = new Promise((resolve) => {
			client.addEventHandler((update) => {
				if (update instanceof tl_1.Api.UpdateLoginToken) resolve(void 0);
			});
		});
		try {
			await Promise.race([updatePromise, inputPromise]);
		} catch (err) {
			throw err;
		} finally {
			isScanningComplete = true;
		}
		try {
			const result2 = await client.invoke(new tl_1.Api.auth.ExportLoginToken({
				apiId: Number(apiCredentials.apiId),
				apiHash: apiCredentials.apiHash,
				exceptIds: []
			}));
			if (result2 instanceof tl_1.Api.auth.LoginTokenSuccess && result2.authorization instanceof tl_1.Api.auth.Authorization) return result2.authorization.user;
			else if (result2 instanceof tl_1.Api.auth.LoginTokenMigrateTo) {
				await client._switchDC(result2.dcId);
				const migratedResult = await client.invoke(new tl_1.Api.auth.ImportLoginToken({ token: result2.token }));
				if (migratedResult instanceof tl_1.Api.auth.LoginTokenSuccess && migratedResult.authorization instanceof tl_1.Api.auth.Authorization) return migratedResult.authorization.user;
				else {
					client._log.error(`Received unknown result while scanning QR ${result2.className}`);
					throw new Error(`Received unknown result while scanning QR ${result2.className}`);
				}
			} else {
				client._log.error(`Received unknown result while scanning QR ${result2.className}`);
				throw new Error(`Received unknown result while scanning QR ${result2.className}`);
			}
		} catch (err) {
			if (err.errorMessage === "SESSION_PASSWORD_NEEDED") return client.signInWithPassword(apiCredentials, authParams);
			throw err;
		}
	}
	/** @hidden */
	async function sendCode(client, apiCredentials, phoneNumber, forceSMS = false) {
		try {
			const { apiId, apiHash } = apiCredentials;
			const sendResult = await client.invoke(new tl_1.Api.auth.SendCode({
				phoneNumber,
				apiId,
				apiHash,
				settings: new tl_1.Api.CodeSettings({})
			}));
			if (sendResult instanceof tl_1.Api.auth.SentCodeSuccess) throw new Error("logged in right after sending the code");
			if (!forceSMS || sendResult.type instanceof tl_1.Api.auth.SentCodeTypeSms) return {
				phoneCodeHash: sendResult.phoneCodeHash,
				isCodeViaApp: sendResult.type instanceof tl_1.Api.auth.SentCodeTypeApp
			};
			const resendResult = await client.invoke(new tl_1.Api.auth.ResendCode({
				phoneNumber,
				phoneCodeHash: sendResult.phoneCodeHash
			}));
			if (resendResult instanceof tl_1.Api.auth.SentCodeSuccess) throw new Error("logged in right after resending the code");
			return {
				phoneCodeHash: resendResult.phoneCodeHash,
				isCodeViaApp: resendResult.type instanceof tl_1.Api.auth.SentCodeTypeApp
			};
		} catch (err) {
			if (err.errorMessage === "AUTH_RESTART") return client.sendCode(apiCredentials, phoneNumber, forceSMS);
			else throw err;
		}
	}
	/** @hidden */
	async function signInWithPassword(client, apiCredentials, authParams) {
		let emptyPassword = false;
		while (1) try {
			const passwordSrpResult = await client.invoke(new tl_1.Api.account.GetPassword());
			if (!authParams.password) {
				emptyPassword = true;
				break;
			}
			const password = await authParams.password(passwordSrpResult.hint);
			if (!password) throw new Error("Password is empty");
			const passwordSrpCheck = await (0, Password_1.computeCheck)(passwordSrpResult, password);
			const { user } = await client.invoke(new tl_1.Api.auth.CheckPassword({ password: passwordSrpCheck }));
			return user;
		} catch (err) {
			if (await authParams.onError(err)) throw new Error("AUTH_USER_CANCEL");
		}
		if (emptyPassword) throw new Error("Account has 2FA enabled.");
	}
	/** @hidden */
	async function signInBot(client, apiCredentials, authParams) {
		const { apiId, apiHash } = apiCredentials;
		let { botAuthToken } = authParams;
		if (!botAuthToken) throw new Error("a valid BotToken is required");
		if (typeof botAuthToken === "function") {
			let token;
			while (true) {
				token = await botAuthToken();
				if (token) {
					botAuthToken = token;
					break;
				}
			}
		}
		const { user } = await client.invoke(new tl_1.Api.auth.ImportBotAuthorization({
			apiId,
			apiHash,
			botAuthToken
		}));
		return user;
	}
	/** @hidden */
	async function _authFlow(client, apiCredentials, authParams) {
		const me = "phoneNumber" in authParams ? await client.signInUser(apiCredentials, authParams) : await client.signInBot(apiCredentials, authParams);
		client._log.info("Signed in successfully as " + utils.getDisplayName(me));
	}
}));
//#endregion
//#region node_modules/telegram/tl/custom/inlineResult.js
var require_inlineResult = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.InlineResult = void 0;
	var api_1 = require_api();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var Utils_1 = require_Utils();
	var InlineResult = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, original, queryId, entity) {
			this._ARTICLE = "article";
			this._PHOTO = "photo";
			this._GIF = "gif";
			this._VIDEO = "video";
			this._VIDEO_GIF = "mpeg4_gif";
			this._AUDIO = "audio";
			this._DOCUMENT = "document";
			this._LOCATION = "location";
			this._VENUE = "venue";
			this._CONTACT = "contact";
			this._GAME = "game";
			this._client = client;
			this.result = original;
			this._queryId = queryId;
			this._entity = entity;
		}
		get type() {
			return this.result.type;
		}
		get message() {
			return this.result.sendMessage;
		}
		get description() {
			return this.result.description;
		}
		get url() {
			if (this.result instanceof api_1.Api.BotInlineResult) return this.result.url;
		}
		get photo() {
			if (this.result instanceof api_1.Api.BotInlineResult) return this.result.thumb;
			else return this.result.photo;
		}
		get document() {
			if (this.result instanceof api_1.Api.BotInlineResult) return this.result.content;
			else return this.result.document;
		}
		async click(entity, replyTo, silent = false, clearDraft = false, hideVia = false) {
			if (entity) entity = await this._client.getInputEntity(entity);
			else if (this._entity) entity = this._entity;
			else throw new Error("You must provide the entity where the result should be sent to");
			let replyObject = void 0;
			if (replyTo != void 0) replyObject = new api_1.Api.InputReplyToMessage({ replyToMsgId: (0, Utils_1.getMessageId)(replyTo) });
			const request = new api_1.Api.messages.SendInlineBotResult({
				peer: entity,
				queryId: this._queryId,
				id: this.result.id,
				silent,
				clearDraft,
				hideVia,
				replyTo: replyObject
			});
			return await this._client.invoke(request);
		}
	};
	exports.InlineResult = InlineResult;
}));
//#endregion
//#region node_modules/telegram/tl/custom/inlineResults.js
var require_inlineResults = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.InlineResults = void 0;
	var inlineResult_1 = require_inlineResult();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var InlineResults = class extends Array {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, original, entity) {
			super(...original.results.map((res) => new inlineResult_1.InlineResult(client, res, original.queryId, entity)));
			this.result = original;
			this.queryId = original.queryId;
			this.cacheTime = original.cacheTime;
			this._validUntil = (/* @__PURE__ */ new Date()).getTime() / 1e3 + this.cacheTime;
			this.users = original.users;
			this.gallery = Boolean(original.gallery);
			this.nextOffset = original.nextOffset;
			this.switchPm = original.switchPm;
		}
		resultsValid() {
			return (/* @__PURE__ */ new Date()).getTime() / 1e3 < this._validUntil;
		}
	};
	exports.InlineResults = InlineResults;
}));
//#endregion
//#region node_modules/telegram/client/bots.js
var require_bots = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.inlineQuery = inlineQuery;
	var tl_1 = require_tl();
	var inlineResults_1 = require_inlineResults();
	var GetInlineBotResults = tl_1.Api.messages.GetInlineBotResults;
	/** @hidden */
	async function inlineQuery(client, bot, query, entity, offset, geoPoint) {
		bot = await client.getInputEntity(bot);
		let peer = new tl_1.Api.InputPeerSelf();
		if (entity) peer = await client.getInputEntity(entity);
		const result = await client.invoke(new GetInlineBotResults({
			bot,
			peer,
			query,
			offset: offset || "",
			geoPoint
		}));
		return new inlineResults_1.InlineResults(client, result, entity ? peer : void 0);
	}
}));
//#endregion
//#region node_modules/telegram/client/buttons.js
var require_buttons = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.buildReplyMarkup = buildReplyMarkup;
	var tl_1 = require_tl();
	var button_1 = require_button();
	var messageButton_1 = require_messageButton();
	var Helpers_1 = require_Helpers();
	/** @hidden */
	function buildReplyMarkup(buttons, inlineOnly = false) {
		if (buttons == void 0) return;
		if ("SUBCLASS_OF_ID" in buttons) {
			if (buttons.SUBCLASS_OF_ID == 3806400242) return buttons;
		}
		if (!(0, Helpers_1.isArrayLike)(buttons)) buttons = [[buttons]];
		else if (!buttons || !(0, Helpers_1.isArrayLike)(buttons[0])) buttons = [buttons];
		let isInline = false;
		let isNormal = false;
		let resize = void 0;
		const singleUse = false;
		const selective = false;
		const rows = [];
		for (const row of buttons) {
			const current = [];
			for (let button of row) {
				if (button instanceof button_1.Button) {
					if (button.resize != void 0) resize = button.resize;
					if (button.singleUse != void 0) resize = button.singleUse;
					if (button.selective != void 0) resize = button.selective;
					button = button.button;
				} else if (button instanceof messageButton_1.MessageButton) button = button.button;
				const inline = button_1.Button._isInline(button);
				if (!isInline && inline) isInline = true;
				if (!isNormal && inline) isNormal = false;
				if (button.SUBCLASS_OF_ID == 195916963) current.push(button);
			}
			if (current) rows.push(new tl_1.Api.KeyboardButtonRow({ buttons: current }));
		}
		if (inlineOnly && isNormal) throw new Error("You cannot use non-inline buttons here");
		else if (isInline === isNormal && isNormal) throw new Error("You cannot mix inline with normal buttons");
		else if (isInline) return new tl_1.Api.ReplyInlineMarkup({ rows });
		return new tl_1.Api.ReplyKeyboardMarkup({
			rows,
			resize,
			singleUse,
			selective
		});
	}
}));
//#endregion
//#region node_modules/telegram/requestIter.js
var require_requestIter = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __asyncValues = exports && exports.__asyncValues || function(o) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var m = o[Symbol.asyncIterator], i;
		return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i);
		function verb(n) {
			i[n] = o[n] && function(v) {
				return new Promise(function(resolve, reject) {
					v = o[n](v), settle(resolve, reject, v.done, v.value);
				});
			};
		}
		function settle(resolve, reject, d, v) {
			Promise.resolve(v).then(function(v) {
				resolve({
					value: v,
					done: d
				});
			}, reject);
		}
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.RequestIter = void 0;
	var Helpers_1 = require_Helpers();
	var _1 = require_telegram();
	var RequestIter = class {
		constructor(client, limit, params = {}, args = {}) {
			this.client = client;
			this.reverse = params.reverse;
			this.waitTime = params.waitTime;
			this.limit = Math.max(!limit ? Number.MAX_SAFE_INTEGER : limit, 0);
			this.left = this.limit;
			this.buffer = void 0;
			this.kwargs = args;
			this.index = 0;
			this.total = void 0;
			this.lastLoad = 0;
		}
		async _init(kwargs) {}
		[Symbol.asyncIterator]() {
			this.buffer = void 0;
			this.index = 0;
			this.lastLoad = 0;
			this.left = this.limit;
			return { next: async () => {
				if (this.buffer == void 0) {
					this.buffer = [];
					if (await this._init(this.kwargs)) this.left = this.buffer.length;
				}
				if (this.left <= 0) return {
					value: void 0,
					done: true
				};
				if (this.index == this.buffer.length) {
					if (this.waitTime) await (0, Helpers_1.sleep)(this.waitTime - ((/* @__PURE__ */ new Date()).getTime() / 1e3 - this.lastLoad));
					this.lastLoad = (/* @__PURE__ */ new Date()).getTime() / 1e3;
					this.index = 0;
					this.buffer = [];
					const nextChunk = await this._loadNextChunk();
					if (nextChunk === false) return {
						value: void 0,
						done: true
					};
					if (nextChunk) this.left = this.buffer.length;
				}
				if (!this.buffer || !this.buffer.length) return {
					value: void 0,
					done: true
				};
				const result = this.buffer[this.index];
				this.left -= 1;
				this.index += 1;
				return {
					value: result,
					done: false
				};
			} };
		}
		async collect() {
			var _a, e_1, _b, _c;
			const result = new _1.helpers.TotalList();
			try {
				for (var _d = true, _e = __asyncValues(this), _f; _f = await _e.next(), _a = _f.done, !_a; _d = true) {
					_c = _f.value;
					_d = false;
					const message = _c;
					result.push(message);
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (!_d && !_a && (_b = _e.return)) await _b.call(_e);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			result.total = this.total;
			return result;
		}
		async _loadNextChunk() {
			throw new Error("Not Implemented");
		}
	};
	exports.RequestIter = RequestIter;
}));
//#endregion
//#region node_modules/telegram/client/fs.js
var require_fs = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$1) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$1, p)) __createBinding(exports$1, m, p);
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	__exportStar(__require("fs"), exports);
}));
//#endregion
//#region node_modules/telegram/client/path.js
var require_path = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = __importDefault(__require("path")).default;
}));
//#endregion
//#region node_modules/telegram/client/downloads.js
var require_downloads = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	var __asyncValues = exports && exports.__asyncValues || function(o) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var m = o[Symbol.asyncIterator], i;
		return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i);
		function verb(n) {
			i[n] = o[n] && function(v) {
				return new Promise(function(resolve, reject) {
					v = o[n](v), settle(resolve, reject, v.done, v.value);
				});
			};
		}
		function settle(resolve, reject, d, v) {
			Promise.resolve(v).then(function(v) {
				resolve({
					value: v,
					done: d
				});
			}, reject);
		}
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.GenericDownloadIter = exports.DirectDownloadIter = void 0;
	exports.iterDownload = iterDownload;
	exports.downloadFileV2 = downloadFileV2;
	exports.downloadMedia = downloadMedia;
	exports._downloadDocument = _downloadDocument;
	exports._downloadContact = _downloadContact;
	exports._downloadWebDocument = _downloadWebDocument;
	exports._downloadCachedPhotoSize = _downloadCachedPhotoSize;
	exports._downloadPhoto = _downloadPhoto;
	exports.downloadProfilePhoto = downloadProfilePhoto;
	var tl_1 = require_tl();
	var Utils_1 = require_Utils();
	var Helpers_1 = require_Helpers();
	var __1 = require_telegram();
	var requestIter_1 = require_requestIter();
	var errors_1 = require_errors();
	var fs_1 = require_fs();
	var extensions_1 = require_extensions();
	var fs = __importStar(require_fs());
	var path_1 = __importDefault(require_path());
	var big_integer_1 = __importDefault(require_BigInteger());
	var MIN_CHUNK_SIZE = 4096;
	var TIMED_OUT_SLEEP = 1e3;
	var MAX_CHUNK_SIZE = 524288;
	var DirectDownloadIter = class extends requestIter_1.RequestIter {
		constructor() {
			super(...arguments);
			this._timedOut = false;
		}
		async _init({ fileLocation, dcId, offset, stride, chunkSize, requestSize, fileSize, msgData }) {
			this.request = new tl_1.Api.upload.GetFile({
				location: fileLocation,
				offset,
				limit: requestSize
			});
			this.total = fileSize;
			this._stride = stride;
			this._chunkSize = chunkSize;
			this._lastPart = void 0;
			this._timedOut = false;
			this._sender = await this.client.getSender(dcId);
		}
		async _loadNextChunk() {
			const current = await this._request();
			this.buffer.push(current);
			if (current.length < this.request.limit) {
				this.left = this.buffer.length;
				await this.close();
				return true;
			} else this.request.offset = this.request.offset.add(this._stride);
		}
		async _request() {
			try {
				this._sender = await this.client.getSender(this._sender.dcId);
				const result = await this.client.invokeWithSender(this.request, this._sender);
				this._timedOut = false;
				if (result instanceof tl_1.Api.upload.FileCdnRedirect) throw new Error("CDN Not supported. Please Add an issue in github");
				return result.bytes;
			} catch (e) {
				if (e.errorMessage == "TIMEOUT") {
					if (this._timedOut) {
						this.client._log.warn("Got two timeouts in a row while downloading file");
						throw e;
					}
					this._timedOut = true;
					this.client._log.info("Got timeout while downloading file, retrying once");
					await (0, Helpers_1.sleep)(TIMED_OUT_SLEEP);
					return await this._request();
				} else if (e instanceof errors_1.FileMigrateError) {
					this.client._log.info("File lives in another DC");
					this._sender = await this.client.getSender(e.newDc);
					return await this._request();
				} else if (e.errorMessage == "FILEREF_UPGRADE_NEEDED") throw e;
				else throw e;
			}
		}
		async close() {
			this.client._log.debug("Finished downloading file ...");
		}
		[Symbol.asyncIterator]() {
			return super[Symbol.asyncIterator]();
		}
	};
	exports.DirectDownloadIter = DirectDownloadIter;
	var GenericDownloadIter = class extends DirectDownloadIter {
		async _loadNextChunk() {
			let data = Buffer.alloc(0);
			const bad = this.request.offset.mod(this.request.limit).toJSNumber();
			const before = this.request.offset;
			this.request.offset = this.request.offset.subtract(bad);
			let done = false;
			while (!done && data.length - bad < this._chunkSize) {
				const current = await this._request();
				this.request.offset = this.request.offset.add(this.request.limit);
				data = Buffer.concat([data, current]);
				done = current.length < this.request.limit;
			}
			this.request.offset = before;
			for (let i = bad; i < data.length; i += this._stride) {
				this.buffer.push(data.slice(i, i + this._chunkSize));
				this.request.offset = this.request.offset.add(this._stride);
			}
			if (done) {
				this.left = this.buffer.length;
				await this.close();
				return;
			}
			if (this.buffer[this.buffer.length - 1].length != this._chunkSize) {
				this._lastPart = this.buffer.pop();
				this.request.offset = this.request.offset.subtract(this._stride);
			}
		}
	};
	exports.GenericDownloadIter = GenericDownloadIter;
	/** @hidden */
	function iterDownload(client, { file, offset = big_integer_1.default.zero, stride, limit, chunkSize, requestSize = MAX_CHUNK_SIZE, fileSize, dcId, msgData }) {
		const info = __1.utils.getFileInfo(file);
		if (info.dcId != void 0) dcId = info.dcId;
		if (fileSize == void 0) fileSize = info.size;
		file = info.location;
		if (chunkSize == void 0) chunkSize = requestSize;
		if (limit == void 0 && fileSize != void 0) limit = Math.floor(fileSize.add(chunkSize).subtract(1).divide(chunkSize).toJSNumber());
		if (stride == void 0) stride = chunkSize;
		else if (stride < chunkSize) throw new Error("Stride must be >= chunkSize");
		requestSize -= requestSize % MIN_CHUNK_SIZE;
		if (requestSize < MIN_CHUNK_SIZE) requestSize = MIN_CHUNK_SIZE;
		else if (requestSize > MAX_CHUNK_SIZE) requestSize = MAX_CHUNK_SIZE;
		let cls;
		if (chunkSize == requestSize && offset.divide(MAX_CHUNK_SIZE).eq(big_integer_1.default.zero) && stride % MIN_CHUNK_SIZE == 0 && (limit == void 0 || offset.divide(limit).eq(big_integer_1.default.zero))) {
			cls = DirectDownloadIter;
			client._log.info(`Starting direct file download in chunks of ${requestSize} at ${offset}, stride ${stride}`);
		} else {
			cls = GenericDownloadIter;
			client._log.info(`Starting indirect file download in chunks of ${requestSize} at ${offset}, stride ${stride}`);
		}
		return new cls(client, limit, {}, {
			fileLocation: file,
			dcId,
			offset,
			stride,
			chunkSize,
			requestSize,
			fileSize,
			msgData
		});
	}
	function getWriter(outputFile) {
		if (!outputFile || Buffer.isBuffer(outputFile)) return new extensions_1.BinaryWriter(Buffer.alloc(0));
		else if (typeof outputFile == "string") return (0, fs_1.createWriteStream)(outputFile);
		else return outputFile;
	}
	function closeWriter(writer) {
		if ("close" in writer && writer.close) writer.close();
	}
	function returnWriterValue(writer) {
		if (writer instanceof extensions_1.BinaryWriter) return writer.getValue();
		if (writer instanceof fs.WriteStream) {
			if (typeof writer.path == "string") return path_1.default.resolve(writer.path);
			else return Buffer.from(writer.path);
		}
	}
	/** @hidden */
	async function downloadFileV2(client, inputLocation, { outputFile = void 0, partSizeKb = void 0, fileSize = void 0, progressCallback = void 0, dcId = void 0, msgData = void 0 }) {
		var _a, e_1, _b, _c;
		if (!partSizeKb) {
			if (!fileSize) partSizeKb = 64;
			else partSizeKb = __1.utils.getAppropriatedPartSize(fileSize);
		}
		const partSize = Math.floor(partSizeKb * 1024);
		if (partSize % MIN_CHUNK_SIZE != 0) throw new Error("The part size must be evenly divisible by 4096");
		const writer = getWriter(outputFile);
		let downloaded = big_integer_1.default.zero;
		try {
			try {
				for (var _d = true, _e = __asyncValues(iterDownload(client, {
					file: inputLocation,
					requestSize: partSize,
					dcId,
					msgData
				})), _f; _f = await _e.next(), _a = _f.done, !_a; _d = true) {
					_c = _f.value;
					_d = false;
					const chunk = _c;
					await writer.write(chunk);
					downloaded = downloaded.add(chunk.length);
					if (progressCallback) await progressCallback(downloaded, (0, big_integer_1.default)(fileSize || big_integer_1.default.zero));
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (!_d && !_a && (_b = _e.return)) await _b.call(_e);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			return returnWriterValue(writer);
		} finally {
			closeWriter(writer);
		}
	}
	/** @hidden */
	async function downloadMedia(client, messageOrMedia, outputFile, thumb, progressCallback) {
		let msgData;
		let date;
		let media;
		if (messageOrMedia instanceof tl_1.Api.Message) {
			media = messageOrMedia.media;
			date = messageOrMedia.date;
			msgData = messageOrMedia.inputChat ? [messageOrMedia.inputChat, messageOrMedia.id] : void 0;
		} else {
			media = messageOrMedia;
			date = Date.now();
		}
		if (typeof media == "string") throw new Error("not implemented");
		if (media instanceof tl_1.Api.MessageMediaWebPage) {
			if (media.webpage instanceof tl_1.Api.WebPage) media = media.webpage.document || media.webpage.photo;
		}
		if (media instanceof tl_1.Api.MessageMediaPhoto || media instanceof tl_1.Api.Photo) return _downloadPhoto(client, media, outputFile, date, thumb, progressCallback);
		else if (media instanceof tl_1.Api.MessageMediaDocument || media instanceof tl_1.Api.Document) return _downloadDocument(client, media, outputFile, date, thumb, progressCallback, msgData);
		else if (media instanceof tl_1.Api.MessageMediaContact) return _downloadContact(client, media, {});
		else if (media instanceof tl_1.Api.WebDocument || media instanceof tl_1.Api.WebDocumentNoProxy) return _downloadWebDocument(client, media, {});
		else return Buffer.alloc(0);
	}
	/** @hidden */
	async function _downloadDocument(client, doc, outputFile, date, thumb, progressCallback, msgData) {
		if (doc instanceof tl_1.Api.MessageMediaDocument) {
			if (!doc.document) return Buffer.alloc(0);
			doc = doc.document;
		}
		if (!(doc instanceof tl_1.Api.Document)) return Buffer.alloc(0);
		let size;
		if (thumb == void 0) outputFile = getProperFilename(outputFile, "document", "." + (__1.utils.getExtension(doc) || "bin"), date);
		else {
			outputFile = getProperFilename(outputFile, "photo", ".jpg", date);
			size = getThumb(doc.thumbs || [], thumb);
			if (size instanceof tl_1.Api.PhotoCachedSize || size instanceof tl_1.Api.PhotoStrippedSize) return _downloadCachedPhotoSize(size, outputFile);
		}
		return await downloadFileV2(client, new tl_1.Api.InputDocumentFileLocation({
			id: doc.id,
			accessHash: doc.accessHash,
			fileReference: doc.fileReference,
			thumbSize: size && "type" in size ? size.type : ""
		}), {
			outputFile,
			fileSize: size && "size" in size ? (0, big_integer_1.default)(size.size) : doc.size,
			progressCallback,
			msgData
		});
	}
	/** @hidden */
	async function _downloadContact(client, media, args) {
		throw new Error("not implemented");
	}
	/** @hidden */
	async function _downloadWebDocument(client, media, args) {
		throw new Error("not implemented");
	}
	/** @hidden */
	function getThumb(thumbs, thumb) {
		function sortThumb(thumb) {
			if (thumb instanceof tl_1.Api.PhotoStrippedSize) return thumb.bytes.length;
			if (thumb instanceof tl_1.Api.PhotoCachedSize) return thumb.bytes.length;
			if (thumb instanceof tl_1.Api.PhotoSize) return thumb.size;
			if (thumb instanceof tl_1.Api.PhotoSizeProgressive) return Math.max(...thumb.sizes);
			if (thumb instanceof tl_1.Api.VideoSize) return thumb.size;
			return 0;
		}
		thumbs = thumbs.sort((a, b) => sortThumb(a) - sortThumb(b));
		const correctThumbs = [];
		for (const t of thumbs) if (!(t instanceof tl_1.Api.PhotoPathSize)) correctThumbs.push(t);
		if (thumb == void 0) return correctThumbs.pop();
		else if (typeof thumb == "number") return correctThumbs[thumb];
		else if (typeof thumb == "string") {
			for (const t of correctThumbs) if ("type" in t && t.type == thumb) return t;
		} else if (thumb instanceof tl_1.Api.PhotoSize || thumb instanceof tl_1.Api.PhotoCachedSize || thumb instanceof tl_1.Api.PhotoStrippedSize || thumb instanceof tl_1.Api.VideoSize) return thumb;
	}
	/** @hidden */
	async function _downloadCachedPhotoSize(size, outputFile) {
		let data;
		if (size instanceof tl_1.Api.PhotoStrippedSize) data = (0, Utils_1.strippedPhotoToJpg)(size.bytes);
		else data = size.bytes;
		const writer = getWriter(outputFile);
		try {
			await writer.write(data);
		} finally {
			closeWriter(writer);
		}
		return returnWriterValue(writer);
	}
	/** @hidden */
	function getProperFilename(file, fileType, extension, date) {
		if (!file || typeof file != "string") return file;
		if (fs.existsSync(file) && fs.lstatSync(file).isDirectory()) {
			let fullName = fileType + date + extension;
			return path_1.default.join(file, fullName);
		}
		return file;
	}
	/** @hidden */
	async function _downloadPhoto(client, photo, file, date, thumb, progressCallback) {
		if (photo instanceof tl_1.Api.MessageMediaPhoto) {
			if (photo.photo instanceof tl_1.Api.PhotoEmpty || !photo.photo) return Buffer.alloc(0);
			photo = photo.photo;
		}
		if (!(photo instanceof tl_1.Api.Photo)) return Buffer.alloc(0);
		const size = getThumb([...photo.sizes || [], ...photo.videoSizes || []], thumb);
		if (!size || size instanceof tl_1.Api.PhotoSizeEmpty) return Buffer.alloc(0);
		if (!date) date = Date.now();
		file = getProperFilename(file, "photo", ".jpg", date);
		if (size instanceof tl_1.Api.PhotoCachedSize || size instanceof tl_1.Api.PhotoStrippedSize) return _downloadCachedPhotoSize(size, file);
		let fileSize;
		if (size instanceof tl_1.Api.PhotoSizeProgressive) fileSize = Math.max(...size.sizes);
		else fileSize = "size" in size ? size.size : 512;
		return downloadFileV2(client, new tl_1.Api.InputPhotoFileLocation({
			id: photo.id,
			accessHash: photo.accessHash,
			fileReference: photo.fileReference,
			thumbSize: "type" in size ? size.type : ""
		}), {
			outputFile: file,
			fileSize: (0, big_integer_1.default)(fileSize),
			progressCallback,
			dcId: photo.dcId
		});
	}
	/** @hidden */
	async function downloadProfilePhoto(client, entity, fileParams) {
		let photo;
		if (typeof entity == "object" && "photo" in entity) photo = entity.photo;
		else {
			entity = await client.getEntity(entity);
			if ("photo" in entity) photo = entity.photo;
			else throw new Error(`Could not get photo from ${entity ? entity.className : void 0}`);
		}
		let dcId;
		let loc;
		if (photo instanceof tl_1.Api.UserProfilePhoto || photo instanceof tl_1.Api.ChatPhoto) {
			dcId = photo.dcId;
			loc = new tl_1.Api.InputPeerPhotoFileLocation({
				peer: __1.utils.getInputPeer(entity),
				photoId: photo.photoId,
				big: fileParams.isBig
			});
		} else return Buffer.alloc(0);
		return client.downloadFile(loc, {
			outputFile: fileParams.outputFile,
			dcId
		});
	}
}));
//#endregion
//#region node_modules/telegram/client/uploads.js
var require_uploads = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.CustomFile = void 0;
	exports.uploadFile = uploadFile;
	exports._fileToMedia = _fileToMedia;
	exports._sendAlbum = _sendAlbum;
	exports.sendFile = sendFile;
	var tl_1 = require_tl();
	var Helpers_1 = require_Helpers();
	var Utils_1 = require_Utils();
	var path_1 = __importDefault(require_path());
	var fs_1 = require_fs();
	var index_1 = require_telegram();
	var messageParse_1 = require_messageParse();
	var messages_1 = require_messages();
	var big_integer_1 = __importDefault(require_BigInteger());
	/**
	* A custom file class that mimics the browser's File class.<br/>
	* You should use this whenever you want to upload a file.
	*/
	var CustomFile = class {
		constructor(name, size, path, buffer) {
			this.name = name;
			this.size = size;
			this.path = path;
			this.buffer = buffer;
		}
	};
	exports.CustomFile = CustomFile;
	var CustomBuffer = class {
		constructor(options) {
			this.options = options;
			if (!options.buffer && !options.filePath) throw new Error("Either one of `buffer` or `filePath` should be specified");
		}
		async slice(begin, end) {
			const { buffer, filePath } = this.options;
			if (buffer) return buffer.slice(begin, end);
			else if (filePath) {
				const buffSize = end - begin;
				const buff = Buffer.alloc(buffSize);
				const fHandle = await fs_1.promises.open(filePath, "r");
				await fHandle.read(buff, 0, buffSize, begin);
				await fHandle.close();
				return Buffer.from(buff);
			}
			return Buffer.alloc(0);
		}
	};
	var KB_TO_BYTES = 1024;
	var LARGE_FILE_THRESHOLD = 10485760;
	var DISCONNECT_SLEEP = 1e3;
	async function getFileBuffer(file, fileSize, maxBufferSize) {
		const options = {};
		if (fileSize > maxBufferSize && file instanceof CustomFile) options.filePath = file.path;
		else options.buffer = Buffer.from(await fileToBuffer(file));
		return new CustomBuffer(options);
	}
	/** @hidden */
	async function uploadFile(client, fileParams) {
		const { file, onProgress } = fileParams;
		let { workers } = fileParams;
		const { name, size } = file;
		const fileId = (0, Helpers_1.readBigIntFromBuffer)((0, Helpers_1.generateRandomBytes)(8), true, true);
		const isLarge = size > LARGE_FILE_THRESHOLD;
		const partSize = (0, Utils_1.getAppropriatedPartSize)((0, big_integer_1.default)(size)) * KB_TO_BYTES;
		const partCount = Math.floor((size + partSize - 1) / partSize);
		const buffer = await getFileBuffer(file, size, fileParams.maxBufferSize || 20971519);
		await client.getSender(client.session.dcId);
		if (!workers || !size) workers = 1;
		if (workers >= partCount) workers = partCount;
		let progress = 0;
		if (onProgress) onProgress(progress);
		for (let i = 0; i < partCount; i += workers) {
			const sendingParts = [];
			let end = i + workers;
			if (end > partCount) end = partCount;
			for (let j = i; j < end; j++) {
				let endPart = (j + 1) * partSize;
				if (endPart > size) endPart = size;
				if (endPart == j * partSize) break;
				const bytes = await buffer.slice(j * partSize, endPart);
				sendingParts.push((async (jMemo, bytesMemo) => {
					while (true) {
						let sender;
						try {
							sender = await client.getSender(client.session.dcId);
							await sender.send(isLarge ? new tl_1.Api.upload.SaveBigFilePart({
								fileId,
								filePart: jMemo,
								fileTotalParts: partCount,
								bytes: bytesMemo
							}) : new tl_1.Api.upload.SaveFilePart({
								fileId,
								filePart: jMemo,
								bytes: bytesMemo
							}));
						} catch (err) {
							if (sender && !sender.isConnected()) {
								await (0, Helpers_1.sleep)(DISCONNECT_SLEEP);
								continue;
							} else if (err instanceof index_1.errors.FloodWaitError) {
								await (0, Helpers_1.sleep)(err.seconds * 1e3);
								continue;
							}
							throw err;
						}
						if (onProgress) {
							if (onProgress.isCanceled) throw new Error("USER_CANCELED");
							progress += 1 / partCount;
							onProgress(progress);
						}
						break;
					}
				})(j, bytes));
			}
			await Promise.all(sendingParts);
		}
		return isLarge ? new tl_1.Api.InputFileBig({
			id: fileId,
			parts: partCount,
			name
		}) : new tl_1.Api.InputFile({
			id: fileId,
			parts: partCount,
			name,
			md5Checksum: ""
		});
	}
	/** @hidden */
	async function _fileToMedia(client, { file, forceDocument, fileSize, progressCallback, attributes, thumb, voiceNote = false, videoNote = false, supportsStreaming = false, mimeType, asImage, workers = 1 }) {
		if (!file) return {
			fileHandle: void 0,
			media: void 0,
			image: void 0
		};
		const isImage = index_1.utils.isImage(file);
		if (asImage == void 0) asImage = isImage && !forceDocument;
		if (typeof file == "object" && !Buffer.isBuffer(file) && !(file instanceof tl_1.Api.InputFile) && !(file instanceof tl_1.Api.InputFileBig) && !(file instanceof CustomFile) && !("read" in file)) try {
			return {
				fileHandle: void 0,
				media: index_1.utils.getInputMedia(file, {
					isPhoto: asImage,
					attributes,
					forceDocument,
					voiceNote,
					videoNote,
					supportsStreaming
				}),
				image: asImage
			};
		} catch (e) {
			return {
				fileHandle: void 0,
				media: void 0,
				image: isImage
			};
		}
		let media;
		let fileHandle;
		let createdFile;
		if (file instanceof tl_1.Api.InputFile || file instanceof tl_1.Api.InputFileBig) fileHandle = file;
		else if (typeof file == "string" && (file.startsWith("https://") || file.startsWith("http://"))) {
			if (asImage) media = new tl_1.Api.InputMediaPhotoExternal({ url: file });
			else media = new tl_1.Api.InputMediaDocumentExternal({ url: file });
		} else if (!(typeof file == "string") || (await fs_1.promises.lstat(file)).isFile()) {
			if (typeof file == "string") createdFile = new CustomFile(path_1.default.basename(file), (await fs_1.promises.stat(file)).size, file);
			else if (typeof File !== "undefined" && file instanceof File || file instanceof CustomFile) createdFile = file;
			else {
				let name;
				if ("name" in file) name = file.name;
				else name = "unnamed";
				if (Buffer.isBuffer(file)) createdFile = new CustomFile(name, file.length, "", file);
			}
			if (!createdFile) throw new Error(`Could not create file from ${JSON.stringify(file)}`);
			fileHandle = await uploadFile(client, {
				file: createdFile,
				onProgress: progressCallback,
				workers
			});
		} else throw new Error(`"Not a valid path nor a url ${file}`);
		if (media != void 0) {} else if (fileHandle == void 0) throw new Error(`Failed to convert ${file} to media. Not an existing file or an HTTP URL`);
		else if (asImage) media = new tl_1.Api.InputMediaUploadedPhoto({ file: fileHandle });
		else {
			let res = index_1.utils.getAttributes(file, {
				mimeType,
				attributes,
				forceDocument: forceDocument && !isImage,
				voiceNote,
				videoNote,
				supportsStreaming,
				thumb
			});
			attributes = res.attrs;
			mimeType = res.mimeType;
			let uploadedThumb;
			if (!thumb) uploadedThumb = void 0;
			else {
				if (typeof thumb == "string") uploadedThumb = new CustomFile(path_1.default.basename(thumb), (await fs_1.promises.stat(thumb)).size, thumb);
				else if (typeof File !== "undefined" && thumb instanceof File) uploadedThumb = thumb;
				else {
					let name;
					if ("name" in thumb) name = thumb.name;
					else name = "unnamed";
					if (Buffer.isBuffer(thumb)) uploadedThumb = new CustomFile(name, thumb.length, "", thumb);
				}
				if (!uploadedThumb) throw new Error(`Could not create file from ${file}`);
				uploadedThumb = await uploadFile(client, {
					file: uploadedThumb,
					workers: 1
				});
			}
			media = new tl_1.Api.InputMediaUploadedDocument({
				file: fileHandle,
				mimeType,
				attributes,
				thumb: uploadedThumb,
				forceFile: forceDocument && !isImage
			});
		}
		return {
			fileHandle,
			media,
			image: asImage
		};
	}
	/** @hidden */
	async function _sendAlbum(client, entity, { file, caption, forceDocument = false, fileSize, clearDraft = false, progressCallback, replyTo, attributes, thumb, parseMode, voiceNote = false, videoNote = false, silent, supportsStreaming = false, scheduleDate, workers = 1, noforwards, commentTo, topMsgId }) {
		entity = await client.getInputEntity(entity);
		let files = [];
		if (!Array.isArray(file)) files = [file];
		else files = file;
		if (!Array.isArray(caption)) {
			if (!caption) caption = "";
			caption = [caption];
		}
		const captions = [];
		for (const c of caption) captions.push(await (0, messageParse_1._parseMessageText)(client, c, parseMode));
		if (commentTo != void 0) {
			const discussionData = await (0, messages_1.getCommentData)(client, entity, commentTo);
			entity = discussionData.entity;
			replyTo = discussionData.replyTo;
		} else replyTo = index_1.utils.getMessageId(replyTo);
		if (!attributes) attributes = [];
		let index = 0;
		const albumFiles = [];
		for (const file of files) {
			let { fileHandle, media, image } = await _fileToMedia(client, {
				file,
				forceDocument,
				fileSize,
				progressCallback,
				attributes: attributes[index],
				thumb,
				voiceNote,
				videoNote,
				supportsStreaming,
				workers
			});
			index++;
			if (media instanceof tl_1.Api.InputMediaUploadedPhoto || media instanceof tl_1.Api.InputMediaPhotoExternal) {
				const r = await client.invoke(new tl_1.Api.messages.UploadMedia({
					peer: entity,
					media
				}));
				if (r instanceof tl_1.Api.MessageMediaPhoto) media = (0, Utils_1.getInputMedia)(r.photo);
			} else if (media instanceof tl_1.Api.InputMediaUploadedDocument) {
				const r = await client.invoke(new tl_1.Api.messages.UploadMedia({
					peer: entity,
					media
				}));
				if (r instanceof tl_1.Api.MessageMediaDocument) media = (0, Utils_1.getInputMedia)(r.document);
			}
			let text = "";
			let msgEntities = [];
			if (captions.length) [text, msgEntities] = captions.shift();
			albumFiles.push(new tl_1.Api.InputSingleMedia({
				media,
				message: text,
				entities: msgEntities
			}));
		}
		let replyObject = void 0;
		if (replyTo != void 0) replyObject = new tl_1.Api.InputReplyToMessage({
			replyToMsgId: (0, Utils_1.getMessageId)(replyTo),
			topMsgId: (0, Utils_1.getMessageId)(topMsgId)
		});
		const result = await client.invoke(new tl_1.Api.messages.SendMultiMedia({
			peer: entity,
			replyTo: replyObject,
			multiMedia: albumFiles,
			silent,
			scheduleDate,
			clearDraft,
			noforwards
		}));
		const randomIds = albumFiles.map((m) => m.randomId);
		return client._getResponseMessage(randomIds, result, entity);
	}
	/** @hidden */
	async function sendFile(client, entity, { file, caption, forceDocument = false, fileSize, clearDraft = false, progressCallback, replyTo, attributes, thumb, parseMode, formattingEntities, voiceNote = false, videoNote = false, buttons, silent, supportsStreaming = false, scheduleDate, workers = 1, noforwards, commentTo, topMsgId }) {
		if (!file) throw new Error("You need to specify a file");
		if (!caption) caption = "";
		entity = await client.getInputEntity(entity);
		if (commentTo != void 0) {
			const discussionData = await (0, messages_1.getCommentData)(client, entity, commentTo);
			entity = discussionData.entity;
			replyTo = discussionData.replyTo;
		} else replyTo = index_1.utils.getMessageId(replyTo);
		if (Array.isArray(file)) return await _sendAlbum(client, entity, {
			file,
			caption,
			replyTo,
			parseMode,
			attributes,
			silent,
			scheduleDate,
			supportsStreaming,
			clearDraft,
			forceDocument,
			noforwards,
			topMsgId
		});
		if (Array.isArray(caption)) caption = caption[0] || "";
		let msgEntities;
		if (formattingEntities != void 0) msgEntities = formattingEntities;
		else [caption, msgEntities] = await (0, messageParse_1._parseMessageText)(client, caption, parseMode);
		const { fileHandle, media, image } = await _fileToMedia(client, {
			file,
			forceDocument,
			fileSize,
			progressCallback,
			attributes,
			thumb,
			voiceNote,
			videoNote,
			supportsStreaming,
			workers
		});
		if (media == void 0) throw new Error(`Cannot use ${file} as file.`);
		const markup = client.buildReplyMarkup(buttons);
		let replyObject = void 0;
		if (replyTo != void 0) replyObject = new tl_1.Api.InputReplyToMessage({
			replyToMsgId: (0, Utils_1.getMessageId)(replyTo),
			topMsgId: (0, Utils_1.getMessageId)(topMsgId)
		});
		const request = new tl_1.Api.messages.SendMedia({
			peer: entity,
			media,
			replyTo: replyObject,
			message: caption,
			entities: msgEntities,
			replyMarkup: markup,
			silent,
			scheduleDate,
			clearDraft,
			noforwards
		});
		const result = await client.invoke(request);
		return client._getResponseMessage(request, result, entity);
	}
	function fileToBuffer(file) {
		if (typeof File !== "undefined" && file instanceof File) return new Response(file).arrayBuffer();
		else if (file instanceof CustomFile) {
			if (file.buffer != void 0) return file.buffer;
			else return fs_1.promises.readFile(file.path);
		} else throw new Error("Could not create buffer from file " + file);
	}
}));
//#endregion
//#region node_modules/telegram/client/messages.js
var require_messages = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __asyncValues = exports && exports.__asyncValues || function(o) {
		if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
		var m = o[Symbol.asyncIterator], i;
		return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
			return this;
		}, i);
		function verb(n) {
			i[n] = o[n] && function(v) {
				return new Promise(function(resolve, reject) {
					v = o[n](v), settle(resolve, reject, v.done, v.value);
				});
			};
		}
		function settle(resolve, reject, d, v) {
			Promise.resolve(v).then(function(v) {
				resolve({
					value: v,
					done: d
				});
			}, reject);
		}
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports._IDsIter = exports._MessagesIter = void 0;
	exports.iterMessages = iterMessages;
	exports.getMessages = getMessages;
	exports.sendMessage = sendMessage;
	exports.forwardMessages = forwardMessages;
	exports.editMessage = editMessage;
	exports.deleteMessages = deleteMessages;
	exports.pinMessage = pinMessage;
	exports.unpinMessage = unpinMessage;
	exports._pin = _pin;
	exports.markAsRead = markAsRead;
	exports.getCommentData = getCommentData;
	var tl_1 = require_tl();
	var requestIter_1 = require_requestIter();
	var Helpers_1 = require_Helpers();
	var Utils_1 = require_Utils();
	var __1 = require_telegram();
	var messageParse_1 = require_messageParse();
	var users_1 = require_users();
	var big_integer_1 = __importDefault(require_BigInteger());
	var uploads_1 = require_uploads();
	var _MAX_CHUNK_SIZE = 100;
	var _MessagesIter = class extends requestIter_1.RequestIter {
		async _init({ entity, offsetId, minId, maxId, fromUser, offsetDate, addOffset, filter, search, replyTo }) {
			var _a, e_1, _b, _c;
			if (entity) this.entity = await this.client.getInputEntity(entity);
			else {
				this.entity = void 0;
				if (this.reverse) throw new Error("Cannot reverse global search");
			}
			if (this.reverse) {
				offsetId = Math.max(offsetId, minId);
				if (offsetId && maxId) {
					if (maxId - offsetId <= 1) return false;
				}
				if (!maxId) maxId = Number.MAX_SAFE_INTEGER;
			} else {
				offsetId = Math.max(offsetId, maxId);
				if (offsetId && minId) {
					if (offsetId - minId <= 1) return false;
				}
			}
			if (this.reverse) {
				if (offsetId) offsetId += 1;
				else if (!offsetDate) offsetId = 1;
			}
			if (fromUser) fromUser = await this.client.getInputEntity(fromUser);
			if (!this.entity && fromUser) this.entity = new tl_1.Api.InputPeerEmpty();
			if (!filter) filter = new tl_1.Api.InputMessagesFilterEmpty();
			if (!this.entity) this.request = new tl_1.Api.messages.SearchGlobal({
				q: search || "",
				filter,
				minDate: void 0,
				maxDate: offsetDate,
				offsetRate: void 0,
				offsetPeer: new tl_1.Api.InputPeerEmpty(),
				offsetId,
				limit: 1
			});
			else if (replyTo !== void 0) this.request = new tl_1.Api.messages.GetReplies({
				peer: this.entity,
				msgId: replyTo,
				offsetId,
				offsetDate,
				addOffset,
				limit: 0,
				maxId: 0,
				minId: 0,
				hash: big_integer_1.default.zero
			});
			else if (search !== void 0 || !(filter instanceof tl_1.Api.InputMessagesFilterEmpty) || fromUser !== void 0) {
				this.request = new tl_1.Api.messages.Search({
					peer: this.entity,
					q: search || "",
					filter: typeof filter === "function" ? new filter() : filter,
					minDate: void 0,
					maxDate: offsetDate,
					offsetId,
					addOffset,
					limit: 0,
					maxId: 0,
					minId: 0,
					hash: (0, Helpers_1.generateRandomBigInt)(),
					fromId: fromUser
				});
				if (!(filter instanceof tl_1.Api.InputMessagesFilterEmpty) && offsetDate && !search && !offsetId) try {
					for (var _d = true, _e = __asyncValues(this.client.iterMessages(this.entity, {
						limit: 1,
						offsetDate
					})), _f; _f = await _e.next(), _a = _f.done, !_a; _d = true) {
						_c = _f.value;
						_d = false;
						const m = _c;
						this.request.offsetId = m.id + 1;
					}
				} catch (e_1_1) {
					e_1 = { error: e_1_1 };
				} finally {
					try {
						if (!_d && !_a && (_b = _e.return)) await _b.call(_e);
					} finally {
						if (e_1) throw e_1.error;
					}
				}
			} else this.request = new tl_1.Api.messages.GetHistory({
				peer: this.entity,
				limit: 1,
				offsetDate,
				offsetId,
				minId: 0,
				maxId: 0,
				addOffset,
				hash: big_integer_1.default.zero
			});
			if (this.limit <= 0) {
				const result = await this.client.invoke(this.request);
				if (result instanceof tl_1.Api.messages.MessagesNotModified) this.total = result.count;
				else if ("count" in result) this.total = result.count;
				else this.total = result.messages.length;
				return false;
			}
			if (!this.waitTime) this.waitTime = this.limit > 3e3 ? 1 : 0;
			if (this.reverse && !(this.request instanceof tl_1.Api.messages.SearchGlobal)) this.request.addOffset -= _MAX_CHUNK_SIZE;
			this.addOffset = addOffset;
			this.maxId = maxId;
			this.minId = minId;
			this.lastId = this.reverse ? 0 : Number.MAX_SAFE_INTEGER;
		}
		async _loadNextChunk() {
			var _a;
			if (!this.request) throw new Error("Request not set yet");
			this.request.limit = Math.min(this.left, _MAX_CHUNK_SIZE);
			if (this.reverse && this.request.limit != _MAX_CHUNK_SIZE) {
				if (!(this.request instanceof tl_1.Api.messages.SearchGlobal)) this.request.addOffset = this.addOffset - this.request.limit;
			}
			const r = await this.client.invoke(this.request);
			if (r instanceof tl_1.Api.messages.MessagesNotModified) return true;
			if ("count" in r) this.total = r.count;
			else this.total = r.messages.length;
			const entities = /* @__PURE__ */ new Map();
			for (const x of [...r.users, ...r.chats]) entities.set((0, Utils_1.getPeerId)(x), x);
			const messages = this.reverse ? r.messages.reverse() : r.messages;
			for (const message of messages) {
				if (!this._messageInRange(message)) return true;
				this.lastId = message.id;
				try {
					message._finishInit(this.client, entities, this.entity);
				} catch (e) {}
				message._entities = entities;
				(_a = this.buffer) === null || _a === void 0 || _a.push(message);
			}
			if (r.messages.length < this.request.limit) return true;
			if (this.buffer) this._updateOffset(this.buffer[this.buffer.length - 1], r);
			else return true;
		}
		_messageInRange(message) {
			if (this.entity) {
				if (this.reverse) {
					if (message.id <= this.lastId || message.id >= this.maxId) return false;
				} else if (message.id >= this.lastId || message.id <= this.minId) return false;
			}
			return true;
		}
		[Symbol.asyncIterator]() {
			return super[Symbol.asyncIterator]();
		}
		_updateOffset(lastMessage, response) {
			if (!this.request) throw new Error("Request not set yet");
			this.request.offsetId = Number(lastMessage.id);
			if (this.reverse) this.request.offsetId += 1;
			if (this.request instanceof tl_1.Api.messages.Search) this.request.maxDate = -1;
			else if (!(this.request instanceof tl_1.Api.messages.SearchGlobal)) this.request.offsetDate = lastMessage.date;
			if (this.request instanceof tl_1.Api.messages.SearchGlobal) {
				if (lastMessage.inputChat) this.request.offsetPeer = lastMessage.inputChat;
				else this.request.offsetPeer = new tl_1.Api.InputPeerEmpty();
				this.request.offsetRate = response.nextRate;
			}
		}
	};
	exports._MessagesIter = _MessagesIter;
	var _IDsIter = class extends requestIter_1.RequestIter {
		async _init({ entity, ids }) {
			this.total = ids.length;
			this._ids = this.reverse ? ids.reverse() : ids;
			this._offset = 0;
			this._entity = entity ? await this.client.getInputEntity(entity) : void 0;
			this._ty = this._entity ? (0, Helpers_1._entityType)(this._entity) : void 0;
			if (!this.waitTime) this.waitTime = this.limit > 300 ? 10 : 0;
		}
		[Symbol.asyncIterator]() {
			return super[Symbol.asyncIterator]();
		}
		async _loadNextChunk() {
			var _a, _b, _c;
			const ids = this._ids.slice(this._offset, this._offset + _MAX_CHUNK_SIZE);
			if (!ids.length) return false;
			this._offset += _MAX_CHUNK_SIZE;
			let fromId;
			let r;
			if (this._ty == Helpers_1._EntityType.CHANNEL) try {
				r = await this.client.invoke(new tl_1.Api.channels.GetMessages({
					channel: this._entity,
					id: ids
				}));
			} catch (e) {
				if (e.errorMessage == "MESSAGE_IDS_EMPTY") r = new tl_1.Api.messages.MessagesNotModified({ count: ids.length });
				else throw e;
			}
			else {
				r = await this.client.invoke(new tl_1.Api.messages.GetMessages({ id: ids }));
				if (this._entity) fromId = await (0, users_1._getPeer)(this.client, this._entity);
			}
			if (r instanceof tl_1.Api.messages.MessagesNotModified) {
				(_a = this.buffer) === null || _a === void 0 || _a.push(...Array(ids.length));
				return;
			}
			const entities = /* @__PURE__ */ new Map();
			for (const entity of [...r.users, ...r.chats]) entities.set(__1.utils.getPeerId(entity), entity);
			let message;
			for (message of r.messages) if (message instanceof tl_1.Api.MessageEmpty || fromId && __1.utils.getPeerId(message.peerId) != __1.utils.getPeerId(fromId)) (_b = this.buffer) === null || _b === void 0 || _b.push(void 0);
			else {
				const temp = message;
				temp._finishInit(this.client, entities, this._entity);
				temp._entities = entities;
				(_c = this.buffer) === null || _c === void 0 || _c.push(temp);
			}
		}
	};
	exports._IDsIter = _IDsIter;
	var IterMessagesDefaults = {
		limit: void 0,
		offsetDate: void 0,
		offsetId: 0,
		maxId: 0,
		minId: 0,
		addOffset: 0,
		search: void 0,
		filter: void 0,
		fromUser: void 0,
		waitTime: void 0,
		ids: void 0,
		reverse: false,
		replyTo: void 0,
		scheduled: false
	};
	/** @hidden */
	function iterMessages(client, entity, options) {
		const { limit, offsetDate, offsetId, maxId, minId, addOffset, search, filter, fromUser, waitTime, ids, reverse, replyTo } = Object.assign(Object.assign({}, IterMessagesDefaults), options);
		if (ids) {
			let idsArray;
			if (!(0, Helpers_1.isArrayLike)(ids)) idsArray = [ids];
			else idsArray = ids;
			return new _IDsIter(client, idsArray.length, {
				reverse,
				waitTime
			}, {
				entity,
				ids: idsArray
			});
		}
		return new _MessagesIter(client, limit, {
			waitTime,
			reverse
		}, {
			entity,
			offsetId,
			minId,
			maxId,
			fromUser,
			offsetDate,
			addOffset,
			filter,
			search,
			replyTo
		});
	}
	/** @hidden */
	async function getMessages(client, entity, params) {
		var _a, e_2, _b, _c;
		if (Object.keys(params).length == 1 && params.limit === void 0) {
			if (params.minId === void 0 && params.maxId === void 0) params.limit = void 0;
			else params.limit = 1;
		}
		const it = client.iterMessages(entity, params);
		const ids = params.ids;
		if (ids && !(0, Helpers_1.isArrayLike)(ids)) {
			try {
				for (var _d = true, it_1 = __asyncValues(it), it_1_1; it_1_1 = await it_1.next(), _a = it_1_1.done, !_a; _d = true) {
					_c = it_1_1.value;
					_d = false;
					return [_c];
				}
			} catch (e_2_1) {
				e_2 = { error: e_2_1 };
			} finally {
				try {
					if (!_d && !_a && (_b = it_1.return)) await _b.call(it_1);
				} finally {
					if (e_2) throw e_2.error;
				}
			}
			return [];
		}
		return await it.collect();
	}
	/** @hidden */
	async function sendMessage(client, entity, { message, replyTo, attributes, parseMode, formattingEntities, linkPreview = true, file, thumb, forceDocument, clearDraft, buttons, silent, supportStreaming, schedule, noforwards, commentTo, topMsgId } = {}) {
		if (file) return client.sendFile(entity, {
			file,
			caption: message ? typeof message == "string" ? message : message.message : "",
			forceDocument,
			clearDraft,
			replyTo,
			attributes,
			thumb,
			supportsStreaming: supportStreaming,
			parseMode,
			formattingEntities,
			silent,
			scheduleDate: schedule,
			buttons,
			noforwards,
			commentTo,
			topMsgId
		});
		entity = await client.getInputEntity(entity);
		if (commentTo != void 0) {
			const discussionData = await getCommentData(client, entity, commentTo);
			entity = discussionData.entity;
			replyTo = discussionData.replyTo;
		}
		let markup, request;
		let replyObject = void 0;
		if (replyTo != void 0) replyObject = new tl_1.Api.InputReplyToMessage({
			replyToMsgId: (0, Utils_1.getMessageId)(replyTo),
			topMsgId: (0, Utils_1.getMessageId)(topMsgId)
		});
		if (message && message instanceof tl_1.Api.Message) {
			if (buttons == void 0) markup = message.replyMarkup;
			else markup = client.buildReplyMarkup(buttons);
			if (silent == void 0) silent = message.silent;
			if (message.media && !(message.media instanceof tl_1.Api.MessageMediaWebPage)) return client.sendFile(entity, {
				file: message.media,
				caption: message.message,
				silent,
				replyTo,
				buttons: markup,
				formattingEntities: message.entities,
				scheduleDate: schedule
			});
			request = new tl_1.Api.messages.SendMessage({
				peer: entity,
				message: message.message || "",
				silent,
				replyTo: replyObject,
				replyMarkup: markup,
				entities: message.entities,
				clearDraft,
				noWebpage: !(message.media instanceof tl_1.Api.MessageMediaWebPage),
				scheduleDate: schedule,
				noforwards
			});
			message = message.message;
		} else {
			if (formattingEntities == void 0) [message, formattingEntities] = await (0, messageParse_1._parseMessageText)(client, message || "", parseMode);
			if (!message) throw new Error("The message cannot be empty unless a file is provided");
			request = new tl_1.Api.messages.SendMessage({
				peer: entity,
				message: message.toString(),
				entities: formattingEntities,
				noWebpage: !linkPreview,
				replyTo: replyObject,
				clearDraft,
				silent,
				replyMarkup: client.buildReplyMarkup(buttons),
				scheduleDate: schedule,
				noforwards
			});
		}
		const result = await client.invoke(request);
		if (result instanceof tl_1.Api.UpdateShortSentMessage) {
			const msg = new tl_1.Api.Message({
				id: result.id,
				peerId: await (0, users_1._getPeer)(client, entity),
				message,
				date: result.date,
				out: result.out,
				media: result.media,
				entities: result.entities,
				replyMarkup: request.replyMarkup,
				ttlPeriod: result.ttlPeriod
			});
			msg._finishInit(client, /* @__PURE__ */ new Map(), entity);
			return msg;
		}
		return client._getResponseMessage(request, result, entity);
	}
	/** @hidden */
	async function forwardMessages(client, entity, { messages, fromPeer, silent, schedule, noforwards, dropAuthor }) {
		if (!(0, Helpers_1.isArrayLike)(messages)) messages = [messages];
		entity = await client.getInputEntity(entity);
		let fromPeerId;
		if (fromPeer) {
			fromPeer = await client.getInputEntity(fromPeer);
			fromPeerId = await client.getPeerId(fromPeer);
		}
		const getKey = (m) => {
			if (m instanceof tl_1.Api.Message) return m.chatId;
			if ((0, Utils_1.parseID)(m)) {
				if (fromPeerId !== void 0) return fromPeerId;
				throw new Error("fromPeer must be given if integer IDs are used");
			} else throw new Error(`Cannot forward ${m}`);
		};
		const sent = [];
		for (let [chatId, chunk] of (0, Helpers_1.groupBy)(messages, getKey)) {
			let chat;
			let numbers = [];
			if (typeof chunk[0] == "number") {
				chat = fromPeer;
				numbers = chunk;
			} else {
				chat = await chunk[0].getInputChat();
				numbers = chunk.map((m) => m.id);
			}
			chunk.push();
			const request = new tl_1.Api.messages.ForwardMessages({
				fromPeer: chat,
				id: numbers,
				toPeer: entity,
				silent,
				scheduleDate: schedule,
				noforwards,
				dropAuthor
			});
			const result = await client.invoke(request);
			sent.push(client._getResponseMessage(request, result, entity));
		}
		return sent;
	}
	/** @hidden */
	async function editMessage(client, entity, { message, text, parseMode, formattingEntities, linkPreview = true, file, forceDocument, buttons, schedule }) {
		if (typeof message === "number" && typeof text === "undefined" && !file && !schedule) throw Error("You have to provide either file or text or schedule property.");
		entity = await client.getInputEntity(entity);
		let id;
		let markup;
		let entities;
		let inputMedia;
		if (file) {
			const { fileHandle, media, image } = await (0, uploads_1._fileToMedia)(client, {
				file,
				forceDocument
			});
			inputMedia = media;
		}
		if (message instanceof tl_1.Api.Message) {
			id = (0, Utils_1.getMessageId)(message);
			text = message.message;
			entities = message.entities;
			if (buttons == void 0) markup = message.replyMarkup;
			else markup = client.buildReplyMarkup(buttons);
			if (message.media) inputMedia = (0, Utils_1.getInputMedia)(message.media, { forceDocument });
		} else {
			if (typeof message !== "number") throw Error("editMessageParams.message must be either a number or a Api.Message type");
			id = message;
			if (formattingEntities == void 0) [text, entities] = await (0, messageParse_1._parseMessageText)(client, text || "", parseMode);
			else entities = formattingEntities;
			markup = client.buildReplyMarkup(buttons);
		}
		const request = new tl_1.Api.messages.EditMessage({
			peer: entity,
			id,
			message: text,
			noWebpage: !linkPreview,
			entities,
			media: inputMedia,
			replyMarkup: markup,
			scheduleDate: schedule
		});
		const result = await client.invoke(request);
		return client._getResponseMessage(request, result, entity);
	}
	/** @hidden */
	async function deleteMessages(client, entity, messageIds, { revoke = false }) {
		let ty = Helpers_1._EntityType.USER;
		if (entity) {
			entity = await client.getInputEntity(entity);
			ty = (0, Helpers_1._entityType)(entity);
		}
		const ids = [];
		for (const messageId of messageIds) if (messageId instanceof tl_1.Api.Message || messageId instanceof tl_1.Api.MessageService || messageId instanceof tl_1.Api.MessageEmpty) ids.push(messageId.id);
		else if (typeof messageId === "number") ids.push(messageId);
		else throw new Error(`Cannot convert ${messageId} to an integer`);
		const results = [];
		if (ty == Helpers_1._EntityType.CHANNEL) for (const chunk of __1.utils.chunks(ids)) results.push(client.invoke(new tl_1.Api.channels.DeleteMessages({
			channel: entity,
			id: chunk
		})));
		else for (const chunk of __1.utils.chunks(ids)) results.push(client.invoke(new tl_1.Api.messages.DeleteMessages({
			id: chunk,
			revoke
		})));
		return Promise.all(results);
	}
	/** @hidden */
	async function pinMessage(client, entity, message, pinMessageParams) {
		return await _pin(client, entity, message, false, pinMessageParams === null || pinMessageParams === void 0 ? void 0 : pinMessageParams.notify, pinMessageParams === null || pinMessageParams === void 0 ? void 0 : pinMessageParams.pmOneSide);
	}
	/** @hidden */
	async function unpinMessage(client, entity, message, unpinMessageParams) {
		return await _pin(client, entity, message, true, unpinMessageParams === null || unpinMessageParams === void 0 ? void 0 : unpinMessageParams.notify, unpinMessageParams === null || unpinMessageParams === void 0 ? void 0 : unpinMessageParams.pmOneSide);
	}
	/** @hidden */
	async function _pin(client, entity, message, unpin, notify = false, pmOneSide = false) {
		message = __1.utils.getMessageId(message) || 0;
		if (message === 0) return await client.invoke(new tl_1.Api.messages.UnpinAllMessages({ peer: entity }));
		entity = await client.getInputEntity(entity);
		const request = new tl_1.Api.messages.UpdatePinnedMessage({
			silent: !notify,
			unpin,
			pmOneside: pmOneSide,
			peer: entity,
			id: message
		});
		const result = await client.invoke(request);
		/**
		* Unpinning does not produce a service message.
		* Pinning a message that was already pinned also produces no service message.
		* Pinning a message in your own chat does not produce a service message,
		* but pinning on a private conversation with someone else does.
		*/
		if (unpin || !("updates" in result) || "updates" in result && !result.updates) return;
		return client._getResponseMessage(request, result, entity);
	}
	/** @hidden */
	async function markAsRead(client, entity, message, markAsReadParams) {
		let maxId = (markAsReadParams === null || markAsReadParams === void 0 ? void 0 : markAsReadParams.maxId) || 0;
		const maxIdIsUndefined = (markAsReadParams === null || markAsReadParams === void 0 ? void 0 : markAsReadParams.maxId) === void 0;
		if (maxIdIsUndefined) {
			if (message) {
				if (Array.isArray(message)) maxId = Math.max(...message.map((v) => __1.utils.getMessageId(v)));
				else maxId = __1.utils.getMessageId(message);
			}
		}
		entity = await client.getInputEntity(entity);
		if (markAsReadParams && !markAsReadParams.clearMentions) {
			await client.invoke(new tl_1.Api.messages.ReadMentions({ peer: entity }));
			if (maxIdIsUndefined && message === void 0) return true;
		}
		if ((0, Helpers_1._entityType)(entity) === Helpers_1._EntityType.CHANNEL) return await client.invoke(new tl_1.Api.channels.ReadHistory({
			channel: entity,
			maxId
		}));
		else {
			await client.invoke(new tl_1.Api.messages.ReadHistory({
				peer: entity,
				maxId
			}));
			return true;
		}
	}
	/** @hidden */
	async function getCommentData(client, entity, message) {
		const result = await client.invoke(new tl_1.Api.messages.GetDiscussionMessage({
			peer: entity,
			msgId: __1.utils.getMessageId(message)
		}));
		const relevantMessage = result.messages.reduce((p, c) => p && p.id < c.id ? p : c);
		let chat;
		for (const c of result.chats) if (relevantMessage.peerId instanceof tl_1.Api.PeerChannel && c.id.eq(relevantMessage.peerId.channelId)) {
			chat = c;
			break;
		}
		return {
			entity: __1.utils.getInputPeer(chat),
			replyTo: relevantMessage.id
		};
	}
}));
//#endregion
//#region node_modules/telegram/tl/custom/index.js
var require_custom = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ChatGetter = void 0;
	var chatGetter_1 = require_chatGetter();
	Object.defineProperty(exports, "ChatGetter", {
		enumerable: true,
		get: function() {
			return chatGetter_1.ChatGetter;
		}
	});
}));
//#endregion
//#region node_modules/telegram/events/common.js
var require_common = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.EventCommonSender = exports.EventCommon = exports.EventBuilder = void 0;
	exports._intoIdSet = _intoIdSet;
	var tl_1 = require_tl();
	var custom_1 = require_custom();
	var Helpers_1 = require_Helpers();
	var __1 = require_telegram();
	var senderGetter_1 = require_senderGetter();
	var big_integer_1 = __importDefault(require_BigInteger());
	var Utils_1 = require_Utils();
	/** @hidden */
	async function _intoIdSet(client, chats) {
		if (chats == void 0) return;
		if (!(0, Helpers_1.isArrayLike)(chats)) chats = [chats];
		const result = /* @__PURE__ */ new Set();
		for (let chat of chats) if (typeof chat == "number" || typeof chat == "bigint" || typeof chat == "string" && (0, Utils_1.parseID)(chat) || big_integer_1.default.isInstance(chat)) {
			chat = (0, Helpers_1.returnBigInt)(chat);
			if (chat.lesser(0)) result.add(chat.toString());
			else {
				result.add(__1.utils.getPeerId(new tl_1.Api.PeerUser({ userId: chat })));
				result.add(__1.utils.getPeerId(new tl_1.Api.PeerChat({ chatId: chat })));
				result.add(__1.utils.getPeerId(new tl_1.Api.PeerChannel({ channelId: chat })));
			}
		} else if (typeof chat == "object" && chat.SUBCLASS_OF_ID == 47470215) result.add(__1.utils.getPeerId(chat));
		else {
			chat = await client.getInputEntity(chat);
			if (chat instanceof tl_1.Api.InputPeerSelf) chat = await client.getMe(true);
			result.add(__1.utils.getPeerId(chat));
		}
		return Array.from(result);
	}
	/**
	* The common event builder, with builtin support to filter per chat.<br/>
	* All events inherit this.
	*/
	var EventBuilder = class {
		constructor(eventParams) {
			var _a;
			this.chats = (_a = eventParams.chats) === null || _a === void 0 ? void 0 : _a.map((x) => x.toString());
			this.blacklistChats = eventParams.blacklistChats || false;
			this.resolved = false;
			this.func = eventParams.func;
		}
		build(update, callback, selfId) {
			if (update) return update;
		}
		async resolve(client) {
			if (this.resolved) return;
			await this._resolve(client);
			this.resolved = true;
		}
		async _resolve(client) {
			this.chats = await _intoIdSet(client, this.chats);
		}
		filter(event) {
			if (!this.resolved) return;
			if (this.chats != void 0) {
				if (event.chatId == void 0) return;
				if (this.chats.includes(event.chatId.toString()) == this.blacklistChats) return;
			}
			if (this.func && !this.func(event)) return;
			return event;
		}
	};
	exports.EventBuilder = EventBuilder;
	var EventCommon = class extends custom_1.ChatGetter {
		constructor({ chatPeer = void 0, msgId = void 0, broadcast = void 0 }) {
			super();
			this._eventName = "Event";
			custom_1.ChatGetter.initChatClass(this, {
				chatPeer,
				broadcast
			});
			this._entities = /* @__PURE__ */ new Map();
			this._client = void 0;
			this._messageId = msgId;
		}
		_setClient(client) {
			this._client = client;
		}
		get client() {
			return this._client;
		}
	};
	exports.EventCommon = EventCommon;
	var EventCommonSender = class extends senderGetter_1.SenderGetter {
		constructor({ chatPeer = void 0, msgId = void 0, broadcast = void 0 }) {
			super();
			this._eventName = "Event";
			custom_1.ChatGetter.initChatClass(this, {
				chatPeer,
				broadcast
			});
			senderGetter_1.SenderGetter.initChatClass(this, {
				chatPeer,
				broadcast
			});
			this._entities = /* @__PURE__ */ new Map();
			this._client = void 0;
			this._messageId = msgId;
		}
		_setClient(client) {
			this._client = client;
		}
		get client() {
			return this._client;
		}
	};
	exports.EventCommonSender = EventCommonSender;
}));
//#endregion
//#region node_modules/telegram/events/Raw.js
var require_Raw = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Raw = void 0;
	var common_1 = require_common();
	/**
	* The RAW updates that telegram sends. these are {@link Api.TypeUpdate} objects.
	* The are useful to handle custom events that you need like user typing or games.
	* @example
	* ```ts
	* client.addEventHandler((update) => {
	*   console.log("Received new Update");
	*   console.log(update);
	* });
	* ```
	*/
	var Raw = class extends common_1.EventBuilder {
		constructor(params) {
			super({ func: params.func });
			this.types = params.types;
		}
		async resolve(client) {
			this.resolved = true;
		}
		build(update) {
			return update;
		}
		filter(event) {
			if (this.types) {
				let correct = false;
				for (const type of this.types) if (event instanceof type) {
					correct = true;
					break;
				}
				if (!correct) return;
			}
			return super.filter(event);
		}
	};
	exports.Raw = Raw;
}));
//#endregion
//#region node_modules/telegram/client/updates.js
var require_updates = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.StopPropagation = void 0;
	exports.on = on;
	exports.addEventHandler = addEventHandler;
	exports.removeEventHandler = removeEventHandler;
	exports.listEventHandlers = listEventHandlers;
	exports.catchUp = catchUp;
	exports._handleUpdate = _handleUpdate;
	exports._processUpdate = _processUpdate;
	exports._dispatchUpdate = _dispatchUpdate;
	exports._updateLoop = _updateLoop;
	var tl_1 = require_tl();
	var network_1 = require_network();
	var index_1 = require_telegram();
	var Helpers_1 = require_Helpers();
	var Logger_1 = require_Logger();
	var PING_INTERVAL = 9e3;
	var PING_TIMEOUT = 1e4;
	var PING_FAIL_ATTEMPTS = 3;
	var PING_FAIL_INTERVAL = 100;
	var PING_DISCONNECT_DELAY = 6e4;
	var PING_INTERVAL_TO_WAKE_UP = 5e3;
	var PING_WAKE_UP_TIMEOUT = 3e3;
	var PING_WAKE_UP_WARNING_TIMEOUT = 1e3;
	/**
	If this exception is raised in any of the handlers for a given event,
	it will stop the execution of all other registered event handlers.
	It can be seen as the ``StopIteration`` in a for loop but for events.
	*/
	var StopPropagation = class extends Error {};
	exports.StopPropagation = StopPropagation;
	/** @hidden */
	function on(client, event) {
		return (f) => {
			client.addEventHandler(f, event);
			return f;
		};
	}
	/** @hidden */
	function addEventHandler(client, callback, event) {
		if (event == void 0) {
			const raw = require_Raw().Raw;
			event = new raw({});
		}
		event.client = client;
		client._eventBuilders.push([event, callback]);
	}
	/** @hidden */
	function removeEventHandler(client, callback, event) {
		client._eventBuilders = client._eventBuilders.filter(function(item) {
			return item[0] !== event && item[1] !== callback;
		});
	}
	/** @hidden */
	function listEventHandlers(client) {
		return client._eventBuilders;
	}
	/** @hidden */
	function catchUp() {}
	/** @hidden */
	function _handleUpdate(client, update) {
		if (typeof update === "number") {
			if ([
				-1,
				0,
				1
			].includes(update)) {
				_dispatchUpdate(client, { update: new network_1.UpdateConnectionState(update) });
				return;
			}
		}
		client._entityCache.add(update);
		client.session.processEntities(update);
		if (update instanceof tl_1.Api.Updates || update instanceof tl_1.Api.UpdatesCombined) {
			const entities = /* @__PURE__ */ new Map();
			for (const x of [...update.users, ...update.chats]) entities.set(index_1.utils.getPeerId(x), x);
			for (const u of update.updates) _processUpdate(client, u, update.updates, entities);
		} else if (update instanceof tl_1.Api.UpdateShort) _processUpdate(client, update.update, null);
		else _processUpdate(client, update, null);
	}
	/** @hidden */
	function _processUpdate(client, update, others, entities) {
		update._entities = entities || /* @__PURE__ */ new Map();
		_dispatchUpdate(client, {
			update,
			others
		});
	}
	/** @hidden */
	async function _dispatchUpdate(client, args) {
		for (const [builder, callback] of client._eventBuilders) {
			if (!builder || !callback) continue;
			if (!builder.resolved) await builder.resolve(client);
			let event = args.update;
			if (event) {
				if (!client._selfInputPeer) try {
					await client.getMe(true);
				} catch (e) {}
				if (!(event instanceof network_1.UpdateConnectionState)) {}
				event = builder.build(event, callback, client._selfInputPeer ? (0, Helpers_1.returnBigInt)(client._selfInputPeer.userId) : void 0);
				if (event) {
					event._client = client;
					if ("_eventName" in event) {
						event._setClient(client);
						event.originalUpdate = args.update;
						event._entities = args.update._entities;
					}
					if (!await builder.filter(event)) continue;
					try {
						await callback(event);
					} catch (e) {
						if (e instanceof StopPropagation) break;
						if (client._errorHandler) await client._errorHandler(e);
						if (client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
					}
				}
			}
		}
	}
	/** @hidden */
	async function _updateLoop(client) {
		let lastPongAt;
		while (!client._destroyed) {
			await (0, Helpers_1.sleep)(PING_INTERVAL, true);
			if (client._destroyed) break;
			if (client._sender.isReconnecting || client._isSwitchingDc) {
				lastPongAt = void 0;
				continue;
			}
			try {
				const ping = () => {
					return client._sender.send(new tl_1.Api.PingDelayDisconnect({
						pingId: (0, Helpers_1.returnBigInt)((0, Helpers_1.getRandomInt)(Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER)),
						disconnectDelay: PING_DISCONNECT_DELAY
					}));
				};
				const lastInterval = lastPongAt ? Date.now() - lastPongAt : void 0;
				if (!lastInterval || lastInterval < PING_INTERVAL_TO_WAKE_UP) await attempts(() => timeout(ping, PING_TIMEOUT), PING_FAIL_ATTEMPTS, PING_FAIL_INTERVAL);
				else {
					let wakeUpWarningTimeout = setTimeout(() => {
						_handleUpdate(client, network_1.UpdateConnectionState.disconnected);
						wakeUpWarningTimeout = void 0;
					}, PING_WAKE_UP_WARNING_TIMEOUT);
					await timeout(ping, PING_WAKE_UP_TIMEOUT);
					if (wakeUpWarningTimeout) {
						clearTimeout(wakeUpWarningTimeout);
						wakeUpWarningTimeout = void 0;
					}
					_handleUpdate(client, network_1.UpdateConnectionState.connected);
				}
				lastPongAt = Date.now();
			} catch (err) {
				if (client._errorHandler) await client._errorHandler(err);
				if (client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(err);
				lastPongAt = void 0;
				if (client._sender.isReconnecting || client._isSwitchingDc) continue;
				client._sender.reconnect();
			}
			if (Date.now() - (client._lastRequest || 0) > 18e5) {
				try {
					await client.invoke(new tl_1.Api.updates.GetState());
				} catch (e) {}
				lastPongAt = void 0;
			}
		}
		await client.disconnect();
	}
	/** @hidden */
	async function attempts(cb, times, pause) {
		for (let i = 0; i < times; i++) try {
			return await cb();
		} catch (err) {
			if (i === times - 1) throw err;
			await (0, Helpers_1.sleep)(pause);
		}
	}
	/** @hidden */
	function timeout(cb, ms) {
		let isResolved = false;
		return Promise.race([cb(), (0, Helpers_1.sleep)(ms).then(() => isResolved ? void 0 : Promise.reject(/* @__PURE__ */ new Error("TIMEOUT")))]).finally(() => {
			isResolved = true;
		});
	}
}));
//#endregion
//#region node_modules/telegram/client/chats.js
var require_chats = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports._ParticipantsIter = void 0;
	exports.iterParticipants = iterParticipants;
	exports.getParticipants = getParticipants;
	exports.kickParticipant = kickParticipant;
	var Helpers_1 = require_Helpers();
	var requestIter_1 = require_requestIter();
	var __1 = require_telegram();
	var tl_1 = require_tl();
	var big_integer_1 = __importDefault(require_BigInteger());
	var inspect_1 = require_inspect();
	var Utils_1 = require_Utils();
	var _MAX_PARTICIPANTS_CHUNK_SIZE = 200;
	var _ChatAction = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, chat, action, params = {
			delay: 4,
			autoCancel: true
		}) {
			this._client = client;
			this._chat = chat;
			this._action = action;
			this._delay = params.delay;
			this.autoCancel = params.autoCancel;
			this._request = void 0;
			this._task = null;
			this._running = false;
		}
		async start() {
			this._request = new tl_1.Api.messages.SetTyping({
				peer: this._chat,
				action: this._action
			});
			this._running = true;
			this._update();
		}
		async stop() {
			this._running = false;
			if (this.autoCancel) await this._client.invoke(new tl_1.Api.messages.SetTyping({
				peer: this._chat,
				action: new tl_1.Api.SendMessageCancelAction()
			}));
		}
		async _update() {
			while (this._running) {
				if (this._request != void 0) await this._client.invoke(this._request);
				await (0, Helpers_1.sleep)(this._delay * 1e3);
			}
		}
		progress(current, total) {
			if ("progress" in this._action) this._action.progress = 100 * Math.round(current / total);
		}
	};
	_ChatAction._str_mapping = {
		typing: new tl_1.Api.SendMessageTypingAction(),
		contact: new tl_1.Api.SendMessageChooseContactAction(),
		game: new tl_1.Api.SendMessageGamePlayAction(),
		location: new tl_1.Api.SendMessageGeoLocationAction(),
		"record-audio": new tl_1.Api.SendMessageRecordAudioAction(),
		"record-voice": new tl_1.Api.SendMessageRecordAudioAction(),
		"record-round": new tl_1.Api.SendMessageRecordRoundAction(),
		"record-video": new tl_1.Api.SendMessageRecordVideoAction(),
		audio: new tl_1.Api.SendMessageUploadAudioAction({ progress: 1 }),
		voice: new tl_1.Api.SendMessageUploadAudioAction({ progress: 1 }),
		song: new tl_1.Api.SendMessageUploadAudioAction({ progress: 1 }),
		round: new tl_1.Api.SendMessageUploadRoundAction({ progress: 1 }),
		video: new tl_1.Api.SendMessageUploadVideoAction({ progress: 1 }),
		photo: new tl_1.Api.SendMessageUploadPhotoAction({ progress: 1 }),
		document: new tl_1.Api.SendMessageUploadDocumentAction({ progress: 1 }),
		file: new tl_1.Api.SendMessageUploadDocumentAction({ progress: 1 }),
		cancel: new tl_1.Api.SendMessageCancelAction()
	};
	var _ParticipantsIter = class extends requestIter_1.RequestIter {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		async _init({ entity, filter, offset, search, showTotal }) {
			var _a, _b;
			if (!offset) offset = 0;
			if (filter && filter.constructor === Function) {
				if ([
					tl_1.Api.ChannelParticipantsBanned,
					tl_1.Api.ChannelParticipantsKicked,
					tl_1.Api.ChannelParticipantsSearch,
					tl_1.Api.ChannelParticipantsContacts
				].includes(filter)) filter = new filter({ q: "" });
				else filter = new filter();
			}
			entity = await this.client.getInputEntity(entity);
			const ty = __1.helpers._entityType(entity);
			if (search && (filter || ty != __1.helpers._EntityType.CHANNEL)) {
				search = search.toLowerCase();
				this.filterEntity = (entity) => {
					return __1.utils.getDisplayName(entity).toLowerCase().includes(search) || ("username" in entity ? entity.username || "" : "").toLowerCase().includes(search);
				};
			} else this.filterEntity = (entity) => true;
			this.requests = [];
			if (ty == __1.helpers._EntityType.CHANNEL) {
				if (showTotal) {
					const channel = await this.client.invoke(new tl_1.Api.channels.GetFullChannel({ channel: entity }));
					if (!(channel.fullChat instanceof tl_1.Api.ChatFull)) this.total = channel.fullChat.participantsCount;
				}
				if (this.total && this.total <= 0) return false;
				this.requests.push(new tl_1.Api.channels.GetParticipants({
					channel: entity,
					filter: filter || new tl_1.Api.ChannelParticipantsSearch({ q: search || "" }),
					offset,
					limit: _MAX_PARTICIPANTS_CHUNK_SIZE,
					hash: big_integer_1.default.zero
				}));
			} else if (ty == __1.helpers._EntityType.CHAT) {
				if (!("chatId" in entity)) throw new Error("Found chat without id " + JSON.stringify(entity));
				const full = await this.client.invoke(new tl_1.Api.messages.GetFullChat({ chatId: entity.chatId }));
				if (full.fullChat instanceof tl_1.Api.ChatFull) {
					if (!(full.fullChat.participants instanceof tl_1.Api.ChatParticipantsForbidden)) this.total = full.fullChat.participants.participants.length;
					else {
						this.total = 0;
						return false;
					}
					const users = /* @__PURE__ */ new Map();
					for (const user of full.users) users.set(user.id.toString(), user);
					for (const participant of full.fullChat.participants.participants) {
						const user = users.get(participant.userId.toString());
						if (!this.filterEntity(user)) continue;
						user.participant = participant;
						(_a = this.buffer) === null || _a === void 0 || _a.push(user);
					}
					return true;
				}
			} else {
				this.total = 1;
				if (this.limit != 0) {
					const user = await this.client.getEntity(entity);
					if (this.filterEntity(user)) {
						user.participant = void 0;
						(_b = this.buffer) === null || _b === void 0 || _b.push(user);
					}
				}
				return true;
			}
		}
		async _loadNextChunk() {
			var _a, _b;
			if (!((_a = this.requests) === null || _a === void 0 ? void 0 : _a.length)) return true;
			this.requests[0].limit = Math.min(this.limit - this.requests[0].offset, _MAX_PARTICIPANTS_CHUNK_SIZE);
			const results = [];
			for (const request of this.requests) results.push(await this.client.invoke(request));
			for (let i = this.requests.length - 1; i >= 0; i--) {
				const participants = results[i];
				if (participants instanceof tl_1.Api.channels.ChannelParticipantsNotModified || !participants.users.length) {
					this.requests.splice(i, 1);
					continue;
				}
				this.requests[i].offset += participants.participants.length;
				const users = /* @__PURE__ */ new Map();
				for (const user of participants.users) users.set(user.id.toString(), user);
				for (const participant of participants.participants) {
					if (!("userId" in participant)) continue;
					const user = users.get(participant.userId.toString());
					if (this.filterEntity && !this.filterEntity(user)) continue;
					user.participant = participant;
					(_b = this.buffer) === null || _b === void 0 || _b.push(user);
				}
			}
		}
		[Symbol.asyncIterator]() {
			return super[Symbol.asyncIterator]();
		}
	};
	exports._ParticipantsIter = _ParticipantsIter;
	requestIter_1.RequestIter, inspect_1.inspect.custom;
	/** @hidden */
	function iterParticipants(client, entity, { limit, offset, search, filter, showTotal = true }) {
		return new _ParticipantsIter(client, limit !== null && limit !== void 0 ? limit : Number.MAX_SAFE_INTEGER, {}, {
			entity,
			filter,
			offset: offset !== null && offset !== void 0 ? offset : 0,
			search,
			showTotal
		});
	}
	/** @hidden */
	async function getParticipants(client, entity, params) {
		return await client.iterParticipants(entity, params).collect();
	}
	/** @hidden */
	async function kickParticipant(client, entity, participant) {
		const peer = await client.getInputEntity(entity);
		const user = await client.getInputEntity(participant);
		let resp;
		let request;
		const type = __1.helpers._entityType(peer);
		if (type === __1.helpers._EntityType.CHAT) {
			request = new tl_1.Api.messages.DeleteChatUser({
				chatId: (0, Helpers_1.returnBigInt)((0, Utils_1.getPeerId)(entity)),
				userId: (0, Helpers_1.returnBigInt)((0, Utils_1.getPeerId)(participant))
			});
			resp = await client.invoke(request);
		} else if (type === __1.helpers._EntityType.CHANNEL) {
			if (user instanceof tl_1.Api.InputPeerSelf) {
				request = new tl_1.Api.channels.LeaveChannel({ channel: peer });
				resp = await client.invoke(request);
			} else {
				request = new tl_1.Api.channels.EditBanned({
					channel: peer,
					participant: user,
					bannedRights: new tl_1.Api.ChatBannedRights({
						untilDate: 0,
						viewMessages: true
					})
				});
				resp = await client.invoke(request);
				await (0, Helpers_1.sleep)(500);
				await client.invoke(new tl_1.Api.channels.EditBanned({
					channel: peer,
					participant: user,
					bannedRights: new tl_1.Api.ChatBannedRights({ untilDate: 0 })
				}));
			}
		} else throw new Error("You must pass either a channel or a chat");
		return client._getResponseMessage(request, resp, entity);
	}
}));
//#endregion
//#region node_modules/telegram/tl/custom/draft.js
var require_draft = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Draft = void 0;
	var Utils_1 = require_Utils();
	var api_1 = require_api();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var Draft = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, entity, draft) {
			this._client = client;
			this._peer = (0, Utils_1.getPeer)(entity);
			this._entity = entity;
			this._inputEntity = entity ? (0, Utils_1.getInputPeer)(entity) : void 0;
			if (!draft || !(draft instanceof api_1.Api.DraftMessage)) draft = new api_1.Api.DraftMessage({
				message: "",
				date: -1
			});
			if (!(draft instanceof api_1.Api.DraftMessageEmpty)) {
				this.linkPreview = !draft.noWebpage;
				this._text = client.parseMode ? client.parseMode.unparse(draft.message, draft.entities || []) : draft.message;
				this._rawText = draft.message;
				this.date = draft.date;
				const replyTo = draft.replyTo;
				if (replyTo != void 0) {
					if ("replyToMsgId" in replyTo) this.replyToMsgId = replyTo.replyToMsgId;
				}
			}
		}
		get entity() {
			return this._entity;
		}
		get inputEntity() {
			if (!this._inputEntity) this._inputEntity = this._client._entityCache.get(this._peer);
			return this._inputEntity;
		}
	};
	exports.Draft = Draft;
}));
//#endregion
//#region node_modules/telegram/tl/custom/dialog.js
var require_dialog = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Dialog = void 0;
	var api_1 = require_api();
	var Utils_1 = require_Utils();
	var draft_1 = require_draft();
	var Helpers_1 = require_Helpers();
	var inspect_1 = require_inspect();
	var Dialog = class {
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		constructor(client, dialog, entities, message) {
			this._client = client;
			this.dialog = dialog;
			this.pinned = !!dialog.pinned;
			this.folderId = dialog.folderId;
			this.archived = dialog.folderId != void 0;
			this.message = message;
			this.date = this.message.date;
			this.entity = entities.get((0, Utils_1.getPeerId)(dialog.peer));
			this.inputEntity = (0, Utils_1.getInputPeer)(this.entity);
			if (this.entity) {
				this.id = (0, Helpers_1.returnBigInt)((0, Utils_1.getPeerId)(this.entity));
				this.name = this.title = (0, Utils_1.getDisplayName)(this.entity);
			}
			this.unreadCount = dialog.unreadCount;
			this.unreadMentionsCount = dialog.unreadMentionsCount;
			if (!this.entity) throw new Error("Entity not found for dialog");
			this.draft = new draft_1.Draft(client, this.entity, this.dialog.draft);
			this.isUser = this.entity instanceof api_1.Api.User;
			this.isGroup = !!(this.entity instanceof api_1.Api.Chat || this.entity instanceof api_1.Api.ChatForbidden || this.entity instanceof api_1.Api.Channel && this.entity.megagroup);
			this.isChannel = this.entity instanceof api_1.Api.Channel;
		}
	};
	exports.Dialog = Dialog;
}));
//#endregion
//#region node_modules/telegram/client/dialogs.js
var require_dialogs = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports._DialogsIter = void 0;
	exports.iterDialogs = iterDialogs;
	exports.getDialogs = getDialogs;
	var tl_1 = require_tl();
	var requestIter_1 = require_requestIter();
	var index_1 = require_telegram();
	var dialog_1 = require_dialog();
	var big_integer_1 = __importDefault(require_BigInteger());
	var Logger_1 = require_Logger();
	var _MAX_CHUNK_SIZE = 100;
	/**
	Get the key to get messages from a dialog.
	
	We cannot just use the message ID because channels share message IDs,
	and the peer ID is required to distinguish between them. But it is not
	necessary in small group chats and private chats.
	* @param {Api.TypePeer} [peer] the dialog peer
	* @param {number} [messageId] the message id
	* @return {[number,number]} the channel id and message id
	*/
	function _dialogMessageKey(peer, messageId) {
		return "" + [peer instanceof tl_1.Api.PeerChannel ? peer.channelId : void 0, messageId];
	}
	var _DialogsIter = class extends requestIter_1.RequestIter {
		async _init({ offsetDate, offsetId, offsetPeer, ignorePinned, ignoreMigrated, folder }) {
			this.request = new tl_1.Api.messages.GetDialogs({
				offsetDate,
				offsetId,
				offsetPeer,
				limit: 1,
				hash: big_integer_1.default.zero,
				excludePinned: ignorePinned,
				folderId: folder
			});
			if (this.limit <= 0) {
				const dialogs = await this.client.invoke(this.request);
				if ("count" in dialogs) this.total = dialogs.count;
				else this.total = dialogs.dialogs.length;
				return true;
			}
			this.seen = /* @__PURE__ */ new Set();
			this.offsetDate = offsetDate;
			this.ignoreMigrated = ignoreMigrated;
		}
		[Symbol.asyncIterator]() {
			return super[Symbol.asyncIterator]();
		}
		async _loadNextChunk() {
			var _a;
			if (!this.request || !this.seen || !this.buffer) return;
			this.request.limit = Math.min(this.left, _MAX_CHUNK_SIZE);
			const r = await this.client.invoke(this.request);
			if (r instanceof tl_1.Api.messages.DialogsNotModified) return;
			if ("count" in r) this.total = r.count;
			else this.total = r.dialogs.length;
			const entities = /* @__PURE__ */ new Map();
			const messages = /* @__PURE__ */ new Map();
			for (const entity of [...r.users, ...r.chats]) {
				if (entity instanceof tl_1.Api.UserEmpty || entity instanceof tl_1.Api.ChatEmpty) continue;
				entities.set(index_1.utils.getPeerId(entity), entity);
			}
			for (const m of r.messages) {
				let message = m;
				try {
					if (message && "_finishInit" in message) message._finishInit(this.client, entities, void 0);
				} catch (e) {
					console.log("msg", message);
					this.client._log.error("Got error while trying to finish init message with id " + m.id);
					if (this.client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
					if (this.client._errorHandler) await this.client._errorHandler(e);
				}
				messages.set(_dialogMessageKey(message.peerId, message.id), message);
			}
			for (const d of r.dialogs) {
				if (d instanceof tl_1.Api.DialogFolder) continue;
				const message = messages.get(_dialogMessageKey(d.peer, d.topMessage));
				if (this.offsetDate != void 0) {
					const date = message === null || message === void 0 ? void 0 : message.date;
					if (date == void 0 || date > this.offsetDate) continue;
				}
				const peerId = index_1.utils.getPeerId(d.peer);
				if (!this.seen.has(peerId)) {
					this.seen.add(peerId);
					if (!entities.has(peerId)) continue;
					const cd = new dialog_1.Dialog(this.client, d, entities, message);
					if (!this.ignoreMigrated || cd.entity != void 0 && "migratedTo" in cd.entity) this.buffer.push(cd);
				}
			}
			if (r.dialogs.length < this.request.limit || !(r instanceof tl_1.Api.messages.DialogsSlice)) return true;
			let lastMessage;
			for (let dialog of r.dialogs.reverse()) {
				lastMessage = messages.get(_dialogMessageKey(dialog.peer, dialog.topMessage));
				if (lastMessage) break;
			}
			this.request.excludePinned = true;
			this.request.offsetId = lastMessage ? lastMessage.id : 0;
			this.request.offsetDate = lastMessage ? lastMessage.date : 0;
			this.request.offsetPeer = (_a = this.buffer[this.buffer.length - 1]) === null || _a === void 0 ? void 0 : _a.inputEntity;
		}
	};
	exports._DialogsIter = _DialogsIter;
	/** @hidden */
	function iterDialogs(client, { limit = void 0, offsetDate = void 0, offsetId = 0, offsetPeer = new tl_1.Api.InputPeerEmpty(), ignorePinned = false, ignoreMigrated = false, folder = void 0, archived = void 0 }) {
		if (archived != void 0) folder = archived ? 1 : 0;
		return new _DialogsIter(client, limit, {}, {
			offsetDate,
			offsetId,
			offsetPeer,
			ignorePinned,
			ignoreMigrated,
			folder
		});
	}
	/** @hidden */
	async function getDialogs(client, params) {
		return await client.iterDialogs(params).collect();
	}
}));
//#endregion
//#region node_modules/telegram/client/2fa.js
var require__2fa = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.updateTwoFaSettings = updateTwoFaSettings;
	var Helpers_1 = require_Helpers();
	var Password_1 = require_Password();
	var tl_1 = require_tl();
	var index_1 = require_telegram();
	/**
	* Changes the 2FA settings of the logged in user.
	Note that this method may be *incredibly* slow depending on the
	prime numbers that must be used during the process to make sure
	that everything is safe.
	
	Has no effect if both current and new password are omitted.
	
	* @param client: The telegram client instance
	* @param isCheckPassword: Must be ``true`` if you want to check the current password
	* @param currentPassword: The current password, to authorize changing to ``new_password``.
	Must be set if changing existing 2FA settings.
	Must **not** be set if 2FA is currently disabled.
	Passing this by itself will remove 2FA (if correct).
	* @param newPassword: The password to set as 2FA.
	If 2FA was already enabled, ``currentPassword`` **must** be set.
	Leaving this blank or `undefined` will remove the password.
	* @param hint: Hint to be displayed by Telegram when it asks for 2FA.
	Must be set when changing or creating a new password.
	Has no effect if ``newPassword`` is not set.
	* @param email: Recovery and verification email. If present, you must also
	set `emailCodeCallback`, else it raises an Error.
	* @param emailCodeCallback: If an email is provided, a callback that returns the code sent
	to it must also be set. This callback may be asynchronous.
	It should return a string with the code. The length of the
	code will be passed to the callback as an input parameter.
	* @param onEmailCodeError: Called when an error happens while sending an email.
	
	If the callback returns an invalid code, it will raise an rpc error with the message
	``CODE_INVALID``
	
	* @returns Promise<void>
	* @throws this method can throw:
	"PASSWORD_HASH_INVALID" if you entered a wrong password (or set it to undefined).
	"EMAIL_INVALID" if the entered email is wrong
	"EMAIL_HASH_EXPIRED" if the user took too long to verify their email
	*/
	async function updateTwoFaSettings(client, { isCheckPassword, currentPassword, newPassword, hint = "", email, emailCodeCallback, onEmailCodeError }) {
		if (!newPassword && !currentPassword) throw new Error("Neither `currentPassword` nor `newPassword` is present");
		if (email && !(emailCodeCallback && onEmailCodeError)) throw new Error("`email` present without `emailCodeCallback` and `onEmailCodeError`");
		const pwd = await client.invoke(new tl_1.Api.account.GetPassword());
		if (!(pwd.newAlgo instanceof tl_1.Api.PasswordKdfAlgoUnknown)) pwd.newAlgo.salt1 = Buffer.concat([pwd.newAlgo.salt1, (0, Helpers_1.generateRandomBytes)(32)]);
		if (!pwd.hasPassword && currentPassword) currentPassword = void 0;
		const password = currentPassword ? await (0, Password_1.computeCheck)(pwd, currentPassword) : new tl_1.Api.InputCheckPasswordEmpty();
		if (isCheckPassword) {
			await client.invoke(new tl_1.Api.auth.CheckPassword({ password }));
			return;
		}
		if (pwd.newAlgo instanceof tl_1.Api.PasswordKdfAlgoUnknown) throw new Error("Unknown password encryption method");
		try {
			await client.invoke(new tl_1.Api.account.UpdatePasswordSettings({
				password,
				newSettings: new tl_1.Api.account.PasswordInputSettings({
					newAlgo: pwd.newAlgo,
					newPasswordHash: newPassword ? await (0, Password_1.computeDigest)(pwd.newAlgo, newPassword) : Buffer.alloc(0),
					hint,
					email,
					newSecureSettings: void 0
				})
			}));
		} catch (e) {
			if (e instanceof index_1.errors.EmailUnconfirmedError) while (true) try {
				const code = await emailCodeCallback(e.codeLength);
				if (!code) throw new Error("Code is empty");
				await client.invoke(new tl_1.Api.account.ConfirmPasswordEmail({ code }));
				break;
			} catch (err) {
				onEmailCodeError(err);
			}
			else throw e;
		}
	}
}));
//#endregion
//#region node_modules/telegram/events/NewMessage.js
var require_NewMessage = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NewMessageEvent = exports.NewMessage = void 0;
	var common_1 = require_common();
	var tl_1 = require_tl();
	var Logger_1 = require_Logger();
	/**
	* Occurs whenever a new text message or a message with media arrives.
	* @example
	* ```ts
	* async function eventPrint(event: NewMessageEvent) {
	* const message = event.message;
	*
	*   // Checks if it's a private message (from user or bot)
	*   if (event.isPrivate){
	*       // prints sender id
	*       console.log(message.senderId);
	*       // read message
	*       if (message.text == "hello"){
	*           const sender = await message.getSender();
	*           console.log("sender is",sender);
	*           await client.sendMessage(sender,{
	*               message:`hi your id is ${message.senderId}`
	*           });
	*       }
	*   }
	* }
	* // adds an event handler for new messages
	* client.addEventHandler(eventPrint, new NewMessage({}));
	* ```
	*/
	var NewMessage = class extends common_1.EventBuilder {
		constructor(newMessageParams = {}) {
			let { chats, func, incoming, outgoing, fromUsers, forwards, pattern, blacklistChats = false } = newMessageParams;
			if (incoming && outgoing) incoming = outgoing = void 0;
			else if (incoming != void 0 && outgoing == void 0) outgoing = !incoming;
			else if (outgoing != void 0 && incoming == void 0) incoming = !outgoing;
			else if (outgoing == false && incoming == false) throw new Error("Don't create an event handler if you don't want neither incoming nor outgoing!");
			super({
				chats,
				blacklistChats,
				func
			});
			this.incoming = incoming;
			this.outgoing = outgoing;
			this.fromUsers = fromUsers;
			this.forwards = forwards;
			this.pattern = pattern;
			this._noCheck = [
				incoming,
				outgoing,
				chats,
				pattern,
				fromUsers,
				forwards,
				func
			].every((v) => v == void 0);
		}
		async _resolve(client) {
			await super._resolve(client);
			this.fromUsers = await (0, common_1._intoIdSet)(client, this.fromUsers);
		}
		build(update, callback, selfId) {
			if (update instanceof tl_1.Api.UpdateNewMessage || update instanceof tl_1.Api.UpdateNewChannelMessage) {
				if (!(update.message instanceof tl_1.Api.Message)) return;
				const event = new NewMessageEvent(update.message, update);
				this.addAttributes(event);
				return event;
			} else if (update instanceof tl_1.Api.UpdateShortMessage) return new NewMessageEvent(new tl_1.Api.Message({
				out: update.out,
				mentioned: update.mentioned,
				mediaUnread: update.mediaUnread,
				silent: update.silent,
				id: update.id,
				peerId: new tl_1.Api.PeerUser({ userId: update.userId }),
				fromId: new tl_1.Api.PeerUser({ userId: update.out ? selfId : update.userId }),
				message: update.message,
				date: update.date,
				fwdFrom: update.fwdFrom,
				viaBotId: update.viaBotId,
				replyTo: update.replyTo,
				entities: update.entities,
				ttlPeriod: update.ttlPeriod
			}), update);
			else if (update instanceof tl_1.Api.UpdateShortChatMessage) return new NewMessageEvent(new tl_1.Api.Message({
				out: update.out,
				mentioned: update.mentioned,
				mediaUnread: update.mediaUnread,
				silent: update.silent,
				id: update.id,
				peerId: new tl_1.Api.PeerChat({ chatId: update.chatId }),
				fromId: new tl_1.Api.PeerUser({ userId: update.out ? selfId : update.fromId }),
				message: update.message,
				date: update.date,
				fwdFrom: update.fwdFrom,
				viaBotId: update.viaBotId,
				replyTo: update.replyTo,
				entities: update.entities,
				ttlPeriod: update.ttlPeriod
			}), update);
		}
		filter(event) {
			var _a;
			if (this._noCheck) return event;
			if (this.incoming && event.message.out) return;
			if (this.outgoing && !event.message.out) return;
			if (this.forwards != void 0) {
				if (this.forwards != !!event.message.fwdFrom) return;
			}
			if (this.fromUsers != void 0) {
				if (!event.message.senderId || !this.fromUsers.includes(event.message.senderId.toString())) return;
			}
			if (this.pattern) {
				const match = (_a = event.message.message) === null || _a === void 0 ? void 0 : _a.match(this.pattern);
				if (!match) return;
				event.message.patternMatch = match;
			}
			return super.filter(event);
		}
		addAttributes(update) {}
	};
	exports.NewMessage = NewMessage;
	var NewMessageEvent = class extends common_1.EventCommon {
		constructor(message, originalUpdate) {
			super({
				msgId: message.id,
				chatPeer: message.peerId,
				broadcast: message.post
			});
			this.originalUpdate = originalUpdate;
			this.message = message;
		}
		_setClient(client) {
			super._setClient(client);
			const m = this.message;
			try {
				m._finishInit(client, this.originalUpdate._entities || /* @__PURE__ */ new Map(), void 0);
			} catch (e) {
				client._log.error("Got error while trying to finish init message with id " + m.id);
				if (client._errorHandler) client._errorHandler(e);
				if (client._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
			}
		}
	};
	exports.NewMessageEvent = NewMessageEvent;
}));
//#endregion
//#region node_modules/telegram/events/index.js
var require_events = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.NewMessageEvent = exports.NewMessage = exports.Raw = void 0;
	var Raw_1 = require_Raw();
	Object.defineProperty(exports, "Raw", {
		enumerable: true,
		get: function() {
			return Raw_1.Raw;
		}
	});
	var NewMessage_1 = require_NewMessage();
	Object.defineProperty(exports, "NewMessage", {
		enumerable: true,
		get: function() {
			return NewMessage_1.NewMessage;
		}
	});
	Object.defineProperty(exports, "NewMessageEvent", {
		enumerable: true,
		get: function() {
			return NewMessage_1.NewMessageEvent;
		}
	});
}));
//#endregion
//#region node_modules/telegram/client/TelegramClient.js
var require_TelegramClient = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.TelegramClient = void 0;
	var telegramBaseClient_1 = require_telegramBaseClient();
	var authMethods = __importStar(require_auth());
	var botMethods = __importStar(require_bots());
	var buttonsMethods = __importStar(require_buttons());
	var downloadMethods = __importStar(require_downloads());
	var parseMethods = __importStar(require_messageParse());
	var messageMethods = __importStar(require_messages());
	var updateMethods = __importStar(require_updates());
	var uploadMethods = __importStar(require_uploads());
	var userMethods = __importStar(require_users());
	var chatMethods = __importStar(require_chats());
	var dialogMethods = __importStar(require_dialogs());
	var twoFA = __importStar(require__2fa());
	var tl_1 = require_tl();
	var Utils_1 = require_Utils();
	var network_1 = require_network();
	var AllTLObjects_1 = require_AllTLObjects();
	var Helpers_1 = require_Helpers();
	var updates_1 = require_updates();
	var Logger_1 = require_Logger();
	var inspect_1 = require_inspect();
	var platform_1 = require_platform();
	/**
	* The TelegramClient uses several methods in different files to provide all the common functionality in a nice interface.</br>
	* **In short, to create a client you must do:**
	*
	* ```ts
	* import {TelegramClient} from "telegram";
	*
	* const client = new TelegramClient(new StringSession(''),apiId,apiHash,{});
	* ```
	*
	* You don't need to import any methods that are inside the TelegramClient class as they binding in it.
	*/
	var TelegramClient = class extends telegramBaseClient_1.TelegramBaseClient {
		/**
		* @param session - a session to be used to save the connection and auth key to. This can be a custom session that inherits MemorySession.
		* @param apiId - The API ID you obtained from https://my.telegram.org.
		* @param apiHash - The API hash you obtained from https://my.telegram.org.
		* @param clientParams - see {@link TelegramClientParams}
		*/
		constructor(session, apiId, apiHash, clientParams) {
			super(session, apiId, apiHash, clientParams);
		}
		/**
		* Used to handle all aspects of connecting to telegram.<br/>
		* This method will connect to the telegram servers and check if the user is already logged in.<br/>
		* in the case of a new connection this will sign in if the phone already exists or sign up otherwise<br/>
		* By using this method you are **agreeing to Telegram's Terms of Service** https://core.telegram.org/api/terms.<br/>
		* this method also calls {@link getMe} to tell telegram that we want to receive updates.<br/>
		* @param authParams - see UserAuthParams and BotAuthParams
		* @return nothing
		* @example
		* ```ts
		* // this example assumes you've installed and imported the input package. npm i input.
		* // This package uses CLI to receive input from the user. you can use your own callback function.
		* import { TelegramClient } from "telegram";
		* import { StringSession } from "telegram/sessions";
		*
		* const client = new TelegramClient(new StringSession(''), apiId, apiHash, {});
		* // logging in as a bot account
		* await client.start(botToken="123456:abcdfgh123456789);
		* // logging in as a user account
		* await client.start({
		*   phoneNumber: async () => await input.text("number ?"),
		*   password: async () => await input.text("password?"),
		*   phoneCode: async () => await input.text("Code ?"),
		*   onError: (err) => console.log(err),
		* });
		* >Number ? +1234567897
		* >Code ? 12345
		* >password ? 111111
		* Logged in as user...
		*
		* You can now use the client instance to call other api requests.
		*/
		start(authParams) {
			return authMethods.start(this, authParams);
		}
		/**
		* Checks whether the current client is authorized or not. (logged in as a user)
		* @example
		* ```ts
		* await client.connect();
		* if (await client.checkAuthorization()){
		*     console.log("I am logged in!");
		* }else{
		*     console.log("I am connected to telegram servers but not logged in with any account/bot");
		* }
		* ```
		* @return boolean (true of authorized else false)
		*/
		checkAuthorization() {
			return authMethods.checkAuthorization(this);
		}
		/**
		* Logs in as a user. Should only be used when not already logged in.<br/>
		* This method will send a code when needed.<br/>
		* This will also sign up if needed.
		* @example
		* ```ts
		* await client.connect();
		* // we should only use this when we are not already authorized.
		* // This function is very similar to `client.start`
		* // The minor difference that start checks if already authorized and supports bots as well.
		* if (!await client.checkAuthorization()){
		*     const phoneNumber = "+123456789";
		*     await client.signIn({
		*         apiId:132456,
		*         apiHash:"132456",
		*     },{
		*     phoneNumber: async () => await input.text("number ?"),
		*     password: async () => await input.text("password?"),
		*     phoneCode: async () => await input.text("Code ?"),
		*     onError: (err) => console.log(err),
		*     })
		*  }
		* ```
		* @param apiCredentials - credentials to be used.
		* @param authParams - user auth params.
		*/
		signInUser(apiCredentials, authParams) {
			return authMethods.signInUser(this, apiCredentials, authParams);
		}
		/**
		* logs the user using a QR code to be scanned.<br/>
		* this function generates the QR code that needs to be scanned by mobile.
		* @example
		* '''ts
		* await client.connect();
		* const user = await client.signInUserWithQrCode({ apiId, apiHash },
		* {
		*       onError: async function(p1: Error) {
		*           console.log("error", p1);
		*           // true = stop the authentication processes
		*           return true;
		*       },
		*       qrCode: async (code) => {
		*           console.log("Convert the next string to a QR code and scan it");
		*           console.log(
		*               `tg://login?token=${code.token.toString("base64url")}`
		*           );
		*       },
		*       password: async (hint) => {
		*           // password if needed
		*           return "1111";
		*       }
		*   }
		* );
		* console.log("user is", user);
		*
		* '''
		* @param apiCredentials - credentials to be used.
		* @param authParams - user auth params.
		*/
		signInUserWithQrCode(apiCredentials, authParams) {
			return authMethods.signInUserWithQrCode(this, apiCredentials, authParams);
		}
		/**
		* Sends a telegram authentication code to the phone number.
		* @example
		* ```ts
		* await client.connect();
		* const {phoneCodeHash,isCodeViaApp} = await client.sendCode({
		*     apiId:1234,
		*     apiHash:"123456789abcfghj",
		* },"+123456798"});
		* ```
		* @param apiCredentials - credentials to be used.
		* @param phoneNumber - the phone number to send the code to
		* @param forceSMS - whether to send it as an SMS or a normal in app message
		* @return the phone code hash and whether it was sent via app
		*/
		sendCode(apiCredentials, phoneNumber, forceSMS = false) {
			return authMethods.sendCode(this, apiCredentials, phoneNumber, forceSMS);
		}
		/**
		* Uses the 2FA password to sign in the account.<br/>
		* This function should be used after the user has signed in with the code they received.
		* @param apiCredentials - credentials to be used.
		* @param authParams - user auth params.
		* @returns the logged in user.
		*/
		signInWithPassword(apiCredentials, authParams) {
			return authMethods.signInWithPassword(this, apiCredentials, authParams);
		}
		/**
		* Used to sign in as a bot.
		* @example
		* ```ts
		* await client.connect();
		* const bot = await client.signInBot({
		*     apiId:1234,
		*     apiHash:"12345",
		* },{
		*     botToken:"123456:abcdfghae4fg654",
		* });
		* // we are now logged in as a bot
		* console.log("Logged in",bot);
		* ```
		* @param apiCredentials - credentials to be used.
		* @param authParams - user auth params.
		* @return instance User of the logged in bot.
		*/
		signInBot(apiCredentials, authParams) {
			return authMethods.signInBot(this, apiCredentials, authParams);
		}
		/**
		* Changes the 2FA settings of the logged in user.
		Note that this method may be *incredibly* slow depending on the
		prime numbers that must be used during the process to make sure
		that everything is safe.
		
		Has no effect if both current and new password are omitted.
		
		* @param client: The telegram client instance
		* @param isCheckPassword: Must be ``true`` if you want to check the current password
		* @param currentPassword: The current password, to authorize changing to ``new_password``.
		Must be set if changing existing 2FA settings.
		Must **not** be set if 2FA is currently disabled.
		Passing this by itself will remove 2FA (if correct).
		* @param newPassword: The password to set as 2FA.
		If 2FA was already enabled, ``currentPassword`` **must** be set.
		Leaving this blank or `undefined` will remove the password.
		* @param hint: Hint to be displayed by Telegram when it asks for 2FA.
		Must be set when changing or creating a new password.
		Has no effect if ``newPassword`` is not set.
		* @param email: Recovery and verification email. If present, you must also
		set `emailCodeCallback`, else it raises an Error.
		* @param emailCodeCallback: If an email is provided, a callback that returns the code sent
		to it must also be set. This callback may be asynchronous.
		It should return a string with the code. The length of the
		code will be passed to the callback as an input parameter.
		* @param onEmailCodeError: Called when an error happens while sending an email.
		
		If the callback returns an invalid code, it will raise an rpc error with the message
		``CODE_INVALID``
		
		* @returns Promise<void>
		* @throws this method can throw:
		"PASSWORD_HASH_INVALID" if you entered a wrong password (or set it to undefined).
		"EMAIL_INVALID" if the entered email is wrong
		"EMAIL_HASH_EXPIRED" if the user took too long to verify their email
		*/
		async updateTwoFaSettings({ isCheckPassword, currentPassword, newPassword, hint = "", email, emailCodeCallback, onEmailCodeError }) {
			return twoFA.updateTwoFaSettings(this, {
				isCheckPassword,
				currentPassword,
				newPassword,
				hint,
				email,
				emailCodeCallback,
				onEmailCodeError
			});
		}
		/**
		* Makes an inline query to the specified  bot and gets the result list.<br/>
		* This is equivalent to writing `@pic something` in clients
		* @param bot - the bot entity to which the inline query should be made
		* @param query - the query string that should be made for that bot (up to 512 characters). can be empty
		* @param entity - The entity where the inline query is being made from.<br/>
		* Certain bots use this to display different results depending on where it's used, such as private chats, groups or channels.<br/>
		* If specified, it will also be the default entity where the message will be sent after clicked.<br/>
		* Otherwise, the “empty peer” will be used, which some bots may not handle correctly.
		* @param offset - String offset of the results to be returned. can be empty
		* @param geoPoint - The geo point location information to send to the bot for localised results. Available under some bots.
		* @return a list of InlineResults
		* @example
		* ```ts
		* // Makes the query to @pic
		* const results = await client.inlineQuery("pic", "something");
		* // clicks on the first result
		* await results[0].click();
		* ```
		*/
		inlineQuery(bot, query, entity, offset, geoPoint) {
			return botMethods.inlineQuery(this, bot, query, entity, offset, geoPoint);
		}
		/**
		* Builds a ReplyInlineMarkup or ReplyKeyboardMarkup for the given buttons.<br/><br/>
		* Does nothing if either no buttons are provided or the provided argument is already a reply markup.<br/><br/>
		* this function is called internally when passing an array of buttons.
		
		* @param buttons - The button, array of buttons, array of array of buttons or markup to convert into a markup.
		* @param inlineOnly - Whether the buttons **must** be inline buttons only or not.
		* @example
		* ```ts
		* import {Button} from "telegram/tl/custom/button";
		*  // PS this function is not async
		* const markup = client.buildReplyMarkup(Button.inline("Hello!"));
		*
		* await client.sendMessage(chat, {
		*     message: "click me!",
		*     buttons: markup,
		* }
		*
		* // The following example can also be used in a simpler way like so
		*
		* await client.sendMessage(chat, {
		*     message: "click me!",
		*     buttons: [Button.inline("Hello!")],
		* }
		* ```
		*/
		buildReplyMarkup(buttons, inlineOnly = false) {
			return buttonsMethods.buildReplyMarkup(buttons, inlineOnly);
		}
		/**
		* Low-level method to download files from their input location.
		* downloadMedia should generally be used over this.
		* @param inputLocation - The file location from which the file will be downloaded. See getInputLocation source for a complete list of supported types.
		* @param fileParams - {@link DownloadFileParams}
		* @return a Buffer downloaded from the inputFile.
		* @example
		* ```ts
		* const photo = message.photo;
		* const buffer = await client.downloadFile(
		*       new Api.InputPhotoFileLocation({
		*          id: photo.id,
		*          accessHash: photo.accessHash,
		*          fileReference: photo.fileReference,
		*          thumbSize: size.type
		*      }),
		*      {
		*          dcId: photo.dcId,
		*          fileSize: "m",
		*      }
		* );
		* ```
		*/
		downloadFile(inputLocation, fileParams = {}) {
			return downloadMethods.downloadFileV2(this, inputLocation, fileParams);
		}
		/**
		* Iterates over a file download, yielding chunks of the file.
		* This method can be used to stream files in a more convenient way, since it offers more control (pausing, resuming, etc.)
		* @param iterFileParams - {@link IterDownloadFunction}
		* @return a Buffer downloaded from the inputFile.
		* @example
		* ```ts
		* const photo = message.photo;
		* for await (const chunk of client.iterDownload({
		*       file: new Api.InputPhotoFileLocation({
		*          id: photo.id,
		*          accessHash: photo.accessHash,
		*          fileReference: photo.fileReference,
		*          thumbSize: size.type
		*      }),
		*      offset: start,
		*      limit: end,
		*      requestSize:2048*1024
		* )){
		*     console.log("Downloaded chunk of size",chunk.length);
		* };
		* ```
		*/
		iterDownload(iterFileParams) {
			return downloadMethods.iterDownload(this, iterFileParams);
		}
		/**
		* Downloads the profile photo from the given user,chat or channel.<br/>
		* This method will return an empty buffer in case of no profile photo.
		* @param entity - where to download the photo from.
		* @param downloadProfilePhotoParams - {@link DownloadProfilePhotoParams}
		* @return buffer containing the profile photo. can be empty in case of no profile photo.
		* @example
		* ```ts
		* // Download your own profile photo
		* const buffer = await client.downloadProfilePhoto('me')
		* console.log("Downloaded image is",buffer);
		* // if you want to save it as a file you can use the fs module on node for that.
		* import { promises as fs } from 'fs';
		* await fs.writeFile("picture.jpg",buffer);
		* ```
		*/
		downloadProfilePhoto(entity, downloadProfilePhotoParams = { isBig: false }) {
			return downloadMethods.downloadProfilePhoto(this, entity, downloadProfilePhotoParams);
		}
		/**
		* Downloads the given media from a message or a media object.<br/>
		* this will return an empty Buffer in case of wrong or empty media.
		* @param messageOrMedia - instance of a message or a media.
		* @param downloadParams {@link DownloadMediaInterface}
		* @return a buffer containing the downloaded data if outputFile is undefined else nothing.
		* @example ```ts
		* const buffer = await client.downloadMedia(message, {})
		* // to save it to a file later on using fs.
		* import { promises as fs } from 'fs';
		* await fs.writeFile("file",buffer);
		* // to use a progress callback you can pass it like so.
		* const buffer = await client.downloadMedia(message, {
		*     progressCallback : console.log
		* })
		* ```
		*/
		downloadMedia(messageOrMedia, downloadParams) {
			return downloadMethods.downloadMedia(this, messageOrMedia, downloadParams === null || downloadParams === void 0 ? void 0 : downloadParams.outputFile, downloadParams === null || downloadParams === void 0 ? void 0 : downloadParams.thumb, downloadParams === null || downloadParams === void 0 ? void 0 : downloadParams.progressCallback);
		}
		/**
		* This property is the default parse mode used when sending messages. Defaults to {@link MarkdownParser}.<br/>
		* It will always be either undefined or an object with parse and unparse methods.<br/>
		* When setting a different value it should be one of:<br/>
		*<br/>
		*  - Object with parse and unparse methods.<br/>
		*  - A str indicating the parse_mode. For Markdown 'md' or 'markdown' may be used. For HTML, 'html' may be used.<br/>
		* The parse method should be a function accepting a single parameter, the text to parse, and returning a tuple consisting of (parsed message str, [MessageEntity instances]).<br/>
		* <br/>
		* The unparse method should be the inverse of parse such that text == unparse(parse(text)).<br/>
		* <br/>
		* See {@link Api.TypeMessageEntity} for allowed message entities.
		* @example
		* ```ts
		* // gets the current parse mode.
		* console.log("parse mode is :",  client.parseMode)
		* ```
		*/
		get parseMode() {
			return this._parseMode;
		}
		/** Setter for parseMode.
		* {@link parseMode}
		* @param mode can be md,markdown for Markdown or html for html. can also pass a custom mode.
		* pass undefined for no parsing.
		* @example
		* // sets the mode to HTML
		* client.setParseMode("html");
		* await client.sendMessage("me",{message:"<u>This is an underline text</u>"});
		* // disable formatting
		* client.setParseMode(undefined);
		* await client.sendMessage("me",{message:"<u> this will be sent as it is</u> ** with no formatting **});
		*/
		setParseMode(mode) {
			if (mode) this._parseMode = (0, Utils_1.sanitizeParseMode)(mode);
			else this._parseMode = void 0;
		}
		/**
		* Iterates over the messages for a given chat.
		* <br/>
		* The default order is from newest to oldest but can be changed with the reverse param.<br/>
		* If either `search`, `filter` or `fromUser` are provided this will use {@link Api.messages.Search} instead of {@link Api.messages.GetHistory}.
		* @remarks
		* Telegram limits GetHistory requests every 10 requests (1 000 messages) therefore a sleep of 1 seconds will be the default for this limit.
		* @param entity - The entity from whom to retrieve the message history.<br/>
		* It may be undefined to perform a global search, or to get messages by their ID from no particular chat<br/>
		* **Note** that some of the offsets will not work if this is the case.<br/>
		* **Note** that if you want to perform a global search, you must set a non-empty search string, a filter. or fromUser.
		* @param iterParams - {@link IterMessagesParams}
		* @yield Instances of custom {@link Message}
		* @example
		* ```ts
		* // From most-recent to oldest
		* for await (const message of client.iterMessages(chat,{}){
		*    console.log(message.id, message.text)
		* }
		*
		* // From oldest to most-recent
		* for await (const message of client.iterMessages(chat,{reverse:true}){
		*    console.log(message.id, message.text)
		* }
		*
		* // Filter by sender
		* for await (const message of client.iterMessages(chat,{fromUser:"me"}){
		*    console.log(message.id, message.text)
		* }
		*
		* // Server-side search with fuzzy text
		* for await (const message of client.iterMessages(chat,{search:"hello"}){
		*    console.log(message.id, message.text)
		* }
		*
		* // Filter by message type:
		* import { Api } from "telegram";
		* for await (const message of client.iterMessages(chat,{filter: Api.InputMessagesFilterPhotos}){
		*    console.log(message.id, message.photo)
		* }
		*
		* // Getting comments from a post in a channel:
		*  * for await (const message of client.iterMessages(chat,{replyTo: 123}){
		*    console.log(message.chat.title,, message.text)
		* }
		* ```
		*/
		iterMessages(entity, iterParams = {}) {
			return messageMethods.iterMessages(this, entity, iterParams);
		}
		/**
		* Same as iterMessages() but returns a TotalList instead.<br/>
		* if the `limit` is not set, it will be 1 by default unless both `minId` **and** `maxId` are set. in which case the entire  range will be returned.<br/>
		* @param entity - The entity from whom to retrieve the message history. see {@link iterMessages}.<br/>
		* @param getMessagesParams - see {@link IterMessagesParams}.
		* @return {@link TotalList} of messages.
		* @example
		* ```ts
		* // The totalList has a .total attribute which will show the complete number of messages even if none are fetched.
		* // Get 0 photos and print the total to show how many photos there are
		* import { Api } from "telegram";
		* const photos = await client.getMessages(chat, {limit: 0, filter:Api.InputMessagesFilterPhotos})
		* console.log(photos.total)
		*
		* // Get all the photos
		* const photos = await client.getMessages(chat, {limit: undefined, filter:Api.InputMessagesFilterPhotos})
		*
		// Get messages by ID:
		* const messages = await client.getMessages(chat, {ids:1337})
		* const message_1337 = messages[0];
		* ```
		*/
		getMessages(entity, getMessagesParams = {}) {
			return messageMethods.getMessages(this, entity, getMessagesParams);
		}
		/**
		* Sends a message to the specified user, chat or channel.<br/>
		* The default parse mode is the same as the official applications (a custom flavour of markdown). **bold**, `code` or __italic__ are available.<br/>
		* In addition you can send [links](https://example.com) and [mentions](@username) (or using IDs like in the Bot API: [mention](tg://user?id=123456789)) and pre blocks with three backticks.<br/>
		* <br/>
		* Sending a /start command with a parameter (like ?start=data) is also done through this method. Simply send '/start data' to the bot.<br/>
		* <br/>
		* See also Message.respond() and Message.reply().
		*
		* @param entity - Who to sent the message to.
		* @param sendMessageParams - see {@link SendMessageParams}
		* @return
		* The sent custom Message.
		* @example
		* ```ts
		* // Markdown is the default.
		* await client.sendMessage("me",{message:"Hello **world!**});
		*
		* // Defaults to another parse mode.
		* client.setParseMode("HTML");
		*
		* await client.sendMessage('me', {message:'Some <b>bold</b> and <i>italic</i> text'})
		* await client.sendMessage('me', {message:'An <a href="https://example.com">URL</a>'})
		* await client.sendMessage('me', {message:'<a href="tg://user?id=me">Mentions</a>'})
		*
		* // Explicit parse mode.
		* //  No parse mode by default
		* client.setParseMode(undefined);
		* //...but here I want markdown
		* await client.sendMessage('me', {message:'Hello, **world**!', {parseMode:"md"}})
		*
		* // ...and here I need HTML
		* await client.sendMessage('me', {message:'Hello, <i>world</i>!', {parseMode='html'}})
		*
		*
		* // Scheduling a message to be sent after 5 minutes
		*
		* await client.sendMessage(chat, {message:'Hi, future!', schedule:(60 * 5) + (Date.now() / 1000)})
		*
		* ```
		*/
		sendMessage(entity, sendMessageParams = {}) {
			return messageMethods.sendMessage(this, entity, sendMessageParams);
		}
		/**
		* Forwards the given messages to the specified entity.<br/>
		*<br/>
		* If you want to "forward" a message without the forward header
		* (the "forwarded from" text), you should use `sendMessage` with
		* the original message instead. This will send a copy of it.
		*<br/>
		* See also {@link Message.forwardTo}`.
		* @param entity - To which entity the message(s) will be forwarded.
		* @param forwardMessagesParams - see {@link ForwardMessagesParams}
		* @return The list of forwarded Message, Note.<br/>
		* if some messages failed to be forwarded the returned list will have them as undefined.
		* @example ```ts
		* // a single one
		* await client.forwardMessages(chat, {messages: message});
		* // or
		* await client.forwardMessages(chat, {messages:messageId,fromPeer:fromChat});
		* // or
		* await message.forwardTo(chat)
		*
		* // multiple
		* await client.forwardMessages(chat, {messages:messages});
		* // or
		* await client.forwardMessages(chat,  {messages:messageIds,fromPeer:fromChat});
		*
		* // Forwarding as a copy
		* await client.sendMessage(chat, {message:message});
		* ```
		*/
		forwardMessages(entity, forwardMessagesParams) {
			return messageMethods.forwardMessages(this, entity, forwardMessagesParams);
		}
		/**
		*  Used to edit a message by changing it's text or media
		*  message refers to the message to be edited not what to edit
		*  text refers to the new text
		*  See also Message.edit()<br/>
		*  Notes: It is not possible to edit the media of a message that doesn't contain media.
		*  @param entity - From which chat to edit the message.<br/>
		*  This can also be the message to be edited, and the entity will be inferred from it, so the next parameter will be assumed to be the message text.<br/>
		*  You may also pass a InputBotInlineMessageID, which is the only way to edit messages that were sent after the user selects an inline query result. Not supported yet!
		*  @param editMessageParams - see {@link EditMessageParams}.
		*  @return The edited Message.
		*  @throws
		*  `MESSAGE_AUTHOR_REQUIRED` if you're not the author of the message but tried editing it anyway.
		*  `MESSAGE_NOT_MODIFIED` if the contents of the message were not modified at all.
		*  `MESSAGE_ID_INVALID` if the ID of the message is invalid (the ID itself may be correct, but the message with that ID cannot be edited).<br/>
		*  For example, when trying to edit messages with a reply markup (or clear markup) this error will be raised.
		*  @example
		*  ```ts
		*  const message = await client.sendMessage(chat,{message:"Hi!"});
		*
		*  await client.editMessage(chat,{message:message,text:"Hello!"}
		*  // or
		*  await client.editMessage(chat,{message:message.id,text:"Hello!"}
		*  ```
		*/
		editMessage(entity, editMessageParams) {
			return messageMethods.editMessage(this, entity, editMessageParams);
		}
		/**
		* Deletes the given messages, optionally "for everyone".
		*
		* See also {@link Message.delete}`.
		*
		* @remarks This method does **not** validate that the message IDs belong to the chat that you passed! It's possible for the method to delete messages from different private chats and small group chats at once, so make sure to pass the right IDs.
		* @param entity - From who the message will be deleted. This can actually be `undefined` for normal chats, but **must** be present for channels and megagroups.
		* @param messageIds - The IDs (or ID) or messages to be deleted.
		* @param revoke - Whether the message should be deleted for everyone or not.
		* By default it has the opposite behaviour of official clients,
		* and it will delete the message for everyone.
		* Disabling this has no effect on channels or megagroups,
		* since it will unconditionally delete the message for everyone.
		* @return
		* A list of {@link AffectedMessages}, each item being the result for the delete calls of the messages in chunks of 100 each.
		* @example
		*  ```ts
		*  await client.deleteMessages(chat, messages);
		*
		*  await client.deleteMessages(chat, messages, {revoke:false});
		*  ```
		*/
		deleteMessages(entity, messageIds, { revoke = true }) {
			return messageMethods.deleteMessages(this, entity, messageIds, { revoke });
		}
		pinMessage(entity, message, pinMessageParams) {
			return messageMethods.pinMessage(this, entity, message, pinMessageParams);
		}
		unpinMessage(entity, message, unpinMessageParams) {
			return messageMethods.unpinMessage(this, entity, message, unpinMessageParams);
		}
		/**
		* Marks messages as read and optionally clears mentions. <br/>
		* This effectively marks a message as read (or more than one) in the given conversation. <br />
		* If a message or maximum ID is provided, all the messages up to and
		* including such ID will be marked as read (for all messages whose ID ≤ max_id).
		*
		* See also {@link Message.markRead}`.
		*
		* @remarks If neither message nor maximum ID are provided, all messages will be marked as read by assuming that `max_id = 0`.
		* @param entity - The chat where the message should be pinned.
		* @param message - The message or the message ID to pin. If it's `undefined`, all messages will be unpinned instead.
		* @param markAsReadParams - see {@link MarkAsReadParams}.
		* @return boolean
		* @example
		*  ```ts
		*  // using a Message object
		*  const message = await client.sendMessage(chat, 'GramJS is awesome!');
		*  await client.markAsRead(chat, message)
		*  // ...or using the int ID of a Message
		*  await client.markAsRead(chat, message.id);
		*
		*  // ...or passing a list of messages to mark as read
		*  await client.markAsRead(chat, messages)
		*  ```
		*/
		markAsRead(entity, message, markAsReadParams) {
			return messageMethods.markAsRead(this, entity, message, markAsReadParams);
		}
		/**
		* Iterator over the dialogs (open conversations/subscribed channels) sequentially.<br/>
		* The order is the same as the one seen in official applications. (dialogs that had recent messages come first)
		* @param iterDialogsParams - see {@link IterDialogsParams}
		* @yield instances of custom {@link Dialog}.
		* @example
		* ```ts
		* // logs all dialog IDs and their title.
		* for await (const dialog of client.iterDialogs({})){
		*     console.log(`${dialog.id}: ${dialog.title}`);
		* }
		* ```
		*/
		iterDialogs(iterDialogsParams = {}) {
			return dialogMethods.iterDialogs(this, iterDialogsParams);
		}
		/**
		* Same as iterDialogs but returns a TotalList instead of an iterator.
		* @param params - {@link IterDialogsParams}
		* @example
		* ```ts
		* // Get all open conversation, print the title of the first
		* const dialogs = await client.getDialogs({});
		* const first = dialogs[0];
		* console.log(first.title);
		* <br/>
		* // Use the dialog somewhere else
		* await client.sendMessage(first, {message: "hi"});
		* <br/>
		* // Getting only non-archived dialogs (both equivalent)
		* non_archived = await client.get_dialogs({folder:0})
		* non_archived = await client.get_dialogs({archived:false})
		* <br/>
		* // Getting only archived dialogs (both equivalent)
		* archived = await client.get_dialogs({folder:1})
		* archived = await client.get_dialogs({archived:true})
		* ```
		*/
		getDialogs(params = {}) {
			return dialogMethods.getDialogs(this, params);
		}
		/**
		* Iterates over the participants belonging to a specified chat , channel or supergroup.<br/>
		* <br/>
		* Channels can return a maximum of 200 users while supergroups can return up to 10 000.<br/>
		* You must be an admin to retrieve users from a channel.<br/>
		* @param entity - The entity from which to retrieve the participants list.
		* @param params - {@link IterParticipantsParams}
		* @remarks
		* The filter ChannelParticipantsBanned will return restricted users. If you want banned users you should use ChannelParticipantsKicked instead.
		* @yield The User objects returned by GetParticipants with an additional .participant attribute<br/>
		*     which is the matched ChannelParticipant type for channels/supergroup or ChatParticipants for normal chats.
		* @example
		* ```ts
		* // logs all user IDs in a chat.
		* for await (const user of client.iterParticipants(chat)){
		*     console.log("User id",user.id);
		* }
		*
		* // Searches by name.
		* for await (const user of client.iterParticipants(chat, {search: "name"})){
		*     console.log("Username is ",user.username); // Some users don't have a username so this can be undefined.
		* }
		*
		* // Filter by admins.
		* import { Api } from "telegram";
		*
		* for await (const user of client.iterParticipants(chat, {filter:  Api.ChannelParticipantsAdmins})){
		*     console.log("admin first name is ",user.firstName);
		* }
		* ```
		*/
		iterParticipants(entity, params = {}) {
			return chatMethods.iterParticipants(this, entity, params);
		}
		/**
		* Exact same as iterParticipants but returns a TotalList instead.<br/>
		* This can be used if you want to retrieve a list instead of iterating over the users.
		* @param entity - entity to get users from.
		* @param params - {@link IterParticipantsParams}.
		* @return
		*/
		getParticipants(entity, params = {}) {
			return chatMethods.getParticipants(this, entity, params);
		}
		/**
		* Kicks a user from a chat.
		*
		* Kicking yourself (`'me'`) will result in leaving the chat.
		*
		* @note
		* Attempting to kick someone who was banned will remove their
		* restrictions (and thus unbanning them), since kicking is just
		* ban + unban.
		*
		* @example
		* // Kick some user from some chat, and deleting the service message
		* const msg = await client.kickParticipant(chat, user);
		* await msg.delete();
		*
		* // Leaving chat
		* await client.kickParticipant(chat, 'me');
		*/
		kickParticipant(entity, participant) {
			return chatMethods.kickParticipant(this, entity, participant);
		}
		/** TODO */
		on(event) {
			return updateMethods.on(this, event);
		}
		addEventHandler(callback, event) {
			return updateMethods.addEventHandler(this, callback, event);
		}
		/**
		* Inverse operation of addEventHandler().<br>
		*
		* @param callback - the callback function to be removed.
		* @param event - the type of the event.
		*/
		removeEventHandler(callback, event) {
			return updateMethods.removeEventHandler(this, callback, event);
		}
		/**
		* Lists all registered event handlers.
		* @return pair of [eventBuilder,CallableFunction]
		*/
		listEventHandlers() {
			return updateMethods.listEventHandlers(this);
		}
		/**
		* Uploads a file to Telegram's servers, without sending it.
		* @remarks generally it's better to use {@link sendFile} instead.
		* This method returns a handle (an instance of InputFile or InputFileBig, as required) which can be later used before it expires (they are usable during less than a day).<br/>
		* Uploading a file will simply return a "handle" to the file stored remotely in the Telegram servers,
		* which can be later used on. This will not upload the file to your own chat or any chat at all.
		* This also can be used to update profile pictures
		* @param fileParams see {@link UploadFileParams}
		* @return {@link Api.InputFileBig} if the file size is larger than 10mb otherwise {@link Api.InputFile}
		* @example
		* ```ts
		* import { CustomFile } from "telegram/client/uploads";
		* const toUpload = new CustomFile("photo.jpg", fs.statSync("../photo.jpg").size, "../photo.jpg");
		* const file = await client.uploadFile({
		*  file: toUpload,
		*  workers: 1,
		*  });
		*  await client.invoke(new Api.photos.UploadProfilePhoto({
		*      file: file,
		*  }));
		* ```
		*/
		uploadFile(fileParams) {
			return uploadMethods.uploadFile(this, fileParams);
		}
		/**
		* Sends message with the given file to the specified entity.
		* This uses {@link uploadFile} internally so if you want more control over uploads you can use that.
		* @param entity - who will receive the file.
		* @param sendFileParams - see {@link SendFileInterface}
		* @example
		* ```
		* // Normal files like photos
		* await client.sendFile(chat, {file:'/my/photos/me.jpg', caption:"It's me!"})
		* // or
		* await client.sendMessage(chat, {message:"It's me!", file:'/my/photos/me.jpg'})
		*
		* Voice notes or round videos
		* await client.sendFile(chat, {file: '/my/songs/song.mp3', voiceNote:True})
		* await client.sendFile(chat, {file: '/my/videos/video.mp4', videoNote:True})
		*
		* // Custom thumbnails
		* await client.sendFile(chat, {file:'/my/documents/doc.txt', thumb:'photo.jpg'})
		*
		* // Only documents
		* await client.sendFile(chat, {file:'/my/photos/photo.png', forceDocument:True})
		*
		* //logging progress
		* await client.sendFile(chat, {file: file, progressCallback=console.log})
		*
		* // Dices, including dart and other future emoji
		* await client.sendFile(chat, {file:new Api.InputMediaDice("")})
		* await client.sendFile(chat, {file:new Api.InputMediaDice("🎯")})
		*
		* // Contacts
		* await client.sendFile(chat, {file: new Api.InputMediaContact({
		*  phoneNumber:'+1 123 456 789',
		*  firstName:'Example',
		*  lastName:'',
		*  vcard:''
		*  }))
		* ```
		*/
		sendFile(entity, sendFileParams) {
			return uploadMethods.sendFile(this, entity, sendFileParams);
		}
		/**
		* invokes raw Telegram requests.<br/>
		* This is a low level method that can be used to call manually any Telegram API method.<br/>
		* Generally this should only be used when there isn't a friendly method that does what you need.<br/>
		* All available requests and types are found under the `Api.` namespace.
		* @param request - The request to send. this should be of type request.
		* @param dcId - Optional dc id to use when sending.
		* @return The response from Telegram.
		* @example
		* ```ts
		* //
		* const result = await client.invoke(new Api.account.CheckUsername({
		*      username: 'some string here'
		*   }));
		* console.log("does this username exist?",result);
		*
		* ```
		*/
		invoke(request, dcId) {
			return userMethods.invoke(this, request, dcId);
		}
		invokeWithSender(request, sender) {
			return userMethods.invoke(this, request, void 0, sender);
		}
		getMe(inputPeer = false) {
			return userMethods.getMe(this, inputPeer);
		}
		/**
		* Return true if the signed-in user is a bot, false otherwise.
		* @example
		* ```ts
		* if (await client.isBot()){
		*     console.log("I am a bot. PI is 3.14159265359);
		* } else {
		*     console.log("I am a human. Pies are delicious);
		* }
		* ```
		*/
		isBot() {
			return userMethods.isBot(this);
		}
		/**
		* Returns true if the user is authorized (logged in).
		* @example
		* if (await client.isUserAuthorized()){
		*     console.log("I am authorized. I can call functions and use requests");
		* }else{
		*     console.log("I am not logged in. I need to sign in first before being able to call methods");
		* }
		*/
		isUserAuthorized() {
			return userMethods.isUserAuthorized(this);
		}
		getEntity(entity) {
			return userMethods.getEntity(this, entity);
		}
		/**
		* Turns the given entity into its input entity version.<br/>
		* Almost all requests use this kind of InputPeer, so this is the most suitable call to make for those cases.<br/>
		* **Generally you should let the library do its job** and don't worry about getting the input entity first, but if you're going to use an entity often, consider making the call.
		* @param entity - If a username or invite link is given, the library will use the cache.<br/>
		* This means that it's possible to be using a username that changed or an old invite link (this only happens if an invite link for a small group chat is used after it was upgraded to a mega-group).
		*<br/>
		*  - If the username or ID from the invite link is not found in the cache, it will be fetched. The same rules apply to phone numbers ('+34 123456789') from people in your contact list.
		*<br/>
		*  - If an exact name is given, it must be in the cache too. This is not reliable as different people can share the same name and which entity is returned is arbitrary,<br/>
		*  and should be used only for quick tests.
		*<br/>
		*  - If a positive integer ID is given, the entity will be searched in cached users, chats or channels, without making any call.
		*<br/>
		*  - If a negative integer ID is given, the entity will be searched exactly as either a chat (prefixed with -) or as a channel (prefixed with -100).
		*<br/>
		*  - If a Peer is given, it will be searched exactly in the cache as either a user, chat or channel.
		*<br/>
		*  - If the given object can be turned into an input entity directly, said operation will be done.
		*<br/>
		*  -If the entity can't be found, this will throw an error.
		* @return
		* {@link Api.InputPeerUser} , {@link Api.InputPeerChat} , {@link Api.InputPeerChannel} or {@link Api.InputPeerSelf} if the parameter  is "me" or "self"
		* @example
		* ```ts
		* // If you're going to use "username" often in your code
		* // (make a lot of calls), consider getting its input entity
		* // once, and then using the "user" everywhere instead.
		* user = await client.getInputEntity('username')
		*
		* // The same applies to IDs, chats or channels.
		* chat = await client.getInputEntity(-123456789)
		* ```
		*/
		getInputEntity(entity) {
			return userMethods.getInputEntity(this, entity);
		}
		/**
		* Gets the ID for the given entity.<br/>
		* This method needs to be async because peer supports usernames, invite-links, phone numbers (from people in your contact list), etc.<br/>
		* <br/>
		* If addMark is false, then a positive ID will be returned instead. By default, bot-API style IDs (signed) are returned.
		* @param peer
		* @param addMark - whether to return a bot api style id.
		* @return the ID of the entity.
		* @example
		* ```ts
		* console.log(await client.getPeerId("me"));
		* ```
		*/
		getPeerId(peer, addMark = true) {
			return userMethods.getPeerId(this, peer, addMark);
		}
		/** @hidden */
		_getInputDialog(peer) {
			return userMethods._getInputDialog(this, peer);
		}
		/** @hidden */
		_getInputNotify(notify) {
			return userMethods._getInputNotify(this, notify);
		}
		/** @hidden */
		async _handleReconnect() {
			this._log.info("Handling reconnect!");
			try {
				await this.getMe();
			} catch (e) {
				this._log.error(`Error while trying to reconnect`);
				if (this._errorHandler) await this._errorHandler(e);
				if (this._log.canSend(Logger_1.LogLevel.ERROR)) console.error(e);
			}
		}
		async connect() {
			await this._initSession();
			if (this._sender === void 0) this._sender = new network_1.MTProtoSender(this.session.getAuthKey(), {
				logger: this._log,
				dcId: this.session.dcId || 4,
				retries: this._connectionRetries,
				delay: this._retryDelay,
				autoReconnect: this._autoReconnect,
				connectTimeout: this._timeout,
				authKeyCallback: this._authKeyCallback.bind(this),
				updateCallback: updates_1._handleUpdate.bind(this),
				isMainSender: true,
				client: this,
				securityChecks: this._securityChecks,
				autoReconnectCallback: this._handleReconnect.bind(this),
				_exportedSenderPromises: this._exportedSenderPromises,
				reconnectRetries: this._reconnectRetries
			});
			const connection = new this._connection({
				ip: this.session.serverAddress,
				port: this.useWSS ? 443 : 80,
				dcId: this.session.dcId,
				loggers: this._log,
				proxy: this._proxy,
				socket: this.networkSocket,
				testServers: this.testServers
			});
			if (!await this._sender.connect(connection, false)) {
				if (!this._loopStarted) {
					(0, updates_1._updateLoop)(this);
					this._loopStarted = true;
				}
				return false;
			}
			this.session.setAuthKey(this._sender.authKey);
			this.session.save();
			this._initRequest.query = new tl_1.Api.help.GetConfig();
			this._log.info(`Using LAYER ${AllTLObjects_1.LAYER} for initial connect`);
			await this._sender.send(new tl_1.Api.InvokeWithLayer({
				layer: AllTLObjects_1.LAYER,
				query: this._initRequest
			}));
			if (!this._loopStarted) {
				(0, updates_1._updateLoop)(this);
				this._loopStarted = true;
			}
			this._connectedDeferred.resolve();
			this._isSwitchingDc = false;
			return true;
		}
		/** @hidden */
		async _switchDC(newDc) {
			this._log.info(`Reconnecting to new data center ${newDc}`);
			const DC = await this.getDC(newDc);
			this.session.setDC(newDc, DC.ipAddress, DC.port);
			await this._sender.authKey.setKey(void 0);
			this.session.setAuthKey(void 0);
			this.session.save();
			this._isSwitchingDc = true;
			await this._disconnect();
			this._sender = void 0;
			return await this.connect();
		}
		/**
		* Returns the DC ip in case of node or the DC web address in case of browser.<br/>
		* This will do an API request to fill the cache if it's the first time it's called.
		* @param dcId The DC ID.
		* @param downloadDC whether to use -1 DCs or not
		* @param web if true this will get the web DCs.
		* TODO, hardcode IPs.
		* (These only support downloading/uploading and not creating a new AUTH key)
		*/
		async getDC(dcId, downloadDC = false, web = false) {
			this._log.debug(`Getting DC ${dcId}`);
			if (!platform_1.isNode || web) switch (dcId) {
				case 1: return {
					id: 1,
					ipAddress: `pluto${downloadDC ? "-1" : ""}.web.telegram.org`,
					port: 443
				};
				case 2: return {
					id: 2,
					ipAddress: `venus${downloadDC ? "-1" : ""}.web.telegram.org`,
					port: 443
				};
				case 3: return {
					id: 3,
					ipAddress: `aurora${downloadDC ? "-1" : ""}.web.telegram.org`,
					port: 443
				};
				case 4: return {
					id: 4,
					ipAddress: `vesta${downloadDC ? "-1" : ""}.web.telegram.org`,
					port: 443
				};
				case 5: return {
					id: 5,
					ipAddress: `flora${downloadDC ? "-1" : ""}.web.telegram.org`,
					port: 443
				};
				default: throw new Error(`Cannot find the DC with the ID of ${dcId}`);
			}
			if (!this._config) this._config = await this.invoke(new tl_1.Api.help.GetConfig());
			for (const DC of this._config.dcOptions) if (DC.id === dcId && !!DC.ipv6 === this._useIPV6) return {
				id: DC.id,
				ipAddress: DC.ipAddress,
				port: 443
			};
			throw new Error(`Cannot find the DC with the ID of ${dcId}`);
		}
		/** @hidden */
		_removeSender(dcId) {
			delete this._borrowedSenderPromises[dcId];
		}
		/** @hidden */
		_getResponseMessage(req, result, inputChat) {
			return parseMethods._getResponseMessage(this, req, result, inputChat);
		}
		/** @hidden */
		[inspect_1.inspect.custom]() {
			return (0, Helpers_1.betterConsoleLog)(this);
		}
		/**
		* Small hack for using it in browsers
		*/
		static get events() {
			return require_events();
		}
	};
	exports.TelegramClient = TelegramClient;
}));
//#endregion
//#region node_modules/telegram/Version.js
var require_Version = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.version = void 0;
	exports.version = "2.26.21";
}));
//#endregion
//#region node_modules/telegram/client/index.js
var require_client = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.users = exports.uploads = exports.updates = exports.tgClient = exports.telegramBaseClient = exports.message = exports.messageParse = exports.downloads = exports.dialogs = exports.chats = exports.buttons = exports.bots = exports.auth = exports.twoFA = void 0;
	exports.twoFA = __importStar(require__2fa());
	exports.auth = __importStar(require_auth());
	exports.bots = __importStar(require_bots());
	exports.buttons = __importStar(require_buttons());
	exports.chats = __importStar(require_chats());
	exports.dialogs = __importStar(require_dialogs());
	exports.downloads = __importStar(require_downloads());
	exports.messageParse = __importStar(require_messageParse());
	exports.message = __importStar(require_messages());
	exports.telegramBaseClient = __importStar(require_telegramBaseClient());
	exports.tgClient = __importStar(require_TelegramClient());
	exports.updates = __importStar(require_updates());
	exports.uploads = __importStar(require_uploads());
	exports.users = __importStar(require_users());
}));
//#endregion
//#region node_modules/telegram/index.js
var require_telegram = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || function(mod) {
		if (mod && mod.__esModule) return mod;
		var result = {};
		if (mod != null) {
			for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
		}
		__setModuleDefault(result, mod);
		return result;
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.client = exports.password = exports.tl = exports.helpers = exports.extensions = exports.sessions = exports.errors = exports.utils = exports.Logger = exports.version = exports.Connection = exports.TelegramClient = exports.Api = void 0;
	var tl_1 = require_tl();
	Object.defineProperty(exports, "Api", {
		enumerable: true,
		get: function() {
			return tl_1.Api;
		}
	});
	exports.tl = __importStar(require_tl());
	var TelegramClient_1 = require_TelegramClient();
	Object.defineProperty(exports, "TelegramClient", {
		enumerable: true,
		get: function() {
			return TelegramClient_1.TelegramClient;
		}
	});
	var network_1 = require_network();
	Object.defineProperty(exports, "Connection", {
		enumerable: true,
		get: function() {
			return network_1.Connection;
		}
	});
	var Version_1 = require_Version();
	Object.defineProperty(exports, "version", {
		enumerable: true,
		get: function() {
			return Version_1.version;
		}
	});
	var Logger_1 = require_Logger();
	Object.defineProperty(exports, "Logger", {
		enumerable: true,
		get: function() {
			return Logger_1.Logger;
		}
	});
	exports.utils = __importStar(require_Utils());
	exports.errors = __importStar(require_errors());
	exports.sessions = __importStar(require_sessions());
	exports.extensions = __importStar(require_extensions());
	exports.helpers = __importStar(require_Helpers());
	exports.client = __importStar(require_client());
	exports.password = __importStar(require_Password());
}));
//#endregion
export { require_sessions as n, require_tl as r, require_telegram as t };
