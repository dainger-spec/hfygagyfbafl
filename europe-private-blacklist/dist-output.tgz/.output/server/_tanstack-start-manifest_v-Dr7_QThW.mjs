// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dr7_QThW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-sGfwh-Wt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-sGfwh-Wt.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CXFaNe-5.js"]
	}
} });
export { tsrStartManifest };
