import { o as __toESM } from "../_runtime.mjs";
import { o as tb, r as isLocale } from "./i18n-BSUu3cSU.mjs";
import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-CNp6uOn-.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+KkrYz9IKvoBmYTQy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{2,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{2,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{2,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
function parseDamageAmount(text) {
	const raw = String(text || "").trim();
	if (!raw) return null;
	const upper = raw.toUpperCase().replace(/Ё/g, "Е");
	let currency = null;
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	const numeric = raw.replace(/[\u00A0\u202F\u2009]/g, " ").replace(/[€$₽]/g, " ").replace(/\b(usd|eur|usdt|rub|евро|бакс\w*|доллар\w*|руб\w*)\b/gi, " ").replace(/[^\d.,\s]/g, " ").trim();
	if (!numeric) return null;
	const s = numeric.replace(/\s+/g, "");
	let normalized = "";
	if (/^\d{1,3}(,\d{3})+$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d+,\d{1,2}$/.test(s)) normalized = s.replace(",", ".");
	else if (/^\d+\.\d{1,2}$/.test(s)) normalized = s;
	else if (/^\d+$/.test(s)) normalized = s;
	else return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n <= 0) return null;
	return {
		amount: normalized.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ""),
		currency
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
async function lookupTelegramHandle(input) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 25e3);
	try {
		const res = await fetch("/api/telegram/resolve", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				input,
				initData: telegramInitData()
			}),
			signal: ctrl.signal
		});
		if (res.ok) {
			const json = await res.json();
			if (json?.username || json?.id) return json;
		}
	} catch {
		if (ctrl.signal.aborted) return {
			...await resolveTelegramId(input) || {
				username: "",
				id: ""
			},
			busy: true
		};
	} finally {
		clearTimeout(timer);
	}
	return resolveTelegramId(input);
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function telegramPlatform() {
	try {
		return String(window.Telegram?.WebApp?.platform || "").toLowerCase();
	} catch {
		return "";
	}
}
function isTelegramDesktop() {
	const p = telegramPlatform();
	if (/(tdesktop|macos|weba|webk|unigram|web)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Windows|Macintosh|Linux/i.test(ua) && !/Android|iPhone|iPad|Mobile/i.test(ua);
}
function isTelegramMobile() {
	const p = telegramPlatform();
	if (/(android|ios|android_x)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
function tgSafe(run) {
	try {
		run();
	} catch {}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tgSafe(() => tg.ready?.());
	tgSafe(() => tg.expand?.());
	tgSafe(() => tg.setHeaderColor?.("#080808"));
	tgSafe(() => tg.setBackgroundColor?.("#080808"));
	tgSafe(() => tg.setBottomBarColor?.("#080808"));
	tgSafe(() => tg.MainButton?.hide?.());
	tgSafe(() => tg.SecondaryButton?.hide?.());
	if (Boolean(tg.isVersionAtLeast?.("8.0")) && isTelegramMobile()) {
		tgSafe(() => tg.requestFullscreen?.());
		tgSafe(() => tg.disableVerticalSwipes?.());
	}
}
function telegramSafeTop() {
	const tg = window.Telegram?.WebApp;
	const safe = Number(tg?.safeAreaInset?.top || 0);
	const content = Number(tg?.contentSafeAreaInset?.top || 0);
	if (!Boolean(tg?.initData || /Telegram/i.test(window.navigator?.userAgent || ""))) return 0;
	if (isTelegramDesktop()) return Math.min(Math.max(safe + content, 0), 28);
	return Math.max(safe + content, 56);
}
function lockTelegramViewport() {
	const apply = () => {
		const root = document.documentElement;
		root.style.setProperty("--app-h", "100dvh");
		root.style.setProperty("--app-top", "0px");
		root.style.setProperty("--tg-safe-top", `${telegramSafeTop()}px`);
	};
	apply();
	const tg = window.Telegram?.WebApp;
	tgSafe(() => tg?.onEvent?.("safeAreaChanged", apply));
	tgSafe(() => tg?.onEvent?.("contentSafeAreaChanged", apply));
	return () => {
		tgSafe(() => tg?.offEvent?.("safeAreaChanged", apply));
		tgSafe(() => tg?.offEvent?.("contentSafeAreaChanged", apply));
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
function openExternal(url) {
	if (!url) return;
	try {
		const tg = window.Telegram?.WebApp;
		if ((/^tg:\/\//i.test(url) || /(?:t\.me|telegram\.me)\//i.test(url)) && tg?.openTelegramLink) {
			tg.openTelegramLink(url);
			return;
		}
		if (tg?.openLink) {
			tg.openLink(url);
			return;
		}
	} catch {}
	try {
		window.open(url, "_blank", "noopener,noreferrer");
	} catch {}
}
function haptic(style) {
	try {
		const hf = window.Telegram?.WebApp?.HapticFeedback;
		if (hf?.impactOccurred && window.Telegram?.WebApp?.isVersionAtLeast?.("6.1")) {
			hf.impactOccurred(style);
			return;
		}
	} catch {}
	try {
		const ms = {
			light: 10,
			soft: 14,
			medium: 20,
			rigid: 24,
			heavy: 32
		}[style];
		navigator.vibrate?.(ms);
	} catch {}
}
var WELCOME_JPEG_BASE64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCALQBQADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8uqKKKACiiigAooooAKKKKACiiigAooooAKKKKAClUd6SnCkwCiiipAKKKKACiiigsKfTR1p1ABRRRQAU4dKbTh0pMBaKKKaAVelLSL0palgFPpo606gfQKB1opR1qB7DqB1ooHWgEOpw6U2njpUAFKtJSrQWh1KtJSr0oAcvWnU1etOqQQU+mU+pZXUB1p1NHWnUgQ+iiioGKo706kXpS0AKvWlpF6UtABTlptPpMoKUdaSlX1pDWw6iiikwQ6iiipBBRRRQUOHSlpB0paS3AKKKKYDgKWkpakAooopAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSEZpaKAGUUUVYBQelFB6UmAyiiimAUUUUCY09aKD1oqkJjW60lObpTaYdBD0ptPpp600ISkaloPSmSxtNYd6dSHpQA2iiigBp601utOPWmt1qxMSmGn0w9aaBhSNS0jVQmNPSm049KbVCGt60lObpTaACmU+mUECN1pKVutJVoGNPWkpW60lAdApp606mtVi6CUHpRQelCENoooqmAh6U2nHpTaSAKKKKYBTT1p1NbrQAlFFFABRRRQQFFFFACMKSnU2qQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnU0dadSYBRRRUgFFFFA0FFFFBQo606mjrTqACiiigApw6U0c0+kwCiigDJpgOHSiiipAcvSlpB0paBsKUdaSlWoGx1A60Uq+tDBC0+mjrTqgApVpKcvSgsWlHSkpw6UAOX1paQdKWpGgHNPpo606pY0A606kWnL1pAh1FFFQMcvSlpB0paAFXpS0DgUUAhR1p1NHWnUmUFOHSm0+kNhQOtFA61LGh1FFFIEFFFFAxw6UtIOlLSW4BRRRTAfRRRUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMPWig9aKtAFB6UUGkwGUUUUwCiiigTGnrRSt1pKaDoJTafTD1qgQU09adTT1pokSg9KKKZLG0h6UtJQA2iiigBp601qe1MbpVITEpp606mtVIGJSN0paD0qhMYelNp1NqkIRulNpx6U2gAplPprUEDW60lK1JVIBrdaSlakpggpD0paD0qkJDKKKKYhtFKwpKoAplPppGDSQCUUUUwCmt1p1NbrQAlFFFABRRRQSwooooEFNPWnUjdaaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAFWloFFSAUUUUgCiiigpBRRRQMUdadTR1p1ABRRRQAq9adTVp1LqAUq0lKvSmwFoooqQHDpS0DiikMKcBgU2n1IMKcOlNpw6UmMctLSLS1Iwp9MHWn0FAOtOpo606hgPoooqRoctLSL0palj6Dh0py9KaOlOXpUsBaBzRSjrUjHUUUq9aAFooooGhR1p1ItLSYwp9MHNPpDYUo6UlOHSpYdAooopFBSjrSU5aGAtFFFJAFFFFMB9FFFQAUUUUAFFFFABRRRQAUUVPp2n32r6laaRplq9ze306W1vCgy0krsFVR7kkAUAQUV2Xxl+GOrfBn4p+Jfhdrdwtxd+Hb5rUzqu0TRkB45AO26NkbH+1XG0AFFFFABRRRQAUUUUAFFFFADD1ooPWirQBRRRSYDT1pKc3Sm0IAooopgB6U2nHpTaaJ6BTD1p9NPWqBCU09adSHpQhDaKKKoTGnrRStSUCGkYNJSt1pKAEPSm049KbVIBtIelLSHpTRK2G0UUVYMaetNbrTj1prdaaEJTD1p9NPWmAlI3SlpG6UEsaeabTqbVIQh5ptPph60xIKD0ooqkC3GUUUUxCHpSU49KbTQBTWp1I3SjqA2iiimAU1utOprdaAEooooAKKKKBMKKKKCQoPSiigBtFFFWAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUDrQA6iiioAKKKKACiiigpBRRRQMUdadSDpS0AFFFFADl6UtIvSlpdQClXpSU6hgFKOtJTlpAhaKKKTH1Cn0wDJp9SDCnU0dadSYxwHFLRRUjQo606mqO9OoKFXrTh1pB0py+tJgLRRQOtIfQcOlLRSr1qBsWnjpTR1p1JjClXrSU5akBaVaSlXpQAtFFFA0OXpS0g6UtSykKo706kHSloBhTh0ptOHFQxhRRRQMKctNpw6UmAtFFFNAFFFKvWgB1FIGBJUEZHUelLUAFFFFABRRRQAUhIHUgUtdp8J/F/gbwd4mS8+IvwzsfG2hXBSO6s57u4tp4UBOZIJIZEw/PRwytgDA+8E3ZN2uBxQKn+IfnX07/wTm+Fg+Jv7Ufh+8urYT6b4Pjk8RXW5cr5kOBbjPQHz3hYeoVq+yfg3+zr+wV8c/DEfiz4f/DvTtRtCVS4hOq6jHc2ch/5ZzxfacxtwcdVbGVLDmvpn4Ifs7fBn4H3OpXnws8EQaDNrEcUd66XdxOZVjLFBmaR9oBYn5cZ4znAxhhsXTxU/ZxTT6pq36l1aUqUeZ2a8j8+/wDgrf8ACU6D8RfCvxfsbYrbeI7FtJ1BwPlF3bYMbMf7zwyKo9oDXwLlf7w/Ov6GfjT8Ifhv8aPDsPhf4neF4Nd0y2u0voYJZZYtk6qyq4aJlYHa7jg4IY5r5v8AF/7GX7GXg3Q73xJ4i+Gmj6TpWnRmW6vLvWtQjiiXpksbjqTgADknAAJ4pYvF0sFLlmm/RXChSnWjdW+Z+Ou5c4yKWvZ/2hvHf7P+vag/h/4AfCS10LSLeT59cubm9e8vSDx5cUszJDEcHhlLkEZKcrXjFb05+0ipWav0e/6kyXK7XuFFFFUIKKKKACiikJCjJOKAGnrRSnnmkq0AUUUUAIelNp56UykgCiiimAHpTadTTxQJdgprDvTqKsQykPSloPIoBjKKKKoliNSU49KbQIa1JTj0ptABTKfTT1qkAw9aKVqSmJDKKU9aSqF0Gt1prU9ulNPIqkIbTW606kYd6YDaQjIpaKCWMpp6089aa3WmhCUw9afTSOaoXUSiiimgY09aSnNTaoTA9KbTqaeDTQBSHpS0h6UMBtFFFMApG9aWg9KAGUUUUAFFFFAmFFFFBIUUUUANPWilPWkq0AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUqjvSU4dKTAKKKKkAooooAKKKKCkFFFLQMcOlFFFABRRQOtADqWiikgAdadTR1p1DAKcvSm05elIaFoooqWCFWnUg6UtIEKtOHWmr0pw61LGOooopFIcOlLSCloGOHSnL0ptOHSpYC0o60lKtJjHUq0lOHSpH1FHWnUi0tSxhTh0ptPpAFOHFNp1ABSjmkpR1oKQ6iiipGhw6UtFFIEKvWlpF60tSPqFFFFAwp46U0dadSYBRRUtpaXeoXcNhYWs1zdXMixQwQxl5JXY4VVUckkkAAUwIqU5Ckjr2rsP8AhS/xkyV/4VH40yOCP7Buv/iK7T4P/sy/FXx58U/CfhHXPhn4q07StU1a3h1C7u9IuIIYbXeDMzOyALiMNjJ64FS5K1wPVP2lf2arj4cfsk/A74jxWHl3r200OvN5eJA9+zXlrvx02RmSPnuFFfJNfvh+1R8HU+MH7OHjD4eadZg3c2mG50qJBjF3bETW6DHQFoxH9HNfiD/wpP40oMP8IPGwI9dAuh/7JRyuK94mLTONorqNT+FPxT0Swn1XWvhp4r0+xtU8ye5utGuIool6bmdkAUcjk1y9K9ygooooAKcBimjrTqAOw+FHxR+Ivwg8aWXi74Y65c6fq6uIfKiG+O8RiMwSxH5ZUb+6QecEYIBH7++Dr3UZdJsX1pYE1E20RvFgBESz7B5gTJJ2h9wGSTjHNfiH+xX8O1+JH7RvheyurfztP0OU69ejtstsNGD6gzeSpHo5r7d/aO/4KP8Ahf4VLdeCvg5HZeKvFUZMU+oO2/TdPfvgr/x8yD0UhAerMQUrzauIf16FKmrtK79Htf7jojTXsHOT8kfd2sXiBCSeB1xX4mftwfF/4veOfjV4l8CfELVxFpXhTVp7bTNIsw0dmkQY+VOVJJeV4irF2JPzkDC/KPcv2cv+CmniCCWLwh+0fMdRtpnIh8UW9uqzwFmyFuYYlCugzgPGoZQBlX7ebf8ABRfw1pUvxN8P/F3w1e2l/o3jnSUZLyzkEsM89sFjMiyKSrAwtb4x6N6HESryjmKhVj8SfK/Na6fK5Spp4fmg9t0fJuKaeKdTT1r1TlCiiigAooroND+HXxC8T2A1Xw14C8R6vZFzGLmx0ueeIuOq70UjIyMjNDaW4HP19H/sK/A+x+NXxO12DX7bzNF0jw7fLOxGVE93E1rDn3HnPKPeH2ryEfBf4yMcD4SeNDn/AKgV1/8AEV+nH/BNz4I6t8PfglqPiPxPod1pmt+LNSkmlt7y3aG4itbfMUKOjgMMuZ3GRyHU1w5hUlHDSVJ+89F/XobYeKlUXNsflFrmjah4d1vUfDurReVfaVdzWVygOdksTlHX8GBH4VQr64/bx/Z+8aad+0JqviLwV4I1zVtM8T28WqO+m6dJPHDckGOZCY1OCXjMnP8Az1r51b4P/FwZz8K/GA/7glz/APEVthsVCvRjUbSuvx6/iKrSdObh2ORoq7rGia34dv30rxBo99pd7GFZ7a9t3glUEZBKOAcEEEVSrqTTV0ZBTKfTW60IBKKKKYBSNS0jUC6iUUUVSExlFBopgxp60lK3WkqkJhTadTT1oJCmU+mHg0AFNbrTqRqaAY3Skpx6U2qF1Gt1pKVqSqQhD0ptPNMpoQ2kPSlPFFUAyiiigTGt1prdKc1IelNEjaRulLSVQmNooopoGIelNpx6U2qBhTT1p1I1NCEooooYDKKU9aSmAUUUUAMopT1pKACiiigTCiiigkKKKKAAjim049KbVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAU4dKbTqTAKKKKkAooooAKKKKCgpR1pKUdaBjqKKKAClWkpw6UMBaKKKSAVaWkXpS0mAU8dKaOtOoGgoooqWND6KKKQkOHSnLTacOlQMWiilHWgpDqB1opVoGOHNOpo606pAKcOlNpw4pMrqLThTRzTqkEOHSlooqRijrTqavWnUgAdadSL60tABSqO9JTh0pMoWlA5pKVaRXQdRRRSYkKtLQBgUVI+oUUUUDFWnUgHFLU7sAoBIIIJBHII7UUVQH2p+yr/wAFBNb8EXFp4H+OeoX2r6ANsNrroLS3lgOgEwHzXEQ45/1i843jCD9SfBPiLSvE2l2et6DrVvqemX8Sz2t3a3AmhnjPRlYEhh/nrX88XYnGe1fs7+wN4Of4ffs5+EdOuFcXerxPrc4bOd102+MYPIIh8kEeua+exuHw2ArQr01yuTtZbPz8j0KFSrXg6ctUl9x9dSMBbde1eK/Hr40fD34H+FpvGPxE8Q/YrbJS2t428y6vZf8AnlBFkF26ZPCqOWKjmuq0H4yfDfxjr+s+DPCnjjRtW1zw6Qup2FpdLJLbE9cgfeAPysVyFb5WweK/P7/grR4Me7h8C/EyAZW2ludCujz/ABjz4PYfduP09K7cwqUcZUp4eb0f+RzYaM6MZVI9D5c/aU/a0+IX7ReryWl3NNo3g+3l3WOgwzFkOD8stw3HnS+5AVeiheS3h1LRXZRoU8PBU6SskZTnKpLmk7sKKKK1JAdadQBiigDd8P8AjjxX4V0fXND8OaxLp1v4jhjttSe3+SWe3Ri3k+YPmEbEgsoOG2qGyBisEAKMClopKKTbS3C4EZ61qP4o8Qy+GE8GTavcS6JDe/2hDZSNujhuNhQumfubgfmAwGwpOdq4y6KGk90NNrYKaetOopiG0UEYooAK7/4N/HX4kfAnxD/b3gLW3ihmYfbdNmZms75R2ljBGT6OMMvOGGTngKKipShWg6dRXT3TKjKUHzRdmfsl+zL+1Z4C/aC01ItJvjpXiW3i8y/0G5uMzRYxukhY486LJ+8ACMjcq5GfpnTpFNuxZiSR3r8a/wDgnr4En8V/tEWPiMo4s/CFnPqcrj7pmZfJhQn1LS7h7RtX6oeL/i/8PPhVpFpf/ELxlpegW9/cLaWz3s4TzZCQMAddoyCz/dQcsQOa+PcKOVY54ehdpq9t2r308z2OaeKw/tammtr9yx4rZjLIschAPXBxXwN+01+23Z+Fp73wJ8G7+PUNZXMV3rqsJLayboVt+olkH985RT03nJX7O+I0Nl4w8M6poMkyPaa5YTWZkjfKmOeJk3qw6jD5BBr8QNQ0670jULvSdQhMV1ZTyW88Z/hkViGH4EEV5OQZZg83xtWtiPe5GrR6a31ffbbbud+YYqvgqEIU9Obr/X5iX9/qGrX0+qatf3F7e3UhlnubiVpJZXPJZmYksT6k5qCiiv0tJJWR8tuFI3rS0hGRS6gNoooqgCkaloPIoExtFFFUhMaw70lObpTaYdBGHem0+mU0IKRutLSN0pkiU1utOprUAJQelFFADKbTqaetWJiHpTafTKaAKaetOprVRI1utJSt0pKoBh60UrdaSgTEPSm0+mUEjaKD1oqwYw9aKD1ooQdAplPpp61YnsJSN0paD0oQhtFFFUwGtSU49KbSQBRRRTAaetJTm9abQAUUUUAFFFFBAUUUUAB6U2nU09apAFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAAdadSL1palgFFFFIAooooBBRRRQWFOHSm08dKACiiigAp9Mp9JgFFFFMBw6UUUVICr1p1ItLQPoFKOtJTlqB9BaB1opV60mAtPpo606pAKVfWkpw6UFi0q9KSnAYoAVadSAcUtSNBT6aOtOqWNAOtPpq05etIEOoooqBjl6UtIOlLQA4dKKKKAQU8U0dadSZQU5abT6Q+gUDrRQOtSwQ6iiikNBRRSgZNAx1FFFSgCiiiqA3/AHh6y8V+NtE8O6rqNvp+n3t7Gt9eXEwijtrRTunlZzwAkYdv8AgNfU37SP7eOreKLOb4a/Aee50HwrGn2WfVkVoby9iA2iOEcNBDtGP77DGSoyh+PAOOaWuGvgqWIrwr1NeS9l0u935vRW7G0K86cHCOl9zS8K+J/EfgbX7HxV4O1u80fWNNkE1reWkpjkjYe46gjIIPBBIIIJFfYmv/tZ6N+1H+z54j+FfxPitdH8eWlqmpaVdxgJaarPanzNqA8QzvGJU2fdYv8AIVJCV8U0hAIwRVYnCU8Vyyl8UWmn1Vv07omnVlSuls9wU5Az1paKK6TMKVR3pKcOlABRU1lZ3upXSWWm2VxeXMnCQ28TSSMcZwFUEk49K7fwd8F/GXjXVP7G0m0lu75SN9jpVtLqd4o6cx2yuIyDxiZo+h54pOSjuFrnBUV9g+E/+Cbfxr1yAXF94NutOgI3faNd1y00wAf7UMC3jj3yVP0roJf2CdA0A+V4v+M3wQ0R14aO6128mkH1PnW//oIrJ4iCK5WfD1FfbTfsVfC26xFo/wC0f8CbuYniP+07sZPoD/aD/wAqo6p/wTn+IU9q9/4Wbwh4miAyn/CP+LCm7323Fsy/h5w+tZyxlKPxO3rZfqUqUpbanxnRXsPj39l74nfD2OS48ReFvEGk28Q3SXF/pZktEHp9ps2ni645coO9eWahoeraZEtzdWm62Zti3UEizQM390SxkoWGDlQcjvW1OtTqq8HdEyjKLtJFAikpwII4ptaEhSdKWigD6y/Z2+Ofgr9lr4I6j4ma1i1zx743vS1lpaPtFvZW+6OKS6YconmtOQg+ZxtxtU7x86fEn4m+N/i74puPGPj/AF2bUtQn+VAxxFbRA/LFDGPljQdgB6k5JJPLhQOgxS1x0MDRoVp4hK857vy6Jdkl95tOvOcI02/dXQ95/Z//AGt/GnwcEXhjXWufEHg4t/x4vIDPYgnlrV26epjY7Cf7pJeuM/aIn8K6l8WtZ8T+CdRtrzRfEvl61bNDwUacZlSRDyjiYSgqeeB1BBPnNIRxxU08uoUcW8ZTVpSVpW2eqd2u6tv56lyxVSdFUJO6TuvL/gDaKKK9E5goooqWA09aSlI5pKpAFFFFAmNPWilakpoT2EPSm0+mHiqBBTKfTT1poQlB6UUUxMbSHpS0UCGUUUUANPWmt1p7UxulWhMSmnrTqa1NAxKRqWgjIqhMYelNp1NqkIRqbTj0ptABTTxTqaetBA1utJStSVSAa3Wkpx6U2mCCkalpD0qxdBtFFFAhtFB60VQBTDT6YetJAFFFFMAPSmU+mUAFFFFABRRRQSwooooEFNPWnUjU0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACqO9LRRUgFFFFIAooooBBRRRQWFPFNHWnUAFFFFAAOtPpo606kwCgdaKVabAWiiipAcvSlpB0paTGFOHSm06pBi0o6UlOpMYo606kWlqRoKcKbT6CgHWnU0dadQwHjpRRRUjQ5aWkHSlqWPoOHSnLTR0pw6VLBC0UUo61Ix1A60Uo60ALRRRQNCr1p1ItLUsoB1p9NHWnUAwpVpKcOlSx9AooopDQUq+tdx8DvhtdfF/4weEfhraqSNe1SG3uCDjZbA7p3/wCAxLI3/Aa6n9rr4axfCX9pHx34NsrQW2nLqj6hpsSptRLS5AniRB02osoT/gBqW1flA8gooopoAoopVHemAtLRRUAFFFFABRRVvSdI1HXL1dP0yASSlWkZmYJHFGoy0juxCoijJLMQAOpobtqwKqI8sixRIzyOQqooyzE8AAV7R8HP2X/iD8WNbGkaRoF1f3MRT7VbQyCGGxBOD9tumUpbsByIQJJztYeWvDV698Ff2avBvhLwTF8a/jl4jn8JeDoirx3jq0Op66CpIisoyPNtoHGQHCi4lQMwEEbE1xvxs/bZ8ReKtDX4YfBDRk+Gnw5tIzBBp+mgQ3l2mfmaaWM/KG6siHnLb3lzmuN151pOGHW276L/AIPkvm0a8iirzPW9S0H9kD9mC0fSviv4lPxJ8UxY83wh4Vzb6VBIMHbcvv3zlT/z8Su2CcQgcV5/4w/4KO/F2609fCXwU8LeG/hd4ehCrb2Wh6dHLOi5AALMnljOQMpEh5618uado6zqJ724+zwbXP3Tu2qD8wx1UYYnGDiKQDDAAxyalO0Xk2yLbxBgy7TlxgnA3A4P8HIAyY0PBGa2hh4r43zP8PuIcm9tDqvGHxF+J/j5Z774hfETxBrwYFjBeanJON3IGEdigAOzIX+GQMARXGxtbx7vNR5dw4G8pg9PfPc8d8e4r3X4FfsYfGf47xwa9p2kJoHhq4O4a3qqNHHMvrbxgb5+OhUbM5BZa+mvBfwF/Y2+EeoDw/cw6z8bPH0AzJpOk2D6nscHawNtAfs8S56i5mbHPTHGFbH0MO3Tj70l0j+vRfNlwoTn7z0XdnwDpWi6r4mum0/w14T1LUboo2IbLzp5FJZypCqCSACg5HOz3JrX0zwf8U7DXtRj8OeE/FWn6tohUXlva29wl3Zlz+7VxsEiH0BwSMnjBNfqBqXxf8e+HIF8NeG/B3wv+FFvGdkNhrWsfbdR2diulaQpKn/ZaT618ZfEPxN4ktPGnxX8W+Lo9G8YWFzqVkmqRX2kXekSzGGNIIpLaNiJLaREuflMgJwof72DWFDMateTXIkraa3vqvl+Jc6MYJe9r6f0/wADD+F37Xf7S3hLxDbeHbD4nyTwNK0Jh8XyLNBHgniWeUmRAMc4kTBOPevUI/j7+zT8VdWuNJ+NXw4TwB4mlPly+K/B1ykttOx25aYRBllRsDIkW4GOCRzjwu68f6L438aReJ0udT0GHTdNFrbxza5dtOkjyO7LHcx20r+UgkZERwMIF5OCKs6hq/h3U7eS01TxpqV3bTDbJDP4j1F0cZzhgdPwRxU1cHTnLnVNwk1vHR/ho/ndDhWlFcrd156/8FHf/Fj9jzWdM0b/AIT3wFqen+LvCs0Znj17w9CZFEYxlrmzhLlQCSWktt6qF5iTk180avoupaHcrbajCoEi74ZonEkM6f3o5FJVxnIyCcEEHkED2HwD8VPFPwN1uTxH8H/iDY2FrsEl1oc73t3b37qOjIbaJdxAADZVh2dc17pDpvwW/bI0+5n8DadZeCviT815qvhW6cR2OsSFctNC4H7uXjPnxgMORMkiEvSWJr4Ff7T70P5rWt/iXT1Wn+Er2cK/8LSXb/J/pv6nw7SV1nxB+HmueAdbv9M1HTb22Gn3H2W6gvIwlxZSkErHMo4+ZQWSRcxyp8yE4ZV5PjPvXrRkprmjscrVtGGaWikpiFooooAYRiinEU2qQBRRRQwEam5q/oujaj4k1rTvDujwedf6rdw2VrHnG+aVwiL+LMB+NeuftefBa0+BnxdPhbSIdmkXelWV3ZMAcNiIRTHPcmaKVj7MKxeIpwqxoN+9JNr5Wv8An+ZahJxc1sv1PFKKKK3IYHpTacelNoQlsFNPWnU1qsSEpGpaQ9KEA2iiiqJY09aKVvWkoEMPWilakoAQ9KbTz0plUgG0h6UtIelNCWw2iiirExlNPWnnrTW600ISmU+mnrTASkb1paQ9KCWNPSm06mnrVIQhptPplMSCkPSloNUgGUUUUxCN1pKVqSqQBTT1p1NbrS6gJRRRTAKZT6aetACUUUUAFFFFBLCiiigQUhHFLRTAbRQeKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1opR1oYC0UUVABRRRQAUUUUDQUUUUFCjrTqaOtOoAKKKKAFXrTqRelLS6gFKtJSr0psBaKKUdakB1FFFJj6hT6aOtOqQ6hTqaOTTqTGOHSloFFSNCr1p1NWnUFCqO9OHWkHSnLSYC0UUDrSH0HUo60Uq9agbFp4po606kxhSrSU5elSAtKtJTh0oAKKKKBoeOlFFFSUhVp1IOlLQDCnU0cmnVA2T21jfXu/7FZT3Hl43+VGW25zjOOmcH8jUp0XWh10a+H/bBv8K3fhv8UPHnwj8Sw+K/h94ju9Jv4yBIIpCIrmMf8s5k+7IhyflYEdxggEfqx+yZ+2b4O+PsEPh3Ubr/AIR/xtEn77SJbpjHeYGTJaMxy46kxn51wfvqN9efjsZVwdpRpc0OrT1XqrbeZ0UKMK2jnZ+n6nz/AP8ABJf4PXmo/EjxR8WtZ06aGHw/YrpNh50WN1zc8yMuecrDGy/ScVrf8FdPhNfx+L/A/wAVtH0ye4Go2M2hX7QxltrwMZYCQO7JNIM+kQ9K/SrQZPMYF2LHpknNaWpSbBlGZTjqDiuqhUjVovEGFSLhU9mfzef2Fr3/AEAtQ/8AAdv8KiudN1KyQSXunXVujHaGliKgn0BPev2v/an/AGxPh7+zZpTWup3r6z4vuofM0/w7bXJWVgc7ZbhhnyIsjgkbmwdoIBYfkT8afjz8Tvj/AOKG8VfEnxDLeOhZbOxjLJZ2EZ/5ZwRZIUdMkks2AWZjzU0asquvLZd7/pYqUeXrc8+pw6U2nCt2SLRRRUgFFFOjilnlSCCJ5ZZWCIiKSzMTgAAck0AWdJ0m91zUItM09EMsm5i0jhI4kUFnkdjwqKoLMx4ABJ6V9o/Cj4YfDH4CfDKH46fG+2M2kSFJfD2gTR7brxLdL80VxNE4yIAcNFCw2hcSygkxoed/Zv8Agz4K8PeE9W+M3xjRYvBfhaRZL8SKGXXNQjYFLGMZxLbxShAwB2TXAVSWjhLV4R8fPjr4u+P/AI+ufG3imUw2ybodK0xXJh0+1zlUX1Y/edyMsxJ4GFXzJzljqro0naMfifn2Xn37LzenSoqjHnlu9l+v9bjvjj8dviD+0X45PiXxpqIjiUumm6bG7fZNNg6kIp78ZeQ8tjJOAoHLjSYtGgM9xMr3W11eFjuVhn5gV77SQGUEOqukqFgCRUtUGkRTXd1K0dxhfswRsOkoPOQcMkiMOCCCDjIZJMlmi6Brfi7XLXw9oOmzalq2r3KQW1nbplppWOFVVAAAGcDgAD0r0YwjSioR0ijnbc3d7jtJ0vxJ431bTvDWg6fdatqV7KIbKztoi8s0rYH3QOWO0ZOB0JPJJP3N8Lv2XvhZ+zwmk618ctOf4gfE3Vv3mh+BtJQXaxnn55EzskVeS80pFumGx5pUNVz4f+GvC37H+jXPhvQTpesfGG+tIm8S+IriI3Nh4Tt5/wDVW0aqC01xKeIrZP3lww3NthUA2NK0LS7M6vqHxMuLlBfX0Y1+z1G7eS71G5YAwx65cQbpJpmG0xaFZbgo2CXPL14WNzCVX3abah5by9Oy/F6apNM7KVFR+Lf8F/wfy8zt/wC0/id+0FNJYalKdb0bPkTeHfDeqPYeFrIjKmHUdaQedqbqCA1vZL5YK43LXsPhn4D6Lo2kwaD4x8VRQ6fJ80fhfwzD/YGkHPX9xbN9puvdppX3dSBmvPpvjE2ixHQbprjQF063QjRrCK1XV4LcD5Dc/MLHQLfGMLLIZsd1biuesv2sPAOmyNbWnjLRLHzGYSwaLfJ+8YHk3WtX2HnbrkWsLkc4c14sJV6nuxjaK2t/n+q9G7nU/ZrVu78/6/rsfV+heB/CPg/Sms/B3hrTtEg25MdhaJbbvdtgBY+7ZNfk3+1l4pabx78UtMifm88dTQS5PJjhhRSP++1T8q+3dF/bt/Z10hXg8R/E/TYmPHkaXpWq3+D6vdSQAyH3CAfWvzI+NHiqy8a/Fvxv4q0a9a50nWPEmpalYSGNoy8M05KOVYBlyiocEAjoa9TJsJUVeVWpFx06rfUyxlWEqcYxdzrvhfZa/p3hdbmxUR/b5nm3bdfjYqPlXJsl8lxwxBBJ+Yg9MDqmuPFpOGuG69PO8V8f+O1gaF4b0CfRrGSy8JapeRm3Qi4j8Ma04lbHzPujvQhJOclQATnAHSrf/CL6eWJPw/1kEDj/AIpfXef/ACer0KijKbbb+7/gnHHY0ZJvFpY/vzwO8virn/x2sLU/D2uX9/DrVjLHpms20kclvq1tB4iku4GRsrseSJsex6jtg1bHhPT2I/4oLWuf+pX13/5NqKTwlZZ58B62nPbwxrn/AMm1MUoO6b+7/glavc908HeMtJ/at0qH4Z/FyG38P/F3TbJ7fRNaurRoYPENqCSYLiPCllYpuKAAhh5sO11ZD8k/E34c6t8OvEl9pGo6dcWT2Vz9lurWdg0tlMV3LGzDh0dfnilX5ZU+ZcFXVO21HwQkyRS6P4X8SaXqFvLHPBfWXhbVxcxOh3KUaS5cLzznGQeRg17zouoJ+1v8P7vRfEujx2/xs8F6eYbqyulFpJ4j03Iby3DAbX3FWVsYjmKOMJKwXnjUWWy54fwXuv5G+q/ut7/yvXZm7j9ZVn8fT+9/wfz9T4h5pa1PEnh+58OaibWZZvIlBktnljMblAxUrIh5SRGVkdOdrKwyRhjl176akro4NgooooAKZT6ZVICS3tbq7cxWdrLcOqlysSFiFGBnA7ZI/MVP/ZGsDro97/34arvhLxj4r8A6/a+KvBXiC90XV7M5hu7SUo4HdT2ZTjlSCpHBBHFfpj+yn+23oHxia18EeN7gaD40ICRL5zLaao3rASfkkP8AzyJ5z8hPKr5maY6vgIe1p0eePWzs18rPQ6sLQhiJckp8r6ab/ifLv/BPL4Q6h41/aCtPE2p6bPFp3gu1fVmaWLCvcn93bpz33sZB/wBcTX0V/wAFM/hVP4g+HGkePdLsHnvfC995M3lqSxs7nCtwOuJUi+m9q+29LkMjqsju2P7zE4/OsvxgRGSUYqw6FTgj8a+Ox2bynOGaRVuRqyv01ur+d30PYw+DSUsI38XX8vuPwR/sXW/+gNff+A7f4VFPp2pWsfnXWnXMMeQu6SIqMnoMn6Gv1m+Ofx58IfBPRf7T8V6xcyXt0rGw0q3nJubwjuBn5IwesjfKOg3NhT+a3xl+PPxA+N+s/bfFeqSx6ZbyM2n6RFKxtrRegIBPzyY6yN8x56DCj6HI87xOc/vPq/JT/mct/Rcqv67fPQ4MfgKeB932nNLtb89TzqmnrTqaetfSHlrcKRulLSHpVCG0UUUwYyilPWkqhMRulJTj0ptBIjdKbTj0ptABTKfTT1poBh60UrUlUIZRSnrSVQug1qaw709ulNPSqQhtNanUjdKYDaKKKCWMpp606mnrTQgph60+mtVC6iUUUVSDqNPWkpW60lMQjdKSnHpTaaAKa1OpD0o6gNooopgFNbrTqa3WgBKKKKACiiiglhRRRQIKKKKAEbrSUrUlWgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApwGBTQOadSYBRRRUgFFFFABRRRQNBRRRQUKOtOpo606gAooooAcKWiikgCnDpTadQwClXrSU5aQIWiiipY+oq06mrTqQdRVp1NWnDrUsY6iiikUhVp1IOlLQMcOlOXpTacvSkwFpR1pKVetSxjqVaSlWpGOHWnU1etOqWMKcOlNp1IBacOlNp1ABSikpVoKQ6iigdakaH0UUUmCFXrS0i0tSPqFdX8J/CmreOPif4U8J6Fc3Nrfanq9rBFc2zlJbbMikzKwIKmMAvkcjbntXKV9I/sS3Xg3wL4v1344/EXUoNP0TwhYG3tXkUtJNf3IZUSBesknkrcfKOmQSVGTXJj8Q8Lhp1Yq7S0XdvRL5uxtQpqrUjBuy6+nX8D9k9C1a1sbB7y6u1htrSJpJZ55QAkSDJd3Y4AAGSxPqTVv/AISrStc0i01zQdTtNS0+9iW4tbq1mWaC4jPIdHUlWU+oNfix+0r+2f8AEL4+vN4Z02Sfw54ISTMelQzHzL3aflku3XG89xGPkU4wGI3nJ/Zw/a4+J37OWoi00m6bWvCdxJvvfD93KfJJJ5kgbBMEv+0owf4lbAx5uGw2Mhl/s3pO236X7m9WpReI5kvdMD9qHwvq/g/9obx9oWt6hd39wmsz3EV1dytLLLbzESwFnYksfKePJz1ry+vpj9tbxZ4I+MeoeFPjx8PbxpbTWbE6RqtrKFS5sbyA7kSdAThmjkAVgSrCE7TwcfM9ejgK0q+GhOorStZrs1o/xMK8FTqOMXddPQKfTB1p9dbMgoooqQCvZf2avg7q3xS8cadpNlJJayX4kk+2RsA+nWCHbcXozxvyRDCeR5rlsqYs15PomlHWtTi08z+REQ0txOV3CGBFLySY/i2orHaOTjA5Ir658b64f2af2cYdGsYX0/x78W7dWeHefN0fQkTZFDuwCG8tsEnDGSa4bO5BXnZjXnCKoUf4k3ZeXdvySu36W6nThqak3Ofwx1f+XzPOf2tfjdpPjrWdP+E3w2ENr8OPAYFlpcFuxMd5Oi7GuSf4gMsqMckgs+cytXg2ntZxXTTXsCSRou8KWIYkdNp2sufZgVIyOuKht4ZrqX7PaRNLIBuYKCSqjqxABOB1PHTNJIoSV4S6OUOCUIYHvwa68Nh44WkqUNl977t+be5jVqOrJzkSXtxHc3rzRK/koixxBySVQDhRkkgDoBlsAAZOM19n/BjwnZ/sufDmy+I2tCGP4s+PrB5dDhurfzV8M6KxCPfyRdTLIXRI4z80jyRxKMtKteQ/sofC/wAOeJ/Eeq/FX4lIF8AfDa3XV9X3plb24yfs1moPDmRxyvO4DYfviofiX+0T4r8S+ONe8YXrsPEt9cLNG6yFk0mZVaONITwP9GiYxxMBxLJPPnf5TDlxLlipvDQ2Xxfov1flZdS4fu17Tr0/z/yO+8QfFLw38J57qxOo303im0mmnvpIrtZbzTbqb/XRpcYZW1abj7VfkN9lX9xbjcuV8fvv2ifiKyB9Dey0KeCKW20+XTozHJpdrJnzILJ2LNbmQndJOD9olYkyTPkg+s/8E/PBfgbx/wCO/GHhHxt4U0rXIbnQRcRRX1ushTbcwq7Rt96Nv3g+ZCDwOa6X9oj9gmbw9pk3j74E3k+rab5D3tz4ZuSTqVrCrYeSAHDzRr0KsokXH/LQkkcUcTg6OLlg6y97TV7O/Ty67/fe5u6NWVFV47eW6PkpzqmsONH0zUNRv7RHN2yXDbFErffmYbiqdcFyfqRnAhuvDWsWNoL6bTZTYklftSIWtt3HAlGY2Jz/AAsan8H6yNE8QW1+AhBYIZD5QeIZ+8jyRSeUR97eqlvlwvJr6k0rQNC19bS/1aaNtV1CNTA0zNBc3Rxw0El0l/rd2MHGbe1t0PJBUHj16tV0rKxxxXMfIgMZAAAwc4/DrTjyMcj6V9I/EXwNo+k3TxXljZ2l3cDZJDfrFb3kgxwRHqFxe6i59ALSE57Cvn3xHod34a1iWwurWeFHO6LzIJYywPceZFGx/wC+AB6VVKqquwNWHWM+kzsEv7c29xlFt7kT7baALj5povJkaXODnBB5GeMivRby8XSIZNW8T+ErG00KaUQafqVn4QV1vJNu44WeaEgbQTkbs+1eU8Gtjwx4qv8AwvK6WscP2edXjn22lsZzGy4ZUlkidkBHXHFFSm56oE7Hrg8PQKEK+Fp2DAMN3g2z5B5B/wCP+nt4XjcNjwtOB7eDbL/5PridHtLWCMXXhR7M2c3ktc6dPZ22u6pGOd8iGS0jQKO6ZH1bkjobO2stXtY9Ss9Zs/s867oy/hfw3Ece6tOCD7EZrz5wqRfxr7n/AME2TT6GifDC5B/4RWb/AMI6y/8Ak+qwTxf4I17S/iL4CsL7T9X8OO1zEF8P29nBKmP3glMd3IWUpuUrt5VmGRnNL/YaAA/2vp/v/wAU94X/APkimPoUcgJXWLH8PD3hkfyuKi0npKSae6aeq+4pO2qWp6l8fvC/hL4w+AtP/aC8BQwwaf4llWPXInfnSNb+SMSNnAVJiEhlb5QSbaY53EH5Fkimt5Ht7mF4pomKSRupVkYcEEHkEHsa+mfgB4z034feP7v4aeMbmO+8DfEyJtOvopXtUWG7f5VkEdrLIkKnzAhI24DBuPKFeZfHz4b6t8PfGV/puqFpbjT7kWNzcFSPtSspe1u8nqZoR82MnzYZ9xyajLajw1R4GbukrwfeO1vWL0f/AG71bNMTFVYLER66Pyf/AAd/vPMaKKK9o4gpp606mnrTQCVb0fTNQ1rWtP0fSEZr++u4ra1CnBMzuFQA9ssQKqV7H+ylbeGbH4rRfEHxxqUOn+HvA9rJrV1PMpYNMuEt41UcvIZXRlRQWPlnsCRjiqzw9CdVK7SbS7vovm9DSlD2k1C9rs/X7wRu0LQrDSptQmu/7Ms4rZ7q5lLyS+VGFMsjscknaWLE9yTWfe+NPD3i/R117wtr+n6xp8zPHHeWNyk8LshKuA6EgkEEEdq/Lf8AaL/bK8afGZLjwj4Ua68OeCjlHtFkAudRX1uXX+H/AKZKdg7lyAw8z+EPxx+IPwT1k6l4P1VjZXDD7fpVwxe0vFH99OzDs64YdjgkH4JcLY3EZe1UmlUevL09G+j/AAX5fQf2tQpYlcqvBaXOr/bJ8P6poX7QXiGXUby5uodXEWp2TzzNIVgkX7gJ6KkiyIqjgBABXilfS/7SfxD8G/tAfDzRPiZ4azZa34bmNjrGkzOpnggnIKSBuPNiWUFQ4AwZwGVSRXzRX1+RzqywFOFePLOC5WvOOn4qz+Z4+YRgsRKVN3jLVP1/y2CkaloPSvWOLqNoooqkJjDRSnrSUwY09aSnNTapCCm06mnrQSIabT6ZQAU1utOpGpoBjUlOPSm1Quo1utJStSVSEIelNpx6U2qQhtI3SlNIelMBtFFFAmNPWmtTm60h6U0SNprU6kbpVCY2iiimgYjU2nNTaoTCm06mmmgCiiihgMooPWimAU1utOprdaAEooooAKKKKCWFFFFAgooooADzTadSMO9NAJRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAKtLSLS1LAKKKKQBRRRQAUUUUDQUUUUFCqO9OoHAooAKB1ooHWgB9FFFJAA606mjrTqGAU5elNpw6UhoWiiipYIcvSlpB0paQ0KvSnL1pq9KcvWpYDqKKKRSH0UUDrQMdT6aOtOqWAU5abTh0pMoWnDpTadUh1HLS0g6UtSxgOtPpo606kADrTqRetLQAU5abTl6UMoWlHWkpR1qSkOooopMSHDpRQOlFSNbhSl3MaxF2MasWVCeAxwCQPU7V/IelJRQMcopaQdKWp6gJgZz+NLRRVAKOtOpq9adUsAooqWzsrjUry3020UNPdzJBEpOAXZgFGe2SQKQHvf7JfwttfHfjSzTXI0/sRFbWtaeUfuxpdnICI2JBXbNcqgYHDBbaUjgmuB/aB+LN58bPizrfjuUyfY55vsmlwvwYbKMlYlIONpIy7eju9e56lqEHwf/ZI1bW9Nby9T+LF6uj6aWQpIuiWytEGKk8eYiys2AMm8BxXyYsJ+yG7MsQXO1U3gu5/3RyPqcCvIwP+1Ympi3snyR+XxP7/AHf+3Ttr/uqUaS3fvP8AT8NfmaMmnCz0pJrqPy9p3x3FnfR3ClhjHmIGOG/2sjb/AHTWUu9ugYySHOCdxLE/rzS478/nXtn7G/w+sviH+0H4dg1lEOjeHvM8RaoXOFW3tB5g3eqmTylI6YY16dWqqFOVSeyuzkjHnkorqd98cr0/s/fCPwZ+zxpUnka2sCeLvFjRn5n1a5XFrC5HUQRqWwQQWjgJ618rcRpwBwOnSux+L/xDvvix8UPE/wARL+Rydb1Ka5hVhgxwZCxJj/ZiWNP+ACqPw+tL+78Y6eNOaaOWAvO00V9FZGBFRiZPtEoMcGP+ejD5Tgj5torHDUnh6N5/E9Zer1fy6LyKqS55abbI9X/ZD1bUPDPx3fRNNl1Cxv8AVdC1DT4mdHhmWcWxuUG1csoZ4I1wMlgQQPm21+iJ1qIXd5r+j+Y/2Syh8aadLGxZWtJxtv7VSQixDKFwGkzuJbZhCp/Lvwx4hPw0+Onhnxy0iLaWerWeptIscyxyWpdWlK+f+9dHTdh5ACwbOMGv0atdVj8C/wBi+IL6WFU+H3iS78N39wJEYJpV2waNmc+YY0AaM4M0IUBdwACxV81n9FPEQqpfEvva/pR+Z6WAnaDj2f8AX6s+ev29f2ZNP0+0T9oz4X2CJpOotFJ4htraPYkUkxBivkQgbVkZlDjAxIynH7w7fn34WfFmPQbObw/fJceRd5823tvPSK8U/wAEkNmYJr6TPIWe7WP5jwcAV+nEV5Y2PgXxD4C8R2EGoaFo99JpGrxT7lE+h3QOyUSSFVyqyjJUzMdmP9Y2F+Hfh5+wenif4ueOPh74r8ePptt4I1CKMxW9oXvL6znVntrhGbbHGGQKSfm2scbehrqwGaUo4OSxktIdd21pZ6ddV96MsRhZSrL2K+Lp59TptG1jTLzQp7XTv7H0fSoCy3SxThIUyBgS2ukG0sYG5PyXt/LJxyGJNcq37MXxP+KlmE+GXgW/1KKVif7Ug0yx0bTypPUzLEFkA/2LiUn1PWvvX4Sfs3fBv4cJp7aT4Tj1G901Qtrf605v7iDH/PHzB5cH/bFEFfRVpKbiP5yWIHUnPFLBZnSxU26N7ef9fqOtgqlFe+flv4K/4JWePLiOKT4hfE/RtJAwXt9KtJL59vpvcxKp+m4fWvVtJ/4Jtfs/6BNGPEWueKtalc7VinvoLZHYDJCrHFvPAJxvPANfbGrQw2MkurPNPthhbcilmXaDuLCNc5bjAwCccDrXAa4ZraRTp1prDW1iyMlraaYhDCKQJIgklIJV0nUjbg7YHKMTlT5uYZhjrtKpb0svx3OvD4fDpXcbnhUP7H37NHhSSSTR/BGuRTKWDvZ61qofK7M58qVQeJFI9RuxnaceIftL/sf6B8KdC/4Wn8KNGV9EsVH/AAkej3NvDqcsNupObu3e8SUqAT+8HPGG+6Dt+r4bfXRJAZtG8Y6gLY2zmS61eGMSNHM9lLlEIUhreT7WQMLJtUjZKOZ9FjutIsp11bR9dEMttJDdRahdjUEEdpm3Q4GWc3EIEpwp387gHJDePSzXFYWp7V1HNbNOV0/x7bO252ywlGtH2aiovvax+Y1qunXUaSrpfhfYyhlzeeEUOCM8hkBB9jyO9Sm201VIGkeGD/3EvB//AMRXXfGPwP8A8KJ+J+o+Cba4vIPDWoQnWvD8n9pwWccdtK5325aW1lLukhdR8wO1Qx5auTTxTYjk6/ID1z/wlNjn/wBN1fb05e3gqtNJxauvT7/vPn5xdOThLdGP4j0uy1LR7mzi03QYJmTdC8Gs+GISJB93c0ASTbnqAwyK9e8XzwfH39nbQ/itdSr/AG34aVfCvi2ZsZ+zs6G3vJDjJEcxglbGBia5GcCvOn8T2EpBbxHLg9j4rs+Py02up/Zm8S6HYfFvWvhbqV8t14b+KGmzWN3H/aC3RF0VcqTIkcShmzMoAQHMqcnFc2OhOnSWJjH3qT5tOq2mt301Xmkb4ZxlP2Lek9Pn0f3/AIM+Zp7ee0nltLqJop4HaOVHGGRgcEH3Bpldh8U/C+oeFvFFzY6mM3ltPNp18wBCteWzeXI4zyfMXypyT/z36muPr6CnNVIKcdmefKLi2mFNbrTqa1WhCUc4K5OCQSM8Ejp/M/nRRVAFIelLQanqAzH69aKKKoAoPSiigTG0UUVSExrdaSlbrSUxsQ9KbTj0ptNEhSN1paRqZIlNPWnU1utACUh6UtB6U0Aw02nU01QmIelNpx6U2qQdQplPpp600SMPWilbrSVQDDRQetFAmI1NPSnNTT0pokbSHpS0hqhMbRRRTQ2IelNp56UyqEwpp606kbrTQhKKKKGA09aSlPWkpoApGHelooAZRRRQAUUUUCYUUUUEhRRRQAUjdKWkbpTQCUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACrS0i0tSwCiiikAUUUUAFFFFBSCiilHWgY6iiigAoHWigdaAH0UUUkADrTqRetLSYBTx0plPoGgoooqWCHUtFFIEOHSnLTacvSoGLQOtFA60FIfSr1pKVetAxw606mjrTqlgFOHSm04dKTK6i06mjrTqkB46UUDpRUDFXrTqavWnUAKtLSLS0Agpy9KbTh0oZQtKOtJSrUj6DqKKKlghw6UUUUhoKKKKBjx0oooqUAUUUVQCrTqatOqWAV1fw18PX3iPxEljpuBd3LR6ZZFshftd2628fI5BUSNKMf88TyK5SvpT9iXw5a3/xN0fVb8qtrpC3/AIkvN65HlW0Igt3z2xJdzH1zH7VxZhiPqmFqVuyb/wCB8zbD0vbVY0+7KP7cev2DfE3TPhd4ewmi/DvRbbR7WJeAshjVnIP+55KH3iNfPs0kU8kN7NGhQYikWFoo2OO4CrlewyytyMEmtbxl4kufHfjnWvFd7Iyy67qdxfNuUuR5khcIAO43bQPYDI61LPbpeW1vZ2trcSqzkW9vDtVZXUHLsRw2F2k48xgMhpF4p4Ch9TwtOjLdLX16v5u7DEVPbVZTXV/8N+Bz/c4ztycZIJx2zivp/wDZxdfAX7MPx2+LRbZd6hZ2vg/T3Xh0a5YCfB7fJLE3/AM18wGNoZHiYqdp6q+8Z7gHvj1BIPYmvpDxVLH4d/YE8EabaybJfF3jbUNRuQB/rEto2t8H1wwT8qnH3lGFL+aUV8l7z/BBQ0bl2T/y/U+cV4Ueveu0+DVldX/xN0OCyjuHnEzOgttNiv5gQjHckMxEJYdd8pCR43sQErjPkIQouDtw3zE5O5uSOx7cYGAO+SZ7C+l0y+g1CCOGR7eRZAk8QlicqwIDo3yuuQMq2QRwQQa66kXKLiuqMk7O56V8e9KEep22r6fGsllMZWF0l216b1w+JJjeyASag24EPdKiwGTesPyrk/cXwt1NPir4T0oteefdfEHwBCpZZQH/ALW0tjAzrtVpUIePO8NGqlvl3SNuHxl8ZPFFz448M6Vr1lZ3m3XGjVpJCfMu549q7GmZEe8kjBC7IY4rS2XbHGhaTcfpT9lga14P8H3Xgbxa7Qa38LPE1prMkCXDbIrO/iEU8LBUfzHimR1ZEjZhISqMM76+czaEpYOEvtRfz/pT5bnfg5JVWns/6/K5774R1N9Vn8K6vqktukPjbQJfC2tPbOsoj1C3DKgkubdpDuHzp896zBiURTIXYcLqN3L4F+Lnwn8fXOy2i1mO6+FfiM79sf2qBy9gwCgRsxZduVLBQu3exBNekazpckMfi7QrR5J7zRr238WaLAJSblIjjesQBubhV3LImIYIR83lx8l3rkP2qNAbUvh3401PQJdmoT6bZeOtMaRlMkVzpkieayx4LjFu2DlwinCqpO414OGcK79k/hnp9+33KSf/AG6ehUTp++t46/d/w34n0GdRe02JazQrKVY7PKaaXcFLqojUjO5Uk6kZOMZPFTa74v0fwZZDUvHGu2GjafDLG51DxDrEdojCK4JDJGpVdxidip7lUV0OM1+VXjX9vT9orxrLLaaL4ksPB9rMGymkRrBIV5ODcSlpMjn7rr7CvJdV8JfFrxTqdvf69Za/rWsamcW0d3JJcajdrgkSLCxM7R4BO8rt6854r1sryKthI3rTUX5a/wCX6nLjMfCvK0E2j9PPFX7fn7P3hK4C3vxUvfEl1bmFntvDWhkwysjyll824KqVkVowwWQ4MeVI3EV82+OP+CgHgLWIW0/TPhp4y1+B7f7M0mveKmtmZDbfZ3JS3jI3OnzMQ/8ArBvGG5ry/wCB/wCyRbeM9ZmX4s+NLXwtpcKlCLGVLqcT9ondcwo54Ai3GbPHl1H+0j+zV8N/g3Yfa/A3xy0XxNf29xsv9Emngjv7eJseWwVJG3MDkOpCsODtwGx6H1fL5VFQk3KT9bffGy/E5lUrpOotPu/JnV6n+3bpOti8j1b4CWEsV+uppOI/Ed3GzLqCot2A2CF3+WhGB8rLuUKcmuy8M/t7/Dme7E+veFfGvh6SbWbbV7h7LV49SgJjgWB4ikqxHyZEUM6gk78uMNXw4DxmkOCCM4rapkWBqR5eVr/t6X6tr8CY46vF3T/BH3H+0F4z8IfFD4S6L8RfCfxOtdd1fwj4pf8A0i1M1hqFtpV/I6iGVEAmQqFijMiIQ4QkZLEHxf8At+/VSn/Cw9UXHGDrviL/AOQ8Vi2nhS68YeHfCl/aeGdPg/sm3X9/pvhbUw1+QwJFzNbjbMwZSvmIVbqN3Ax0n9jeK93zeHpj6n+y/FXH/kxXLh8PTwlL2Kbdm+2ivttbu9Et7FVasq8+e29u5SbxBesQP+Fjaocemu+Iv/kOud8Wa5qFqdN8S6Z4qmvdS8P30WoWhnvNWuyjKwOV+1WyIvIRidwyExzwK61tH8WAZ/4R1+emdL8Vc/8AkxVS/wDD/iS7sprS48M7op0aJz/ZXic4DDHRpyp+hBHqDXRB04yT1/Az946X9r/SrXxBd6X8TtGgC6f410Oz8QwdyJ4ljgnjC9iYprRmP/TE5r5g619VaQ0njb9kbSYdTJjvfh94qk0W7adSHhsr0GBxyMrtN2oHp5IHavlZo5IpHhmjKSRsVZSMFSOx96rJW4Yd4Z705OPyXw/+S2fzNMcuaoqq+0k/v3/G4UjUtI3SvYRxDaKKKoAoooqWAyilPWkqgCiiigTG0UHrRTQMa1JTmptULoIelNp56UymhBSNS0jdKZLEprU6mtQAlFFFADKaetOpp61YmIelNp9MpoApp606mt1qkSNakpWpKoBp60lKetJQJiNTacelNoJG0UHrRVgxlFB60U0J7BTKfTKoGFI1LSNQhCUUUU2A09aSlPWkpoAooooAaetJSnrSUAFFFFAmFFFFBIUUUUAFI3SlpG6U0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAq0tItLUsAooopAFFFFABRRRQUgpR1pKUdaBjqKKKAClHWkpR1oYDqKKKSAVetLSLS0mAU+mU+gaCiiipY0PooopCQ6nDpTacOlQMWgdaKUdaCkOpV60lKvWgY4dadTR1p1SAU4dKbTh0qWV1FHWnU0dadSBDx0ooHSioGKvWnU1etOoAVaWkWloBBTh0ptOHSkyhaVaSnL0pD6C0UUVLGh1FFBOBmkCAEE4BGR1or6i+Nv7OD+BP2PvhH8UksfL1G9uLh9ZZYyGMd+POsy/cbYodvPeSvl2sqNWNaPNHu19zLlFwdmPoooq0SFFFFUAq06mr1p1SwEOcHHWvqz4PM3gj9nj4s+NtwiK+HNO8O2U4+/vvQ80mD7G/iAH+xXymQTwoJPYDqfavqvx4ieE/2M763hfnxX8QLiJCO8FsHjQfQCySvGzn34UqH884r7mpP8EztwXuylU/li/ysvxZ8nGQRyxyHb8vzbSM8+uOmPrx+Ga6eS9aPSJUuJ2MhCrKv8MIySqyH+Jsg7IFwi7AWHyvjnLdgZfMjbaRyJB1GO49/Q9j05wR1T6Ag01G1NVgtrSNJJIUIzCJBmKM8fNcTbC3Q7I0zghdkfsztpc4kcoo2REY9TxXv/xnuW/4ZU/Z9tIiBCw8USNj++NRQf1NeD3MEtvdzwTxRxOjkPHHnCN3XknoeO/Tqep9s8aXUOu/sdfDe5iwX8LeK9a0eYd1NykN2o/EBj+BrkxTSqUW/wCb84yX6mtJe7NLt+qPFZI5IxF5kPl74gy8nLDc3JGeDx6DI2nnqY24U5pFYkncckYGd2eMDHP049sY7V7/APstfCD4eeM7Lxp8TvjFPcjwV4KsUW5gtt/mzT3O9EYGM7/3YUsAOrmPJ2hwdMTiIYWk6tS9l21bvokl3b0Jp03VkoRPSfB/hhvh18MfDvxL8R+HVPiaK0gTwjpeqOt3cvIyv5d7dRMwaG2cq1raIg2RSXEcrbnZXrU+ElrZfDX4v+BofEmu6bJa/EvTLvw5LZzXJe6n0qcD+y7yZFOAsuyEfMQxLy9Oc8d8NNdXw/4CHiDxnpuqeMbmGe9T4f6TfM4n1DTVjLyvOgJK2EbxRXAYMNktu3lnmUjntf1Zo/gAvxi13U7JfiF8SvFks0WoXFnuuIbLT2jIFmVyII0mVVJVcnEUYXYuR8/OnOrOVOT0k+W/reyXW0dW3/MrLrbuTjBKS6K/5b+uiXkfpF4Qt473TtC1a8vdNX+z7W58O6mkk67bh1dYkjCwsltu3JgrscruMaEfMWuDw14fu/D+k+DZNah+y2F3daBNFeQSaek8c1tJG1vb28Pk28rKjhUOyRFVHKguCw+bov22v2fbbwYfEmta5qF5q2v/AGLVLnQ9KsbhLy01CJEEo+0SsIwPMT5ShUCPoDuJrxbx3/wUd8e6jqV9d/DL4f8Ah/wz9smE8l7eIb+9eRUEaS5YLErBAAP3ZwBjJHXxcJleOqSfLBx9dEvv1e7Wmh31sVQUUm7+h5p+yr8I9d8f/GWbwva3y2aaQzm/vEneGWJVfB8to0aQFtrD5Xi648wZw36fW/7Pnw10vwddeGfB/hLTtMFziSZ1jDy3sgzzcyyiRpySfvTCYDrtJxXz/wD8E9tDi0z4V3HiFxfPf+JL2S8vLiY3AhnZWZVKCREQsAPmaPzBk8v/AAL9k6VLkhTSzXNJ18xlQTtGOnq11+/YrB4OMMMqj1b/AAPirxD8P/2hPBfxQ0jQvAGjpYNqDi0fxVDpyak2l28hEZe3gndppFTepcptiRTuaGPgjxP4v/sLftc33jMy6jcWXjaCaVkt9Ui1WGGKJGPeGZkaHPBKopX0J61+tdrHF5W8qCcYzisLW0Dk8ZxXp1cfVwFFVKai5W6r+n+Njkp4WFao4ybsfjr+yl8BNJ+J/wAY7HQPiJePp+i2888ZjJMP9qzRAhraCQ4O7OWOzLBVOdvDD6J/4KG/AnwN4K+EOkeKfh/8PtI0t9M1mCC+vLG1WKUWr27xr5rDmQb0iG58ndjn5mz9s2GhaFaanHqcGiafFexQm2juUtI1lSEsWMauF3KhJJKg4JJOKp/FPwRo3xG8Da14H8QR5sdcspLOVgATEWHySrn+JHCuPdRXmVM/nXxNPFO6jBq6v06nXDLlTpSp6NvqfkRpHgOx03T0trzwLrN9Lku01z4ZR5OQONy6ioIHb5RVn/hEtGPK/DnUvw8Kj/5Z1DFol54fu9R8I+JpdJsdY8PXk2l3kU+naBFh4mKhla72SyAqFPmEEMSeTUps7PGRq/h4nHaHwp/SSvrnVne6mvxPDUVtYR/CmkbQD8ONRGe//CLD/wCWVMk8JaOAD/wrrUB/3K4H/uSoFrZ9P7Y8On/tj4V/+OUNaWgyDq3h/wD78+Fh/wC1KPaz/nX4j5V2PQ/2frA6ro3xq+Eo06e2Gs+GTqmnWdxa+QUlhU7SIhJJt/eSxY+duEHToPnLxYRL4jvbxRtW/KagF/ufaEWbb+AkA/Cvoj9l+/t9E/aW8P24u7GeHXdLvNOk+zHTgpAjeXBWxdkBzGvLYY+4Arwj4iaO2g68mlSAiS0jms3z1P2e5mtlP/fMC1z4J8mYVo/zRhL52cX/AOkI3rrmw0JdnJfk1+ZzFI1LTWr3EcIlFFFUAUUUVLAaetISB1pT1r6I/Yp+BNv8b/G/ia31a3D6ZpXh67hMh/5ZXl5G9vbtj1UPLID2MQrHFYmGDoyr1NooulTlWmoR3Z87UVa1XS7/AELVb3Q9VtzBfadcy2lzEescsbFXU/RgR+FVa3TTV0ZsaetFB60VSExG6U2nHpTaoOgHpTKeelMpoQUjdKWkbpTJYlNanU1qAEooooAZTT1p1NPWrEwplPplNAwprdadTW61RI1qSlakqgGnrSUrdaSgTA9KZTz0plBI09aKD1oq0DGHrRQetFCF0CmnrTqaetWDEpGpaRqEISiiiqYDW60lK3WkoQBRRRQA1utJSt1pKACiiigTCiiigkKKKKACkbpS0jdKaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAVaWkWlqWAUUUUgCiiigAooooKQUo60lKOtAx1FFFABSjrSUo60MB1FFFJAKtLSLS0mAU+mU+gaCiiipY0PooopCQ6nDpTacOlQMWlHWkoHWgpD6VetJSr1oGOHWnU0dadUgFOHSm04dKlldRR1p1NHWnUgQ8dKKB0oqBir1p1NXrTqAFWlpFpaAQU4dKbTh0pMoWlWkpVpD6DqsabpmpazqEGlaPYXF9e3TiOC2t42kllc9FVVBLE+gFV6QjNSwR3Y+BPxyOdvwZ8dH6eHbz/wCN10/w1/Zc+M3jT4geHPC+sfCvxjpWm6pqdvbX1/d6JdW8Ntbs482RpHjCrtTcRkjkAdTXqn7OH7cms+CZLXwn8YZbnV9DXZFb6wqmS8sV6ASjrPGBj/poOcF+Er9Nvh74i0XxJpNnrmgava6lp97GJbe5tpRJFKh7qw//AFg8HB4r5PGZ5jcDX9hXoJJ7SUm0/wAN/L/hz16GX0K9P2lOpdrdW1/P8Sj+0R8G7X4ofs5eKvhvp1gvmy6SW0mFRjZdWwElso9PmjVPoxr8Yj+z78fEGX+CHj8fXw1e/wDxqv3/ABIraaOR0rxj42/F7wB8GPC0/jD4g66ljZqTHBCvz3F5NjIigjzl3P4Ko5YqBmuirjZZZCMKMOdytZX6/czKFBYmTlOXKkfi9f8AwV+M+lWFzqmqfCLxrZ2dnE09zcXHh+7jihjUZZ3dowFUepOK43Oele3/ALR37WHjz9oHUZdOLvong6KYPaaJDJnzCp+WW5fjzZO46KvG0A5ZvEK9rDTrTpqVeKjLsne3zstTiqKEZNQd13tYKKKK6SBR1p1NHWnVLA1PClst54s0S0kGUn1G3jYezSKP617/APG+7e3/AGSPg3psuQ+q3uq6vKD1LPO7/wDtc14L4Iz/AMJv4cx/0F7I/wDkdK9w/aZYw/Av4B2ychtAvJcds4tT/wCzV4+P97GYWH99v7oTOzD6Uar8v/bonhvhHTJLq+jm+xpdXEsohsbV8eW03XfLngRRg7mLfL0B+UuR0uranDb2UU+n3ElxFbyyppMs0TK17dkg3WqSFvmGCAEzjGE5Jik3Yfh1WNu1otx9nmvIGW6u9pP2GwX5pcAY+aTkYGCwO0Z84ik8Qai8tqLtLc25vIhFYW5Yn7Hp6MVUZ6bnYHJwpJ3kj99XpyXPU/r+v6fkcmyOdiXaoHHHpxXe6D8RLCw+Dfi34V6tp1xctq+qadrGkToyhLS5h8xJy+eSHhlKjHdRniuBTbGqRZycfn6mn1VWnGqrS7p/c7oIycdh3yGNWyu8ZTCgAgA5y3rndgeyn0FeifBr48/EP4FajqF94GurFoNXhWHULDULYXFrdKu7YXQ85Xe2CCOGYcgkHzfzR8wTBZex4564p53gMskZR1JUqeoIOMUVaUK8HCqrp9GEZODvF2Z9ffA6DxR8SfCPxt/aU+IOoRahqMXhbUtLsJhKAbdjZuZESBBtijWLy0QcYDMAOpFH4KfD7VvjP+zzpWheH9ZktNX8PeML+xgmRjDHZQX9nGrSzMiSSMmVcZVf7wZkUFx6x4B8O6R4I/4J++Jr63s2ivNa8P3kt5NJHGGmaWXy12uhbfGA/wApLHO5jhCxUfOX7IfxSg+FfiuSTxpakeA/FUkOl6jczITBDdxnzbeU8fN5bfeA6LISf4QflIzq4iGJq4Za05pRXlFWaS9G7Lq35nruMKbpQq7Sjq/V3v8AkeQ6z4H8UeHdZ8Q6DqGjT/avCsrw6u0UbNHbbZ1g3M2MBTK6KrHGS6461iE8E1+s9t+zD8P9e8G+NrCW/vNW1v4jA3mpa5NcbWupSxlt9qwMiC3WQowjVgGCruc4BH5S3GmapoPiN9C1KxaHUdOvzZ3Fs0SzFJ45NrIU5V8MCCvIOCK9fKc2p5rGThvG35b997/Kxx4zBzwjSl1P0D/Yx8S6f4L+Fmn+IfHms2OjRX4FnpwnsZo7jUArEIsckzvNdbQAFjto1iXtubcF+0fDGqjUbWO8WzvLZZOVjvLdoJQOxMbfMueuGAOOoFfnJ8OrnX9GjvPFN/fvpd7bhbXVtUudTS1vYQSNsF/rEiN/Zy42hdPsEa624R9pAc/YXwC1XUdT063u43vxpLxGW1ddIOk2FxnGZIIrlnv7lTn/AF85UN1A5r4vNcJy15Yq+rfy9Nv11Wumx7WDr3hGjbSx9J2c4MHJ7Vk6u45xTrOdvL5PaqmpuWGM0YnEe0w6RVKly1TIVwsoJOKuXzK1qG68Y/Gvnn9oX4V/GLxRcweKvgn8XtR8Ma1aqY30+e6cafchlCF8BW8twoGPlIyCRtYkn8+/GH7QH7WHg3xRqHhvxp8SvFGna1bWkOm3dtNcqGSEbZFAKcKxyN0ikO3IcnkVnleUf2lTl7GrG/VO918rbeaKxeN+qyXPB+vRn0J+3F4M/wCEO+I+ifFbSoES18WJ/Y+rgTW9uPtkK5glaWeGVV3RfKfl6QdRmvn9tehdgzXFj7f8VRpI/wDcfWn4k+NXxc+Leh+HNP8AiP8AEDw3fafpd7/bCrHqMGnXrXG1xEXljXMbR7yFCqMdxnBFF/EVwCceMbn/AMONOf8A2SvrMBhauGw0KOItKUbq6b2vp22XkeJiasKtWVSndJ/n1IH8RR8Ay2RGe3ifSf8A5Apx1+Db/rrLn/qadJ/+V9OOv3L8t4yuSff4izZ/9AqJ9auSMr4yuAT/ANVClOP/AByuz2cf5Px/4Jjd9zU+GWtonx6+G17FLDlNW+ykxaraXZAm2pyILeLb948tuz2xg55H9omxNl8SvEcJzmDxNrMAz2U3Hngf+TFb/hvUJ5fij8O5X8QyX5TxXpwCP4nfU9u6eMEhGUbPTd36VF+1ZCsXxS8TkADf4n1Bj+NrYn+tc9G0cygkrXpv8Jf8E2lrhX/i/Nf8A8VprdadTW6176OASiiiqAK6bQPhf8TvFemprPhb4c+KNZ0+R2jS70/R7m4hZ1OGUPGhUkHqM8VzNd58IPjd8QPgh4g/tzwXqpW3mI+3abOS1peoD92RM9fRxhl7EZOefEOrGm3QScuibsn89bFQUXJKbsvLUhHwI+OR6fBfx4f+5bvf/jdfpt/wTx+C2r/DX4GS6l4o0S80vXfE+oTX11a3lu0M8EMf7qFHRgGX7skgDDP72tX9mz9pbwD8fNJEmiXX9na9axh9Q0O5lBng6AvGePOiyR84AIyNyqSM/TOmFVs2JPbvXxtbNcRmTlgsVS9m1q1e+3y263Pbhg6eGtXpT5k9tLH5I/tr/s5/ECz/AGgdc17wL4A8Qa1pPiRE1Yy6Xpc1zHDcPlZ0YxqQGMis+Dg4kFeCt8EPjWhw3we8bj/uXrz/AON1+03i6WOAzTyzJHGgLuzsFVVHJJJ4AA7mvg39on9uTT9Ka58I/BK4g1C++aO48QFQ9vAen+jKRiVv+mhGwcbQ2dwyyriHMMROOBw1BT5Ek5NtJJbN6f8ABfQvF5Zh6cXiKtTlvra138tT4m8Q+GfEvhLUBpPivw7qei3xjWYW2oWkltL5bZ2tskAODg4OKzas6nqmp63qNxq+s6hcX19dyGW4ubiVpJZXPVmZiST7mq1ffw5uVc2589K19BG6U2lakqxdAPSmU89KZTQgpG6UtI3SmSxKa1OprUAJRRRQAymnrTqaetWJhTKfTKaBhTW606mt1qiRrUlK1JVANbrSUp60lAmB6UynnpTKCRp60UHrRVoGMPWig9aKELoFNPWnU09asGJSN0paRulCEJRRRVMBrdaSlbrSUIAooooAa3WkpW60lABRRRQJhRRRQSFFFFABSN0paRulNAJRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAKtLSLS1LAKKKKQBRRRQAUUUUFIKUdaSlHWgY6iiigApR1pKUdaGA6iiikgFWlpF60tJgFPplPoGgoooqWCH0UUUgQ6nDpTacvSoGLQOtFA60FIfSr1pKVetAxw606mjrTqlgFOHSm04dKlldRR1p1Np1IB46UUg6UtQMVetOpq9adQAq0tIvWloAKcvSm05elDKFpR1pKUdakpDqKKKTEgb7nTNfrJ+wRoH/AAhXwI8O2kq7Z9ZaXWZcE8idh5X/AJCSI/jX5U6Fpseta3p2kT38FjFe3cVvJdTuEigVmAMjseAq5ySeABX1R8bf207pbB/hx8AZ5tJ0S2gFi+uqDFdTRIuwLbDgwJtAG/iQ9tmMH5jiLDYvMPY4TCreXNJ9El39b6LfQ9XLKlHD89as+lkurb/4Y/UfT/i14B1bXtT8BaR4y0i98RaLGsmoaXBdq9zbKe7oDnjjcByuV3Y3DPwT/wAFSvCDX9h4N+JVvuZbOefRLrqRiQGaE+g5ScZ75X0FfBWh+Idf8M67a+KPD+s3mn6xZTfaLe+t5WSaOTn5gw55yQfUEjvX1dqP7VemftCfAvxB8Kviw0GneMEsxd6VqKKI7XU7q3PmIhH3YJnVWj7I5fA2EhTjiMBi8Di6GJpPnhGykuqT0bt1S37r8SqVejXpTpT0k9V2729T5DX0paYpPen19S9zygoooqgAdafTKcOlJgbXgkZ8beHRnH/E3s/y89M17f8AtHsb74A/AfUIiNsejXtuG9x9mH/shrwTQ74aXrum6oxAFndw3BJ9EYH+lfQvxm08n9kz4cGTiTRPEWq6OSP4QJ7naPb5YVrxcwfJi8LP+/b74T/4B24b3qNWP93/ANuieAaO8Ulo9g0rLbyAT6jMhAf7OhG2JSePmbbgfdLGIHG2l1czXtw008aRySxLdSxoMLBBtCwxL1wuwoB14ZAfumqOlSRKsgdAbaI+bIpJHm7eFTjnknqOcEnHy1fkkIDvfESux+33pccSSHPlxkAY53ZO3Bw7ZGUr2HpL+v6/pHEtjGe1ki2kAjZtDtjkZGQp+oB69CGFP7Vd1MTra2ySYMjsbq6JYb98uSgIHUFVDg9f3h9azVkklJ2JlQcE+2f8/mKrWWotjrZLGzm+HkEqxWK3UVw8+/8AtGyE5UsEIMIjFyfuqQDIVABYLzWPpOl6j4k1RLKzSSaedmmlcQySbF6ySMsSM+0DLHapOM8V6hpghbwXFpE/iXV41l0/y3t/7R1lYMuhJXyUsWi25PKhyh/vEHNee/D231G68Z6SdMtpLie3uEuQI3nVlCEEuDb/AL8BPvlowWVUZsEKRXLTqNxm7Wtc0aV0feXxTh/4Qz9gG4srbUILtL+Gyht5oJ4Zo5I5b6N/lkihhEmURzuaMPkkOSwJrwjwl4J1nW9OihEVtHYQaVbwaveavdLaWdjGQrJFfTxEC2jZjlbC2P2iYlmmcHaB7H/wUP8AFB0H4Q+Bvhsb64nu9SvBe3LzzLNJIlrD5ZMkiqocmS4J3BV3FCcCk+AfhKDV9U8LaVeXuoRTaLawXdvbWlhGG0yN08xZWh+aDTBN/wA9X8y/uc7/ANyjEV8dha7wuWvFPTnnOX5L81+vQ9utT9rilSXRRX9f15HoHgH4BfHj4S+CoJPgf8cLHVomtjdLo3iPSyLEyMN6tauWZ7YHj5GwpJy/U4+M/hnpt9aeItZ17xVp2q3PjGTV7mylgVhDf3OoAlpoIH6W5GWkubsgeRHjbh5FNfrbp8Frd2ktneQR3EFxG0U0Uqh0kRgQysDwQQSCD1Br8yPj74E8Ffs7fGzVtN0TRtUutFvbS4vbrSLZylq9vLtktrQszNceQGRftEqv84JjXZjdSyDHyxyqwqfHLW6STdu7Vv66oWZYdYdwcfhXm9PvuanhiHWvEOpaPJpdvDfXVsWg0P8As3TI5LW1SNszJoVjMRCkaMMS6rdnYGVmBaRN0n2z8FfC8fgrQhqGppbyXWpw/bbrUxey6i7KMc3OpTkNcuc5yqRxAK2xAoBPyt8F73RvFbyXlteWeti5UX98t5KtrYR20B2Lfa00ZCw2cZQraaVGQoVEZx/y1r7F8JeJ9K8QWOn6zp80muQSxRW9nqVtFg3ccpO6cQAARQZjysjcMq5QsMF+POqs/wCElZLf/L79fva3aW+AhH42/T+v67dj02yuCVGOlNv33Kax9B1IXljBdrNbyCeMPvt5C8TZ7oxxke+K0biQMORXie1vT5WejyWldHjfxT/aK+Dnwpnew8X+NbQamDgaVYg3d9kjIBhjyY846yFR718M/tBfFv8AZc+PGqT+Mb2Lx3ofiHStOmsraMWNqE1N1VjbiRvNfy9rkAkjOzjggEfcmvX9v8M9f1jxVqfgTwxYaReXBuLrxDp8MNrPGrMqhryR8bsYkkkmZlHzRRxpK5JrxL9pjxx+z3478C6zPqWveBNRvk0m4+ywywPH4iju2jJtvJGBKuZfLykoC7SS3Fevk6pYevGVOnNt/ai113VkvzfocONlOrTalKOnRr8b3/I+Q/DXiCW10HTLcPp4MdpEg3eItJiIG0YBSSyd1IGMhmZgc5JNaL+Jbrkm40s46Y8U6L/8gVU0nULmPT7GO/8AGXiETpbRJIn9s65GVcIAV2pZMq4PGFZlHQEjmrcmrk7lXxh4kGB0/t7Xj/7Y19rKK5m+T8/8zwU7L4hV8Sy5AFzpwJ658VaP/wDK+kPiOYgg3OmcdB/wlWjf/IFMTVCR/wAjb4jzjn/ie69z/wCSNM/tVsbW8XeIhz1Oua7/APINLlX/AD7/AD/zHzP+Ys+FbuTWvi18OrENbt/xVNjL+51iyvMbZozyLe2iK9+SSOOnesz9qO8W7+KPillbIXxVqSD/AIDBZp/ND+VdR8HnXXP2ifhzYLrepagIb+4umW71C/uQhSIuCBdQRbf9UeVznHOMDPnHx4vje/EPW5twZbvXNXvlYdCr380a/wDjsK1hRiv7Sjpa1Pb1k/8A5E1k/wDZX5y/JL/M87pp606mV7yOAKKKKoApG6Ypaax7+lTuwPp//gnj4I/4SH47P4wuIibbwjp0tyr7iMXM4MEQ9/leZv8AtnX6i+IPid4K8A6VaXXjTxbpWhw6jcLZWj390kInnboi7jye5PRRySBzX5gfBD48+EP2aPgtNd6fDb69478W3b3i2CviKyt48xQG6deRz5sgiBDMHXJQEMfAPiN8S/HHxY8STeKvHuv3Gp30vyxhziK3jzxHFGPljQeigep5JJ+QrZXis2zOpXm+SlFcqfV23su129evS57MMVRwmFjTjrN6vsv6R+u/xw0pfHngTxL4OMgX+2tLubONs9JHjPlt+D7D71+MLRvCzwyxskkbFWVhgqR2PvXvnwM/a38Y/DCG18KeK5LnXvCcIEcUJYG609QePIdjyg/55Mdv90pyT5r8Zf8AhGpfib4g1HwbqUV/omqXR1Kymj4+ScCUoVPKMjOyFWAIKEVfDmW4vJsRWw1f3oStKMls7aO/Z7aeWlxZpiaONpU6tPSS0a/L5bnF0UUV9gjxWNbrSUrdaSmN7CHpTacelNpokKRqWkamSJTWp1NagBKKKDQAymnrTqaetWJhTKcabTQMKa3WnU09apEjWpKVqSqAaetJSnrSUCYHpTKcelNoJGnrRQetFWDGHrRQetFNC6BTT1p1NNUDEpGpaRqEISiiiqYDW60lK3WkoQBRRRQA1utJSt1pKACiiigTCiiigkKKKKACkbpS0jdKaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAVaWkWlqWAUUUUgCiiigAooooKQUo60lKOtAx1FFFABQOtFA60APooopIBV60tNHWnUmAU8dKZTh0oGhaKKKlgh9FIOlLSBDh0py0xelOXrUsY6gdaKKRSH0DrRQOtAx4606mU+pYBTh0ptKtJlDqdTaUdKkOo8dKWkWlqWMUdadTKfSAB1p1Np1ABTlptKOtDKQ6gdaKKkaH0Ug5paQCj0pcAdKaOKdUj6hRgUUUDCnDpTactJgLRRRQgClBxSUUwHMNwwRkHrX1Lq7L4o/Y/wDGYk/eSaL4vg1u27ssN6kLrx2/4+5Pyr5ZHIxX1D+zhjxp4H+Ifw6GXvPEng0XVspGUN1YvLFGB/tbWtM/QV4mdr2dGFf+ScX8uZX/APJbnbgfenKn/Mmvw0/Gx8tRzFSq7AUZ9wQjhsdM+o/xODzWlaQy6te2ulJNiS9uVaaZhn52ONzd8KCSc8gl+1ZzLvUBeN3BPX5f/r1r+HrWWWa4NsgeZofsturNgNLMREFJ/wBx3Yf7le1JpK5xIn8RmTUZLOCwtWUzublYWI3QrI4SGLjjaI0gx7OazporW1t7iW1z5VxHtCsOQxlLofb5Ix+YrSmmgbVL3VbW4PlQTLHZsQQBDFG5iz648q35/wBoetZGprIb2eNuDGqW7AcbmjGzd/47+tTHpEH3Pf7bSfFXkxRxaJqAjVFVANI8S424AHAucdPTisH9jnwhL4t+PXh+3+wvcQ6a/wDaE5VGPkrEVZX3I6yRESeXtkXOHKBlKMwqzLoGl28T+b4JdtqnO7wvbnGBz/zEv1rp/wBmrxKvwQ+CHxD+NsluI9W1EQeGvDcrrC4kvGDs5Q/6xWiXErL8qsu37xxjwa85xwlVUneUrRXrLT8L3+R3UYxdaLnstX6LU5/9tb4jp8Q/jvq8NjcrNpvhhF0O1ZWOxmiJM7AdBmZ5RkdQF9q+v/2NbFYvBFveeQII5tPtZLWNGNtC8bD95LFZn5wrSIVN3MTJO6Pt2xRoD+ZbNI5aSV2eRyWZmOSSepJPWv0P/YqexuvB+karN4hiibyzY22l2plxcXEcW2Sa5mfm6mSFEVIl/dW0LRjG+TNebxJhY4TKI0Ke0bLbt6d7avbfyOzLKrrY11Jbs+ydLfGK8H/bW/Z6f4zeCrXXNDtNMTV9CcS3Ur6Wbi7ubFQ+Y45IyJsR+ZJMsKBvMcKMZxXuGmvtwas+I9M1DV9HI024ukurVxdwQQ37WaXcseWSGaVVZliZ9u7aOQMEMMqfisoxU8NVjVpuzR7uNoxqwcZLRn47+Pbm98Ha5d6RZR3dvBBcPdzxa/aRNNdtJCbi3fUUid1a4L+aVt5kIjPyvuBevp/4F/tNeHYvD2rWP9n29hate215e6rq19LJIApUyX+p3yMDNK4VY4bCGPJKBPucnif2lfg74rbxPeW3hn4f6U/ibXJ2a4tILu4uL+aUzPPcXunWO+T7LZFhtM0+15DlkWNXK18hfLsSNJw6kbio3fKemDkDnAHTIxj8P0xYfD5vhlffT/h9H3Wnp6o+T9pUwlV2P1l0r9qTwksIv8XVnZmWW8nGp3K+ZY6UXDDUr1sE23mZZLezAaWXdDtUBgV9J0z4taDq+q29k9zcWMw0+K+ubG5jUTWqzxCSFbpfvQzsFkCW4LSOFdtu1c1+Men6/relXNtcWWq3SG2vEv0XzCVW4XpMFOQJAM4bGQa6/wAM/Hj4q+D7qK+0LxKEu7cXb29zJBHLJDcXWPtF2C6nNy6jYZ23SBPlDBQAPJxHCkGm6Mtdd/6f9emvbTzeafvo/Y6/ktbuEhgki/I5R15QkBl3KeVOCCMgEcGvlT9pT9lH4R6d8HvGHj/wb4Qg0vxHpm3Xku0ubgg+U6tMm3zMKpj3ngA7gDnNfI2l/tf/ABz0qGC0tvE2y1ttOOmRooO9Qzo0tzvYkvcvsx50m9l3NtK9vZtY/bhm+JnwO8Q/Du88OeZ4z8QpLpVtb2oK2xtpt5kclvuiOEBBlnd3JY7RXm0shzPLMRCrQlePMr2dtL/aWmnc655jhMXScKis7O11+R5bb2vie+s7bU7TRdTaK5iSeN4dM8RPGysoYFX+1YYc8EE5HOal/s/xdg48PawxPJYaV4j/APkqsqz8LaZbWsNsfCl1OYo0jMk3hi2LuQoG5j/aQyTjJPel/wCEc0wkj/hC2POcjw1B/wDLKvp3a+kjxVe2xoHTPFZO5tB1kccH+yvEP/yVTTpXin/oXtXwOn/Eq8Q//JNVP+Ee0zHHgt8f9ixB/wDLKoJPD2mMpx4LfrjP/CNQf/LGldfzfgCR6L+zPa3SftCTaxrdnLBH4W8NXeot50V5GYy2FyVu5HcZWUkYIUgZx1J+a/Fl7Pe39q1w26QWcUztn7zXGblj/wB9TtX0D8GYE0D4QfHDx3YWRgW9gh8L2ESW4gcTzHyWUIHkCndNCxAduec186eI54J9ev3tHD26TtFbkdPJQ7Y//HAo/Cnl8XPG1p9EoR+aXM//AEs1rvlw9OPe7+92/wDbTOJ7UlFFe6cIUUUUmAGmU49KbQgDAooopgFIcDgUtNPWgW7CiiiqQhp60lFFMGI1NpT1pKpCCkbrS009aCQprdadTDQAUh6UtI1NANptOPSm1QhD0ptObpTapB1CmnrTqaaaJGt1pKD1oqgGnrSUHrRQJiNTac1NPSmSNoooqgYw9aKKKaB7BTKeelMqhMKRqWkbrQhCUUUU2A09aSlPWkpoAooooAaetJSnrSUAFFFFAmFFFFBIUUUUAFI3SlpG6U0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAq0tItLUsAooopAFFFFABRRRQUgooooGPopFpaACgdaKB1oAfRRRSQAOtOptOoYBTl6U2nLSGhaKKKlghy9KWmrTqQdRV6U5etNWnDrUsY6iiikUhw6UtItLQMdTh0po6U5aTAWlXrSUo61LGOpVpKVetSNjh1p1NHWnVLGFOHSm05aQC04dKbSrQAtFFFA0PopB0pakoVT2p1NHWnUAwpw6U2lX0qGPoLRRRQCClHWkooGPopAe1LU7AFFFFUADivcP2UPGI8J/FDw5eSyusC6r9hnVRkNDfx+QWf/AGUmS15/2q8Pra8IXLxaytjHKYjqUbWauGK7ZWIMLbhyoWZYnJ9Frkx2HjisPOjLaSa+9WNaFR0qsZrozoPjj4L/AOFefF7xX4RSMRwWepSPaqBgC2l/eQj/AL9un41zGl3f2SPegbzEZ5+BlgyoVgdR6iSQ/lX0F+1vbxeO/DXw9/aB02NdnibS103Vdn3Yr+HdlT3zkTJ9LevmRJbiKZZY3w8bEqT0A3DAPtwTWOV1pYvBwlU+K1pf4o6S/FF4uCo1pKO269HqvwOi1S6htFEGY7m3VyjdDujDrGD9cWin/gdZ+mRm71a0immQGe4QPJK8aLywySZSIx/wMhfXiqAY3DlnjCCPaigdOAM49sjP410vgRIv+ElhuZxblLWN5is19bWgJxtAD3CSRk5YHaUOQDjGMjtl+7gzBe8z0Gd9NWK4I1jQciNyMWPhU/wn0fI/4Dz6c4rN+JutxxfCz4U+CNPiSK1ttIvtbuygC+feXOoXEZZ8feZYraFQTyBwOK3ZdZsHwrWunlMYYDxFoWcd8f6F1rj49GTxlp1n4StdS0y38Q+HjJa2MU19GIdStJJWmWKO5JERmSWWYgEr5gkCrhkCP5tOzalJJcrvpbs109TaTsml1/zTOEr66/ZL8a3Wk+DkJ1KGFdImlzGL1vMNv5qy7ruXB+waessufJjBmvJ2CKGC7R8qa34f17wzctZ+I9Ev9LnXrHeW7wt+TAGvpP8AZTtZP+EQe8vLu4hgj1ie4slhuIRcO8dvH5klrGQFidEb59QuWMdqjnygJHZhlnahUwTctVdf1/W261RtgHKNdWP0e0i48yOKQhxvVWw6FGGRnlW5U+x5HQ8119nIDGFI4NeZ+ANUt9V8MaVf2Sxi3ltk8ryzK0ZQDAKNMBI6EDKyMAXGG6MK9AsJiVANfkuGbpVXB9GfZVffgpHiH7S/w0GtWDw6Tc/2bZ687f2na2du8j6pcgEgvbWypNfuEXhZ7iO2jVN0gYZA/O/42eCdCstJTxD4XgVrW1uvImvUliliuCcJ5YuUMdvPLHtQeRYxvFDH1lkPzD9Lv2krHWtd8KppNjoUt9pyf6TfvI09xbSDIVIG061In1JyxBW3LJATgysVG2vzy+OGuTSaPqtzcyvLcIq6XPcs9vc3UZV/ltpZ4gLOxRQwYWFirMqhlmf5c1+g5BWnLlSfXb/P/g7adz5fMIRjJ6f1/X6nz1RSBiwBcKCFVflQKMAAdAOvHJ6k5JySTS19kzyDQ8Paba6trENlfXK29s4dpXNzBAQApIw07omc44LdM4yeK9Ms7PSLK3itoNa0ZkiXaDNF4XlfHuzyFmPuSTXm/hjV49D1qHUJ7ZriJVdHjQwhjuUgYM0ciDkjkoeM9Oo9RGvW6kf6Hp4wf+hi0P8A+Qq48S5ppJK3nb9TWmkR40s8NrGhcc8WnhX/AOLpyppcmTHqejsOmRZeFj/7NVbU/Flpp1o97Np9tJGhUbLfWdHnkOTjhEscn39BXM+Eb7wt4y+INnbfEiO+TRrkSQK2mXthpksC/MyO8s0QgYL3yELdARwKyhCUouTSsvJMptJ2udZKumqMf2roatnkG08Lf/F1VvbjTrSznuhqmjOYY2dVj07w1KSQOAERizc9lBPsao63fRfD/wAZal4G02c6zpFrd+Xo1/PbW2n/AGq1diYp2a6t3O11ZGDMQuDkEqQRLo0d58T/ABjpPwusNONvNrGqQ2stwkllMiwrJ+8kRobaPIULv3B8YUjBzTs4r2jS5bXvZLTfYE7vlW/6nrPiTd8Nf2Wvh94baTy77xHd3HjK7KrtVkiTdbB8dAzyWIx3IPHp8rDGOOnavob9r/xja6r48v8ARdJKLp2iRweGLJI2yqxWwEtyuOgImkhTI/59yO1fPNZZJCX1b28171RuT/7ed19ysvka45r2vs47RSX3aP73qFFFFeucYUUUhOKl6gI1JRRVAFFFFAMKbSt0pKBIKRjS01utWJCUUUHpQDGUUUVQmBptOPSm0EiHpTacelNoAKa3WnU09aaAa3SkpWpKoXUa1JSt1pKpCA9KZTj0ppqkIaaKKQ9KYDaKKKBMRqaelK3WmnpTRIlIelLSN0qhMbRRRTQMQ9KbTm6U2qBhSN1paaetNCCiiihgNPWkpT1pKaAKKKQ9KAEPWkoooAKKKKBMKKKKCQooooAKRulLSN0poBKKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBVpaaDzTqlgFFFFIAooooAKKKKBoKKKKChR1p1NHWnUAFFFFAD6KQdKWkgCnDpTaVelDAWlXrSUo60gQ6iiikx9RV606mjrTqkOoq9aWm06pYx9FA6UUhoVadTR1p1BQq9KctNHWnDrSYDqKKKQx1KOKQdKWoG9h1OHSmjpTlpMBaUdaSipGPoHWiigB1FA5ooGhQeadTKfSYwpwOabSg9qRW6HUdKKKTEhwOaKRaWpHsBIAyTgClIKkqwIIOCD1Br0f9nP4cSfFb42eFPBvlb7We+W5v/lyBaQgyy59MojKPdhXR/tk/D1vhz+0T4qsY7dYbLW5xr1kq9PLusu4A7BZfNQD0SuV4yksUsJf3nHm+V7GyoydL23S9jxUcGnUylB7V0tGQ6iiihAFIc9R1HIpaKYH1p8H2X41/CDxn8GJiH1DUbX/hKfD+9j8uoIwW5hBIIQNOFIUEkR3jHAr5LnikUSQyIyyrlGVlwVPQgjqK9E+CXj/UfAfi+w1jTg0l1pVydRtIgeZ127bq2HB/10G4DuXjiA612n7XPw807QPGll8UfCO2fwp8RIP7Xs5o1IRLlgGmQ/3SxdZAP+mhX+A14mG/2HHzoP4anvR/xJe8vmrP1Ujuq/7Rh1U6x0fp0fyen3HhACxrgcACvU/A0Wj+H9IEzeMZdPvrzbJcLaazfWRAH3Y5EjsnBZSW53sPmOKwPh14J1PxDdf2yNLlnsrN/k8zT7+eCeTH3d9mhdSuQ33l5x1Ga9bl/wCE8lwPsl/gnGdvisg89eWrrxVaN/Zv5nPTg/iMP/hIbGQ5HxM1Zfr4r1IY/PT6z9XHhHXIo4Nc8ZzakiP5iC78SX8yq+CNwDadwcE10z2PjdS2bW9A9fI8UjP5msvX9d1rwvbRTa1qEVmZlYwJdS+JbczFRyqmR1B6ge2RmuWHI5Lkvf1/4Bo721sczLc+H9EtpLfR/iHfW0EalltLPxBdqCcZCgHTwMnjGcdeter/AAL0DUNN8M2djrmm20sl7qEdzdWcNr9okvbk/vYEukZh9tuQgDxWRZYIRm5uiqrtfgPh/wCN/gr4o0HxN4N+NujX+n33iC9jvNO8YWge/uNKEaEJbtHKzSPByQdrF23YPKoyet+FdC8ZaTZW9h4HTwb8T9HgtRZQy+HNXhFzFbFoz5c2mzFJmDYeWSEBftEpTz5JI1EdYZhNqm6LVndaytZ6bqW2/Ru91f11w6Skp3v6fqt/0PtzwLr9x4k8PWuuXD2TPeGSRfscrTQhN5ChZWAE2MYMqAI5BKfLgnu9PnGBk18w6T+0X4d8B+G5F8W/Df4saNdWyyOw1vw7L5l3IOh81f3Y3YXAAVEGFUBVApkn7f3wCsri0tRquqyST3bwT/8AEumUWkSk/v5MruYMBlUQM3zLu8vnH5wspx0qspUqMnG72V/yPqfruHUEp1Fc9a/aVv2X4d/2Sk0Stq10tqYi13JJdDaWMMdra4kuywBzEZIosAtK4jDA/mX460zRbvWINa1nx3PfaRY3H2CaGCK3uLfTI2gdo7eGO2lghkd2jYtFajyIg6gzSFiT9e+If+CiXwS1LQLqzn8Ka5qkV3a3SS6fPboFmUP5ccEm7K4lXLtjcqpxmRiUHwN8RfGP/CeeNNR8WtA9sNQdWW3JAjtwAAsMagALGihUUeig8Z2j7nhzCYugpRrQcPN21fkv19N9T53M6tGpJOnLmMvU2sS1mLC0gthFb26zyRStLvlILO5STGW5AIHyDbjvmqQ6DNaVr4Y8TXts15ZeGtVuLdRkyxWcjoB65UGs6RWhma3lG2RfvDIOD6H0PtX1iaei6Hk+YVp6b4r8UaLbCy0jxPq1hbAlhDbX0sUYJ6kKrADNQ6Npcur3pgWK8NvDG011LbW/nNBEoyXKllGOgyzKORkim6fDG811cIwMNrBLKplgZg3ykKGAyFJJHJOAcc+qajLRjWmo3UtU1bW7tbzWNSvNRuQgiWS6neZwoPCgsSccnj3Nejfs0eIV8IfHDw9qtxcC1eCcxbJ702cUzNhfJmkMbgI2TkMAMgc5wD5hGiyukTh9rsFOxNzYJ7LkZPtkV9W+EPDniTQPDqXml2vxxuJoVBiutQsrHSrJRjjyxdPNhfdW/CuLH1IQoulL7Sa7GtGLc+ZdNT66/aI+CfwX+Jfhi38a/GKWHQm0iLzJdVg1AQqobaWjMpTE27ZGoJRn2qAgGa+Mv2YtC8PeAE+IX7QCTtqmj+D7eXTdAlltvJN7fTYVcR5ZlYh40xknFyPTFcT8U/EPibxlJY+HNQub3xJ4g1a8Fpax6l4x/t66t3ZlVREtuEtYdx+Xa25xk8L96vQvj5qOn/CLwB4Z+BXhy9WRvCkMep6zPC3FxrVwrGEdcgIDNOAwI2i3BxxXzlHBVsPh44CVVy9q7W6Rgvitq3rflv3lsepKvCrUeJULcnXq5Pbttv8AI+cvGWo3Ooa5Il1dtdS2mYpp2bcZrgszzybv4g0zysDx8pX0rDpFG0ADt6UtfZRiopRR4zd3cKKKKbEFNJyaUntTaEAUA55H1ra8FeFNR8d+MdD8F6QubzXNQgsITgna0jhdxx2Gcn2Br3b9u74TWHwx+LWn3OgWgg0XW9GtRaqowqyWsa2zqB/uxwufeWuWpjaVPEwwsvimm18rf8H7maxozlTlVWyt+J830UUjdK6zFiE5ooopoTEptKx7UlUGyCmse1Opp600ISiiimJiN1pKKKBDW60lB60UAB4plOPSm1SAaTk0UUh6UxIbRRRVi6CNTT0pT1prelNCEpGpaa1MBKKKKCWNprUtNPWmhBTWp1NbrVC6iUUUVSB7iNTaVutJTEwptOPSm00AUUUlDAaetFFFMAprdadTW60AJRRRQAUUUUEsKKKKBBRRRQAUjdKWkY9qaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKcDmm0oPakwFoooqQCiiigAooooGgooooKFHWnU0dadQAUUUUAKtOpo606l1AKVaSlWmwFoooqQH0Ug6UtJjCnU2nDpUgxadTaUGkxj1paaOtOqRhT6ZTh0oKFHWnU2nA5FDAfRSLS1I0KtOplPqWNCqe1OBwaYOtOpAh9FA5oqBjlpaaOtOoAVT2paaDinUAFOB7U2loKHUUUVI0OHNLTQe1OoB6HTeAPhr41+KOrTaH4E0iLU9Qhi842pvreCV07lFmkQyY77c4GCcZFehR/sc/tLSY8v4XXDfTVLH/wCPV47ZX19pl5BqOmXtxZ3ds4lhuLeVo5InByGVlIKkHoQc19xfs2/tw2Opy23g743XcFjdnbHbeISAkE56YugOI26fvR8p53BcFj4Gd4rM8FD22BpxqRW6d+b1Vnr6b+p6GBo4XES5MRJxfR6W/wCAd3/wT6/Zh8efDLxN4k8bfE3wwdI1Ca1i03TIpJ4pWMTNvnfMbMACUiUc5+9Wv/wUK/Zp8c/FiXwn4n+GXhxtX1bTRcWF9Ak8MTG2YiSN90rKMK/mjGc/vBX1r4WlixHJHIrqwBBUggg9wR1q/wCIHjlevhY51WlU/tV29ona2trWtbe9uu+570sDBR+qJ+7367n43t+xZ+0+n3vhRcj/ALith/8AH64P4i/CP4hfCW7tdP8AiHoMekXV4hlht21C1nlKZxuKRSOyqecFgAcHBODX3N+0/wDtv6H4DkvfA3whuLXWPEsZaG61TAls9ObowT+GaYfiinrvIKj89tb1vWfE2sXfiDxDqlzqOp38pmubu5kLySue5Y8noB9AB2r7fJcZmePh7fGU4wg9lrzPz1ei/F/ieFjqGGw8uSjJyfXa3/BKgPalplOBzXvNHALRRRQmA+C4ntLiK7tJWingdZYpEOGR1OQQexBr60+DF7oHxy+Feo/s+eIJLe1bUhNqvhC4kCqun6lFue4tFA5VFLtKoGT5E8ozuTA+SK6HwN4ru/CetQ3VtqM1gpminS7hTdJZ3ERJhuUHcoxOVwdyNIvG7I4cxwjxdL3HacXeL7Nbf8HurrqdGGrexnqrp6NeX9f5npPhzw98NNBtJNE+I/iXQfDHiXTJ5bHUdMvNE1m4mjkibZvaS2nETFsZ+UD6YwTrHSvg5ej7J4U8WaP4l1iX5LPSNL8L6+91dynpHGr3Sgsfc/nXpPxO028+LHg8ftKfCuz060+IHhaAWfi3Tls4boPEIsreQLKjqw8rDxyjloT8r5hOfCtf+J1t4Ot7nQvhbq8smrapGf8AhI/GKK0V3qEj8yW1qWAe3tQeDgK8xGXwm2JfMw0qmNXPGclK9nG6tFrdP3b8trcru3JNebW9WEaD5Wk10dt19+/fTRj/AB7p+rfDpba28UeCPBUOpXZmjfToNZubi9sCu3BuI4rthCx3ZCP83ynK8YPmFxFfCzt9QvndopyyQNKxLOF+8V/2ckDPc5AyQ2K8ceXSNUZtzBQq8k+wru7rwrdanq1gWeBI7K3L3Jdt9vaxxH/VDJwVUqyF8/M6XDnKrvb2oR9ikpu776/q3Y4pPmeiORh0rULiGS4S3YJGExu4LlxuGPbZl8nA2jOeRldF0S61xpBaoVSNQMsOHlfiOIZIBZj+Shm+6rEdTIv/AAjumXWr6zcSXN1dSNKgkXas3mgMke3PDOvlyzYyRH5Me4eaQOg8Krax+HjcWNxuub0SiOYkI8Ctlbq7Lt0d/wDUxngIodz0mIc6rjG6Eld6nJ6T8Rfiv4TiWHw/8RPFGmwnf5Y07V7mBGVCQWARl+XhucAfK2ehx1Fl+0j+0fbzpZR/FXxTLKc7Y7y6ec8Egk+aTwCCDnpg5xg1JHp9pPd+YtsfKh8uGKNFwwIKeUihuAx/dths4P2dX4iuajg0TTzJLqTrHteFMypASvkkLtWMP8zK4MeF4ZozAhO+7bGElh5u8qab9EWpTWibJ1/ac/aMuxHGvji8mM2AoNhbMxyyqOsefvOo+px1qC4+OX7RF3lZPiLrVpGyFzJbzi0Aj2by/wC72tt2ENwM4ZMD5l3Ub6Wz066gt7vyWmvg7NDNOzxogVlfc6DlcmRCy8sDdyLnzYSK2oeKILuF00rfd3144S3Uxqshkchi7qnQ7v3hAOBIY1Hy2qhl9XoNpqlH7kHtJ/zP7zDuNa+IPxHvodO1DW/EHiO7flI57qa8dQOrfMWOB1J/GtTxxb6VoWl22g2cNut0pBuCLa3EgcYzukFxPKCf7p8oYP3e1WLLQrPwhpBu9dsvBd1fByVN3rLXjr2CLDYyELz183Iz2Fcksd74l1ZdmnbpJyN8Wn2iAoncqibQdoPUkdOT3raNpS93SK+4l3S13ZcmtX0nw1Hcz2ksVxqz/uzc2CENAvO+GRn3DJK/MsYyDgP1FaWiWotfA2rXi58y+BiBg8WWVsTGvVZdPbM8w3DI6A9getZfibbda42naZCsywMLW3jisooHdwcFSImfe28kBi7k8c9q9U8TeF7vSfAK6Xb2d/cLHCFLS/DCK3ucAdWvH+c+77t3epqVVDlT3k/P9PlvoVGLle3Q8WhlEU0UhXcEdWI3Fc4PqOR+Fe5Ta14NsNDvNSsrbwJLMrM0suneGtU1iRTnjfNqbiLPQcfL6cV4Mf3kXGDuH4Gvb/AHhfxF+0Z4o03wDp2o+Ln0yxKXWs6hqeq/aLa2tQBzFBsVIWJ4RNz5JXkKGIjHKEIe1qStGN23fSy7rqVRvKXJFXb2Oz/Zo0KPQLHW/wBqXx9p0M0GkKbDw1Y29mlv/aGoOPLAihiUKOWEY2Ljc7t1iNeEfEbxPqPijxLdXep36Xtw1zNc3dxG26Oe8lIMzof+eYIWNAOPLijwBzXsv7RvxZ0O8g0vwd8PTFB4V8NQNYeHI7eUlZSA0c+oE/xfxRQsckkzy5ViufnEDAxXLltKdacsdWVnLRL+WK2Xr1fm7dEb4mahFUIO6W77vq/0Xlr1Fooor12ziCkJoJxSdaSQG14N8GeJPiD4ht/CnhKxivdVuwxt7eS8gtjMR/ChmdFZz2QEscHAODXp4/Yx/acPT4VXR/7iVj/8erxZHeN1kjdkdCGVlOCCOhBr7T/Zh/blfTXsvAXxxvpJrbKwWXiR8vJEOipd93XoPN5Yfx7hll8nOK+Y4Wn7bAQjO26ad/VWav6b9rnZg6eGqz5MRJxvs9LfM1/2KP2R/ih4O+MaeO/in4Ok0e10SylfTfNuYJTLdyDywQInbAWNpDzjnbivbv27vgXrnxa+Glmvg7Sft3iLQ9RS5tIFeONpopB5cyBpCqgY8t+SP9V+FfRfhy5s7qOC7s7iKaCZFljlicOkiMMqysOCCCCCOCDTPFzI4xnjFfm2JzvEV60c0lZTg0ktbWW63vrd316n01LAU6cHhF8Mr3Z+P5/ZB/aQQ4f4YzD/ALilj/8AHq5L4g/Bf4l/C21tbzx94cTSEvXKW6yahaySS46lY45GcqOhYDAJAJBIr7m/aO/a28I/Cea68LeD/s+v+LVDI8YO6009+n79gfncH/lkpyMfMV6H8+/F3jDxP491+58UeMNZuNT1K6PzzTHoB0RVGAijPCqAB2Ar7zIcfm2ZpV8VTjCn00lzP0u9F5vfoup4OYYbB4N+zozcpfKy/wCCY9FFNJ7V9QeTuJRRRQDEJ7U2lJyaSqQgpGNLTScmgkKQ9KWmnrQAlFFFADSeaax7UtNPWrEwprelOpp600DEoopD0qhMbTT1px4ptUhBTD1px4ptABSHpS01utBIlNNOJwKbVIQUynGm0xIKKKDVIOo09aSiimIRulJStSU0AUjdKWmt1o6gJRRRTAKa3WnU1utACUUUUAFFFFBLCiiigQUUUUAFNpWPakqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKKAHUUUVABRRRQAUUUUAgooooLFHWnUynjmgAooooAB1p9Mp9JgFA60UUwHUUDpRUgOWlpo606gfQKVT2pKB1qB7j6VetJQOKAQ+nUynL0qAFpV60lA4oKQ+lWkoHFAx4606mU8dKlgFOBptKDzSZQ6nA8U2lBqQ6jlp1NHFOqWMKcOlNpQeaQDqVelJQDigB1FFFA0KD2p1Mp4OaTQwpwORTaAcUitx9dl8G/BP8Awsb4peGfBroGt9Q1CP7VnoLZPnmP/ftX/GuMBzXs/wCzb8SfBXwavPEPxI8RwSalrUNkNO0LSovlM8spzJK74IjRVQKW5Y+aQoOCRxZjOtTwtR4dXna0V5vRfc9X5G2GjCVaKqu0b6+nU/VO9+JPg34aeGJ/FnjXW7TRtIsl+aWY4GcfLHGo+Z3IGFRQSccCmeDvjN4E+MvhhfFvw68RQ6lZghZVA2T2suM+XNGfmjb0zwRypI5r8fvit8YfHnxm17+3fG+qmVYcraWMOUtLNCfuxR5IGe7HLNgbicCqHw7+JXjX4VeI4fFPgXW59OvY/llVTuhuY88xyxn5ZEPoR6EYIBHw1Pgmp9QdOVX97v8A3fTv8/wPelnkfrPPGPufj6/8A639p3wOPh/8dfFmiwQeVZ3V4dSswAAvk3AEoC+ylyn/AACvLq9m/aG+MHh747WvhnxwmmrpPimxgk0rWLJdzRyxhjJDNC56pl5gVY7lO0ZYfNXjNfaZY6/1OmsSrTSs/VaX+dr/ADPExfs/bydJ3i3dfPX8NgooorvOcUH1p1MpQcUmgHUdaKKVwPXfgH8bfEvww8V2F7ptwjvAPswt55NkN/aFtzWcrH7h3EvDL/yzk4bKOxTtv2jPgP4futF/4X/8DYHuPB+ps0mr6WkW2XRLnOJAY+scYc4ZP+WTHA+RozXzYRng17l8AP2idf8AhrrRhneK8tL9Rb6hZXcgW31OELtCyM2VjnCkqsrDaynZJleR5WMw1WjU+uYP4vtR2Ul29V0fTro9OujVhOPsa23R9n/l3X6niNpcm0vLe8TcTDIr/K+xiAecMMlT6MOQcHtW/ZeM7yS4uFvorJbe6mjkliEJ8p1QKscbDn91Gqr8gySqBRjcxPvnxf8A2aNC8b6Lc/GP9mffqGiu7/2v4XEbLf6RcrzLGkJy429TCcsvVDIhBX5iKmeOWS3R3RNs0hEQXYCQpJIzgB2VR2+bsTiu3C4mjjoc8N1o090+zXR/8OjCrSnQlyy/4D9DT1XWIdd1lGvbi5j06Jm2h2DzMpJd2J/ilkYsxJ43N/CgG3bi8b28cEUSKkKuoLRJEJUjjXiOM54cKOSCcN0Y/vriuRvRALm5ELov7390iEsgU7jgM2CcYUDjkZOeOSd0DSrGkW2VkmXZuPlggnywW543bTnPKDk9Tu6cWkmZ31O0XxzaSpGk42icNlXdnEYLEP5jD5nL7m34wzJ5wHzXLlXf8J7przQpK16bVpTJKVUfackszSbmIAlIZ8MOkkruMCOEDi5FQuYYrfHmiJ0PmCVuUzgFcDksMjGQRjgggwkx8lBgFQMseQ3GT+eR9DU/V4BzM0/E+vP4n1u41iWyhs0fZFb20AGy3hRQkca57KiqOnbOOa7f4b+GPD8X/E0vNe0nUL9oQ0OlRaFearPCSOCyKEtycdmdwO4BFcFokWqNqML6HprXlzC29IRaLcKTz1iZWVh7EEcV2HifxT8abqyltvGPibxHZWax8WN7dS2sTADhY7YkAjoPkXAzzgDIirFtKlB2Xrr91mXF295lPxx4l1ORjoheW1jBZpoBo1rpGQSfle3tx/6Gxz6d6qaRp+l6Vokmv6jf+HLi5kXNpp1ybmW4yDjIEP7peCTiV+g4U0zwL4VvfE2qD7LZapNFZ4mIsNJbUHdgQQnlZVCDzneyrgGr3xF1u7uL5PDSahfNY6aR/ozy2q23nY5dLe0HkwthipAZ2BBBbOQBcqapQ+fT9OoO/wATK3wz06K+8V2s1y1p5dn++K3PiO30Ukj7u24mPBBx90Fvp1r17x/LaXvh2aCW60RLZVyFu/iidaVf923t23sfoDXn3wkGgWF1Pq+peLfCFncsDAllrvh651b5eCXEawSRc9ASSevAzz6zpR+InxS8RW3gT4IXfgm+l2H+1NR0j4f2ejwadETtDS3DW4mU53Y2AMSMLubiuDGSkq3Psord8yS67/Cb0leNlu+is/w3PAfAHgDxR8T/ABRZ+CfB1gb7ULw43E4ihjH3ppHI+SNRyWI/AkgH6f8Aib4o8Mfs+eAbv4J+B9QbUbqdj/wmevK2yfULxl+axibJKkhsSHJ8mIlTullIOjrfiz4efsxeC9S+Hvwt1n7d4jmcweKPGACmc3QwWtbXkgzLu+7kpACGctKQB8h69r114gvBcToIYIQUtrdWLLCmSTyeWYklmY8sxJPWuePPnNVVJq1CLuk9HJ9JPyW8V/28+iNm44KDitaj3fZdl5938l1KuoX9zql9Lf3ZTzJcDai7URVAVUVRwqqoVQBwAABwKr0UV7u2iPPCkJ7CkJ9KSmkAUUUUwCtnwZ4XvfG/i/RfB2nBvtGs30NkjAZ2b3Cl/ooOT7A1jV6t+zb478E/Cvx7cfEzxrBPenQdPmOk6dbj97eX8o8tBuI2oio8rM7dNq4DMQK58XUqUqE50Y3kk7Lu+n4mlKMZVIqbsr6+nU/VSHxf4R+GHhL+1PEWr2mieH9FtooPPuG2RxRIoSNAByzEABUUFieADWJ4L/aA+G/xt0WbWPAHiBLwWxK3VpMvlXVtyQpkiJyFbHDDKnpnIIH5Z/Gj48ePvjnrp1PxbfCHT4GJ0/SLYlbSzU8fKv8AE5HV2yx9cYA4/wALeK/EvgjXLfxJ4R1q60rU7VsxXFu+CB3Ug8Mp6FWBBHBBHFfBUeBpzwTjXq/vnr/dXk+r83+D6/QTz6KrqVOHuL7/AOvI9h/bT8Gr4X+Oeo6tbQ7LTxPBHqyYXC+a2UmA9T5kbsf98V4TXt/xm+OmlfHX4faNLr+mppnjPw3dFWMKn7Nf2sygSNH18t1eOMlG4wzFT1UeH9K+zyWOIp4GnSxStOC5X520Tv1urM8XHunPESnRd4vVfPp94E4FNpSc0leqcmwUjHtS9Kb1pokSiiimJgelNoJzRQIQ8U2lY9qSgApGpaaTmmgEPSm0rHtSVQuohOBTaVj2pKpAFNanUymSI3SkoPWiqAa1JQTk0UAwpp60p6U2ggRqSgnNFWgYjHtTaU9aSgEFIelLTWqxdBKKKKBDT1oooqgCmnrTqYetJAFFFFMApp606mUAFFFFABRRRQSwooooEFFFFACN1pKDyaKsAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAFWlpF60tSwCiiikAUUUUAFFFFBYUqntSUo60AOooooAKcOlNpV60MB1FFFCAUdKWkHWlqWAU+mU4dKBoWiiipYIcDmlpq06kCHDpSg00HmlqWMfRRRSGhw6UtNHWnUFDgc0qntTQead0pMB1FFFIa7Dh0paaDzTqhj3Q4HNOU9qYvWloBD6KKKgY4HNLTAcU+gBQe1LTacDmgApQcUlFBSH0U0HtTqkYoOKWm0oNA9x1FFFJoSYoOaWm0ob1qR+gtFFFAJhRRRQMKcG9abmigB9BGRimUu40rAelfCj43+L/hdrMGpaNq8lpLGqRGfZ5qSwr92C5iyBPEOg5V4+DGw27T9B6x4Y+A/wC1n5d/Y3Nr8OPiVe7hG52yabrb8bihAAdzuGeEuFLfPHKRmvjPIq5p2q3ulmVbZo2huABPbzRiSGYDoHRgQcZOD1UnIIPNebicvVSp7ehJwqd118mtmvJ/Kz1OmliXGPs5rmj2f6dn/Tudj8U/gt8Tvg/qA0/xt4eu7SF8W41GJzLYXQU4XZIi46KpKN84xkqCcVwhR44d5t/mgk2usshAw4JUbOGHKuSQcfMOh+99G/DD9sTxp4Wsl8Oa/Ja6/okq+VNpfiDdcwtHg/JHckPKi8gBJlnQAdV7dZqvhX9jL4tp9tjm1b4T6vctgsNs2kvLjosiF7cAHsskI4PyislmVfC+7jaT/wAUE5J+sfiX3SS7lvDU62tCfyej+/Z/h6HyQXEKeX5jLIj5jZY1XMbDklvvHI24B6DPrXcfDL4by+Mi2ombWyttJ+7t9J8Mz6xO7DnJj+SEr7NJk91wefYL/wDYI+It3bjV/hh498H+MdPAEkE0F0I2fHI+Uh4ce3mkV0uq/C3452+mRWnijwD8ZdflgQRizsPGNpHpqKBjbHBbxTBEA6Ku38KKub4atG2Gqxb9VdfJ/qKODqwd6kGl6O33o4rxd4h1vRdOg0vUPFPxOsbdV2mz1XULXwvbxxgdrCIyuy+yrn0rx2PQdb+I3iuPw74M8PJezRhzt0yCVy6jmSd3mbeVyfvSMoAxwmSK9e0z4Q/Gq1nv5/C37PfiTw5eCN/sU8OlS3M5dgQC11dORAQTu3wxq5xgFc7hq/DD9lP49WCFZvgJ4dn1KWQsupeKL9ZI7dCAAEtUmCkg5JMkcnXAAqYYrD4Om5SnFPzcVr5q9vuYeynWklGLfyb/AEucp4pbw34K8Lv4VimSWCzeSWPT9R8WnWwkgP30tdPC2cDGTGVmlc88hjxXh4E11OFijMk88mFjjQAs7HgKqjAyTgAD2FfYmu/s7eH9Khhh/aR/aU8N6NBb/OvhrwzBEhVs4Hl28ca4bnGVtmJz1qMfG34FfAlJIfgZ8MbaDV4sx/8ACQ+KAz3nbJitwTONwzjP2ZCRzkGsqGZRUbYaLqSfVX5f/ApfpzM0nhne9VqKXff7l+tjO+Dn7P3xH0DwfH4v+JXxH8R/CDwbAWmv92vPaz3ofGwR2oVfIZhlcyl3Y42xtmpPif8AtIeHPBXh4/DT4JaNP4W8PBnF0UzFq+qORjzJXJL2yMOS75uHUqAIkOR4l8Qfjv46+IOqDVdX169vbxNwivLkqptwcZFrCmI7UHAOUBkz1kIJrzhmZmLyOWZjksTkk+tXDLZ4mftsc0+vKvh9X1k10b26JMl4qNKPJh/ve/8AwF6fNst6pqt3q86TXPlxxwr5dvbwrsht485CRqOAMkk9ySWYliSalN3Gkr2lG2hxDi3pTaKKqwBRRRQAUUUUCbsFISB25oJxSUB6hRRRVJCbCmk0E9qSmMKKKQntQIQnNJRRVCYUhOKXpTTzQSFITilppOaAEooooAQmm0p5NNaqQmJSUtNY9qaDZCUUUVYhGPamk4pSc01j2poQlIelLTWpgJRRRQJiMe1NNKetNY9qaJEpKWkPSqExtFFFNAwpp6049KZVAwoPSikahCEoooqmAh6U2lakpIAooopgIx7U2lPWkoAKKKKACiiiggKKKKACg9KKRqaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAp1NpQe1JgLRRRUgFFFFABRRRQUgpR1pKKBj6KAciigAoHWiigB9FIDkUtJAFOptKOlDAWlXrSUUgH0UUUmPqAOKfTKcDkVIMWnU2lWkxj1paaDinVIBTgc02lBoLHU4dKbSg80APU9qWmU+pAKcDmm0oOKTKHU4HIptAOKkNh6ntTqZTgc1LGLSqe1JRSAfQDikBzS0AOopAaWgApwPam0UFD6KQGlqRig06mUoOKB7jqKKKVhXsKDilptGcVNh7jqRiQMgZpBIO4P5Guh+HvhG9+Ifjzw94F01JTPrupW9iGRclBI4Vn5/uglj7A0pSUIuUtkCu3ZHp/xd+Bb+APgN8JfiWtkUuPFNvdnVJQTgu8hls+PVrck/8BrxGv2E/bA+Edr4q/Ze1/w7o1iqHw7YxanpkSJkoLJc7VHqYBKg+tfjyH45BH4GvHyPHyzChKVT4lJ/c9V+dvkduOw6w00o7NL/ACY6ik3A8YP5Glr2TjClyaSigBc56irFlqF9pspn069uLWQrtLwyFCR6ZB6VWopNJ6Ab2l+M9Z0e9XULPyI7lfuzW4azkB6532xjc8+rGu50z9pf4s6aAIviB4xjx/DFr8siD8LkTH9a8oorCrhKFf8AiwT9UaQrVKfwyaPap/2svjDNH5Z+InjMD/Z1W3U/mtsD+tctrvxz+IXiJHh1nxLrmpwyDBj1DXb6Yf8AfCzLH+GzFefUVlTy7CUXenTSfkrFSxFaatKTfzNRvEmseWYre6WyRhh1soUtt49H8sLvH+9mssYAwBRRXYopbGO4uTSUUUwCiik3D3/KgBa9e/Ze+C4+OXxHuvC1yGFla6Jf3czjI2SGExW5yOhFxLC3uFNeQbh7/ka/SD/gmf8ADKTTvhp4h+JF1AVm8S3ws7Vj3tbUHLD0zLI4P/XIV5Ge42WAwM6tP4novV/5K7OzAUFiMRGEtt36H5yXNrc2N1PY3sDwXFtI0U0TjDRupwVI9QeKjr3H9tP4fj4d/tDeIoIbfyrLXyuu2oUHGJ8mX/yOsw+gFeGeYO2fyNd+ExEcZh4YiO0kn96OavTdGpKm+jsOpCfSm7s0tdFjMKKKKq1hN3Cmk+lBOaSmFu4UUUhOKAAnFNooqkrCCiikJ7UEiE5oopCcUABNNoooAKRj2pScUymkAHim0pNJVC3EPFNpSe1JVIApCaWmnk0yRKbSse1JVAJ0ptKx7UlABSHpS00nJoJEppOaU9KSqQgppPNKeKbTEFFFFUg3YjelNpT1pKYmFNPWnHpTaaAKKKQ8UMBD1pKKKYBRRRQA09aSiigAooooEwooooJCiiigApp604nFNqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgB1FFFQAUUUUAFFFFA0FFFFBQqntTqbTqACiiigBVPanUwcU+kwCgdaKKYDqKKKkByntS00HBp1A90FKOtJRUMe4+gcUg5paAQ6nA0wGnA4qQHUUUUikOBzS00HFOoGOByKVT2pgOKdSYD6KQHNLSGhwOaWmA4p3WpaGOB7U4HFMpwOaQIfRTQadUsYA4p1NpQcUgHUoPakooAdRSA+tLQAU4H1ptFBQ+img+tOqRhnFOBBptFA9x9T2F/e6Xe2+pabdSW11ayLNDNG2GR1OQQfqKrBvWnUhH3N+zh+2F4P8AEtxaeDfjVo+gadqbARW+unTbaO1um6AXACBYXP8AfAEZ5yE6n7t8MeHfDkdxBeWmgaTDNEQ0csNjCjrkdVZVBHB6g9DX4VsARyK/Wr9hGy8Q6R+z94XPiPVLu7lvRNd2qXEpf7NZs5WCJM9E2IHA6DzMDjAr854oymjlzjjKM3FSlZxu7a3d1221W3a2x9LlWLliU6E4ptK6dlf5/wCZ9U6rBDJpnlyIrKy4IYZBB6givIvF1n8PvCGk3niHxHYeHdL0ywQy3F3c2VukcS9Bk7O5wABkkkAAk4r0281izuIZrWK6ikmtSqzxpIC8TMu5Q4HKkqcjOMjkcV+d/wDwU5h8Qz2fgvVI9UvP7DE91a3FkJSIPtWFeKQoOC5Qyrk9AhAxls+R7GOZ5hSwkZuCl1Xkr/j0OxT+rYeVZxUrf5nkX7S/7Wq/E03ngj4ZaBY6J4SJaKe8FhDFe6muepKrmGI44QHcR9887F+bB0pAaXIr9RweDpYGiqFFaL5t+bfc+TrVp1puc92FFFFdRncKKKKB3Ciiur+FHgK9+KXxN8M/Dyw3CTXdShtXZescRbMsn/AEDt/wE1M5KEXKWy1Gk27I5UgqSrAgjqD2pK+jP2+PhnbfDj9oXUJdKsltdI8R2VtqtlGibUT5fKkQduJInb/gYr5zrPDV44mjGtHaSuVUg6U3B9AooorYi4UUUUCuFev/AAH/AGjdd+DF8mn32iaf4i8LzS77nTry2ieWHP3pLeV1Jjbvt5RucjJ3DyDIpC1Y4jD08VTdKqrxf9fIqnUlTkpx3R+wvwk8U/CX4v8AhuHxV4Is9Cv7RiEnjbTLdJ7WXGTFNHtyjenUMOVLDmvcPDljaWGn/ZbS1gt4UU7Y4Y1jRc8nCqABz6CvyU/YJtvElx+0FYy6Nql5aWFlY3N3q0cMjLHcwBdiRyAcMDLJEcH0yORkfq1aa1b2Nmst5dRQo7JCrSyBA0jnaiAk4LMSAB1J4FfkuaYKOTZj9XjNzi1dX3V76PufYYSs8Zhva8qi7206nMeL9MsLu9aa606zuHUbQ01tHIQM9AWBwK+X/wBov9o74e/Bm3n8P6Jo+ia14yZcJYCzhMNiSMh7kquQcHIiBDHjJQEE/QfxTOq6n4b1vTdB1KfT9Su7C5gs7qBtskFw0bCN1PYhypzX4w3Ml1NdzzXzyvcvIzTNKSZC5OWLE87iSc55zW3CmUU83rTq15vlg17qbV79/LTZb/mZxjJYKnGMIq8uttrfqafizxXr/jjX7vxP4mvhdaheNukZY1jRQOAqIgCooHAVQAPSsmimlvSv1uMVBKMVZI+Md5O7FJAppOaKKoewUUUhPpQICcU2iiqsIKKKQmglu4E9qSiigAphOaUnNJQAUUUhPamAhOaaTilJxTetUJhSE4paYTmmkGwUUUE4qhMRj2pp4opCaaEJSUtNY9qYCUUUUCYhOKbSk5pCcCgkaetFFFWDGt6UlFFAbBSE8UtNJ5qxbISiiigQjUlFFUAUjHtS009aW7ASiiimAUjHtS009aAEooooAKKKKCWFFFFAgooooAaetFB60VaAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAHUUintS1IBRRRSAKKKKACiiigsKcOlNpV60AOooooAKcOlNpQeaGA6iiikgFU9qWmjinUMApw6U2lBwaQIdRRRSY9mKp7U6mU4HNSAoOKdTaVT2pMY8HtS00cU6pAKcDmm0A4oLH0oPakooAeDinUwHNOB7VLQC0oOKSikMfQDimg9qdUj3HU4HsajBxTqAQ+ikBzS1IxQcU6mUoOKQDqUH1pKKAHUUgOKWgApQcUlFBVx4INFMpwb1pWAWjOKKKQ7mx4P8M6j438W6N4O0lC15rV9BZQ4UttaRwu4gdhnJ9ga+3Pjf+2bovwq0dfhR8ArmC9v9MtU05tcTbJa2CRoEVbccrNKAo+cgxqem88r8H29zc2kontLmWCUKyb4nKNtZSrDI7FSQR3BINRjjpXlY7KaGZV6dXE6xhe0ejb6vva2i9bnZh8ZPDU5QpaOXXrbyO+8AfHP4q/DXxvP8QvDXjC+bWL6TfqTXkrXCakM5K3Ksf3oOTyTuGcqQea+o/ib8cPBv7Vn7PHiGyhij0nxl4djj1xtInfO4QE+dLbOf9YnkvMSPvrjkFcMfh/d61JDNLBIJreZ4pFyA6MVYZGDyPaljsnw+Mq08RblqQaakvLo+66eXQMPjauHhKlvGSaa/VeYwdKWiivVscdwyaXcaSilYd0LurovA3gDxf8StZ/4R3wRpK6nqZjMqWguYopJFHXYsjKXI6kLkgc9K5yn29xc2dxFeWdxJBcW8iyxSxMVeN1OVZSOQQQCCOhqZqTi+Tfpf+kC5b6nsS/seftMMMr8JtRb6XNuf/alfUP7AX7KvxG8C/FbUPiD8U/CFxov9l6cbfSUuHjcyzzna8i7WONkQde3+tFYX7Mf7dlrI1r4I+O93HDKSsVn4lKYRuwW8A6H/AKbAY/vjrJX6GeF7i2nEU8DxvHIodHjYMrKRkEEcEEdCK+BzPOczo1HgcZTjFS05lezXWzb+/qrn0GFwOFnFYijNu3R209T5i/4KJfs++K/i94S8Nap8P/Dz6t4g0K/kiMETqjvZzp85yxAO14o+M9Hb3r4Nf9jr9piPiT4T36/W6th/7Ur9nfE0iFD06V8T/tN/tneFPhVPdeEfAkdn4h8WjdHKdwez01un70qf3kgP/LNTgEHeR9w44POcxo1v7PwNNT1b1von3d9EaVsDhqkPrOIm4/qfBPxA+DnxK+FcFpcfEHw1/YwvmK20ct5bvLLjqwjRy+0dC2MZIGcmuL3Vp+KPFXiTxtrt14m8W61darqd426a5uGyx9AAOFUdAqgADgADisuv0Ggqvs17a3N1te3yvdnzs+TmfJe3nuLupMn1oorWxN0FFFFOwrn2L+yJ4w+H/wCz38IfEXxj+Id4Vu/E93/Z+jadDta7vorUZcxKeiGWUK0jYUGLHJwp8L+OX7RfxD+PGspd+Ir02Gj2cpk03RrWRvs9r2Dk8GSXHBkbnrgKDtHmEk80qxJNPJIsCGOJXckRqWLbVB6DczHA7k+tR7q8uhlFCljJ4+a5qkur6K1kl8t3u/TQ654yrOhHDrSK/F+Z9XfAn9tfW9EW18H/ABivrjUtLjCxWutkNLd2oHAE/Vp0HHzf6wY/j4A8U/aB0HT/AA/8XPEB0SeK50jVpxrGm3MLh4Z7a5AlVo2HBUF2T6oR2rzs89ac0kjhA7swjXYgJztXJOB6DJJ+pNLDZPh8Hi5YvDrl51aSWzd7p+T38nfuVVxtSvQVGrryvR9fQaSTRRRXrHFcKM4pC3pTadhCk5pKKKYXCiikJ9KCQJ9KSiigAppNBNJQAUUUhOKAAnFNopCatCEJzRRSE4oDYQntSUUVQgppOaUntTaaVxATim0daKoBCcU2lJzSUAFITilppOaCRKaTmlJpKpCCmse1L0ptMW7CiiimgeoHgUylJpKoTCkJpaaTk0IAoooqmAh4FNpWPakpIAooopgB4plOam0AFFFFABRRRQSwooooEFFFBPFMBpoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAHWnU2nUmAUUUVIBRRRQAUUUUFIKKKKBj6KRfSloAKKKKAHDmlpqntTqWzAKVaSgHFNgOoooqQHA5FLTQcU6ge4UoNJRUMe4+ikBzS0CQ4c0oPamA4p1Sxj6KQHNLSGmKD2p1MpwOaChQcU6m0oPagB4OaWm9KcDmpAKcDmm0UmPzH0oNNBzS1Ix1OBzTAe1LRYB9FIDS1IxQcUvWm0ZxSAfQDikBzS0AOBzRTaUN60ALRRRQO4ucUob1ptFFhj6KbnFKG9aVgFooyKKQ7hk0u40lFAXHZFLTKKAsh9FMyfWlyaAsdH8PPB918QPHmgeCrNXMms6hDasU6pGzje/0VdzH2U1+z9v4w8KfD7wzJrOv6tZaLoekworT3MgiihiUBUX3OAAFAJJwACa/J79mfx94G+E3iXV/ij4wV7280axNvomlQD99dXc+ULhiNsaJEJQznJHmLgMeKwfjN8efiD8cdaGoeLtR8vT7dy1hpFsStpZgjHyr/E5HV2yxz1xgD5HOcpxOdZhTjflpU1q+7e6S66Ja7LXfY9nA4ulgcNJ7zk9uyXf8T9dPB3xv+H3xq8Lt4m+HPiSLUrWNzFOu0x3Fs+SAJYmwyZxlSRhhyCa/Kz9rzwWvgn9oHxPBBAIrTWZV1q2A6bbgb3+mJfNX/gNeeeAviH4z+GHiODxX4G1240vUYPlLRnKTIescqH5ZEPdWBHAPUCvS/j/APGrQvjz4d8NeKruwTSvGOjtJp2p2kas0Fzbv+8jnhY5IVXEoKMSQZVwWGSFgMlr5RmvtqT5qNRNPvF7q/fa1/PWw8RjaeMwfs5q04u67Po/+G8jxWim5NJk+tfXni2H0mRTaKAshd1Jk0UUBdBRRRQFwopC3pSZJp2EKSKQkmkop2AKKKKBXCgnFIT6UlAgJzRRSE4oAWmk5pCc0UAFFFITigAJxTaKQntVJCAntSUUhOKYeYE4ptHWiqSEFITil6U0nNMQlITmgntSVSAKaT2pScU2gAoooJxQS2Ix7U2ikJ7U0IQnNFFITiqBiE9qSiigNgoJwKKaTVi2EooooEB6U2gnJoqkAUUU1j2pbsBKKKKYBRRSHpQAh5NJRRQAUUUUCYUUUUEhRRRQAU09adTT1poAoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApQaSgdaTAdRRRUgFFFFABRRRQNBRRRQUKODTqZTgeKAFooooAKcOabSqaTAdRRRTQCqe1LTelO60mAU4HtTaXpSBDqKKKTQ9gBxT6ZSg9qkGOpQaSikxjwcU6mA5pQcVIDqOlFFBSY4HNLTAcU+gYoNOBxTKcDmhoB/Wimg4p1SAU4HNNopNDH0oOKaDmlqRjqcD61GDindaAH0U0HFOqbDClDetJRSAfRTAcU4EGgBQSKUNSUUAOopuSKUN60ALRRRQO4UuTSUUDuO3UZFNopWAfRTKXJ9aLAOopu40u72pWAXA60Um72o3CiwC0Y70m4UbvaizAWik3e1JuNFgHUU3JpKdgHZFG6m0UWAXJpKKKYXCiiigVwopCRSZJoEOJAppJNFFABRSEgUhOaAAt6UlFFABRRTSfSnYBSabRSE5qhXAn0pKKQnFAeoE4pvWjrRVJC3Ciimk5piAnNITignFNqkgCkpaaTmgBCc0UUUCbCmk5oJ7UlBIE4ptBOaKpAFNJzSk9qbTEu4UUUVSQbiE4ptKTmkpiYUE4oppOaEgCiiiqYBTDzSse1JSQBRRRTAKaTk0pOBTaACiiigAooooJYUUUUCCiiigAJwKbStSVSAKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAOHNFID2palgFFFFIAooooAKKKKCgpQcUlFAx9FIDS0AFFFFADgc0tNBwadS2AKUHtSUUwHUUA5oqQFB7U6mU4HNA0LRRRUtAuw4HNLTOlO60g2FBxTqbSg0mhjwe1LTKcDmpAWlBxSUUFJj6KaDinUDHA5pQcUynA5oaAfRTQcU7rUgFOBptFIfoPozimhvWnVI9xwOaXOKZSg+tAX7jwc0tMpQaVhjqKM5oqQFBIpcg02igB9FNBNLkUALS7qSigB2RRTaKAHUU3caXd7UALRRkUUBcKKKKB3CiiigLhRRRQFwooooC4UUUZHrQK4UUm72o3GgBaMim0UALu9KTOaKKACikyKQk0AKSBSE0lFABRRRQAUhIFIT6UlUkApOaQnFIT6UlMVwJzRRTS3pQGwpOKbRRVWsL1Ciimk5piAnNITignFN600gDrRRTSewpgBNJRRQJsKQmgnFNoJCmk5pSe1JVJAFITilphOaYtwoooppDYUhPagnFNqhbBRRQTigQjHtSUUVSAKSlprHtS3ASiiimAUUUhOBQAhOaSiigAooooEFFFFBIUUUUAFFFIx7UwEoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnDpTaVT2pMBaKKKkAooooAKKKKBoKKKKChQcU6mU5T2oAWiiigApwOabQDihgPooopIABxTqbSg9qGgFooopAP60U0HFOoHuFKDikoqWrD3H0U0GnUhbCg9qWm0oNJoY8HNLTKcDmpAWlBxSUUFJj6KaDinUDFBzTs4plKD60NXAeDmlplOBqQFpQcUlFA9xwOaWmU4H1qWh+ooOKcCDTaKQDqcG9ajBNOBBoC4+imU7d61Nhi0UZFFIAzil3UlFADsilplFAD6Kbk0bvagB1FJkUZHrQAtGT60UUAGTRk0UUAGTRk0UUAGT60ZNFFABRSZHrRkUALRTd3tRk0AOpMim0UALu9KTJNFFABRRRQAUUhb0pM5p2AUt6U2gkCkLVQrikgU0nNFFAbhSUE02mkHoKTmkoopiCgnFITikpiAnNITikJpKpIAooppPpQAE9hSUUUCbCgnFBOKb1oJCmk0pOKbTSAKKKaT2qhPsBOaSiigewUUU0mrFsBOaSiigQU0nNKT2pKaQBRRRQwEJwKbSk5pKaAKKKKACmk5pSabQAUUUUAFFFFBLCiiigQUUUUAFNpWPakqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBwOaKRaWpYBRRRSAKKKKACiiigpBRRRQMeDmimg4p1ABRRRQAoPanUynA5pMBaKKKaAcDmim04HNJoApwPam0UgH0UgPrS0h+aClB7UlFSPcfRTQexp1AkKDmlptKDmpaGPBzS0ynA5pALSg4pKMigpMd1paZnFOBFAxwOKWm0A4oAeDinUwHNLnFS0A6ikBFGR60DuKDinAg0zcKXIpNAPopoJpQQaVh7igmnAg02kyPWkGw+lyajDe9KHHeiwXJNwpaZuHrRSsMfRTcmjcO9KwDqKbvWl3CiwC0Um4UZFFgFoyaMiikAZPrRk+tFFABk+tGT60mRRuFOwC5PrRSbhRketAC0UUUgCikJA70m9adgHUU3ePQ0m/wB6LAPpMim5z3op2AXcaSk3elIW96dhXHEgUham5HrRketAbi0UmRSE07BohSQKQnNJRTsAUUUhYDvTFcWmk+lBOaQnFFhBSE+lITmiqAKKTIppOaAFJzSUUUCbCgnFITimk+tBIvWkJxSFgO9Nz700gFopMj1oJ9KoVwJptFFA9goopCfSqF5gT2ptFFMTYUE4o6U0nNCQBRRRVbAFNJ7UpOKbSQBRRRTAKKKaT2oAOtJRRQAUUUUCCiiigkKKKKACiikamAh5oooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAOlOptKp7UmAtFFFSAUUUUAFFFFA0FFFFBQU4Gm0vSgB1FAOaKACjpRRQA7rS00HFOpbAITik3Y6mhjX78/sI/wDJofwu/wCwIv8A6NelKVgWp+A28UbxX9OVFTzjsfzG7xTg+a/pwopc4WP5kQ3vS7vevpH/AIKRHH7anxI/666Z/wCmu0r9Ff8AglCc/skWf/Yf1L/0JKpuyuB+LO73p6tmv6aq/mp8YH/ir9c/7CVz/wCjWqU7jM2mlqM8V9Sf8EyD/wAZn+Ch/wBO2rf+m64oFc+Wg9O3e9f001+Vf/BZpseOvhn/ANgnUP8A0dFSTuM/OvfSGSv0J/4I1HPxR+IX/YAtv/Siv1goBH8ywmHc0vmj1r+miorm1tbyIwXdtFPGeqSIGU/gaQH8zyyCpAwNf0D/ABN/ZN/Z0+LtnPbeNfhJ4emuJ1wdQs7RbO9U9iLiELJx1wSR6gjivyv/AG1v2A/EX7MwPj3wXf3XiH4f3M4iM8yA3elOxwiXO0BWRjwsoAG7CsFJXcDufJVLux1qNX4p8UU91PHa2sMk00ziOOONSzOxOAoA5JJOABQO4hermj6NrfiG9Gm+H9HvtTu2BYW9nbvNIQO+1ATX6Ufsl/8ABK/TZNMtPHv7TkNzJdT7ZrXwpBOY1iTqPtkifMWP/PJGG3+JiSVX9EfCPgXwV4A0tdE8DeEtH8P2CAAW+mWUdtGcdCQgGT7nmkK5/Pv/AMKA+PgtP7QPwQ8fi1/57/8ACNXvl/8AfXl4rjtW0jWfD962m69pN7pt2gBa3vLd4ZFB6Eq4BFf0q1geMfAHgb4h6W+i+PPCGj+ILFwV8jUrKO4QZHJUODtPuMEUBc/m/V6fuFfpN+1v/wAEs7TTtMu/H/7MkF272+6e88KTzmYtH1JspG+YsP8Ank5YtztbOEP5qsJIZGilRkdGKsrDBUjqCOxpNFJ3JC3FMMg9a6H4bv8A8XF8K/8AYbsf/R6V/R9RYG7H8z/mj1/WjzRX9MFHWiyFc/mgEgPepFk96/ow8WfCf4X+PLN7Dxr8O/DeuwSdU1DS4Z+fUFlJB9xzXwn+1X/wSx8M32kX3jf9muOXTdWtle4m8MTztJbXagZK2rvlopOuEZihyACmOTlC5+Xu800yUlzDcWVxLZ3tvJBcQO0UsUqFHjdThlZTyCCCCDX6nf8ABHBt3w6+I3/Ybs//AEQ1LlHex+V5k96TzB61/S/RT5Rcx/ND5vuaUSn1r+l2ijlDmP5pllz1qQPntX6Qf8FmTi8+Ef8A1z13+djX5uIaiSKTJCwAqNpAKGYV9a/8EtCD+1vpg/6gupf+ihSSBs+RjN70nnCv6XaKvlRPMfzRCanCav6WJYYZ42hniSRG4ZXUEH6g15t8RP2afgJ8VrOW08d/Cfw3qLyoU+1LYpBdoD/cuIgsq/gwo5UHMfz5CU0pkPrX2l+2t/wTt1T4CaZc/FD4U3t5rngeFgb+1ucPe6SGOA7MoAlgyQN+Ay5G4EZeviUycVPKVckMlNMg9a/en9hg5/ZJ+GJ/6gi/+jXr3Wq5Sbn80Hmj1pfO96/perM1jwx4a8RQvbeIPD2manDKu147y0jmVh6EOCCKfKFz+bYSZ704PX7U/Hj/AIJtfs8fFvTbm68JeHoPAHiMofs17okIjtC/YS2gxGy567Ajf7XGK/Ir41fBrx18AviDqHw3+IWnC31GyIeKaLLQXlu2dk8LkDdG2D2BBBUgMpAXKNO5xJeml8d69s/YkfP7WfwvAH/Mfi/9Bav3yppA3Y/mh3+9Bkr9Q/8AgssceEfhh/2EtT/9FQVy/wDwR5+Lf2XW/GnwR1G5xHfwp4j0xGOAJY9sNyB6syNbnHpExosFz84vN96UPnvX9L9flf8A8Fhfhb/ZvjPwX8Y7G2xDrNnJoWoOowBPATJCzerNHJIPpDTsJM/PMHNBIFMV6RmpWGDPTN9fpF/wR1+GH2nWfHfxlvLfKWcEPhzT5CMgvIRPc49CFS2/CQ/j+oNMm5/M6Gp1ffv/AAV7+LP9u/FDwv8AB/T7ndbeFtPbU79FPH2y6xsVh6rDGjD2nNfAIPHNA0wJxTGfFDtX7B/8El/hR/wh3wB1D4k31tsv/HmptLExGCbG1LQxD1/1puW9wy0xNn48+YPWgSiv6Z6yPGHhbSfHHhPWvBmvQ+bpuvafcabdp/ehmjaNwPfDGgR/NiGpScVs+PPB+rfDrxxr/gHXk26h4e1K50y54wC8MjIWHsduQe4IrDzxTsAFqjZ8dK9u/YnP/GWXwsH/AFMVv/Wv39o2A/mS30b6/ptoo5hWP5kTIKTePWv6b6KfMOx/Mjv96N3vX9JfxI/5J34p/wCwLff+iHr8Iv2HD/xlv8Lf+w/F/wCgtTTuKx4eXxTd9f05UUucLH8xu8UbhX9OVFPnCx/Mbuz0NKDmv6HP2r/+TYPi3/2JOtf+kUtfzxL1q4yuJqw6iimk5o3AQnNFFFMAooooAQnFNpSc0lABRRRQAUUUUEthRRRQIKKKKACmk5pWPakqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAHA5opoOKdUtWAKKKKQBRRRQAUUUUFJhRRRQMUHFOplOB7UALRRRQAUoNJRQAP3r9+v2Ef+TQ/hd/2A1/9GvX4CE9q/fv9hH/k0P4Xf9gNf/Rr1nPYInrHxE8R3Xg74f8AibxdYwRT3OiaPe6lDFLnY7wwPIqtgg4JUA4OcV+VI/4LKfHU/wDNLvAn/fN5/wDHq/Uf4yWN7qnwh8caZplnPd3l34b1OC3t4IzJJNI1rIqoirksxJAAHJJr8Bh+y3+031/4Zz+J/wD4SGof/GqIJPcbPrT/AIfJfHX/AKJf4E/75vP/AI9R/wAPkfjp/wBEv8Cf983n/wAer5OH7Lv7TXf9nT4n/wDhIah/8aof9mD9paFGll/Z4+JqIgLMzeEtQAUDqSfK4qrRFdmf8dvjBrnx8+K2u/FvxJpdjp2o6+1u09tYh/Ij8m3jgXbvZm5WIE5J5Jr9b/8Agk//AMmj2f8A2MGpf+hJX4qE5r9q/wDglB/yaRZ/9jBqX/oSUpbDR9j1/NR4vP8AxV+uf9hK6/8ARrV/SvX80/i8/wDFX65/2Err/wBGtUxBmYelfUn/AATH/wCTz/BP/Xtq3/puuK+Ws8V9Sf8ABMf/AJPP8E/9e2rf+m64qnsB+5FflT/wWc/5Hr4Zf9gnUP8A0dFX6rV+VH/BZ3/kevhl/wBgnUP/AEdFUR3Gyp/wRo/5Kl8Q/wDsAW3/AKU1+sVfk5/wRo/5Kn8Q/wDsAW3/AKUV+sdEtxI/PL9sb/go38W/2dPjvq3wr8JeC/COo6bp9pZ3EdxqMVy07NNCsjAmOZVwCxA46V5h4T/4LLfEa31KI+O/g94cvtPLASjSbue0mVe5XzTKpI9DjPTI614//wAFRyP+GxvEv/YN0v8A9JEr5MJGKdguf0c/Br4weCfjv8O9K+JvgC9kuNJ1VGwkyhJ7aVTtkhlUE7XVgQcEg8EEqQTueM/CGgfEDwlrHgjxTYreaRrtlLYXkJ/jikUq2D2YZyD1BAI5FfGf/BILSddsP2atbv8AUopY7DU/Fl1PpwcHEka29vG8if7PmRsvHdGr7mqXoM/m3+Ivg6/+HHxA8S/D/U2LXXhvVrvSpWx99oJWj3D2O3I9jX3T/wAEof2Z9P8AGviTUf2gvGelC50/wxcrZeHY5lzHJqOA0lxg9fJVkCnkb5Mj5oxj5b/bXuLKf9rH4pvYFTEPEl0jbTn94pCyf+Phq/Z39jjwBb/DT9mD4ceGIYBFKdCt9Ruh3+03Y+0y5PfDysPoBQB7NXy9+1l+338Mf2X7oeFF06bxZ40kiWb+x7S4WGO0RhlWuZiG8ssOVQKzEYJCghj798R/Glj8OPh94l+IGpR+Za+G9Iu9WljBwZFghaQoD6nbge5r+dLxf4u1/wCIHizV/G/iu/e91jXLyW+vJ3P35ZGLHA7KM4AHAAAHAoQH3OP+Cx3xm/tHzW+FHgs2G7/UCS7E2M9PM8zGcd9n4V9nfsm/t5/DH9qSV/DUVhN4W8ZwRGd9Fu7hZVuY1+89tMAvmhRyylVYDJwQC1fhttGOlbXgXxr4h+GnjXRfH/hO9a01fQb2K+tJVPG9Gztb1VhlWHQqSDwaBn9JVfkl/wAFVf2aNP8Ah3400746eDNKFro/jCd7fWo4VxHDquC4lwOF89A7ED+OJ2PL1+qXgjxXYeO/BegeN9KUiy8Q6Xa6rbAnJEU8SyKCfowryD9ur4fR/Ej9lH4iaMIw1xp+lNrdsccrJZEXB2+7JE6f8DNIR+G/w2b/AIuN4V/7Ddj/AOj0r+kKv5ufhqc/Ebwp/wBhux/9HpX9I1O1gPAf22v2hfFf7M3wYT4k+DtH0nU9QbWLXTvI1NZGh8uVZCWxG6NuGwY5xya+DrT/AILFfHNZ1a++GHgWWEH5kiS8jYj2YzMB+Rr6f/4K0f8AJqsX/Y0af/6Lnr8aRjtQM/c79kH9ubwJ+1ZHeaDHo0vhrxhpcAurnSJrgTpPBkKZreUBS6hmUMpUFdy/eHNfTFfhj/wTcOrj9szwF/ZHmYP9oi72/d+z/YLjdu9s7cZ/i298V+51Aj8dv+CrnwX0/wCHnxy074jaHZ/Z7H4g2kl1cqq4T+0bcqk7DHTejwOfVmc9695/4I2HPw5+I3/Ybs//AEQ1Qf8ABZf7GPAvw0L/APH1/a2oeV/1z8mPf+vl1N/wRqOfhz8Rv+w3Z/8AohqQz9Ea/Mz47/8ABUr4wfCr4zeMvhto3w98HXlj4b1i4063nuVuvNkSNsBn2ygZ+gAr9M6/Dv8Aav8A2evj/wCIv2lviVr3h74G/EHVNMv/ABHeT2t7ZeGb2eC4jaQlXjkSMqynsQSKBHrA/wCCxHxyP/NMPAv/AHzef/HqUf8ABYf45H/mmPgX/vm8/wDj1fKI/Zh/aX/6N4+Jv/hJah/8ap4/Zi/aX/6N4+Jv/hJah/8AGqCtDsP2pf2vvG/7V8vhqXxn4Z0PSD4YW8W2GmCYeb9oMO7f5jt08hcYx1NeFrV3X/DniLwjrNz4d8WaBqOi6tZFVubDUbWS2uISyhgHjkAZcqwIyOhB71SBx2qGUrA9fWn/AASz/wCTudL/AOwJqX/osV8lMcivrT/glkc/tc6X/wBgTUv/AEWKaEz9p6+JP28P25viV+yv4/8ADvhLwT4V8M6ra6xo51GaTVY7hpEk8949q+XKgxhAeQTmvtuvyX/4LF/8lp8D/wDYrt/6Vy1RJa8O/wDBY74q2+oRv4s+EXhS/sdw8yPTrm5tJdvfa8jSjP1Wv0U/Z9+P/gL9pH4d23xE8A3EwgaVrW9srkBbixulALQyAEjOGVgQSCrA+w/nlJGK/TD/AIIxtrB/4Wup8z+yv+JORn7n2j/S87ffbjP/AAHPagGfpXqWm2GsaddaRqtnFd2V9C9tc28qhklidSrowPBBBII9DX8937SvwoHwP+OvjP4Xw+b9k0XUmFiZTl2s5VEtuWPc+VImT65r+hqvxO/4Kl/ZP+Gvtd+zf6z+ydM+0f8AXT7OMf8AjmygD9O/2F/+TR/hh/2BF/8ARr16t8Q/EV34Q8AeJvFlhDDNc6Jo97qMMcwJjeSGB5FVsEHaSoBwQcV5R+wr/wAmjfDD/sCL/wCjXr0H43/8kW8f/wDYr6r/AOkklAj8wU/4LEfH0kFvht4AI74gvR/7cV7l+zh/wVc0H4keM9M8A/GDwRb+FrnWLhLSz1iwu2ls/PchUSaNxuiUsQN+5wCRuCjLD8mlIx1q3pOnanrOr2Oj6HbTXOo31zFbWcMIJkkndwqKuOdxYgD3NMZ/S5XxF/wVf+D2neMvgFD8U7ayX+2fAl7EzTqPmawuZFhljPqBI0Lj02v6mvtawjuYbG3ivJRJcJEiyuP4nAG4/ic14V+3nNZQfshfE578qIjpKouTj9408Sx/+PlaBH5C/sQkf8NafC7/ALD8X/oLV++1fgP+xB/ydp8Lv+w/F/6C1fvxQwPzj/4LMf8AIo/C/wD7CWp/+ioK+Bf2Yviu/wAEvj34K+JLTtHZ6ZqcaajjvYzAxXPHf91I5HuBX31/wWY/5FH4X/8AYS1P/wBFQV+WpHFAH9MiOkqLLE6ujgMrKcgg9CDXzn/wUG+Ff/C1v2VvGFlbW3naj4ciXxJYYGSHtMtLgdyYDOoA7sKs/sEfFv8A4XD+y74P1i6uvO1TQ4D4e1Mk5bz7QBEZj3Z4TDIfd6+gLq1t722ms7yBJoJ42iljcZV0YYKkdwQSKAP5oVakduK7j46/Da4+Dvxl8Y/DK4Vwvh/V7i1tmf70ltu3QSH/AHomjb/gVJ8CvhxP8YPjL4N+GkCuyeINYt7W5KdUtt26dx/uxLI3/AaLDuftP+wL8Lv+FU/sreCdKubbytQ1u1PiG/yMMZbs+YgYdmWEwof9yvoC9vLXTrOfUL64SC2tYmmmlc4WNFBLMT2AAJp1vbwWlvFaWsKRQwosccaDCooGAAOwAFfNH/BRj4s/8Kp/ZW8UG0ufJ1PxZs8M2ODgn7SG88jvxbpPz2OKQj8bvjn8Tbr4yfGPxh8TrovjxBq091bq/wB6O2DbYIz/ALkSxr/wGuIpiDApWbjinuMveH9A1Txb4i0rwrodubjUtZvYNPs4h/y0nmkCIv4swFf0Z/DbwPpfwz+H3hz4e6KB9i8OaXbaZC2MFxFGE3n/AGmILH3Jr8df+CXnwn/4WN+1BY+Jr228zTPAllLrcpZcobk/urZf94PIZR/1xNftdQxHAfEL4u6L8PvG/wAOvBGpbPtPxA1i50uBmbHliKzmm3e5MiwR4/6a139flX/wU/8AjleeFf2sPhYmjztI3wzhtdfMat0upbpZGjI94raD6h6/UvTNSstY0201fTbhZ7O+gjubeVfuyRuoZWHsQQaGrAfjz/wVk+En/CD/ALQdn8RrC28vT/H2mrcSMBhft9qFhmA+sf2Zj6l2PvXxJnPSv2w/4Kg/CP8A4WV+zBqXiKxtfM1TwJdR69CVGWNsMx3K5/uiN/MP/XEV+JqniqWwHW/Cf4jar8IviR4e+JmiWNreX/hy+S/t7e63eTI65wH2kNjnsRX2af8Agsd8cx/zS/wJ/wB83n/x6vgg4700jPSgW597N/wWR+Og/wCaX+BP++bz/wCPV+tmm3L3unWt5IoVp4ElYDoCyg8fnX8zDjjpX9MOgf8AIC07/r0h/wDQBRJIaPLf2t/jRr37PfwA8TfFvwzpVhqWpaI1isNtfh/Ifz7yGBt2xlbhZSRg9QK/Osf8Fkfjof8Aml/gT/vm8/8Aj1faf/BTT/kyr4gf9dNI/wDTpa1+GC4oik0Jn3frv/BXr43a9oeoaFc/DPwPHFqNpLaSPGt3uVZEKkjM2MgGvAP2HP8Ak7j4Wf8AYfi/9BavECDXuH7Dv/J3Hwt/7GCH/wBBartZCP6AK+Uv2+f2u/G37Jmh+D9U8F+GtE1iTxHd3dvOuqCYrGIkjZSnluvJ3nOc9BX1bX5//wDBW/4afEj4keFfhxb/AA6+H/iXxTLY6hqL3SaLpM980CtHCFLiFGKgkHBOM4NZx3KZ4R/w+T+On/RL/An/AHzef/HqX/h8n8dP+iX+BP8Avm8/+PV8mj9lz9pvp/wzp8T/APwkNQ/+NUv/AAy3+01/0bp8T/8AwkdQ/wDjVaWiTdn0f8Rv+Crnxl+Jfw/8S/DvVvhz4MtbLxPpN3pFxPbrdebFHcRNGzJumI3AMSMgjPaviVfWuu8Y/B34u/DrT4dW+IXwr8X+GLK5mFvDc6zod1ZRSS7S2xXlRQW2qxwDnAJ7VyOeKLLoAE9qSiiqAKKKKACmk9qUmm0AFFFFABRRRQJsKKKKCQooooAKKKQntTQCUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUoPakopMB1FHWipAKKKKACiiigAooooKQUUUUDHA5pab0pwOaACiiigBj96/f39hH/k0L4Xf9gNf/AEa9fgE/ev39/YQ/5NC+F3/YDX/0a9RPYaPeaK5b4q61qfhr4X+MPEei3P2fUNK0DUL20m2K/lzRW7ujbWBU4ZQcEEHHIr8Tx/wUw/bbP/NaR/4Tek//ACLUKLY27H7s1Q1//kBaj/16Tf8AoBr8N/8Ah5f+2z/0Wgf+E5pP/wAi0yf/AIKT/tqXUEltcfGYNFMhjdf+Ed0kZUjBHFtVcjFc+Zq/av8A4JP/APJo9n/2MGpf+hJX4qdK/an/AIJOyxyfslWyI4Ji8RakrgdjmM4/Ig/jTnsCPsqv5pvF5/4rDXP+wldf+jWr+lmv5q/H9lc6Z4+8S6bexNHcWmsXkEqMMFXWZwwI9iDUwBmNX1J/wTG/5PQ8E/8AXtq3/puuK+Wd3HNfVn/BLyyubv8AbL8JzwRM8dlYarPMQPuIbKWME/8AApFH4iqewH7h1+VH/BZ3/ke/hl/2CdQ/9HRV+q9flL/wWdljb4gfDWAODImj3zsvcAzoAf8Ax0/lUR3Gyt/wRnOfil8Q/wDsAW3/AKUV+sdfk3/wRm/5Kl8Q/wDsX7b/ANKRX6yUS3BHyj+0B/wTk+D37RfxNv8A4qeMPGHjLT9T1CC3t5INNuLVIFWGMRqQJIHbJCjPzda5Twt/wSO/Zc0HUYr/AFjU/G/iOONgxs9Q1SGOCTHZvs8Mcn5OK9p+Kf7a/wCzJ8FfGVz8P/ib8TP7G1+ziimmtP7G1C42JIgdDvhgdDlSDw3HevQvhZ8Wvh58bPB1v4++F/iWLXNCuZZYI7pIZYSJI22ujRyqsiEHsyjIIIyCCVdgbnhvw3oHg/QbHwv4W0e00rSNMgW2s7K0iEcUEa9FVRwP6nmuT+Onxk8KfAP4Xa58T/F1yi22lW7fZrcvte9umBENvH6s7YHsNzHhSR3U/n+RJ9l8vzth8vzM7d2OM45xmvwN/bA+Ovx6+LfxT1TQPjhcJYXXhS+nsIdAs1aOx0+RW2sY1JJctgHzWJLAjB24AErhc8Y8T+INU8XeJNW8Wa5P5+pa1fT6jeSf355pGkkb8WYmv6RfB8MNv4R0S3t8eVFp1skeBgbREoH6V/NWQMV/RR+zr4vg8e/AX4e+L4JRJ/afhvT5ZSDnEwgVZVPusiuD7imwRxH7eNxPbfshfE+S2zvOjCM4P8DTRq3/AI6TX4JxV/RP+0B4Bn+KXwP8d/D2zjD3mvaBe2lmCcD7UYmMOT6eYEr+dcpLbyvBPG8UsTFHRxhlYHBBB6EGkBLmmSEYpd4pYLa5v7qGxsoHnuLiRYooo13NI7HCqAOpJIGKEO5+/H7FE9xc/snfC2S5zvHhy2jGT/AoKr/46BXonxShhufhl4ut7jHlS6DfpJkZG027g/pVP4K+B3+Gfwg8FfD6YL5/h3QLHTbgqchpooEWRgfdwx/Gub/aw8aW3w+/Zr+JPiq5l8sweHLy2gbOP9IuIzBAPxllQfjSEfgd8NCf+FjeFP8AsN2P/o9K/pJr+bf4af8AJRvCn/Ybsf8A0elf0kVTA+fP24v2fPGn7S/wUT4b+A9T0Ww1NdZtdRMurzSxQeXGkgYboo5G3fOMDbjrzXwLaf8ABHn9o550W+8f/DeKEn5nivr+RgPZTaKD+Yr9epJYoV3zSKi9MsQBUR1CwAyb63AH/TVf8aQHzP8Asc/sKeDP2U1vPEk+uP4m8Z6pb/ZZ9Te38mG1tyQzQ28eWIBZV3OxJbauAoyD9QVxfi741/B/wFaPe+M/ih4W0aJM/wDH5q0EbMfRVLbmPsATXwl+1T/wVV8PQ6Pe+CP2aPtF7qNyr283ii6t2ihtlIwWtInw7ydcO6qq4BCvngA8W/4KvfGrT/iH8cdN+G+hXn2ix+H1pJbXTK2U/tG4KtOox12IkCH0ZXHavef+CNX/ACTn4jf9huz/APRDV+V9zPcXlxLeXlxJPPO7SSyyOWeR2OWZmPJJJJJNfqh/wRr/AOSdfEb/ALDdn/6IagD9EaKK/Hv9pf8Ab6/az+H37QPxA8EeEPisLDRdE166srC1/sLTZfJhRyFXfJbs7YHdiT70AfsJRX4ZD/gpR+2r3+Mw/wDCd0n/AORaeP8AgpP+2p/0WUf+E7pP/wAjUhlL/goSf+MyfiT/ANfdl/6QW9fPQ6VvfEH4h+L/AIreMtS+IPj7V/7U1/V3SS9u/s8UHmskaxqdkSqi4RFHCjpnrWCCMdaTKWgjnivrb/glh/ydzpn/AGBNS/8ARYr5Icivrb/glh/ydzpn/YE1L/0UKEDP2or4c/b4/Yc+LX7U3xC8OeLPh74h8I6fZ6Pox06dNZu7mKRpPPeTKiK3kBXDjqQc54r7jqKW5t4CFmuI4yeQGcD+dMg/Jjw7/wAEdfjfc6hFH4t+KHgfTrAsPNm043d7Mq99sckMIJ+riv0d/Z3/AGe/An7NXw5t/h54Fjmlj81ru/v7nBuL+6YANK+OBwqqqjhVUDk5J9Em1bSraMzXGp2kUa9WeZVA/EmvNPiL+1T+zv8ACq0mufGvxe8NWssKF/sVvepdXjem23h3SHP+7j3oA9N1LUrDRtOutX1W8itLKxge5ubiZgqRRIpZ3YngAAEk+gr+e39pj4sf8Lx+O3jP4oQ+b9j1nUm+wCUYdbOJRFbgjsfKjTI9c19Gftp/8FFdZ/aA065+GXwusLzw/wCBpWH22e5IW+1YKchXCkrFDnB2AktgFiBlK+KWGBTGfvd+wt/yaN8MP+wIv/o169i8WeHbPxf4W1nwlqE00Vrren3GnTyQkCRI5o2jYqSCNwDHGQRnsa8d/YW/5NG+GH/YEX/0a9e065rWmeG9F1DxFrVz9n0/S7WW9u5tjP5cMSF3baoLHCqTgAk44BpCPhxf+CO/7PAIz8Q/iMR3xeWI/wDbWvYvgV+wD+zl8ANfg8XeGdB1HWvEFnk2mqa9dLcy2xIwWjRESJW/2wm4c4IyaTRf+Cin7GviHWbDQNL+M0T3upXMVpbrLoepwIZZGCqGkkt1RBkjLMwUdSQOa+kKYBX52/8ABWz9oTSdM8Faf+zroGoJNq+tXEOqa7HG2fs1nEd8ET+jSShJAOoWIEjDqT9Hft0fFP4yfBn4Ban4/wDgzY6fLfWU8cepXNzCZpLCzkyhuYo87WZXMed4ZQGLEEKa/CvXvEOueLNbvvEvibVrrVNV1Odrm8vLqUySzysclmY8k0AewfsQj/jLX4Xf9h+L/wBBav34r8B/2Iv+Ttvhd/2H4v8A0Fq/fihgfnF/wWZ/5FH4X/8AYS1P/wBFQV+XGMiv1H/4LM/8ij8L/wDsJan/AOioK/LgdKBn6Ff8Effi1/Y/j7xb8F9Rudtv4hs11nTkY8C6t/llVR/eeJwx9rev1ar+df4CfFC5+C/xo8HfFC2aTZoGqwz3Sp96S0Y7LiMe7QvIv41/RFaXdtf2kN9ZTpPb3Maywyocq6MMqwPcEEGhiPyO/wCCvvw2/wCEb+Nvhv4mWlvstvGGjfZ7hwPv3lmwRiT/ANcZbcD/AHDUH/BIX4cf8JN8d9f+I91b77bwbopjhfH3Ly8Yxoc/9cUuR+NfWP8AwVd+HK+Mf2XJfFkFvvu/BOr2uphwMt9nlb7NKv0zNG5/6557VU/4JLfDxfCv7M03jSe323XjTW7m8WQjBa1t8W8a/QSRzkf79PoB9sV+Sv8AwV++LP8AwkHxX8MfCDT7ndbeE9OOo3yKePtt3gqrD1WGONh7TGv1jv76z0uxuNT1C4S3tbSJ555XOFjjUFmYnsAATX86nxu+JV58YvjB4v8AidelwfEOrT3cKP1it922CP8A4BEqJ/wGkgOLHSmucClJ44q/4b8Par4w8S6T4S0KAz6lrV9Bp1nF/fnmkVEX8WYCmB+vH/BJf4Tf8IX+z7ffEe+ttl/491N542IwxsbUtDCD3/1n2lh6h1NfcFc78OfBGlfDXwD4d+H2iLix8OaZbaZAcYLrFGqbz/tNjcT3JNa+rWB1XSr3S1vrmyN5byW4ubVlWaDepXzIywIDrnIJBGQMg9KQH8+n7XPxJX4tftKfELxzDcedaXWtTWtlJnIa0tsW8DD6xxIfxr9gv+CdvxN/4Wf+yZ4Lubi482+8OQv4bvOclWtDshBPqbcwH/gVeT/8OdP2ZT/zPXxP/wDBnp//AMhV9C/sy/sreBf2VNB1nw18PvEvijU9P1u8jvpYtbubeYQzKmwtH5MMWNyhA2c/cXGOcttNCR6xr2iaZ4m0PUfDmtWy3On6raTWN3C3SSGVCjqfYqxH41/OX8Vfh/qfwo+Jnif4bavuN14b1W405nIx5qxuQkg9nXaw9mFf0h1+Qf8AwV3+Ef8Awinxs0P4safa7LLxvpvkXbgcfb7MLGxPpuga3A9fLb8CIM+EM5opAaU9KqwXsRydK/pg0D/kBad/16Q/+gCv5npOlf0w6B/yAtO/69If/QBSkC3Pmz/gpp/yZV8QP+umkf8Ap0ta/DFe1fud/wAFNP8Akyr4gf8AXTSP/Tpa1+GKdqcdgY49K9u/Ye/5O4+Fv/YwQ/8AoLV4iele3fsOn/jLn4W/9jBD/wCgtVdBI/oAoor4k/4KdftG/GX9njw34Cv/AIPeMP7An1q+vob5/wCz7W681I44igxcROFwXb7uM55rJK+hT0PtuivwnH/BS/8Aba/6LSP/AAnNJ/8AkWl/4eYfts/9FoH/AITmk/8AyLVcjFc+3P8AgsicfALwb/2OEf8A6RXVfkMOleu/GX9rf9oP9oHw/ZeFvi74/GvaZp94L+2g/sqytdk4RkD7reFGPyuwwSRz0zivIx0rSKshMKKKKYBQTijpTSc0AJRRRQAUUUUCCiiigkKKKKACiiigAJxTaCc0VSAKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAAOKdTaUHtSaAWiiipAKKKKACiiigAooooKClBxSUUDH9aKaDinUAMbvX7+/sIf8mhfC7/ALAa/wDo16/ANutfv5+wj/yaF8Lv+wGv/o16iew0el/GDTr/AFj4S+NtI0q0lu72+8OalbW0ESlnlle2kVEUDqSSAB6mvwXX9jn9qvv+z348/wDBLN/8TX9C1FQpWG1c/nr/AOGOf2qv+jfPHf8A4JZv/iaUfsd/tVf9G+eO/wDwSzf/ABNf0J0VXOxWP5o/FvhHxR4E8QXnhPxnoF9ous2BRbqwvYWinhLIHUMjcjKsrD2Ir9Pv+CNnxQsbvwV44+Dd1cRpfabqSeIrONm+eaCeNIZto/uxvDFn3nHrXx5/wUb/AOT0viV/18ad/wCm21ryb4I/GPxj8A/iZo/xR8Dzouo6TId8EuTDdwONssEoHVHUkeoOGGCARTXMhbH9HVfmP+3n/wAE4PHPi3x7qvxr+AOnQ6q2vSm81rw+JUhnW7PMlxblyFkEhy7ISGDliu4NhftT9m39qz4T/tO+F49Y8DazHBrEEKNqmg3Lhb2wcjnK8eZHngSrlT7HKj2Ss03Flbn8+Ol/sZ/tXaxqq6Nafs/eN47hm2B7rSZLaDPvNKFiA9y2K/Uf/gn5+w5d/sw6bqPjr4hXNpd+PNfthaPFat5kOl2e4OYFk/jkdlQuw+X5FC5ALN9j0UOTegWCvxQ/4KofFCx+IX7UVz4f0m4jmtPBGlwaG8kbbla63PNPz6q0wjI7NERX3V+2x/wUC8F/AHQ9R8C/DnVrPXfiTOhgWGIiaDRiRzLcEfKZB1WHrnBcBfvfi1fX17ql9canqV1LdXl5K89xPK5Z5ZHJZnZjySSSSfU04rqJn6D/APBGf/kqXxD/AOwBbf8ApTX6x1+Tv/BGj/kqXxD/AOwBbf8ApRX6xUpbjR+IP/BUkH/hsbxL/wBg3S//AEkSu2/4JUftHf8ACtfivcfBbxJf+X4f8euv2EyNhLfV1GI8ennKPKPcusI9a4v/AIKjjP7YviX/ALBul/8ApIlfKdleXmm3tvqWnXUttd2kqTwTRMVeKRSCrKRyCCAQfaq3Qj+mivzB/wCCuH7Nvkz6b+0v4WsPkl8rSPFCxr0bG21um+oxCxPpCO5r7T/Y+/aBs/2kfgXofj5pYhrcC/2br8CYHlahEoEhwOiyArKo7LIB1Br0vx/4G8O/EzwTrfw/8W2YutI1+ylsbuPvsdcblPZlOGVuoYAjpULRjP5ss1+sP/BI79oC38Q+AtV/Z9129RdS8LySanoqu2GmsJnLTIo7mOZix9px/dNfmr8avhN4i+B3xS8RfC3xQhN5oN40KzbSq3MB+aGdR/dkjZHHpuweQayvh74+8WfCvxrpHxB8D6rJp2t6Jcrc2k6dMjgow/iRlJVlPDKxB4NVuI/pLr81v23/APgmh4m8Z+MdS+L/AOzxb2lzdazK13q/huWZLdmuWOXntXciP5zlmjdl+YsVJ3BR9Jfsnft0/C39pnRrbTLi9tPDXjqNQl3oF1cBTO+OZLRmx5yHBO0fOvIYYwzfS9TsM/n5H7Gf7V7ah/ZY+AHjXzt23cdMcQ5zj/W/6vHvuxX3P+w1/wAE1vEfw+8Yad8ZP2gobOHUtIkFzo3hyGZLjyLkfcuLmRMoWQ/MiIzfNtYsNu0/o/RRcAr85P8Agrv8fLbTfC2ifs8aFdxve6xJHrWuhGBMNrE3+jxMOxeQGTHUCFT0avff2tf28Phj+zVpFzo2l3ln4n8eyK0dtodtcBltHx/rLxlP7pRwdn334AAGXX8UPHHjXxR8SfF+reO/GmrTanret3LXV5cynl3PYDoqgAKqjhVAAwABQgJfhqMfEfwp/wBhux/9HpX9JFfzc/DYH/hY/hT/ALDdj/6PSv6RqGB8W/8ABWoZ/ZUiH/U06f8A+i56/GhEr9mf+CtAz+ypF/2NGn/+i56/GpBii4AEAp4WgHFG6gqwjDFfql/wRr/5Jz8Rv+w3Z/8Aohq/K1jmv1T/AOCNg/4t18Rv+w3Z/wDohqBM/RCvxJ/aq/Zd/aN8VftJfEjxJ4b+CfjHU9K1LxFeXNneWukyyRTxM5KujAYII71+21FAj+fcfsgftT/9G/eOv/BLN/8AE04fsgftTf8ARv8A46/8Es3/AMTX9A1FAH85fj/4R/FD4UPYx/ErwFrnhltTEjWY1Oze3M4j27ym4DO3emcdNwrlAeK/SP8A4LN/8hT4S/8AXDW//QrKvzaHSkUmK1fW/wDwSw/5O50v/sCal/6KFfI56V9cf8EsB/xlzpZ/6gmpf+ihQDP2pr8lP+Cxy5+NXgb/ALFdv/Suav1rr8lv+CxYz8avA3/Yrt/6Vy00SfASxinhPalUU6kUkJgUx8AVJTHFAM/ez9hb/k0b4Yf9gRf/AEa9eg/HD/ki3j//ALFfVf8A0kkrz/8AYW4/ZH+GH/YEX/0a9egfG/8A5Iv4/wD+xX1X/wBJJKCT+ckLxX7of8E+f2jf+GgvgNYrrl/5/izwh5ej63vbMkwVf3F0e582NeT3kSWvw0VeOlfQv7DH7RD/ALOXx50rXdUvGi8L6/t0fxApPyJbyMNlwR6xPtfPXZ5ij71UwP3U13Q9J8TaJqHhzXrCK90zVbWWyvLaUZSaCRSjow9CpI/Gv5+v2nfgXq37Ofxp1/4ZagJZLO2l+1aRdSD/AI+9PlJMMmehIAKNjgOjjtX9CKOkiLJG6ujgMrKcgg9CDXxj/wAFPv2bv+Fu/Bv/AIWb4bsPM8T/AA/SS7YRrl7rSzzcR8dTHgSrnoFkAGXpAfmv+xDz+1r8Lv8AsPxf+gtX78V+Av7D4P8Aw1r8Lif+g/F/6C1fv1QwPzh/4LNf8ij8L/8AsJan/wCioK/LhelfqR/wWa/5FH4X/wDYS1P/ANFQV+W6k0DEkHFfuX/wTn+Lf/C2P2WPDP2u687VPCW7wzfZOW/0cL5BPfm3eDnuQ1fhowr71/4JDfFr/hGvi/4i+EWoXO208Zad9tskY/8AL9abmKqO26B5if8AritHQR+oHxk8Bw/FH4T+MPh1Oqn/AISPRLzToy3RJZImWN/qrlWHuKo/AH4fD4VfBLwP8O2hEU+g6FZ2l0B3uREDO34ylz+Nd/RQB8wf8FH/AIs/8Kq/ZW8TR2lz5Wp+LynhmywcEi4DG4Pr/wAe6TjPYla/DRRgV99/8Fffiz/wkXxc8N/CKwud1r4Q00316in/AJfbvDBWHcrAkTA/9Nmr4FB9KaAViB3r67/4Jb/Cf/hYv7T1n4ovrbzNM8B2MutSFhlDdN+6tl/3gztKP+uJr5Cav2N/4JM/Cb/hCf2erz4iX1t5eoePtTe4RiMN9htS0MIP/bT7Sw9Q4oYH27Xinx+/bA+CX7NOq6TonxR1m/t73WreS6tobKxe5YRIwUs+37oJJA9drele11+FH/BRn4of8LR/aw8WvbXHm6f4WMfhmz5yFFtkTj/wIe4/DFCVwZ+i/wDw9W/ZE/6D/iT/AMEcv+NTWH/BUz9kXUL62sE8Ta9C1zMkKyTaNKkaFmAyzdlGeT2FfiXt9qRlFVyoWp/TfXyz/wAFJ/hH/wALV/ZX8RXVla+bqngx08S2eB82yAMLkZ64+zvM2O5RfSu8/Yz+Kn/C5P2aPAnjS4ufO1AaYmm6kxOWN3akwSs3oXMfmfRxXsWoWFlqthc6XqNslxaXkL288MgyskbqVZSPQgkVGzGfzMqe9PPSu1+OfwyvPgz8YfF/wwvQ5Ph7VZ7SB3+9Lbbt0En/AAOJo3/4FXEZrUWxHIc1/TFoH/IC07/r0h/9AFfzOsK/pi0D/kBad/16Q/8AoAqZgj5s/wCCmn/JlXxA/wCumkf+nS1r8MU7V+53/BTP/kyr4gf9dNI/9OlrX4XinDYGOY5GBXt/7Dn/ACdz8LP+w/D/AOgtXh5r3D9hz/k7j4WH/qPxf+gtVPYSP6Aa+CP+CsXwj+J/xY8L/Dq1+GfgLXPE82nahqEl2ml2b3BgV44QpcKDgEqcfQ1970VinZ3Kep/PUP2Of2q8f8m9+O//AASzf/E0f8Mc/tWf9G+eO/8AwSzf/E1/QrRV87FY/nd1z9lX9pLwzo194i8Q/A7xnp2maZbyXd5d3OkzJFBCilnkdiMBQASSewry0Hiv6G/2tf8Ak134tf8AYl6x/wCkklfzxr1qou4noOooppOaoAJzSUUUAFFFFABRRRQSwooooEFFFFABSE9qUnFNqkgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAOBzRTQcU6paAKKKKQBRRRQAUUUUDTCiiigoKUHFJRQA4jI4r33wJ+3p+1j8M/CGl+AvBHxW/s3QtFg+zWNp/YWmzeVHknbvlt2duSeWYmvAQcU7g0WuB9Nf8PLv22/+i1/+W3pH/yLR/w8u/bc/wCi1/8Alt6R/wDItfMmB6UYFKyA+m/+Hl37bn/Ra/8Ay29I/wDkWlH/AAUu/ba7/Gv/AMtvSP8A5Fr5jwKXAosgOl+I3xG8Z/FzxpqXxD+IWs/2r4g1do2vbz7PFB5pjjWJP3cSqi4RFHCjpk85Nc3toB9adRsBZ0jWNY8O6nb61oGrXmmajaOJLe7s52hmhcfxI6EMp9wa+mvAv/BTL9r7wRbpZTeP7TxJbRqFRNd06K4cY7mVAkrH3ZzXy5SYHpRZMD7dm/4K9/tSTW4gj8PfDyBwP9dHpN0XP/fV0V/SvIfif+3l+1X8WbS40rxF8Vr+w0y5BV7HRoo9PjKHqhaECR1PcO7A14BgUox3FHKkAYJJJJJPJJpdtLRSA9C+DX7QXxe/Z81XUda+EXi7+wL3VbdbW8l+wWt15sStuC4uI3A55yADXrH/AA8r/bZ/6LT/AOW5pH/yLXzLRSsgudb8Ufir4++NPjG58f8AxL17+2devIooZ7v7LDb70jQIg2QoiDCgDhee+a5TAoBFLQM9M+DH7S/xw/Z6XVU+EHjuXQI9aMRvo/sNrdpKY92xttxHIFI3sMqASDznAr0z/h5V+2x/0Wr/AMtzSf8A5Fr5nopNAd38X/jh8T/j34itvFnxY8RRa3q9parYx3a6ba2j+QrMyo32eOMPgu2CwJGcZxXC7fSkoBIpBYWN5YJUngkaOSNg6OpIZWByCCOhFfRXw4/4KD/tZ/DOCOwsPilda3YxKFW21+FNQAA4H72QecMegkx7V87ZB60YFAH2v/w92/ak+yfZv7C+H/mf8/H9k3Pmfl9p2f8AjteX/Ej/AIKBftYfE+CSw1P4p3ejWEqlGtNBhTTwQRggyRgSkEdQXI9q+eNoowKBisXlkaWV2d3JZmY5JJ6knvTgMU0HFLu9aTuBZ07UbzSNStNW06bybuxnjuYJNobZIjBlOCCDggHBBFfR/wDw8n/bX7fGn/y3NJ/+Ra+aOtGBSuB7J8Wf2w/2j/jn4VHgn4qfEX+29FW6jvRa/wBkWFt++QMFbfBAj8Bm4zjnpXjq5xTRxTt1AC0UmR60tIdwr1P4OftR/Hj9n7TdS0n4ReOv7BtNWnS5vI/7Ms7rzZFXarZuIXK4BxgECvLKKAPpQ/8ABSb9tjt8af8Ay3NJ/wDkWj/h5P8Atsf9Fo/8tzSf/kWvmvFGB6UxH0p/w8n/AG1/+i0f+W5pP/yLSj/gpN+2t3+NH/luaT/8i181YHpRgUDPSfjN+0d8Z/2hJdJn+MHjL+330JZ108/2daWvkibYZP8Aj3ij3Z8tPvZxjjGTXnAIx1ptFIaQ7I9a634WfFr4hfBTxdF47+GPiD+xtcggltkuvskFziOQYddkyOnI77c+lchRTBo+l/8Ah5N+2r/0Wj/y3dJ/+Ra8m+MXx5+LHx+1qx8RfFzxX/b2oaba/YrWb7DbWvlw7y+3bbxop+ZickE89a4Gii4WHAj1oyKbRSGO3CmnmiigR7z4G/bt/at+GnhHS/Angn4qf2boejQfZrG1/sPTZvKjyTjfJbs7ck8sxNaGt/8ABQz9sTxJouoeHta+L/2nT9UtZbK7h/4R/S08yGRCjruW2DDKsRkEEZ4Ir52ooEIB60hXNOooA+g/DX/BQT9r/wAIeHtM8K6B8YpYdM0i0isrOKXRNNneOGNQqKZJbdnfCgDLMTxya0JP+CkX7aU0bwzfGRZI5FKujeG9IIYHggg2vIr5r2ijAHemI2/B3jrxX8P/ABnp3xB8H6kmm69pN19tsrlLaF1hm55ETqY8cn5SuPavev8Ah5P+2v8A9Fo/8tzSf/kWvmnj0pKAPUfjL+098c/2g7PS7D4weOP7fg0aWWaxT+zLO18p5Aoc5t4kLZCr97PTivLwcUmKKAFJJrZ8D+N/Ffw08XaX478D6u+l67os4ubG7SNJDFJgjO1wyMCCQQwIIJBBrE3CkJJpoD6XP/BSn9tcf81p/wDLc0n/AORaT/h5T+2x/wBFp/8ALc0n/wCRa+aMCjApgbvjzx34t+J/jDVPHvjrWH1XXtZm8+9vHjSMyuFCj5I1VFAVQAFAAAAArCHFLSZFArgRmvoHwl+39+1t4D8L6V4L8JfFZNO0XRLOKwsLVPD2lsIYI1Cou5rYsxwOWYlickkkk18+kk0lAWPpj/h5V+2x/wBFq/8ALc0n/wCRa+btRv77V9RutW1O5e4vL2Z7m4mf70krsWZj7kkn8agophsFIRS0EgUw9T174Qfte/tF/ATwzP4O+E/xGfRNGubx9QktTpdldjz3REZg1xC7LlY04BA4zjJJPcf8PLP22f8AotX/AJbmkf8AyLXzOeaTA9KLILnW/FL4sePvjX4xn8ffEzW01fXrqKKCe8Wyt7UyJGu1NyQIiEhQBnGcADPArkqKKYhCO9fS0H/BSX9tO1gjtoPjRtjiQIi/8I5pJwoGAMm19K+aSfSk69adr7ge4/Ez9t/9qL4x+CtQ+HfxH+J/9r+HtVMJu7P+xdOt/MMUqSx/vIYEcYeNDwwzjByCRXhoGKWinogCtvwP428UfDbxdpfjvwVqf9na5otwLqxuvIjm8mUA4bZIrI3U8MpFYlNJ9KW4H00f+Cl37bQ6fGv/AMtvSP8A5FpP+Hl37bn/AEWv/wAtvSP/AJFr5lwKTAo5UB9N/wDDy79tz/otf/lt6R/8i0f8PLv22/8Aotf/AJbekf8AyLXzJgUYHpRZAfQvi3/goH+15468Lat4L8VfFz7do2u2U2nahbf2BpkXnW8qFJE3x2yuuVJGVII7EV89AYpelNJzTtYAJzSUUUAFFFFABRRRQS2FFFFAgooooAKOlFNJzTSuAdaKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAClBpKKAHUUgPalqQCiiikAUUUUAFFFFA0wooooKClBxSUUAP60U3OKcDmgAooooAKUHFJRQA7rS0zOKcDmlsAtFFFO4ADinA5ptFDQDqKQN60tSAUoNJRQA/OaKZShvWge46ijOaKVg1QUZIoopWHe4u71pabRSFYfRTdxpcigNRaMmiigdxd1LkU2kpWAfRTcn1pdxpWAdk0u6mbqXI9aLAO3ClyPWmUUgH0UzIo3D1pgPopmfelyaQDqKbk0ZNADqKbk0ZNADqKbk0ZPrQA6imZ9TRQA/I9aTcKbRQA7dSbjSZHrSbhTsA7NJSbqTJ9aLAOzSbhSUU7AGTRRRTC4UUmRSbvSgQ6k3elNooCwEk0UUU7DugoooyPWnYQUUhb0ptMNhS3pSUUUCCiikJ9KAFJxTSc0UU0gCiiincAopCcU0nNLcBSc0lFFMAooooAKKOlNJzQAE5pKKKACiiigAooooJbCiiigQUUUUAFFFITTACe1JRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSg5pKKGA6igHNFQAUUUUAFFFFABRRRQNMKKKKCgooooAcDmlplOB9aAFooooAKKKKAFB9adTKAcUmgH0UgOaWi4BRnFFNY0wF3+tJuFfuz+xBdlP2T/hmu7poq/8Aox69x+3H+9+tfLVuJYUakqfs9m1v2+R6cMslOKlzb+X/AAT+bXeKAwr+kr7cf7361S1Kw0XWYmg1jSbG+jcbWS5gSVWHoQwORWa4ph/z7/8AJv8AgFf2VL+b8P8Agn84gb0NOD+tftz8Zf2D/wBmr4v6fcY8C2XhPWXQ+Rqvh6FbNkf+88KAQy5PXcu4jOGU81+SP7RHwA8Z/s3/ABFufAXi7y7mNk+1aZqMKkQ39qWIWVQc7WyCGQnKsDyRhj6+AzfD5g+SGkuz/Q5K+EqYdXex5rupu4d69o/Yrk2ftWfDJvTXYv8A0Fq/d/7cf7361jmecRy2oqbje6vvb9GXhsG8TFyTsfzdBqd1r9Nf+Cwlx5vhP4ZjPTUdS/8ARUNfmQpruwOKWOoKula9/PZ2MK9F0JuFx1FFFdVjK4Uu40lIT2osPQUv703eK/Sf/gkT8MxbW3jX40X1vhpmj8OabIRg7V2z3JHsSbYZH91hX6Pfbj/e/Wvn8bn9PB15UVG9vO36HfRy+VaCne1z+bsMKcGr+kFrsOpR8MrDBB5BFfgV+018Lz8Gfjx4y+H0UBisrDUnm04Y4+xTAS2+D3xG6qfdT6V0Zbm8MxnKmo2aV97/AKIzxODlhoqTdzzWimhhilyK9c47gTikLn1p0MM91PHa2sMk08ziOOONSzOxOAqgckknAAr9I/2VP+CZGjjTbTxz+0nDPNdz7ZrbwtBcGOOFOo+1yJ8zOf8AnmjAL0YsSVXkxmOoYCHPWfourNqNCeIlywR+c2jaJrviK8GneHtGvtUuiNwgs7Z55CPXagJrsf8Ahn/4+/ZRff8ACj/H/wBmPSb/AIRm98v/AL68vFfvX4U8L+D/AAJpiaL4K8L6RoNggAFtptnHbR8dMqgAJ9zW19uP979a+fnxPG/uQ082egsrfVn85GraTrPh++fTNf0i8028j+/b3du8Mq/VXAIqqJK/ol8X+E/BvxA0iTQfHPhbSdf06UENbajaR3Cc9wHBwfQjkdq/PP8Aa2/4JoaZYaXf/ET9nCC5BtUM934Ud2nLoOWazdiXLAc+UxYnnYc7UPZhOIcNiJKFT3W/u/4BjVy+pTXNHU/OfeKQv601g8bNHIhVlJBBGCCOxFfWP/BMCbyv2r9MbOP+JLqP/osV7GIqrD0ZVrX5Vc46cPaTUO58neYPSnB6/pB+3H+9+tflV/wV2nMvxj8FHPTwyf8A0qlryMBnkcdXVFQte/W/6HXXwLoQ52z4U3ikMn4UzcK+tv2CP2QJPj54tXx/48sHXwB4fuB5kbggavdLgi2X/pmvBkI7EKOWJX18TiKeEpOrVdkjkp05VpKENz5K8ygP71/SBBPDawR21tGkUMSBI40AVUUDAAA4AA7V8zftv/tkWP7OHgv+wvDFzBc+PtfgYaZbnDixhOVN5KvoDkIp+846FVavDw/EDxVRUqVK7fn/AMA7qmX+yi5zlp6f8E/FncfWmlqsarqupa3qV3rOs3897f30z3NzczyF5JpXYs7ux5LEkkk9zX9CvwuvSPhn4RG7/mBWHf8A6d0r0MyzJZbGLlG/Nfrb9Dnw2GeJbSdrH88YanA5r9xv28Lsv+yP8SF3ddOh/wDSqGvw3VqvLcesxpOoo2s7b36eiJxNB4aSi3cfRTd1ISa9A59RS1N3ivrH/gmBL5X7V+mNn/mC6j/6LFfsn9uP979a8XMc6jl9b2ThfS+9v0O3D4F4iHOmfzdh6Un1Nfdv/BXefzfjH4KJOceGT/6VS18KWlrdahdwWFhbS3FzcyLDDDEhZ5HY4VVUckkkAAdSa9PCYhYuhGula5z1afsZuHYYWrT8P+FfFXi25ay8KeGtW1q4UZaLTrKS5cD3WME1+nP7Kf8AwTT8FeF9JsfG37QthHr/AIiuEEyeH3kzYafnkLNtP+kSAdQT5YJIw+A1fdWi2Gi+G9Nh0bw7pFjpen2y7YbSyt0ghjX0VEAUD6CvFxXEeHoycKK5vPZf8E7aWXVJq89D8Bp/2fPj9a24u7n4G/EGGFhkSyeGb1UP4mLFcPf2V/pV3JYapZXFndQnbJDPG0ciH0KsARX9H/24/wB79a5T4h/DX4bfFjSG0P4keCtH8Q2ZBCrfWyu8XvHJ9+Nv9pCD71zU+KI39+Gnky5ZXK2kj+eUNQWr7K/bd/YJl+A9rL8T/hXPd6j4HaULfWlw3mXGjs7AJl+skJYhQx+ZSVDFs7q+T/ADH/hPPDZ/6i9n/wCjkr6TDYuli6XtqLuv60POqUpUZ8k1qYRf0pu+v6Svtx/vfrR9uP8Ae/Wvnf8AWmH/AD7/APJv+Aej/Zcv5vw/4J/NrvFG8V/SV9uP979aPtx/vfrR/rTD/n3/AOTf8AP7Kl/N+H/BP5tdwpd4r+kn7cf7360fbj/e/Wj/AFph/wA+/wDyb/gC/sqX834f8E/m23E0tdN8VTn4o+MG9df1D/0oeuZr6uL5oqR5TVnYKKKQnFO4C00n0oJzSUWAKKKKYBRRRQAUhOKCfSm0AL1pKKKACiiigAooooJbCiiigQUUUUAFFFBOKAAnFNo60VSQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApwOabRSaAdRQDmipAKKKKACiiigAooooHewUUUUDCiiigYoOKd1plLQA6ikBzS0AFFFFABShvWkooAdnNNfvRSM3XNK1hH7gfsWXYT9lj4bpu6aOv8A6MevTfH3iu78LeBPEfifTkhku9I0m8v4EmBMbSRQs6hgCCVJUZwQcdxXi/7HN3s/Zi+HibjxpA/9GPXb/F+93fCbxsu48+HdSH/ktJX4lisWv7QnB/ztf+TH3dGg/q0Zf3V+R+ev/D2b9ovv4M+HX/gvvv8A5Lr3X9mX/gpinxT8c6d8Ofip4RsdCvtbnW107UtOmc2z3DcJDJHIWZC7YVWDEbmUED71floOelfQn7Iv7OvxF+JXxZ8M+II/D9/p/hvQtUttTvtVuIHih2wSLJ5UbEDfI20KAucbtx4FfpeZ5VldDCzqVIqFk9b216evp1Pl8Ji8VUqxjFuV3sftX9uH979a+J/+CrHhrTdY+CXh7xe0S/2joXiBLeKXjIt7iGTzE/F4oT/wGvrf7d/tGvz6/wCCn/xv0fUbLQvgfot8lzeWt4NZ1ny2z9nKxskELY/iIldyvUARn+IV8Bw3Wq4nM6UaXR3fpbX/ACPoszpxpYWTn/TPmD9jd9n7Ufw2b01yI/8AjrV+4v24f3v1r8M/2Qn2ftM/Dp+mNai/9Bav2r+3f7Rr1+NsR7DF01/d/VnHkVL2lGT8/wBEfEH/AAVwuBN4V+G4znGoaj/6Lhr82VJBr9FP+CrVx53hj4djOcX+of8AouGvzrXrX1HCtT2uVU5f4v8A0pnk5vHkxco+n5Ifu9aXIplFfQnnXH1GxpSSBXrP7J/w4HxT/aA8I+GrmDzdPgvRqeoAjKm2tv3rK3s5VY/+BiscTXhhaM69TaKbfyLpU3Wmqcd27H67fssfDxfg78AvBvgaWHyb6DT1u9RUjDfbJyZpgfXa7lB7IK3/AIt/F/SPhNoGl67q5Ux6nr+maIm5sBTdXKRu5/3IzI//AACtb7d/tGvgj/gqn8QZYdH8B+ALK7ZZJby41ycK2ChiURQN+Jlmx/u1+QZZUlnOZRpTfxtt/i2fZ4qCwOGc10SS/BH6Mfbh/e/Wvzg/4Kv/AA1C6n4P+Mlhb/Lcxv4f1J1HG9N01sT6kqbgZ9EUV9o/CT4hR/EX4YeFfHKShm1vSbW8m29FmaMeav8AwF9y/hXI/tXfD4fFz4B+LfCUMPnaglmdQ04AZb7VbnzUVfd9pj+jmllWaPLsxh7XSz5Zfk/u3+QYvB/WMM+TtdfmfiwpoJpiHNDHiv2Wx8Tc+7f+CY/7PuneKPEV/wDHXxdpq3Fl4cuBaaBHMuUe/wABpJ8HqYlKBT03OSPmQY/Tn7cP73614L+yj4Uj+Hf7O/gTw2FCTHSY7+5A6+fc5uHB9SGlK/8AARXfeN/G9n4H8G674z1DL22habc6lKgOC6wxs5Ue524Hua/Gs4zeePx8+V3V+WK8k7L79z7bBYJYfDxv2uzzP9pz9uP4dfs4SL4eezm8S+LZohMukWs4iW3Q/da4lIbysjkKFZiMHABBr5Ib/grX8YDqHmp8MvCIsd2fJL3Rl256eZ5mM477Pwr4v8XeLNc8eeKtV8Z+Jr17vVNZupLy6lbu7nOAOyjoB0AAA4FZWOK/RcFw5hKFFRrx5pdXr+H9XPmq+ZVqk24Oy6H7Ofsvftv+Af2kjLoC6fL4b8WWsPny6TcTiVJ4x96S3lAXzAMjKlVYZzggE19Efbh/e/WvwD+Fnj3UfhZ8R/DnxD0kubjQdQhuzGj7TNEG/exZ7B0LofZjX3r/AMPXPCX/AESLWf8AwaRf/EV83nPDuJpV08vg5Qa2utH21Z6eCzKlOnbEytJfj9x4/wD8FJvgdp/w2+Ldr8QvDNgLfRvHKS3M8cY+SLUkYefgD7okDpJ7sZMcDjJ/4Joy+V+1NpzHj/iT6h/6LFWv2sv20PC37Snw+0/wjZ/D/UdHvtN1WPUYbue9jlXaIpI3jwFB58wH6qKyv+CccnlftOac+cf8Si//APRYr3FLFU8hqLGRtOMZLpsttvI4OWlLMI+xd4to/Yj7cP7361+Xf/BWScS/F/waQc48Nn/0qlr9I/t3+0a/OL/gor4T8RfE39pT4f8AgPwnZm81XVtBjt7ePOAC11cZdj/CiqpZj2VSe1fHcK42MsxTm7JRk38ke1m+Hawzstbo+dv2X/2dfEf7SHxFh8MWBls9Csdlxrmphci1t8/dXPBlfBVF9csRhWr9rPBXhrwz8PPCumeCvB+mRado+j2621pbRdFUdyerMSSzMeWYknJJrzD9n/4N+Fv2fvhxY+BPDirLMoE+p35TbJfXbAb5W9BwFVf4VAHJyT0PxL+K3hT4TeC9S8d+M9S+y6bpse4gYMk0h4SKNf4nY4AH4nABIzzniCeb4pUsPdwTtFdW+/q+nb7y8FlqwVLnqb7t9ij+0l+0l4W/Zz+Hdx4v1tku9Tud1vo2liTD31zjgeojXILv2HHLMoP4p/EL4g+LPin4y1Tx7431R9Q1jV5jNPK3CqOiog/hRVAVVHAAArpPj38dPFv7QXxBu/HHiiUxQ8waZp6uWisLUHKxr6nuzY+ZiTwMAedgDGa/QMiyj+zaPNU1qS38vJfr3fyPnMfjPrU7R+Fbf5jG6V/QD8Mr0D4b+FBu6aHY9/8Apglfz/P0r94vhve4+HfhYbjxotj/AOiErw+N6/sadF93L9D0Mhp+0lP5HHftyXYf9lH4iJu66fD/AOlMNfiglfsr+2vd+Z+y38QE3Hmwh/8ASmKvxpWujgqt7bBVJf3v0RlnkPZ14ry/Vj6Q9KWkavsbHi6n1N/wTRl8r9qbTmzj/iT6gP8AyGK/X37cP7361+O//BOOXyv2nNOfOP8AiUX/AP6LFfrP9u/2jX5dxjivY5io/wB1fmz6vJKPPhr+b/Q/Nv8A4Kyzeb8XvBhBzjw2f/SqWuR/4JnfDnTPGv7QjeJ9Zgjmt/BmmvqkEci7lN4zrFC2Dxld7uD2ZFI9t/8A4KoTed8WfB7Zzjw6R/5My1D/AMEufF9jovxd8S+GLuZY5td0QSWucfvJLeUMUHvsd2+iH0r6GFeceGfbU9+V/dfX8LnmulF5pyS7/pofq19uH979a+SP20v27bv9nPVbHwD4F8PWWreKb2zF/NPqBc2tlCzMqZRCrSOxRjjcoUAE53Yr6W+3f7Rr5D/bV/Y21P8AaA1a0+IvgHWbS18TWViLG4sr0lIb6JGZkKyAHZIN7LyNrDbkrtyfickxuDljIrHu0Pwv0v5f09D3sdh66oN4de9/Wx846V/wVM/aYsb9bnULfwlqNvvBe2l0x41255CskgYcdyT+NfoZ+zF+054c/aW+Hx8W6VYvpep2M32TVtMeXzDazYypV8DejLyrYH8QPKmvx+8b/s0fHr4dtJ/wlXws1+GCLO+6trY3dsB6maHeg/E1zngv4o/Er4bC8h8BeOte8OC+ZDdrpt9JbecU3bd4QjJG5sZ6ZNfoONyXBZnQ5sA4qXRp3XzsfOUMdXwtS2ITa7Pf8T98vEml6N4t8P6l4W8Q2cd5pmrWstld28gyskMilWU/gTX4H+ItIvfhb8UNT0MslzdeEdemtdzghZJLW4K5IHOCY/1rpR+0/wDtGZ/5Ll44/wDB5cf/ABVefatq+qa/ql3ret6hcX+oX8z3F1dXEhklmlc5Z3Y8sxJJJPU1pkWT4jK3NVZqUZW0VyMfjaeLUXCNmj7YP/BWj41/9E58F/8AfN3/APHqaf8AgrX8ax/zTnwV/wB83f8A8er4eP1pjCu7+wsv/wCfS/H/ADMPr+I/nP36+DnxCv8A4j/Cjwj4+1a2t7W98Q6NaalcQ2+7yo5JYldlXcScAnjJJqX4tePL34f/AAs8YeO9Lt4Lm88O6Ffarbwz7vLkkggeRVfaQdpKgHBBxXnn7MF5s/Z0+Gqbjx4X04f+QEqx+0heb/2e/iYu7r4R1cf+SklfkrxMfr/senPb5c1j7BUX9X5+vLf8D4eH/BWz41n/AJpz4K/75u//AI9Th/wVq+Nf/ROfBf8A3zd//Hq+GlFPA9a/Wv7Dy7/n0vx/zPj/AK/if5y/4g1m48R+INT8RXcUcU2qXk17IkedqvI5chc84BbjNUKCR2ppOa9RKyscm4pb0pKKKoAooooAKKKQnFAC00nNBOaSgAooooAKKKKBBRRRQJsKKKKBBRRRQAUUUE4oACcU3rR1oqkgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFOBzTaKTQDqKAc0UgCiiikAUUUUAFFFFABRRRQUmFFFFAwpQaSigB+c0UynBvWgBaKKKACmP3p9MfvQB+xv7It35f7Nfw/T00kf8Aox69e+3e9eD/ALKF1s/Z18CJnppY/wDQ3rtfiTq1zZfDrxTeWN1Lb3EGi30sM0TlHjdYHKsrDkEEAgjkGv50zGm6mZVYJ7zkv/Jmfp+FajhYS7RX5Hof273o+3e9fiSPjt8b+v8AwuXxz/4UV5/8crtPhv8Ath/Hn4eaxDfy+OtT8R2IcfaLDW7p7tJUzyA8hLxnHQqR7gjivrqvh5jYQcqdWMn21V/meJDibDuVpQaXyZ+lfxz0P9oPxRpM9j8GfiL4e8NiSHaftWnSG6Zud2253OqAjoRDuB5Den5N/FT4efEb4b+L7vRvifpl7b6zO7XLz3MnnC83EkzLNkiUE5y2Sc5Bwciv2F8IeMtP8Z+FdH8XaUXFnrVjBfwB8blSVA4De4zg+4ryz9rn4YaV8VvgzrSy2qNrHh+2l1bSp9o3pJEu54wfSRFKkdM7T/CK5OF+IJ5RiFhK8FySdm7JST21a3S63+Rvm+VrG0nXpyfMldK+j+XT5H57/smvs/aQ+Hz+msxn/wAdav2R+3e9fjP+yw+39ofwE/pq8f8AJq/Xn7b/ALVdfiGv9upf4P8A25mPDH+7z/xfoj48/wCCotx53hrwB7X1/wD+i4q/PxSCa+8v+CmM/neHfAgznF7ff+i4q+ClNfZcFr/hFpesv/SmeFn3+/z+X5Ilopob3pd2OtfVWPHEY198f8ExvAAtbTxZ8V7yD552TQrByOdi7Zbgj2JMAz6o1fApbP41+wX7PHglfhb8GfC3g6SLyru3sVuL4Y5+1TEyyg+uHcqPZRXxXHWO+q5b9Xi9ajt8lq/0XzPe4dw3tsV7R7RV/m9F+p7L9u96/Jr9vXx6PHH7R2tQQzeZa+G7eDRISDxmMF5R+Essg/4DX6jfbf8Aar5c17/gn78GvEmuaj4i1bxj46lvtUu5b25k+3WfzyyOXc/8e3csa+C4SzLB5Ti5YnGN/DZWV92r/gvxPpM6wlfGUVSoJb3Zpf8ABN74inXvghd+DLmfdceE9TkijQnJW1uMzIf+/hnH/Aa+sPt3vXz78C/2aPAn7Puq6pqngrxF4luv7Xt0t7mDUrmCSI7G3I4EcKHcMsAckYZuPT2P7b/tV5ee18Pi8wq4jCN8knfXTV7/AI3OvLqVWjhoU63xLT/L8D8if2nPh2Phb8c/Ffhe3g8qwa8N/p4AwotZ/wB6ir7LuKfVDXlpPHWvun/gpJ4CF1a+F/inZw5eBn0S/cDnY26WAn2BEwz/ALS18Kmv2vh3Hf2lltKu371rP1Wj+/f5nwWaYb6pi501te69Hr/wD91vDNxFb+G9Kghx5cdjAiY6bRGoFeY/te6lNH+zX4+Nvnc2l7Dg/wALSorf+Ok1d+C/jGDxf8JPB/iOGXd9t0a0aTnOJVjCyL+Dqw/Cpfi/4dk8ffCzxX4NtwGuNX0i6trYE4HnmM+Vn23ha/D8P/smYwdb7E1f5S1P0CqvbYV8nWOnzR+NCdKlqJkkgkaGZGR0YqysMFSOoI7GlDkV/RR+YaD2xTat6LpWoeIdZsNA0mDz77U7mKztowcb5ZHCIufckCvdv+GE/wBor/oAaT/4NYf8a4sVmOEwLSxNSMG9rtK5vRwtbEJulByt2R8/HpzX0l/wT0l8r9pPT2/6hN9/6LFcB8T/ANmX4sfCHw2vivxxpun22nvcpZo0V/HKzSuGIAVTnojH8K7T9gWXy/2irB/+oXff+gCvNzfFUcZk+IqYealHllqndbHVgqNShjqUKsWndb+p+rn273rkz4D8PS/FM/Fu6j8/WY9Di0K0Lji2hE0ssjL/ALTmRQT2CYH3jV37b/tVi+MfHvh3wD4av/F3irU47HTNNiMs8r/oqjqzMcAKOSSAK/CKLq83JRveWmm7v0+Z+iVIwtzT2Wv/AATuft3vXiX7XXwUb49/Ci40XTJGXXtGkOpaQPMKpNMqkNCw6fOpKgn7rbTnGQfKP2cP21B8YviZrvgvxHYwaVFfObjwynG8xIuHgkbo0hVfMBHH+sHQLX1L9t/2q9Krh8bw7jYOa5akbSXVf8Hs/mjmhPD5ph2o6xd1/X5o/Dya3uLO4ltLuCSGeB2jljkUqyODgqQeQQQQRS54r7A/b4+Ai6HrX/C7PClljT9WlEWuxRrxBdtwtxgdFk6Mf7+DyXr473E96/c8pzKlm2EhiqXXddn1X9dNT88xuEngqzoz6fiu4PX7i/Du9x8P/DIz00ay/wDRCV+HD9K/an4f3mPAfhsbumkWf/olK+I8RV+6w/rL9D6DhfWdT0X6nLftlXfmfsy+PEz1sYv/AEoir8gVNfrL+17deZ+zd45TPWyi/wDSiKvyZU11+Hq/4T6n+N/+kxMOJtMTD/D+rJN1IxOKMikJzX3p85c+kv8AgnpJ5X7Smnv/ANQq/wD/AEWK/VL7d71+Un7AsnlftFWD5/5hd9/6AK/Tz7b/ALVfjXHy/wCFVf4F+bPu+G1/sb/xP9D8/wD/AIKdzed8VPCTenh8/wDpTJXyf4N8X+IPAPinTPGXhW/ay1XSLhbm1mUZ2sOxB4KkEgg8EEg9a+o/+Ck03m/E/wAKtnpoJH/kxJXzR4c+GfxH8Y2Dar4S8A+ItasklMLXGn6ZNcRCQAEoWRSNwDKcdeR61+g8NypRyOiqzXK4tO+2remp8zmim8wqezvdPp6I/UL4Bfts/DL4xafa6brepWvhnxXtCT6beTBIp5P71vK2A4PZCd45GCBuP0D9u96/E8/Aj43n/mjvjX/wQ3X/AMRU3gz4+/Gr4dBLfwn8SNdsIIeFtJLgz26Y7CGXcg/75r5bHcC4fFzlPLK6X91u6XzV3b1T9T18PxDUoxUcXTfqtPwZ+1X273rgviL8FfhB8V7eSLx34B0jUppB/wAfgh8q7X/dnj2yD6bsetfA3gn/AIKP/FvRZIofG3h3RfEdqCN8kSNZXLevzLuj/wDIdfa3wW+PXgz46eFm8S+EpZ4ntpBBfWNyoWe1lIyAwBIKkcqwODz0IIHyePyHNcgtiJXS/mi/8rNfNI9rDZhg8y/dx1fZr+kfEH7UX7EOq/CCwufHnw7vrnXPCkHz3cE4BvNOUn7zFQBLEO7gAr3GAWr5XU1+4d09tfWs1leQxz29xG0UsUihldGGGUg8EEEgivxy+N3ge3+G3xb8VeCbLItNM1GRbQFskW74khBPciN0BPrX6FwZxDWzWMsLi3ecFdPuttfNaa9b/f8ANZ7llPBNVqOkXpbs/wDgnF0xu9Oprd6+5ufOn7P/ALNd5s/Z9+HS56eGtPH/AJAWrH7Q95v+AfxHT18KaqP/ACUkrnP2dLvb8Bfh8u7p4csB/wCQVqf4/wB3u+BfxDXd18LaoP8AyVkr+eJL/hW/7if+3H6cl/sX/bv6H45qcUpJNMXtT6/oc/MgooooAKKKKACikJFITmgALelJRRQAUUUUAFFFFAmwooooJCiiigAooooAKKKCcUABOKb1ooqkgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUoPY0lFADqKQH1pakAooopAFFFFABRRRQAUUUUDTCiiigoKKKKAFBIpQQabRQA+mN3pQcUh5/GgD9Wf2XbrZ+z94ITPTTB/6G1dl8Qzdah4A8TWFlBJPcXOj3sMUUa7nkdoHCqoHJJJAArzT9mm88v4EeDEz004D/AMfavTPt3+1X89Zg/Z5jVmuk5P8A8mZ+pYWPPhYR7xX5H5VD4EfGz/okvi7/AME8/wD8TXS+DP2T/jn4y1SGxbwRe6LbO4E17qyfZo4V7ttb52+iqT/Ov0w+3f7VH27/AGq+tqcf42UWoUop99X+p4kOF8OneU218iXwVodn4I8H6L4O0+ZpLbRLCCwjkfhnEaBdx9zjJ+tU/id4ltPD/wAOPFGtX8iLBZ6Rdytu6HETYX3JOAB6mnXetWlhbSXt9dxW1vCpeSWVwiIo6kseAPrXxF+1r+1Dp3juxb4Z/D29Nxo/mq+p6imQl2yHKwx+sYYBi38RAxwMt85k2V4jOcbFRTaveUui1u/m+iPUzDF0svw7betrJHkP7MbbPj94Hf01aP8Aka/V/wC2+9fk3+ze3l/HXwW/pqifyNfqL9u/2q+i8QVfHUv8H6s8vhf/AHef+L9EfO37eXgrxp4/0TwhB4N8MalrUlnd3bzrZW7SmIMkYUttHGcH8q+PR+z98cP+iU+J/wDwXSf4V+pf27/ao+3f7VcOU8X4jKcJHCU6cWo31d+rv+p043IaWNruvKbTdu3RWPy1/wCGf/jh/wBEp8T/APguk/wrF8VfDX4geB7SG+8YeDdX0a3uJPKilvbVold8Z2gkcnAJr9ZPt3+1Xy1/wUAuPO+H/hpc9NYY/wDkB6+jyjjPE5ljqeFnTilJ2ur9mzycfw/RwmHlWjNtr0Pmf9mvwKPiH8avDOhzw+ZZW90NQvQRlfIg/eFW9mKqn/A6/Vz7b718Q/sBeDltLPxH8RrqLD3DLpFmxHOxcSTY9iTCPqhr6/8At3+1XzvG+N+t5l7FPSmrfN6v9F8j1OHcN7HCe0e8nf5bL/P5mP8AFT44+Bvg3ptlqnje/ngi1Cdre3WCAyuzBdxOB2Axz7ivNv8AhvL4B/8AQV1j/wAFj180ft2eOD4i+KFh4Tgm3W/huwAdc8C4nxI//kMQ/rXzaFr3cl4LwWMwFPEYpy5pK+jSVnt0fSx5uYZ/iMPiZ0qNuWOmq+/r3P0p/wCG8vgF/wBBXWf/AAWPXuukeIrHXdJstb0u4E1nqFvHdW8g6PFIoZW/EEGvxhK1+i37Gvj8+J/grY6Vcz77vw3PJpkmTyYx88R+gRwo/wBw153FHCuGynCxxOEcnrZ3d9Hs9l10+Z1ZNnNXHVnRrW2urHq/x28Gr8TvhL4l8GrGJLm7smlsx3+1RESQ49Muig+xNfkmQVJVgQRwQexr9ift3+1X5i/tK+CB4D+M3iDTbeHy7K/m/tSzAGB5U+XIHsr70/4DXZ4f47llVwMnv7y/J/p9xjxRhrqGIXo/zX6n1N+wH8XItS8H33wn1K4VbzQpHvNOUnBktJXLSKB32SsSfaVfSvrP7b71+N/hDxbr3gTxJYeLPDN61rqOmzCaFx0PYqw7qwJUjuCRX6M/BP8AaZ8GfGDTYrf7TDpPiJFxcaVPKAzNjloSceYn05HcdCeLjHh2rh8RLH0I3py1lb7L6t+T3v3+RvkOaQq0lhartJaLzX+aPKv2mv2N9W8T+Ir34hfCSO3kuNRcz6ho0kqxFpyctLAzYX5jyysRzkgnO0fM3/DPHxz+1/Yf+FV+I/MJ27vsTeX/AN9/cx75r9Rvt3+1R9u/2q5cv41x+BoKhJKaWibvf8Hr+fmb4rh7DYio6ibjfe2x8u/sr/sjax4H8RW3xK+KKW8Wo2OX0zSo5FlMMpGPOmZcruAJ2qpOCQSQQBX2D9t96wPt3+1XiHx7/aq8M/CvT7nRPD91Bq3iuRGSK2jYPFZt0DzkHgjr5f3jxnAOa8mvVx/E+NTa5pvRJbJfovNnbTp4XJ8PvaK77t/qzyf/AIKDfFO21jV9E+FmmXSyjSSdT1IKc7bh02wofQiNnY+0q15/+wtJ5X7QFi//AFDL3/0AV4VrGrap4h1W71zW76W8v7+Zri4nlOWkkY5LH8a9s/Yok8n47Wb5/wCYdef+gCv1HEZbDKuHqmEi72hK77tq7f3/AIHxtLFvG5pCs+slb06H6X/bfevhf/gol4o1ybxN4X8JrqUo0gWDX7WinCNcGR08xgPvEKMDPTLYxk5+yft3+1Xwz+35L5/xD8NtnpopH/keSvz3guEXm8LrZS/I+p4gbjgJWfVfmfM+jatqXh/VrPXdFvZLS/0+dLm2njOGjlRgysPoQK/Vv4E/GfT/AIy/Dyw8WW5jiv1H2bVLVT/x73SgbwB/dbIZf9lh3Br8m69e/Zk+NM3wc+IEct/csPD2tbLTVEzwgz8k+PVCTn/ZLjriv0HivJP7XwnPTX7yGq811X+Xn6ny2SZj9Rr8s37ktH5dn/n5H6b+ItL0jxZoV/4a1+zju9O1O3e2uYX6OjDB+h7gjkEAjkV+Unxq+FOrfBv4gX/g/UC81sp8/TrphgXVqxOx/wDeGCrDsyt2xX6lx6nHNGs0MqvG6hlZTkMD0IPcV5D+018ILf4yeA3jsIU/4SLRg9zpcp4Mhx88BPo4Ax6MFPTNfn3Cmdf2Ri/Z1X+6no/J9H/n5eh9TneXfXqHPD447ea7f5eZ+azHNfsZ4EvMeB/Doz00q0H/AJBWvx1nilt5ZLe4ieKWJijo64ZWBwQQehBr9bfBF9jwXoAz00u1/wDRS19L4hJOlh/WX5I8jhb46vov1Mz9pbTtY8T/AAM8W6DoGnXGoaheWkaQW1uheSQiaMkKo5PAJ/CvziH7P/xwH/NKfE//AILpP8K/Ur7d/tUfbv8Aar5bJOJq+R0JUKUFJN31v2S6eh7WY5NTzGoqk5NWVtD8t/8Ahn/44f8ARKvE/wD4LpP8Kqat8Ffi7oWm3Osaz8OPEFlY2cZluLiaxkSOJB1ZiRgCv1T+3f7Vee/tC3m/4IeNkz10e4H/AI7X0OF46xWIrwpOlG0ml16ux5dbhqhSpympvRN9D45/YWl8v9oCxbP/ADDL3/0AV+k/233r8zv2JpPK+O9k+f8AmG3g/wDHBX6Jfbv9qvL48V80X+Bfmzr4a/3N/wCJ/kj4j/4KJy+d8SfDBz00Mj/yYkrvP+CdXjG2/wCEV8V+CGk23FrqEeqopP30ljWNiPoYVz/vCvN/2/pfP+IfhtuuNFI/8jyV4f8ACL4n638IPHNj400ZfO8nMN3alyq3Vu334ye3QEHnDKpwcYr6rDZa814XhhofFa69VJv8dvmeLWxawWcSqy2vZ+jR+u/233r84/2i/wBlDx74S8Yap4j8DeHrvXfDWpXEl3CthEZprPexYxPEuW2qScMARtAyQc19pfDn4u+DfinoUeu+EdXjuF2qbi2YgT2rkfclTOVPXnocZBI5rq/t3+1X5/lWaYvhvEy5Y67SjL+tGuh9TjcDQzairvTdNH5K2Pw2+Iuq3Is9O8BeIrmfcF8uLTJ2YH3wvFffv7FvwV8T/BvwprOqeMkFpqviWW3c2IcMbaGEPs3kcb2MrkgE4AXPOQPbft3+1R9u/wBqvSzri7EZxhnheRQi7X1u3Z3/ADOTL8hpYGqq3M5NbdDf+2+9flX+1Nr1r4j/AGgvGup2kqyRrfLZ7l6FoIUhb/x6M19kftEftOaD8KdDu9E0G/hvvF1zG0VvbRMHFkWHE03ZcZyEPLHHGMmvzkmmnup5Lm5meWaZzJJI5yzsTkknuSa97gPKa1Fzx9VWUlyx81dNv00Vu55fEuNpzUcNB3ad35dEgzUbZ5zT6a1fpJ8mfrV+z7d7Pgb4DXPTw9Yj/wAgrU/x2u93wT8fLnr4Z1Mf+S0lc98B7zZ8FvA6Z6aDZD/yCtTfG283/Bvx0mevhzUR/wCSz1/Priv7V/7if+3H6ev9y/7d/Q/Khe1PpqinV/QR+YBRRkCmk0AKSBSEk0lFABRRRQAUUUUAFFFFBLYUUUUCCiiigAooooAKKKQnsKYATikooqrAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFAOKKKAHUU3OKcDmpaAKKKKQBRRRQAUUUUAFFFFABRRRQVcKKKKBhQRmiigD0rw5+0n8a/COh2fhvw940Npp2nx+VbQ/2daSbEznG54ix6nqTWn/AMNbftCH/moP/lKsv/jNeRUYHpXnyyjL5ycpUINvryx/yOqOPxcUoxqysv7z/wAz13/hrT9oT/ooP/lKsv8A4zUc37Vv7QNwmyT4hyAf7GnWiH81iBryalBHpUrJstW2Hh/4BH/If9oYv/n7L/wJ/wCZ0Pin4iePPG5H/CW+L9W1VA29Yrm6dolPqsedq/gBXPBadRXfTpQox5KaSXZaHNOcqj5pu7L/AId8Qaz4T1yz8R+H7z7LqOnyia2m8tX2OOh2uCp/EGvTP+GtP2g/+ign/wAFVl/8ZrySjArnxGAwmLkpYilGbXeKf5o1pYqvQVqU3FeTa/I9a/4a0/aE/wCig/8AlKsv/jNH/DWn7Qn/AEUH/wApVl/8ZryTAowKw/sbLf8AoHh/4BH/ACNf7Qxn/P2X/gT/AMz1z/hrT9oT/ooP/lKsv/jNcx48+NPxL+J1hbaZ458SnU7a0mM8KfY7eHbJtK5zEik8E8E4ri8D0orSlleBoTVSlRhGS2aik180iJ43E1IuE6kmn0bZ6H4Q/aD+LvgLQLfwx4S8WjT9Mti7RQDTrWTBdizEs8RYkknqT6dAK2v+Gs/2g/8AooJ/8FVl/wDGa8ioqZ5TgKsnOdCDb1bcYtv8Bxx2KhFRjVkkv7z/AMzR8Qa/rPizW7zxH4gvWvNR1CUzXM7Kql3PfCgAfQAAVRpuTRu9q7YwUIqMFZI5m3J3e4pGa63wD8W/iJ8LhfJ4F8Rtpi6iYzcr9mhmEhTdtOJUbBG5umM556CuSyKMiorUaeIg6daKlF9Grr7mVTqTpS56bafdaM9b/wCGs/2g/wDooJ/8FVl/8ZrivHnxK8bfE6/ttT8cayupXVpCYIZfssMJWPcW2/ukXIySec4yfWuZwPSlrnoZdgsNP2lGjGMu6ik/vSNamMxFaPJUqSa7NtibRQjyQyLNE7RyIwZXU4KkdCD2NLRXbdM5z1Pwt+1H8bvCkS20HjKXUrdRgRanGtyf++2/ef8Aj1dY37cPxlMHlDT/AAyG/wCeospd3/o3H6V8/wCB6UYFeVVyPLK0uedCN/RL8jthmeMprljUdvU9N8XftLfGnxnDJaah4zuLO0lUq1vpyLbKQeoLIA5B9CxFeYYJJJ5J6k07Apa7sPhKGEjyYeCivJJfkc9WvVrvmqybfm7ibRW34N8beKPh7rieJPCGqfYNRjjeJZ/JjlwjDDDbIrLz9KxaK1qU4VYuFRJp7p6pkRnKElKLs0etf8NZ/tBf9FBP/gqsv/jNcT47+JPjb4nahbap441r+0rq0h+zwyfZoodse4tjESqDyTyRmuawPSlrlo5bgsNP2lGjGMu6ik/vSNqmMxFaPJUqSa7NtiUhWnUV2nOel6D+0t8b/DOjWfh/RfHUkNhYRLBbxPY2spSNei75IyxAHAyTgADoKv8A/DWf7QX/AEUA/wDgqsv/AIzXklGBXnSyjLptylQg2/7sf8jrWPxcVZVZW/xP/Mv+IvEGreK9bvPEWuzxz6hfyGa5lSCOESOerbI1VQT1OByck8kmvRbL9qf49adZwafZePDHb20SwxJ/ZlmdqKAFGTDk8Ada8spMCtq2CwmIjGFanGSjsnFNL0utDKnia9JuVObTe9m1f1PWv+Gs/wBoP/ooB/8ABVZf/GaP+GtP2hP+igH/AMFVl/8AGa8lwKMCuf8AsfLf+geH/gEf8jX+0MZ/z9l/4E/8z1r/AIaz/aD/AOigf+Uqy/8AjNUNf/aV+NnijRb3w7r3jY3Wn6hC0FzD/Z1om+Nuo3LEGH1BBrzTAoyKccoy+ElKOHgmv7kf8hPH4uSs6srf4n/mbXgzxt4n+HuuJ4k8H6p/Z+oxxvEs3kxy4RhhhtkVl5+leg/8NZ/tB/8ARQT/AOCqy/8AjNeR7vakzWtfLsJip89elGT7uKb/ABRFLF4ihHlpTcV5No6fx58SfG3xO1C21TxvrX9pXVpD9nhk+zRQ7Y9xbGIlUHknkjNczj3pKK6aVGnQgqdKKjFbJKyMpzlUk5zd2+rLmj67rXhy/TVPD+rXmm3kf3J7SdopB/wJSDivXNC/bC+OejRiG41+y1VFGF+3WKEge7R7GP1JJrxekwPSufFZfhMb/vFOMvVJ/ia0cVXw38Kbj6M+hJP25fjG8YRdK8LxkfxrZz5P5zEfpXG+Kv2n/jd4tgktLvxrPYW0nWHTYktePTeg8zHsWry3ApcCuajkWW0Jc1OhG/on+ZvUzPGVVyyqO3qDvJNI00sjO7sWd2OSxPUk9zR0oor1ThCkIzS0UAem6H+018cPDejWXh/RfG5trDToEtraH+zbR/LjQYVdzRFjgDqSTTtZ/ad+OXiHR77QNY8cG4sdSt5LS5i/s2zXzIpFKuu5YgRkEjIINeXkikya4P7JwHPz+whfe/LG9++x1fXsVy8vtJW/xP8AzFGB1pCTSUV3nKFFFFABRRRQAUUUUCuFFFFBIUUUUAFFFFABRRRQAUUE4ppOaaQCk5pKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBQfWlptAJFJoB1FAOaKkAooooAKKKKACiiigAooooHcKKKKB3CiiigYUUUUAFLu9aSigB2RS0ylyaAHUUm6jIoAWiiigAooooAKKKKACiiigAoyfWiigBdxpdwptFFgHZFGR602ilYB2RS0yiiwD6KZRRYB9FMoosA+kptFFgHZHrRkU2iiwDtwpNxpKKdgFyfWkoooAKKKKACiiigAooooAKKKKACijIpN1AC0mRSZNJQA4t6Umc0lFABRRRQAUUUUAFFFFArhRRRQK4UUUUCCiiigAooooAKKKCcUAFIT6UhJNFUkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKUN60lFADqKbnFKGqbALRRRSAKKKKACiiigAooooAKKKKACiiigq4UUUUAFFFFAwooooAXNG40lFADtwpcimUUAPoptGTQA6ik3e1G4UALRSZHrS0AFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUmR60ALRSbhRu9qAFopu40ZNADsik3Cm0UALuNGTSUUAFFFFABRRRQAUUUUAFFFFArhRRRQK4UUUUCCiiigAooooAKKKKACigkCmkk07AKW9KSiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAAcU4EGm0UrAOopoJFOBBpWAKKKKQBRRRQAUUUUAFFFFABRRRQAUUUUDuFFFFA7hRRRQFwooooGFFFFABRRRQAUUUUALk0u4U2igB2RS5HrTKKAH5HrRTKKAH0UyigB9FMooAfRketMooAfketJkU2igB24UhNJRQAUUUUAFFFFABRRRQAUUUUAFFFFAgooooC4UUUUCuFFFFAgooooAKKKKACiiigAooooAKKCQKaSadgHEgU0nNFFOwBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAASKUEUlFKwDqKbk0ob1pWAWijNFIAooooAKKKKACiiigAooooAKKKKACiiigAooooHcKKKKAuFFFFA7hRRRQAUUUUDCiiigAooooAKKKKACiiigAooooAKKKKBBRRRQFwooooFcKKKKAuFFFFAgooooAKKKKACiiigAooooAKKKKACiiigAopC3pSZJp2AcSBTSTRRTsAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoyaKKAF3ClptFKwDqKTcaNwpWAWiiikAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFA7hRRRQFwooooC4UUUUBcKKKKAuFFFFAXCiiigQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFJuFG407ALSZFJRTsAZNFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/9k=";
var CUSTOM_EMOJI = {
	"👤": "6032693626394382504",
	"✏️": "6039779802741739617",
	"📄": "6034969813032374911",
	"💰": "5778421276024509124",
	"📎": "6039451237743595514",
	"📝": "5922693616953725714",
	"📊": "5936143551854285132"
};
var KEYS = Object.keys(CUSTOM_EMOJI).sort((a, b) => b.length - a.length);
function escapeRegExp(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function applyCustomEmoji(text) {
	let out = text;
	for (const base of KEYS) {
		const id = CUSTOM_EMOJI[base];
		out = out.replace(new RegExp(escapeRegExp(base), "g"), `<tg-emoji emoji-id="${id}">${base}</tg-emoji>`);
	}
	return out;
}
function hasCustomEmoji(text) {
	return /<tg-emoji\b/.test(text);
}
var BUTTON_EMOJI = {
	"🛡": "6030445631921721471",
	"📝": "5922693616953725714",
	"📣": "6039422865189638057",
	"👥": "6032609071373226027",
	"🌐": "5776233299424843260",
	"⬅️": "5960671702059848143",
	"✅": "5774022692642492953",
	"🔎": "6032850693348399258",
	"🌟": "5805331990618053402"
};
var BTN_KEYS = Object.keys(BUTTON_EMOJI).sort((a, b) => b.length - a.length);
function decorateButtons(markup, useIcons) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return markup;
	const rows = m.inline_keyboard.map((row) => row.map((btn) => {
		const text = typeof btn.text === "string" ? btn.text : "";
		if (!useIcons || !text) return { ...btn };
		for (const emoji of BTN_KEYS) if (text.startsWith(emoji + " ")) return {
			...btn,
			text: text.slice(emoji.length + 1),
			icon_custom_emoji_id: BUTTON_EMOJI[emoji]
		};
		return { ...btn };
	}));
	return {
		...markup,
		inline_keyboard: rows
	};
}
function markupHasIconableButton(markup) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return false;
	return m.inline_keyboard.some((row) => row.some((btn) => typeof btn.text === "string" && BTN_KEYS.some((e) => btn.text.startsWith(e + " "))));
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	allowCheck: () => allowCheck,
	allowEvidenceChunk: () => allowEvidenceChunk,
	allowEvidenceDownload: () => allowEvidenceDownload,
	allowEvidenceUpload: () => allowEvidenceUpload,
	appendEvidenceChunk: () => appendEvidenceChunk,
	bannerById: () => bannerById,
	bannerFilePath: () => bannerFilePath,
	blacklistEntry: () => blacklistEntry,
	checkCounterparty: () => checkCounterparty,
	configureFromOrigin: () => configureFromOrigin,
	diagnoseUserSearch: () => diagnoseUserSearch,
	evidenceBytesOnDisk: () => evidenceBytesOnDisk,
	evidenceOwnedBy: () => evidenceOwnedBy,
	featuresEnabled: () => featuresEnabled,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	hasUserbot: () => hasUserbot,
	isDisconnectError: () => isDisconnectError,
	listBanners: () => listBanners,
	listComplaintsForUser: () => listComplaintsForUser,
	listSponsors: () => listSponsors,
	postMatchesSubject: () => postMatchesSubject,
	recentBlacklist: () => recentBlacklist,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveChannelAsUser: () => resolveChannelAsUser,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	saveUserLocaleServer: () => saveUserLocaleServer,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	setAudienceBase: () => setAudienceBase,
	setSponsorLink: () => setSponsorLink,
	sponsorAvatarPath: () => sponsorAvatarPath,
	sponsorStats: () => sponsorStats,
	uploadedEvidencePath: () => uploadedEvidencePath,
	userbotStatus: () => userbotStatus,
	verifyAccountPair: () => verifyAccountPair,
	verifyEvidenceDownload: () => verifyEvidenceDownload,
	verifyTelegramInitData: () => verifyTelegramInitData,
	webhookSecret: () => webhookSecret,
	webhookSecretMatches: () => webhookSecretMatches
});
function botToken() {
	return process.env.TELEGRAM_BOT_TOKEN || "";
}
var warnedMissingToken = false;
function requireToken() {
	const token = botToken();
	if (!token && !warnedMissingToken) {
		warnedMissingToken = true;
		console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
	}
	return token;
}
function isDisconnectError(err) {
	const any = err;
	const code = String(any?.code || any?.cause?.code || "");
	const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
	return code === "ECONNRESET" || code === "EPIPE" || code === "ECONNABORTED" || code === "ERR_STREAM_PREMATURE_CLOSE" || /aborted|socket hang up|ECONNRESET|premature close/i.test(msg);
}
function installDisconnectGuards() {
	const swallow = (err) => {
		if (isDisconnectError(err)) return;
		console.error("[epb]", err);
	};
	process.on("uncaughtException", swallow);
	process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
function botApi() {
	return `https://api.telegram.org/bot${requireToken()}`;
}
var BOT_USERNAME = "EuropeBlack_bot";
function webhookSecret() {
	return `epb-${createHash("sha256").update(botToken()).digest("hex").slice(0, 24)}`;
}
function webhookSecretMatches(header) {
	const expected = webhookSecret();
	const got = String(header || "");
	const a = Buffer.from(got);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var RELAY_PATH = join(DATA_DIR, "telegram-relay-chats.json");
var BACKUP_DIR = join(DATA_DIR, "backups");
function writeJsonAtomic(path, value) {
	mkdirSync(dirname(path), { recursive: true });
	const tmp = `${path}.${process.pid}.tmp`;
	writeFileSync(tmp, JSON.stringify(value, null, 2));
	renameSync(tmp, path);
}
function readJson(path) {
	try {
		return JSON.parse(readFileSync(path, "utf8"));
	} catch {
		return null;
	}
}
function latestBackup(prefix) {
	try {
		const names = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		return names.length ? join(BACKUP_DIR, names[names.length - 1]) : null;
	} catch {
		return null;
	}
}
function backupDaily(prefix, value) {
	try {
		const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		writeJsonAtomic(join(BACKUP_DIR, `${prefix}-${day}.json`), value);
		const old = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		for (const name of old.slice(0, Math.max(0, old.length - 30))) unlinkSync(join(BACKUP_DIR, name));
	} catch {}
}
function mergeRelayLists(...lists) {
	const out = [];
	for (const list of lists) for (const chat of list || []) {
		if (!chat?.id) continue;
		const idx = out.findIndex((c) => sameChat(c.id, chat.id));
		if (idx < 0) out.push({
			...chat,
			id: String(chat.id)
		});
		else if (out[idx].status !== "on" && chat.status === "on") out[idx] = {
			...out[idx],
			...chat
		};
	}
	return out;
}
var bindingsLoadFailed = false;
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v4-admin";
function loadBindings() {
	let raw = readJson(BINDINGS_PATH);
	if (!raw && existsSync(BINDINGS_PATH)) {
		const backup = latestBackup("telegram-bindings");
		raw = backup ? readJson(backup) : null;
		if (!raw) {
			if (!bindingsLoadFailed) console.error("[epb] telegram-bindings.json is unreadable and there is no backup; it will not be overwritten");
			bindingsLoadFailed = true;
		}
	}
	const loaded = raw || {};
	const relayFile = readJson(RELAY_PATH);
	const relayBackup = relayFile ? null : readJson(latestBackup("telegram-relay-chats") || "");
	loaded.relayChats = mergeRelayLists(loaded.relayChats, relayFile, relayBackup);
	return loaded;
}
function saveBindings() {
	if (bindingsLoadFailed) return;
	try {
		writeJsonAtomic(BINDINGS_PATH, bindings);
		writeJsonAtomic(RELAY_PATH, bindings.relayChats || []);
		backupDaily("telegram-bindings", bindings);
		backupDaily("telegram-relay-chats", bindings.relayChats || []);
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids-verified.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var LOCALES_PATH = join(DATA_DIR, "telegram-locales.json");
var userLocales = {};
try {
	if (existsSync(LOCALES_PATH)) {
		const raw = JSON.parse(readFileSync(LOCALES_PATH, "utf8"));
		for (const [id, value] of Object.entries(raw || {})) if (isLocale(value)) userLocales[id] = value;
	}
} catch {
	userLocales = {};
}
function saveLocales() {
	try {
		writeJsonAtomic(LOCALES_PATH, userLocales);
	} catch {}
}
function langOf(userId) {
	return userLocales[String(userId || "")] === "en" ? "en" : "ru";
}
function hasLang(userId) {
	return isLocale(userLocales[String(userId || "")]);
}
function setLang(userId, locale) {
	userLocales[String(userId)] = locale;
	saveLocales();
}
function saveUserLocaleServer(userId, locale) {
	if (!isLocale(locale)) return;
	setLang(userId, locale);
}
function btUser(userId, key, vars) {
	return tb(langOf(userId), key, vars);
}
var idCache = {};
var legacyIds = {};
var pendingPosts = {};
legacyIds = readJson(join(DATA_DIR, "telegram-ids.json")) || {};
idCache = {
	...KNOWN_TELEGRAM_IDS,
	...readJson(ID_CACHE_PATH) || {}
};
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
for (const rec of Object.values(pendingPosts)) if (rec.status === "published" && rec.channelPosted === void 0) rec.channelPosted = true;
var BLACKLIST_CLEANUP = [
	"hugos",
	"mkcrd",
	"annuit1",
	"ballin812"
];
var BLACKLIST_CLEANUP_STAMP = "cleanup-v2";
if (bindings.blacklistCleanupStamp !== BLACKLIST_CLEANUP_STAMP) {
	let changed = false;
	for (const rec of Object.values(pendingPosts)) {
		if (rec.removedFromCheck) continue;
		if (pendingAccounts(rec).map((a) => a.username.replace(/^@/, "").toLowerCase()).some((n) => BLACKLIST_CLEANUP.includes(n))) {
			rec.removedFromCheck = true;
			changed = true;
		}
	}
	if (changed) savePending();
	bindings.blacklistCleanupStamp = BLACKLIST_CLEANUP_STAMP;
	saveBindings();
}
var FINDS_CLEANUP_STAMP = "finds-v1";
if (bindings.findsCleanupStamp !== FINDS_CLEANUP_STAMP) {
	if (bindings.recentFinds?.length) bindings.recentFinds = [];
	bindings.findsCleanupStamp = FINDS_CLEANUP_STAMP;
	saveBindings();
}
var idCacheTimer = null;
function saveIdCache() {
	if (idCacheTimer) return;
	idCacheTimer = setTimeout(() => {
		idCacheTimer = null;
		try {
			writeJsonAtomic(ID_CACHE_PATH, idCache);
		} catch {}
	}, 2e3);
}
function savePending() {
	try {
		const entries = Object.entries(pendingPosts);
		if (entries.length > 1200) {
			const drop = entries.filter(([, rec]) => rec.status === "published" || rec.status === "rejected").sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
			const extra = entries.length - 1e3;
			for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
		}
		writeJsonAtomic(PENDING_PATH, pendingPosts);
	} catch {}
}
function rememberUser(user) {
	if (!user?.id || !user.username) return;
	rememberHandle(user.username, String(user.id));
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	const keys = Object.keys(idCache);
	if (keys.length > 8e3) for (const extra of keys.slice(0, keys.length - 7e3)) delete idCache[extra];
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
var MAX_EVIDENCE_FILE = 1073741824;
var MAX_EVIDENCE_CHUNK = 2097152;
function sanitizeEvidenceId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9_-]/g, "");
	if (!safe || safe.length < 8 || safe.length > 80) return null;
	if (safe === ".." || safe.startsWith(".")) return null;
	return safe;
}
function evidenceOwnerPath(id) {
	return join(EVIDENCE_DIR, `${id}.own`);
}
function writeEvidenceOwner(id, userId) {
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(evidenceOwnerPath(id), String(userId || ""));
}
function readEvidenceOwner(id) {
	try {
		return readFileSync(evidenceOwnerPath(id), "utf8").trim();
	} catch {
		return "";
	}
}
function evidenceOwnedBy(id, userId) {
	const safe = sanitizeEvidenceId(id || "");
	if (!safe || !userId) return false;
	return readEvidenceOwner(safe) === userId && Boolean(uploadedEvidencePath(safe));
}
function evidenceHmacKey() {
	return createHmac("sha256", "EvidenceGet").update(botToken() || "none").digest();
}
function evidenceSig(key, exp) {
	return createHmac("sha256", evidenceHmacKey()).update(`${key}.${exp}`).digest("hex").slice(0, 32);
}
function verifyEvidenceDownload(key, exp, sig) {
	const safe = sanitizeEvidenceId(key);
	if (!safe) return false;
	const expMs = Number(exp);
	if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
	if (expMs > Date.now() + 1728e5) return false;
	const expect = evidenceSig(safe, expMs);
	const a = Buffer.from(expect, "hex");
	const b = Buffer.from(String(sig || ""), "hex");
	if (a.length !== b.length || a.length === 0) return false;
	return timingSafeEqual(a, b);
}
function isAllowedEvidenceMagic(bytes) {
	if (!bytes.length) return false;
	const head = bytes.subarray(0, 256).toString("utf8").replace(/^\uFEFF/, "").trimStart().toLowerCase();
	if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<script") || head.startsWith("<svg") || head.startsWith("<?xml") || head.startsWith("<?php") || head.startsWith("#!") || head.startsWith("import ") || head.startsWith("function ") || head.startsWith("const ") || head.startsWith("var ") || head.startsWith("{")) return false;
	if (bytes[0] === 77 && bytes[1] === 90) return false;
	if (bytes[0] === 127 && bytes[1] === 69 && bytes[2] === 76 && bytes[3] === 70) return false;
	if (bytes[0] === 202 && bytes[1] === 254 && bytes[2] === 186 && bytes[3] === 190) return false;
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return true;
	if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) return true;
	if (bytes.length >= 6 && bytes.subarray(0, 3).toString("ascii") === "GIF") return true;
	if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && (bytes.subarray(8, 12).toString("ascii") === "WEBP" || bytes.subarray(8, 12).toString("ascii") === "AVI ")) return true;
	if (bytes.length >= 4 && bytes[0] === 26 && bytes[1] === 69 && bytes[2] === 223 && bytes[3] === 163) return true;
	if (bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp") return true;
	return false;
}
function saveUploadedEvidence(userId, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
	if (!isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const id = randomUUID();
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	writeEvidenceOwner(id, userId);
	pruneEvidenceDir();
	return id;
}
var chunkCursor = /* @__PURE__ */ new Map();
function appendEvidenceChunk(userId, requestedId, index, total, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const safe = index === 0 ? randomUUID() : sanitizeEvidenceId(requestedId);
	if (!safe) throw new Error("bad chunk");
	if (index === 0 && !isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	if (index > 0 && readEvidenceOwner(safe) !== userId) throw new Error("forbidden");
	if (index === 0) writeEvidenceOwner(safe, userId);
	const part = join(EVIDENCE_DIR, `${safe}.part`);
	const dest = join(EVIDENCE_DIR, safe);
	const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
	if (existsSync(dest) && readEvidenceOwner(safe) === userId) return safe;
	const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
	if (index < expected) return safe;
	if (index !== expected) throw new Error("chunk order");
	if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
	if (index === 0) {
		if (existsSync(part)) unlinkSync(part);
		if (existsSync(dest)) unlinkSync(dest);
	}
	if ((existsSync(part) ? statSync(part).size : 0) + bytes.length > MAX_EVIDENCE_FILE) {
		try {
			unlinkSync(part);
		} catch {}
		chunkCursor.delete(safe);
		throw new Error("file too large");
	}
	appendFileSync(part, bytes);
	const next = index + 1;
	chunkCursor.set(safe, next);
	writeFileSync(idxPath, String(next));
	if (index !== total - 1) return safe;
	if (existsSync(dest)) unlinkSync(dest);
	renameSync(part, dest);
	try {
		unlinkSync(idxPath);
	} catch {}
	chunkCursor.delete(safe);
	pruneEvidenceDir();
	return safe;
}
function evidenceBytesOnDisk(id) {
	const path = id ? uploadedEvidencePath(id) : null;
	if (!path) return 0;
	try {
		return statSync(path).size;
	} catch {
		return 0;
	}
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	if (rateHits.size > 4e3) for (const [k, hits] of rateHits) {
		const keep = hits.filter((t) => now - t < 216e5);
		if (!keep.length) rateHits.delete(k);
		else rateHits.set(k, keep);
	}
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function verifyTelegramInitData(initData) {
	if (!botToken() || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const groups = /* @__PURE__ */ new Map();
		for (const name of readdirSync(EVIDENCE_DIR)) {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			const key = name.replace(/\.(own|part|idx)$/, "");
			const group = groups.get(key) || {
				paths: [],
				mtime: 0,
				size: 0
			};
			group.paths.push(path);
			group.mtime = Math.max(group.mtime, st.mtimeMs);
			group.size += st.size;
			groups.set(key, group);
		}
		const list = [...groups.values()].sort((a, b) => a.mtime - b.mtime);
		let total = list.reduce((sum, g) => sum + g.size, 0);
		const maxBytes = 8589934592;
		const maxUploads = 400;
		const fresh = Date.now() - 18e5;
		let count = list.length;
		for (const group of list) {
			if (count <= maxUploads && total <= maxBytes) break;
			if (group.mtime > fresh) break;
			for (const path of group.paths) try {
				unlinkSync(path);
			} catch {}
			total -= group.size;
			count -= 1;
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes = 1) {
	if (bytes < 0) return {
		ok: false,
		error: "file required"
	};
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("up:global", 2e3, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowEvidenceDownload() {
	return !tooMany("evget:global", 240, 6e4);
}
function allowEvidenceChunk(initData, bytes) {
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("upchunk:global", 2e3, 6e4)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowNewComplaint(userId, storyLen) {
	const loc = langOf(userId);
	if (storyLen > 5e3) return tb(loc, "storyLong");
	if (tooMany(`app:${userId}`, 3, 216e5)) return tb(loc, "tooManyUser");
	if (tooMany("app:global", 40, 36e5)) return tb(loc, "tooManyGlobal");
	return null;
}
function readUploadedEvidence(id) {
	const path = uploadedEvidencePath(id);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
function uploadedEvidencePath(id) {
	const safe = sanitizeEvidenceId(id);
	if (!safe) return null;
	const path = join(EVIDENCE_DIR, safe);
	if (!path.startsWith(EVIDENCE_DIR)) return null;
	return existsSync(path) ? path : null;
}
var BANNER_DIR = join(DATA_DIR, "banners");
var MAX_BANNER_BYTES = 20971520;
var MAX_BANNERS = 20;
function sanitizeBannerId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9]/g, "");
	if (safe.length < 10 || safe.length > 40) return null;
	return safe;
}
function newBannerId() {
	return createHash("sha256").update(randomUUID()).digest("hex").slice(0, 24);
}
function saveBannerFile(id, bytes) {
	mkdirSync(BANNER_DIR, { recursive: true });
	writeFileSync(join(BANNER_DIR, id), bytes);
}
var SPONSOR_AVATAR_DIR = join(DATA_DIR, "sponsor-avatars");
function sanitizeAvatarKey(k) {
	const safe = String(k || "").replace(/[^a-f0-9]/g, "");
	return safe.length >= 8 && safe.length <= 64 ? safe : null;
}
function sponsorAvatarPath(key) {
	const safe = sanitizeAvatarKey(key);
	if (!safe) return null;
	const path = join(SPONSOR_AVATAR_DIR, safe);
	if (!path.startsWith(SPONSOR_AVATAR_DIR)) return null;
	return existsSync(path) ? path : null;
}
async function sponsorAvatarUrl(smallFileId) {
	if (!smallFileId) return "";
	const key = createHash("sha256").update(smallFileId).digest("hex").slice(0, 24);
	const path = join(SPONSOR_AVATAR_DIR, key);
	if (!existsSync(path)) {
		const bytes = await downloadTelegramFile(smallFileId);
		if (!bytes) return "";
		try {
			mkdirSync(SPONSOR_AVATAR_DIR, { recursive: true });
			writeFileSync(path, bytes);
		} catch {
			return "";
		}
	}
	return `/api/telegram/sponsor-avatar?a=${key}`;
}
function bannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	return (bindings.banners || []).find((b) => b.id === safe) || null;
}
function bannerFilePath(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	const path = join(BANNER_DIR, safe);
	if (!path.startsWith(BANNER_DIR)) return null;
	return existsSync(path) ? path : null;
}
function listBanners() {
	return (bindings.banners || []).map((b) => ({
		id: b.id,
		type: b.type,
		link: b.link,
		width: b.width,
		height: b.height,
		src: `/api/telegram/banner?id=${encodeURIComponent(b.id)}`
	}));
}
var sponsorsCache = null;
function invalidateSponsors() {
	sponsorsCache = null;
	statsCache = null;
}
var AUDIENCE_DEFAULT = 20178;
var statsCache = null;
async function sponsorStats() {
	if (statsCache && Date.now() - statsCache.at < 6e5) return statsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	let sum = 0;
	await Promise.all(chats.map(async (c) => {
		const n = await tgSoft("getChatMemberCount", { chat_id: c.id });
		if (typeof n === "number" && n > 0) sum += n;
	}));
	const base = typeof bindings.audienceBase === "number" ? bindings.audienceBase : AUDIENCE_DEFAULT;
	const value = {
		chats: chats.length,
		audience: Math.max(base, sum)
	};
	statsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setAudienceBase(n) {
	if (!Number.isFinite(n) || n < 0 || n > 1e9) return false;
	bindings.audienceBase = Math.round(n);
	saveBindings();
	statsCache = null;
	return true;
}
async function listSponsors() {
	if (sponsorsCache && Date.now() - sponsorsCache.at < 6e5) return sponsorsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	const value = await Promise.all(chats.map(async (c) => {
		const chat = await tgSoft("getChat", { chat_id: c.id });
		const title = chat?.title || c.title || "Чат";
		const avatar = await sponsorAvatarUrl(chat?.photo?.small_file_id);
		return {
			id: String(c.id),
			title,
			link: c.link || "",
			avatar
		};
	}));
	sponsorsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setSponsorLink(chatId, raw) {
	const relay = findRelay(chatId);
	if (!relay) return "bad";
	const text = (raw || "").trim();
	if (text === "-" || text === "—" || text === "") {
		delete relay.link;
		saveBindings();
		invalidateSponsors();
		return "cleared";
	}
	if (!(/^https:\/\/[^\s]+$/i.test(text) || /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text))) return "bad";
	relay.link = text.startsWith("http") ? text : `https://${text}`;
	saveBindings();
	invalidateSponsors();
	return "set";
}
function removeBannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return;
	bindings.banners = (bindings.banners || []).filter((b) => b.id !== safe);
	saveBindings();
	try {
		const path = join(BANNER_DIR, safe);
		if (path.startsWith(BANNER_DIR) && existsSync(path)) unlinkSync(path);
	} catch {}
}
async function downloadTelegramFile(fileId) {
	const info = await tgSoft("getFile", { file_id: fileId });
	if (!info?.file_path) return null;
	if (info.file_size && info.file_size > MAX_BANNER_BYTES) return null;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 6e4);
	try {
		const res = await fetch(`https://api.telegram.org/file/bot${requireToken()}/${info.file_path}`, { signal: ctrl.signal });
		if (!res.ok) return null;
		const bytes = Buffer.from(await res.arrayBuffer());
		if (bytes.length > MAX_BANNER_BYTES) return null;
		return bytes;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
function extractBannerMedia(msg) {
	if (msg.animation?.file_id) return {
		type: "video",
		fileId: msg.animation.file_id,
		mime: msg.animation.mime_type || "video/mp4",
		width: msg.animation.width,
		height: msg.animation.height
	};
	if (msg.video?.file_id) return {
		type: "video",
		fileId: msg.video.file_id,
		mime: msg.video.mime_type || "video/mp4",
		width: msg.video.width,
		height: msg.video.height
	};
	if (msg.photo?.length) {
		const ph = msg.photo.at(-1);
		return {
			type: "image",
			fileId: ph.file_id,
			mime: "image/jpeg",
			width: ph.width,
			height: ph.height
		};
	}
	const doc = msg.document;
	if (doc?.file_id && doc.mime_type) {
		if (doc.mime_type.startsWith("image/") && doc.mime_type !== "image/svg+xml") return {
			type: "image",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
		if (doc.mime_type.startsWith("video/")) return {
			type: "video",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
	}
	return null;
}
function normalizeBannerLink(raw) {
	const text = raw.trim();
	if (text === "-" || text === "—" || text.toLowerCase() === "нет") return "";
	if (/^https:\/\/[^\s]+$/i.test(text)) return text;
	if (/^tg:\/\/[^\s]+$/i.test(text)) return text;
	if (/^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text)) return text.startsWith("http") ? text : `https://${text}`;
	return null;
}
var TgError = class extends Error {
	code;
	retryAfter;
	migrateTo;
	constructor(json, method) {
		super(json.description || method);
		this.code = json.error_code;
		this.retryAfter = json.parameters?.retry_after;
		this.migrateTo = json.parameters?.migrate_to_chat_id ? String(json.parameters.migrate_to_chat_id) : void 0;
	}
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function tgOnce(method, body) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 45e3);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify(body),
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new TgError(json, method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
async function tg(method, body = {}) {
	let payload = body;
	for (let attempt = 0;; attempt++) try {
		return await tgOnce(method, payload);
	} catch (err) {
		if (!(err instanceof TgError) || attempt >= 3) throw err;
		if (err.migrateTo && payload.chat_id != null) {
			onChatMigrated(String(payload.chat_id), err.migrateTo);
			payload = {
				...payload,
				chat_id: err.migrateTo
			};
			continue;
		}
		if (err.code === 429 && (err.retryAfter ?? 0) <= 60) {
			await sleep(((err.retryAfter ?? 1) + 1) * 1e3);
			continue;
		}
		throw err;
	}
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function customEmojiEnabled() {
	if (typeof bindings.customEmoji === "boolean") return bindings.customEmoji;
	return process.env.EPB_CUSTOM_EMOJI === "0" ? false : true;
}
function isPrivateChat(chatId) {
	return Number(chatId) > 0;
}
function isCustomEmojiError(err) {
	return err instanceof TgError && /emoji/i.test(err.message || "");
}
function isNotModified(err) {
	return err instanceof TgError && /not modified/i.test(err.message || "");
}
async function sendCeMessage(chatId, text, extra = {}) {
	if (customEmojiEnabled() && isPrivateChat(chatId)) {
		const richText = applyCustomEmoji(text);
		const markup = extra.reply_markup;
		if (hasCustomEmoji(richText) || markupHasIconableButton(markup)) {
			const richExtra = markup ? {
				...extra,
				reply_markup: decorateButtons(markup, true)
			} : extra;
			try {
				return await tg("sendMessage", {
					chat_id: chatId,
					text: richText,
					parse_mode: "HTML",
					...richExtra
				});
			} catch (err) {
				if (!isCustomEmojiError(err)) return null;
			}
		}
	}
	return tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		...extra
	});
}
async function editCard(cb, caption, reply_markup) {
	const chatId = cb.message?.chat.id;
	const messageId = cb.message?.message_id;
	if (chatId == null || messageId == null) return;
	const isMedia = Boolean(cb.message?.photo || cb.message?.caption);
	const method = isMedia ? "editMessageCaption" : "editMessageText";
	const field = isMedia ? "caption" : "text";
	const build = (txt, markup) => ({
		chat_id: chatId,
		message_id: messageId,
		[field]: txt,
		parse_mode: "HTML",
		reply_markup: markup,
		...isMedia ? {} : { disable_web_page_preview: true }
	});
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const richText = useCe ? applyCustomEmoji(caption) : caption;
	if (useCe && (hasCustomEmoji(richText) || markupHasIconableButton(reply_markup))) try {
		await tg(method, build(richText, decorateButtons(reply_markup, true)));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
		if (!isCustomEmojiError(err)) {}
	}
	try {
		await tg(method, build(caption, reply_markup));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
	}
	await sendCeMessage(chatId, caption, { reply_markup });
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v3") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v3";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook && bindings.webhookStamp === webhookStamp()) {
		await applyMenuButton();
		return;
	}
	await registerMiniAppUrl(site);
}
function webhookStamp() {
	return createHash("sha256").update(webhookSecret()).digest("hex").slice(0, 16);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			language_code: "ru",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Open the app"
				},
				{
					command: "apply",
					description: "File a complaint in chat"
				},
				{
					command: "cancel",
					description: "Cancel the complaint"
				},
				{
					command: "lang",
					description: "Language / Язык"
				}
			],
			language_code: "en",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("deleteMyCommands", { scope: { type: "default" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
		for (const chat_id of arbiterCandidates()) await tgSoft("setMyCommands", {
			commands: [
				{
					command: "admin",
					description: "Панель управления"
				},
				{
					command: "relays",
					description: "Чаты рассылки"
				},
				{
					command: "channel",
					description: "Канал для постов"
				},
				{
					command: "id",
					description: "ID этого чата"
				}
			],
			scope: {
				type: "chat",
				chat_id
			}
		});
	}
	profileReady = true;
}
var statusCache = null;
function getBotStatus() {
	if (!statusCache || Date.now() - statusCache.at > 6e4) statusCache = {
		at: Date.now(),
		value: computeBotStatus()
	};
	return statusCache.value;
}
async function computeBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	for (const id of arbiterCandidates()) {
		if (!await chatReachable(id)) continue;
		arbiterOk = true;
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		channelOk
	};
}
var mtClient = null;
var mtIdleTimer = null;
var mtBlockedUntil = 0;
var mtMisses = /* @__PURE__ */ new Map();
var mtInflight = /* @__PURE__ */ new Map();
var MT_SESSION_PATH = join(DATA_DIR, "mtproto.session");
function mtproto() {
	if (!mtClient) {
		mtClient = (async () => {
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
			const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
			let saved = "";
			try {
				const [stamp, value] = readFileSync(MT_SESSION_PATH, "utf8").split("\n");
				if (stamp === webhookStamp() && value) saved = value.trim();
			} catch {}
			const client = new TelegramClient(new StringSession(saved), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 12,
				floodSleepThreshold: 0,
				deviceModel: "EPB",
				systemVersion: "Linux",
				appVersion: "1.0",
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.start({ botAuthToken: botToken() }), 2e4, "mtproto login timeout");
			try {
				mkdirSync(DATA_DIR, { recursive: true });
				writeFileSync(MT_SESSION_PATH, `${webhookStamp()}\n${client.session.save()}`, { mode: 384 });
			} catch {}
			return {
				client,
				Api
			};
		})();
		mtClient.catch(() => dropMtproto());
	}
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = setTimeout(() => dropMtproto(), 18e5);
	return mtClient;
}
function withTimeout(promise, ms, message) {
	let timer;
	const timeout = new Promise((_, reject) => {
		timer = setTimeout(() => reject(new Error(message)), ms);
	});
	return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function dropMtproto() {
	const pending = mtClient;
	mtClient = null;
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
function floodSeconds(err) {
	const e = err;
	if (typeof e?.seconds === "number" && e.seconds > 0) return e.seconds;
	const m = `${e?.errorMessage || ""} ${e?.message || ""}`.match(/FLOOD_WAIT_(\d+)|A wait of (\d+) seconds/);
	return m ? Number(m[1] || m[2]) : 0;
}
var USER_SESSION_PATH = join(DATA_DIR, "user-session.txt");
function userSession() {
	const env = (process.env.TELEGRAM_USER_SESSION || "").trim();
	if (env) return env;
	try {
		return readFileSync(USER_SESSION_PATH, "utf8").trim();
	} catch {
		return "";
	}
}
function hasUserbot() {
	return Boolean(userSession());
}
var userClient = null;
var userIdleTimer = null;
var userBlockedUntil = 0;
function userApiCreds() {
	return {
		apiId: Number(process.env.TELEGRAM_API_ID || bindings.userbotApi?.apiId || 0),
		apiHash: (process.env.TELEGRAM_API_HASH || bindings.userbotApi?.apiHash || "").trim()
	};
}
var OWNER_ID = "1457986905";
function isOwner(id) {
	return String(id || "") === OWNER_ID;
}
function checkEnabled() {
	if (typeof bindings.checkEnabled === "boolean") return bindings.checkEnabled;
	if (process.env.EPB_CHECK_ENABLED === "0") return false;
	return true;
}
function featuresEnabled() {
	return { check: checkEnabled() };
}
function saveUserSession(session) {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(USER_SESSION_PATH, session, { mode: 384 });
	} catch {}
}
function clearUserSession() {
	dropUserbot();
	try {
		if (existsSync(USER_SESSION_PATH)) unlinkSync(USER_SESSION_PATH);
	} catch {}
}
function userbot() {
	if (!userClient) {
		userClient = (async () => {
			const session = userSession();
			if (!session) throw new Error("no user session");
			const { apiId, apiHash } = userApiCreds();
			if (!apiId || !apiHash) throw new Error("set TELEGRAM_API_ID and TELEGRAM_API_HASH for the userbot");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 15,
				floodSleepThreshold: 0,
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.connect(), 2e4, "userbot connect timeout");
			return {
				client,
				Api
			};
		})();
		userClient.catch(() => dropUserbot());
	}
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = setTimeout(() => dropUserbot(), 12e5);
	return userClient;
}
var userEntitiesLoaded = false;
async function ensureUserEntities(client) {
	if (userEntitiesLoaded) return;
	userEntitiesLoaded = true;
	try {
		await withTimeout(client.getDialogs({ limit: 300 }), 25e3, "dialogs timeout");
		const saved = client.session?.save?.();
		if (typeof saved === "string" && saved) saveUserSession(saved);
	} catch {
		userEntitiesLoaded = false;
	}
}
async function userInputPeer(client, ref) {
	try {
		return await client.getInputEntity(ref);
	} catch {
		await ensureUserEntities(client);
		return client.getInputEntity(ref);
	}
}
function dropUserbot() {
	const pending = userClient;
	userClient = null;
	userEntitiesLoaded = false;
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
async function userbotStatus() {
	if (!userSession()) return {
		ok: false,
		error: "нет сессии"
	};
	const { apiId, apiHash } = userApiCreds();
	if (!apiId || !apiHash) return {
		ok: false,
		error: "нет TELEGRAM_API_ID / TELEGRAM_API_HASH"
	};
	try {
		const { client, Api } = await userbot();
		const u = (await withTimeout(client.invoke(new Api.users.GetUsers({ id: [new Api.InputUserSelf()] })), 12e3, "timeout"))?.[0];
		return {
			ok: true,
			name: u?.username ? `@${u.username}` : u?.firstName || "аккаунт"
		};
	} catch (err) {
		return {
			ok: false,
			error: err?.message || "ошибка"
		};
	}
}
async function resolveChannelAsUser(ref) {
	if (!userSession()) return null;
	try {
		const { client } = await userbot();
		const chan = await withTimeout(client.getInputEntity(ref), 12e3, "timeout");
		if (!chan?.channelId) return null;
		const id = `-100${chan.channelId.toString()}`;
		const full = await client.getEntity(ref).catch(() => null);
		return {
			id,
			title: full?.title,
			username: full?.username,
			addedAt: Date.now()
		};
	} catch {
		return null;
	}
}
function snippetAround(text, needle) {
	const flat = text.replace(/\s+/g, " ").trim();
	if (!needle) return flat.slice(0, 180);
	const i = flat.toLowerCase().indexOf(needle.toLowerCase());
	if (i < 0) return flat.slice(0, 180);
	const from = Math.max(0, i - 60);
	return (from > 0 ? "…" : "") + flat.slice(from, from + 180).trim() + (from + 180 < flat.length ? "…" : "");
}
var deletedCache = /* @__PURE__ */ new Map();
async function channelPostDeleted(rec) {
	if (!userSession() || Date.now() < userBlockedUntil) return false;
	const ids = rec.channelMsgIds || [];
	const chat = rec.channelChatId || bindings.channelId || "";
	if (!ids.length || !chat) return false;
	const cacheKey = `${chat}:${ids.join(",")}`;
	const cached = deletedCache.get(cacheKey);
	if (cached && Date.now() - cached.at < 3e5) return cached.deleted;
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, chat);
		const deleted = !(await withTimeout(client.getMessages(peer, { ids }), 12e3, "getMessages timeout") || []).some((m) => m && m.id && m.className !== "MessageEmpty");
		deletedCache.set(cacheKey, {
			at: Date.now(),
			deleted
		});
		return deleted;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) userBlockedUntil = Date.now() + (wait + 5) * 1e3;
		else if (!err?.errorMessage) dropUserbot();
		return false;
	}
}
function channelRef(channel) {
	if (channel.username) return `@${channel.username.replace(/^@/, "")}`;
	const n = Number(channel.id);
	return Number.isSafeInteger(n) ? n : channel.id;
}
async function serverSearch(client, peer, query) {
	return await withTimeout(client.getMessages(peer, {
		search: searchQueryFor(query),
		limit: 60
	}), 15e3, "search timeout") || [];
}
async function scanRecent(client, peer, limit = 800) {
	return await withTimeout(client.getMessages(peer, { limit }), 45e3, "scan timeout") || [];
}
var scanCache = /* @__PURE__ */ new Map();
var SCAN_TTL = 12e4;
async function scanRecentCached(client, peer, channelKey) {
	const hit = scanCache.get(channelKey);
	if (hit && Date.now() - hit.at < SCAN_TTL) return hit.msgs;
	const msgs = await scanRecent(client, peer);
	scanCache.set(channelKey, {
		at: Date.now(),
		msgs
	});
	return msgs;
}
function searchQueryFor(raw) {
	return raw.replace(/[^\p{L}\p{N}]+/gu, " ").trim() || raw;
}
function escapeRe(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
var NON_ACCUSATION_LINE_RE = /(оспор|обжал|по\s*(всем\s*)?вопрос|для\s*связ|связ[ьи]|контакт|админ|administrator|\badmin\b|support|поддержк|dispute|appeal|помощ|реклам|сотруднич|менеджер|гарант|куп(лю|ить)|прод(ам|аж|ать)|прайс|услуг|сервис|магазин|\bshop\b|подписк|вступай|вступить|присоединя|заказать|скидк|акци|цен[аы])/iu;
var ACCUSED_LABEL_RE = /^(?:[📛🚫❌🤡⚠🔴🛑‼️\s])*(?:ответчик|обвиняем\w*|скамер|кидал\w*|мошенник|виновник|respondent|defendant)\s*:?\s*$/iu;
function isStrictChannel(channel) {
	return /wwh/i.test(channel.title || "") || /wwh/i.test(channel.username || "");
}
var IGNORE_USERNAMES = /* @__PURE__ */ new Set([
	"europepromo",
	"ctoroot",
	"sbepbank",
	BOT_USERNAME.toLowerCase()
]);
function isIgnoredHandle(uname) {
	return IGNORE_USERNAMES.has((uname || "").replace(/^@/, "").toLowerCase());
}
function usernameOnLine(line, uname) {
	if (!uname) return false;
	return new RegExp("@?(?<!\\w)" + escapeRe(uname) + "(?!\\w)", "iu").test(line);
}
function idOnLine(line, id) {
	const digits = (id || "").replace(/\D/g, "");
	if (digits.length < 5) return false;
	return new RegExp("(?<!\\d)" + digits + "(?!\\d)").test(line);
}
function arbitrationAccused(line, strict = false) {
	const marker = strict ? "(?:пользовател\\S*\\s+|юзер\\S*\\s+|user\\s+|@)" : "(?:пользовател\\S*\\s+|юзер\\S*\\s+|человек\\S*\\s+|аккаунт\\S*\\s+|user\\s+|@)?";
	const m = line.match(new RegExp("(?:^|\\s)(?:на|против|on|against)\\s+" + marker + "(.+)$", "i"));
	if (!m) return "";
	return m[1].split(/\s+(?:от|from|by|заявител\S*|подал\S*|reporter)\s+/i)[0] || "";
}
function postMatchesSubject(body, username, id, strict = false) {
	const uname = (username || "").replace(/^@/, "").toLowerCase();
	const ignoredName = !uname || IGNORE_USERNAMES.has(uname);
	if (ignoredName && !id) return false;
	let labelAbove = false;
	for (const line of body.split(/\r?\n/)) {
		if (/арбитраж|arbitr/i.test(line)) {
			const accused = arbitrationAccused(line, strict);
			if (accused && (!ignoredName && usernameOnLine(accused, uname) || idOnLine(accused, id))) return true;
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		const hasId = idOnLine(line, id);
		const hasU = !ignoredName && usernameOnLine(line, uname);
		if (!hasId && !hasU) {
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		let rest = line;
		if (uname) rest = rest.replace(new RegExp("@?" + escapeRe(uname), "ig"), " ");
		const idDigits = (id || "").replace(/\D/g, "");
		if (idDigits.length >= 5) rest = rest.replace(new RegExp(idDigits, "g"), " ");
		if (!NON_ACCUSATION_LINE_RE.test(rest)) {
			if (!strict) return true;
			if (labelAbove) return true;
		}
		if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
	}
	return false;
}
async function userSearchChannel(channel, query, subject) {
	if (Date.now() < userBlockedUntil) return [];
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(channel));
		const strict = isStrictChannel(channel);
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, query)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(channel.id))) if (m.id) byId.set(m.id, m);
		const out = [];
		for (const m of byId.values()) {
			const body = m.message || "";
			if (!m.id || !body || !postMatchesSubject(body, subject.username, subject.id, strict)) continue;
			out.push({
				channelId: channel.id,
				channelTitle: channel.title || "канал",
				messageId: m.id,
				link: messageLink(channel, m.id),
				date: (m.date || 0) * 1e3,
				snippet: snippetAround(body, subject.username || subject.id)
			});
		}
		return out;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) {
			userBlockedUntil = Date.now() + (wait + 5) * 1e3;
			console.warn(`[epb] userbot FLOOD_WAIT ${wait}s`);
		} else if (!err?.errorMessage) dropUserbot();
		return [];
	}
}
async function diagnoseUserSearch(input) {
	const parsed = parseTelegramInput(input);
	const uname = parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const q = uname || id;
	if (!q) return "Укажите @username или ID для проверки.";
	if (!hasUserbot()) return "Юзербот не подключён (нет сессии). Подключите: /userbot.";
	const channels = checkChannels();
	if (!channels.length) return "Не выбрано ни одного канала для поиска. Выберите: /userbot → каналы.";
	const st = await userbotStatus();
	if (!st.ok) return `Аккаунт не отвечает: ${st.error || "ошибка"}`;
	let resolvedId = id;
	if (uname && !resolvedId) {
		const r = await resolveUsernameMtproto(uname, "");
		if (r && r !== "busy" && r.id) resolvedId = r.id;
	}
	const idDigits = (resolvedId || "").replace(/\D/g, "");
	const mentions = (body) => uname && body.toLowerCase().includes(uname) || idDigits.length >= 5 && body.includes(idDigits);
	const lines = [`Аккаунт: ${st.name || "ок"}. Каналов: ${channels.length}. Ищу «${q}»${resolvedId && resolvedId !== q ? ` (id ${resolvedId})` : ""}…`];
	let total = 0;
	for (const ch of channels) try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(ch));
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, q)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(ch.id))) if (m.id) byId.set(m.id, m);
		const msgs = [...byId.values()];
		const strict = isStrictChannel(ch);
		const mentioned = msgs.filter((m) => m.id && mentions(m.message || ""));
		const relevant = msgs.filter((m) => m.id && postMatchesSubject(m.message || "", uname, resolvedId, strict));
		total += relevant.length;
		lines.push(`• ${ch.title || ch.username || ch.id}: просмотрено ${msgs.length}, упомянут ${mentioned.length}, в тему ${relevant.length}`);
	} catch (err) {
		lines.push(`• ${ch.title || ch.username || ch.id}: ошибка — ${err?.message || String(err)}`);
	}
	lines.push(`Итого по делу: ${total}.`);
	return lines.join("\n");
}
async function resolveUsernameMtproto(username, userId = "") {
	const key = username.toLowerCase();
	if (!botToken()) return null;
	if (Date.now() < mtBlockedUntil) return "busy";
	if (Date.now() - (mtMisses.get(key) || 0) < 18e5) return null;
	const running = mtInflight.get(key);
	if (running) return running;
	if (userId && tooMany(`mtproto:user:${userId}`, 8, 6e4)) return "busy";
	if (tooMany("mtproto:resolve", 30, 6e4) || tooMany("mtproto:resolve:h", 400, 36e5)) return "busy";
	const job = (async () => {
		try {
			const ask = async () => {
				const { client, Api } = await mtproto();
				if (client.connected === false) throw new Error("mtproto disconnected");
				return withTimeout(client.invoke(new Api.contacts.ResolveUsername({ username })), 1e4, "mtproto request timeout");
			};
			let raw;
			try {
				raw = await ask();
			} catch (err) {
				if (err?.errorMessage || floodSeconds(err)) throw err;
				dropMtproto();
				raw = await ask();
			}
			const result = raw;
			const user = result.users?.[0];
			const id = String(user?.id ?? result.peer?.userId ?? "");
			if (!/^\d{5,15}$/.test(id)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			return {
				username: user?.username || username,
				id
			};
		} catch (err) {
			const wait = floodSeconds(err);
			if (wait) {
				mtBlockedUntil = Date.now() + (wait + 5) * 1e3;
				console.warn(`[epb] MTProto FLOOD_WAIT ${wait}s, lookups paused`);
				return "busy";
			}
			const rpc = err?.errorMessage;
			if (rpc && /USERNAME_(NOT_OCCUPIED|INVALID)/.test(rpc)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			if (!rpc) dropMtproto();
			return null;
		} finally {
			mtInflight.delete(key);
			if (mtMisses.size > 5e3) mtMisses.clear();
		}
	})();
	mtInflight.set(key, job);
	return job;
}
async function lookupVerifiedId(username, userId = "") {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key) return null;
	const cached = idCache[key];
	if (cached) return {
		username,
		id: cached
	};
	const chat = await tgSoft("getChat", { chat_id: `@${key}` });
	if (chat?.id) {
		rememberHandle(chat.username || username, String(chat.id));
		return {
			username: chat.username || username,
			id: String(chat.id)
		};
	}
	const mt = await resolveUsernameMtproto(key, userId);
	if (mt && mt !== "busy" && mt.id) {
		rememberHandle(mt.username, mt.id);
		return mt;
	}
	return mt === "busy" ? "busy" : null;
}
async function verifyAccountPair(username, id) {
	const handle = username.replace(/^@/, "").trim();
	if (!handle || !id) return { check: "unknown" };
	const found = await lookupVerifiedId(handle);
	if (!found || found === "busy") return { check: "unknown" };
	return found.id === id ? { check: "ok" } : {
		check: "mismatch",
		realId: found.id
	};
}
async function resolveHandleServer(input, userId = "") {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (tooMany("resolve:global", 80, 6e4)) {
		const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
		if (cached && (!parsed.id || cached === parsed.id)) return {
			username: parsed.username,
			id: cached,
			source: "telegram"
		};
		return {
			username: parsed.username,
			id: parsed.id,
			source: parsed.id ? "parsed" : "unresolved"
		};
	}
	if (parsed.id) {
		if (parsed.username) {
			const pair = await verifyAccountPair(parsed.username, parsed.id);
			if (pair.check === "mismatch" && pair.realId) return {
				username: parsed.username,
				id: pair.realId,
				source: "telegram"
			};
			return {
				username: parsed.username,
				id: parsed.id,
				source: pair.check === "ok" ? "telegram" : "parsed"
			};
		}
		const chat = await tgSoft("getChat", { chat_id: parsed.id });
		if (chat?.username) rememberHandle(chat.username, parsed.id);
		return {
			username: chat?.username || "",
			id: parsed.id,
			source: chat?.username ? "telegram" : "parsed"
		};
	}
	const username = parsed.username;
	const found = await lookupVerifiedId(username, userId);
	if (found && found !== "busy") return {
		username: found.username,
		id: found.id,
		source: "telegram"
	};
	const legacy = legacyIds[username.toLowerCase()];
	if (legacy) return {
		username,
		id: legacy,
		source: "parsed"
	};
	return {
		username,
		id: "",
		source: "unresolved",
		busy: found === "busy"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function previousPosts(accounts, exceptKey = "") {
	const ids = new Set(accounts.map((a) => a.id || a.telegramId || "").filter(Boolean));
	const names = new Set(accounts.map((a) => (a.username || "").replace(/^@/, "").toLowerCase()).filter(Boolean));
	const hits = Object.entries(pendingPosts).filter(([key, rec]) => key !== exceptKey && rec.status === "published").filter(([, rec]) => pendingAccounts(rec).some((a) => a.id && ids.has(a.id) || a.username && names.has(a.username.replace(/^@/, "").toLowerCase()))).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
	if (!hits.length) return "";
	return `⚠️ По этому аккаунту уже был пост: ${hits.slice(0, 3).map(([key, rec]) => `${escapeHtml(key)} (${new Date(rec.createdAt || 0).toLocaleDateString("ru-RU")})`).join(", ")}${hits.length > 3 ? ` и ещё ${hits.length - 3}` : ""}`;
}
function accountCheckHtml(a) {
	if (!a.username) return "❔ указан только ID, проверить по username нельзя";
	if (a.check === "ok") return "✅ username и ID совпадают (проверено в Telegram)";
	if (a.check === "mismatch") return `⚠️ Заявитель указал чужой ID <code>${escapeHtml(a.claimedId || "?")}</code> — заменён на настоящий ID @${escapeHtml(a.username.replace(/^@/, ""))}`;
	return "❔ связку username и ID проверить не удалось";
}
function applicationBriefHtml(app) {
	const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
	const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const accounts = scammerAccounts(app);
	const scammer = accounts.map((a) => `${formatAccountLine(a.username, a.telegramId, true)}\n${accountCheckHtml(a)}`).join("\n");
	const brief = (app.summary || app.story).trim();
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		...previousPosts(accounts) ? [previousPosts(accounts)] : [],
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(brief)}`
	].join("\n");
}
function applicationDetailHtml(app) {
	const detail = app.story.trim();
	const brief = (app.summary || "").trim();
	if (!detail || detail === brief) return "";
	return `<b>Подробно</b>\n${escapeHtml(detail)}`;
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	const multi = accounts.length > 1;
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const name = handle ? `@${escapeHtml(handle)}` : "";
		const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
		const last = i === accounts.length - 1;
		if (multi) {
			const head = [name, id].filter(Boolean).join(" ");
			if (!last) return `${head} ;`;
			return scam ? `${head} - ${scam}` : head;
		}
		if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
		return [name, id].filter(Boolean).join("\n");
	});
}
function channelHtml(accounts, story, amount = "", currency = "", bodyHtml = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		bodyHtml.trim() || escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const scamLine = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	return [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`
	].join("\n").slice(0, 1024);
}
function splitHtml(html, max = 4090) {
	if (html.length <= max) return [html];
	const tokens = html.match(/<[^>]*>|&[#a-zA-Z0-9]+;|[\s\S]/g) || [];
	const parts = [];
	const closers = (stack) => stack.map((t) => `</${t.name}>`).reverse().join("");
	const openers = (stack) => stack.map((t) => t.tag).join("");
	let stack = [];
	let cur = "";
	let lastNl = null;
	let lastSpace = null;
	for (let i = 0; i < tokens.length; i++) {
		const token = tokens[i];
		if (cur.length + token.length + closers(stack).length > max && cur.trim()) {
			const lastBreak = lastNl && lastNl.at > max / 3 ? lastNl : lastSpace && lastSpace.at > max / 3 ? lastSpace : null;
			lastNl = null;
			lastSpace = null;
			if (lastBreak) {
				parts.push(cur.slice(0, lastBreak.at) + closers(lastBreak.stack));
				stack = [...lastBreak.stack];
				cur = openers(stack);
				i = lastBreak.next - 1;
				continue;
			}
			parts.push(cur + closers(stack));
			cur = openers(stack);
		}
		const tag = token.match(/^<(\/)?([a-zA-Z0-9-]+)/);
		if (tag) {
			const name = tag[2].toLowerCase();
			if (tag[1]) {
				const idx = stack.map((t) => t.name).lastIndexOf(name);
				if (idx >= 0) stack = stack.slice(0, idx);
			} else if (!token.endsWith("/>")) stack = [...stack, {
				name,
				tag: token
			}];
		}
		cur += token;
		if (token === "\n") lastNl = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
		else if (token === " ") lastSpace = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
	}
	if (cur.replace(/<[^>]*>/g, "").trim()) parts.push(cur);
	return parts.map((p) => p.replace(/^\n+/, ""));
}
function reviewKeyboard(appId = "") {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: appId ? `pub:${appId}` : "pub"
	}, {
		text: "Отклонить",
		callback_data: appId ? `rej:${appId}` : "rej"
	}]] };
}
function publishChoiceKeyboard(key = "") {
	const suffix = key ? `:${key}` : "";
	const rows = [[{
		text: "Опубликовать с рассылкой",
		callback_data: `puball${suffix}`.slice(0, 64)
	}], [{
		text: "Опубликовать без рассылки",
		callback_data: `pubch${suffix}`.slice(0, 64)
	}]];
	if (key && pendingPosts[key]) {
		rows.push([{
			text: "✏ Изменить текст",
			callback_data: `pedit:${key}`
		}, {
			text: "👁 Предпросмотр",
			callback_data: `pview:${key}`
		}]);
		if (pendingPosts[key].postHtml) rows.push([{
			text: "↩ Вернуть исходный текст",
			callback_data: `porig:${key}`
		}]);
	}
	return { inline_keyboard: rows };
}
async function tgForm(method, form) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 12e4);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			body: form,
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new Error(json.description || method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
var TG_UPLOAD_MAX = 51380224;
function mediaSize(file) {
	return file.size || evidenceBytesOnDisk(file.storageKey);
}
function evidencePublicUrl(storageKey) {
	if (!storageKey || !sanitizeEvidenceId(storageKey)) return "";
	const site = publicSiteUrl();
	if (!site) return "";
	const exp = Date.now() + 864e5;
	const sig = evidenceSig(storageKey, exp);
	return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}&exp=${exp}&sig=${sig}`;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const size = mediaSize(file);
	if (file.kind === "video" && size > TG_UPLOAD_MAX) return sendLargeVideo(chatId, file, opts);
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	if (blob.size > TG_UPLOAD_MAX && file.kind === "video") return sendLargeVideo(chatId, file, opts);
	const form = new FormData();
	form.set("chat_id", String(chatId));
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
async function sendLargeVideo(chatId, file, opts = {}) {
	const url = evidencePublicUrl(file.storageKey);
	const extra = { chat_id: chatId };
	if (opts.caption) {
		extra.caption = opts.caption;
		extra.parse_mode = "HTML";
	}
	if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
	if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
	if (url) {
		const video = await tgSoft("sendVideo", {
			...extra,
			video: url,
			supports_streaming: true
		});
		if (video) return {
			...video,
			fileId: video.video?.file_id,
			kind: "video"
		};
		const doc = await tgSoft("sendDocument", {
			...extra,
			document: url
		});
		if (doc) return {
			message_id: doc.message_id,
			chat: doc.chat,
			fileId: doc.document?.file_id,
			kind: "video"
		};
	}
	const link = url || file.name || "видео";
	return {
		...await tg("sendMessage", {
			chat_id: chatId,
			text: [
				opts.caption,
				`Видео: ${escapeHtml(file.name || "файл")}`,
				url ? `<a href="${url}">скачать</a>` : link
			].filter(Boolean).join("\n"),
			parse_mode: "HTML",
			disable_web_page_preview: false,
			reply_markup: opts.replyMarkup,
			reply_to_message_id: opts.replyTo
		}),
		kind: "video"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		summary: app.summary || "",
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? btUser(chatId, "pendingNotice", {
			id: appId,
			scam
		}) : kind === "published" ? btUser(chatId, "publishedNotice", {
			id: appId,
			scam
		}) : btUser(chatId, "rejectedNotice", {
			id: appId,
			scam
		}),
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
var loginStates = /* @__PURE__ */ new Map();
function ownerLoginActive(chatId) {
	const st = loginStates.get(String(chatId));
	if (!st) return false;
	if (Date.now() - st.touched > 6e5) {
		st.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(chatId));
		return false;
	}
	return true;
}
async function sendOwnerPanel(chatId) {
	const st = await userbotStatus();
	const connected = st.ok;
	const channels = checkChannels();
	const rows = [];
	if (connected) {
		rows.push([{
			text: "📡 Выбрать каналы для поиска",
			callback_data: "ub:chans"
		}]);
		rows.push([{
			text: "🔌 Переподключить аккаунт",
			callback_data: "ub:connect"
		}]);
		rows.push([{
			text: "❌ Отключить аккаунт",
			callback_data: "ub:off"
		}]);
	} else rows.push([{
		text: "➕ Подключить аккаунт",
		callback_data: "ub:connect"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Юзербот для поиска по блеклистам</b>",
			connected ? `Аккаунт: ${escapeHtml(st.name || "подключён")} ✅` : "Аккаунт не подключён",
			`Каналов выбрано для поиска: ${channels.length}`,
			"",
			connected ? "Поиск в мини-приложении идёт по выложенным жалобам EPB и по выбранным каналам (через аккаунт, по username, включая старые посты)." : "Подключите свой аккаунт Telegram, затем выберите каналы, по которым искать. Понадобятся api_id и api_hash с my.telegram.org."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
}
async function startOwnerLogin(chatId) {
	const existing = loginStates.get(String(chatId));
	if (existing?.client) await existing.client.disconnect?.().catch(() => {});
	loginStates.set(String(chatId), {
		step: "apiId",
		touched: Date.now()
	});
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Подключение аккаунта</b>",
			"",
			"Нужны api_id и api_hash: зайдите на https://my.telegram.org → API development tools.",
			"",
			"Пришлите <b>api_id</b> (число).",
			"Отмена: /cancel_userbot"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function handleOwnerLogin(chatId, text) {
	const key = String(chatId);
	const st = loginStates.get(key);
	if (!st) return false;
	st.touched = Date.now();
	const value = text.trim();
	const fail = async (msg) => {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: msg
		});
	};
	try {
		if (st.step === "apiId") {
			const n = Number(value);
			if (!n || !Number.isInteger(n)) return await fail("api_id — это число. Пришлите ещё раз."), true;
			st.apiId = n;
			st.step = "apiHash";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Теперь пришлите <b>api_hash</b>.",
				parse_mode: "HTML"
			});
			return true;
		}
		if (st.step === "apiHash") {
			if (!/^[a-f0-9]{16,}$/i.test(value)) return await fail("Похоже, это не api_hash. Пришлите ещё раз."), true;
			st.apiHash = value;
			st.step = "phone";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Пришлите номер телефона аккаунта в формате +7999…"
			});
			return true;
		}
		if (st.step === "phone") {
			if (!/^\+?\d{7,15}$/.test(value.replace(/\s/g, ""))) return await fail("Неверный номер. Пример: +79991234567"), true;
			st.phone = value.replace(/\s/g, "");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			st.client = new TelegramClient(new StringSession(""), st.apiId, st.apiHash, {
				connectionRetries: 2,
				baseLogger: new Logger("none")
			});
			st.Api = Api;
			await withTimeout(st.client.connect(), 25e3, "connect timeout");
			st.phoneCodeHash = (await withTimeout(st.client.sendCode({
				apiId: st.apiId,
				apiHash: st.apiHash
			}, st.phone), 25e3, "sendCode timeout")).phoneCodeHash;
			st.step = "code";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Код отправлен в Telegram на этот аккаунт. Пришлите код. Если боитесь, что Telegram заблокирует код в сообщении — вставьте пробелы: 1 2 3 4 5."
			});
			return true;
		}
		if (st.step === "code") {
			const code = value.replace(/\D/g, "");
			if (!code) return await fail("Пришлите код из Telegram."), true;
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.SignIn({
					phoneNumber: st.phone,
					phoneCodeHash: st.phoneCodeHash,
					phoneCode: code
				})), 25e3, "signin timeout");
			} catch (err) {
				const m = err?.errorMessage || err?.message || "";
				if (/SESSION_PASSWORD_NEEDED/.test(m)) {
					st.step = "password";
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "На аккаунте включена двухфакторная защита. Пришлите пароль."
					});
					return true;
				}
				if (/PHONE_CODE_INVALID|PHONE_CODE_EXPIRED/.test(m)) return await fail("Код неверный или просрочен. Пришлите ещё раз, либо начните заново: /cancel_userbot."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
		if (st.step === "password") {
			const { computeCheck } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const check = await computeCheck(await st.client.invoke(new st.Api.account.GetPassword()), value);
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.CheckPassword({ password: check })), 25e3, "password timeout");
			} catch (err) {
				const m = err?.errorMessage || "";
				if (/PASSWORD_HASH_INVALID/.test(m)) return await fail("Пароль неверный. Пришлите ещё раз."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
	} catch (err) {
		loginStates.delete(key);
		await st.client?.disconnect?.().catch(() => {});
		await fail(`Не удалось подключить аккаунт: ${err?.message || "ошибка"}. Начните заново: /userbot`);
		return true;
	}
	return true;
}
async function finishOwnerLogin(chatId, st) {
	saveUserSession(st.client.session.save());
	bindings.userbotApi = {
		apiId: st.apiId,
		apiHash: st.apiHash
	};
	saveBindings();
	await st.client.disconnect?.().catch(() => {});
	loginStates.delete(String(chatId));
	dropUserbot();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Аккаунт подключён ✅\nТеперь выберите каналы для поиска."
	});
	await sendChannelPicker(chatId);
}
async function sendChannelPicker(chatId, editMessageId) {
	const dialogs = [];
	try {
		const { client } = await userbot();
		const list = await withTimeout(client.getDialogs({ limit: 200 }), 2e4, "dialogs timeout");
		for (const d of list) {
			const e = d?.entity;
			if (!e || e.className !== "Channel") continue;
			dialogs.push({
				id: `-100${e.id?.toString?.() ?? e.id}`,
				title: d.title || e.title || "канал",
				username: e.username || void 0
			});
		}
	} catch (err) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось получить список каналов: ${err?.message || "ошибка"}`
		});
		return;
	}
	if (!dialogs.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "У аккаунта нет каналов. Подпишитесь на нужные каналы и откройте список снова: /userbot"
		});
		return;
	}
	const selected = new Set(checkChannels().map((c) => chatIdKey(c.id)));
	const rows = dialogs.slice(0, 60).map((d) => [{
		text: `${selected.has(chatIdKey(d.id)) ? "✅" : "▫️"} ${cut(d.title, 40)}`,
		callback_data: `ub:tgl:${d.id}`
	}]);
	rows.push([{
		text: "Готово",
		callback_data: "ub:done"
	}]);
	const text = "<b>Каналы для поиска</b>\nОтметьте, по каким каналам искать. Нажмите «Готово», когда закончите.";
	if (editMessageId) await tgSoft("editMessageText", {
		chat_id: chatId,
		message_id: editMessageId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	else await tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	dialogCache.clear();
	for (const d of dialogs) dialogCache.set(chatIdKey(d.id), d);
}
var dialogCache = /* @__PURE__ */ new Map();
async function toggleCheckChannel(id) {
	const list = [...checkChannels()];
	const idx = list.findIndex((c) => sameChat(c.id, id));
	if (idx >= 0) list.splice(idx, 1);
	else {
		const d = dialogCache.get(chatIdKey(id));
		list.push({
			id,
			title: d?.title,
			username: d?.username,
			addedAt: Date.now()
		});
	}
	bindings.checkChannels = list.slice(-100);
	saveBindings();
}
async function handleOwnerCallback(cb) {
	const data = cb.data || "";
	if (!data.startsWith("ub:")) return false;
	const chatId = cb.message?.chat.id;
	if (!chatId || !isOwner(cb.from?.id)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Недоступно",
			show_alert: true
		});
		return true;
	}
	const [, action, ...rest] = data.split(":");
	const answer = (t = "") => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: t || void 0
	});
	if (action === "connect") {
		await answer();
		await startOwnerLogin(chatId);
	} else if (action === "off") {
		clearUserSession();
		delete bindings.userbotApi;
		saveBindings();
		await answer("Аккаунт отключён");
		await sendOwnerPanel(chatId);
	} else if (action === "chans") {
		await answer();
		await sendChannelPicker(chatId);
	} else if (action === "tgl") {
		await toggleCheckChannel(rest.join(":"));
		await answer();
		await sendChannelPicker(chatId, cb.message.message_id);
	} else if (action === "done") {
		await answer("Сохранено");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Готово. Каналов для поиска: ${checkChannels().length}.`
		});
	} else await answer();
	return true;
}
var CHECK_INDEX_PATH = join(DATA_DIR, "telegram-check-index.json");
var checkIndex = readJson(CHECK_INDEX_PATH) || {};
var checkIndexTimer = null;
function saveCheckIndex() {
	if (checkIndexTimer) return;
	checkIndexTimer = setTimeout(() => {
		checkIndexTimer = null;
		try {
			writeJsonAtomic(CHECK_INDEX_PATH, checkIndex);
		} catch {}
	}, 3e3);
}
function checkChannels() {
	return bindings.checkChannels || [];
}
function isCheckChannel(id) {
	if (id == null) return void 0;
	return checkChannels().find((c) => sameChat(c.id, id));
}
function tokensFromText(text) {
	const usernames = /* @__PURE__ */ new Set();
	const ids = /* @__PURE__ */ new Set();
	for (const m of text.matchAll(/@([A-Za-z][A-Za-z0-9_]{3,31})/g)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/gi)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:tg:\/\/user\?id=|\bid[:\s=]*)(\d{5,15})/gi)) ids.add(m[1]);
	for (const m of text.matchAll(/\b(\d{7,15})\b/g)) ids.add(m[1]);
	return {
		usernames: [...usernames],
		ids: [...ids]
	};
}
function messageLink(channel, messageId) {
	if (channel.username) return `https://t.me/${channel.username.replace(/^@/, "")}/${messageId}`;
	return `https://t.me/c/${String(channel.id).replace(/^-100/, "").replace(/^-/, "")}/${messageId}`;
}
function addCheckHit(token, hit) {
	const list = checkIndex[token] || (checkIndex[token] = []);
	if (list.some((h) => sameChat(h.channelId, hit.channelId) && h.messageId === hit.messageId)) return;
	list.unshift(hit);
	if (list.length > 25) list.length = 25;
}
function indexCheckPost(channel, messageId, text, date) {
	const body = (text || "").slice(0, 4096);
	if (!body.trim()) return;
	const { usernames, ids } = tokensFromText(body);
	if (!usernames.length && !ids.length) return;
	const snippet = body.replace(/\s+/g, " ").trim().slice(0, 160);
	const hit = {
		channelId: String(channel.id),
		channelTitle: channel.title || "канал",
		messageId,
		link: messageLink(channel, messageId),
		date: date * 1e3 || Date.now(),
		snippet
	};
	for (const u of usernames) addCheckHit(`@${u}`, {
		...hit,
		username: u
	});
	for (const id of ids) addCheckHit(id, hit);
	const keys = Object.keys(checkIndex);
	if (keys.length > 2e5) for (const k of keys.slice(0, keys.length - 18e4)) delete checkIndex[k];
	saveCheckIndex();
}
function removeCheckChannelFromIndex(channelId) {
	for (const [token, list] of Object.entries(checkIndex)) {
		const kept = list.filter((h) => !sameChat(h.channelId, channelId));
		if (kept.length) checkIndex[token] = kept;
		else delete checkIndex[token];
	}
	saveCheckIndex();
}
var DEFAULT_MANUAL_SOURCE = "Сторонний источник";
var RECENT_FINDS_MAX = 25;
function recordFind(uname, id, display, result) {
	if (!result.channels.length) return;
	if (!uname && !id) return;
	const sources = [];
	for (const c of result.channels) {
		const title = c.channelTitle || "источник";
		const name = /wwh/i.test(title) ? "WWH" : title;
		if (!sources.includes(name)) sources.push(name);
	}
	const list = [...bindings.recentFinds || []];
	const same = (f) => uname && (f.username || "").toLowerCase() === uname || id && f.telegramId === id;
	const entry = {
		id: list.find(same)?.id || `find-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
		username: uname || void 0,
		telegramId: id || void 0,
		label: display || (uname ? `@${uname}` : `ID ${id}`),
		sources,
		at: Date.now()
	};
	bindings.recentFinds = [entry, ...list.filter((f) => !same(f))].slice(0, RECENT_FINDS_MAX);
	saveBindings();
}
function recentBlacklist(limit = 24) {
	if (!checkEnabled()) return [];
	const out = [];
	const shownKeys = /* @__PURE__ */ new Set();
	const key = (v) => (v || "").replace(/^@/, "").toLowerCase().trim();
	for (const [k, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		out.push({
			kind: "epb",
			id: k,
			account: scamLabel(rec),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
		for (const a of pendingAccounts(rec)) {
			if (a.username) shownKeys.add(key(a.username));
			if (a.id) shownKeys.add(key(a.id));
		}
	}
	for (const e of bindings.manualBlacklist || []) {
		out.push({
			kind: "manual",
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			date: e.addedAt || 0,
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note
		});
		if (e.username) shownKeys.add(key(e.username));
		if (e.telegramId) shownKeys.add(key(e.telegramId));
	}
	for (const f of bindings.recentFinds || []) {
		if (f.username && shownKeys.has(key(f.username)) || f.telegramId && shownKeys.has(key(f.telegramId))) continue;
		out.push({
			kind: "find",
			id: f.id,
			account: f.label,
			date: f.at,
			source: (f.sources || []).join(" · ")
		});
	}
	out.sort((a, b) => b.date - a.date);
	return out.slice(0, Math.max(1, limit));
}
function blacklistEntry(id) {
	if (!checkEnabled() || !id) return null;
	const rec = pendingPosts[id] || pendingPosts[id.toUpperCase()];
	if (rec && rec.status === "published" && rec.channelPosted && !rec.removedFromCheck) return {
		kind: "epb",
		id,
		account: scamLabel(rec),
		amount: rec.amount || "",
		currency: rec.currency || "",
		date: rec.createdAt || 0,
		summary: rec.summary || "",
		story: rec.story || rec.summary || ""
	};
	const man = (bindings.manualBlacklist || []).find((e) => e.id === id);
	if (man) return {
		kind: "manual",
		id,
		account: man.username ? `@${man.username.replace(/^@/, "")}` : man.telegramId ? `ID ${man.telegramId}` : "",
		date: man.addedAt || 0,
		source: man.source || DEFAULT_MANUAL_SOURCE,
		note: man.note
	};
	const find = (bindings.recentFinds || []).find((f) => f.id === id);
	if (find) return {
		kind: "find",
		id,
		account: find.label,
		date: find.at,
		source: (find.sources || []).join(" · "),
		note: "Найден по запросу проверки контрагента."
	};
	return null;
}
function matchManualBlacklist(uname, id) {
	const out = [];
	for (const e of bindings.manualBlacklist || []) {
		const eu = (e.username || "").replace(/^@/, "").toLowerCase();
		if (uname && eu === uname || id && e.telegramId === id) out.push({
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note,
			date: e.addedAt || 0
		});
	}
	return out.sort((a, b) => b.date - a.date);
}
async function checkCounterparty(input) {
	if (!checkEnabled()) return {
		query: {
			username: "",
			id: ""
		},
		epb: [],
		channels: [],
		manual: []
	};
	const parsed = parseTelegramInput(input);
	const uname = isIgnoredHandle(parsed.username) ? "" : parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const matched = [];
	for (const [key, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		const accounts = pendingAccounts(rec);
		if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) matched.push({
			key,
			rec
		});
	}
	const epb = [];
	for (const { key, rec } of matched) {
		if (await channelPostDeleted(rec)) {
			rec.removedFromCheck = true;
			savePending();
			continue;
		}
		const accounts = pendingAccounts(rec);
		epb.push({
			id: key,
			accounts: accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", "),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
	}
	epb.sort((a, b) => b.date - a.date);
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (list) => {
		for (const h of list) {
			const dkey = `${chatIdKey(h.channelId)}:${h.messageId}`;
			if (seen.has(dkey)) continue;
			seen.add(dkey);
			hits.push(h);
		}
	};
	const channels = checkChannels();
	if (hasUserbot() && channels.length) {
		let effectiveId = id;
		if (uname && !effectiveId) {
			const r = await resolveUsernameMtproto(uname, "");
			if (r && r !== "busy" && r.id) effectiveId = r.id;
		}
		const subject = {
			username: uname,
			id: effectiveId
		};
		const searchTerms = [uname, effectiveId].filter(Boolean);
		for (const channel of channels) for (const term of searchTerms) push(await userSearchChannel(channel, term, subject));
	} else for (const token of [uname ? `@${uname}` : "", id].filter(Boolean)) push(checkIndex[token] || []);
	hits.sort((a, b) => b.date - a.date);
	const result = {
		query: {
			username: uname,
			id
		},
		epb,
		channels: hits.slice(0, 30),
		manual: matchManualBlacklist(uname, id)
	};
	recordFind(uname, id, uname ? `@${parsed.username.replace(/^@/, "")}` : id ? `ID ${id}` : "", result);
	return result;
}
function allowCheck(initData) {
	if (!checkEnabled()) return {
		ok: false,
		error: "disabled"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`check:${user.id}`, 40, 6e4)) return {
		ok: false,
		error: "too many"
	};
	if (tooMany("check:global", 1500, 6e4)) return {
		ok: false,
		error: "busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function packCaption(full, _fallback = "") {
	if (full.length <= 1024) return {
		caption: full,
		leftover: ""
	};
	return {
		caption: "",
		leftover: full
	};
}
async function attachReviewButtons(chatId, messageId, leftover, keyboard) {
	if (!leftover) return (await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Опубликовать или отклонить:",
		reply_to_message_id: messageId,
		reply_markup: keyboard
	}))?.message_id || messageId;
	const parts = splitHtml(leftover);
	let lastId = messageId;
	for (let i = 0; i < parts.length; i++) {
		const sent = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: parts[i],
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_to_message_id: i === 0 ? messageId : void 0,
			reply_markup: i === parts.length - 1 ? keyboard : void 0
		});
		if (sent?.message_id) lastId = sent.message_id;
	}
	return lastId;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
function groupMedia(files) {
	const groups = [];
	let current = [];
	let currentDoc = false;
	for (const file of files) {
		const isDoc = (file.type || file.kind) === "document";
		if (current.length && (current.length >= 10 || isDoc !== currentDoc)) {
			groups.push(current);
			current = [];
		}
		currentDoc = isDoc;
		current.push(file);
	}
	if (current.length) groups.push(current);
	return groups;
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard, followUp = caption) {
	if (!files.length) {
		const parts = splitHtml(followUp);
		let lastId = 0;
		let lastChat = chatId;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id: chatId,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		return {
			chat_id: lastChat,
			message_id: lastId,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const packed = packCaption(followUp, caption);
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = { chat_id: chatId };
		if (packed.caption) {
			payload.caption = packed.caption;
			payload.parse_mode = "HTML";
		}
		if (!packed.leftover) payload.reply_markup = keyboard;
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		if (!packed.leftover) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	const packed = packCaption(followUp, caption);
	let firstId = 0;
	for (const [i, chunk] of groupMedia(files).entries()) {
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0 && packed.caption) {
				payload.caption = packed.caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard, followUp = caption) {
	const packed = packCaption(followUp, caption);
	const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
	const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
	const files = [];
	let firstId = 0;
	if (!small.length && large.length) {
		const sent = await sendMediaFile(chatId, large[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length > 1 ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		for (const extra of large.slice(1)) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && large.length === 1) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	if (small.length <= 1) {
		const sent = await sendMediaFile(chatId, small[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		firstId = sent.message_id;
		for (const extra of large) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && !large.length) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	for (let i = 0; i < small.length; i += 10) {
		const chunk = small.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 && packed.caption ? { caption: packed.caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	for (const extra of large) {
		const more = await sendMediaFile(chatId, extra);
		if (more.fileId) files.push({
			type: more.kind,
			file_id: more.fileId
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendDetail(chatId, html, replyTo) {
	for (const [i, part] of splitHtml(html).entries()) await tgSoft("sendMessage", {
		chat_id: chatId,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: i === 0 ? replyTo : void 0
	});
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const briefText = applicationBriefHtml(app);
	const detailText = applicationDetailHtml(app);
	const keyboard = reviewKeyboard(app.id);
	const blobs = app.evidence.filter((f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard, briefText) : null;
			if (sent) {
				if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard, briefText);
			if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const parts = splitHtml(briefText);
		let lastId = 0;
		let lastChat = chat_id;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		if (detailText) await sendDetail(lastChat, detailText, lastId);
		storePending(app, []);
		return {
			chat_id: lastChat,
			message_id: lastId
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const userId = app.victim.telegramId || "";
	const blocked = allowNewComplaint(userId, app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
	app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
		...file,
		name: String(file.name || "file").slice(0, 120),
		dataUrl: "",
		storageKey: evidenceOwnedBy(file.storageKey, userId) ? file.storageKey : void 0
	}));
	if (app.evidence.length > 30) return {
		ok: false,
		error: btUser(userId, "tooManyFiles")
	};
	for (const account of scammerAccounts(app).slice(0, 8)) {
		account.username = String(account.username || "").replace(/^@/, "").trim();
		account.telegramId = /^\d{5,15}$/.test(String(account.telegramId || "").trim()) ? String(account.telegramId).trim() : "";
		account.check = "unknown";
		if (account.username) {
			const found = await lookupVerifiedId(account.username);
			if (found && found !== "busy") {
				if (account.telegramId && account.telegramId !== found.id) account.claimedId = account.telegramId;
				account.telegramId = found.id;
				account.check = account.claimedId ? "mismatch" : "ok";
			}
		} else if (account.telegramId) {
			const chat = await tgSoft("getChat", { chat_id: account.telegramId });
			if (chat?.type === "private" && chat.username) {
				account.username = chat.username;
				rememberHandle(chat.username, account.telegramId);
				account.check = "ok";
			}
		}
	}
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		if (pendingPosts[app.id]) {
			pendingPosts[app.id].reviewChatId = String(sent.chat_id);
			pendingPosts[app.id].reviewMessageId = sent.message_id;
			savePending();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: btUser(userId, "addBotArbiter", { bot: BOT_USERNAME })
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseAppKey(text, data = "") {
	const fromCb = callbackKey(data);
	if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
	const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
	if (fromText?.[1]) return fromText[1];
	return parseEpbMarker(text)?.key || fromCb;
}
function stripServiceMarker(text) {
	return text.replace(/\n*#epb[^\n]*/gi, "").replace(/\n*#published[^\n]*/gi, "").replace(/\n*#rejected[^\n]*/gi, "").replace(/\n*Статус:[^\n]*/gi, "").trim();
}
function alreadyHandled(text) {
	return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
var PartialSendError = class extends Error {
	sentIds;
	answered;
	constructor(cause, sentIds) {
		super(cause instanceof Error ? cause.message : String(cause));
		this.sentIds = sentIds;
		this.answered = cause instanceof TgError;
	}
};
async function sendPostToChat(chat_id, html, files) {
	const ids = [];
	try {
		return await sendPostParts(chat_id, html, files, ids);
	} catch (err) {
		throw new PartialSendError(err, ids);
	}
}
async function sendPostParts(chat_id, html, files, ids) {
	const collect = (sent) => {
		for (const m of Array.isArray(sent) ? sent : [sent]) {
			const id = m?.message_id;
			if (id) ids.push(id);
		}
	};
	const packed = packCaption(html);
	const parts = packed.leftover ? splitHtml(packed.leftover, 4090) : [];
	if (!files.length) {
		const chunks = splitHtml(html, 4090);
		for (const part of chunks) collect(await tg("sendMessage", {
			chat_id,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: false
		}));
		return ids;
	}
	for (const [i, chunk] of groupMedia(files).entries()) {
		const firstCaption = i === 0 && packed.caption ? packed.caption : void 0;
		if (chunk.length === 1) {
			const file = chunk[0];
			const payload = {
				chat_id,
				caption: firstCaption,
				parse_mode: firstCaption ? "HTML" : void 0
			};
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			collect(await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload));
		} else collect(await tg("sendMediaGroup", {
			chat_id,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...firstCaption && idx === 0 ? {
					caption: firstCaption,
					parse_mode: "HTML"
				} : {}
			}))
		}));
	}
	for (const part of parts) collect(await tg("sendMessage", {
		chat_id,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: false
	}));
	return ids;
}
function isMissingRights(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /not enough rights|need administrator|have no rights|CHAT_WRITE_FORBIDDEN|not allowed to post|CHAT_SEND_\w+_FORBIDDEN/i.test(text);
}
function isChatGone(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /chat not found|bot was blocked|bot is not a member|kicked|chat was deactivated|group chat was upgraded/i.test(text);
}
function isGroupOrChannel(chat) {
	if (chat.type === "private") return false;
	if (chat.type === "group" || chat.type === "supergroup" || chat.type === "channel") return true;
	const id = Number(chat.id);
	return Number.isFinite(id) && id < 0;
}
function relayDestinations() {
	const skip = new Set([
		...channelCandidates(),
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId || "",
		...OFFICIAL_ARBITER_IDS
	].filter(Boolean).map((id) => chatIdKey(id)));
	const seen = /* @__PURE__ */ new Set();
	return (bindings.relayChats || []).filter((chat) => {
		const k = chatIdKey(chat.id);
		if (chat.status !== "on" || !isGroupOrChannel(chat) || skip.has(k) || seen.has(k)) return false;
		seen.add(k);
		return true;
	});
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	let lastError = "channel not found";
	for (const chat_id of ids) try {
		return {
			chatId: chat_id,
			messageIds: await sendPostToChat(chat_id, html, files)
		};
	} catch (err) {
		if (err instanceof PartialSendError && err.sentIds.length) return {
			chatId: chat_id,
			messageIds: err.sentIds,
			partialError: err.message
		};
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
var RIGHTS_NOTICE_EVERY = 864e5;
function isMediaForbidden(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /rights to send (photos|videos|documents|media|audios|voice)|CHAT_SEND_(PHOTOS|VIDEOS|MEDIA|DOCS|GIFS)_FORBIDDEN/i.test(text);
}
var BROADCAST_PATH = join(DATA_DIR, "telegram-broadcasts.json");
var broadcastJobs = readJson(BROADCAST_PATH) || [];
var migratedKeys = /* @__PURE__ */ new Map();
function saveBroadcastJobs() {
	try {
		writeJsonAtomic(BROADCAST_PATH, broadcastJobs);
	} catch {}
}
async function channelAllowsForwarding(chatId) {
	return !(await tgSoft("getChat", { chat_id: chatId }))?.has_protected_content;
}
function recordRelayDelivery(key, chatId, messageIds) {
	const ids = messageIds.filter((n) => Number.isFinite(n));
	if (!key || !ids.length) return;
	const rec = pendingPosts[key];
	if (!rec) return;
	const list = rec.relayDeliveries ||= [];
	const k = chatIdKey(chatId);
	const existing = list.find((d) => chatIdKey(d.chatId) === k);
	if (existing) {
		for (const id of ids) if (!existing.messageIds.includes(id)) existing.messageIds.push(id);
	} else list.push({
		chatId: String(chatId),
		messageIds: [...ids]
	});
	savePending();
}
async function runBroadcast(job) {
	const report = job.report;
	if (job.inflight && !job.done.includes(job.inflight)) {
		(report.unconfirmed ||= []).push(`${job.inflight}: сервер перезапустился во время отправки, повторно не отправляли`);
		report.sent += 1;
		job.done.push(job.inflight);
	}
	job.inflight = void 0;
	const done = new Set(job.done);
	const approved = relayDestinations().filter((c) => !done.has(chatIdKey(c.id)));
	report.total = Math.max(report.total, done.size + approved.length);
	let forward = Boolean(job.source?.messageIds.length) && await channelAllowsForwarding(job.source.chatId);
	if (job.source?.messageIds.length && !forward && !report.failed.some((x) => x.startsWith("пересылка"))) report.failed.push("пересылка из канала запрещена (защита контента), в чаты ушли копии");
	let forwardedOk = 0;
	let emptyInARow = 0;
	for (const chat of approved) {
		if (job.done.includes(chatIdKey(chat.id))) continue;
		const label = chat.title ? `${chat.title} (${chat.id})` : chat.id;
		job.inflight = chatIdKey(chat.id);
		saveBroadcastJobs();
		try {
			let viaForward = false;
			if (forward && job.source) {
				let result = null;
				let fwdErr = null;
				try {
					result = await tg("forwardMessages", {
						chat_id: chat.id,
						from_chat_id: job.source.chatId,
						message_ids: job.source.messageIds
					});
				} catch (err) {
					fwdErr = err;
				}
				if (!fwdErr && result && result.length >= job.source.messageIds.length) {
					viaForward = true;
					forwardedOk += 1;
					emptyInARow = 0;
					recordRelayDelivery(job.key, chat.id, result.map((m) => m?.message_id).filter((n) => typeof n === "number"));
				} else if (fwdErr instanceof TgError && /protected|CHAT_FORWARDS_RESTRICTED|message to forward not found|message can't be forwarded/i.test(fwdErr.message)) {
					forward = false;
					report.failed.push("пересылка из канала невозможна (защита контента или пост удалён), в чаты ушли копии");
				} else if (fwdErr instanceof TgError && (isChatGone(fwdErr) || isMissingRights(fwdErr) && !isMediaForbidden(fwdErr))) throw fwdErr;
				else if (fwdErr instanceof TgError && isMediaForbidden(fwdErr)) {} else {
					(report.unconfirmed ||= []).push(`${label}: ${fwdErr instanceof Error ? fwdErr.message.replace(/^Bad Request: /, "") : `переслано ${result?.length ?? 0} из ${job.source.messageIds.length}`}`);
					viaForward = true;
					if (!fwdErr && result && !result.length && !forwardedOk && ++emptyInARow >= 3) {
						forward = false;
						report.failed.push("пересылка из канала не работает (Telegram пропускает сообщения), остальным чатам ушли копии");
					}
				}
			}
			if (!viaForward) try {
				const ids = await sendPostToChat(chat.id, job.html, job.files);
				recordRelayDelivery(job.key, chat.id, ids);
				if (forward) (report.copies ||= []).push(label);
			} catch (err) {
				const refusedCleanly = err instanceof PartialSendError && err.answered && !err.sentIds.length;
				if (!job.files.length || !refusedCleanly || !isMediaForbidden(err)) throw err;
				const ids = await sendPostToChat(chat.id, job.html, []);
				recordRelayDelivery(job.key, chat.id, ids);
				(report.textOnly ||= []).push(label);
			}
			report.sent += 1;
		} catch (err) {
			if (isMissingRights(err)) {
				report.noRights.push(label);
				const relay = findRelay(chat.id);
				if (relay && Date.now() - (relay.rightsNoticeAt || 0) > RIGHTS_NOTICE_EVERY) {
					relay.rightsNoticeAt = Date.now();
					saveBindings();
					await tgSoft("sendMessage", {
						chat_id: chat.id,
						text: "Сообщение для администрации: Вы не выдали достаточно прав для отправки рассылки в Вашем чате."
					});
				}
			} else if (isChatGone(err)) report.gone.push(label);
			else {
				const noAnswer = !(err instanceof TgError) && !(err instanceof PartialSendError && err.answered) && !(err instanceof Error && err.message.startsWith("пересланы"));
				report.failed.push(noAnswer ? `${label}: Telegram не ответил (возможно, пост дошёл); повторно не отправляем, чтобы не было дублей` : `${label}: ${err instanceof Error ? err.message : String(err)}`);
			}
		}
		const k = chatIdKey(chat.id);
		job.done.push(k);
		job.inflight = void 0;
		const moved = migratedKeys.get(k);
		if (moved) job.done.push(moved);
		saveBroadcastJobs();
		await sleep(Math.max(50, 40 * ((forward ? job.source?.messageIds.length : job.files.length) || 1)));
	}
	return report;
}
async function finishBroadcast(job) {
	const report = job.report;
	bindings.lastBroadcast = {
		at: Date.now(),
		total: report.total,
		sent: report.sent,
		noRights: report.noRights.length,
		gone: report.gone.length,
		failed: report.failed.length
	};
	saveBindings();
	broadcastJobs = broadcastJobs.filter((j) => j.id !== job.id);
	saveBroadcastJobs();
	if (!job.reportTo || !report.total) return;
	await tgSoft("sendMessage", {
		chat_id: job.reportTo.chatId,
		text: broadcastReportHtml(report),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: job.reportTo.messageId
	});
}
async function deleteChatMessages(chatId, messageIds) {
	let ok = 0;
	let fail = 0;
	const ids = [...new Set(messageIds.filter((n) => Number.isFinite(n)))];
	for (let i = 0; i < ids.length; i += 100) {
		const batch = ids.slice(i, i + 100);
		if (await tgSoft("deleteMessages", {
			chat_id: chatId,
			message_ids: batch
		})) ok += batch.length;
		else for (const id of batch) if (await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: id
		})) ok += 1;
		else fail += 1;
		await sleep(40);
	}
	return {
		ok,
		fail
	};
}
async function deletePublishedEverywhere(key) {
	const channel = {
		ok: 0,
		fail: 0
	};
	const chats = {
		ok: 0,
		fail: 0
	};
	let chatCount = 0;
	const rec = pendingPosts[key];
	if (!rec) return {
		channel,
		chats,
		chatCount
	};
	if (rec.channelChatId && rec.channelMsgIds?.length) {
		const r = await deleteChatMessages(rec.channelChatId, rec.channelMsgIds);
		channel.ok += r.ok;
		channel.fail += r.fail;
	}
	for (const d of rec.relayDeliveries || []) {
		if (!d.messageIds.length) continue;
		chatCount += 1;
		const r = await deleteChatMessages(d.chatId, d.messageIds);
		chats.ok += r.ok;
		chats.fail += r.fail;
	}
	rec.deletedEverywhere = true;
	rec.channelPosted = false;
	rec.removedFromCheck = true;
	rec.relayDeliveries = [];
	rec.channelMsgIds = [];
	savePending();
	return {
		channel,
		chats,
		chatCount
	};
}
function enqueueBroadcast(job) {
	broadcastQueue = broadcastQueue.then(() => runBroadcast(job)).then(() => finishBroadcast(job)).catch((err) => console.error("[epb] broadcast", err));
}
function resumeBroadcasts() {
	const fresh = broadcastJobs.filter((j) => Date.now() - j.startedAt < 432e5);
	if (fresh.length !== broadcastJobs.length) {
		broadcastJobs = fresh;
		saveBroadcastJobs();
	}
	for (const job of fresh) {
		console.log(`[epb] resuming broadcast ${job.key}: ${job.done.length} chats already done`);
		enqueueBroadcast(job);
	}
}
function broadcastReportHtml(report) {
	const list = (items) => items.slice(0, 15).map((x) => `• ${escapeHtml(x)}`).join("\n") + (items.length > 15 ? `\n… и ещё ${items.length - 15}` : "");
	const unsure = report.unconfirmed?.length || 0;
	const lines = [`<b>Рассылка завершена</b>: доставлено ${report.sent - unsure} из ${report.total}` + (unsure ? `, без подтверждения ${unsure}` : "")];
	if (report.unconfirmed?.length) lines.push("", `<b>Telegram ответил ошибкой, но пост обычно доходит — проверьте чат, повторно не отправляли (${report.unconfirmed.length})</b>`, list(report.unconfirmed));
	if (report.copies?.length) lines.push("", `<b>Пересылка в чат не прошла, отправлено копией (${report.copies.length})</b>`, list(report.copies));
	if (report.textOnly?.length) lines.push("", `<b>В чате запрещены фото/видео, отправлен только текст (${report.textOnly.length})</b>`, list(report.textOnly));
	if (report.noRights.length) lines.push("", `<b>Нет прав (${report.noRights.length})</b>`, list(report.noRights));
	if (report.gone.length) lines.push("", `<b>Бот удалён или чат недоступен (${report.gone.length})</b>`, list(report.gone));
	if (report.failed.length) lines.push("", `<b>Ошибки (${report.failed.length})</b>`, list(report.failed));
	return lines.join("\n");
}
function entitiesToHtml(text, entities = []) {
	const tags = {
		bold: ["<b>", "</b>"],
		italic: ["<i>", "</i>"],
		underline: ["<u>", "</u>"],
		strikethrough: ["<s>", "</s>"],
		spoiler: ["<tg-spoiler>", "</tg-spoiler>"],
		code: ["<code>", "</code>"],
		pre: ["<pre>", "</pre>"],
		blockquote: ["<blockquote>", "</blockquote>"],
		expandable_blockquote: ["<blockquote expandable>", "</blockquote>"]
	};
	const opens = /* @__PURE__ */ new Map();
	const closes = /* @__PURE__ */ new Map();
	const usable = entities.filter((e) => typeof e.offset === "number" && typeof e.length === "number" && e.length > 0).filter((e) => tags[e.type] || e.type === "text_link" && /^https?:\/\//i.test(e.url || "")).sort((a, b) => a.offset - b.offset || b.length - a.length);
	for (const e of usable) {
		const [open, close] = e.type === "text_link" ? [`<a href="${escapeHtml(e.url || "")}">`, "</a>"] : tags[e.type];
		if (e.offset >= text.length) continue;
		opens.set(e.offset, [...opens.get(e.offset) || [], open]);
		const end = Math.min(e.offset + e.length, text.length);
		closes.set(end, [close, ...closes.get(end) || []]);
	}
	let out = "";
	for (let i = 0; i <= text.length; i++) {
		out += (closes.get(i) || []).join("");
		out += (opens.get(i) || []).join("");
		if (i < text.length) out += escapeHtml(text[i]);
	}
	return out;
}
var postEditPrompts = /* @__PURE__ */ new Map();
function postPreviewHtml(key) {
	const rec = pendingPosts[key];
	return channelHtml(pendingAccounts(rec), rec.summary || rec.story, rec.amount, rec.currency, rec.postHtml);
}
async function sendPostPreview(chatId, key, replyTo) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const repeat = previousPosts(pendingAccounts(rec), key);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `${`<b>Предпросмотр поста ${escapeHtml(key)}</b>${rec.postHtml ? " (текст изменён)" : ""}` + (rec.files?.length ? `\nК посту приложится доказательств: ${rec.files.length}` : "") + (repeat ? `\n${repeat}` : "")}\n━━━━━━━━━━\n${postPreviewHtml(key)}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: replyTo,
		reply_markup: publishChoiceKeyboard(key)
	});
}
async function askPostEdit(chatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			`<b>Новый текст поста ${escapeHtml(key)}</b>`,
			"",
			"Ответьте на это сообщение новым текстом. Можно жирный, курсив и ссылки.",
			"Строки с аккаунтом и суммой и подпись Subscribe бот добавит сам.",
			"",
			"Сейчас в посте:",
			rec.postHtml || escapeHtml((rec.summary || rec.story).trim())
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Новый текст поста"
		}
	});
	if (prompt?.message_id) {
		postEditPrompts.set(`${chatId}:${prompt.message_id}`, key);
		if (postEditPrompts.size > 200) postEditPrompts.delete(postEditPrompts.keys().next().value);
	}
}
async function handlePostEditReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const key = postEditPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!key) return false;
	const rec = pendingPosts[key];
	if (!rec || rec.status !== "pending") {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Заявка уже обработана, текст не изменён.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const text = (msg.text || msg.caption || "").trim();
	if (text.length < 5) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком коротко. Ответьте на сообщение бота ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	if (text.length > 3500) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком длинно: максимум 3500 символов.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const html = entitiesToHtml(msg.text || msg.caption || "", msg.entities || msg.caption_entities).trim();
	const previous = rec.postHtml;
	rec.postHtml = html;
	if (postPreviewHtml(key).length > 3900) {
		rec.postHtml = previous;
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пост получается слишком длинным для Telegram. Сократите текст и ответьте ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	savePending();
	postEditPrompts.delete(`${msg.chat.id}:${replyTo}`);
	await sendPostPreview(msg.chat.id, key, msg.message_id);
	return true;
}
var publishing = /* @__PURE__ */ new Set();
var broadcastQueue = Promise.resolve();
async function publishFromMessage(text, callbackId, extraFiles = [], relay = false, keyHint = "", reportTo) {
	const parsed = parseEpbMarker(text);
	const key = keyHint || parsed?.key || "";
	const stored = key ? pendingPosts[key] : void 0;
	if (!parsed && !stored) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	if (stored?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (stored?.status === "rejected") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Заявка уже отклонена",
			show_alert: true
		});
		return false;
	}
	const lock = key || `txt:${createHash("sha256").update(text).digest("hex").slice(0, 16)}`;
	if (!key && pendingPosts[lock]?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (publishing.has(lock)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже публикуем"
		});
		return false;
	}
	publishing.add(lock);
	const html = channelHtml(pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""), stored?.summary || stored?.story || parsed?.story || "", stored?.amount, stored?.currency, stored?.postHtml);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	let channelPost;
	try {
		channelPost = await sendChannelPost(html, files);
	} catch {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: relay ? "Не удалось опубликовать в канал. Чаты без прав пропускаются." : "Не удалось опубликовать. Бот должен быть админом канала.",
			show_alert: true
		});
		return false;
	}
	if (key && pendingPosts[key]) {
		pendingPosts[key].status = "published";
		pendingPosts[key].channelPosted = true;
		pendingPosts[key].channelChatId = channelPost.chatId;
		pendingPosts[key].channelMsgIds = channelPost.messageIds;
	} else pendingPosts[lock] = {
		username: "",
		id: "",
		story: "",
		amount: "",
		currency: "",
		files: [],
		createdAt: Date.now(),
		status: "published",
		channelPosted: true
	};
	savePending();
	if (relay) {
		const job = {
			id: randomUUID(),
			key: lock,
			html,
			files,
			source: channelPost,
			done: [],
			report: {
				total: 0,
				sent: 0,
				noRights: [],
				gone: [],
				failed: []
			},
			reportTo,
			startedAt: Date.now()
		};
		broadcastJobs.push(job);
		saveBroadcastJobs();
		enqueueBroadcast(job);
	}
	publishing.delete(lock);
	if (key && pendingPosts[key]) await notifyApplicant(pendingPosts[key], key, "published");
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: channelPost.partialError ? "Пост в канале вышел не целиком. Повторно не публикуем — проверьте канал." : relay ? "Опубликовано в канал, рассылка по чатам идёт" : "Опубликовано без рассылки",
		show_alert: Boolean(channelPost.partialError)
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
var channelSetup = /* @__PURE__ */ new Set();
var checkChannelSetup = /* @__PURE__ */ new Set();
var removeFromCheckSetup = /* @__PURE__ */ new Set();
var addBlacklistSetup = /* @__PURE__ */ new Set();
var sponsorLinkSetup = /* @__PURE__ */ new Map();
var bannerSetup = /* @__PURE__ */ new Map();
function gcSessions() {
	const now = Date.now();
	for (const [id, session] of sessions) if (now - (session.touched || 0) > 72e5) sessions.delete(id);
	if (sessions.size <= 400) return;
	const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
	for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard(locale) {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: tb(locale, "openApp"),
		web_app: { url }
	}]);
	rows.push([{
		text: tb(locale, "applyBtn"),
		callback_data: "apply"
	}]);
	if (checkEnabled()) rows.push([{
		text: tb(locale, "checkMenuBtn"),
		callback_data: "bcheck"
	}]);
	rows.push([{
		text: tb(locale, "sponsorsMenuBtn"),
		callback_data: "bsponsors"
	}]);
	rows.push([{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}, {
		text: tb(locale, "ownersBtn"),
		callback_data: "owners"
	}]);
	rows.push([{
		text: tb(locale, "langBtn"),
		callback_data: "lang"
	}]);
	return { inline_keyboard: rows };
}
var checkWait = /* @__PURE__ */ new Set();
function backToMenuKeyboard(locale) {
	return { inline_keyboard: [[{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function checkResultKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "checkMore"),
		callback_data: "bcheck"
	}], [{
		text: tb(locale, "inMenu"),
		callback_data: "home"
	}]] };
}
async function botSponsorsText(locale) {
	const list = await listSponsors().catch(() => []);
	const lines = [`<b>${tb(locale, "sponsorsMenuBtn").replace(/^\s*[^\p{L}\p{N}]+\s*/u, "")}</b>`, ""];
	if (!list.length) {
		lines.push(tb(locale, "sponsorsEmptyB"));
		return lines.join("\n");
	}
	for (const s of list.slice(0, 20)) lines.push(s.link ? `• <a href="${s.link}">${escapeHtml(s.title)}</a>` : `• ${escapeHtml(s.title)}`);
	if (list.length > 20) lines.push(`… +${list.length - 20}`);
	return lines.join("\n");
}
function formatBotCheck(locale, input, res) {
	const q = res.query.username ? `@${res.query.username}` : res.query.id ? `ID ${res.query.id}` : input.trim();
	if (!(res.epb.length || res.manual.length || res.channels.length)) return tb(locale, "checkClean", { q: escapeHtml(q) });
	const lines = [`🔎 <b>${escapeHtml(q)}</b>`, ""];
	if (res.epb.length) {
		lines.push(tb(locale, "checkEpbHdr"));
		for (const e of res.epb.slice(0, 6)) lines.push(`• ${escapeHtml(e.accounts)}${e.amount ? ` — ${escapeHtml(e.amount)} ${escapeHtml(e.currency)}` : ""}`);
		lines.push("");
	}
	for (const m of res.manual.slice(0, 6)) lines.push(`📛 ${escapeHtml(m.source)}: ${escapeHtml(m.account)}`);
	if (res.channels.length) {
		const allWwh = res.channels.every((c) => /wwh/i.test(c.channelTitle || ""));
		lines.push(allWwh ? tb(locale, "checkFoundForum") : tb(locale, "checkFoundChats"));
		for (const c of res.channels.slice(0, 8)) {
			const wwh = /wwh/i.test(c.channelTitle || "");
			const name = wwh ? "WWH" : c.channelTitle || "источник";
			lines.push(wwh ? `• ${escapeHtml(name)}` : `• <a href="${c.link}">${escapeHtml(name)}</a>`);
		}
		lines.push("");
	}
	lines.push(tb(locale, "checkDispute"));
	return lines.join("\n").slice(0, 3900);
}
async function runBotCheck(chatId, input) {
	const locale = langOf(chatId);
	await tgSoft("sendChatAction", {
		chat_id: chatId,
		action: "typing"
	});
	let res;
	try {
		res = await checkCounterparty(input);
	} catch {
		res = {
			query: {
				username: "",
				id: ""
			},
			epb: [],
			channels: [],
			manual: []
		};
	}
	await sendCeMessage(chatId, formatBotCheck(locale, input, res), {
		reply_markup: checkResultKeyboard(locale),
		disable_web_page_preview: true
	});
}
function applyCancelRow(chatId) {
	return [{
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}];
}
function startText(locale) {
	return tb(locale, "start");
}
function ownersText(locale) {
	return tb(locale, "owners", { bot: BOT_USERNAME });
}
function ownersKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}], [{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function langKeyboard(withBack = false) {
	const rows = [[{
		text: "Русский",
		callback_data: "lang:ru"
	}, {
		text: "English",
		callback_data: "lang:en"
	}]];
	if (withBack) rows.push([{
		text: "⬅️ Назад / Back",
		callback_data: "home"
	}]);
	return { inline_keyboard: rows };
}
var LANG_PROMPT = "Выберите язык / Choose language";
async function askLanguage(chatId, withBack = false) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Выберите язык / Choose language",
		reply_markup: langKeyboard(withBack)
	});
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	const candidates = [
		join(process.cwd(), "public/bot", name),
		join(process.cwd(), ".output/public/bot", name),
		join(process.cwd(), "public", name),
		join("/workspace/public/bot", name),
		join("/workspace/.output/public/bot", name)
	];
	try {
		const here = dirname(fileURLToPath(import.meta.url));
		candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
	} catch {}
	return candidates.find((p) => existsSync(p)) || null;
}
function cardBytes(kind) {
	if (kind === "welcome") try {
		return Buffer.from(WELCOME_JPEG_BASE64, "base64");
	} catch {}
	const path = cardPath(kind);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const rich = useCe ? applyCustomEmoji(caption) : caption;
	const plainMarkup = extra.reply_markup;
	const richMarkup = useCe ? decorateButtons(plainMarkup, true) : plainMarkup;
	const needsRich = useCe && (hasCustomEmoji(rich) || markupHasIconableButton(plainMarkup));
	const cap = needsRich ? rich : caption;
	const rest = (markup) => {
		const { reply_markup: _omit, ...other } = extra;
		return markup === void 0 ? other : {
			...other,
			reply_markup: markup
		};
	};
	const trySend = async (method, build) => {
		try {
			return await tg(method, build(cap, needsRich ? richMarkup : plainMarkup));
		} catch (err) {
			if (needsRich && isCustomEmojiError(err)) return await tgSoft(method, build(caption, plainMarkup));
			return null;
		}
	};
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await trySend("sendPhoto", (c, markup) => ({
			chat_id: chatId,
			photo: cached,
			caption: c,
			parse_mode: "HTML",
			...rest(markup)
		}))) return;
		if (bindings.cards) delete bindings.cards[kind];
		saveBindings();
	}
	const bytes = cardBytes(kind);
	if (bytes?.length) {
		const sendForm = (c, markup) => {
			const form = new FormData();
			form.set("chat_id", String(chatId));
			form.set("caption", c);
			form.set("parse_mode", "HTML");
			if (markup) form.set("reply_markup", JSON.stringify(markup));
			form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
			return tgForm("sendPhoto", form);
		};
		try {
			let sent;
			try {
				sent = await sendForm(cap, needsRich ? richMarkup : plainMarkup);
			} catch (err) {
				if (needsRich && isCustomEmojiError(err)) sent = await sendForm(caption, plainMarkup);
				else throw err;
			}
			const fileId = sent.photo?.at(-1)?.file_id;
			if (fileId) {
				bindings.cards = {
					...bindings.cards,
					[kind]: fileId
				};
				saveBindings();
			}
			return;
		} catch {}
	}
	await trySend("sendMessage", (c, markup) => ({
		chat_id: chatId,
		text: c,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		...rest(markup)
	}));
}
async function startCaption(locale) {
	return startText(locale);
}
async function replyStart(chatId, userId) {
	const locale = langOf(userId ?? chatId);
	await sendCard(chatId, "welcome", await startCaption(locale), { reply_markup: applyKeyboard(locale) });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		summary: "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: [],
		touched: Date.now()
	};
}
function parseAmount(text) {
	return parseDamageAmount(text);
}
function formatAmount(amount) {
	const [intPart, frac] = amount.split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return frac ? `${grouped}.${frac}` : grouped;
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session, userId) {
	if (!session.accounts.length) return btUser(userId, "emptyAccounts");
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function sendStep(chatId, text, extra = {}) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
	const sent = await sendCeMessage(chatId, text, extra);
	if (session && sent?.message_id) session.stepMsgId = sent.message_id;
	return sent;
}
function clearStepMessage(chatId, deleteIt = true) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		if (deleteIt) tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session, chatId) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: btUser(chatId, "moreAccount"),
		callback_data: "apply:more"
	}, {
		text: btUser(chatId, "next"),
		callback_data: "apply:next"
	}]);
	rows.push(applyCancelRow(chatId));
	await sendStep(chatId, session?.accounts.length ? btUser(chatId, "accountsListed", { list: listed }) : btUser(chatId, "stepAccounts"), { reply_markup: { inline_keyboard: rows } });
}
async function askSummary(chatId) {
	await sendStep(chatId, btUser(chatId, "stepSummary"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askStory(chatId) {
	await sendStep(chatId, btUser(chatId, "stepStory"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askAmount(chatId) {
	await sendStep(chatId, btUser(chatId, "stepAmount"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askCurrency(chatId, amount) {
	await sendStep(chatId, btUser(chatId, "pickCurrency", { amount: formatAmount(amount) }), { reply_markup: { inline_keyboard: [[{
		text: "💵 USD",
		callback_data: "apply:cur:USD"
	}, {
		text: "💶 EUR",
		callback_data: "apply:cur:EUR"
	}], applyCancelRow(chatId)] } });
}
async function askEvidence(chatId) {
	await sendStep(chatId, btUser(chatId, "stepEvidence"), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "done"),
		callback_data: "apply:done"
	}, {
		text: btUser(chatId, "skipFiles"),
		callback_data: "apply:skip"
	}], applyCancelRow(chatId)] } });
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? btUser(chatId, "filesCount", { n: session.evidence.length }) : btUser(chatId, "noFiles");
	await sendStep(chatId, btUser(chatId, "confirm", {
		accounts: formatSessionAccounts(session, chatId),
		victim,
		id: session.victimId,
		amount: session.amount,
		currency: session.currency,
		files,
		summary: session.summary,
		story: session.story
	}), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "sendReview"),
		callback_data: "apply:send"
	}, {
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}]] } });
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await sendCeMessage(chatId, btUser(from.id, "applyStart"));
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice) {
	clearStepMessage(chatId);
	sessions.delete(userId);
	await sendCeMessage(chatId, notice || btUser(userId, "cancel"), { reply_markup: applyKeyboard(langOf(userId)) });
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needAccountSubmit")
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (!session.summary.trim() || session.summary.trim().length < 10) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needSummary")
		});
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (!session.story.trim() || session.story.trim().length < 20) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needStory")
		});
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		summary: session.summary,
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || btUser(userId, "sendFail")
		});
		return;
	}
	clearStepMessage(chatId);
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: btUser(userId, "sent", { id: app.id })
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: btUser(userId, "addAccountLeast")
					});
					return;
				}
				session.step = "summary";
				sessions.set(userId, session);
				await askSummary(chatId);
				return;
			}
			const resolved = await resolveHandleServer(raw, userId);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "parseAccount")
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "idNoNumeric", { user: resolved.username })
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (session.step === "summary") {
		const summary = (msg.text || msg.caption || "").trim();
		if (summary.length < 10) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needSummary")
			});
			return;
		}
		if (summary.length > 800) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "summaryLong")
			});
			return;
		}
		session.summary = summary;
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 20) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needStory")
			});
			return;
		}
		if (story.length > 5e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "storyLong")
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needAmount")
			});
			return;
		}
		session.amount = parsed.amount;
		if (!parsed.currency) {
			sessions.set(userId, session);
			await askCurrency(chatId, parsed.amount);
			return;
		}
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 30) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "fileAccepted", { n: session.evidence.length }),
				reply_markup: { inline_keyboard: [[{
					text: btUser(userId, "done"),
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "sendMedia")
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: btUser(cb.from?.id, "applyInDm"),
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(cb.from?.id, "applyOpen", { bot: BOT_USERNAME })
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: btUser(cb.from?.id, "restart")
		});
		return;
	}
	tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
		if (!session.amount) {
			await askAmount(chatId);
			return;
		}
		session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
		session.step = "evidence";
		sessions.set(userId, session);
		await askEvidence(chatId);
		return;
	}
	if (cb.data === "apply:keep") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "addAccountFirst")
			});
			return;
		}
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "nextAccount")
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") await submitSession(chatId, userId, session);
}
function findRelay(id) {
	return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}
function upsertRelay(chat, status) {
	const list = [...bindings.relayChats || []];
	const idx = list.findIndex((c) => sameChat(c.id, chat.id));
	const next = {
		id: String(chat.id),
		title: chat.title || list[idx]?.title,
		type: chat.type || list[idx]?.type,
		status
	};
	if (status === "pending") next.requestedAt = Date.now();
	if (idx >= 0) list[idx] = {
		...list[idx],
		...next
	};
	else list.push(next);
	bindings.relayChats = pruneRelays(list);
	saveBindings();
}
function pruneRelays(list) {
	const LIMIT = 5e3;
	if (list.length <= LIMIT) return list;
	const removable = list.filter((c) => c.status !== "on").sort((a, b) => (a.requestedAt || 0) - (b.requestedAt || 0)).slice(0, list.length - LIMIT);
	const drop = new Set(removable.map((c) => chatIdKey(c.id)));
	return list.filter((c) => !drop.has(chatIdKey(c.id)));
}
function onChatMigrated(oldId, newId) {
	if (!oldId || !newId || sameChat(oldId, newId)) return;
	migratedKeys.set(chatIdKey(oldId), chatIdKey(newId));
	let changed = false;
	const list = bindings.relayChats || [];
	const old = list.find((c) => sameChat(c.id, oldId));
	if (old) {
		const twin = list.find((c) => sameChat(c.id, newId));
		if (twin) {
			if (old.status === "on") twin.status = "on";
			bindings.relayChats = list.filter((c) => c !== old);
		} else {
			old.id = newId;
			old.type = "supergroup";
		}
		changed = true;
	}
	if (bindings.channelId && sameChat(bindings.channelId, oldId)) {
		bindings.channelId = newId;
		changed = true;
	}
	if (changed) {
		saveBindings();
		console.log(`[epb] chat ${oldId} migrated to ${newId}`);
	}
}
function dropRelay(id) {
	bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
	saveBindings();
}
function chatKindLabel(type) {
	if (type === "channel") return "канал";
	if (type === "supergroup") return "супергруппа";
	if (type === "group") return "группа";
	return type || "чат";
}
async function greetRelayChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: [
			`<b>${CHANNEL_NAME}</b>`,
			"",
			"Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает."
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function notifyArbitersAboutRelay(chat, addedBy) {
	const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
	const who = addedBy?.username ? `@${addedBy.username}` : addedBy?.first_name ? `${escapeHtml(addedBy.first_name)} (<code>${addedBy.id}</code>)` : "неизвестно";
	await tgSoft("sendMessage", {
		chat_id: arbiter,
		text: [
			"<b>Бот добавлен в чужой чат</b>",
			"",
			`Название: ${escapeHtml(chat.title || "без названия")}`,
			`Тип: ${chatKindLabel(chat.type)}`,
			`ID: <code>${chat.id}</code>`,
			`Кто добавил: ${who}`,
			"",
			"Подключить рассылку одобренных постов в этот чат?"
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [[{
			text: "Принять",
			callback_data: `rel:y:${chat.id}`
		}, {
			text: "Отклонить",
			callback_data: `rel:n:${chat.id}`
		}]] }
	});
}
async function replaceReplyMarkup(msg, markup, nextText) {
	const text = nextText ?? msg.caption ?? msg.text ?? "";
	const isMedia = Boolean(msg.caption || msg.photo || msg.video);
	if (nextText) {
		if (isMedia) {
			if (await tgSoft("editMessageCaption", {
				chat_id: msg.chat.id,
				message_id: msg.message_id,
				caption: text.slice(0, 1024),
				parse_mode: "HTML",
				reply_markup: markup
			})) return true;
		} else if (await tgSoft("editMessageText", {
			chat_id: msg.chat.id,
			message_id: msg.message_id,
			text,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: markup
		})) return true;
	}
	const markupOnly = await tgSoft("editMessageReplyMarkup", {
		chat_id: msg.chat.id,
		message_id: msg.message_id,
		reply_markup: markup
	});
	return Boolean(markupOnly);
}
function callbackKey(data) {
	const i = data.indexOf(":");
	return i >= 0 ? data.slice(i + 1) : "";
}
async function handleRelayDecision(cb, allow) {
	const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
	if (!raw) return;
	const chatId = raw;
	const relay = findRelay(chatId);
	const title = relay?.title || chatId;
	if (allow) {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "on");
		const wrote = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
			show_alert: !wrote
		});
	} else {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "off");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят."
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Отклонено"
		});
	}
	const next = allow ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.` : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
	if (cb.message) await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: next,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [] }
	});
}
async function bindChat(chat, from, justAdded = true) {
	if (!isGroupOrChannel(chat)) return;
	const id = String(chat.id);
	if (isOfficialArbiterChat(id)) {
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
				"",
				"Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
				"Сменить: /channel -100…"
			].join("\n"),
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialChannel(id)) {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${escapeHtml(chat.title ?? id)}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	const existing = findRelay(id);
	if (existing?.status === "on") {
		if (!justAdded) return;
		await tgSoft("sendMessage", {
			chat_id: chat.id,
			text: "Рассылка уже включена. Одобренные посты будут приходить сюда."
		});
		return;
	}
	if (existing?.status === "pending" && Date.now() - (existing.requestedAt || 0) < 864e5) return;
	if (existing?.status === "off" && !justAdded) return;
	if (tooMany("relay:global", 8, 6e4)) return;
	if (from?.id && tooMany(`relay:${from.id}`, 3, 36e5)) return;
	upsertRelay(chat, "pending");
	await greetRelayChat(chat);
	await notifyArbitersAboutRelay(chat, from);
}
var USERS_PATH = join(DATA_DIR, "telegram-users.json");
var botUsers = readJson(USERS_PATH) || {};
var isUserId = (id) => /^[1-9]\d{0,15}$/.test(String(id ?? ""));
if (!existsSync(USERS_PATH)) {
	const seed = /* @__PURE__ */ new Set([...Object.keys(userLocales), ...Object.values(pendingPosts).map((r) => r.victimId || "")]);
	for (const id of seed) if (isUserId(id)) botUsers[id] = {
		first: Date.now(),
		last: 0
	};
	try {
		writeJsonAtomic(USERS_PATH, botUsers);
	} catch {}
}
var usersTimer = null;
function saveUsers() {
	if (usersTimer) return;
	usersTimer = setTimeout(() => {
		usersTimer = null;
		try {
			writeJsonAtomic(USERS_PATH, botUsers);
		} catch {}
	}, 3e3);
}
function touchUser(id, blocked) {
	if (!isUserId(id)) return;
	const key = String(id);
	const now = Date.now();
	const user = botUsers[key] || {
		first: now,
		last: now
	};
	user.last = now;
	if (blocked !== void 0) user.blocked = blocked;
	else if (user.blocked) user.blocked = false;
	botUsers[key] = user;
	saveUsers();
}
function userStats() {
	const all = Object.values(botUsers);
	const blocked = all.filter((u) => u.blocked).length;
	return {
		total: all.length,
		active: all.length - blocked,
		blocked
	};
}
var DM_JOBS_PATH = join(DATA_DIR, "telegram-dm-broadcasts.json");
var dmDonePath = (id) => join(DATA_DIR, `dm-done-${id.replace(/[^a-z0-9-]/gi, "")}.log`);
var dmJobs = readJson(DM_JOBS_PATH) || [];
var dmDraft = null;
var dmPrompts = /* @__PURE__ */ new Map();
var dmAlbums = /* @__PURE__ */ new Map();
var dmQueue = Promise.resolve();
var dmStarting = /* @__PURE__ */ new Set();
function saveDmJobs() {
	try {
		writeJsonAtomic(DM_JOBS_PATH, dmJobs);
	} catch {}
}
function readDone(id) {
	try {
		return new Set(readFileSync(dmDonePath(id), "utf8").split("\n").filter(Boolean).map((l) => l.replace(/^\?/, "")));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function dmMarkup(draft) {
	return draft.buttons.length ? { inline_keyboard: draft.buttons } : void 0;
}
async function sendDmCopy(chatId, draft) {
	if (draft.srcIds.length > 1) {
		if (!(await tg("copyMessages", {
			chat_id: chatId,
			from_chat_id: draft.srcChat,
			message_ids: draft.srcIds
		}))?.length) throw new Error("сообщение не скопировалось");
		return;
	}
	await tg("copyMessage", {
		chat_id: chatId,
		from_chat_id: draft.srcChat,
		message_id: draft.srcIds[0],
		reply_markup: dmMarkup(draft)
	});
}
function parseDmButtons(text) {
	const rows = [];
	for (const line of text.split("\n").map((l) => l.trim()).filter(Boolean)) {
		const row = [];
		for (const part of line.split("|").map((p) => p.trim()).filter(Boolean)) {
			const m = part.match(/^(.+?)\s+[-–—]\s+(\S+)$/);
			if (!m) return `Не понял строку: «${part}». Формат: Текст - https://ссылка`;
			const url = m[2];
			if (!/^(https?:\/\/|tg:\/\/)\S+$/i.test(url)) return `Ссылка должна начинаться с https:// или tg:// — «${url}»`;
			row.push({
				text: m[1].slice(0, 64),
				url
			});
		}
		if (row.length > 8) return "В одном ряду максимум 8 кнопок";
		if (row.length) rows.push(row);
	}
	if (!rows.length) return "Не нашёл ни одной кнопки";
	if (rows.length > 10) return "Максимум 10 рядов кнопок";
	return rows;
}
function dmScreen() {
	const st = userStats();
	const running = dmJobs.find((j) => !j.stopped);
	const lines = [
		"<b>Пользователи бота</b>",
		`Всего: ${st.total}`,
		`Получат рассылку: ${st.active}`,
		`Заблокировали бота: ${st.blocked}`,
		"",
		"Рассылка уходит только в личные сообщения пользователям бота. В чаты и каналы она не отправляется."
	];
	const keyboard = [];
	if (running) {
		const done = readDone(running.id).size;
		lines.push("", `<b>Идёт рассылка</b>: ${done} из ${running.recipients.length}`);
		keyboard.push([{
			text: "⏹ Остановить рассылку",
			callback_data: `adm:ubstop:${running.id}`
		}]);
		keyboard.push([{
			text: "🔄 Обновить",
			callback_data: "adm:ub"
		}]);
	} else keyboard.push([{
		text: "✉ Новая рассылка",
		callback_data: "adm:ubnew"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function askDmContent(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Новая рассылка пользователям бота</b>",
			"",
			"Ответьте на это сообщение тем, что нужно разослать: текст, фото, видео, GIF, стикер или альбом, с подписью и форматированием.",
			"Премиум-эмодзи сохранятся, если у владельца бота есть Telegram Premium.",
			"",
			"Не удаляйте своё сообщение, пока рассылка не закончится: бот копирует именно его."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Сообщение для рассылки"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "content");
}
async function askDmButtons(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Кнопки под рассылкой</b>",
			"",
			"Ответьте на это сообщение. Каждая строка — ряд кнопок, кнопки в ряду через «|»:",
			"<code>Наш канал - https://t.me/+KkrYz9IKvoBmYTQy</code>",
			"<code>Сайт - https://example.com | Бот - https://t.me/EuropeBlack_bot</code>"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Текст - https://ссылка"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "buttons");
}
async function sendDmPreview(chatId) {
	const draft = dmDraft;
	if (!draft) return;
	const st = userStats();
	let previewOk = true;
	try {
		await sendDmCopy(String(chatId), draft);
	} catch (err) {
		previewOk = false;
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось показать предпросмотр: ${err.message}`
		});
	}
	const album = draft.srcIds.length > 1;
	const keyboard = [];
	if (!album) {
		keyboard.push([{
			text: draft.buttons.length ? "✏ Изменить кнопки" : "➕ Добавить кнопки",
			callback_data: "adm:ubbtn"
		}]);
		if (draft.buttons.length) keyboard.push([{
			text: "🗑 Убрать кнопки",
			callback_data: "adm:ubclr"
		}]);
	}
	if (previewOk) keyboard.push([{
		text: `🚀 Разослать (${st.active})`,
		callback_data: `adm:ubgo:${draft.id}`
	}]);
	keyboard.push([{
		text: "✖ Отменить",
		callback_data: "adm:ubcancel"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Предпросмотр рассылки — выше</b>",
			`Получат: ${st.active} пользователей бота (только личные сообщения, не чаты и не каналы).`,
			album ? "Это альбом: Telegram не позволяет добавить к альбому кнопки." : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: keyboard }
	});
}
async function handleDmReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const kind = dmPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!kind) return false;
	if (kind === "buttons") {
		if (!dmDraft) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Черновик рассылки не найден. Начните заново: /admin"
			});
			return true;
		}
		const parsed = parseDmButtons(msg.text || "");
		if (typeof parsed === "string") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `${parsed}\nОтветьте на сообщение с инструкцией ещё раз.`,
				reply_to_message_id: msg.message_id
			});
			return true;
		}
		dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
		dmDraft.buttons = parsed;
		await sendDmPreview(msg.chat.id);
		return true;
	}
	if (msg.media_group_id) {
		const albumKey = `${msg.chat.id}:${msg.media_group_id}`;
		const album = dmAlbums.get(albumKey);
		if (album) {
			album.ids.push(msg.message_id);
			return true;
		}
		const timer = setTimeout(async () => {
			const done = dmAlbums.get(albumKey);
			dmAlbums.delete(albumKey);
			if (!done) return;
			dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
			dmDraft = {
				id: randomUUID(),
				srcChat: done.chat,
				srcIds: [...done.ids].sort((a, b) => a - b),
				buttons: []
			};
			await sendDmPreview(msg.chat.id);
		}, 1500);
		dmAlbums.set(albumKey, {
			chat: String(msg.chat.id),
			ids: [msg.message_id],
			timer
		});
		return true;
	}
	dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
	dmDraft = {
		id: randomUUID(),
		srcChat: String(msg.chat.id),
		srcIds: [msg.message_id],
		buttons: []
	};
	await sendDmPreview(msg.chat.id);
	return true;
}
function collectDmAlbumItem(msg) {
	if (!msg.media_group_id) return false;
	const album = dmAlbums.get(`${msg.chat.id}:${msg.media_group_id}`);
	if (!album) return false;
	if (!album.ids.includes(msg.message_id)) album.ids.push(msg.message_id);
	return true;
}
async function updateDmStatus(job, final = false) {
	const done = readDone(job.id).size;
	const text = final ? [
		`<b>Рассылка пользователям ${job.stopped ? "остановлена" : "завершена"}</b>`,
		`Доставлено: ${job.sent}`,
		`Заблокировали бота / недоступны: ${job.blocked}`,
		job.failed ? `Ошибки: ${job.failed}` : "",
		`Обработано: ${done} из ${job.recipients.length}`
	].filter(Boolean).join("\n") : `<b>Идёт рассылка пользователям</b>: ${done} из ${job.recipients.length}\nДоставлено ${job.sent}, недоступны ${job.blocked}${job.failed ? `, ошибки ${job.failed}` : ""}`;
	const markup = final ? void 0 : { inline_keyboard: [[{
		text: "⏹ Остановить",
		callback_data: `adm:ubstop:${job.id}`
	}]] };
	if (job.statusMessage) {
		if (await tgSoft("editMessageText", {
			chat_id: job.statusChat,
			message_id: job.statusMessage,
			text,
			parse_mode: "HTML",
			reply_markup: markup
		}) || !final) return;
	}
	const sent = await tgSoft("sendMessage", {
		chat_id: job.statusChat,
		text,
		parse_mode: "HTML",
		reply_markup: markup
	});
	if (sent?.message_id && !final) {
		job.statusMessage = sent.message_id;
		saveDmJobs();
	}
}
async function runDmJob(job) {
	const done = readDone(job.id);
	let lastStatus = 0;
	await updateDmStatus(job);
	for (const chatId of job.recipients) {
		if (job.stopped) break;
		if (!isUserId(chatId) || done.has(chatId)) continue;
		appendFileSync(dmDonePath(job.id), `?${chatId}\n`);
		try {
			await sendDmCopy(chatId, job);
			job.sent += 1;
		} catch (err) {
			const text = String(err?.message || "");
			if (err instanceof TgError && (err.code === 403 || /blocked|deactivated|can't initiate|chat not found|user not found/i.test(text))) {
				job.blocked += 1;
				touchUser(chatId, true);
			} else job.failed += 1;
		}
		done.add(chatId);
		appendFileSync(dmDonePath(job.id), `${chatId}\n`);
		if (Date.now() - lastStatus > 4e3) {
			lastStatus = Date.now();
			saveDmJobs();
			await updateDmStatus(job);
		}
		await sleep(Math.max(45, 45 * job.srcIds.length));
	}
	await updateDmStatus(job, true);
	dmJobs = dmJobs.filter((j) => j.id !== job.id);
	saveDmJobs();
	try {
		unlinkSync(dmDonePath(job.id));
	} catch {}
}
function enqueueDmJob(job) {
	dmQueue = dmQueue.then(() => runDmJob(job)).catch((err) => console.error("[epb] user broadcast", err));
}
function resumeDmJobs() {
	for (const job of dmJobs) {
		if (Date.now() - job.startedAt > 864e5) continue;
		console.log(`[epb] resuming user broadcast ${job.id}: ${readDone(job.id).size} done`);
		enqueueDmJob(job);
	}
}
async function handleDmCallback(cb, action, arg) {
	const chatId = cb.message.chat.id;
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "ub") {
		await answer();
		await renderAdmin(cb, dmScreen());
		return true;
	}
	if (action === "ubnew") {
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Сначала дождитесь окончания текущей рассылки", true);
			return true;
		}
		await answer("Ответьте на сообщение бота тем, что нужно разослать");
		await askDmContent(chatId);
		return true;
	}
	if (action === "ubbtn") {
		await answer();
		if (!dmDraft) await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Черновик не найден. Начните заново: /admin"
		});
		else await askDmButtons(chatId);
		return true;
	}
	if (action === "ubclr") {
		if (dmDraft) dmDraft.buttons = [];
		await answer("Кнопки убраны");
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubcancel") {
		dmDraft = null;
		await answer("Рассылка отменена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: "Рассылка отменена."
		});
		return true;
	}
	if (action === "ubgo") {
		if (!dmDraft || dmDraft.id !== arg) {
			await answer("Этот черновик уже неактуален", true);
			return true;
		}
		await answer();
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Разослать это сообщение ${userStats().active} пользователям бота? Отменить уже отправленное будет нельзя.`,
			reply_markup: { inline_keyboard: [[{
				text: "✅ Да, разослать",
				callback_data: `adm:ubyes:${dmDraft.id}`
			}], [{
				text: "⬅ Назад",
				callback_data: "adm:ubback"
			}]] }
		});
		return true;
	}
	if (action === "ubback") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubyes") {
		if (!dmDraft || dmDraft.id !== arg || dmStarting.has(arg) || dmJobs.some((j) => j.id === arg)) {
			await answer("Эта рассылка уже запущена или отменена", true);
			return true;
		}
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Уже идёт другая рассылка", true);
			return true;
		}
		dmStarting.add(arg);
		const recipients = Object.entries(botUsers).filter(([id, u]) => isUserId(id) && !u.blocked).map(([id]) => id);
		const job = {
			...dmDraft,
			recipients,
			sent: 0,
			blocked: 0,
			failed: 0,
			startedAt: Date.now(),
			statusChat: String(chatId)
		};
		dmJobs.push(job);
		saveDmJobs();
		dmDraft = null;
		await answer("Рассылка запущена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Рассылка запущена: ${recipients.length} получателей.`
		});
		enqueueDmJob(job);
		return true;
	}
	if (action === "ubstop") {
		const job = dmJobs.find((j) => j.id === arg);
		if (job) {
			job.stopped = true;
			saveDmJobs();
		}
		await answer(job ? "Останавливаем…" : "Рассылка уже закончилась");
		return true;
	}
	return false;
}
var ADMIN_PAGE = 8;
var RELAY_FILTERS = [
	{
		key: "a",
		label: "Все",
		match: () => true
	},
	{
		key: "on",
		label: "✅ Вкл",
		match: (c) => c.status === "on"
	},
	{
		key: "pd",
		label: "⏳ Ждут",
		match: (c) => c.status === "pending"
	},
	{
		key: "off",
		label: "⛔ Выкл",
		match: (c) => c.status === "off"
	}
];
var statusIcon = (status) => status === "on" ? "✅" : status === "pending" ? "⏳" : "⛔";
var statusText = (status) => status === "on" ? "рассылка включена" : status === "pending" ? "ждёт решения" : "рассылка выключена";
function ago(ts) {
	if (!ts) return "давно";
	const min = Math.round((Date.now() - ts) / 6e4);
	if (min < 60) return `${Math.max(1, min)} мин назад`;
	const h = Math.round(min / 60);
	if (h < 48) return `${h} ч назад`;
	return `${Math.round(h / 24)} дн назад`;
}
function cut(text, max) {
	return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function pendingComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => (rec.status || "pending") === "pending").sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function publishedComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => rec.status === "published" && rec.channelPosted && !rec.deletedEverywhere).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function adminDeleteList(page) {
	const list = publishedComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => {
		const chats = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
		return [{
			text: `${cut(scamLabel(rec), 22)} · ${chats} чат. · ${ago(rec.createdAt)}`,
			callback_data: `adm:dlc:${key}`
		}];
	});
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:dl:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:dl:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:dl:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Удалить блеклист</b>: опубликовано ${list.length}\nВыберите запись — бот спросит подтверждение и удалит пост из канала и из всех чатов рассылки.` : "<b>Удалить блеклист</b>: опубликованных записей нет.",
		keyboard
	};
}
async function adminDeleteConfirm(key) {
	const rec = pendingPosts[key];
	const back = {
		text: "⬅ К списку",
		callback_data: "adm:dl:0"
	};
	if (!rec || rec.status !== "published") return {
		text: "Эта запись уже не опубликована.",
		keyboard: [[back]]
	};
	const chatCount = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
	const channelCount = rec.channelMsgIds?.length || 0;
	return {
		text: [
			"<b>Удалить блеклист везде?</b>",
			`Аккаунт: ${escapeHtml(scamLabel(rec))}`,
			`Ущерб: ${escapeHtml(rec.amount || "—")} ${escapeHtml(rec.currency || "")}`,
			"",
			`Будет удалено: пост в канале (${channelCount} сообщ.) и сообщения в ${chatCount} чатах рассылки.`,
			"Отменить удаление нельзя. Сообщения старше 48 часов Telegram может не дать удалить в некоторых чатах."
		].join("\n"),
		keyboard: [[{
			text: "🗑 Да, удалить везде",
			callback_data: `adm:dlgo:${key}`
		}], [back]]
	};
}
function adminHome() {
	const relays = bindings.relayChats || [];
	const all = Object.values(pendingPosts);
	const count = (st) => all.filter((r) => (r.status || "pending") === st).length;
	const last = bindings.lastBroadcast;
	return {
		text: [
			`<b>${CHANNEL_NAME} — панель</b>`,
			"",
			`<b>Заявки</b>: ждут решения ${count("pending")}, опубликовано ${count("published")}, отклонено ${count("rejected")}`,
			`<b>Чаты рассылки</b>: включено ${relays.filter((c) => c.status === "on").length}, ждут ${relays.filter((c) => c.status === "pending").length}, выключено ${relays.filter((c) => c.status === "off").length}`,
			`<b>Пользователи бота</b>: ${userStats().total} (заблокировали ${userStats().blocked})`,
			`<b>Канал</b>: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			last ? `<b>Последняя рассылка</b>: ${ago(last.at)}, доставлено ${last.sent} из ${last.total}` + (last.noRights ? `, без прав ${last.noRights}` : "") + (last.gone ? `, недоступно ${last.gone}` : "") : "<b>Последняя рассылка</b>: ещё не было"
		].join("\n"),
		keyboard: [
			[{
				text: `📝 Заявки без решения (${count("pending")})`,
				callback_data: "adm:ap:0"
			}],
			[{
				text: `🗑 Удалить блеклист (${count("published")})`,
				callback_data: "adm:dl:0"
			}],
			[{
				text: "📋 Чаты рассылки",
				callback_data: "adm:rl:a:0"
			}, {
				text: "⏳ Ждут решения",
				callback_data: "adm:rl:pd:0"
			}],
			[{
				text: "📢 Канал для постов",
				callback_data: "adm:ch"
			}],
			[{
				text: "📣 Рассылка пользователям бота",
				callback_data: "adm:ub"
			}],
			[{
				text: `🖼 Баннеры (${(bindings.banners || []).length})`,
				callback_data: "adm:bn"
			}],
			...checkEnabled() ? [
				[{
					text: "➕ Добавить юзера в блеклист",
					callback_data: "adm:bladd"
				}],
				[{
					text: "🧹 Убрать юзера из блеклиста",
					callback_data: "adm:ccrm"
				}],
				[{
					text: "🔎 Каналы для проверки",
					callback_data: "adm:cc"
				}]
			] : [],
			[{
				text: "🔄 Обновить",
				callback_data: "adm:home"
			}, {
				text: "✖ Закрыть",
				callback_data: "adm:x"
			}]
		]
	};
}
function adminRelayList(filter, page) {
	const f = RELAY_FILTERS.find((x) => x.key === filter) || RELAY_FILTERS[0];
	const list = (bindings.relayChats || []).filter(f.match);
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const slice = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE);
	const keyboard = [RELAY_FILTERS.map((x) => ({
		text: x.key === f.key ? `• ${x.label}` : x.label,
		callback_data: `adm:rl:${x.key}:0`
	})), ...slice.map((c) => [{
		text: `${statusIcon(c.status)} ${cut(c.title || c.id, 40)}`,
		callback_data: `adm:rc:${c.id}:${f.key}:${p}`
	}])];
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:rl:${f.key}:${p - 1}`
	});
	nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:rl:${f.key}:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:rl:${f.key}:${p + 1}`
	});
	keyboard.push(nav, [{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: [`<b>Чаты рассылки</b> — ${f.label}: ${list.length}`, list.length ? "Нажмите на чат, чтобы открыть карточку." : "Здесь пока пусто."].join("\n"),
		keyboard
	};
}
async function adminRelayCard(chatId, filter, page, note = "") {
	const relay = findRelay(chatId);
	const back = {
		text: "⬅ К списку",
		callback_data: `adm:rl:${filter}:${page}`
	};
	if (!relay) return {
		text: "Этого чата уже нет в списке.",
		keyboard: [[back]]
	};
	const suffix = `${relay.id}:${filter}:${page}`;
	const toggle = relay.status === "on" ? {
		text: "⛔ Выключить рассылку",
		callback_data: `adm:roff:${suffix}`
	} : {
		text: "✅ Включить рассылку",
		callback_data: `adm:ron:${suffix}`
	};
	return {
		text: [
			`<b>${escapeHtml(relay.title || "без названия")}</b>`,
			`ID: <code>${escapeHtml(relay.id)}</code>`,
			`Тип: ${chatKindLabel(relay.type)}`,
			`Статус: ${statusIcon(relay.status)} ${statusText(relay.status)}`,
			`Ссылка спонсора: ${relay.link ? `<code>${escapeHtml(relay.link)}</code>` : "не задана"}`,
			relay.requestedAt ? `Запрос: ${ago(relay.requestedAt)}` : "",
			note ? `\n${note}` : ""
		].filter(Boolean).join("\n"),
		keyboard: [
			[toggle],
			[{
				text: relay.link ? "🔗 Изменить ссылку спонсора" : "🔗 Задать ссылку спонсора",
				callback_data: `adm:rlink:${suffix}`
			}],
			[{
				text: "🔍 Проверить права бота",
				callback_data: `adm:rchk:${suffix}`
			}],
			[back]
		]
	};
}
async function botRightsNote(chatId) {
	const member = await tgSoft("getChatMember", {
		chat_id: chatId,
		user_id: Number(botToken().split(":")[0])
	});
	if (!member) return "❌ Бот не видит этот чат: его удалили или чат закрыт.";
	if (member.status === "left" || member.status === "kicked") return "❌ Бота в этом чате нет.";
	if ((await tgSoft("getChat", { chat_id: chatId }))?.type === "channel") return member.status === "administrator" && member.can_post_messages !== false ? "✅ Бот админ канала и может публиковать." : "⚠️ Бот не может публиковать в канале: нужен админ с правом публикации.";
	if (member.status === "restricted" && (member.can_send_messages === false || member.can_send_photos === false)) return "⚠️ Боту запрещено отправлять сообщения или медиа в этом чате.";
	return member.status === "administrator" || member.status === "creator" ? "✅ Бот админ, рассылка будет доходить." : "✅ Бот участник чата и может писать. Лучше выдать админа, чтобы медиа точно доходили.";
}
function adminPendingList(page) {
	const list = pendingComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => [{
		text: `${key} · ${cut(scamLabel(rec), 24)} · ${rec.amount} ${rec.currency} · ${ago(rec.createdAt)}`,
		callback_data: `adm:as:${key}`
	}]);
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:ap:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:ap:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:ap:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Заявки без решения</b>: ${list.length}\nНажмите на заявку — бот пришлёт её ещё раз с кнопками.` : "<b>Заявки без решения</b>: нет, все разобраны.",
		keyboard
	};
}
async function adminShowComplaint(arbiterChatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return false;
	const accounts = pendingAccounts(rec).map((a) => formatAccountLine(a.username, a.id, true)).join("\n");
	const parts = splitHtml([
		`<b>Заявка ${escapeHtml(key)}</b> (повтор из панели, ${ago(rec.createdAt)})`,
		"",
		`<b>Аккаунт</b>\n${accounts}`,
		`<b>Ущерб</b>\n${escapeHtml(rec.amount)} ${escapeHtml(rec.currency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(rec.summary || rec.story)}`,
		rec.files?.length ? `\nДоказательств: ${rec.files.length} (в исходной заявке, они уйдут в пост)` : ""
	].join("\n"));
	for (const [i, part] of parts.entries()) {
		const payload = {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: i === parts.length - 1 ? reviewKeyboard(key) : void 0
		};
		if (i === 0 && rec.reviewMessageId && rec.reviewChatId && sameChat(rec.reviewChatId, arbiterChatId)) payload.reply_parameters = {
			message_id: rec.reviewMessageId,
			allow_sending_without_reply: true
		};
		await tgSoft("sendMessage", payload);
	}
	return true;
}
function adminCheck() {
	const list = checkChannels();
	const ub = hasUserbot();
	const lines = [
		"<b>Каналы для проверки контрагента</b>",
		`Подключено: ${list.length}`,
		`Аккаунт (юзербот): ${ub ? "подключён ✅" : "не подключён"}`,
		"",
		ub ? "Поиск идёт через подключённый аккаунт по всем постам этих каналов, включая старые. Бота в каналы добавлять не нужно — аккаунт должен быть на них подписан." : "Сейчас бот индексирует только новые посты каналов, где он сам состоит. Чтобы искать по старым постам чужих каналов без добавления бота, подключите аккаунт (юзербот) — см. HOSTING.md."
	];
	const keyboard = list.map((c) => [{
		text: `🗑 ${cut(c.title || c.username || c.id, 36)}`,
		callback_data: `adm:ccdel:${c.id}`
	}]);
	keyboard.push([{
		text: "🔌 Проверить аккаунт",
		callback_data: "adm:ccping"
	}]);
	keyboard.push([{
		text: "🧹 Убрать жалобу из блеклиста",
		callback_data: "adm:ccrm"
	}]);
	keyboard.push([{
		text: "➕ Добавить канал",
		callback_data: "adm:ccadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
function adminBanners() {
	const list = bindings.banners || [];
	const lines = [
		"<b>Баннеры в мини-аппе</b>",
		`Сейчас: ${list.length} из ${MAX_BANNERS}`,
		"",
		list.length ? "Баннеры показываются сверху в приложении. Видео и GIF идут без звука и по кругу. Тап по баннеру открывает ссылку." : "Пока нет ни одного баннера. Нажмите «Добавить баннер», пришлите картинку / видео / GIF, затем ссылку."
	];
	const keyboard = list.map((b, i) => [{
		text: `🗑 ${i + 1}. ${b.type === "video" ? "🎞" : "🖼"} ${cut(b.link || "без ссылки", 34)}`,
		callback_data: `adm:bndel:${b.id}`
	}]);
	if (list.length < MAX_BANNERS) keyboard.push([{
		text: "➕ Добавить баннер",
		callback_data: "adm:bnadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function handleBannerInput(msg) {
	const key = String(msg.chat.id);
	const st = bannerSetup.get(key);
	if (!st) return false;
	if (st.phase === "media") {
		const media = extractBannerMedia(msg);
		if (!media) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Пришлите картинку, видео или GIF одним сообщением (не текстом). Или /admin, чтобы выйти."
			});
			return true;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Загружаю медиа…"
		});
		const bytes = await downloadTelegramFile(media.fileId);
		if (!bytes) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Не удалось загрузить файл. Для баннера подойдёт картинка / видео / GIF до 20 МБ. Пришлите ещё раз."
			});
			return true;
		}
		const id = newBannerId();
		saveBannerFile(id, bytes);
		st.draft = {
			type: media.type,
			file: id,
			mime: media.mime,
			width: media.width,
			height: media.height
		};
		st.phase = "link";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа сохранено. Теперь пришлите ссылку (https://… или t.me/…), которая откроется по тапу на баннер.\nЕсли ссылка не нужна — отправьте «-»."
		});
		return true;
	}
	if (!msg.text) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пришлите ссылку текстом (https://…) или «-», чтобы без ссылки."
		});
		return true;
	}
	const link = normalizeBannerLink(msg.text);
	if (link === null) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Это не похоже на ссылку. Пришлите адрес вида https://… или t.me/…, либо «-» без ссылки."
		});
		return true;
	}
	const draft = st.draft;
	bannerSetup.delete(key);
	if (!draft) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа не найдено, начните заново: /admin → Баннеры."
		});
		return true;
	}
	const banner = {
		id: draft.file,
		type: draft.type,
		file: draft.file,
		mime: draft.mime,
		link,
		width: draft.width,
		height: draft.height,
		createdAt: Date.now()
	};
	bindings.banners = [...bindings.banners || [], banner].slice(-20);
	saveBindings();
	const view = adminBanners();
	await tgSoft("sendMessage", {
		chat_id: msg.chat.id,
		text: `Баннер добавлен${link ? "" : " (без ссылки)"}.\n\n${view.text}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
	return true;
}
async function applySponsorLink(arbiterChatId, raw) {
	const st = sponsorLinkSetup.get(String(arbiterChatId));
	sponsorLinkSetup.delete(String(arbiterChatId));
	if (!st) return;
	const res = setSponsorLink(st.relayId, raw);
	if (res === "bad") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не похоже на ссылку. Пришлите https://… или t.me/…, либо «-», чтобы убрать."
		});
		return;
	}
	const view = await adminRelayCard(st.relayId, st.filter, st.page, res === "set" ? "Ссылка спонсора сохранена." : "Ссылка спонсора убрана.");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function applyRemoveFromCheck(arbiterChatId, raw) {
	removeFromCheckSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	let removed = 0;
	const epbId = text.match(/\b(EPB-[A-Za-z0-9]+)\b/i)?.[1];
	if (epbId) {
		const rec = pendingPosts[epbId] || pendingPosts[epbId.toUpperCase()];
		if (rec && !rec.removedFromCheck) {
			rec.removedFromCheck = true;
			removed = 1;
		}
	} else {
		const parsed = parseTelegramInput(text);
		const uname = parsed.username.replace(/^@/, "").toLowerCase();
		const id = parsed.id;
		if (!uname && !id) {
			await tgSoft("sendMessage", {
				chat_id: arbiterChatId,
				text: "Не понял. Пришлите EPB-… или @username / ID."
			});
			return;
		}
		for (const rec of Object.values(pendingPosts)) {
			if (rec.removedFromCheck) continue;
			const accounts = pendingAccounts(rec);
			if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) {
				rec.removedFromCheck = true;
				removed += 1;
			}
		}
		const manual = bindings.manualBlacklist || [];
		const keptManual = manual.filter((e) => {
			const eu = (e.username || "").replace(/^@/, "").toLowerCase();
			return !(uname && eu === uname || id && e.telegramId === id);
		});
		if (keptManual.length !== manual.length) {
			removed += manual.length - keptManual.length;
			bindings.manualBlacklist = keptManual;
			saveBindings();
		}
	}
	if (removed) savePending();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: removed ? `Убрано из блеклиста: ${removed}. В проверке контрагента больше не показывается.` : "Ничего подходящего не нашёл."
	});
}
async function applyAddToBlacklist(arbiterChatId, raw) {
	addBlacklistSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	const firstTok = text.split(/\s+/)[0] || "";
	const note = text.slice(firstTok.length).trim();
	const parsed = parseTelegramInput(firstTok);
	const username = parsed.username.replace(/^@/, "");
	const id = parsed.id;
	if (!username && !id) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не понял. Пришлите @username или ID, можно с комментарием через пробел."
		});
		return;
	}
	const entry = {
		id: randomUUID(),
		username: username || void 0,
		telegramId: id || void 0,
		source: DEFAULT_MANUAL_SOURCE,
		note: note || void 0,
		addedAt: Date.now()
	};
	bindings.manualBlacklist = [...bindings.manualBlacklist || [], entry].slice(-5e3);
	saveBindings();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Добавлено в блеклист (проверка контрагента).",
			`Аккаунт: ${escapeHtml(username ? `@${username}` : `ID ${id}`)}`,
			`Источник: ${escapeHtml(DEFAULT_MANUAL_SOURCE)}`,
			note ? `Комментарий: ${escapeHtml(note)}` : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML"
	});
}
async function applyCheckChannel(arbiterChatId, raw) {
	checkChannelSetup.delete(String(arbiterChatId));
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала (-100…) или @username."
		});
		return;
	}
	let entry = null;
	const chat = await chatReachable(ref);
	if (chat && (chat.type === "channel" || chat.type === "supergroup")) entry = {
		id: String(chat.id),
		title: chat.title,
		username: chat.username,
		addedAt: Date.now()
	};
	else if (hasUserbot()) entry = await resolveChannelAsUser(String(ref));
	if (!entry) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: hasUserbot() ? "Не удалось открыть этот канал. Подключённый аккаунт должен быть подписан на него. Пришлите @username или ID ещё раз." : "Не вижу этот канал. Добавьте бота в канал (участником или админом) и пришлите ID ещё раз — или подключите аккаунт (юзербот), тогда бота добавлять не нужно."
		});
		return;
	}
	if (isOfficialChannel(entry.id) || isOfficialArbiterChat(entry.id)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный канал бота, добавлять его не нужно."
		});
		return;
	}
	const list = [...checkChannels()];
	if (!list.some((c) => sameChat(c.id, entry.id))) {
		list.push(entry);
		bindings.checkChannels = list.slice(-100);
		saveBindings();
	}
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал подключён для проверки.",
			escapeHtml(entry.title || entry.id),
			`ID: <code>${escapeHtml(entry.id)}</code>`,
			"",
			hasUserbot() ? "Поиск по этому каналу идёт через подключённый аккаунт, включая старые посты." : "Новые посты этого канала будут попадать в поиск. Для старых постов подключите аккаунт (юзербот)."
		].join("\n"),
		parse_mode: "HTML"
	});
}
function adminChannel() {
	return {
		text: [
			"<b>Канал для постов</b>",
			`Сейчас: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			"",
			"Чтобы сменить: нажмите кнопку и пришлите ID канала (-100…) или @username следующим сообщением. Бот должен быть админом канала."
		].join("\n"),
		keyboard: [[{
			text: "✏ Сменить канал",
			callback_data: "adm:chset"
		}], [{
			text: "⬅ В меню",
			callback_data: "adm:home"
		}]]
	};
}
async function sendAdminPanel(chatId) {
	const view = adminHome();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function renderAdmin(cb, view) {
	if (!cb.message) return;
	return await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function handleAdminCallback(cb) {
	const chatId = cb.message.chat.id;
	const [, action = "home", ...rest] = (cb.data || "").split(":");
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "x") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		return;
	}
	if (action === "home") {
		await answer();
		await renderAdmin(cb, adminHome());
		return;
	}
	if (action.startsWith("ub") && await handleDmCallback(cb, action, rest[0] || "")) return;
	if (action === "rl") {
		await answer();
		await renderAdmin(cb, adminRelayList(rest[0] || "a", Number(rest[1] || 0)));
		return;
	}
	const [target = "", filter = "a", page = "0"] = rest;
	if (action === "rc") {
		await answer();
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "ron" || action === "roff") {
		const relay = findRelay(target);
		if (!relay) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		upsertRelay({
			id: relay.id,
			title: relay.title,
			type: relay.type
		}, action === "ron" ? "on" : "off");
		if (action === "ron") await tgSoft("sendMessage", {
			chat_id: relay.id,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await answer(action === "ron" ? "Рассылка включена" : "Рассылка выключена");
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "rchk") {
		await answer("Проверяем…");
		await renderAdmin(cb, await adminRelayCard(target, filter, page, await botRightsNote(target)));
		return;
	}
	if (action === "rlink") {
		if (!findRelay(target)) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		sponsorLinkSetup.set(String(chatId), {
			relayId: target,
			filter,
			page
		});
		await answer("Пришлите ссылку");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ссылку на чат (https://… или t.me/…), которая будет прикреплена к названию на странице «Спонсоры проекта». Чтобы убрать ссылку — отправьте «-»."
		});
		return;
	}
	if (action === "ap") {
		await answer();
		await renderAdmin(cb, adminPendingList(Number(rest[0] || 0)));
		return;
	}
	if (action === "as") {
		const key = rest[0] || "";
		const shown = (pendingPosts[key]?.status || "pending") === "pending" && await adminShowComplaint(chatId, key);
		await answer(shown ? "Заявка отправлена ниже" : "Заявка уже обработана", !shown);
		if (!shown) await renderAdmin(cb, adminPendingList(0));
		return;
	}
	if (action === "cc") {
		await answer();
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "ccping") {
		await answer("Проверяем аккаунт…");
		const st = await userbotStatus();
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: st.ok ? `Аккаунт подключён: ${escapeHtml(st.name || "аккаунт")}` : `Аккаунт не подключён: ${escapeHtml(st.error || "ошибка")}`
		});
		return;
	}
	if (action === "ccrm") {
		removeFromCheckSetup.add(String(chatId));
		await answer("Пришлите номер жалобы или аккаунт");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите номер жалобы (EPB-…) либо @username / ID аккаунта, который нужно убрать из блеклиста (поиска). Жалоба останется в истории, но перестанет находиться в проверке контрагента."
		});
		return;
	}
	if (action === "bladd") {
		addBlacklistSetup.add(String(chatId));
		await answer("Пришлите @username или ID");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите @username или ID аккаунта, которого нужно добавить в блеклист (проверку контрагента). Можно с комментарием через пробел, например:\n@scammer кинул на сделке, инфа из чужого блеклиста\n\nИсточник отметится как «Сторонний источник»."
		});
		return;
	}
	if (action === "ccadd") {
		checkChannelSetup.add(String(chatId));
		await answer("Пришлите ID канала следующим сообщением");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ID канала (-100…) или @username для проверки. Бот должен быть в этом канале."
		});
		return;
	}
	if (action === "ccdel") {
		const target = rest.join(":");
		bindings.checkChannels = checkChannels().filter((c) => !sameChat(c.id, target));
		saveBindings();
		removeCheckChannelFromIndex(target);
		await answer("Канал убран");
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "dl") {
		await answer();
		await renderAdmin(cb, adminDeleteList(Number(rest[0] || 0)));
		return;
	}
	if (action === "dlc") {
		await answer();
		await renderAdmin(cb, await adminDeleteConfirm(rest.join(":")));
		return;
	}
	if (action === "dlgo") {
		const delKey = rest.join(":");
		if (!pendingPosts[delKey] || pendingPosts[delKey].status !== "published") {
			await answer("Запись уже удалена", true);
			await renderAdmin(cb, adminDeleteList(0));
			return;
		}
		await answer("Удаляю во всех чатах…");
		const res = await deletePublishedEverywhere(delKey);
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: [
				"Блеклист удалён.",
				`Канал: удалено ${res.channel.ok}${res.channel.fail ? `, не удалось ${res.channel.fail}` : ""}.`,
				`Чаты рассылки (${res.chatCount}): удалено ${res.chats.ok}${res.chats.fail ? `, не удалось ${res.chats.fail}` : ""}.`,
				res.channel.fail || res.chats.fail ? "Часть сообщений не удалилась — вероятно, они старше 48 часов или у бота нет прав на удаление в чате." : ""
			].filter(Boolean).join("\n")
		});
		await renderAdmin(cb, adminDeleteList(0));
		return;
	}
	if (action === "bn") {
		bannerSetup.delete(String(chatId));
		await answer();
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "bnadd") {
		if ((bindings.banners || []).length >= MAX_BANNERS) {
			await answer("Достигнут лимит баннеров", true);
			await renderAdmin(cb, adminBanners());
			return;
		}
		bannerSetup.set(String(chatId), { phase: "media" });
		await answer("Пришлите медиа для баннера");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите картинку, видео или GIF для баннера (до 20 МБ). Следующим сообщением попрошу ссылку."
		});
		return;
	}
	if (action === "bndel") {
		removeBannerById(rest.join(":"));
		await answer("Баннер удалён");
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "ch") {
		await answer();
		await renderAdmin(cb, adminChannel());
		return;
	}
	if (action === "chset") {
		await answer("Пришлите ID канала следующим сообщением");
		await askPublishChannel(chatId);
		return;
	}
	await answer();
}
function relayListHtml() {
	const list = bindings.relayChats || [];
	const by = (status) => list.filter((c) => c.status === status);
	const line = (c) => `• ${escapeHtml(c.title || "без названия")} — <code>${escapeHtml(c.id)}</code>`;
	const lines = [
		`<b>Чаты рассылки</b>: включено ${by("on").length}, ждут решения ${by("pending").length}, выключено ${by("off").length}`,
		"",
		"<b>Включены</b>",
		...by("on").length ? by("on").map(line) : ["—"]
	];
	if (by("pending").length) lines.push("", "<b>Ждут решения</b>", ...by("pending").map(line));
	lines.push("", "Включить вручную: /relay_on -100…", "Выключить: /relay_off -100…");
	return splitHtml(lines.join("\n"));
}
async function handleRelayCommand(arbiterChatId, cmd, arg) {
	if (cmd === "relays") {
		for (const part of relayListHtml()) await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true
		});
		return;
	}
	const raw = arg.trim().split(/\s+/)[0] || "";
	if (!/^-\d{5,20}$/.test(raw)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: `Укажите ID чата: /${cmd} -100…\nСписок: /relays`
		});
		return;
	}
	const chat = await tgSoft("getChat", { chat_id: raw });
	if (cmd === "relay_on" && !chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Бот не видит этот чат. Сначала добавьте бота в чат, потом повторите команду."
		});
		return;
	}
	if (chat && (isOfficialArbiterChat(chat.id) || isOfficialChannel(chat.id))) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный чат, рассылка туда не нужна."
		});
		return;
	}
	const target = chat ? {
		id: chat.id,
		type: chat.type,
		title: chat.title
	} : { id: raw };
	upsertRelay(target, cmd === "relay_on" ? "on" : "off");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: `${cmd === "relay_on" ? "Рассылка включена" : "Рассылка выключена"}: ${escapeHtml(chat?.title || raw)}\nID: <code>${escapeHtml(String(target.id))}</code>`,
		parse_mode: "HTML"
	});
}
async function parseChannelRef(raw) {
	const t = raw.trim().split(/\s+/)[0] || "";
	if (!t) return null;
	if (t.startsWith("@")) return t;
	const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
	if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
	const num = t.replace(/[^\d-]/g, "");
	if (/^-100\d{6,}$/.test(num)) return num;
	if (/^100\d{6,}$/.test(num)) return `-${num}`;
	if (/^\d{6,}$/.test(num)) return `-100${num}`;
	return t;
}
async function applyPublishChannel(arbiterChatId, raw) {
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
			parse_mode: "HTML"
		});
		return;
	}
	const chat = await chatReachable(ref);
	if (!chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз."
		});
		return;
	}
	if (chat.type !== "channel" && chat.type !== "supergroup") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не канал. Нужен ID канала, куда постить одобренные заявки."
		});
		return;
	}
	bindings.channelId = String(chat.id);
	saveBindings();
	channelSetup.delete(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал для постов обновлён.",
			escapeHtml(chat.title || "Канал"),
			`ID: <code>${chat.id}</code>`
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function askPublishChannel(arbiterChatId) {
	channelSetup.add(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			`Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
			"",
			"Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
			"Бот должен быть админом этого канала.",
			"",
			"Или сразу: /channel -100…"
		].join("\n"),
		parse_mode: "HTML"
	});
}
var seenUpdates = /* @__PURE__ */ new Set();
async function handleUpdate(update) {
	if (typeof update?.update_id === "number") {
		if (seenUpdates.has(update.update_id)) return;
		seenUpdates.add(update.update_id);
		if (seenUpdates.size > 5e3) seenUpdates.delete(seenUpdates.values().next().value);
	}
	try {
		await handleTelegramUpdate(update);
	} catch (err) {
		if (!isDisconnectError(err)) console.error("[epb] update", err);
	}
}
async function handleTelegramUpdate(update) {
	ensureBotProfile();
	const post = update.channel_post || update.edited_channel_post;
	if (post) {
		const ch = isCheckChannel(post.chat.id);
		if (ch) {
			if (post.chat.title && post.chat.title !== ch.title) {
				ch.title = post.chat.title;
				saveBindings();
			}
			indexCheckPost(ch, post.message_id, post.text || post.caption || "", post.date || 0);
		}
		return;
	}
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.message?.reply_to_message?.from);
	rememberUser(update.message?.reply_to_message?.forward_from);
	rememberUser(update.callback_query?.from);
	for (const ent of [
		...update.message?.entities || [],
		...update.message?.caption_entities || [],
		...update.message?.reply_to_message?.entities || []
	]) rememberUser(ent.user);
	const groupMsg = update.message;
	if (groupMsg && (groupMsg.chat.type === "group" || groupMsg.chat.type === "supergroup")) {
		if (groupMsg.migrate_to_chat_id) onChatMigrated(String(groupMsg.chat.id), String(groupMsg.migrate_to_chat_id));
		if (groupMsg.migrate_from_chat_id) onChatMigrated(String(groupMsg.migrate_from_chat_id), String(groupMsg.chat.id));
		if (!isOfficialArbiterChat(groupMsg.chat.id)) return;
	}
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "");
	const liveSession = sessions.get(floodId);
	const incoming = update.message;
	const evidenceBurst = liveSession?.step === "evidence" && Boolean(incoming?.photo?.length || incoming?.video || incoming?.document);
	if (tooMany("upd:global", 600, 6e4)) return;
	if (floodId && !evidenceBurst && tooMany(`flood:${floodId}`, 80, 6e4)) return;
	if (liveSession) liveSession.touched = Date.now();
	gcSessions();
	if (update.message?.chat.type === "private") touchUser(update.message.from?.id);
	if (update.callback_query?.message?.chat.type === "private") touchUser(update.callback_query.from?.id);
	const member = update.my_chat_member;
	if (member) {
		if (member.chat.type === "private") {
			touchUser(member.chat.id, member.new_chat_member.status === "kicked");
			return;
		}
		if (!isGroupOrChannel(member.chat)) return;
		const status = member.new_chat_member.status;
		if (status === "left" || status === "kicked") {
			dropRelay(member.chat.id);
			return;
		}
		if (status === "member" || status === "administrator" || status === "creator") {
			const before = member.old_chat_member?.status;
			await bindChat(member.chat, member.from, !before || before === "left" || before === "kicked");
		}
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if (cb.data === "owners") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, ownersText(locale), ownersKeyboard(locale));
			return;
		}
		if (cb.data === "home") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			checkWait.delete(String(cb.message.chat.id));
			const locale = langOf(cb.from?.id);
			await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			return;
		}
		if (cb.data === "bsponsors") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, await botSponsorsText(locale), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "bcheck") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			if (!checkEnabled() || cb.message.chat.type !== "private") return;
			const locale = langOf(cb.from?.id);
			checkWait.add(String(cb.message.chat.id));
			await editCard(cb, tb(locale, "checkPrompt"), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "lang") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await editCard(cb, LANG_PROMPT, langKeyboard(true));
			return;
		}
		if (cb.data === "lang:ru" || cb.data === "lang:en") {
			const locale = cb.data.endsWith("en") ? "en" : "ru";
			if (cb.from?.id) setLang(cb.from.id, locale);
			tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: tb(locale, "langSaved")
			});
			if (Boolean(cb.message.photo || cb.message.caption)) await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			else {
				tgSoft("deleteMessage", {
					chat_id: cb.message.chat.id,
					message_id: cb.message.message_id
				});
				await replyStart(cb.message.chat.id, cb.from?.id);
			}
			return;
		}
		if (cb.data.startsWith("ub:")) {
			if (await handleOwnerCallback(cb)) return;
		}
		if (cb.data.startsWith("adm:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleAdminCallback(cb);
			return;
		}
		if (cb.data.startsWith("rel:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
			return;
		}
		if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:") || /^p(edit|view|orig):/.test(cb.data)) && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (alreadyHandled(text)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub" || cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch")) {
			const markup = publishChoiceKeyboard(parseAppKey(text, cb.data));
			if (!await replaceReplyMarkup(cb.message, markup)) await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: "Как опубликовать эту заявку?",
				reply_to_message_id: cb.message.message_id,
				reply_markup: markup
			});
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Выберите тип публикации"
			});
			return;
		}
		if (/^p(edit|view|orig):/.test(cb.data)) {
			const [action, key = ""] = cb.data.split(":");
			const rec = pendingPosts[key];
			if (!rec || (rec.status || "pending") !== "pending") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже обработана",
					show_alert: true
				});
				return;
			}
			if (action === "pedit") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Ответьте на сообщение бота новым текстом"
				});
				await askPostEdit(cb.message.chat.id, key);
			} else if (action === "pview") {
				await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			} else {
				delete rec.postHtml;
				savePending();
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Вернули исходный текст"
				});
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			}
			return;
		}
		if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			const relay = cb.data.startsWith("puball");
			const key = parseAppKey(text, cb.data);
			if (!await publishFromMessage(key && pendingPosts[key] ? `#epb u=${pendingPosts[key].username || ""} id=${pendingPosts[key].id || "0"} k=${key}` : text, cb.id, extraFiles, relay, key, {
				chatId: cb.message.chat.id,
				messageId: cb.message.message_id
			})) return;
			const next = `${escapeHtml(stripServiceMarker(text || "Заявка"))}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
			const cleared = { inline_keyboard: [] };
			if (!await replaceReplyMarkup(cb.message, cleared, next)) await tgSoft("editMessageReplyMarkup", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				reply_markup: cleared
			});
			return;
		}
		if (cb.data === "rej" || cb.data.startsWith("rej:")) {
			const key = parseAppKey(text, cb.data);
			const record = key ? pendingPosts[key] : void 0;
			if (record?.status === "published" || key && publishing.has(key)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже опубликована",
					show_alert: true
				});
				return;
			}
			if (record && record.status !== "rejected") {
				record.status = "rejected";
				savePending();
				await notifyApplicant(record, key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${escapeHtml(stripServiceMarker(text))}\n\nСтатус: отклонено`;
			await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		const fromId = msg.from?.id;
		if (fromId && !hasLang(fromId)) {
			await askLanguage(msg.chat.id);
			return;
		}
		await replyStart(msg.chat.id, fromId);
		return;
	}
	if (cmd === "lang") {
		await askLanguage(msg.chat.id, hasLang(msg.from?.id));
		return;
	}
	if (cmd === "channel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
		if (arg) await applyPublishChannel(msg.chat.id, arg);
		else await askPublishChannel(msg.chat.id);
		return;
	}
	if (cmd === "admin" || cmd === "menu" || cmd === "panel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await sendAdminPanel(msg.chat.id);
		return;
	}
	if (cmd === "checkon" || cmd === "checkoff") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		bindings.checkEnabled = cmd === "checkon";
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: cmd === "checkon" ? "Проверка контрагента включена." : "Проверка контрагента выключена и скрыта."
		});
		return;
	}
	if (cmd === "audience") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const n = Number((msg.text || "").replace(/[^\d]/g, ""));
		if (!setAudienceBase(n)) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Укажите число, например: /audience 20178"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `Базовая аудитория обновлена: ~${n.toLocaleString("ru-RU")}. Показывается в приложении (с учётом реального числа участников чатов).`
		});
		return;
	}
	if (cmd === "emoji") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim().toLowerCase();
		if (arg === "on" || arg === "off") {
			bindings.customEmoji = arg === "on";
			saveBindings();
		}
		const state = customEmojiEnabled() ? "включены" : "выключены";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: arg === "on" || arg === "off" ? `Премиум-эмодзи ${state}. Работают в личных сообщениях бота (меню и шаги жалобы), пока у владельца активен Telegram Premium.` : `Премиум-эмодзи сейчас ${state}. Включить: /emoji on · выключить: /emoji off`
		});
		return;
	}
	if (cmd === "usearch") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim();
		if (!arg) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Проверка поиска по юзернейму. Пришлите: /usearch @username"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Проверяю поиск…"
		});
		const report = await diagnoseUserSearch(arg);
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: report
		});
		return;
	}
	if (cmd === "userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id) || !checkEnabled()) return;
		await sendOwnerPanel(msg.chat.id);
		return;
	}
	if (cmd === "cancel_userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		await loginStates.get(String(msg.chat.id))?.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(msg.chat.id));
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Подключение отменено."
		});
		return;
	}
	if (cmd === "relays" || cmd === "relay_on" || cmd === "relay_off") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await handleRelayCommand(msg.chat.id, cmd, (msg.text || "").split(/\s+/).slice(1).join(" "));
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: btUser(msg.from?.id, "applyInGroup", { bot: BOT_USERNAME })
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) return;
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда.",
					"",
					`Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
					"Сменить: /channel -100…"
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && bannerSetup.has(String(msg.chat.id)) && await handleBannerInput(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && collectDmAlbumItem(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handleDmReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handlePostEditReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && removeFromCheckSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyRemoveFromCheck(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && addBlacklistSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyAddToBlacklist(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && sponsorLinkSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applySponsorLink(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && checkChannelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyCheckChannel(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyPublishChannel(msg.chat.id, msg.text);
		return;
	}
	if (msg.chat.type !== "private") return;
	if (isOwner(msg.from?.id) && !cmd && ownerLoginActive(msg.chat.id) && msg.text) {
		if (await handleOwnerLogin(msg.chat.id, msg.text)) return;
	}
	if (checkWait.has(String(msg.chat.id)) && msg.text && !cmd) {
		checkWait.delete(String(msg.chat.id));
		await runBotCheck(msg.chat.id, msg.text);
		return;
	}
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	if (await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: webhookSecret(),
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member",
			"channel_post",
			"edited_channel_post"
		],
		drop_pending_updates: false
	})) {
		bindings.webhookStamp = webhookStamp();
		saveBindings();
	}
	return {
		ok: true,
		url: clean
	};
}
var webhookArmed = false;
async function configureFromOrigin(_origin) {
	const site = publicSiteUrl();
	if (!site) return {
		configured: false,
		reason: "need_https"
	};
	if (!webhookArmed) {
		webhookArmed = true;
		ensureProductionWebhook();
	}
	return {
		configured: true,
		url: site
	};
}
if (botToken() && (process.env.PUBLIC_URL || true)) setTimeout(() => void ensureBotProfile().catch(() => {}), 3e3);
if (botToken() && broadcastJobs.length) setTimeout(resumeBroadcasts, 5e3);
if (botToken() && dmJobs.length) setTimeout(resumeDmJobs, 6e3);
//#endregion
export { parseDamageAmount as C, waitForTelegramUser as D, telegramInitData as E, openExternal as S, readTelegramWebUser as T, CHANNEL_URL as _, bannerById as a, lockTelegramViewport as b, isDisconnectError as c, sponsorAvatarPath as d, telegram_bot_server_exports as f, webhookSecretMatches as g, verifyTelegramInitData as h, appendEvidenceChunk as i, resolveHandleServer as l, verifyEvidenceDownload as m, allowEvidenceDownload as n, bannerFilePath as o, uploadedEvidencePath as p, allowEvidenceUpload as r, handleUpdate as s, allowEvidenceChunk as t, saveUploadedEvidence as u, bootTelegramWebApp as v, parseTelegramInput as w, lookupTelegramHandle as x, haptic as y };
