import { a as t } from "./i18n-BJWtIYqJ.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.functions-B_N17vTo.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus_createServerFn_handler = createServerRpc({
	id: "35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b",
	name: "getTelegramStatus",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getTelegramStatus.__executeServer(opts));
var getTelegramStatus = createServerFn({ method: "GET" }).handler(getTelegramStatus_createServerFn_handler, async () => {
	const { getBotStatus } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	return getBotStatus();
});
var resolveTelegramHandle_createServerFn_handler = createServerRpc({
	id: "ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093",
	name: "resolveTelegramHandle",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => resolveTelegramHandle.__executeServer(opts));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(4096).optional()
})).handler(resolveTelegramHandle_createServerFn_handler, async ({ data }) => {
	const { resolveHandleServer, verifyTelegramInitData } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		username: "",
		id: "",
		source: "unresolved"
	};
	return resolveHandleServer(data.input, authed.id);
});
var evidenceSchema = object({
	id: string().max(40),
	kind: _enum(["image", "video"]),
	name: string().max(200),
	size: number().nonnegative().max(2147483647),
	mime: string().max(80),
	dataUrl: string().max(80).optional().default(""),
	storageKey: string().max(80).optional()
});
var personSchema = object({
	username: string().max(64),
	telegramId: string().max(20),
	firstName: string().max(64).optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(5e3),
	summary: string().min(10).max(800),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().max(16384).optional(),
	locale: _enum(["ru", "en"]).optional()
});
var submitToTelegram_createServerFn_handler = createServerRpc({
	id: "60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359",
	name: "submitToTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => submitToTelegram.__executeServer(opts));
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(submitToTelegram_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const locale = data.locale === "en" ? "en" : "ru";
	const authed = bot.verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		ok: false,
		error: t(locale, "errOpenBot")
	};
	bot.saveUserLocaleServer(authed.id, locale);
	const app = {
		id: data.id,
		createdAt: data.createdAt,
		status: data.status,
		victim: {
			username: authed.username || "",
			telegramId: authed.id
		},
		scammer: data.scammer,
		scammers: data.scammers,
		story: data.story,
		summary: data.summary,
		damageAmount: data.damageAmount,
		damageCurrency: data.damageCurrency,
		evidence: data.evidence
	};
	return bot.sendApplicationToArbiters(app);
});
var configureTelegram_createServerFn_handler = createServerRpc({
	id: "308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e",
	name: "configureTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => configureTelegram.__executeServer(opts));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(configureTelegram_createServerFn_handler, async ({ data }) => {
	const { configureFromOrigin } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	return configureFromOrigin(data.origin);
});
var getMyComplaints_createServerFn_handler = createServerRpc({
	id: "8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da",
	name: "getMyComplaints",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getMyComplaints.__executeServer(opts));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({
	telegramId: string().min(1).max(20),
	initData: string().max(4096).optional()
})).handler(getMyComplaints_createServerFn_handler, async ({ data }) => {
	const { listComplaintsForUser, verifyTelegramInitData } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return [];
	return listComplaintsForUser(authed.id);
});
var saveUserLocale_createServerFn_handler = createServerRpc({
	id: "11d2abc3e6b37013d6db0d65775d802606c07fa20c30974f0bdb6267adcd933f",
	name: "saveUserLocale",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => saveUserLocale.__executeServer(opts));
var saveUserLocale = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	locale: _enum(["ru", "en"])
})).handler(saveUserLocale_createServerFn_handler, async ({ data }) => {
	const { verifyTelegramInitData, saveUserLocaleServer } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const authed = verifyTelegramInitData(data.initData);
	if (!authed) return { ok: false };
	saveUserLocaleServer(authed.id, data.locale);
	return { ok: true };
});
var checkCounterparty_createServerFn_handler = createServerRpc({
	id: "2d472c3ddcd5f68c787b571931a54cb87506748cc8d6701b6ba316f30d5f9c13",
	name: "checkCounterparty",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => checkCounterparty.__executeServer(opts));
var checkCounterparty = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(16384)
})).handler(checkCounterparty_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const gate = bot.allowCheck(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		result: await bot.checkCounterparty(data.input)
	};
});
var getFeatures_createServerFn_handler = createServerRpc({
	id: "1e6f5eee2bcdda2bc5a98f0ab7b0ce73f7b151332e14ed173cef508c1244730a",
	name: "getFeatures",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getFeatures.__executeServer(opts));
var getFeatures = createServerFn({ method: "GET" }).handler(getFeatures_createServerFn_handler, async () => {
	const { featuresEnabled } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	return featuresEnabled();
});
var getBanners_createServerFn_handler = createServerRpc({
	id: "c92ddbdf60c25136c999dc716b14d40a8e263c2991c82d6a7e299679f89d5a92",
	name: "getBanners",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getBanners.__executeServer(opts));
var getBanners = createServerFn({ method: "GET" }).handler(getBanners_createServerFn_handler, async () => {
	const { listBanners } = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	return listBanners();
});
var getRecentBlacklist_createServerFn_handler = createServerRpc({
	id: "de3182526ef98fe284877678fbffa5a010fe5e4a323128619c963dd2ce2e7396",
	name: "getRecentBlacklist",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getRecentBlacklist.__executeServer(opts));
var getRecentBlacklist = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(getRecentBlacklist_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const gate = bot.allowCheck(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		items: bot.recentBlacklist()
	};
});
var getBlacklistEntry_createServerFn_handler = createServerRpc({
	id: "97b5ba3a1bcbd875c36ae5b3ab4bb3ca7c878ba6e6a91dc044a5a8519dd604b4",
	name: "getBlacklistEntry",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getBlacklistEntry.__executeServer(opts));
var getBlacklistEntry = createServerFn({ method: "POST" }).validator(object({
	id: string().min(1).max(80),
	initData: string().max(16384)
})).handler(getBlacklistEntry_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-B54_DJOM.mjs").then((n) => n.d);
	const gate = bot.allowCheck(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		entry: bot.blacklistEntry(data.id)
	};
});
//#endregion
export { checkCounterparty_createServerFn_handler, configureTelegram_createServerFn_handler, getBanners_createServerFn_handler, getBlacklistEntry_createServerFn_handler, getFeatures_createServerFn_handler, getMyComplaints_createServerFn_handler, getRecentBlacklist_createServerFn_handler, getTelegramStatus_createServerFn_handler, resolveTelegramHandle_createServerFn_handler, saveUserLocale_createServerFn_handler, submitToTelegram_createServerFn_handler };
