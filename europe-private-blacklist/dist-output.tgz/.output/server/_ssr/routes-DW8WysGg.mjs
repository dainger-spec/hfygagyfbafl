import { o as __toESM } from "../_runtime.mjs";
import { _ as telegramInitData, d as CHANNEL_URL, f as bootTelegramWebApp, g as readTelegramWebUser, h as parseTelegramInput, m as lookupTelegramHandle, p as lockTelegramViewport, v as waitForTelegramUser } from "./telegram-bot.server-BypCqBaV.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as ImagePlus, c as Check, i as LoaderCircle, o as Film, r as Plus, s as ChevronLeft, t as X } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DW8WysGg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "") {
	const core = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
	return prefix ? `${prefix}-${core}` : core;
}
function r(n) {
	return Math.round(n * 100) / 100;
}
function starPoints(cx, cy, outer = 7.1, inner = 2.85) {
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const rad = i % 2 === 0 ? outer : inner;
		const a = -Math.PI / 2 + i * Math.PI / 5;
		pts.push(`${r(cx + rad * Math.cos(a))},${r(cy + rad * Math.sin(a))}`);
	}
	return pts.join(" ");
}
function EuStarsLogo({ className, size = 64, title }) {
	const stars = Array.from({ length: 12 }, (_, i) => {
		const angle = (i * 30 - 90) * Math.PI / 180;
		return {
			cx: r(50 + 36 * Math.cos(angle)),
			cy: r(50 + 36 * Math.sin(angle))
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 100",
		width: size,
		height: size,
		className: cn("text-gold", className),
		role: title ? "img" : "presentation",
		"aria-hidden": title ? void 0 : true,
		"aria-label": title,
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }) : null, stars.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: starPoints(s.cx, s.cy),
			fill: "currentColor"
		}, i))]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold tracking-tight transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-gold text-gold-fg hover:bg-gold/92",
			secondary: "bg-surface-2 text-fg hover:bg-surface shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.14)] hover:bg-surface",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface",
			danger: "bg-danger text-danger-fg hover:bg-danger/90",
			ok: "bg-ok text-ok-fg hover:bg-ok/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("flex h-11 w-full rounded-xl bg-surface px-3.5 text-base text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", "file:mr-3 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-fg", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("flex min-h-32 w-full rounded-xl bg-surface px-3.5 py-3 text-base leading-relaxed text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var MAX_FILES = 30;
var CHUNK_SIZE = 524288;
var sessionBlobs = /* @__PURE__ */ new Map();
function resizeImage(file, max = 960, quality = .8) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const objectUrl = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(objectUrl);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(objectUrl);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(objectUrl);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = objectUrl;
	});
}
async function postChunk(makeBody, attempt = 0) {
	const controller = new AbortController();
	const timer = window.setTimeout(() => controller.abort(), 45e3);
	try {
		const res = await fetch("/api/telegram/evidence", {
			method: "POST",
			body: makeBody(),
			signal: controller.signal
		});
		if (!res.ok) throw new Error(`upload ${res.status}`);
		return await res.json();
	} catch (err) {
		if (attempt >= 4) throw err;
		await new Promise((resolve) => window.setTimeout(resolve, 500 * (attempt + 1)));
		return postChunk(makeBody, attempt + 1);
	} finally {
		window.clearTimeout(timer);
	}
}
async function uploadEvidenceFile(id, file, onProgress) {
	const total = Math.max(1, Math.ceil(file.size / CHUNK_SIZE));
	let storageKey = "";
	for (let index = 0; index < total; index++) {
		const json = await postChunk(() => {
			const slice = file.slice(index * CHUNK_SIZE, Math.min(file.size, (index + 1) * CHUNK_SIZE));
			const body = new FormData();
			body.set("id", id);
			body.set("index", String(index));
			body.set("total", String(total));
			body.set("initData", telegramInitData());
			body.set("chunk", slice, file.name || "video.mp4");
			return body;
		});
		onProgress?.(index + 1, total);
		if (json.storageKey) storageKey = json.storageKey;
	}
	if (!storageKey) throw new Error("upload failed");
	return storageKey;
}
async function fileToEvidence(file, onProgress) {
	const isVideo = file.type.startsWith("video/");
	const id = uid("ev");
	if (isVideo) {
		sessionBlobs.set(id, URL.createObjectURL(file));
		const storageKey = await uploadEvidenceFile(id, file, onProgress);
		return {
			id,
			kind: "video",
			name: file.name,
			size: file.size,
			mime: file.type || "video/mp4",
			dataUrl: "",
			storageKey
		};
	}
	const dataUrl = await resizeImage(file);
	return {
		id,
		kind: "image",
		name: file.name,
		size: file.size,
		mime: "image/jpeg",
		dataUrl
	};
}
function canAddEvidence(current, incoming) {
	return current + incoming <= MAX_FILES;
}
function evidenceSrc(item) {
	return item.dataUrl || sessionBlobs.get(item.id) || "";
}
function EvidencePicker({ files, onChange }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [progress, setProgress] = (0, import_react.useState)("");
	async function addFiles(list) {
		const incoming = Array.from(list).filter((f) => f.type.startsWith("image/") || f.type.startsWith("video/"));
		if (!incoming.length) return;
		if (!canAddEvidence(files.length, incoming.length)) {
			setError(`Максимум 30 файлов`);
			return;
		}
		setError("");
		setBusy(true);
		setProgress("");
		try {
			const next = [];
			for (let i = 0; i < incoming.length; i++) {
				const file = incoming[i];
				setProgress(incoming.length > 1 ? `Загружаем ${i + 1} из ${incoming.length}…` : file.type.startsWith("video/") ? "Загружаем видео…" : "Загружаем файл…");
				next.push(await fileToEvidence(file, (done, total) => {
					setProgress(incoming.length > 1 ? `Загружаем ${i + 1} из ${incoming.length}: ${done}/${total}` : `Загружаем видео: ${done}/${total}`);
				}));
			}
			onChange([...files, ...next]);
		} catch {
			setError("Не удалось загрузить файл. Проверьте сеть и попробуйте ещё раз.");
		} finally {
			setBusy(false);
			setProgress("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*,video/*",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					if (e.target.files) addFiles(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => {
					e.preventDefault();
				},
				onDrop: (e) => {
					e.preventDefault();
					if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
				},
				className: cn("flex min-h-28 w-full flex-col items-center justify-center gap-2 rounded-2xl bg-surface px-4 py-6 text-center shadow-[0_0_0_1px_rgba(243,239,228,0.10)]", "hover:bg-surface-2"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-fg",
						children: busy ? progress || "Загружаем файлы…" : "Скрины и видео"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [
							"До ",
							30,
							" файлов. Можно перетащить сюда."
						]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-3 gap-2",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, { item: file }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "icon",
						className: "absolute top-1 right-1 size-8 rounded-full",
						onClick: () => onChange(files.filter((f) => f.id !== file.id)),
						"aria-label": "Удалить файл",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, file.id))
			}) : null
		]
	});
}
function EvidenceThumb({ item }) {
	const src = evidenceSrc(item);
	if (item.kind === "video") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square overflow-hidden rounded-lg bg-surface-2",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			className: "size-full object-cover img-outline",
			muted: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex size-full items-center justify-center text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute bottom-1 left-1 rounded-sm bg-bg/80 px-1.5 py-0.5 text-xs font-medium tracking-wide text-fg",
			children: "VIDEO"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: item.name,
		className: "aspect-square w-full rounded-lg object-cover img-outline"
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
createServerFn({ method: "GET" }).handler(createSsrRpc("35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b"));
createServerFn({ method: "POST" }).validator(object({ input: string().min(1).max(200) })).handler(createSsrRpc("ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093"));
var evidenceSchema = object({
	id: string(),
	kind: _enum(["image", "video"]),
	name: string(),
	size: number(),
	mime: string(),
	dataUrl: string().optional().default(""),
	storageKey: string().optional()
});
var personSchema = object({
	username: string(),
	telegramId: string(),
	firstName: string().optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(4500),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().optional()
});
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(createSsrRpc("60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359"));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(createSsrRpc("308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e"));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({ telegramId: string().min(1).max(20) })).handler(createSsrRpc("8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da"));
var SEED_STORY = "якобы продает фтп.\nКлянчит деньги по мелочи 50-100 баксов и включает дурачка, не может выдать, надо еще докинуть или просто игнорит.";
var SEED_AT = Date.UTC(2026, 7, 26, 12, 0, 0);
var seedPublished = {
	id: "EPB-SEED",
	createdAt: SEED_AT,
	publishedAt: SEED_AT,
	status: "published",
	victim: {
		username: "archive_epb",
		telegramId: "1000000001",
		firstName: "Archive"
	},
	scammer: {
		username: "LopataBuild",
		telegramId: "5213159067"
	},
	story: SEED_STORY,
	damageAmount: "100",
	damageCurrency: "USD",
	evidence: []
};
var emptyIdentity = {
	firstName: "",
	username: "",
	telegramId: ""
};
function safeStorage() {
	try {
		const storage = window.localStorage;
		const key = "__epb__";
		storage.setItem(key, "1");
		storage.removeItem(key);
		return storage;
	} catch {
		return {
			length: 0,
			clear() {},
			getItem() {
				return null;
			},
			key() {
				return null;
			},
			removeItem() {},
			setItem() {}
		};
	}
}
var useBlacklistStore = create()(persist((set) => ({
	identity: emptyIdentity,
	applications: [seedPublished],
	setIdentity: (patch) => set((s) => ({ identity: {
		...s.identity,
		...patch
	} })),
	submitApplication: (app) => set((s) => ({ applications: [app, ...s.applications] })),
	publishApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "published",
		publishedAt: Date.now()
	} : a) })),
	rejectApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "rejected",
		rejectedAt: Date.now()
	} : a) })),
	resetDemo: () => set({
		identity: emptyIdentity,
		applications: [seedPublished]
	})
}), {
	name: "epb-blacklist",
	storage: createJSONStorage(() => safeStorage()),
	skipHydration: true,
	partialize: (s) => ({ applications: s.applications })
}));
function rehydrateBlacklistStore() {
	useBlacklistStore.persist.rehydrate();
}
var CURRENCIES = [
	"EUR",
	"USD",
	"USDT",
	"RUB"
];
var MAX_ACCOUNTS = 8;
function emptyAcc() {
	return {
		key: uid("acc"),
		input: "",
		username: "",
		id: ""
	};
}
function ApplyForm({ onSubmitted }) {
	const identity = useBlacklistStore((s) => s.identity);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const submitApplication = useBlacklistStore((s) => s.submitApplication);
	const [victimUser, setVictimUser] = (0, import_react.useState)(identity.username);
	const [victimId, setVictimId] = (0, import_react.useState)(identity.telegramId);
	const [victimResolving, setVictimResolving] = (0, import_react.useState)(false);
	const [accounts, setAccounts] = (0, import_react.useState)([emptyAcc()]);
	const [story, setStory] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("EUR");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [formError, setFormError] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const fromTelegram = (0, import_react.useMemo)(() => Boolean(readTelegramWebUser()), []);
	(0, import_react.useEffect)(() => {
		const tg = readTelegramWebUser();
		if (!tg) return;
		setIdentity(tg);
		setVictimUser(tg.username);
		setVictimId(tg.telegramId);
	}, [setIdentity]);
	(0, import_react.useEffect)(() => {
		const handle = victimUser.trim();
		if (!handle || fromTelegram) return;
		let cancelled = false;
		setVictimResolving(true);
		const t = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await lookupTelegramHandle(handle);
				} catch {
					res = null;
				}
				if (cancelled) return;
				setVictimResolving(false);
				if (res?.id) {
					setVictimId(res.id);
					setIdentity({
						username: res.username || handle.replace(/^@/, ""),
						telegramId: res.id
					});
				}
			})();
		}, 480);
		return () => {
			cancelled = true;
			clearTimeout(t);
		};
	}, [
		victimUser,
		fromTelegram,
		setIdentity
	]);
	async function onSubmit(e) {
		e.preventDefault();
		setFormError("");
		const vUser = victimUser.replace(/^@/, "").trim();
		if (!vUser) {
			setFormError("Укажите ваш Telegram, чтобы арбитры могли связаться");
			return;
		}
		if (!victimId) {
			setFormError("ID пострадавшего ещё подтягивается");
			return;
		}
		const filled = accounts.map((a) => ({
			username: a.username.replace(/^@/, "").trim(),
			telegramId: a.id.trim()
		})).filter((a) => a.username || a.telegramId);
		if (!filled.length) {
			setFormError("Укажите хотя бы один аккаунт");
			return;
		}
		if (filled.some((a) => !a.username && !a.telegramId)) {
			setFormError("Укажите username или ID аккаунта");
			return;
		}
		if (story.trim().length < 20) {
			setFormError("Опишите схему подробнее (от 20 символов)");
			return;
		}
		if (story.trim().length > 4500) {
			setFormError("Описание слишком длинное - до 4500 символов");
			return;
		}
		if (!amount.trim() || Number(amount) <= 0) {
			setFormError("Укажите сумму ущерба");
			return;
		}
		if (!files.length) {
			setFormError("Прикрепите хотя бы одно доказательство");
			return;
		}
		setSending(true);
		const app = {
			id: `EPB-${uid().slice(0, 4).toUpperCase()}`,
			createdAt: Date.now(),
			status: "pending",
			victim: {
				username: vUser,
				telegramId: victimId,
				firstName: identity.firstName
			},
			scammer: filled[0],
			scammers: filled,
			story: story.trim(),
			damageAmount: amount.trim(),
			damageCurrency: currency,
			evidence: files,
			initData: telegramInitData()
		};
		submitApplication(app);
		setIdentity({
			username: vUser,
			telegramId: victimId
		});
		let notice = "Заявка сохранена. Telegram ещё не принял - добавьте бота в чат арбитров.";
		try {
			const tg = await submitToTelegram({ data: app });
			notice = tg.ok ? "Заявка ушла в чат арбитров в Telegram." : tg.error || notice;
		} catch {}
		setSending(false);
		onSubmitted(notice);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex min-h-0 flex-1 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-md flex-col gap-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: "Пострадавший"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: fromTelegram ? "Данные из Telegram. Username нужен, чтобы арбитры могли написать вам." : "Username нужен, чтобы арбитры могли написать вам."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ваш Telegram",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: victimUser ? victimUser.startsWith("@") ? victimUser : `@${victimUser}` : "",
									onChange: (e) => setVictimUser(e.target.value.replace(/^@/, "")),
									placeholder: "@username",
									autoComplete: "username",
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdStatus, {
								label: "Ваш ID",
								idValue: victimId,
								resolving: victimResolving,
								emptyText: "Подтянется из username"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: "Аккаунт"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "@username или t.me. Если несколько аккаунтов - добавьте все."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: accounts.map((acc, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScammerAccountRow, {
									index,
									row: acc,
									canRemove: accounts.length > 1,
									onChange: (next) => setAccounts((prev) => prev.map((item) => item.key === acc.key ? {
										...item,
										...next
									} : item)),
									onRemove: () => setAccounts((prev) => prev.filter((item) => item.key !== acc.key))
								}, acc.key))
							}),
							accounts.length < MAX_ACCOUNTS ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-surface text-sm font-semibold text-gold shadow-[0_0_0_1px_rgba(240,196,48,0.28)] hover:bg-surface-2",
								onClick: () => setAccounts((prev) => [...prev, emptyAcc()]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Ещё аккаунт"]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: "Суть обмана"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Как связывались, что обещали, куда просили перевести. Этот текст уйдёт в пост, если заявку одобрят."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: story,
								onChange: (e) => setStory(e.target.value.slice(0, 4500)),
								maxLength: 4500,
								placeholder: "Например: якобы продаёт FTP, клянчит по 50-100$, включает дурачка и пропадает."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Сумма ущерба",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: amount,
										onChange: (e) => setAmount(e.target.value.replace(/[^\d.,]/g, "")),
										placeholder: "100"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Валюта",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-11 grid-cols-4 overflow-hidden rounded-xl shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
										children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCurrency(c),
											className: cn("h-11 px-1 text-xs font-semibold transition-colors", currency === c ? "bg-gold text-gold-fg" : "bg-surface text-muted hover:text-fg"),
											children: c
										}, c))
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg font-bold",
								children: "Доказательства"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Переписка, чеки, видеозвонки."
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePicker, {
							files,
							onChange: setFiles
						})]
					}),
					formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: formError
					}) : null
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0 border-t border-line bg-bg px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				className: "w-full",
				disabled: sending,
				children: sending ? "Отправляем…" : "Отправить на рассмотрение"
			})
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function ScammerAccountRow({ index, row, canRemove, onChange, onRemove }) {
	const [resolving, setResolving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const value = row.input.trim();
		setError("");
		if (!value) {
			if (row.username || row.id) onChange({
				username: "",
				id: ""
			});
			return;
		}
		const parsed = parseTelegramInput(value);
		onChange({ username: parsed.username });
		if (parsed.id) {
			onChange({
				username: parsed.username,
				id: parsed.id
			});
			setResolving(false);
			return;
		}
		let cancelled = false;
		setResolving(true);
		const t = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await lookupTelegramHandle(value);
				} catch {
					res = null;
				}
				if (cancelled) return;
				setResolving(false);
				if (!res) {
					onChange({
						username: "",
						id: ""
					});
					setError("Не удалось разобрать username или ID");
					return;
				}
				if (res.id) {
					onChange({
						username: res.username,
						id: res.id
					});
					setError("");
					return;
				}
				onChange({
					username: res.username,
					id: ""
				});
				setError("ID не найден. Перешлите боту сообщение этого человека и введите @username ещё раз - или вставьте числовой ID.");
			})();
		}, 480);
		return () => {
			cancelled = true;
			clearTimeout(t);
		};
	}, [row.input]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl bg-surface/70 p-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-muted",
					children: ["Аккаунт ", index + 1]
				}), canRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
					onClick: onRemove,
					"aria-label": "Удалить аккаунт",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Telegram",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.input,
					onChange: (e) => onChange({ input: e.target.value }),
					placeholder: "@username или t.me",
					required: index === 0
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ID",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.id,
					onChange: (e) => {
						onChange({ id: e.target.value.replace(/\D/g, "").slice(0, 15) });
						setError("");
					},
					placeholder: "Вставьте числовой ID",
					inputMode: "numeric",
					required: false
				})
			}),
			resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1.5 text-sm text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), "Подтягиваем ID…"]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null
		]
	});
}
function IdStatus({ label, idValue, resolving, emptyText }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-xl bg-surface px-3 py-2.5 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-muted",
			children: label
		}), resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-1.5 text-sm text-gold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), "Подтягиваем ID…"]
		}) : idValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: idValue
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-subtle",
			children: emptyText
		})] }), idValue && !resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-8 items-center justify-center rounded-full bg-ok/15 text-ok",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
		}) : null]
	});
}
var STATUS_LABEL = {
	pending: "Подано",
	published: "Одобрено",
	rejected: "Отклонено"
};
function MiniApp({ page, onPage, onClose, onReview, embedded = false }) {
	const [notice, setNotice] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const identity = useBlacklistStore((s) => s.identity);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const openComplaint = (0, import_react.useCallback)(() => onPage("apply"), [onPage]);
	const openHistory = (0, import_react.useCallback)(() => onPage("history"), [onPage]);
	(0, import_react.useEffect)(() => {
		rehydrateBlacklistStore();
		bootTelegramWebApp();
		const unlock = lockTelegramViewport();
		let cancelled = false;
		(async () => {
			const user = await waitForTelegramUser(2500) || readTelegramWebUser();
			if (cancelled) return;
			if (user) try {
				setIdentity(user);
			} catch {}
			setReady(true);
		})();
		return () => {
			cancelled = true;
			unlock();
		};
	}, [setIdentity]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex flex-col overflow-hidden overscroll-none bg-bg text-fg", !embedded && "z-50"),
		style: {
			position: "fixed",
			left: 0,
			right: 0,
			top: "var(--app-top, 0px)",
			height: "var(--app-h, 100dvh)",
			maxHeight: "var(--app-h, 100dvh)",
			paddingTop: "var(--tg-safe-top, 0px)"
		},
		children: [ready && page !== "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute left-2 z-10 flex size-11 items-center justify-center rounded-xl text-fg hover:bg-surface",
			style: { top: "calc(var(--tg-safe-top, 0px) + 4px)" },
			onClick: () => onPage("home"),
			"aria-label": "Назад",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex min-h-0 flex-1 flex-col overflow-hidden", ready && page !== "home" && "pt-10"),
			children: [
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountLoading, {}) : null,
				ready && page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, {
					identity,
					onComplaint: openComplaint,
					onHistory: openHistory
				}) : null,
				ready && page === "apply" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyForm, { onSubmitted: (msg) => {
					setNotice(msg ?? "");
					onPage("done");
				} }) : null,
				ready && page === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { telegramId: identity.telegramId }) : null,
				ready && page === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, {
					onPage,
					onClose,
					onReview,
					notice
				}) : null
			]
		})]
	});
}
function AccountLoading() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 96,
				title: "Europe Private Blacklist"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mt-8 size-8 animate-spin text-gold" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-display text-lg font-bold",
				children: "Подключаем Telegram"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
				children: "Подождите, подтягиваем ваш аккаунт. Это займёт пару секунд."
			})
		]
	});
}
function Home$1({ identity, onComplaint, onHistory }) {
	const handle = identity.username ? `@${identity.username}` : identity.firstName || (identity.telegramId ? `ID ${identity.telegramId}` : "");
	const canUse = Boolean(identity.telegramId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto overscroll-contain px-4 py-8 text-center [touch-action:pan-y]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 104,
				title: "Europe Private Blacklist"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-7 font-display text-3xl font-extrabold tracking-tight",
				children: ["Europe Private", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-gold",
					children: "Blacklist"
				})]
			}),
			handle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-subtle",
				children: ["Вы вошли как ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium text-fg",
					children: handle
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-subtle",
				children: "Откройте Mini App из бота Telegram, чтобы войти своим аккаунтом."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex w-full max-w-md flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full rounded-xl",
						onClick: onComplaint,
						disabled: !canUse,
						children: "Подать жалобу"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full rounded-xl",
						onClick: onHistory,
						disabled: !canUse,
						children: "История жалоб"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "lg",
						variant: "outline",
						className: "w-full rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: CHANNEL_URL,
							target: "_blank",
							rel: "noreferrer",
							children: "Наш канал"
						})
					})
				]
			})
		]
	});
}
function History({ telegramId }) {
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		async function load() {
			if (!telegramId) {
				setItems([]);
				return;
			}
			try {
				const list = await getMyComplaints({ data: { telegramId } });
				if (!cancelled) setItems(list);
			} catch {
				if (!cancelled) setItems([]);
			}
		}
		load();
		const t = window.setInterval(() => void load(), 8e3);
		return () => {
			cancelled = true;
			window.clearInterval(t);
		};
	}, [telegramId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-md space-y-3",
			children: items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center justify-center gap-2 py-16 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-gold" }), "Загружаем историю…"]
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-sm text-muted",
				children: "Пока нет поданных жалоб."
			}) : items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryCard, { item }, item.id))
		})
	});
}
function HistoryCard({ item }) {
	const handle = item.scammerUsername ? item.scammerUsername.split(" · ").map((u) => {
		const name = u.replace(/^@/, "").trim();
		return name ? `@${name}` : "";
	}).filter(Boolean).join(" · ") : "без username";
	const when = item.createdAt ? new Date(item.createdAt).toLocaleString("ru-RU", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}) : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "rounded-2xl bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold leading-snug break-words",
						children: handle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs text-subtle break-words",
						children: [item.scammerId ? `Id: ${item.scammerId}` : "Id: -", item.amount ? ` · ${item.amount} ${item.currency}` : ""]
					}),
					when ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-subtle",
						children: when
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: item.status })]
		})
	});
}
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold", status === "pending" && "bg-gold/15 text-gold", status === "published" && "bg-ok/15 text-ok", status === "rejected" && "bg-danger/15 text-danger"),
		children: STATUS_LABEL[status]
	});
}
function Done({ onPage, onClose, onReview, notice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto overscroll-contain px-5 py-10 text-center [touch-action:pan-y]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-16 items-center justify-center rounded-full bg-gold text-gold-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
					size: 40,
					className: "text-gold-fg"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl font-bold",
				children: "Жалоба у арбитров"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: notice || "Материалы ушли в закрытый чат. Если кейс подтвердят - пост выйдет в канал. Если нет - публикации не будет."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex w-full max-w-md flex-col gap-3",
				children: [
					onReview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onReview,
						children: "Открыть чат арбитров"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: () => onPage("history"),
						children: "История жалоб"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full",
						onClick: () => onPage("home"),
						children: "На главную"
					}),
					onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "ghost",
						className: "w-full",
						onClick: onClose,
						children: "Закрыть приложение"
					}) : null
				]
			})
		]
	});
}
function Home() {
	const [page, setPage] = (0, import_react.useState)("home");
	const [canClose, setCanClose] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		bootTelegramWebApp();
		setCanClose(Boolean(window.Telegram?.WebApp?.close));
		configureTelegram({ data: { origin: window.location.origin } }).catch(() => {});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniApp, {
		page,
		onPage: setPage,
		embedded: true,
		onClose: canClose ? () => window.Telegram?.WebApp?.close?.() : void 0
	});
}
//#endregion
export { Home as component };
