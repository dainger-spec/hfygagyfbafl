import { a as t } from "./i18n-DtQf35Yd.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
// node_modules/.nitro/vite/services/ssr/assets/telegram-bot.functions-B5xq4OHX.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus_createServerFn_handler = createServerRpc({
	id: "35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b",
	name: "getTelegramStatus",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getTelegramStatus.__executeServer(opts));
var getTelegramStatus = createServerFn({ method: "GET" }).handler(getTelegramStatus_createServerFn_handler, async () => {
	const { getBotStatus } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return getBotStatus();
});
var resolveTelegramHandle_createServerFn_handler = createServerRpc({
	id: "ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093",
	name: "resolveTelegramHandle",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => resolveTelegramHandle.__executeServer(opts));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(4096).optional()
})).handler(resolveTelegramHandle_createServerFn_handler, async ({ data }) => {
	const { resolveHandleServer, verifyTelegramInitData } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		username: "",
		id: "",
		source: "unresolved"
	};
	return resolveHandleServer(data.input, authed.id);
});
var evidenceSchema = object({
	id: string().max(40),
	kind: _enum(["image", "video"]),
	name: string().max(200),
	size: number().nonnegative().max(2147483647),
	mime: string().max(80),
	dataUrl: string().max(80).optional().default(""),
	storageKey: string().max(80).optional()
});
var personSchema = object({
	username: string().max(64),
	telegramId: string().max(20),
	firstName: string().max(64).optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(5e3),
	summary: string().min(10).max(800),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().max(16384).optional(),
	locale: _enum(["ru", "en"]).optional()
});
var submitToTelegram_createServerFn_handler = createServerRpc({
	id: "60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359",
	name: "submitToTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => submitToTelegram.__executeServer(opts));
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(submitToTelegram_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const locale = data.locale === "en" ? "en" : "ru";
	const authed = bot.verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		ok: false,
		error: t(locale, "errOpenBot")
	};
	if (!bot.hasSubmitPass(authed.id)) return {
		ok: false,
		error: "captcha"
	};
	bot.saveUserLocaleServer(authed.id, locale);
	const app = {
		id: data.id,
		createdAt: data.createdAt,
		status: data.status,
		victim: {
			username: authed.username || "",
			telegramId: authed.id
		},
		scammer: data.scammer,
		scammers: data.scammers,
		story: data.story,
		summary: data.summary,
		damageAmount: data.damageAmount,
		damageCurrency: data.damageCurrency,
		evidence: data.evidence
	};
	const res = await bot.sendApplicationToArbiters(app);
	if (res.ok) bot.consumeSubmitPass(authed.id);
	return res;
});
var configureTelegram_createServerFn_handler = createServerRpc({
	id: "308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e",
	name: "configureTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => configureTelegram.__executeServer(opts));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(configureTelegram_createServerFn_handler, async ({ data }) => {
	const { configureFromOrigin } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return configureFromOrigin(data.origin);
});
var getMyComplaints_createServerFn_handler = createServerRpc({
	id: "8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da",
	name: "getMyComplaints",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getMyComplaints.__executeServer(opts));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({
	telegramId: string().min(1).max(20),
	initData: string().max(4096).optional()
})).handler(getMyComplaints_createServerFn_handler, async ({ data }) => {
	const { listComplaintsForUser, verifyTelegramInitData } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return [];
	return listComplaintsForUser(authed.id);
});
var saveUserLocale_createServerFn_handler = createServerRpc({
	id: "11d2abc3e6b37013d6db0d65775d802606c07fa20c30974f0bdb6267adcd933f",
	name: "saveUserLocale",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => saveUserLocale.__executeServer(opts));
var saveUserLocale = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	locale: _enum(["ru", "en"])
})).handler(saveUserLocale_createServerFn_handler, async ({ data }) => {
	const { verifyTelegramInitData, saveUserLocaleServer } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const authed = verifyTelegramInitData(data.initData);
	if (!authed) return { ok: false };
	saveUserLocaleServer(authed.id, data.locale);
	return { ok: true };
});
var checkCounterparty_createServerFn_handler = createServerRpc({
	id: "2d472c3ddcd5f68c787b571931a54cb87506748cc8d6701b6ba316f30d5f9c13",
	name: "checkCounterparty",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => checkCounterparty.__executeServer(opts));
var checkCounterparty = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(16384),
	platform: string().max(24).optional()
})).handler(checkCounterparty_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const gate = bot.allowCheck(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	if (bot.captchaRequired(gate.userId)) return {
		ok: false,
		error: "captcha"
	};
	const result = await bot.checkCounterparty(data.input);
	const who = bot.verifyTelegramInitData(data.initData);
	bot.logSearch({
		id: gate.userId,
		username: who?.username,
		first_name: who?.firstName
	}, data.input, result, "app", data.platform);
	return {
		ok: true,
		result
	};
});
var getCheckSources_createServerFn_handler = createServerRpc({
	id: "e350e76b836184c4252b1300f908594ee1718fe6a59cef9b5037f80b6db26ad1",
	name: "getCheckSources",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getCheckSources.__executeServer(opts));
var getCheckSources = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(getCheckSources_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	if (!bot.verifyTelegramInitData(data.initData)) return {
		ok: false,
		sources: []
	};
	return {
		ok: true,
		sources: bot.checkSources()
	};
});
var getFeatures_createServerFn_handler = createServerRpc({
	id: "1e6f5eee2bcdda2bc5a98f0ab7b0ce73f7b151332e14ed173cef508c1244730a",
	name: "getFeatures",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getFeatures.__executeServer(opts));
var getFeatures = createServerFn({ method: "GET" }).handler(getFeatures_createServerFn_handler, async () => {
	const { featuresEnabled } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return featuresEnabled();
});
var getBanners_createServerFn_handler = createServerRpc({
	id: "c92ddbdf60c25136c999dc716b14d40a8e263c2991c82d6a7e299679f89d5a92",
	name: "getBanners",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getBanners.__executeServer(opts));
var getBanners = createServerFn({ method: "GET" }).handler(getBanners_createServerFn_handler, async () => {
	const { listBanners } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return listBanners();
});
var getSponsors_createServerFn_handler = createServerRpc({
	id: "db4120598d8871d8ab7232bc07450195064ca19d0d7200897b93b10502c9ded7",
	name: "getSponsors",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getSponsors.__executeServer(opts));
var getSponsors = createServerFn({ method: "GET" }).handler(getSponsors_createServerFn_handler, async () => {
	const { listSponsors } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return listSponsors();
});
var getBaseStats_createServerFn_handler = createServerRpc({
	id: "77ad66b5722b2f9fff5c8da8fb47c4865f3e124dfa22cf9ea4726e6311e36620",
	name: "getBaseStats",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getBaseStats.__executeServer(opts));
var getBaseStats = createServerFn({ method: "GET" }).handler(getBaseStats_createServerFn_handler, async () => {
	const { publicBaseStats } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return publicBaseStats();
});
var getSponsorStats_createServerFn_handler = createServerRpc({
	id: "2d0a921e77890fa9e04902a0c26433c58e821a6a5ae27fd6894b84b12c1c1d10",
	name: "getSponsorStats",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getSponsorStats.__executeServer(opts));
var getSponsorStats = createServerFn({ method: "GET" }).handler(getSponsorStats_createServerFn_handler, async () => {
	const { sponsorStats } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return sponsorStats();
});
var getPostDetail_createServerFn_handler = createServerRpc({
	id: "2c1b49e5b56e5a468d24a3849258981b4d60edcc3a360b762ad4d1869a283b21",
	name: "getPostDetail",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getPostDetail.__executeServer(opts));
var getPostDetail = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	channelId: string().max(40),
	messageId: number().int().positive()
})).handler(getPostDetail_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const gate = bot.allowView(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return bot.postDetail(gate.userId, data.channelId, data.messageId);
});
var getLatestParsed_createServerFn_handler = createServerRpc({
	id: "4b99c0cbc338f28020e73fc89ede51c1b76279317762b8e9250f5e9577d3a5c3",
	name: "getLatestParsed",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getLatestParsed.__executeServer(opts));
var getLatestParsed = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(getLatestParsed_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const gate = bot.allowView(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		items: bot.latestParsed(30)
	};
});
var getRecentBlacklist_createServerFn_handler = createServerRpc({
	id: "de3182526ef98fe284877678fbffa5a010fe5e4a323128619c963dd2ce2e7396",
	name: "getRecentBlacklist",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getRecentBlacklist.__executeServer(opts));
var getRecentBlacklist = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(getRecentBlacklist_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const gate = bot.allowView(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		items: bot.recentBlacklist()
	};
});
var getBlacklistEntry_createServerFn_handler = createServerRpc({
	id: "97b5ba3a1bcbd875c36ae5b3ab4bb3ca7c878ba6e6a91dc044a5a8519dd604b4",
	name: "getBlacklistEntry",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getBlacklistEntry.__executeServer(opts));
var getBlacklistEntry = createServerFn({ method: "POST" }).validator(object({
	id: string().min(1).max(80),
	initData: string().max(16384)
})).handler(getBlacklistEntry_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const gate = bot.allowView(data.initData);
	if (!gate.ok) return {
		ok: false,
		error: gate.error
	};
	return {
		ok: true,
		entry: bot.blacklistEntry(data.id)
	};
});
var getAccess_createServerFn_handler = createServerRpc({
	id: "e3a3a791ffaa9c3999d70e9f613b39bc798206b96b103fad776884c8b6863ab3",
	name: "getAccess",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getAccess.__executeServer(opts));
var getAccess = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(getAccess_createServerFn_handler, async ({ data }) => {
	const { appAccess } = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	return appAccess(data.initData);
});
var getCaptcha_createServerFn_handler = createServerRpc({
	id: "ffa934712ecc833841414b698f46f9857e4dc250f4a6a8b043a02c7203468986",
	name: "getCaptcha",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getCaptcha.__executeServer(opts));
var getCaptcha = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	purpose: _enum(["check", "submit"]).optional()
})).handler(getCaptcha_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const user = bot.verifyTelegramInitData(data.initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	const png = bot.newCaptchaImage(user.id, data.purpose ?? "check");
	if (!png) return {
		ok: false,
		error: "too many"
	};
	return {
		ok: true,
		image: `data:image/png;base64,${png.toString("base64")}`
	};
});
var solveCaptcha_createServerFn_handler = createServerRpc({
	id: "0c668cf12cc60da20acb2b4e52ef9034f5fe9836910b4f1e2a2929b4056b29b6",
	name: "solveCaptcha",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => solveCaptcha.__executeServer(opts));
var solveCaptcha = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	answer: string().max(40)
})).handler(solveCaptcha_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-CTIyQymu.mjs").then((n) => n.f);
	const user = bot.verifyTelegramInitData(data.initData);
	if (!user) return {
		ok: false,
		result: "expired"
	};
	return {
		ok: true,
		result: bot.solveCaptcha(user.id, data.answer)
	};
});
export { checkCounterparty_createServerFn_handler, configureTelegram_createServerFn_handler, getAccess_createServerFn_handler, getBanners_createServerFn_handler, getBaseStats_createServerFn_handler, getBlacklistEntry_createServerFn_handler, getCaptcha_createServerFn_handler, getCheckSources_createServerFn_handler, getFeatures_createServerFn_handler, getLatestParsed_createServerFn_handler, getMyComplaints_createServerFn_handler, getPostDetail_createServerFn_handler, getRecentBlacklist_createServerFn_handler, getSponsorStats_createServerFn_handler, getSponsors_createServerFn_handler, getTelegramStatus_createServerFn_handler, resolveTelegramHandle_createServerFn_handler, saveUserLocale_createServerFn_handler, solveCaptcha_createServerFn_handler, submitToTelegram_createServerFn_handler };
