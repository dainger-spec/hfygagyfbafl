import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-BbaBmsmf.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+VkDLqrlnIGxjN2Uy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{3,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{3,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tg.ready?.();
	tg.expand?.();
	tg.setHeaderColor?.("#080808");
	tg.setBackgroundColor?.("#080808");
	tg.setBottomBarColor?.("#080808");
	tg.MainButton?.hide?.();
	tg.SecondaryButton?.hide?.();
	tg.disableVerticalSwipes?.();
}
function lockTelegramViewport() {
	const apply = () => {
		const vv = window.visualViewport;
		const height = Math.max(240, Math.round(vv?.height ?? window.innerHeight));
		const top = Math.round(vv?.offsetTop ?? 0);
		const root = document.documentElement;
		root.style.setProperty("--app-h", `${height}px`);
		root.style.setProperty("--app-top", `${top}px`);
		if (window.scrollY || window.scrollX) window.scrollTo(0, 0);
		document.documentElement.scrollTop = 0;
		document.body.scrollTop = 0;
	};
	apply();
	const vv = window.visualViewport;
	vv?.addEventListener("resize", apply);
	vv?.addEventListener("scroll", apply);
	window.addEventListener("scroll", apply, { passive: true });
	window.Telegram?.WebApp?.onEvent?.("viewportChanged", apply);
	return () => {
		vv?.removeEventListener("resize", apply);
		vv?.removeEventListener("scroll", apply);
		window.removeEventListener("scroll", apply);
		window.Telegram?.WebApp?.offEvent?.("viewportChanged", apply);
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	WEBHOOK_SECRET: () => WEBHOOK_SECRET,
	allowEvidenceUpload: () => allowEvidenceUpload,
	configureFromOrigin: () => configureFromOrigin,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	listComplaintsForUser: () => listComplaintsForUser,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	verifyTelegramInitData: () => verifyTelegramInitData
});
var TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
if (!TOKEN) console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
var API = `https://api.telegram.org/bot${TOKEN}`;
var BOT_USERNAME = "EuBlackList_bot";
var WEBHOOK_SECRET = `epb-${createHash("sha256").update(TOKEN).digest("hex").slice(0, 24)}`;
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v1";
function loadBindings() {
	try {
		return JSON.parse(readFileSync(BINDINGS_PATH, "utf8"));
	} catch {
		return {};
	}
}
function saveBindings() {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(BINDINGS_PATH, JSON.stringify(bindings, null, 2));
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var idCache = {};
var pendingPosts = {};
try {
	idCache = {
		...KNOWN_TELEGRAM_IDS,
		...JSON.parse(readFileSync(ID_CACHE_PATH, "utf8"))
	};
} catch {
	idCache = { ...KNOWN_TELEGRAM_IDS };
}
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
function saveIdCache() {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(ID_CACHE_PATH, JSON.stringify(idCache, null, 2));
	} catch {}
}
function savePending() {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(PENDING_PATH, JSON.stringify(pendingPosts, null, 2));
	} catch {}
}
function rememberUser(user) {
	const username = user?.username?.replace(/^@/, "").toLowerCase();
	if (!user?.id || !username) return;
	const id = String(user.id);
	if (idCache[username] === id) return;
	idCache[username] = id;
	saveIdCache();
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
function saveUploadedEvidence(id, bytes) {
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	pruneEvidenceDir();
	return id;
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function verifyTelegramInitData(initData) {
	if (!TOKEN || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(TOKEN).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const files = readdirSync(EVIDENCE_DIR).map((name) => {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			return {
				path,
				mtime: st.mtimeMs,
				size: st.size
			};
		}).sort((a, b) => a.mtime - b.mtime);
		let total = files.reduce((s, f) => s + f.size, 0);
		const maxBytes = 1610612736;
		const maxFiles = 400;
		while (files.length && (files.length > maxFiles || total > maxBytes)) {
			const drop = files.shift();
			if (!drop) break;
			total -= drop.size;
			try {
				unlinkSync(drop.path);
			} catch {}
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes) {
	if (bytes > 52428800) return {
		ok: false,
		error: "file too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany("up:global", 200, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowNewComplaint(userId, storyLen) {
	if (storyLen > 4e3) return "Слишком длинное описание.";
	if (tooMany(`app:${userId}`, 3, 216e5)) return "Слишком много заявок. Подождите несколько часов.";
	if (tooMany("app:global", 40, 36e5)) return "Сейчас слишком много заявок. Попробуйте позже.";
	return null;
}
function readUploadedEvidence(id) {
	const path = join(EVIDENCE_DIR, id);
	if (!existsSync(path)) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function tg(method, body = {}) {
	const json = await (await fetch(`${API}/${method}`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(body)
	})).json();
	if (!json.ok) throw new Error(json.description || method);
	return json.result;
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId || !isOfficialChannel(bindings.channelId)) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v1") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v1";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook) {
		await applyMenuButton();
		return;
	}
	await tgSoft("setWebhook", {
		url: hook,
		secret_token: WEBHOOK_SECRET,
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member"
		],
		drop_pending_updates: false
	});
	await registerMiniAppUrl(site);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", { commands: [
			{
				command: "start",
				description: "Открыть приложение"
			},
			{
				command: "apply",
				description: "Подать жалобу в чате"
			},
			{
				command: "cancel",
				description: "Отменить заявку"
			}
		] });
	}
	if (profileReady) return;
	profileReady = true;
	await tgSoft("setMyShortDescription", { short_description: "Закрытый европейский блеклист. Mini App → жалоба → арбитры." });
	await tgSoft("setMyDescription", { description: [
		"Europe Private Blacklist — закрытый европейский блеклист.",
		"",
		"1. /start и «Открыть приложение»",
		"2. Mini App подтягивает ваш Telegram",
		"3. На главной — Подать жалобу",
		"4. Арбитры: Опубликовать или Отклонить"
	].join("\n") });
}
async function getBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	let arbiterId = bindings.arbiterChatId || REQUESTED_ARBITER;
	for (const id of arbiterCandidates()) {
		const chat = await chatReachable(id);
		if (!chat) continue;
		arbiterOk = true;
		arbiterId = String(chat.id);
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		arbiterId,
		channelOk,
		miniAppUrl: publicMiniAppUrl() || ""
	};
}
async function resolveHandleServer(input) {
	if (tooMany("resolve:global", 40, 6e4)) return null;
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id && !parsed.username) {
		const chat = await tgSoft("getChat", { chat_id: parsed.id });
		if (chat?.username) rememberHandle(chat.username, parsed.id);
		return {
			username: chat?.username || "",
			id: parsed.id,
			source: "parsed"
		};
	}
	const username = parsed.username;
	if (parsed.id) {
		rememberHandle(username, parsed.id);
		return {
			username,
			id: parsed.id,
			source: "parsed"
		};
	}
	const cached = idCache[username.toLowerCase()];
	if (cached) return {
		username,
		id: cached,
		source: "telegram"
	};
	const chat = await tgSoft("getChat", { chat_id: `@${username}` });
	if (chat?.id && chat.id > 0 && chat.type !== "channel" && chat.type !== "supergroup" && chat.type !== "group") {
		const id = String(chat.id);
		rememberHandle(chat.username || username, id);
		return {
			username: chat.username || username,
			id,
			source: "telegram"
		};
	}
	return {
		username,
		id: "",
		source: "unresolved"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function applicationHtml(app) {
	const victim = `@${app.victim.username.replace(/^@/, "")} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const accounts = scammerAccounts(app);
	const scammer = accounts.map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const first = accounts[0];
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Суть обмана</b>\n${escapeHtml(app.story.trim())}`,
		"",
		`#epb u=${escapeHtml(first?.username.replace(/^@/, "") || "")} id=${escapeHtml(first?.telegramId || "")} k=${escapeHtml(app.id)}`
	].join("\n");
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const head = [handle ? `@${escapeHtml(handle)}` : "", a.id ? `Id: ${escapeHtml(a.id)}` : ""].filter(Boolean).join(" ");
		if (i === accounts.length - 1 && scam) return `${head} - ${scam}`;
		if (accounts.length > 1) return `${head} ;`;
		return head;
	});
}
function channelHtml(accounts, story, amount = "", currency = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const accounts = scammerAccounts(app);
	const first = accounts[0];
	const scamLine = accounts.map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	const head = [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		""
	].join("\n");
	const tail = `\n\n#epb u=${escapeHtml(first?.username.replace(/^@/, "") || "")} id=${escapeHtml(first?.telegramId || "")} k=${escapeHtml(app.id)}`;
	let story = app.story.trim();
	const budget = 1024 - head.length - tail.length;
	if (story.length > budget) story = `${story.slice(0, Math.max(0, budget - 1))}…`;
	return `${head}${escapeHtml(story)}${tail}`;
}
function reviewKeyboard() {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: "pub"
	}, {
		text: "Отклонить",
		callback_data: "rej"
	}]] };
}
async function tgForm(method, form) {
	const json = await (await fetch(`${API}/${method}`, {
		method: "POST",
		body: form
	})).json();
	if (!json.ok) throw new Error(json.description || method);
	return json.result;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	const form = new FormData();
	form.set("chat_id", chatId);
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	for (const a of accounts) rememberHandle(a.username, a.id);
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? `Жалоба ${appId} на ${scam} принята.\nСтатус: подано. Арбитры проверят материалы.` : kind === "published" ? `Жалоба ${appId} на ${scam} одобрена и опубликована в Europe Private Blacklist.` : `Жалоба ${appId} на ${scam} отклонена арбитрами. Публикации не будет.`,
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
async function attachReviewButtons(chatId, messageId, caption, keyboard) {
	if (await tgSoft("editMessageCaption", {
		chat_id: chatId,
		message_id: messageId,
		caption,
		parse_mode: "HTML",
		reply_markup: keyboard
	})) return messageId;
	return (await tg("sendMessage", {
		chat_id: chatId,
		text: caption,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: messageId,
		reply_markup: keyboard
	})).message_id;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard) {
	if (!files.length) {
		const sent = await tg("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: keyboard
		});
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = {
			chat_id: chatId,
			caption,
			parse_mode: "HTML",
			reply_markup: keyboard
		};
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
	}
	let firstId = 0;
	for (let i = 0; i < files.length; i += 10) {
		const chunk = files.slice(i, i + 10);
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0) {
				payload.caption = caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 ? {
					caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, caption, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard) {
	if (blobs.length <= 1) {
		const sent = await sendMediaFile(chatId, blobs[0], {
			caption,
			replyMarkup: keyboard
		});
		const files = sent.fileId ? [{
			type: sent.kind,
			file_id: sent.fileId
		}] : [];
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
	}
	const files = [];
	let firstId = 0;
	for (let i = 0; i < blobs.length; i += 10) {
		const chunk = blobs.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 ? { caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 ? {
					caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, caption, keyboard),
		files
	};
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const keyboard = reviewKeyboard();
	const blobs = app.evidence.filter((f) => Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard) : null;
			if (sent) {
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const sent = await tg("sendMessage", {
			chat_id,
			text: applicationHtml(app),
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: keyboard
		});
		storePending(app, []);
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const blocked = allowNewComplaint(app.victim.telegramId || "", app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	if (app.evidence.length > 20) return {
		ok: false,
		error: "Слишком много файлов."
	};
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: `Добавьте @${BOT_USERNAME} в чат арбитров админом и напишите там /id`
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	const caption = html.length > 1024 ? `${html.slice(0, 1023)}…` : html;
	let lastError = "channel not found";
	for (const chat_id of ids) try {
		if (!files.length) {
			await tg("sendMessage", {
				chat_id,
				text: html,
				parse_mode: "HTML",
				disable_web_page_preview: false
			});
			return;
		}
		for (let i = 0; i < files.length; i += 10) {
			const chunk = files.slice(i, i + 10);
			const firstCaption = i === 0 ? caption : void 0;
			if (chunk.length === 1) {
				const file = chunk[0];
				const payload = {
					chat_id,
					caption: firstCaption,
					parse_mode: firstCaption ? "HTML" : void 0
				};
				if (file.type === "video") payload.video = file.file_id;
				else if (file.type === "document") payload.document = file.file_id;
				else payload.photo = file.file_id;
				await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload);
			} else await tg("sendMediaGroup", {
				chat_id,
				media: chunk.map((file, idx) => ({
					type: file.type,
					media: file.file_id,
					...firstCaption && idx === 0 ? {
						caption: firstCaption,
						parse_mode: "HTML"
					} : {}
				}))
			});
		}
		return;
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function publishFromMessage(text, callbackId, extraFiles = []) {
	const parsed = parseEpbMarker(text);
	if (!parsed) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	const stored = parsed.key ? pendingPosts[parsed.key] : void 0;
	const html = channelHtml(pendingAccounts(stored, parsed.username, parsed.id), stored?.story || parsed.story, stored?.amount, stored?.currency);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	try {
		await sendChannelPost(html, files);
	} catch {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Не удалось опубликовать. Бот должен быть админом канала.`,
			show_alert: true
		});
		return false;
	}
	if (parsed.key && pendingPosts[parsed.key]) {
		pendingPosts[parsed.key].status = "published";
		savePending();
		await notifyApplicant(pendingPosts[parsed.key], parsed.key, "published");
	}
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: "Опубликовано"
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard() {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: "Открыть приложение",
		web_app: { url }
	}]);
	rows.push([{
		text: "Подать жалобу в чате",
		callback_data: "apply"
	}]);
	return { inline_keyboard: rows };
}
function startText() {
	return [
		"<b>Europe Private Blacklist</b>",
		"",
		"Откройте приложение, чтобы подать жалобу.",
		"",
		"Арбитры проверят материалы: одобрили — карточка в канале, отклонили — без публикации."
	].join("\n");
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	return [join(process.cwd(), "public/bot", name), join("/workspace/public/bot", name)].find((p) => existsSync(p)) || null;
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await tgSoft("sendPhoto", {
			chat_id: chatId,
			photo: cached,
			caption,
			parse_mode: "HTML",
			...extra
		})) return;
	}
	const path = cardPath(kind);
	if (!path) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			...extra
		});
		return;
	}
	const form = new FormData();
	form.set("chat_id", String(chatId));
	form.set("caption", caption);
	form.set("parse_mode", "HTML");
	if (extra.reply_markup) form.set("reply_markup", JSON.stringify(extra.reply_markup));
	const bytes = readFileSync(path);
	form.set("photo", new Blob([new Uint8Array(bytes)], { type: "image/jpeg" }), `${kind}.jpg`);
	try {
		const fileId = (await tgForm("sendPhoto", form)).photo?.at(-1)?.file_id;
		if (fileId) {
			bindings.cards = {
				...bindings.cards,
				[kind]: fileId
			};
			saveBindings();
		}
	} catch {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			...extra
		});
	}
}
async function replyStart(chatId) {
	await sendCard(chatId, "welcome", startText(), { reply_markup: applyKeyboard() });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: []
	};
}
function parseAmount(text) {
	const m = text.trim().match(/(\d+(?:[.,]\d+)?)/);
	if (!m?.[1]) return null;
	const amount = m[1].replace(",", ".");
	const upper = text.toUpperCase();
	let currency = "USD";
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSDT\b/.test(upper)) currency = "USDT";
	else if (/\bRUB\b|₽|РУБ/.test(upper)) currency = "RUB";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	return {
		amount,
		currency
	};
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session) {
	if (!session.accounts.length) return "пока пусто";
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: "Ещё аккаунт",
		callback_data: "apply:more"
	}, {
		text: "Далее",
		callback_data: "apply:next"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: session?.accounts.length ? `Аккаунты:\n${listed}\n\nПерешлите сообщение следующего аккаунта или напишите @username. Когда все добавлены — «Далее».` : "Шаг 1/5. Аккаунты.\nПерешлите сообщение, @username или t.me.\nЕсли несколько аккаунтов — пришлите по очереди, затем «Далее».",
		reply_markup: rows.length ? { inline_keyboard: rows } : void 0
	});
}
async function askVictim(chatId, session) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `Шаг 2/5. Ваш контакт, чтобы арбитры могли связаться.\nСейчас: ${session.victimUsername ? `@${session.victimUsername} · id ${session.victimId}` : `id ${session.victimId} (username нет)`}\nНапишите другой @username или нажмите «Оставить».`,
		reply_markup: { inline_keyboard: [[{
			text: "Оставить",
			callback_data: "apply:keep"
		}]] }
	});
}
async function askStory(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 3/5. Суть обмана одним сообщением."
	});
}
async function askAmount(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 4/5. Сумма ущерба. Например: 250 EUR или 100 USD."
	});
}
async function askEvidence(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 5/5. Скрины и видео. Пришлите файлы, можно несколько. Когда закончите — «Готово».",
		reply_markup: { inline_keyboard: [[{
			text: "Готово",
			callback_data: "apply:done"
		}, {
			text: "Без файлов",
			callback_data: "apply:skip"
		}]] }
	});
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? `${session.evidence.length} файл(ов)` : "без файлов";
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"Проверьте заявку:",
			"",
			"Аккаунт:",
			formatSessionAccounts(session),
			`Пострадавший: ${victim} · ${session.victimId}`,
			`Ущерб: ${session.amount} ${session.currency}`,
			`Доказательства: ${files}`,
			"",
			session.story
		].join("\n"),
		reply_markup: { inline_keyboard: [[{
			text: "Отправить на рассмотрение",
			callback_data: "apply:send"
		}, {
			text: "Отмена",
			callback_data: "apply:cancel"
		}]] }
	});
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Заявка на блеклист. Отмена — /cancel."
	});
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice = "Заявка отменена.") {
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: notice,
		reply_markup: applyKeyboard()
	});
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Добавьте хотя бы один аккаунт."
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || "Не удалось отправить арбитрам."
		});
		return;
	}
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `Заявка ${app.id} ушла арбитрам. Если одобрят — пост в канале, если нет — публикация не выйдет.`
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "Сначала добавьте хотя бы один аккаунт."
					});
					return;
				}
				session.step = "victim";
				sessions.set(userId, session);
				await askVictim(chatId, session);
				return;
			}
			const resolved = await resolveHandleServer(raw);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: "Не разобрал. Перешлите сообщение или напишите @username."
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: `@${resolved.username} принял, но ID не найден. Перешлите любое его сообщение или допишите числовой ID.`
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		const raw = (msg.text || "").trim();
		if (!raw) {
			await askVictim(chatId, session);
			return;
		}
		const parsed = parseTelegramInput(raw);
		session.victimUsername = parsed.username || raw.replace(/^@/, "");
		if (parsed.id) session.victimId = parsed.id;
		session.step = "story";
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 8) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Нужно описание схемы — хотя бы пару предложений."
			});
			return;
		}
		if (story.length > 4e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Описание слишком длинное — сократите до 4000 символов."
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Напишите сумму числом, например 250 EUR."
			});
			return;
		}
		session.amount = parsed.amount;
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 20) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: `Файл ${session.evidence.length}/20 принят. Ещё или «Готово».`,
				reply_markup: { inline_keyboard: [[{
					text: "Готово",
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите скрин или видео, либо нажмите «Готово»."
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявку нужно подать в личке с ботом",
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: `Откройте @${BOT_USERNAME} в личных сообщениях и нажмите /apply`
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Начните заново: /apply"
		});
		return;
	}
	await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:keep") {
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Сначала добавьте аккаунт."
			});
			return;
		}
		session.step = "victim";
		sessions.set(userId, session);
		await askVictim(chatId, session);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите следующий аккаунт: перешлите сообщение или @username."
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") await submitSession(chatId, userId, session);
}
async function rejectForeignChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: "Этот бот работает только в официальном чате Europe Private Blacklist. Чужие чаты не обслуживаются."
	});
	await tgSoft("leaveChat", { chat_id: chat.id });
}
async function bindChat(chat) {
	const id = String(chat.id);
	if (chat.type === "channel") {
		if (bindings.channelId && !isOfficialChannel(id)) {
			await rejectForeignChat(chat);
			return;
		}
		if (!bindings.channelId) {
			bindings.channelId = id;
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${chat.title ?? id}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	if (chat.type === "group" || chat.type === "supergroup") {
		if (!isOfficialArbiterChat(id)) {
			await rejectForeignChat(chat);
			return;
		}
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить."
			].join("\n"),
			parse_mode: "HTML"
		});
	}
}
async function handleUpdate(update) {
	await ensureBotProfile();
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.callback_query?.from);
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || "");
	if (floodId && tooMany(`flood:${floodId}`, 45, 6e4)) return;
	const member = update.my_chat_member;
	if (member) {
		const status = member.new_chat_member.status;
		if (status === "member" || status === "administrator" || status === "creator") await bindChat(member.chat);
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if ((cb.data === "pub" || cb.data === "rej") && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		const isMedia = Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (text.includes("#published") || text.includes("#rejected")) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub") {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			if (!await publishFromMessage(text, cb.id, extraFiles)) return;
			const next = `${text}\n\nСтатус: опубликовано`.replace("#epb ", "#published #epb ");
			if (isMedia) await tgSoft("editMessageCaption", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				caption: next,
				parse_mode: "HTML",
				reply_markup: { inline_keyboard: [] }
			});
			else await tgSoft("editMessageText", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				text: next,
				disable_web_page_preview: true,
				reply_markup: { inline_keyboard: [] }
			});
			return;
		}
		if (cb.data === "rej") {
			const parsed = parseEpbMarker(text);
			if (parsed?.key && pendingPosts[parsed.key]) {
				pendingPosts[parsed.key].status = "rejected";
				savePending();
				await notifyApplicant(pendingPosts[parsed.key], parsed.key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${text}\n\nСтатус: отклонено`.replace("#epb ", "#rejected #epb ");
			if (isMedia) await tgSoft("editMessageCaption", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				caption: next,
				parse_mode: "HTML",
				reply_markup: { inline_keyboard: [] }
			});
			else await tgSoft("editMessageText", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				text: next,
				disable_web_page_preview: true,
				reply_markup: { inline_keyboard: [] }
			});
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		await replyStart(msg.chat.id);
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `Заявку подайте в личке: @${BOT_USERNAME}`
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) {
				await rejectForeignChat(msg.chat);
				return;
			}
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда."
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) {
				await rejectForeignChat(msg.chat);
				return;
			}
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (msg.chat.type !== "private") return;
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: WEBHOOK_SECRET,
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member"
		],
		drop_pending_updates: false
	});
	return {
		ok: true,
		url: clean
	};
}
async function configureFromOrigin(origin) {
	const url = origin.replace(/\/$/, "");
	if (!url.startsWith("https://")) return {
		configured: false,
		reason: "need_https"
	};
	if (/localhost|127\.0\.0\.1/i.test(url)) return {
		configured: false,
		reason: "local"
	};
	const registered = await registerMiniAppUrl(url);
	if (!registered.ok) return {
		configured: false,
		reason: "grok_gate"
	};
	return {
		configured: true,
		url: registered.url
	};
}
//#endregion
export { telegram_bot_server_exports as a, parseTelegramInput as c, telegramInitData as d, waitForTelegramUser as f, saveUploadedEvidence as i, readTelegramWebUser as l, allowEvidenceUpload as n, bootTelegramWebApp as o, handleUpdate as r, lockTelegramViewport as s, WEBHOOK_SECRET as t, resolveTelegramId as u };
