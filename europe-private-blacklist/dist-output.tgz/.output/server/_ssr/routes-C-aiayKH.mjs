import { o as __toESM } from "../_runtime.mjs";
import { a as t, i as persistLocale, n as hasSavedLocale, t as detectLocale } from "./i18n-DRcgfq3J.mjs";
import { S as waitForTelegramUser, _ as lookupTelegramHandle, b as readTelegramWebUser, g as lockTelegramViewport, h as bootTelegramWebApp, m as CHANNEL_URL, v as parseDamageAmount, x as telegramInitData, y as parseTelegramInput } from "./telegram-bot.server-CRuzqs5m.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as ImagePlus, i as LoaderCircle, o as Film, r as Plus, s as ChevronLeft, t as X } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C-aiayKH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "") {
	const core = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
	return prefix ? `${prefix}-${core}` : core;
}
function r(n) {
	return Math.round(n * 100) / 100;
}
function starPoints(cx, cy, outer = 7.1, inner = 2.85) {
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const rad = i % 2 === 0 ? outer : inner;
		const a = -Math.PI / 2 + i * Math.PI / 5;
		pts.push(`${r(cx + rad * Math.cos(a))},${r(cy + rad * Math.sin(a))}`);
	}
	return pts.join(" ");
}
function EuStarsLogo({ className, size = 64, title }) {
	const stars = Array.from({ length: 12 }, (_, i) => {
		const angle = (i * 30 - 90) * Math.PI / 180;
		return {
			cx: r(50 + 36 * Math.cos(angle)),
			cy: r(50 + 36 * Math.sin(angle))
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 100",
		width: size,
		height: size,
		className: cn("text-gold", className),
		role: title ? "img" : "presentation",
		"aria-hidden": title ? void 0 : true,
		"aria-label": title,
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }) : null, stars.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: starPoints(s.cx, s.cy),
			fill: "currentColor"
		}, i))]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold tracking-tight transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-gold text-gold-fg hover:bg-gold/92",
			secondary: "bg-surface-2 text-fg hover:bg-surface shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.14)] hover:bg-surface",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface",
			danger: "bg-danger text-danger-fg hover:bg-danger/90",
			ok: "bg-ok text-ok-fg hover:bg-ok/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("flex h-11 w-full rounded-xl bg-surface px-3.5 text-base text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", "file:mr-3 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-fg", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("flex min-h-32 w-full rounded-xl bg-surface px-3.5 py-3 text-base leading-relaxed text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var MAX_FILES = 30;
var CHUNK_SIZE = 1572864;
var sessionBlobs = /* @__PURE__ */ new Map();
function isVideoFile(file) {
	if (file.type.startsWith("video/")) return true;
	return /\.(mp4|mov|webm|mkv|m4v|avi)$/i.test(file.name || "");
}
function isImageFile(file) {
	if (file.type.startsWith("image/")) return true;
	return /\.(jpe?g|png|webp|gif|heic|heif)$/i.test(file.name || "");
}
function isEvidenceFile(file) {
	return isVideoFile(file) || isImageFile(file);
}
function resizeImage(file, max = 960, quality = .8) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const objectUrl = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(objectUrl);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(objectUrl);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(objectUrl);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = objectUrl;
	});
}
function postChunkOnce(body) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", "/api/telegram/evidence");
		xhr.timeout = 12e4;
		xhr.responseType = "text";
		xhr.onload = () => {
			if (xhr.status < 200 || xhr.status >= 300) {
				reject(/* @__PURE__ */ new Error(`upload ${xhr.status}`));
				return;
			}
			try {
				resolve(JSON.parse(xhr.responseText || "{}"));
			} catch {
				reject(/* @__PURE__ */ new Error("bad upload response"));
			}
		};
		xhr.onerror = () => reject(/* @__PURE__ */ new Error("network"));
		xhr.ontimeout = () => reject(/* @__PURE__ */ new Error("timeout"));
		xhr.send(body);
	});
}
async function postChunk(makeBody, attempt = 0) {
	try {
		return await postChunkOnce(await makeBody());
	} catch (err) {
		if (attempt >= 6) throw err;
		await new Promise((resolve) => window.setTimeout(resolve, 400 * (attempt + 1)));
		return postChunk(makeBody, attempt + 1);
	}
}
async function chunkAsFile(file, index, total) {
	const start = index * CHUNK_SIZE;
	const end = Math.min(file.size, (index + 1) * CHUNK_SIZE);
	const buf = await file.slice(start, end).arrayBuffer();
	return new File([buf], file.name || `video-${index + 1}-of-${total}.mp4`, { type: file.type || "video/mp4" });
}
async function uploadEvidenceFile(file, onProgress) {
	const total = Math.max(1, Math.ceil(file.size / CHUNK_SIZE) || 1);
	let storageKey = "";
	for (let index = 0; index < total; index++) {
		const json = await postChunk(async () => {
			const part = await chunkAsFile(file, index, total);
			const body = new FormData();
			if (storageKey) body.set("id", storageKey);
			body.set("index", String(index));
			body.set("total", String(total));
			body.set("initData", telegramInitData());
			body.set("chunk", part, part.name);
			return body;
		});
		onProgress?.(index + 1, total);
		if (json.storageKey) storageKey = json.storageKey;
	}
	if (!storageKey) throw new Error("upload failed");
	return storageKey;
}
function dataUrlToJpegFile(dataUrl, name) {
	const b64 = dataUrl.split(",")[1] || "";
	const bin = atob(b64);
	const bytes = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
	const safe = (name || "photo.jpg").replace(/\.[^.]+$/, ".jpg");
	return new File([bytes], safe, { type: "image/jpeg" });
}
async function fileToEvidence(file, onProgress) {
	const id = uid("ev");
	if (isVideoFile(file)) {
		sessionBlobs.set(id, URL.createObjectURL(file));
		const storageKey = await uploadEvidenceFile(file, onProgress);
		return {
			id,
			kind: "video",
			name: file.name,
			size: file.size,
			mime: file.type || "video/mp4",
			dataUrl: "",
			storageKey
		};
	}
	let dataUrl = "";
	try {
		dataUrl = await resizeImage(file);
	} catch {
		sessionBlobs.set(id, URL.createObjectURL(file));
		const storageKey = await uploadEvidenceFile(file, onProgress);
		return {
			id,
			kind: "image",
			name: file.name,
			size: file.size,
			mime: file.type || "application/octet-stream",
			dataUrl: "",
			storageKey
		};
	}
	sessionBlobs.set(id, dataUrl);
	const jpeg = dataUrlToJpegFile(dataUrl, file.name);
	const storageKey = await uploadEvidenceFile(jpeg, onProgress);
	return {
		id,
		kind: "image",
		name: file.name,
		size: jpeg.size,
		mime: "image/jpeg",
		dataUrl: "",
		storageKey
	};
}
async function persistEvidence(files) {
	const out = [];
	for (const file of files) {
		if (file.storageKey) {
			out.push({
				...file,
				dataUrl: ""
			});
			continue;
		}
		const src = file.dataUrl || sessionBlobs.get(file.id) || "";
		if (!src.startsWith("data:")) {
			out.push({
				...file,
				dataUrl: ""
			});
			continue;
		}
		const jpeg = dataUrlToJpegFile(src, file.name || "photo.jpg");
		const storageKey = await uploadEvidenceFile(jpeg);
		out.push({
			...file,
			dataUrl: "",
			storageKey,
			size: jpeg.size,
			mime: "image/jpeg"
		});
	}
	return out;
}
function canAddEvidence(current, incoming) {
	return current + incoming <= MAX_FILES;
}
function evidenceSrc(item) {
	return item.dataUrl || sessionBlobs.get(item.id) || "";
}
var SEED_STORY = "якобы продает фтп.\nКлянчит деньги по мелочи 50-100 баксов и включает дурачка, не может выдать, надо еще докинуть или просто игнорит.";
var SEED_AT = Date.UTC(2026, 7, 26, 12, 0, 0);
var seedPublished = {
	id: "EPB-SEED",
	createdAt: SEED_AT,
	publishedAt: SEED_AT,
	status: "published",
	victim: {
		username: "archive_epb",
		telegramId: "1000000001",
		firstName: "Archive"
	},
	scammer: {
		username: "LopataBuild",
		telegramId: "5213159067"
	},
	story: SEED_STORY,
	summary: "якобы продает фтп, клянчит 50-100$ и пропадает.",
	damageAmount: "100",
	damageCurrency: "USD",
	evidence: []
};
var emptyIdentity = {
	firstName: "",
	username: "",
	telegramId: ""
};
function safeStorage() {
	try {
		const storage = window.localStorage;
		const key = "__epb__";
		storage.setItem(key, "1");
		storage.removeItem(key);
		return storage;
	} catch {
		return {
			length: 0,
			clear() {},
			getItem() {
				return null;
			},
			key() {
				return null;
			},
			removeItem() {},
			setItem() {}
		};
	}
}
var useBlacklistStore = create()(persist((set) => ({
	identity: emptyIdentity,
	locale: "ru",
	applications: [seedPublished],
	setIdentity: (patch) => set((s) => ({ identity: {
		...s.identity,
		...patch
	} })),
	setLocale: (locale) => {
		persistLocale(locale);
		set({ locale });
	},
	submitApplication: (app) => set((s) => ({ applications: [app, ...s.applications] })),
	publishApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "published",
		publishedAt: Date.now()
	} : a) })),
	rejectApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "rejected",
		rejectedAt: Date.now()
	} : a) })),
	resetDemo: () => set({
		identity: emptyIdentity,
		locale: detectLocale(),
		applications: [seedPublished]
	})
}), {
	name: "epb-blacklist",
	storage: createJSONStorage(() => safeStorage()),
	skipHydration: true,
	partialize: (s) => ({
		applications: s.applications,
		locale: s.locale
	})
}));
function rehydrateBlacklistStore() {
	Promise.resolve(useBlacklistStore.persist.rehydrate()).then(() => {
		if (!hasSavedLocale()) return;
		const stored = useBlacklistStore.getState().locale;
		if (stored === "ru" || stored === "en") persistLocale(stored);
	});
}
function EvidencePicker({ files, onChange }) {
	const locale = useBlacklistStore((s) => s.locale);
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [progress, setProgress] = (0, import_react.useState)("");
	async function addFiles(list) {
		const incoming = Array.from(list).filter(isEvidenceFile);
		if (!incoming.length) return;
		if (!canAddEvidence(files.length, incoming.length)) {
			setError(t(locale, "maxFiles", { n: 30 }));
			return;
		}
		setError("");
		setBusy(true);
		setProgress("");
		try {
			const next = [];
			for (let i = 0; i < incoming.length; i++) {
				const file = incoming[i];
				setProgress(incoming.length > 1 ? t(locale, "uploadingN", {
					i: i + 1,
					n: incoming.length
				}) : file.type.startsWith("video/") ? t(locale, "uploadingVideo") : t(locale, "uploadingFile"));
				next.push(await fileToEvidence(file, (done, total) => {
					setProgress(incoming.length > 1 ? t(locale, "uploadingNProgress", {
						i: i + 1,
						n: incoming.length,
						done,
						total
					}) : t(locale, "uploadingVideoProgress", {
						done,
						total
					}));
				}));
			}
			onChange([...files, ...next]);
		} catch {
			setError(t(locale, "uploadFail"));
		} finally {
			setBusy(false);
			setProgress("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*,video/*",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					if (e.target.files) addFiles(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => {
					e.preventDefault();
				},
				onDrop: (e) => {
					e.preventDefault();
					if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
				},
				className: cn("flex min-h-28 w-full flex-col items-center justify-center gap-2 rounded-2xl bg-surface px-4 py-6 text-center shadow-[0_0_0_1px_rgba(243,239,228,0.10)]", "hover:bg-surface-2"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-fg",
						children: busy ? progress || t(locale, "uploading") : t(locale, "dropFiles")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: t(locale, "dropHint", { n: 30 })
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-3 gap-2",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, { item: file }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "icon",
						className: "absolute top-1 right-1 size-8 rounded-full",
						onClick: () => onChange(files.filter((f) => f.id !== file.id)),
						"aria-label": t(locale, "removeFile"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, file.id))
			}) : null
		]
	});
}
function EvidenceThumb({ item }) {
	const src = evidenceSrc(item);
	if (item.kind === "video") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square overflow-hidden rounded-lg bg-surface-2",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			className: "size-full object-cover img-outline",
			muted: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex size-full items-center justify-center text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute bottom-1 left-1 rounded-sm bg-bg/80 px-1.5 py-0.5 text-xs font-medium tracking-wide text-fg",
			children: "VIDEO"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: item.name,
		className: "aspect-square w-full rounded-lg object-cover img-outline"
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
createServerFn({ method: "GET" }).handler(createSsrRpc("35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b"));
createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(4096).optional()
})).handler(createSsrRpc("ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093"));
var evidenceSchema = object({
	id: string().max(40),
	kind: _enum(["image", "video"]),
	name: string().max(200),
	size: number().nonnegative().max(2147483647),
	mime: string().max(80),
	dataUrl: string().max(80).optional().default(""),
	storageKey: string().max(80).optional()
});
var personSchema = object({
	username: string().max(64),
	telegramId: string().max(20),
	firstName: string().max(64).optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(5e3),
	summary: string().min(10).max(800),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().max(16384).optional(),
	locale: _enum(["ru", "en"]).optional()
});
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(createSsrRpc("60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359"));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(createSsrRpc("308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e"));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({
	telegramId: string().min(1).max(20),
	initData: string().max(4096).optional()
})).handler(createSsrRpc("8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da"));
var saveUserLocale = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	locale: _enum(["ru", "en"])
})).handler(createSsrRpc("11d2abc3e6b37013d6db0d65775d802606c07fa20c30974f0bdb6267adcd933f"));
var CURRENCIES = ["USD", "EUR"];
var MAX_ACCOUNTS = 8;
function emptyAcc() {
	return {
		key: uid("acc"),
		input: "",
		username: "",
		id: ""
	};
}
function ApplyForm({ onSubmitted }) {
	const identity = useBlacklistStore((s) => s.identity);
	const locale = useBlacklistStore((s) => s.locale);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const submitApplication = useBlacklistStore((s) => s.submitApplication);
	const [accounts, setAccounts] = (0, import_react.useState)([emptyAcc()]);
	const [summary, setSummary] = (0, import_react.useState)("");
	const [story, setStory] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("USD");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [formError, setFormError] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const tg = readTelegramWebUser();
		if (!tg) return;
		setIdentity(tg);
	}, [setIdentity]);
	async function onSubmit(e) {
		e.preventDefault();
		setFormError("");
		const tgUser = readTelegramWebUser();
		const vUser = (tgUser?.username || "").replace(/^@/, "").trim();
		const vId = tgUser?.telegramId || "";
		if (!vId) {
			setFormError(t(locale, "errOpenBot"));
			return;
		}
		const filled = accounts.map((a) => ({
			username: a.username.replace(/^@/, "").trim(),
			telegramId: a.id.trim()
		})).filter((a) => a.username || a.telegramId);
		if (!filled.length) {
			setFormError(t(locale, "errAccount"));
			return;
		}
		if (filled.some((a) => !a.telegramId)) {
			setFormError(t(locale, "idNotFound"));
			return;
		}
		if (summary.trim().length < 10) {
			setFormError(t(locale, "errSummary"));
			return;
		}
		if (summary.trim().length > 800) {
			setFormError(t(locale, "errSummaryLong"));
			return;
		}
		if (story.trim().length < 20) {
			setFormError(t(locale, "errStory"));
			return;
		}
		if (story.trim().length > 5e3) {
			setFormError(t(locale, "errStoryLong"));
			return;
		}
		const parsedAmount = parseDamageAmount(amount);
		if (!parsedAmount) {
			setFormError(t(locale, "errAmount"));
			return;
		}
		if (!files.length) {
			setFormError(t(locale, "errFiles"));
			return;
		}
		setSending(true);
		try {
			const uploaded = await persistEvidence(files);
			setFiles(uploaded);
			const app = {
				id: `EPB-${uid().slice(0, 4).toUpperCase()}`,
				createdAt: Date.now(),
				status: "pending",
				victim: {
					username: vUser,
					telegramId: vId,
					firstName: tgUser?.firstName || identity.firstName
				},
				scammer: filled[0],
				scammers: filled,
				story: story.trim(),
				summary: summary.trim(),
				damageAmount: parsedAmount.amount,
				damageCurrency: parsedAmount.currency || currency,
				evidence: uploaded.map((f) => ({
					...f,
					dataUrl: ""
				}))
			};
			const tg = await Promise.race([submitToTelegram({ data: {
				...app,
				initData: telegramInitData(),
				locale
			} }), new Promise((resolve) => window.setTimeout(() => resolve({
				ok: false,
				error: t(locale, "errTimeout")
			}), 9e4))]);
			if (!tg.ok) {
				setFormError(tg.error || t(locale, "sentFail"));
				return;
			}
			submitApplication(app);
			setIdentity({
				username: vUser,
				telegramId: vId,
				firstName: tgUser?.firstName || identity.firstName
			});
			onSubmitted(t(locale, "sentOk"));
		} catch {
			setFormError(t(locale, "sentFail"));
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex min-h-0 flex-1 flex-col overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-md flex-col gap-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: t(locale, "accTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(locale, "accHint")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4",
								children: accounts.map((acc, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScammerAccountRow, {
									index,
									row: acc,
									canRemove: accounts.length > 1,
									onChange: (next) => setAccounts((prev) => prev.map((item) => item.key === acc.key ? {
										...item,
										...next
									} : item)),
									onRemove: () => setAccounts((prev) => prev.filter((item) => item.key !== acc.key))
								}, acc.key))
							}),
							accounts.length < MAX_ACCOUNTS ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-surface text-sm font-semibold text-gold shadow-[0_0_0_1px_rgba(240,196,48,0.28)] hover:bg-surface-2",
								onClick: () => setAccounts((prev) => [...prev, emptyAcc()]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t(locale, "addAccount")]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: t(locale, "summaryTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(locale, "summaryHint")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: summary,
								onChange: (e) => setSummary(e.target.value.slice(0, 800)),
								maxLength: 800,
								placeholder: t(locale, "summaryPh")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-right text-xs text-subtle",
								children: [summary.length, "/800"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: t(locale, "storyTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(locale, "storyHint")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: story,
								onChange: (e) => setStory(e.target.value.slice(0, 5e3)),
								maxLength: 5e3,
								placeholder: t(locale, "storyPh")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-right text-xs text-subtle",
								children: [story.length, "/5000"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t(locale, "amount"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										inputMode: "decimal",
										value: amount,
										onChange: (e) => setAmount(e.target.value.replace(/[^\d.,\s]/g, "")),
										placeholder: "15,000"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: t(locale, "currency"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-11 grid-cols-2 overflow-hidden rounded-xl shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
										children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setCurrency(c),
											className: cn("h-11 px-1 text-xs font-semibold transition-colors", currency === c ? "bg-gold text-gold-fg" : "bg-surface text-muted hover:text-fg"),
											children: c
										}, c))
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-lg font-bold",
								children: t(locale, "evidenceTitle")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: t(locale, "evidenceHint")
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePicker, {
							files,
							onChange: setFiles
						})]
					}),
					formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: formError
					}) : null
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0 border-t border-line bg-bg px-4 py-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				size: "lg",
				className: "w-full",
				disabled: sending,
				children: sending ? t(locale, "sending") : t(locale, "send")
			})
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function ScammerAccountRow({ index, row, canRemove, onChange, onRemove }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [resolving, setResolving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const idRef = (0, import_react.useRef)(row.id);
	idRef.current = row.id;
	(0, import_react.useEffect)(() => {
		const value = row.input.trim();
		setError("");
		if (!value) {
			if (row.username || row.id) onChange({
				username: "",
				id: ""
			});
			return;
		}
		const parsed = parseTelegramInput(value);
		if (parsed.id) {
			onChange({
				username: parsed.username,
				id: parsed.id
			});
			setResolving(false);
			return;
		}
		onChange({
			username: parsed.username,
			id: ""
		});
		let cancelled = false;
		setResolving(true);
		const timer = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await lookupTelegramHandle(value);
				} catch {
					res = null;
				}
				if (cancelled) return;
				setResolving(false);
				if (!res) {
					onChange({
						username: parsed.username,
						id: idRef.current
					});
					if (!idRef.current) setError(t(locale, "parseFail"));
					return;
				}
				if (res.id) {
					onChange({
						username: res.username,
						id: res.id
					});
					setError("");
					return;
				}
				onChange({
					username: res.username,
					id: idRef.current
				});
				if (!idRef.current) setError(t(locale, "idNotFound"));
			})();
		}, 480);
		return () => {
			cancelled = true;
			clearTimeout(timer);
		};
	}, [row.input]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl bg-surface/70 p-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-muted",
					children: [
						t(locale, "accountN"),
						" ",
						index + 1
					]
				}), canRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
					onClick: onRemove,
					"aria-label": t(locale, "removeAccount"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Telegram",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.input,
					onChange: (e) => onChange({ input: e.target.value }),
					placeholder: t(locale, "accPlaceholder"),
					required: index === 0
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ID",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.id,
					onChange: (e) => {
						onChange({ id: e.target.value.replace(/\D/g, "").slice(0, 15) });
						setError("");
					},
					placeholder: t(locale, "pasteId"),
					inputMode: "numeric",
					required: false
				})
			}),
			resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1.5 text-sm text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), t(locale, "resolvingId")]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null
		]
	});
}
function MiniApp({ page, onPage, onClose, onReview, embedded = false }) {
	const [notice, setNotice] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [langPicked, setLangPicked] = (0, import_react.useState)(null);
	const identity = useBlacklistStore((s) => s.identity);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const locale = useBlacklistStore((s) => s.locale);
	const openComplaint = (0, import_react.useCallback)(() => onPage("apply"), [onPage]);
	const openHistory = (0, import_react.useCallback)(() => onPage("history"), [onPage]);
	const openOwners = (0, import_react.useCallback)(() => onPage("owners"), [onPage]);
	(0, import_react.useEffect)(() => {
		rehydrateBlacklistStore();
		bootTelegramWebApp();
		if (hasSavedLocale()) {
			const saved = window.localStorage.getItem("epb-locale");
			if (saved === "ru" || saved === "en") useBlacklistStore.getState().setLocale(saved);
			setLangPicked(true);
		} else setLangPicked(false);
		const unlock = lockTelegramViewport();
		let cancelled = false;
		(async () => {
			const user = await waitForTelegramUser(2500) || readTelegramWebUser();
			if (cancelled) return;
			if (user) try {
				setIdentity(user);
			} catch {}
			setReady(true);
		})();
		return () => {
			cancelled = true;
			unlock();
		};
	}, [setIdentity]);
	const showLang = ready && langPicked === false;
	const showApp = ready && langPicked === true;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex flex-col overflow-hidden overscroll-none bg-bg text-fg", !embedded && "z-50"),
		style: {
			position: "fixed",
			left: 0,
			right: 0,
			top: "var(--app-top, 0px)",
			height: "var(--app-h, 100dvh)",
			maxHeight: "var(--app-h, 100dvh)",
			paddingTop: "var(--tg-safe-top, 0px)"
		},
		children: [showApp && page !== "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute left-2 z-10 flex size-11 items-center justify-center rounded-xl text-fg hover:bg-surface",
			style: { top: "calc(var(--tg-safe-top, 0px) + 4px)" },
			onClick: () => onPage("home"),
			"aria-label": t(locale, "back"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex min-h-0 flex-1 flex-col overflow-hidden", showApp && page !== "home" && "pt-10"),
			children: [
				!showApp && !showLang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountLoading, { locale }) : null,
				showLang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageGate, { onPicked: () => setLangPicked(true) }) : null,
				showApp && page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, {
					identity,
					onComplaint: openComplaint,
					onHistory: openHistory,
					onOwners: openOwners
				}) : null,
				showApp && page === "apply" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyForm, { onSubmitted: (msg) => {
					setNotice(msg ?? "");
					onPage("done");
				} }) : null,
				showApp && page === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { telegramId: identity.telegramId }) : null,
				showApp && page === "owners" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnersGuide, {}) : null,
				showApp && page === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, {
					onPage,
					onClose,
					onReview,
					notice
				}) : null
			]
		})]
	});
}
function persistLangToBot(locale) {
	const initData = telegramInitData();
	if (!initData) return;
	saveUserLocale({ data: {
		initData,
		locale
	} }).catch(() => {});
}
function LangSwitch() {
	const locale = useBlacklistStore((s) => s.locale);
	const setLocale = useBlacklistStore((s) => s.setLocale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-1 rounded-full bg-surface p-1 shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
		children: ["ru", "en"].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => {
				setLocale(code);
				persistLangToBot(code);
			},
			className: cn("rounded-full px-3 py-1 text-xs font-bold", locale === code ? "bg-gold text-gold-fg" : "text-muted hover:text-fg"),
			children: code === "ru" ? "Русский" : "English"
		}, code))
	});
}
function LanguageGate({ onPicked }) {
	const setLocale = useBlacklistStore((s) => s.setLocale);
	function pick(code) {
		setLocale(code);
		persistLangToBot(code);
		onPicked();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 104,
				title: "Europe Private Blacklist",
				className: "epb-spin-slow"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-7 font-display text-3xl font-extrabold tracking-tight",
				children: ["Europe Private", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-gold",
					children: "Blacklist"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm text-muted",
				children: "Выберите язык / Choose language"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex w-full max-w-md flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: () => pick("ru"),
					children: "Русский"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "secondary",
					className: "w-full rounded-xl",
					onClick: () => pick("en"),
					children: "English"
				})]
			})
		]
	});
}
function AccountLoading({ locale }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 96,
				title: "Europe Private Blacklist",
				className: "epb-spin-slow"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-display text-lg font-bold",
				children: t(locale, "loadingTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
				children: t(locale, "loadingText")
			})
		]
	});
}
function Home$1({ identity, onComplaint, onHistory, onOwners }) {
	const locale = useBlacklistStore((s) => s.locale);
	const handle = identity.username ? `@${identity.username}` : identity.firstName || (identity.telegramId ? `ID ${identity.telegramId}` : "");
	const canUse = Boolean(identity.telegramId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto overscroll-contain px-4 [touch-action:pan-y]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col items-center justify-center py-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangSwitch, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
					size: 104,
					title: "Europe Private Blacklist",
					className: "epb-spin-slow mt-5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-7 font-display text-3xl font-extrabold tracking-tight",
					children: ["Europe Private", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-gold",
						children: "Blacklist"
					})]
				}),
				handle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-subtle",
					children: [
						t(locale, "signedIn"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: handle
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-subtle",
					children: t(locale, "openFromBot")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex w-full max-w-md flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full rounded-xl",
						onClick: onComplaint,
						disabled: !canUse,
						children: t(locale, "fileComplaint")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full rounded-xl",
						onClick: onHistory,
						disabled: !canUse,
						children: t(locale, "history")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: CHANNEL_URL,
					target: "_blank",
					rel: "noreferrer",
					className: "mt-5 text-sm font-medium text-gold underline underline-offset-4",
					children: t(locale, "subscribe")
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onOwners,
			className: "mx-auto mb-5 text-sm font-medium text-muted underline underline-offset-4",
			children: t(locale, "ownersLink")
		})]
	});
}
function OwnersGuide() {
	const locale = useBlacklistStore((s) => s.locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md space-y-5 text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: t(locale, "ownersTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: t(locale, "ownersIntro")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-bold",
							children: t(locale, "ownersHow")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersStep1") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: t(locale, "ownersStep2")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersGroup") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersChannel") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersStep3") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						t(locale, "ownersHelp"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://t.me/EuropePromo",
							target: "_blank",
							rel: "noreferrer",
							className: "font-medium text-gold",
							children: "@EuropePromo"
						})
					]
				})
			]
		})
	});
}
function History({ telegramId }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		async function load() {
			if (!telegramId) {
				setItems([]);
				return;
			}
			try {
				const list = await getMyComplaints({ data: {
					telegramId,
					initData: telegramInitData()
				} });
				if (!cancelled) setItems(list);
			} catch {
				if (!cancelled) setItems([]);
			}
		}
		load();
		const tmr = window.setInterval(() => void load(), 8e3);
		return () => {
			cancelled = true;
			window.clearInterval(tmr);
		};
	}, [telegramId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-md space-y-3",
			children: items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center justify-center gap-2 py-16 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-gold" }), t(locale, "historyLoading")]
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-sm text-muted",
				children: t(locale, "historyEmpty")
			}) : items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryCard, { item }, item.id))
		})
	});
}
function HistoryCard({ item }) {
	const locale = useBlacklistStore((s) => s.locale);
	const handle = item.scammerUsername ? item.scammerUsername.split(" · ").map((u) => {
		const name = u.replace(/^@/, "").trim();
		return name ? `@${name}` : "";
	}).filter(Boolean).join(" · ") : t(locale, "noUsername");
	const when = item.createdAt ? new Date(item.createdAt).toLocaleString(locale === "en" ? "en-GB" : "ru-RU", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}) : "";
	const statusLabel = item.status === "pending" ? t(locale, "statusPending") : item.status === "published" ? t(locale, "statusPublished") : t(locale, "statusRejected");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "rounded-2xl bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold leading-snug break-words",
						children: handle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs text-subtle break-words",
						children: [item.scammerId ? `Id: ${item.scammerId}` : "Id: -", item.amount ? ` · ${item.amount} ${item.currency}` : ""]
					}),
					when ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-subtle",
						children: when
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold", item.status === "pending" && "bg-gold/15 text-gold", item.status === "published" && "bg-ok/15 text-ok", item.status === "rejected" && "bg-danger/15 text-danger"),
				children: statusLabel
			})]
		})
	});
}
function Done({ onPage, onClose, onReview, notice }) {
	const locale = useBlacklistStore((s) => s.locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto overscroll-contain px-5 py-10 text-center [touch-action:pan-y]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-16 items-center justify-center rounded-full bg-gold text-gold-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
					size: 40,
					className: "text-gold-fg"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl font-bold",
				children: t(locale, "doneTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: notice || t(locale, "doneText")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex w-full max-w-md flex-col gap-3",
				children: [
					onReview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: onReview,
						children: t(locale, "history")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: () => onPage("history"),
						children: t(locale, "history")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full",
						onClick: () => onPage("home"),
						children: t(locale, "home")
					}),
					onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "ghost",
						className: "w-full",
						onClick: onClose,
						children: t(locale, "closeApp")
					}) : null
				]
			})
		]
	});
}
function Home() {
	const [page, setPage] = (0, import_react.useState)("home");
	const [canClose, setCanClose] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		bootTelegramWebApp();
		setCanClose(Boolean(window.Telegram?.WebApp?.close));
		configureTelegram({ data: { origin: window.location.origin } }).catch(() => {});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniApp, {
		page,
		onPage: setPage,
		embedded: true,
		onClose: canClose ? () => window.Telegram?.WebApp?.close?.() : void 0
	});
}
//#endregion
export { Home as component };
