import { o as __toESM } from "../_runtime.mjs";
import { a as t, i as persistLocale, n as hasSavedLocale, t as detectLocale } from "./i18n-CdCY3_Sv.mjs";
import { C as parseDamageAmount, D as waitForTelegramUser, E as telegramInitData, S as openExternal, T as readTelegramWebUser, _ as CHANNEL_URL, b as lockTelegramViewport, v as bootTelegramWebApp, w as parseTelegramInput, x as lookupTelegramHandle, y as haptic } from "./telegram-bot.server-CXnqFaWc.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as Search, c as ImagePlus, d as ChevronLeft, i as ShieldAlert, l as Film, o as Plus, r as ShieldCheck, s as LoaderCircle, t as X, u as ExternalLink } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-K98oXUxN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "") {
	const core = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
	return prefix ? `${prefix}-${core}` : core;
}
function r(n) {
	return Math.round(n * 100) / 100;
}
function starPoints(cx, cy, outer = 7.1, inner = 2.85) {
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const rad = i % 2 === 0 ? outer : inner;
		const a = -Math.PI / 2 + i * Math.PI / 5;
		pts.push(`${r(cx + rad * Math.cos(a))},${r(cy + rad * Math.sin(a))}`);
	}
	return pts.join(" ");
}
function EuStarsLogo({ className, size = 64, title, spin = false, fast = false, emblem = false }) {
	const gid = `epb-star-${(0, import_react.useId)().replace(/:/g, "")}`;
	const stars = Array.from({ length: 12 }, (_, i) => {
		const angle = (i * 30 - 90) * Math.PI / 180;
		return {
			cx: r(50 + 36 * Math.cos(angle)),
			cy: r(50 + 36 * Math.sin(angle))
		};
	});
	const ring = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 100",
		width: size,
		height: size,
		className: cn("text-gold", spin && (fast ? "epb-spin-fast" : "epb-spin-slow"), !emblem && className),
		role: title && !emblem ? "img" : "presentation",
		"aria-hidden": title && !emblem ? void 0 : true,
		"aria-label": emblem ? void 0 : title,
		children: [
			title && !emblem ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
				id: gid,
				cx: "50%",
				cy: "45%",
				r: "60%",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "0%",
						stopColor: "#fff8e0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "45%",
						stopColor: "#f6c862"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
						offset: "100%",
						stopColor: "#d49a3a"
					})
				]
			}) }),
			stars.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
				points: starPoints(s.cx, s.cy),
				fill: `url(#${gid})`
			}, i))
		]
	});
	if (!emblem) return ring;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("relative inline-block shrink-0", className),
		style: {
			width: size,
			height: size
		},
		role: title ? "img" : void 0,
		"aria-label": title,
		children: [ring, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("picture", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
			srcSet: "/brand/emblem-v2.webp",
			type: "image/webp"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/brand/emblem-v2.png",
			alt: "",
			"aria-hidden": true,
			draggable: false,
			className: "pointer-events-none absolute left-1/2 top-1/2 h-[53%] w-auto -translate-x-1/2 -translate-y-1/2 select-none"
		})] })]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl text-sm font-semibold tracking-tight transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-gold bg-[linear-gradient(180deg,#ffe6a8_0%,#f2be55_48%,#d39a36_100%)] text-gold-fg shadow-[inset_0_1px_0_rgba(255,255,255,0.35)] hover:brightness-105",
			secondary: "bg-surface-2 text-fg hover:bg-surface shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.14)] hover:bg-surface",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-surface",
			danger: "bg-danger text-danger-fg hover:bg-danger/90",
			ok: "bg-ok text-ok-fg hover:bg-ok/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, onClick, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		onClick: (e) => {
			if (!props.disabled) haptic("light");
			onClick?.(e);
		},
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("flex h-11 w-full rounded-xl bg-surface px-3.5 text-base text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", "file:mr-3 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-fg", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("flex min-h-32 w-full rounded-xl bg-surface px-3.5 py-3 text-base leading-relaxed text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.5)]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var MAX_FILES = 30;
var CHUNK_SIZE = 1572864;
var sessionBlobs = /* @__PURE__ */ new Map();
function isVideoFile(file) {
	if (file.type.startsWith("video/")) return true;
	return /\.(mp4|mov|webm|mkv|m4v|avi)$/i.test(file.name || "");
}
function isImageFile(file) {
	if (file.type.startsWith("image/")) return true;
	return /\.(jpe?g|png|webp|gif|heic|heif)$/i.test(file.name || "");
}
function isEvidenceFile(file) {
	return isVideoFile(file) || isImageFile(file);
}
function resizeImage(file, max = 960, quality = .8) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const objectUrl = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(objectUrl);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(objectUrl);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(objectUrl);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = objectUrl;
	});
}
function postChunkOnce(body) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", "/api/telegram/evidence");
		xhr.timeout = 12e4;
		xhr.responseType = "text";
		xhr.onload = () => {
			if (xhr.status < 200 || xhr.status >= 300) {
				reject(/* @__PURE__ */ new Error(`upload ${xhr.status}`));
				return;
			}
			try {
				resolve(JSON.parse(xhr.responseText || "{}"));
			} catch {
				reject(/* @__PURE__ */ new Error("bad upload response"));
			}
		};
		xhr.onerror = () => reject(/* @__PURE__ */ new Error("network"));
		xhr.ontimeout = () => reject(/* @__PURE__ */ new Error("timeout"));
		xhr.send(body);
	});
}
async function postChunk(makeBody, attempt = 0) {
	try {
		return await postChunkOnce(await makeBody());
	} catch (err) {
		if (attempt >= 6) throw err;
		await new Promise((resolve) => window.setTimeout(resolve, 400 * (attempt + 1)));
		return postChunk(makeBody, attempt + 1);
	}
}
async function chunkAsFile(file, index, total) {
	const start = index * CHUNK_SIZE;
	const end = Math.min(file.size, (index + 1) * CHUNK_SIZE);
	const buf = await file.slice(start, end).arrayBuffer();
	return new File([buf], file.name || `video-${index + 1}-of-${total}.mp4`, { type: file.type || "video/mp4" });
}
async function uploadEvidenceFile(file, onProgress) {
	const total = Math.max(1, Math.ceil(file.size / CHUNK_SIZE) || 1);
	let storageKey = "";
	for (let index = 0; index < total; index++) {
		const json = await postChunk(async () => {
			const part = await chunkAsFile(file, index, total);
			const body = new FormData();
			if (storageKey) body.set("id", storageKey);
			body.set("index", String(index));
			body.set("total", String(total));
			body.set("initData", telegramInitData());
			body.set("chunk", part, part.name);
			return body;
		});
		onProgress?.(index + 1, total);
		if (json.storageKey) storageKey = json.storageKey;
	}
	if (!storageKey) throw new Error("upload failed");
	return storageKey;
}
function dataUrlToJpegFile(dataUrl, name) {
	const b64 = dataUrl.split(",")[1] || "";
	const bin = atob(b64);
	const bytes = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
	const safe = (name || "photo.jpg").replace(/\.[^.]+$/, ".jpg");
	return new File([bytes], safe, { type: "image/jpeg" });
}
async function fileToEvidence(file, onProgress) {
	const id = uid("ev");
	if (isVideoFile(file)) {
		sessionBlobs.set(id, URL.createObjectURL(file));
		const storageKey = await uploadEvidenceFile(file, onProgress);
		return {
			id,
			kind: "video",
			name: file.name,
			size: file.size,
			mime: file.type || "video/mp4",
			dataUrl: "",
			storageKey
		};
	}
	let dataUrl = "";
	try {
		dataUrl = await resizeImage(file);
	} catch {
		sessionBlobs.set(id, URL.createObjectURL(file));
		const storageKey = await uploadEvidenceFile(file, onProgress);
		return {
			id,
			kind: "image",
			name: file.name,
			size: file.size,
			mime: file.type || "application/octet-stream",
			dataUrl: "",
			storageKey
		};
	}
	sessionBlobs.set(id, dataUrl);
	const jpeg = dataUrlToJpegFile(dataUrl, file.name);
	const storageKey = await uploadEvidenceFile(jpeg, onProgress);
	return {
		id,
		kind: "image",
		name: file.name,
		size: jpeg.size,
		mime: "image/jpeg",
		dataUrl: "",
		storageKey
	};
}
async function persistEvidence(files) {
	const out = [];
	for (const file of files) {
		if (file.storageKey) {
			out.push({
				...file,
				dataUrl: ""
			});
			continue;
		}
		const src = file.dataUrl || sessionBlobs.get(file.id) || "";
		if (!src.startsWith("data:")) {
			out.push({
				...file,
				dataUrl: ""
			});
			continue;
		}
		const jpeg = dataUrlToJpegFile(src, file.name || "photo.jpg");
		const storageKey = await uploadEvidenceFile(jpeg);
		out.push({
			...file,
			dataUrl: "",
			storageKey,
			size: jpeg.size,
			mime: "image/jpeg"
		});
	}
	return out;
}
function canAddEvidence(current, incoming) {
	return current + incoming <= MAX_FILES;
}
function evidenceSrc(item) {
	return item.dataUrl || sessionBlobs.get(item.id) || "";
}
var SEED_STORY = "якобы продает фтп.\nКлянчит деньги по мелочи 50-100 баксов и включает дурачка, не может выдать, надо еще докинуть или просто игнорит.";
var SEED_AT = Date.UTC(2026, 7, 26, 12, 0, 0);
var seedPublished = {
	id: "EPB-SEED",
	createdAt: SEED_AT,
	publishedAt: SEED_AT,
	status: "published",
	victim: {
		username: "archive_epb",
		telegramId: "1000000001",
		firstName: "Archive"
	},
	scammer: {
		username: "LopataBuild",
		telegramId: "5213159067"
	},
	story: SEED_STORY,
	summary: "якобы продает фтп, клянчит 50-100$ и пропадает.",
	damageAmount: "100",
	damageCurrency: "USD",
	evidence: []
};
var emptyIdentity = {
	firstName: "",
	username: "",
	telegramId: ""
};
function safeStorage() {
	try {
		const storage = window.localStorage;
		const key = "__epb__";
		storage.setItem(key, "1");
		storage.removeItem(key);
		return storage;
	} catch {
		return {
			length: 0,
			clear() {},
			getItem() {
				return null;
			},
			key() {
				return null;
			},
			removeItem() {},
			setItem() {}
		};
	}
}
var useBlacklistStore = create()(persist((set) => ({
	identity: emptyIdentity,
	locale: "ru",
	applications: [seedPublished],
	setIdentity: (patch) => set((s) => ({ identity: {
		...s.identity,
		...patch
	} })),
	setLocale: (locale) => {
		persistLocale(locale);
		set({ locale });
	},
	submitApplication: (app) => set((s) => ({ applications: [app, ...s.applications] })),
	publishApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "published",
		publishedAt: Date.now()
	} : a) })),
	rejectApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "rejected",
		rejectedAt: Date.now()
	} : a) })),
	resetDemo: () => set({
		identity: emptyIdentity,
		locale: detectLocale(),
		applications: [seedPublished]
	})
}), {
	name: "epb-blacklist",
	storage: createJSONStorage(() => safeStorage()),
	skipHydration: true,
	partialize: (s) => ({
		applications: s.applications,
		locale: s.locale
	})
}));
function rehydrateBlacklistStore() {
	Promise.resolve(useBlacklistStore.persist.rehydrate()).then(() => {
		if (!hasSavedLocale()) return;
		const stored = useBlacklistStore.getState().locale;
		if (stored === "ru" || stored === "en") persistLocale(stored);
	});
}
function EvidencePicker({ files, onChange }) {
	const locale = useBlacklistStore((s) => s.locale);
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [progress, setProgress] = (0, import_react.useState)("");
	async function addFiles(list) {
		const incoming = Array.from(list).filter(isEvidenceFile);
		if (!incoming.length) return;
		if (!canAddEvidence(files.length, incoming.length)) {
			setError(t(locale, "maxFiles", { n: 30 }));
			return;
		}
		setError("");
		setBusy(true);
		setProgress("");
		try {
			const next = [];
			for (let i = 0; i < incoming.length; i++) {
				const file = incoming[i];
				setProgress(incoming.length > 1 ? t(locale, "uploadingN", {
					i: i + 1,
					n: incoming.length
				}) : file.type.startsWith("video/") ? t(locale, "uploadingVideo") : t(locale, "uploadingFile"));
				next.push(await fileToEvidence(file, (done, total) => {
					setProgress(incoming.length > 1 ? t(locale, "uploadingNProgress", {
						i: i + 1,
						n: incoming.length,
						done,
						total
					}) : t(locale, "uploadingVideoProgress", {
						done,
						total
					}));
				}));
			}
			onChange([...files, ...next]);
		} catch {
			setError(t(locale, "uploadFail"));
		} finally {
			setBusy(false);
			setProgress("");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*,video/*",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					if (e.target.files) addFiles(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => {
					e.preventDefault();
				},
				onDrop: (e) => {
					e.preventDefault();
					if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
				},
				className: cn("flex min-h-28 w-full flex-col items-center justify-center gap-2 rounded-2xl bg-surface px-4 py-6 text-center shadow-[0_0_0_1px_rgba(243,239,228,0.10)]", "hover:bg-surface-2"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-fg",
						children: busy ? progress || t(locale, "uploading") : t(locale, "dropFiles")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: t(locale, "dropHint", { n: 30 })
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-3 gap-2",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, { item: file }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "icon",
						className: "absolute top-1 right-1 size-8 rounded-full",
						onClick: () => onChange(files.filter((f) => f.id !== file.id)),
						"aria-label": t(locale, "removeFile"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, file.id))
			}) : null
		]
	});
}
function EvidenceThumb({ item }) {
	const src = evidenceSrc(item);
	if (item.kind === "video") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square overflow-hidden rounded-lg bg-surface-2",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			className: "size-full object-cover img-outline",
			muted: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex size-full items-center justify-center text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute bottom-1 left-1 rounded-sm bg-bg/80 px-1.5 py-0.5 text-xs font-medium tracking-wide text-fg",
			children: "VIDEO"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: item.name,
		className: "aspect-square w-full rounded-lg object-cover img-outline"
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
createServerFn({ method: "GET" }).handler(createSsrRpc("35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b"));
createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(4096).optional()
})).handler(createSsrRpc("ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093"));
var evidenceSchema = object({
	id: string().max(40),
	kind: _enum(["image", "video"]),
	name: string().max(200),
	size: number().nonnegative().max(2147483647),
	mime: string().max(80),
	dataUrl: string().max(80).optional().default(""),
	storageKey: string().max(80).optional()
});
var personSchema = object({
	username: string().max(64),
	telegramId: string().max(20),
	firstName: string().max(64).optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(5e3),
	summary: string().min(10).max(800),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().max(16384).optional(),
	locale: _enum(["ru", "en"]).optional()
});
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(createSsrRpc("60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359"));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(createSsrRpc("308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e"));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({
	telegramId: string().min(1).max(20),
	initData: string().max(4096).optional()
})).handler(createSsrRpc("8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da"));
var saveUserLocale = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	locale: _enum(["ru", "en"])
})).handler(createSsrRpc("11d2abc3e6b37013d6db0d65775d802606c07fa20c30974f0bdb6267adcd933f"));
var checkCounterparty = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(16384)
})).handler(createSsrRpc("2d472c3ddcd5f68c787b571931a54cb87506748cc8d6701b6ba316f30d5f9c13"));
var getFeatures = createServerFn({ method: "GET" }).handler(createSsrRpc("1e6f5eee2bcdda2bc5a98f0ab7b0ce73f7b151332e14ed173cef508c1244730a"));
var getBanners = createServerFn({ method: "GET" }).handler(createSsrRpc("c92ddbdf60c25136c999dc716b14d40a8e263c2991c82d6a7e299679f89d5a92"));
var getSponsors = createServerFn({ method: "GET" }).handler(createSsrRpc("db4120598d8871d8ab7232bc07450195064ca19d0d7200897b93b10502c9ded7"));
createServerFn({ method: "GET" }).handler(createSsrRpc("2d0a921e77890fa9e04902a0c26433c58e821a6a5ae27fd6894b84b12c1c1d10"));
var getRecentBlacklist = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(createSsrRpc("de3182526ef98fe284877678fbffa5a010fe5e4a323128619c963dd2ce2e7396"));
var getBlacklistEntry = createServerFn({ method: "POST" }).validator(object({
	id: string().min(1).max(80),
	initData: string().max(16384)
})).handler(createSsrRpc("97b5ba3a1bcbd875c36ae5b3ab4bb3ca7c878ba6e6a91dc044a5a8519dd604b4"));
var getAccess = createServerFn({ method: "POST" }).validator(object({ initData: string().max(16384) })).handler(createSsrRpc("e3a3a791ffaa9c3999d70e9f613b39bc798206b96b103fad776884c8b6863ab3"));
var CURRENCIES = ["USD", "EUR"];
var MAX_ACCOUNTS = 8;
function emptyAcc() {
	return {
		key: uid("acc"),
		input: "",
		username: "",
		id: "",
		idLocked: false
	};
}
function ApplyForm({ onSubmitted, onBack }) {
	const identity = useBlacklistStore((s) => s.identity);
	const locale = useBlacklistStore((s) => s.locale);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const submitApplication = useBlacklistStore((s) => s.submitApplication);
	const [accounts, setAccounts] = (0, import_react.useState)([emptyAcc()]);
	const [summary, setSummary] = (0, import_react.useState)("");
	const [story, setStory] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("USD");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [formError, setFormError] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const tg = readTelegramWebUser();
		if (!tg) return;
		setIdentity(tg);
	}, [setIdentity]);
	async function onSubmit(e) {
		e.preventDefault();
		setFormError("");
		const tgUser = readTelegramWebUser();
		const vUser = (tgUser?.username || "").replace(/^@/, "").trim();
		const vId = tgUser?.telegramId || "";
		if (!vId) {
			setFormError(t(locale, "errOpenBot"));
			return;
		}
		const filled = accounts.map((a) => ({
			username: a.username.replace(/^@/, "").trim(),
			telegramId: a.id.trim()
		})).filter((a) => a.username || a.telegramId);
		if (!filled.length) {
			setFormError(t(locale, "errAccount"));
			return;
		}
		if (filled.some((a) => !a.telegramId)) {
			setFormError(t(locale, "idNotFound"));
			return;
		}
		if (summary.trim().length < 10) {
			setFormError(t(locale, "errSummary"));
			return;
		}
		if (summary.trim().length > 800) {
			setFormError(t(locale, "errSummaryLong"));
			return;
		}
		if (story.trim().length < 20) {
			setFormError(t(locale, "errStory"));
			return;
		}
		if (story.trim().length > 5e3) {
			setFormError(t(locale, "errStoryLong"));
			return;
		}
		const parsedAmount = parseDamageAmount(amount);
		if (!parsedAmount) {
			setFormError(t(locale, "errAmount"));
			return;
		}
		if (!files.length) {
			setFormError(t(locale, "errFiles"));
			return;
		}
		setSending(true);
		try {
			const uploaded = await persistEvidence(files);
			setFiles(uploaded);
			const app = {
				id: `EPB-${uid().slice(0, 4).toUpperCase()}`,
				createdAt: Date.now(),
				status: "pending",
				victim: {
					username: vUser,
					telegramId: vId,
					firstName: tgUser?.firstName || identity.firstName
				},
				scammer: filled[0],
				scammers: filled,
				story: story.trim(),
				summary: summary.trim(),
				damageAmount: parsedAmount.amount,
				damageCurrency: parsedAmount.currency || currency,
				evidence: uploaded.map((f) => ({
					...f,
					dataUrl: ""
				}))
			};
			const tg = await Promise.race([submitToTelegram({ data: {
				...app,
				initData: telegramInitData(),
				locale
			} }), new Promise((resolve) => window.setTimeout(() => resolve({
				ok: false,
				error: t(locale, "errTimeout")
			}), 9e4))]);
			if (!tg.ok) {
				setFormError(tg.error || t(locale, "sentFail"));
				return;
			}
			submitApplication(app);
			setIdentity({
				username: vUser,
				telegramId: vId,
				firstName: tgUser?.firstName || identity.firstName
			});
			onSubmitted(t(locale, "sentOk"));
		} catch {
			setFormError(t(locale, "sentFail"));
		} finally {
			setSending(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "relative flex min-h-0 flex-1 flex-col overflow-hidden",
		children: [
			sending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0 z-30 flex flex-col items-center justify-center gap-6 bg-bg/95 px-8 text-center backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
						size: 112,
						title: "Europe Private Blacklist",
						spin: true,
						fast: true,
						emblem: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-bold",
							children: t(locale, "sendingTitle")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t(locale, "sendingHint")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "epb-progress h-1.5 w-56 max-w-full rounded-full bg-surface" })
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-md flex-col gap-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									haptic("light");
									onBack();
								},
								"aria-label": t(locale, "back"),
								className: "-ml-2 flex size-9 shrink-0 items-center justify-center rounded-xl text-fg hover:bg-surface",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-bold",
								children: t(locale, "fileComplaint")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-lg font-bold",
										children: t(locale, "accTitle")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: t(locale, "accHint")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: accounts.map((acc, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScammerAccountRow, {
										index,
										row: acc,
										canRemove: accounts.length > 1,
										onChange: (next) => setAccounts((prev) => prev.map((item) => item.key === acc.key ? {
											...item,
											...next
										} : item)),
										onRemove: () => setAccounts((prev) => prev.filter((item) => item.key !== acc.key))
									}, acc.key))
								}),
								accounts.length < MAX_ACCOUNTS ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-surface text-sm font-semibold text-gold shadow-[0_0_0_1px_rgba(240,196,48,0.28)] hover:bg-surface-2",
									onClick: () => setAccounts((prev) => [...prev, emptyAcc()]),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), t(locale, "addAccount")]
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-lg font-bold",
										children: t(locale, "summaryTitle")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: t(locale, "summaryHint")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: summary,
									onChange: (e) => setSummary(e.target.value.slice(0, 800)),
									maxLength: 800,
									placeholder: t(locale, "summaryPh")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-right text-xs text-subtle",
									children: [summary.length, "/800"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-lg font-bold",
										children: t(locale, "storyTitle")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: t(locale, "storyHint")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: story,
									onChange: (e) => setStory(e.target.value.slice(0, 5e3)),
									maxLength: 5e3,
									placeholder: t(locale, "storyPh")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-right text-xs text-subtle",
									children: [story.length, "/5000"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t(locale, "amount"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "decimal",
											value: amount,
											onChange: (e) => setAmount(e.target.value.replace(/[^\d.,\s]/g, "")),
											placeholder: "15,000"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: t(locale, "currency"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid h-11 grid-cols-2 overflow-hidden rounded-xl shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
											children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setCurrency(c),
												className: cn("h-11 px-1 text-xs font-semibold transition-colors", currency === c ? "bg-gold text-gold-fg" : "bg-surface text-muted hover:text-fg"),
												children: c
											}, c))
										})
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: t(locale, "evidenceTitle")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t(locale, "evidenceHint")
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePicker, {
								files,
								onChange: setFiles
							})]
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-danger",
							children: formError
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0 border-t border-line bg-bg px-4 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full",
					disabled: sending,
					children: sending ? t(locale, "sending") : t(locale, "send")
				})
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function ScammerAccountRow({ index, row, canRemove, onChange, onRemove }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [resolving, setResolving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const idRef = (0, import_react.useRef)(row.id);
	idRef.current = row.id;
	(0, import_react.useEffect)(() => {
		const value = row.input.trim();
		setError("");
		if (!value) {
			if (row.username || row.id) onChange({
				username: "",
				id: "",
				idLocked: false
			});
			return;
		}
		const parsed = parseTelegramInput(value);
		if (parsed.id) {
			onChange({
				username: parsed.username,
				id: parsed.id,
				idLocked: false
			});
			setResolving(false);
			return;
		}
		onChange({
			username: parsed.username,
			id: "",
			idLocked: false
		});
		if (parsed.username.length < 4) {
			setResolving(false);
			return;
		}
		let cancelled = false;
		setResolving(true);
		const timer = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await lookupTelegramHandle(value);
				} catch {
					res = null;
				}
				if (cancelled) return;
				setResolving(false);
				if (!res) {
					onChange({
						username: parsed.username,
						id: idRef.current
					});
					if (!idRef.current) setError(t(locale, "parseFail"));
					return;
				}
				if (res.id) {
					onChange({
						username: res.username,
						id: res.id,
						idLocked: res.source === "telegram"
					});
					setError("");
					return;
				}
				onChange({
					username: res.username,
					id: idRef.current
				});
				if (!idRef.current) setError(t(locale, res.busy ? "idBusy" : "idNotFound"));
			})();
		}, 900);
		return () => {
			cancelled = true;
			clearTimeout(timer);
		};
	}, [row.input]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-2xl bg-surface/70 p-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-semibold text-muted",
					children: [
						t(locale, "accountN"),
						" ",
						index + 1
					]
				}), canRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-8 items-center justify-center rounded-md text-muted hover:bg-surface-2 hover:text-fg",
					onClick: onRemove,
					"aria-label": t(locale, "removeAccount"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Telegram",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.input,
					onChange: (e) => onChange({ input: e.target.value }),
					placeholder: t(locale, "accPlaceholder"),
					required: index === 0
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "ID",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: row.id,
					readOnly: true,
					tabIndex: -1,
					"aria-readonly": true,
					className: "cursor-not-allowed opacity-70",
					placeholder: t(locale, "idAuto"),
					inputMode: "numeric",
					required: false
				})
			}),
			row.idLocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: t(locale, "idLocked")
			}) : null,
			resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-1.5 text-sm text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), t(locale, "resolvingId")]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null
		]
	});
}
function MiniApp({ page, onPage, onClose, onReview, embedded = false }) {
	const [notice, setNotice] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [langPicked, setLangPicked] = (0, import_react.useState)(null);
	const identity = useBlacklistStore((s) => s.identity);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const locale = useBlacklistStore((s) => s.locale);
	const openComplaint = (0, import_react.useCallback)(() => onPage("apply"), [onPage]);
	const openHistory = (0, import_react.useCallback)(() => onPage("history"), [onPage]);
	const openOwners = (0, import_react.useCallback)(() => onPage("owners"), [onPage]);
	const openCheck = (0, import_react.useCallback)(() => onPage("check"), [onPage]);
	const openSponsors = (0, import_react.useCallback)(() => onPage("sponsors"), [onPage]);
	const [checkOn, setCheckOn] = (0, import_react.useState)(false);
	const [banned, setBanned] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		getFeatures().then((f) => setCheckOn(Boolean(f?.check))).catch(() => {});
	}, []);
	(0, import_react.useEffect)(() => {
		rehydrateBlacklistStore();
		bootTelegramWebApp();
		if (hasSavedLocale()) {
			const saved = window.localStorage.getItem("epb-locale");
			if (saved === "ru" || saved === "en") useBlacklistStore.getState().setLocale(saved);
			setLangPicked(true);
		} else setLangPicked(false);
		const unlock = lockTelegramViewport();
		let cancelled = false;
		(async () => {
			const user = await waitForTelegramUser(2500) || readTelegramWebUser();
			if (cancelled) return;
			if (user) try {
				setIdentity(user);
			} catch {}
			try {
				const init = telegramInitData();
				if (init) {
					const acc = await getAccess({ data: { initData: init } });
					if (!cancelled && acc?.banned) setBanned(true);
				}
			} catch {}
			if (cancelled) return;
			setReady(true);
		})();
		return () => {
			cancelled = true;
			unlock();
		};
	}, [setIdentity]);
	const showLang = ready && !banned && langPicked === false;
	const showApp = ready && !banned && langPicked === true;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex flex-col overflow-hidden overscroll-none bg-bg text-fg", !embedded && "z-50"),
		style: {
			position: "fixed",
			left: 0,
			right: 0,
			top: "var(--app-top, 0px)",
			height: "var(--app-h, 100dvh)",
			maxHeight: "var(--app-h, 100dvh)",
			paddingTop: "var(--tg-safe-top, 0px)"
		},
		children: [showApp && ![
			"home",
			"sponsors",
			"check",
			"apply"
		].includes(page) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute left-2 z-10 flex size-11 items-center justify-center rounded-xl text-fg hover:bg-surface",
			style: { top: "calc(var(--tg-safe-top, 0px) + 4px)" },
			onClick: () => onPage("home"),
			"aria-label": t(locale, "back"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex min-h-0 flex-1 flex-col overflow-hidden", showApp && ![
				"home",
				"sponsors",
				"check",
				"apply"
			].includes(page) && "pt-10"),
			children: [
				!showApp && !showLang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountLoading, { locale }) : null,
				ready && banned ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1 flex-col items-center justify-center px-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
							size: 112,
							title: "Europe Private Blacklist",
							emblem: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 font-display text-xl font-bold",
							children: t(locale, "bannedTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
							children: t(locale, "bannedText")
						})
					]
				}) : null,
				showLang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageGate, { onPicked: () => setLangPicked(true) }) : null,
				showApp && page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, {
					identity,
					onComplaint: openComplaint,
					onHistory: openHistory,
					onOwners: openOwners,
					onCheck: openCheck,
					onSponsors: openSponsors,
					checkOn
				}) : null,
				showApp && page === "apply" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyForm, {
					onBack: () => onPage("home"),
					onSubmitted: (msg) => {
						setNotice(msg ?? "");
						onPage("done");
					}
				}) : null,
				showApp && page === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { telegramId: identity.telegramId }) : null,
				showApp && page === "check" && checkOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCounterparty, { onBack: () => onPage("home") }) : null,
				showApp && page === "owners" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnersGuide, {}) : null,
				showApp && page === "sponsors" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorsPage, { onBack: () => onPage("home") }) : null,
				showApp && page === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, {
					onPage,
					onClose,
					onReview,
					notice
				}) : null
			]
		})]
	});
}
function persistLangToBot(locale) {
	const initData = telegramInitData();
	if (!initData) return;
	saveUserLocale({ data: {
		initData,
		locale
	} }).catch(() => {});
}
function LangSwitch() {
	const locale = useBlacklistStore((s) => s.locale);
	const setLocale = useBlacklistStore((s) => s.setLocale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-1 rounded-full bg-surface p-1 shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
		children: ["ru", "en"].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => {
				setLocale(code);
				persistLangToBot(code);
			},
			className: cn("rounded-full px-3 py-1 text-xs font-bold", locale === code ? "bg-gold text-gold-fg" : "text-muted hover:text-fg"),
			children: code === "ru" ? "Русский" : "English"
		}, code))
	});
}
function LanguageGate({ onPicked }) {
	const setLocale = useBlacklistStore((s) => s.setLocale);
	function pick(code) {
		setLocale(code);
		persistLangToBot(code);
		onPicked();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 128,
				title: "Europe Private Blacklist",
				spin: true,
				emblem: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "mt-7 font-display text-3xl font-extrabold tracking-tight uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-fg",
					children: "Europe Private"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "epb-gold-text block",
					children: "Blacklist"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-sm text-muted",
				children: "Выберите язык / Choose language"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex w-full max-w-md flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: () => pick("ru"),
					children: "Русский"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "secondary",
					className: "w-full rounded-xl",
					onClick: () => pick("en"),
					children: "English"
				})]
			})
		]
	});
}
function AccountLoading({ locale }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center px-4 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 120,
				title: "Europe Private Blacklist",
				spin: true,
				emblem: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-display text-lg font-bold",
				children: t(locale, "loadingTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xs text-sm leading-relaxed text-muted",
				children: t(locale, "loadingText")
			})
		]
	});
}
function Banners() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [active, setActive] = (0, import_react.useState)(0);
	const scrollerRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		getBanners().then((list) => setItems(Array.isArray(list) ? list : [])).catch(() => {});
	}, []);
	if (!items.length) return null;
	const open = (link) => {
		if (!link) return;
		haptic("light");
		openExternal(link);
	};
	const onScroll = () => {
		const el = scrollerRef.current;
		if (!el) return;
		setActive(Math.round(el.scrollLeft / (el.clientWidth || 1)));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-md pt-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: scrollerRef,
			onScroll,
			className: "flex snap-x snap-mandatory items-start gap-3 overflow-x-auto overscroll-x-contain [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
			children: items.map((b) => {
				const ratio = b.width && b.height ? `${b.width} / ${b.height}` : void 0;
				const mediaClass = ratio ? "block size-full object-cover" : "block h-auto max-h-[80vh] w-full object-contain";
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => open(b.link),
					"aria-label": "banner",
					style: ratio ? {
						aspectRatio: ratio,
						maxHeight: "80vh"
					} : void 0,
					className: cn("relative block w-full shrink-0 snap-center overflow-hidden rounded-2xl bg-surface shadow-[0_0_0_1px_rgba(243,239,228,0.08)]", b.link ? "cursor-pointer" : "cursor-default"),
					children: b.type === "video" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
						src: b.src,
						autoPlay: true,
						muted: true,
						loop: true,
						playsInline: true,
						preload: "metadata",
						className: mediaClass
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: b.src,
						alt: "",
						className: mediaClass,
						loading: "lazy"
					})
				}, b.id);
			})
		}), items.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex justify-center gap-1.5",
			children: items.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1.5 rounded-full transition-all", i === active ? "w-4 bg-gold" : "w-1.5 bg-muted/40") }, b.id))
		}) : null]
	});
}
function Home$1({ identity, onComplaint, onHistory, onOwners, onCheck, onSponsors, checkOn }) {
	const locale = useBlacklistStore((s) => s.locale);
	const handle = identity.username ? `@${identity.username}` : identity.firstName || (identity.telegramId ? `ID ${identity.telegramId}` : "");
	const canUse = Boolean(identity.telegramId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col overflow-y-auto overscroll-contain px-4 [touch-action:pan-y]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banners, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorsTicker, { onOpen: onSponsors })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center py-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LangSwitch, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
						size: 128,
						title: "Europe Private Blacklist",
						spin: true,
						emblem: true,
						className: "mt-5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-7 font-display text-3xl font-extrabold tracking-tight uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-fg",
							children: "Europe Private"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "epb-gold-text block",
							children: "Blacklist"
						})]
					}),
					handle ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-xs text-subtle",
						children: t(locale, "openFromBot")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex w-full max-w-md flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							className: "w-full rounded-xl",
							onClick: onComplaint,
							disabled: !canUse,
							children: t(locale, "fileComplaint")
						}), checkOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							variant: "secondary",
							className: "w-full rounded-xl",
							onClick: onCheck,
							disabled: !canUse,
							children: t(locale, "checkBtn")
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: CHANNEL_URL,
						target: "_blank",
						rel: "noreferrer",
						className: "mt-5 text-sm font-medium text-gold underline underline-offset-4",
						children: t(locale, "subscribe")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onOwners,
				className: "mx-auto mb-5 mt-4 text-sm font-medium text-muted underline underline-offset-4",
				children: t(locale, "ownersLink")
			})
		]
	});
}
var SPONSORS_CACHE_KEY = "epb-sponsors";
var PARTNER_LOGOS = [
	{
		src: "/partners/wwh.png",
		alt: "WWH Club",
		r: 740 / 128
	},
	{
		src: "/partners/animal-planet.png",
		alt: "Animal Planet Blacklist",
		r: 1
	},
	{
		src: "/partners/kidalam.png",
		alt: "KidaLam NeT",
		r: 1
	},
	{
		src: "/partners/z-black.png",
		alt: "Z-BLACK",
		r: 122 / 128
	},
	{
		src: "/partners/pi.png",
		alt: "π",
		r: 107 / 128
	},
	{
		src: "/partners/ws-blacklist.png",
		alt: "WS Blacklist",
		r: 1
	},
	{
		src: "/partners/cookie.png",
		alt: "Cookie Blacklist",
		r: 1
	}
];
function PartnerLogos({ size, gap = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: PARTNER_LOGOS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex shrink-0 items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: l.src,
			alt: l.alt,
			draggable: false,
			width: Math.round(size * l.r),
			height: size,
			loading: "eager",
			decoding: "async",
			style: {
				width: Math.round(size * l.r),
				height: size
			},
			className: "max-w-none shrink-0 select-none"
		}), gap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-6 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mx-3 text-gold/40",
			children: "·"
		})]
	}, l.src)) });
}
function GoldText({ text }) {
	const parts = text.split(/(\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)/u);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: parts.map((p, i) => !p ? null : /\p{Extended_Pictographic}/u.test(p) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p }, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "epb-gold-text",
		children: p
	}, i)) });
}
function SponsorsTicker({ onOpen }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [items, setItems] = (0, import_react.useState)(() => {
		try {
			const raw = sessionStorage.getItem(SPONSORS_CACHE_KEY);
			return raw ? JSON.parse(raw) : [];
		} catch {
			return [];
		}
	});
	(0, import_react.useEffect)(() => {
		getSponsors().then((s) => {
			const list = Array.isArray(s) ? s : [];
			setItems(list);
			try {
				sessionStorage.setItem(SPONSORS_CACHE_KEY, JSON.stringify(list));
			} catch {}
		}).catch(() => {});
	}, []);
	const Seq = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerLogos, { size: 24 }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "epb-gold-text opacity-80",
				children: t(locale, "sponsorsTitle")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-3 text-gold/40",
				children: "·"
			})]
		}),
		items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoldText, { text: s.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-3 text-gold/40",
				children: "/"
			})]
		}, s.id))
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => {
			if (onOpen) {
				haptic("light");
				onOpen();
			}
		},
		"aria-label": "project sponsors",
		className: "group relative mt-4 flex w-full items-center overflow-hidden rounded-xl bg-surface/60 py-2 shadow-[0_0_0_1px_rgba(240,196,48,0.14)]",
		style: { "--epb-marquee-dur": `${Math.max(12, items.length * 2.5 + PARTNER_LOGOS.length * 1.6)}s` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "epb-marquee-track text-sm font-semibold tracking-tight text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seq, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seq, {})]
			}, items.length),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-bg to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-bg to-transparent" })
		]
	});
}
function SponsorAvatar({ src, title }) {
	if (src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: "size-9 shrink-0 rounded-full object-cover",
		loading: "lazy"
	});
	const letter = (title || "?").replace(/^@/, "").charAt(0).toUpperCase() || "?";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex size-9 shrink-0 items-center justify-center rounded-full bg-surface-2 text-xs font-bold text-muted",
		children: letter
	});
}
function SponsorsPage({ onBack }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getSponsors().then((s) => setItems(Array.isArray(s) ? s : [])).catch(() => setItems([]));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							haptic("light");
							onBack();
						},
						"aria-label": t(locale, "back"),
						className: "-ml-2 flex size-9 shrink-0 items-center justify-center rounded-xl text-fg hover:bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold",
						children: t(locale, "sponsorsTitle")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative overflow-hidden rounded-2xl bg-surface/60 py-3 shadow-[0_0_0_1px_rgba(240,196,48,0.14)]",
					style: { "--epb-marquee-dur": "22s" },
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "epb-marquee-track",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerLogos, {
								size: 48,
								gap: true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartnerLogos, {
								size: 48,
								gap: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-bg to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pointer-events-none absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-bg to-transparent" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: t(locale, "sponsorsHeader")
				}),
				items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[52px] animate-pulse rounded-2xl bg-surface/60" }, i))
				}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-center text-sm text-muted",
					children: t(locale, "sponsorsEmpty")
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: items.map((s) => s.link ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							haptic("light");
							openExternal(s.link);
						},
						className: "flex w-full items-center gap-3 rounded-2xl bg-surface/70 p-2.5 text-left shadow-[0_0_0_1px_rgba(243,239,228,0.08)] hover:bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorAvatar, {
								src: s.avatar,
								title: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate font-semibold text-gold",
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4 shrink-0 text-gold" })
						]
					}, s.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-2xl bg-surface/70 p-2.5 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SponsorAvatar, {
							src: s.avatar,
							title: s.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 flex-1 truncate font-semibold",
							children: s.title
						})]
					}, s.id))
				})
			]
		})
	});
}
function OwnersGuide() {
	const locale = useBlacklistStore((s) => s.locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md space-y-5 text-sm leading-relaxed",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-bold",
					children: t(locale, "ownersTitle")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: t(locale, "ownersIntro")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-base font-bold",
							children: t(locale, "ownersHow")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersStep1") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: t(locale, "ownersStep2")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersGroup") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersChannel") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t(locale, "ownersStep3") })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						t(locale, "ownersHelp"),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://t.me/EuropePromo",
							target: "_blank",
							rel: "noreferrer",
							className: "font-medium text-gold",
							children: "@EuropePromo"
						})
					]
				})
			]
		})
	});
}
function History({ telegramId }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [items, setItems] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		async function load() {
			if (!telegramId) {
				setItems([]);
				return;
			}
			try {
				const list = await getMyComplaints({ data: {
					telegramId,
					initData: telegramInitData()
				} });
				if (!cancelled) setItems(list);
			} catch {
				if (!cancelled) setItems([]);
			}
		}
		load();
		const tmr = window.setInterval(() => void load(), 8e3);
		return () => {
			cancelled = true;
			window.clearInterval(tmr);
		};
	}, [telegramId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-md space-y-3",
			children: items === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center justify-center gap-2 py-16 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-gold" }), t(locale, "historyLoading")]
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-sm text-muted",
				children: t(locale, "historyEmpty")
			}) : items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryCard, { item }, item.id))
		})
	});
}
var RECENT_CACHE_KEY = "epb-recent-bl";
var EUROPE_PROMO_URL = "https://t.me/EuropePromo";
var FORUM_ALIASES = [{
	re: /wwh/i,
	name: "WWH"
}];
function forumName(title) {
	const t = (title || "").trim();
	for (const a of FORUM_ALIASES) if (a.re.test(t)) return a.name;
	return t || "форум";
}
function isWWH(title) {
	return /wwh/i.test(title || "");
}
var fmtBlDate = (locale, ms) => ms ? new Date(ms).toLocaleDateString(locale === "en" ? "en-GB" : "ru-RU", {
	day: "2-digit",
	month: "2-digit",
	year: "2-digit"
}) : "";
function CheckCounterparty({ onBack }) {
	const locale = useBlacklistStore((s) => s.locale);
	const [value, setValue] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [data, setData] = (0, import_react.useState)(null);
	const [recent, setRecent] = (0, import_react.useState)(() => {
		try {
			const raw = sessionStorage.getItem(RECENT_CACHE_KEY);
			return raw ? JSON.parse(raw) : [];
		} catch {
			return [];
		}
	});
	const [recentLoading, setRecentLoading] = (0, import_react.useState)(recent.length === 0);
	const [detail, setDetail] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		getRecentBlacklist({ data: { initData: telegramInitData() } }).then((r) => {
			if (cancelled || !r.ok) return;
			const items = r.items;
			setRecent(items);
			try {
				sessionStorage.setItem(RECENT_CACHE_KEY, JSON.stringify(items));
			} catch {}
		}).catch(() => {}).finally(() => {
			if (!cancelled) setRecentLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	async function run() {
		const input = value.trim();
		if (!input) {
			setError(t(locale, "checkEmptyInput"));
			return;
		}
		haptic("light");
		setError("");
		setLoading(true);
		setData(null);
		try {
			const res = await checkCounterparty({ data: {
				input,
				initData: telegramInitData()
			} });
			if (res.ok) {
				const r = res.result;
				setData(r);
				haptic(r.epb.length || r.channels.length || (r.manual?.length ?? 0) ? "heavy" : "soft");
			} else setError(t(locale, "checkFail"));
		} catch {
			setError(t(locale, "checkFail"));
		} finally {
			setLoading(false);
		}
	}
	const open = (e) => {
		haptic("light");
		setDetail(e);
	};
	const epbEntry = (e) => ({
		kind: "epb",
		id: e.id,
		account: e.accounts || e.id,
		amount: e.amount,
		currency: e.currency,
		date: e.date
	});
	const manualEntry = (m) => ({
		kind: "manual",
		id: m.id,
		account: m.account,
		date: m.date,
		source: m.source,
		note: m.note
	});
	if (detail) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlacklistDetail, {
		entry: detail,
		onBack: () => setDetail(null)
	});
	const found = data && (data.epb.length > 0 || data.channels.length > 0 || (data.manual?.length ?? 0) > 0);
	const fmtDate = (ms) => fmtBlDate(locale, ms);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								haptic("light");
								onBack();
							},
							"aria-label": t(locale, "back"),
							className: "-ml-2 flex size-9 shrink-0 items-center justify-center rounded-xl text-fg hover:bg-surface",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-bold",
							children: t(locale, "checkTitle")
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(locale, "checkHint")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value,
						onChange: (e) => {
							setValue(e.target.value.slice(0, 200));
							setError("");
						},
						onKeyDown: (e) => {
							if (e.key === "Enter") run();
						},
						placeholder: t(locale, "checkPlaceholder"),
						autoComplete: "off",
						autoCapitalize: "none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "shrink-0 rounded-xl px-4",
						onClick: () => void run(),
						disabled: loading,
						children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4" })
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-danger",
					children: error
				}) : null,
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 py-10 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-gold" }), t(locale, "checkChecking")]
				}) : null,
				data && !loading ? found ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						data.epb.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-bold text-danger",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), t(locale, "checkInEpb")]
							}), data.epb.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlacklistRow, {
								account: e.accounts || e.id,
								sub: `${t(locale, "checkEpbItem", {
									id: e.id,
									amount: e.amount,
									currency: e.currency
								})}${fmtDate(e.date) ? ` · ${fmtDate(e.date)}` : ""}`,
								onClick: () => open(epbEntry(e))
							}, e.id))]
						}) : null,
						data.manual?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-bold text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), t(locale, "checkInExternal")]
							}), data.manual.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlacklistRow, {
								account: m.account,
								sub: m.source,
								onClick: () => open(manualEntry(m))
							}, m.id))]
						}) : null,
						data.channels.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 text-sm font-bold text-gold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), t(locale, data.channels.every((c) => isWWH(c.channelTitle)) ? "checkOnForum" : "checkInChats")]
							}), data.channels.map((c, i) => {
								const wwh = isWWH(c.channelTitle);
								const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold",
											children: forumName(c.channelTitle)
										}), !wwh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex shrink-0 items-center gap-1 text-xs text-gold",
											children: [
												t(locale, "checkOpen"),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })
											]
										}) : null]
									}),
									c.snippet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs leading-relaxed text-muted",
										children: c.snippet
									}) : null,
									fmtDate(c.date) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-[11px] text-subtle",
										children: fmtDate(c.date)
									}) : null
								] });
								const cls = "block rounded-2xl bg-surface/70 p-3 text-sm shadow-[0_0_0_1px_rgba(243,239,228,0.08)]";
								return wwh ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: cls,
									children: body
								}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: c.link,
									target: "_blank",
									rel: "noreferrer",
									className: cls,
									children: body
								}, i);
							})]
						}) : null
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-3 py-10 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-10 text-ok" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg font-bold",
							children: t(locale, "checkClean")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xs text-sm leading-relaxed text-muted",
							children: t(locale, "checkCleanHint")
						})
					]
				}) : null,
				!data && !loading && (recent.length || recentLoading) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-sm font-bold text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-4" }), t(locale, "checkRecent")]
						}),
						recentLoading && !recent.length ? Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-[52px] animate-pulse rounded-2xl bg-surface/60" }, i)) : null,
						recent.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlacklistRow, {
							account: e.account || "—",
							sub: e.kind === "manual" ? e.source || t(locale, "checkInExternal") : e.kind === "find" ? e.source || t(locale, "checkFoundSub") : `${e.amount || ""} ${e.currency || ""}`.trim() + (fmtDate(e.date) ? ` · ${fmtDate(e.date)}` : ""),
							danger: e.kind === "epb" || e.kind === "find",
							onClick: () => open(e)
						}, e.id))
					]
				}) : null
			]
		})
	});
}
function BlacklistRow({ account, sub, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-center justify-between gap-2 rounded-2xl bg-surface/70 p-3 text-left text-sm shadow-[0_0_0_1px_rgba(243,239,228,0.08)] hover:bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("block truncate font-semibold", danger && "text-danger"),
				children: account
			}), sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block truncate text-xs text-muted",
				children: sub
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4 shrink-0 rotate-180 text-subtle" })]
	});
}
function BlacklistDetail({ entry, onBack }) {
	const locale = useBlacklistStore((s) => s.locale);
	const isManual = entry.kind === "manual";
	const isFind = entry.kind === "find";
	const isSimple = isManual || isFind;
	const [full, setFull] = (0, import_react.useState)(isSimple ? entry : null);
	const [loadingFull, setLoadingFull] = (0, import_react.useState)(!isSimple);
	(0, import_react.useEffect)(() => {
		if (isSimple) return;
		let cancelled = false;
		getBlacklistEntry({ data: {
			id: entry.id,
			initData: telegramInitData()
		} }).then((r) => {
			if (cancelled) return;
			if (r.ok && r.entry) setFull({
				...entry,
				...r.entry
			});
		}).catch(() => {}).finally(() => {
			if (!cancelled) setLoadingFull(false);
		});
		return () => {
			cancelled = true;
		};
	}, [entry, isSimple]);
	const shown = full || entry;
	const date = fmtBlDate(locale, shown.date);
	const situation = shown.story || shown.summary;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 [touch-action:pan-y]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto w-full max-w-md space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						haptic("light");
						onBack();
					},
					className: "flex items-center gap-1 text-sm font-medium text-muted hover:text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }),
						" ",
						t(locale, "back")
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-danger",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-bold break-words",
						children: shown.account || "—"
					})]
				}),
				isSimple ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-surface/70 p-4 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold text-gold",
								children: shown.source || t(locale, "checkInExternal")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed",
								children: t(locale, isFind ? "checkFoundDesc" : "checkExternalDesc")
							}),
							shown.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed text-muted",
								children: shown.note
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full rounded-xl",
						onClick: () => {
							haptic("light");
							openExternal(EUROPE_PROMO_URL);
						},
						children: t(locale, "checkDispute")
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-2xl bg-surface/70 p-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									t(locale, "checkDamageLabel"),
									":",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold text-fg",
										children: [
											shown.amount,
											" ",
											shown.currency
										]
									}),
									date ? ` · ${date}` : ""
								]
							})
						}),
						situation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-bold",
								children: t(locale, "checkSituation")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "whitespace-pre-wrap text-sm leading-relaxed text-muted",
								children: situation
							})]
						}) : loadingFull ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 py-4 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin text-gold" }), t(locale, "checkChecking")]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: CHANNEL_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex items-center gap-1 text-sm font-medium text-gold underline underline-offset-4",
							children: [
								t(locale, "subscribe"),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3" })
							]
						})
					]
				})
			]
		})
	});
}
function HistoryCard({ item }) {
	const locale = useBlacklistStore((s) => s.locale);
	const handle = item.scammerUsername ? item.scammerUsername.split(" · ").map((u) => {
		const name = u.replace(/^@/, "").trim();
		return name ? `@${name}` : "";
	}).filter(Boolean).join(" · ") : t(locale, "noUsername");
	const when = item.createdAt ? new Date(item.createdAt).toLocaleString(locale === "en" ? "en-GB" : "ru-RU", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit"
	}) : "";
	const statusLabel = item.status === "pending" ? t(locale, "statusPending") : item.status === "published" ? t(locale, "statusPublished") : t(locale, "statusRejected");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "rounded-2xl bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-bold leading-snug break-words",
						children: handle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-0.5 text-xs text-subtle break-words",
						children: [item.scammerId ? `Id: ${item.scammerId}` : "Id: -", item.amount ? ` · ${item.amount} ${item.currency}` : ""]
					}),
					when ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-subtle",
						children: when
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold", item.status === "pending" && "bg-gold/15 text-gold", item.status === "published" && "bg-ok/15 text-ok", item.status === "rejected" && "bg-danger/15 text-danger"),
				children: statusLabel
			})]
		})
	});
}
function Done({ onPage, onClose, onReview, notice }) {
	const locale = useBlacklistStore((s) => s.locale);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center overflow-y-auto overscroll-contain px-5 py-10 text-center [touch-action:pan-y]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
				size: 132,
				title: "Europe Private Blacklist",
				spin: true,
				emblem: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl font-bold",
				children: t(locale, "doneTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: notice || t(locale, "doneText")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex w-full max-w-md flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "w-full",
						onClick: () => {
							haptic("light");
							openExternal(EUROPE_PROMO_URL);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2",
							children: [
								t(locale, "addEvidence"),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "secondary",
						className: "w-full",
						onClick: () => onPage("home"),
						children: t(locale, "home")
					}),
					onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "ghost",
						className: "w-full",
						onClick: onClose,
						children: t(locale, "closeApp")
					}) : null
				]
			})
		]
	});
}
function Home() {
	const [page, setPage] = (0, import_react.useState)("home");
	const [canClose, setCanClose] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		bootTelegramWebApp();
		setCanClose(Boolean(window.Telegram?.WebApp?.close));
		configureTelegram({ data: { origin: window.location.origin } }).catch(() => {});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniApp, {
		page,
		onPage: setPage,
		embedded: true,
		onClose: canClose ? () => window.Telegram?.WebApp?.close?.() : void 0
	});
}
//#endregion
export { Home as component };
