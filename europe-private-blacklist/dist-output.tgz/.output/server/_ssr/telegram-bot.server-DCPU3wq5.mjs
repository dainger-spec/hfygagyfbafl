import { o as __toESM } from "../_runtime.mjs";
import { o as tb, r as isLocale } from "./i18n-DDQKq3x_.mjs";
import { createHash, createHmac, randomInt, randomUUID, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { deflateSync } from "node:zlib";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-DCPU3wq5.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+KkrYz9IKvoBmYTQy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{2,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{2,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{2,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
function parseDamageAmount(text) {
	const raw = String(text || "").trim();
	if (!raw) return null;
	const upper = raw.toUpperCase().replace(/Ё/g, "Е");
	let currency = null;
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	const numeric = raw.replace(/[\u00A0\u202F\u2009]/g, " ").replace(/[€$₽]/g, " ").replace(/\b(usd|eur|usdt|rub|евро|бакс\w*|доллар\w*|руб\w*)\b/gi, " ").replace(/[^\d.,\s]/g, " ").trim();
	if (!numeric) return null;
	const s = numeric.replace(/\s+/g, "");
	let normalized = "";
	if (/^\d{1,3}(,\d{3})+$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d+,\d{1,2}$/.test(s)) normalized = s.replace(",", ".");
	else if (/^\d+\.\d{1,2}$/.test(s)) normalized = s;
	else if (/^\d+$/.test(s)) normalized = s;
	else return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n <= 0) return null;
	return {
		amount: normalized.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ""),
		currency
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
async function lookupTelegramHandle(input) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 25e3);
	try {
		const res = await fetch("/api/telegram/resolve", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				input,
				initData: telegramInitData()
			}),
			signal: ctrl.signal
		});
		if (res.ok) {
			const json = await res.json();
			if (json?.username || json?.id) return json;
		}
	} catch {
		if (ctrl.signal.aborted) return {
			...await resolveTelegramId(input) || {
				username: "",
				id: ""
			},
			busy: true
		};
	} finally {
		clearTimeout(timer);
	}
	return resolveTelegramId(input);
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function telegramPlatform() {
	try {
		return String(window.Telegram?.WebApp?.platform || "").toLowerCase();
	} catch {
		return "";
	}
}
function isTelegramDesktop() {
	const p = telegramPlatform();
	if (/(tdesktop|macos|weba|webk|unigram|web)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Windows|Macintosh|Linux/i.test(ua) && !/Android|iPhone|iPad|Mobile/i.test(ua);
}
function isTelegramMobile() {
	const p = telegramPlatform();
	if (/(android|ios|android_x)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
function tgSafe(run) {
	try {
		run();
	} catch {}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tgSafe(() => tg.ready?.());
	tgSafe(() => tg.expand?.());
	tgSafe(() => tg.setHeaderColor?.("#080808"));
	tgSafe(() => tg.setBackgroundColor?.("#080808"));
	tgSafe(() => tg.setBottomBarColor?.("#080808"));
	tgSafe(() => tg.MainButton?.hide?.());
	tgSafe(() => tg.SecondaryButton?.hide?.());
	if (Boolean(tg.isVersionAtLeast?.("8.0")) && isTelegramMobile()) {
		tgSafe(() => tg.requestFullscreen?.());
		tgSafe(() => tg.disableVerticalSwipes?.());
	}
}
function telegramSafeTop() {
	const tg = window.Telegram?.WebApp;
	const safe = Number(tg?.safeAreaInset?.top || 0);
	const content = Number(tg?.contentSafeAreaInset?.top || 0);
	if (!Boolean(tg?.initData || /Telegram/i.test(window.navigator?.userAgent || ""))) return 0;
	if (isTelegramDesktop()) return Math.min(Math.max(safe + content, 0), 28);
	return Math.max(safe + content, 56);
}
function lockTelegramViewport() {
	const apply = () => {
		const root = document.documentElement;
		root.style.setProperty("--app-h", "100dvh");
		root.style.setProperty("--app-top", "0px");
		root.style.setProperty("--tg-safe-top", `${telegramSafeTop()}px`);
	};
	apply();
	const tg = window.Telegram?.WebApp;
	tgSafe(() => tg?.onEvent?.("safeAreaChanged", apply));
	tgSafe(() => tg?.onEvent?.("contentSafeAreaChanged", apply));
	return () => {
		tgSafe(() => tg?.offEvent?.("safeAreaChanged", apply));
		tgSafe(() => tg?.offEvent?.("contentSafeAreaChanged", apply));
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
function openExternal(url) {
	if (!url) return;
	try {
		const tg = window.Telegram?.WebApp;
		if ((/^tg:\/\//i.test(url) || /(?:t\.me|telegram\.me)\//i.test(url)) && tg?.openTelegramLink) {
			tg.openTelegramLink(url);
			return;
		}
		if (tg?.openLink) {
			tg.openLink(url);
			return;
		}
	} catch {}
	try {
		window.open(url, "_blank", "noopener,noreferrer");
	} catch {}
}
function haptic(style) {
	try {
		const hf = window.Telegram?.WebApp?.HapticFeedback;
		if (hf?.impactOccurred && window.Telegram?.WebApp?.isVersionAtLeast?.("6.1")) {
			hf.impactOccurred(style);
			return;
		}
	} catch {}
	try {
		const ms = {
			light: 10,
			soft: 14,
			medium: 20,
			rigid: 24,
			heavy: 32
		}[style];
		navigator.vibrate?.(ms);
	} catch {}
}
var WELCOME_JPEG_BASE64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCALQBQADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8uqKKKACiiigAooooAKKKKACiiigAooooAKKKKACnAYpAO9LUtgFFFFIAooooAKKKKACiiigpIKKKKBijrTqaOtOoAKKKKACjrRTgMUN2AAMUtFFSAUUUAZqgADNOooqW7gFKOTSUoHegEOooopDfYKKKB1pN3GtBQM0tLRSFuFA60U4DFJuwwoopwGKkAHSloooGFFFKB3oKFC0tFFABQOtAGadjFABRRTgAKlu4CjpRRRQAUUUUD2ClwaME06k2G4gGKWiipHsFFFABNArhg0u00tFA7ABiiiigYUUuD6UYNACUuD6UbTTqTYDcGjBp1FK4DcGjBp1FFwG4NJT6QrTuA2il2mjB9KYCUEZoooATaaTBp1FArDaKMGigVwpCM0tFA9xuDSU+mkGqTFtsJRRRTDcKKKKBDKKeQDTTxQnYBh60U6mkYqgCkIBpaKAGEYopWHekoAKDRRQSxlFPIzTTxQIYetFOIzTapMAppFOopiegyilPWkoHuFFFFUJDSMGkpzDvTaYmFIR3paKAG0UpGKSqAKTrS0VLAYRiinEZptUmAUUUUAFNbrTqa3WgBKKKKACiiigTCiiigkKKKKACiiigAppGKdQRmmmA2iiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKAM0U4dKTAKKKKkAooooAKKKKACiiigpIKKKKBhRRSgUAKB3paKKACiiigAp9NAzTqT1AKKKKYBTqQDNLSYBRRRSAUDNO6UijvS0D6BRRRUtgkFOApB1p1IGFFFKBmgYgFOopQOalu4AB3p1FFIAoooHWgtCjrTqKKACgDNFOoAAMUUtKBSbAAMUtFFIAoopQM0h+glOA4oAApaTY0gooopA2FGDSgeopaBbgBiiilwaChKKcAPSlpXAQD1paKKQBRRRSAKKKKACiiigAooooAKKKKACiiigApCKWimAyin0YHpTuAygjNLg0lMBuDRTqQj0FBNrCUUUUDTEIptPpCAaaYNDaKUjFJTF6hSEZpaKYrDelIRmnEZpCMU0wGEYop1NPWmAU1qdRQAyilI5pKACkI70tFBIykI704jmkpiG0UpHcUlUAhGabT6aetAl2Eoooppg0FNIxTqQjNUG6G0UUUCCmnrTqQjvTQCUUUUwCmHrT6aR3pLQBKKKKYBSEZpaKAGUU4jvTaACiiigAooooE0FFFFBIUUUUAFFFFACEd6SnHpTapAFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnDpTacOlJgFFFFSAUUUUAFFFFA0FFFFBQUUUUAKBmnUAYooAKKKKAClAzSU5elDAWiiikgCgc0UoHemwF6UUUVIBSgdzSU+gaCiiikw3ClAzSU4DFSNhS0UUAgpw4FAGKKlsAp9IBilpAFFFFBSADNOAxQOlLQMKByaOtOAxQAYxRRT8YqW7gIBiloooCwUUUoHrSH6ABSgYpaKm49goopQBQF7iU7GKKKASsFLigD1p1JsYgHrS0UUgCiiikAUUUUAFFFGD6UAFFLg0uB6UANop2B6UYHpQA2inYHpRgelADaKdgelIQaAEoowfSigAooooAKKKKACkIpaKYDcGkp9IR6U7gNppFOopiauNopSBSUBsJ1pCvpTqKA3GUUpX0pKoXqFIRmlophYbSU+mnrQmIYRiinEZppGKoBCM0hGKdSGgBtFFFAmFNPWnUhGaCRtNIxT+lJ1ppgNooPFFUDGkYpKcRkU2gEFFFFUmLZiEdxTafTT1pgxKKKKBDSMUUrDvSVSAKKKKTAaRikpx6U2mgCiiigAppGKdRQAyilIxSUAFFFFABRRRQSwooooEFFFFAAelNpx6U2qQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApw6UgHelpMAoooqQCiiigAooooGgooooKClXrSU4DFAC0UUUAFFFHWgBQM06k6UtLcAoooAzTAAM06iipbuAUUU4CgAAxS0UUh+QUUUoHepHsKBiloooEu4UoFIBTqTYwpw6UAetLUgFFFFBSQU4DFAGKWgYUUU4DFAABilHNHWlAxSbAAMUtFFIaQUUU4ClcPQQD1p1FFSPYKAM0oFLQG4YAoopwHtQMTBNOooqWwCiiikAUUUuDQAlGKcABS0ANA9aXApaKACiiigAooooAKKKKACiiigAooooAKKKKAEoI9KWigBmDRT6TAoAbRS4NJQAUUUUAFNIp1FO4DKCAacQKbTuAhGKSnUhX0pi22EpCM0tFAbjKKcRmmkYqkxBQRmiimDQ0jFIRmnkZppGKExDCMUU4jNNIxVAIRmmnin0hGaAG0UdKKBNAelMp9IRQSNIzTadSEd6pMBKQjNLRTExlFKw70lA9wpCM0tFUIZRTiM02mJqwUhFLRQA2igjFFUAU0jFOopbAMooIxRTAKKKKAEam04jNNoAKKKKACiiiglhRRRQIKKKKAA02nUhHemgEoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoopQO9DAWiiioAKKKKACiiigAooooKCiilAzQMAO9OoooAKKKKACnAYpB1p1JgFFFFNIApwGKaBmnUmAUUUUgFAzTqBxRQPYKKKKlsaADNO6UAYpaQtwoAzR1pwGKTGFKB3oAzTqkAooooKSCnAUgHenUDCiinAYoAAMClHNAGaUDFJsAAxS0UUhoKAM0AZp9JsNxAMUtFFSPYKUDFKBiigLBSgZpQKWk2MKKKKkAoopdvrQAlKFpQAKWgBAMUtFFABRRg0u2gBKMH0pwGKKAE2mjb70tFACbRS0UUAFFFdj8Gfhze/F74teEvhnYht/iHVYLSRlPMcJbMsn/AACMO/8AwGhu2rCxyd1a3VjO1re2s1vMoVmjlQo4BAIJB5GQQfoair7A/wCCoXwotvh7+0Ja+KdHsRbaP4x0e3nhVeFSe1VbaSMDthI4G/7a18f1MJc0UwsFJgUtFUAm33o2mlooAbg+lFOoIzQA2il20mDQAUhGaWigBu30pKfSEZoAbRSlfSkoAKKKKAEIptPpCAapMBpGab0p9IRmmKw2kIzSkYooAYQRRT6aRiqTFsJQRmiimA0jFIaeRmmkYoTEMopxGaaRiqAQjNNp9NI70AJRRRQJoQjvTafTSMUEjSKSndaaRiqTAKaRinUhGaYthtFHSimhvUKaR3p1FULcZRSkYpKBBTadSEd6aASiiim1cBCM02n01utJAJRRRTAKQjvS0UAMopSMUlABRRRQIKKKKCQooooAKKKKAGkYopxGabVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAAGadSAUtSwCiiikAUUUUAFFFFA0FFFFBQU4DFIBTqACiiigAoopQO9ACgYpaKKSAKOtFKOlNgL0oooqQCnAd6QCnUDXcKKKKlsEFOAxSAZp1IH2CiilA70DFAxSgZpKcBioAXpRRRQNIKUDvQBmnUFBRRTgMUAAGKXrQBmndKTYABgUUUUh2ClAzQBmnUmx7hRRShfWpD0EAzTqKUCgAAzTgAKKKlsYUUUAE0gClAJpQvrS0AJgUtFFABRShfWlxigBoBpwAoooAKKKKB2CiiigdgooqW2tpbu5hs4NnmzyLEnmSLGu5iAMsxCqMnkkgDqTQGiIqK9wg/Yg/awuoo7i1+CusSwzIJI5EmgZZEIyGUh8EEcgjg1MP2Fv2uj0+BevH6PD/8AF1CqQezX3hseE194/wDBI74VjxH8XPEnxWvrbdbeE9NFjZsy8fbLslSyn1WFJgf+ugrwX/hhP9rwggfAjxBn6xf/ABVfqn/wT4+BOrfAr9nvTNE8V6O+m+JtZu7jVtYt5APMildvLijb3WGOPI7Fmpy960e4m1a5wX/BU34R/wDCc/s6nxpYWpk1LwJfx6kCqgsbOUiG4X6AmGQ+0Rr8cgcgEd6/pH8eeE9J8beEdZ8Ha5AJtO12wuNNu0IzuhmjaN/0Yn6ivw41H9gb9raw1C7s7b4Ma1ew29xJFHcxNEEnVWIDqC+dpxkexFJRVOTh8wUrpM+f6K91b9hf9rlfvfAzXh/wOH/4umD9hz9rY8j4Ha5x/tw//F0OrTW8l949zw2iuq+Ivws+IHwk1eLw/wDEfw8+ianNF5ws5biJ5lTjDOiMSmc8bgM84ziuVqk1JXQWCiiimFgooooFYMCkK0tFAhtFOpCvpQAlJgGlooAaQaSn0hAoAbRQQRRQAYzTSMU6incBlIRinkelNqhDaKUj0pKAGkd6Sn00j0pphsJRRRVCsNIxSEZp9NIxQmIZ0opxGabVAIR3ptPppHcUAJRRRQS0NIxSdacRmm0CGkYopxFNqkAhGabT6aR3piWglFFFNAxCKbT6QjvVA+42iiigQ0jFFOPSm1SAKQjNLRSYDKKUjvSUwCiiigAIzTKfSMO9ADaKKKACiiigTQUUUUEhRRRQAU0jBp1BGaaAbRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUAZopV6UmAtFFFSAUUUUAFFFFABRRRQWFFFOUd6AFHFFFFABRRRQAAZp1AGKWk9QCiijrTAAM06jpRUsApQM0lPAxQCQUUUUmPcKAM0U4DFSNi0UUAZoBCgUtFOUd6lgAGKWiikNBSgZpAM07pQULRRSgd6AAD1p3Wkp4GKTYABiiiikMKUCgDuadUtj3CiinAYpBuIB60tL1pwGKTdgEA9aWiikMKKOtOAxSAQClpaKACigAmhiFHJxnjNACDnOD0p4x2r6t/bH/Zxl+Dnwi+BfipdP+z3F94aGma7hcbNQZ2vAG9WxdyJn0g9q+UqUZKSugsFFFFMdgopcE0u31ouMbS4NOopXAQL60uB6UUUrjCjGaKKAsfQX7Mn7ZnxA/Z7u4dDv1k8S+CXkzNo9xL89qGPzSWkhz5bdyn3GOcgE7x+sXwY+MHw3+N3hePxd8Odcg1G0+VbiBlCXNlIf+Wc8XWNuuOqsBlWYc1+DeBXWfC34rfED4L+LrXxx8N9fm0vUrc7XC/NDcxZ+aGaM/LJG3dSPQjBAI8jG5RRxUvaw92ffo/X/M66GLqUVyvVH9BVjFFkfu0/75FdJp4VUAAwK+Xf2OP2s9K/ah8KX943hq50TxB4faCHV7dVL2bPKH2PbynkhvLfMbfMmOrDDH6fsXG0VrladGfs57ozxbVSPNHYs3pGwiuY1CKIscxqf+A10N5INhrzj4rfEXw58LPBGs/ELxW12NJ0O3+03X2S3M8xXcFAVB1JZlGSQBnJIAJp5xLm0XUWCVtWSaqLG0tJ769kt7e2to2mnmmZUjijUZZ3Y4CqBySTgV+dn7Uv/BRK2ge98Bfs7SxvIpaC78VNF8o7EWSMP/IzD1KL9168E/ai/bX+JX7R93LoVs0nhvwPHLut9FtpjvugD8sl3IMea3cLgIpxgZG4/OoAAwBXn4TIqSkq2JV326fPv+R1VcfOS5KWiJr28vNSvJtR1K8nu7u5kaWe4nkaSSV2OWZmYksSeSTyaioor6A8+wYHpSFfSlopgNwaSn0U7iGUU7aKTBp3ASiiigVgpCMc0tenfsx/Dtvir8fPBXgx4BNaT6nHdX6lcr9jgzNOG9jHG457kVFSapQc5bJX+4FFyaSPLs0tek/tH+AD8MPjt428FrbiK3s9Wmms0VcKLWb97AB7CKRB9a82INFOpGtCNSOzSf3hKLhJxfQKaV9KdRViGUU4jNNIxQAUhGaWimAykIzUhGaaRimmIZRTiM03pTDYaR3FJT6QimmA2jrRRVCGkYppGak600jFNMQyinEZptMBpFJT6aRigBKQjNLRQS0MpCO9PI702mIbRSkYpKoGrjSMUlOppGKAQUUUVSYthpGKSn9aZTEwpCO9LRQgG0UEYoqgCmkYp1IRmlsA2iiimAUUUUANIxSU4jim0AFFFFABRRRQQwooooAKKKKAEIpKcelNqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAAzTqRR3palgFFFFIAooooAKKKKCkFFFFAwpwGBSAc06gAooooAKUDNJTgMChgLRRRSSAKUDFIOtOoYBRRSgZpAAFOoooH5BRRSgZqB7Cgd6WiigS7hTulIBinAZqWxgBmnUdKKQwo60U4DFBQAYpaKUDvQAAetOpKcBik2AAYpaKKQwpQPWgDvTqlsYUAZoAzTsYpBuAGKUDNAGadSbGHSiiipAKUDNAHrTqAE6UtFKB60AIBmnAYpC6LwWApPMj/vj86YDq9R/Zc+GTfF/wDaD8DeAng820vNVjuL8Fcj7HBmafPoDHG4+pFeWCSM9HH51+hP/BIX4YHVPGnjL4vXcBMWlWsehWDnkGaciSYj3WONB9JjWdWXLB/d95UVdn2L+3j8Jo/iv+y54w0+K136jodt/wAJFp4VcsstqC7qo9WgMyf8CFfhkmSoz17/AFr+lu9sIbuyltbmBZYZoykiMMh0Iwyn2IJH41/PR+0L8MJfgp8bfGPwxnBEWianIlozE5e0fElu2T1zE8ZPuTShF03yhzJ6nnuDS4FJ5sf98fnSeZH/AHx+dXqA+ikBDcg5pwBpDsJRTtoooDQTBo2+9OooC4m0UYHpS0Ug1CkJwCfSlrU8J+GdS8a+K9G8H6Qub3W7+Cwt/lJw8sgRSQOwJBPtSclFXewJN6H6v/8ABNDwA/gf9ni11y7tzFeeL9Rm1d9ww3kL+5gH0Ijdx/11r7SsZ8KDmvJ9Bj8KfC3wNbWsl9Z6R4d8L6bFb/abmVYYLa1gjCKzu2AowoOfU+tfDv7Tf/BT/UrkXfgj9m4vaRAmG48VXMP7yQYwfscTj92P+mjjf1wqcNXy+VYmrja060Vo39y6fgepi6UaFONN7n6eX1ztGDwfevPPid4asPH/AIL17wPqZH2XxBptzpkpP8ImjZA34Fgfwr8ff2ef23fjP8BdXkE2sXPizw3f3T3WpaPqt08heRzmSaGZtzxSk5JblWJJZWPI/UD4R/tFfDX9oLwx/wAJD8P9aEk8Uatf6XcYS909j2ljBPGcgSKSjY4OcgLPpYihD2i2XX/PsGXxp1HyPRn4i6ppl9oeq32iapCYb3T7iS1uIz/BIjFWX8CCPwqvX0D+3Z8Pv+ED/aL1y8trcR2PilE1+32rhd02ROM9CfPSY/Qivn6vosLiY4uhCvHaSTPPq0nRm4PoJgelGBS0V0Geo3b70YNOophcZRT6TaKA0G0UpBpCcdaAsGBTSvpSebH/AHx+dHmxf89F/OnqIDX3t/wSl+Gn27xF40+Ld3b5j0+1j0Cwc9PNmIlnP1WOOMfSY18ENIhU7WBJ6YPev22/Yf8AhO/wu/Zv8JaPc2xh1DVLb+3NQDLhvOusSKre6xeSn1Q15mb1GsM6cd5afLqdOEinVUnstT4y/wCCpnw2bTfF3hX4qWttti1O2fRL6QdPOhJeEn3aN2GfSGvhev2l/bj+Fo+JX7PfivSYLcy3+mW/9tWAVct51rl2VfdovOT/AIHX4riRejOAR1rn4fquWF9hLeDt8t1/l8jXMaaVXnW0tf8AMeRmmkEUeZH/AHx+dHmRn+MfnXunnhRSkelJSAaRikp9IR6UANooooAaRik60+mkelUmAwjFFOppGKYthCM02n0hGaaYeY2gjNFFUIaRimkVIRmm00xDKTrTiO9JTAYRiinEZptABTSKdRQSMpp4p5GKQjNNMQ2kIzS0VQmMopSO9JQPcKQjvS0VQvIZRSkYpKYgIzTadSN1poBKKKKGgGsO9JTqb0oQBRRRTADyKZT6aw70AJRRRQAUUUUCYUUUUEhRRRQAU0jFOoI4poBtFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUqjvQAtFFFQAUUUUAFFFFABRRRQWFFFKBQA4DFFFFABRRRQAqjvTqKKW4BRRSgd6YCgYoooqQCnAYpAO9OoGu4UUUVLBABmndKAMUtINwpQO9IBmnUmxhTgMUAd6WpAKKKUDvQUkKBS0UAZoGAGadRTgKTYABiloopDClA7mgDuadUtjCgDNAGadSDcOlKB3pQO5paTYwoopQM1ICdacBijGKWgAoxmgDNOoAAMUUUUAkfRP7M/x8+D3guWDwf8dPgr4P8QaG77YtdOhRTahZZPJlAA+0R8/9dBzgvwlfpF4V+Bv7MHi7R7PxF4e+D3w31PStRiE1reWujwyRTIe6sPQ8EdQcggEYr8VNueMV7F+zn+1H8R/2btdNx4cuP7U8PXcgfUdAu5WFtP23xnnyZccCRRngBgwG2vDzPLK9d+2wtWUZdruz/wAn+H5nfhcRTpe5Vgmu9tUfrrZ/swfs2SACT4B+AD/3A4q9V+HPw88B/DjTZNH+H/g7R/DlhPObmW20y1W3ieYqqmQqvViqqM+iivLfgJ+0F8Nfj/4YTxJ4B1kSSxKov9MuCqXunyH+CWMHpkEK65RsHByCB7lpLqQK58rr1nP2WIbuu5piqdPl56S0fY2zjZ07V5N8QfgL8FPHutyeJvGnwm8J67q8saRPe6jpcc87Igwqlm5wBwPavV3cBD9KxNRkU5Br3sxqclO8XqedhY80tUeDXX7MP7O0ZIT4DeAR/wBwGGvE/wBom4/Y2/Zz8P8A2zxR8E/AF9rd3GW03Q7XRIBdXXYO3B8qIEHMjDsQoY8U79r79v7wt8Hnu/APwtNl4j8ajdFcXG4SWWkt0PmEcSzA/wDLMHapHznI2H8sfFPirxL458Q3vi3xjrd3rGsalKZrm8upC8kjH69ABgBRgAAAAAAD5zC4DF4mfta1WSh2u7v/ACX9I9OrXo048kIJv0L3xB8Zr4+8V3fiaHwpoPhqCfCQaXolklra20YztUKvLNzy7EsT3xgDnqSlxX0qtFWR5tgopdpowKLhoJRg06ikMTbRtpaKA1DAr2P9lPxh8PPhl8TJfiv8Rbl2tvCthLcaZYW43XN9qEg8qJI1PGFDyOXYhVKL1JUHxyjA9Kyr0o4inKlLaSs7dioScJKS3R7B+0D+1R8Tv2hdREevXh0nw3bvustAspW+zx46PKeDNJ/tsOOdoQEivHwoAwABRRTo0aeHgqdJWiugTlKpJym7sK2PBvjXxf8ADvxFa+LfA3iC80XV7M5iurV9rAHqrDkOp6FWBUjggjiseiraUk4yV0yVpqj6A/aC/aG0j9o/4d+G9U8Q6bHpPjzwrcSW9ysKkW2o2cygtLF12Mska5jbp5pKkjcq/P8AgUYHpRWOGw1PCU/ZUVaOtl2vrZeVzSrUlWlzzeom0Ubfelorcz1G4NFOooDUbRTsCk207i0EqWyu5dPvrfUIIreSS1lWZUuIEmiYqQQHjcFXXjlWBB7iosGincLH33+zT8aP2U/iu9r4N+JPwK+G3hnxbIVihlOiwpYak54AjZv9TKT/AMs2O0kja2SEH1rbfs5/s9MdsvwK8Bgjgg6FECD6e1ficVB6ivsH9ln9vjW/hybTwP8AGa4vNb8NLshtNWAMt7piDgK46zwj0++oztLDCV8rm2VY2LdfAVZeceZ/+S6/h93Y9TB4rD29niIL1svx/wAz9CbT9mT9nGZcN8BvARz/ANQOKvbdMghgtlghjVI41CIqjAVQMAD8K4nwd4m0LxVotn4g8NavZ6ppl9GJra7tJRJFKh7hh+RHBByCAQRXbWUwCVy5ZiZ1n+/k213NsVShBfu0rPsYnie2imhkiljDI4Ksp7gjBFfP+pfs9fAO2G23+CPgNQvA/wCJDAf6V9A+IJVZWFeb+JtU0nRNPutY1vUbWwsLONpri5uZViihjUZLMzYAA96+YzrFV6FeUcNNxb7Nq/bY9bA0adSmnVinbujylvgV8EzJsX4L+BOuAB4ft+f/AB2vlT9pP4xfs7/Dp7nwX8MPg78Ota8Toxhubz+wbeSz04jhhwMTTA8bfuKfvbiClYP7T37buo+NZLvwL8Gru403w+d0N5rAUx3V+OhWLvDEec/xt32jKn5E2BRgCvo+H8hx7tiszrT8ocz/APJtfw+/sebmWOwutLC04+crL8P8/uFeRpZHlcKGdixCIEUE+iqAAPYAAUhGaKK+7Pn7DSMUU6kI9KBDSM00jFPpKAG0UpGKSgBCO9Np9IRmqTAjIxRTqaRimLYQjNNp9IRTTDzG0hGaWiqExlIR3p5GabTTENpCM0pGKKYDKKUjvSUAwIzTKfSEZoIGEd6SnUhGKpMBKYRin0hGaYthtFFFNAwIzTKfSMO9UG42gjNFFAhtFKw70lUAUhHelopPQBlFB4NFMAo60UUAMopzDvTaACiiigAooooIYUUUUAFFFFADT1opSO9JVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAU7pSLS1LAKKKKQBRRRQAUUUUDQUUUUFBTxwKaBTqACiiigApVHekHNPpMAooopoAp1Io70tJgFFFOUd6QIXpRRRSY9wpQO9JTqkbFoopQO9ACgYFKBmjrTulQAUUUUFJCgZp1IBiloGFOAxQBilAzQ2AAdzTqKKkApQO9AGadUtlBQBmgDNOpBuFOA7mgDvS1LYwoopQM0gADNOoooAKUD1oAxS0AFFFLjNA0hKcB60AYpaTYwoooIwM9+wpDsfef/BKXwF5vibxn8VLmD5bK2h0KykJ4MkzebPgeywxD/tpX6kaTPwpzXyJ+wx4DHw7/AGffDNtPCIrzW42127JXaxa5w0e4eogWEV0H7R37bXw6/Zr05tJcDxD4zmj3W2h28uPKyMrJdSDPkpyCF++w6AD5h8XQx8sbmlT2eqTsvloe1UwyoYSLl11+8+s5boCPrWHqN2Ap+UMByVI4Ydx+PSvys+C//BU74qaH43vZ/jba2/iHwvrV15rR6fbrBPo4OABbDOHiAHMchJPXeDkt+j3hX4k+DfiZ4WtPGfgPxDaazot+pMNzbtxuH3kdTho5F6MjAMp6ivVzitUpUve27nHgqcJzsj8PPj74BPww+N3jbwIsQig0rWbhbVR0Fq7b4PzieM/jXCBTX2R/wU+8D/2P8YNA8f28O2DxRpP2eYhetzaNsYk+pie3/KvjivRwOI+t4aFbuvxWj/E569N0qkodhMCloorrMrBRRRQMKKKXB9KAEopdppdvvSuA2inbRRgelFwG0U/A9KMD0ouAyin4HpRgelFwGUU7A9KNoouA2inbfek2mi4CUUuD6UlMAooooAKMCiigVhNppjcA8c1JXWfCLwHN8Tvin4W8ARBiutanDBOQ2ClvndM4Pqsau3/Aamc40oucnold/IaTk1Fbs/V39h3wPL8PP2dPCOnXEZjutUhfW7kEENuum3oCD3EIhH4V9MWl1tiyTXC2k1jpFnkeTZ2VrFn5mCRwwovcnAVVUDk4AAr4b/al/wCCjdxGLz4f/s8X4DKWgvfFO3I9CtkD/wCjiOf4AOHr84yqpic0xM6lNbttvorn0uMhTwlGMZdF95+gmuXgJbBr5w/a78Njxv8AATxpoiRNJNDpzalbqoyxktWE+B7lY3H415B+zf8A8FB9O8cJZ+BfjhNbaRr7KIbbXhiKyvm6ATjpBKf74xGxzny+M/TeuNFcK8FxGskUi7ZEPIeNhgj6FT+Rrxc3+t5Vjo1a0bOLTXZ2d9GehgVRxmHcYPdWfkfiIvCinV0PxD8Iz+A/HniDwbcBw2jajPaKX6uiOQj/APAlAb8a56v2SFSNWKnB3T1R8TKDi3F7oQj0ptPpCM1aZI2ilIxSUxNCEUlOoIzQIbTSKd0ooAZRSkdxSUAIRmm0+kIzTTAjIxRTqaRiqFsIRTafTSO4ppgJSEdxS0VQmM600jFPIpCM00xDaaRinUlMBtFBGKKBNDSO9JT6aRigkZRSkZpKpANI70lPphGKYkFFFFUg2GkYpKcRmm0xMKaRinUhHFCASiiiqYCEcU2n00jBpIBKKKKYBTKfSMO9ADaKKKACiiigTCiiigkKKKKACmkYNOpGpoBKKKKoAooooAKKKKACiiigAooooAKKKKAHDpRRRUgFFFFIAooooAKKKKCgoopQMmgYoGBS0UUAFFFFACqO9OoopbgFA5opVHemwFoooqQFHJp1IBS0D2QUUUAZNSx7DgO9LRRSEu4AZp1AGKUDNS2MUCloopDQU4DFIBmnUFBSgd6QDNOoAUDNO6UgGKWpAKUDNJTgMUmyhaOtFOAxUhuAGKUDuaAM06k2MKKKUDNSAAd6dRR1oAKcBigDFFABRRSgetBSQAZp1FFS3cYUAZpQPWnUBsIBiur+E3gWb4mfE3wz4DiB26xqMUM7Btuy3B3TPnttjV2z/s1ytWLLUNQ05ppNNvZrV7iB7aVoXKF4nG10JH8LKSpHQgkHIJFZ1FKUHGDs7aPs+446NN7H37+0p+3zp/hGGb4dfs9z21xfRR/Z7jxAgD21koG0R2gPEjqAB5pygwNoY/MvwDf32oatfXGq6tfXF7e3cjTXFzcStJLNIxyzOzEliSSSScmoVQKOBS1w5dltDLKXs6C9W936nRicVUxU+afyXRBtHpXovwO/aB+JP7PniX+3fAmq5tLkqNR0m5y9nfxj+GRMjDD+F1IZecHBIPnVFds6cKsXCorp9DCLcXzJ6n3v+0X8WvAX7Xn7MF14p8Ih7PxR4Gu4NY1DQ53BubaFj5E7IePNg/eRvvUDAQbgp4PwQpyAfUVNZ3t7p0r3Gn3cttJJFJbu0TlS8UiFHQ46qysykdCCQeDUQBrkwOCjgIOlTd43bSfS/Tz1Nq9aVeSnJa2+8SinbfWlwBXZcxG4NLt9aWijUAxiiiiiwBRRRRYAopNw56nHXHOK6Hw78O/iD4uiWfwt4H13VoCcefaWEssQ9y6qVUe5IFDkoq7dg3Oforu5fgl47sZEi12bw1orPn5dS8S6dA4PoY2nEgPttpW+FFvDkXvxZ8AwEdQL+eb9YYXH5Vn7an0d/TX8hqLZwdFduPhro5O0fGPwIT/v6kP52YH60snwomaJpLD4jeBLzH8I1pbcn/wIEf60lXp9Xb1TQ+SRw9Fdqfgt8T5bf7VpfhpdajAznRL631Nv++bV5DXKarpGsaDeHT9d0i+066XrBdQNFIP+AsAauNSFTSLT+Ymmt0VaKQEHoelLV2EFFFFKwCbRSYNOoo1QDKKfjNJt9KLgNr6p/YKg8HeDNa8X/Hr4i6rBpeh+EdPWwt7mcZD3d0WysSjLSSiKKUBFBJ80fWvlcgip21HUH02LRnvJjYQzvcpbbz5azOqq0m3puKogJ64UDtXNjMN9coSoc1lLRvy6/etDSjU9jUVS17H0H+07+2b4x+O80/hbw0bnw94HV/lsQ4FxqGDw9069R3ESnYvfeQGr5z2jGMcUuB6UVWFwtHBUlRoRtFf194qtWdebnUd2NZBg19F/s6/theJvhULXwf46Nzrvg+MCGHndd6YvbySfvxj/AJ5McD+EryG+dqCAajG4HD5jRdDEx5ov8PNdmVQxFTCzVSm7M95/bKtNB1T4jaZ8T/COoW+o6H420uK7ivLdspJcwfuJVIPKuqxxFlbDAvggGvAyM1I0s5t1tDNIYEdpFiLnYrsFDMF6AkKoJ/2R6UyrwOH+p4eGH5r8qsn5Lb8NBYir7erKra19RpGKSn00j0rrMdxKaRinUUXAZRTiPSm1QmrgRmmkYp1HWgkbTSO9OIxRQAyilI7ikoAQjuKb1p9NI71SYDCMUU4jNNpi2GkYpKdTSMVSYBTSMU6gjNMkjI70lOppGKpAIRmm0+mkd6AEpCM0tFBLQymkYp5HekIzTQhtIRmloqhMZRSkYpKEPcKaRg06kIyKsW6G0UUUCGkYNFKRxSVSAKQilopPRgMooPFFMAoPNFFADKKUjmkoAKKKKACiiiggKKKKACg9KKKAG0UHrRVgFFFFABRRRQAUUUUAFFFFABQOtFKo70mAtFFFSAUUUUAFFFFA0FFFFBQU4Cm0+gAooooAKVfWkpwGBSYC0UUU0ADmnUijvS0mAUoGaSnAd6QIWiiikx7sKcBxSAZNOqQfYKUDvSU4cUmMKeBimgd6dUgFFFKB3oLQoGKWilA70AKBinAd6QDNOqWwCiilA70higYpaKUCpGAHenAZpKeBik2AUUUAZqRigZp1JS0AHWnAYoAxRQAUUU4DuaCrAB60tFHWpGkFOAoAxS0BcKKKUDFS2GwAetLRRSHa4UUUUDClAJpQvrS0rgIFpaKKLdwCiilwaYCUU7aKWlcBu00h2ryTXReFfAniHxfHcX1itvY6RZFRe6xqEvkWNrnoHlPBc/wxrukbnarYxX0D8B/2ZPEvxJkS4+FfgePXbYNsm8a+LrdrfRYDkhvslkQWumAP/LQSA4G6GM1jUrxp3v8A16v+n5FKLlseB+Hfhv4u8S6f/bdtYR6foobY2sapMtpYqc4IEshCyMD/AAJuf0UnivR/hv8AAePxxc/ZPBPhbxp8Ur1MCQeH7M6fpMTg/Mr31yhJHs0UXs3cfeC/szfsz/Au1g+In7VHxEh8Z635eIZ/E8xS0AAz5VnpqFi6DHCYdQOir0rhviV/wVU8FeG7Q+GfgL8MTfW9ophtrvVFFlYxgDgxWcPzFfYvGf8AZrlWInW0pq/povv3/IvkUdxvw1/YJ+MrCGa9vfh38LYd24RaTpf9vasEPUG6uWfy2z3ilA44A6V6Prf7GX7Mvha3+3/tDfGzxH4iKfvGPi7xjHYwrjn5IlKuo9g5r4F+I/7bP7TXxLM8er/FHUNJsZTn7DoZGnQqP7uYdrsPZ2avHobPUdZvZNR1SW+kiVVur67ZS8ggMqxmX5iC/wAzgdeT34NVHDVG+abS9N/v3E5xWiP09vPFH/BKv4dJ9nGn+BtTePgCHSL3WSSP9t1dD9S2Kqt+2x/wT98PDydD+GcEiJwPsfgSwjH/AJEZTX5jNpcf9oXmnxXtvL9l8/bNHzHMIgxYqfQqjEHvx61Ys5vDy6fH9ttJGufLu0k2yP8Ae8sG3cAcf6zcGHTbg4q3hlu5Ni535H6XH/goP+xPN+6k+FmphDwd3g/SiPy86o3/AGqf+CcPixdmv+ANEt93U33gGAke+bcOfyr845LzwjK/nDTDEiajazGISOWaBoybmMc5IV1AU9cMaoz3nh37GVSxdrmTT1jyruFS6FwMvyehhU8YwGfgDGRDwcJ7OS+Y1Uce33H6Uy+Df+CY/wAUwjabqvg7S55G/d+Tqt3osm7thJyiZ9ipq1qn7ENndaY83wm/aC8VQabKP3VrqjW/iDStvZQnypj3Ksfr0r8xbk6DJfStbpc21sZZnjBIZhHjMaDvu4wST3z0FavhrxF4q8Gzpq/gnxxqGjXfkfaJpLC9ktZEIlKBNyNuckBGx0w/PQ1y1suruK9lWa8pJSRtCvTT9+H3Ox9V/EL9i34s6Kstzf8Awm8O+M7VQAL/AME3p02+VR1Y2ci+UT/sxQE/7Xp846t8M7T+0ZNK0TW5bDVIjtk0PxPb/wBk3yNnAUNIfJbr/FIjnsmeK9j+HX/BQP8AaO8MZh8SLaeNtOs1El0uo2my4iiBC5NxFtZeSBuk38mvovRf2vP2Tf2i9Mi8MfGbw3baRdSLsWPxJAJoImI5MN9GA8I6jcfK+tc31jMMD/Gp80V1g7/+SvX7rGvs8PX/AIcrPtL/ADX6n5xa3oms+GtQfSvEOkXmm3iAMYbqFo22nowDYypxweh7VT21+i3xD/Ykv4tCFz8EPFtnr3h2ZDcQeFPFEwurFkYHmxvkIaEkE4ZWQnvKRxXxx4y+D13pniCXw1baRqXhfxKhBbwvr7LHJLlsA2d0Qsc6k/dB2seAnnHmu/B5nQxivCXr5eq3X5eZz1sNUov3l/Xk+p5fg0VYvrK+0u+n0zVbG4sry2dop7e4iaOSJwcFWVgCCD1BqHAr0kzAbRS4NJTAKQgUtFKwDSCKSn0hWi/cBtFKRikpgFIR6UtFArdhtFOIzTSMU0xbiEZptPpCM1Qeo2kIzSkYooAZRTiM02qEHWmkYp1BGaCRtNIp3SigBlFKRikoAaRikIzT6aRiqTEMpCM04jvSUw8hlFKR3pKoQhHemkZp9NIxTQhnSilI70lUAwjFFOIzTaADrTKfSMO9BAxh3pKdTTxVIBCM02n00imJaCUUUVSDZjSMGkpxGabTEwppGDTqRhQgEoooqmAjU2nHmm0kAUUUUwEIyKbT6aetACUUUUAFFFFBLCiiigQUUUUAI3WkpxHFNqkAUUUUwCiiigAooooAKKKKACnU0dadUsAooopAFFFFABRRRQUgooooGKo706kHSloAKKKKAFHWnUi0tLdgFFFAHNMB1FFFSAo5p1IvrS0D2QUUUAZNSxrQcBgUtFFISFUd6WgcU5R3qWMXpRRRSGgAzT6QDiloKADNOpAKcBSYCgYpaKKQ0AGadQBilqWxgBmnUAYpQO9IEKBilooqRhTgMUAUtIApQKAO9LQAUUVLa2d1qF3Bp9jbvPc3cqwQxRjLSOxwFA9STgUFbHS6z8OPEGgfDvwv8TL9ANK8XXeo2lhgHObMwrIxPTBabA/3GrmK/Uz9s39m+38JfsDeGPDumWqyX3wuNjdzyRJzI02Yr5/o004kPsg9K/LNfmAI71jSqe0jcfK09Q604DFAGKWtACgDNAGadUt3HsAGKKKKQWCiinAYpXGIBmnUUUbgFFFKF9aewCUoX1pcYpalsBMYpaKtaPo+r+IdWtdC0LTp7/UL6QRW9tAhZ5HPYAf5FJu2rAplgMdcngCvWfBPwY1CXxBZaBrfhrUvEXi6/wBraf4J01it0QQG8zUJB/x6RAEEpkSlTlvJUrIfRf2ePgH4n8Z+I5NA+FVxZ3Gt2TqNd8cyp52m+HAesNgRxcXZ7TKeCP3W0D7SfrPxT8QP2df+CfHhCXw74d05te8eavAJ5oXlD6lqTnkT31xg+RCWJKxgc8lVPzSV5uIxtpqjSV5Pot/V9l+L8tzeFG65paIp+Cv2RvBHgTQ7X4oftc+KNBuLXQ032fh2Nha+GtD3nPliMf8AH1KT14PmH73nH5q8z+PH/BTi4dJPCX7OOiRadYwR/Zo9f1C1UOqAYH2W0I2RKONpkDHHGxDXyX8bP2gfif8AH3xB/b3xI8QNPBAx+xaZb5isbFT2iiyQD2LMS7fxMcCvPrazubyaKC0tmkeaURRqP43PRV7kkkAAdzinRy/m9/Eu77fZX+YSrWXLT0/Mu+J/Ffibxtrl14l8Y6/qOuardEvPd307TSuM5xliTgE8DoM4GKm0nwxPqEirc3KWii9WxnLjH2eSRT5bSZ6IXVgxH3QvPJGd7RNO0WwYaoYUv4GhN79laTb9qtMFLu3LcbZohmRWx91TJj7grmtXv5Lq7kWC886JIktBOE2NcQoR5e9exCrGMdtgzyCa71K/uw0t/X9f8OY27mnbjQ9DnWaWIpf2sUbvBOx+S6gk2yQycZKSIGbgfeIXOAap/wDCS38MMVtYRJDHBbXVgrOMs1tMzNscDAJDSOwPqR6VkyuxdpZXaSRyWYscliTkknqT1r6N+BH7Cfxn+NcFt4g1K0Hg3wtOBIup6rC3nXMZz81vbjDyDphjsQg8PUVZ0qMees7LzHFSk+WJ83ssanY3cdPUV658Lv2Tvj78YFivfCPw/vIdJmIxq2qYs7QgjO5ZJdvmj/rnvPtX6KeB/wBmT9lz9lzTo/GHiGLTZ7q3I/4qDxbcRMRIP+eETYiRgTxsVpOnzGm6p+2rp3jO+l0T9nj4VeLPihqMB2NeRQNYaZER2e4lXIHpuVAR0NePUzmda6wcL26vRfp+LR2RwahZ1pW8lqzw/wAEf8ErJRDHd/E/4rrGxGZLPQLIvg+1xOVH/kI16zb/APBPr9lrwxo80mt6HrN5HHA/m6nqWtyReUNpzKTCIoxtHzfMCOOQas69b/tf6xpr638TvjT8PfgjoTENssEjuLpY8cq9xcOEDdeY5fw9fIPEfgn9mHXdP1a6134rfF/456vBbzOP7OW91G2imVCQwaKLylVWAY5mIAB7V50sRjcQ7uvZdoK9vmrL8WbqFGmtIX9Xb8DwT9mf4Yad458MeOFsfA2k+MdYOt6Do2jRam1zDCkdzJdtcyM8EkbwqIrcMZMnaFPBzg5uu/Cf4b6v4cPiWLRPFvw9ubvR7jxBp6TAa5pV5ZxSGIN5sCrc2ayTAIjTRyKSy5cBlY5vwx8Gw2nw/vPiHZ+Jdc0HUrCz169Fxpl6beR0txpkVrGSBkKZ79w2CCQMDB5rH1H9o/4sa/4R1Twl4g1a11KDV9PtNIlvZ7OP7ZFY29wJ47ZJlAby/MGSG3Zzj0x70oYidaU6MtLrq1bo7bp7X2/PTz4uHLaS1/r5ifBjxmfAyanqOn/GnxH4Fvr0rbyJpOlm5F1AMMC7CePjd/DgjjOal8RWXwr8UapNrmtfGbWru9uCDNMPB0cRkb+8226ALe55rpfBHjiDwx4U03SNK/aV8QaFCkIkfTbfQJXjtpZPnkQMJAGw7N82BnrgVsH4p3JJP/DWXiYn/sXpv/jtKcpKrKcE03pe3/3N/mxxS5Un/X4nD/Df9oX4j/ADxDND8LfG9zqXh8ShjY6hbk2d2CMktblj5bZJyyMH4Hz4r7g8BftE/s3fthaDD8Ofit4astL16X5YNN1OTA80jG+wvPlaOQ5+4SrHpiUZr5V/4WhdMOf2s/Ewx2/sGf8A+OV57rPhP4V6lPeaq/xrmuL64LzEP4ZliWSUjPJVjtBPUgHqTg1y4nBUMZL2kk4VFtKKlf5+6r/1sbUq86S5U7x7O1vzPpP9oP8AZO8W+A9NlvLy31L4geCdPhKQarbxKfEvh+Fegl6C7tkHY4CrkKbYZJ+RvEvg6/8ADsUWqW91Dq2hXjlLPV7QEwSnGTGwIDRSgfejcBh1wVKs30t+zT+334u+HhtPB/xhlv8AxD4cjKxW2qAlr/TF4A+Y4M8Q/usd4GdrYAQ+5fFH9mvw98QtGvPjB+zRJoV4/iCDztT8O5DaL4lRWJwq5UW9yGzjBjKycgwyZY408dXy6qqGOtZ7SWkX6/yv8PzNHh4YiDqYfpuuq/zR+bVIa7fxn8Pxp9vea/4bs9Qhs7Cf7PrGkXykahoFxu2+VcLtUtEX+VZgoBOFdY3Kq3Edele/GSmro4GrDQueeRRjFOGMDFFXcQzp3paVl9KSnuAU0j0p1FGwDKKcRmkIxRe4CUEZoopiaGkYop1NIxTTDcQjNNIxT6TrTFsNrU8K+Ftb8b+JtM8IeG7Q3Oq6xcx2lpFnG6RzgZPYc8n0rLIxX1r/AME2vhtL4p+MuofECeDNr4L08yQuegvbjdFFj6IJ2+qCuXHYpYLDTrv7Kv8APp+JpRpOtUjTXVnyMM5wQQRwQaWvXv2tPhyPhh8f/Fmg21uYdPvLs6rp64wv2e5/ehV9kLNH/wBszXkNb4evHE0Y1obSSf3kVKbpycJboCM02nUhFbGY3rTSMU+kIzQA2kIzS0UAMppGKkYd6aRmrExtMIxT6QjNNMNxtBGaKKoTGU0jFSMO9NIzTQhtNIxTqQjIpgNooooExp4NNYd6eR3ptMkbSEZpTxRVAxlFKRzSUINwppGDTqRulWLdDaKKKBDaKVh3pKpAFNPWnUh6UtmA2iiimAUjDvS0HmgBlFFFABRRRQJhRRRQSFFFFABTT1p1I3WmgEoooqgCiiigAooooAKKKKAFXrS0i0tSwCiiikAUUUUAFFFFBQUUUqjvQMdRRRQAUUUo60ALS0UUkAUo6UlOoYBRRSgc0gHDiiiikx9Qpw6U2n1IMKVaSnAYFJjCn01adUgFKBmkpwHFBYtAGTRTgOKACngYpqjvTqkApQM0lOAxSZQtKBSU4cVIbi9adSAUtS2MKUCk606kAtAGaKd0FABRXsfwZ/Zd8W/HfT5LvwN8QPAqXlvuNxpWoajNBfQIDjeYzCdydPmQsoyASDxXqUP/AATJ/aEmx5XiXwA301ab/wCM1y1MfhaU/Z1KiUuzeptChVmuaMW16HyWBmvpH/gnz8LB8UP2oPDTXloJ9M8Kb/EV4GXKk25HkKe2TO0PB6gNXXR/8Etv2lZP9XrfgI/9xeT/AONV9qf8E+v2RfFH7NWl+K774hS6TceIvEF3BFHJp1yZ4ksolJUbiq4ZpJGyMdI0pTxNOpC1KSbemglCSfvKx9OeP/A+n/EPwBr/AIB1Zc2fiLS7nS5j3AmjZN31BIYH1Ar+d7VdJv8AQNXv9A1WAw32mXMtndRH/lnLGxVl/Agj8K/pSMAMJGOor8vf2nP+CaXxi+I3x28XfED4a6j4RttB8Q3g1COG/v5IJknkRWnyqxsMGUyMDnowrZQ9lZPaxHNzXPzmoAzX2M3/AASo/aZT72u+AB/3F5v/AIzUY/4JYftK7tg1/wAA5P8A1Fpv/jNZyr0o7zX3lqMnsj4/or0H4z/BbWPgb4l/4Q/xL4z8J6zrEe4XdpoV7JdGyYfwzMY1RX/2NxYdwMivPqtNSV0JBSgZoAzTqLjADFFFFFgCgDNKB606hsBAMUtFFSAUUVJa2l1fXcFjY2s1zdXMiwwQQoXklkY4VFUZLMSQAAMk9KALGiaJrHiXWLXQNAsJb3UL2QRQQR4yx65JPAAAJLEgAAkkAE19T/s5/s3X/wAVb298H+DNVa18M27fZfGnjm3TJvSQC2laWWHMZH35MfOMM37spHLR+AX7O+t/ELXLr4X+GL82UMaKPiF4qtyri1hY/wDIIsn5VnbaRI4OHZWGTDGxn97/AGpf2m/C37M3hC2/Z2/Z9tbbT9bsrQW0stsdy6HCwyTuPL3kmd5ZvmUtuPzEbfHxeLnVqLD4bWT+5L+Z/ovm+h10qSUfaVNF+fki5+0X+1P4A/ZP8JW/wD/Z40rT4/EOnwmBvLUS2+i5HzSSk58+8Y8nfnB+Z8kCM/m5rOtav4i1i617X9TutT1TUZjPc3dzKZJZpGPLMzHJ69TUM0s9xLLdXUrzTzMZJJJG3M7nksSeSSe9dD4P0QXtzNHf2Zuo5Lb7QbNT5c9xbjO6W2c8GWPDMF77ZFIOHU9uFwtPBQb3k931ZjUquq7bLojJtdIunhh1H7R5MMVytvcTAH/RZTkoXA+ZQdpIIBPytgEritvUpdK0nUPIuNPe0lnXyNTsVIxBcLyl1bMvylTneoBxguoIjdSbi+JtN0+WRlNpqEtvCbK6ZlMcWs6c2CFlXOY50wpDA5yisCJIg0nJandJc3Wy3nlntoF8u3acfvRFnKo2ODtyR/IlQuOhc03qrL+v6/pmexJq2t3mq6s2usypdyHfPLCdokm6PJtwMFiAzccsScAEKNv4ZfC/x38XvFFt4M+Hfh+41bUp/mbYMRW8Y6yzSH5Y0HdmIHQdSAe1/Zz/AGZvHn7SHiVtP8Pp/Z3h+wdRq2uTxlobUHnYgyPNlI+7GCPUlVyw/QfV/GfwR/Yk8Kaf8Lfhv4YuNc8X6oiGz0CxPm6pq1wQQlxeSKpKKzZ2jb0yIo8AkcGNzGOGao0Y81R9Oy7vsjejQdRc83aPf/Iwvg1+xb8F/wBm7Qx8SPjJreka3rWnqs02oamVTSdNkzkCGOT/AFjg4w7gkkApGp66d5+1J8WfjheXXh79lTwN5mlRu0V1488TRNDp0OOGaCJhmQjB+8GYY5iA5ryDxXbar4r8b2F5+03JffEPx/Li50D4Q+F3P2LSc4w19KhKRAbhv3MzYyWaRchfcdO+CHjD4jw2q/tA+J7e00SGJRZfDvwlI1ppNtAM7UuZY8SXWF25VSsQZTtJBxXzuIqwhL2+KnzN7X+H/t2O8vXSPmz0KUXJezpKy/H5vp+LPJ7DwF8IL/xbLd+ILnxb+1P8TIPluFtWA0LTnwfkkmZhbRR5GNpdxnH7tele/wCkfDn9oDxXZQWOveOdE+FXh+JSkPh/wHYxy3UcZXARr+dPLjYc/wCohA6c+voVtq3w4+F2nab4YtotN0OF1xpui6fa/vph6wWkCmR/dgpHqa6DTtW8Q6y2638OHSbfqrakwe6Yev2eIkR/8Dkz6qKx+syrx51t0vZ/cvhXyV13L9lCm+WW/l+r3/E8/wDDv7LPwZ0K+Gu3nhFPEWt5BbV/E9xJrN6zDowkui4Q/wC4q10/jYro/grXXQ7IbXSL51jT5UQLbSHhRwBx2rprDWtNupmtbbVEvpUO2QwsrhD77PlX6E1xf7QN1/Z3wZ8faojYNr4X1WT6H7JJXLWg68ovmbd1u79Toi1Tg9LaH5N/2vb6X+zlc2qsBJqdhFYpjqWm1aWd/wBNJj/KvI9At9Puta0+01XWE0m0kmQTXz27zrbrnlzGgLPj0A5rotd1hP8AhX2j+H0OS0okb0HlNM4/W8f9ab8ML7+x/Eb6zH440fwvcWtu6w3Op6TJqEchf5GVY1t5wG2sx3Moxjg5r72KdOE2u7f6dn+TPnrXaR7K3xNuASV/ays2zzn/AIQ245/O3qJviZdkFT+1ZYkHsfB9x/8AI9VP+Fkaocj/AIaL8AgHqT4Dl5/8pdMPxJ1UZA/aE8BN/wByJJz/AOUuvKVB/wAn4f8A3I6L+f4//bFsfEiYZ/4yosOfTwdcH/22pv8AwsafJA/alssH/qUZx/7b1XHxJ1bBH/DQ/gHp/wBCLL/8q6Z/wsXVRnH7QngHkf8AQjS8/wDlLp+xf8v4f/cgUrdf6/8AAih4q1LQPGelnSPEX7SWn3tt5iyhD4UuUw46EMsAIPJH0JqL4P8A7QPiP9mHxq8PgfxQni/wjemOXUrAwz28FwcYYosqBoplAwJFBBG0HcBsGh/wsXVskH9oDwJj/sSJef8AymVW1XxfNrGnXWl3vx88CSW93E0Mqr4LnjJVhg4ZdMBB9wcirUHKDo1Yc0HurO34U1r8wUuV88XaS6/1I+y/GPg3wB+1j4StfjZ8DddtdP8AGlvC1sLmeNALn93iTTNUhO5WBQ7QzBlKEffiI2/AfxC+Hl1ps+q6hp+gXOi3miz+R4j8OT7jPo0xYLvTcS0lq7Mux8kqWVHLbo5JtP4Y/FnXf2aPHlt4m+HfjKx8TWN3GqavYww3cNtdwhj+6kE8MZDD7ySKCUJz0LK33L4/8J+DP2r/AAFpnxw+Cd9bQ+MbCBoLc3KIPtS7MTaTqEZyhyrlQWyhVwMmJ8jz4zq5HUUajvQlpGT3j/dl5dn09Lo6XGOOi5QVqi3XfzX6n5ipwOuRTsiu18eeDLawjuPE3h/T7ixsYrw2OraPcFjcaDf5bNvJu+YxMUfy3bkhGRiXjZjxeMV9PGamro81qwnJ7UEZpaKYhpGKSn00j0qkwEoIzRRRYBpGKSn00jFCYCUUVd0XTodY1e00qfWLHSku5REb2+Mgt4M/xSGNHYL7hTjOTgZIYmUCMUV9RWP/AATt+N2q2lvqGl+M/h5e2l3Es9vcW+sSSRTRsMq6OItrKR0IOKuL/wAE0f2hG+74g8Bn/uLS/wDxquD+1sAnb20fvRv9VrtX5H9x8nvgKSe1frR/wTy+GL+Bf2drHWLy28u+8Y3UmtyEjnyCPLtx9CiGQf8AXU18qaX/AMEw/j7cahapqfiDwZHYtPGLl4NTkeVItw3sqmLBYDJA7mv1R0TQtP0bSLTRtKtFt7Gwt47W1hUYEcMahEUfRVA/CvFz7G0sXRjh8PJSu7u3Zf8AB/I7cvoypVHUqK1trn57/wDBT34ZrcaN4a+K1jbfvtMuG0XUGVesEu6SBmPorrMv1lFfnsR3r9vv2jPhfH8Vvhb4l8BEQrPqtiyWkk2dkV0hEkDtjkASImSOcZr85pP+Cc3x2gwJPE3gUf8AcSnP/tGsOHM4w2Fwjw2KqKLg2ld2unr+DujbM8HVq1lVoxbUl0XU+WaK+nn/AOCefxrT73ivwL/4Mrj/AOMVieK/2JviN4G8P3XinxX8Qvh7p2mWYzJNNqdwMt2RR5GXc9lUFj2FfQwzvLaslCFeLb2SZ5k8DiYrmlTaXoz57I70lOZQrsiyLIoJAZc4b3GQDj6gGmkYr1DkGkd6Sn0wjFABTSMU6kIzTQDGHekp1NPFULYaw70lO602qQBTelOpGHemSMIpKcRmm1QDSKSnEZFNoAKaeKdSN60EDG9aSnHmm1SAQ9KbT6YetMSCiiiqQbMbSUrDvSUxAelNp1NIwaaAKKKKGAw8UUrUlMAooooAaetJTmHem0AFFFFAgooooJCiiigApGpaRqaASiiiqAKKKKACiiigAoooHWgBwGKKKKgAooooAKKKKBoKKKKCgpw6U2n0AFFFFABTl6U2nCkwFooopoBVpaB0oqWAU4dKbT+lA0FFFFSwQqjvTqQdKWkAAZNOpAKcOtSxjhwKKKKQ0A5NPpqjvTqCgAyadSDpTgKTAcOKKKKQ0KBTqQDFLUMewqjvTgMmkpwGBSYIWiilAzUjFApaKAMmgBQKWiigEXtA1/XPCmt2fiXwzqtzpmq6fKJrW7tpCkkTjuCPbIPqCR0Nfpj+yX+3h4b+Jj2XgH4tS2egeLnKwWt/kRWOqt0Uc4EE5PG37jn7pUkJX5gqO9KVDAgivOzHLMPmUbVVqtn1X/A8jqw+KqYaV4PTsf0P2GVOGGCOMGun0tgSCK/Mf/gnZ+1j8U/E/i22+BPjGKXxNpsVjLcWWrSy4utMghTOyVj/AK6Inai5+ZSwAJXCr+l+lTDArxMDRnl+J9hUd7fkdteosTT9pFHU5Xyx64rIvWAJq6LgeX1rIv7lA3LYyccmvpMdXiqdzy8NTfMZer6jp+l2F1qur39tY2NlE09zdXMyxQwxqMs7uxAVQOpNfmb+1z/wUdvvEDX/AMN/2dr24sNM+a3vvFQBjuLodGWzH3oU6jzTiQ9tnVvHP2yf2u/ip8dPFeqeANUtZPC3hXQNRltf+Efhn3tJcQSFDJdSLgSyBlOAPkQ/dBILN80gAAADgVxUMFFNVKmrOidZv3Y7CszSO0srs7uSzOxyWJ6kmgDNAGadXe2YhRRRRsAU4DFAGKWk2AUUUUgCgDNKBS0AHCivcfgn8LvE+q+IdJ8KeEnWPx54utfNhnKEr4a0V1/eX8hH3ZpY2/d4wyxuGX55oSnA/D7QbYRy+Ndb0o6jZWFwlnpmmGFpf7X1VxmK22Dl414klA6rsj4aZDX6EeB9O0L9jP4Ja58VvitdLqXjvxE4udUZ3US3t+4ZoNOiZeiJ8zOV4BEjDIVBXkZpjvq8PZ01ecnZLu/8lu/ku514XD+1lzS0itW/L+tir8avir4L/Yb+DWmfCb4UpEfFl/as1k0iq00Zb5ZdUuRjBkZlIjU8ZXABSLafzRu7q7vry41PUbua6u7uV57i4mkLySyMSzOzHliSSSSckkk1t+PfHnin4n+MdU8e+M7/AO16tq8xmmYDaiDGFjRedqKoVVXPAUDnFZOm6Rf6zL9n06Pz7jdxbR/NM64JJROC5AH3VOeDwACR0Zfglgqbc3ectZPu/wDJEYit7eS5VaK2QkGk399YvqNsiNbQypHNIGyINxAVnGOFJIwcYJ4znit7XbyPS9NtdOsmnsry3nEktlKxLWVzhSJ7WYHPlyKFOCT0Q5fCSB7z3PhrTFnSJJDNG0dlqtlgx3EbDEtrco3ytgHBVwGA6h0aPHLs0spVpZWYICqKSSEXOQoyScDJ79yepNdq9536GGwOWkd5pTueRizMe5Jz/WvXf2Z/2bfEv7RfjP8Asy0aXTvDOmMkmt6uEyIIyeIo88NM+CFXoMFjwprmPgt8IPFfx2+INh8PfCSLHLcZmvL2RSYrG1QjzJ5MdlBAAyCzMqjlhX6BfEbxrpH7PfhzTv2Vv2aI7W38Tixe91fWruRVi0C02A3GqX0uNqzMmGGRiNdmBzCjcGPxkqP7mj/Ef3RX8z/Q6KFKM/fn8K/HyNn4hfGLTPg9aWP7LX7J/hfT5vFVlasbiaRl/s/w1bgAzXl9M3ytPgh2MnAJBfJ2RHxr4YaFqd9ea7d/CLxLmZzMfG/xw19OTxmeHShMRsX1mZgSBlmQeXWL4b8PeDZPh5cajquqaroXwaa+C32pbGTxD8TtWVifLjXPmJbb922MH5eWY+ZveLq/GHxEFpdaf4c8SeFdHm1fToYz4a+FEFxHDo3hmBAGW+8QzkqjSqCHFuxCx8F9rOTXhuDinTp6t7t9X1v3t/K3yx+1d6HTzR0ctui/r89307npHgS6+G/wj8DXWu+ELyPwb4JnPmX/AI+16PzdX8TzcsWsoHXzJtxLMsjps5JihfPmV1tr4t8X6roVxrCzH4PeAlPmT+IPEkkTeINUU4/eqk5aOzDc4efzJTxsiUYI+SvF37T/AIT8Aa1/wmbajb/GH4soHWPXL2J08PeHsnIi022IUybSFHm4TdjcG5IPluo/tT+J9c1QeLfFOk2/jLxQMvBeeJ/9JsNNJz/x6acu23Rhx88glBxnaDzWUcnr4j961v1et/RO1/WSt/LBGjxkafur7l/X5fNn314S+I0aWd1efs8/DuObTro51H4ieNryay0+5IHMpnmze6j9B5cQxgMoqG0+I/hDxPfy2E/jXxh8eNchZfO0nwfpph8P2jHkBhGyWu3/AGrm4mPTjnFfmb4y+LnxP+ImsJrvj7xlfeIJ4seTFf7ZbaLjACW5BhUYONoQD2qrqfxH+Ims2SaZqPjjWpNPi4jsheSLbRjphIQdiD2VRXdHIpJfHr31b+cnq/8At3k9DB4272/r0/zufsVovjjxHBHDF4nufAfw302IALYS6xBd3qqP4TgxW0J/3RL/AFrA/aR+KHw0vv2fPiLpem/E7wtqN/c+Gb62jhg12zlnld4yu1UR8sTk8AV+OPlDJJZySST8xHJpRGM5y3/fRrSlkUKclJz2aei/zbf3sJY2bTjbcYss8y7pnJUcKvZQOP1wK9Q+FUk+m6BdXNn8T/hvoMl5cbZLPxH4fOoXQCD5WV20+4VUO9uFccgkjpXmZAxjFdN4T1m/8Pabealbv4UljXIW01fSLXUJZm45jWWGQr06kqPrXt1l7SLj3/rsziXuu56wdY1YAn/hevwOJH/Ulrz/AOUaojr+rPJhvjb8EgAMbv8AhCV/+U1cXovxN1vVL+ytL/w38MtHtr1iiX2oeCrAW4wcEkxWjtweCQpAzzgc13r20uefHn7O2RzhfDlvg/8AlPrgnRjTdpJfcv8A5E2i+bZlV9b1dmx/wvD4JEDv/wAIWo/9w1Iur6nuIHxt+CA9/wDhC1/+U1SSG4BGPGX7Ph5/h8NWv/yBTwJ9wJ8Zfs8jkAg+HLbH/pB0qOWn2X3L/wCRK17/ANfeVJNZ1Rjt/wCF2fBQe6+C1/8AlNUQ1LUSxz8bPguAf+pNH/ynrRl87P8AyOP7O/Lfw+HLf/5A6VATOJNo8Yfs/HnqPDltj9bCjlpvovuX/wAgCv3/AK+8paje31/Yz2Mvxp+DJinjaJxF4Q8pyrDB2uujhlPoQQQeQQarfBT4zaj+y78RYLnSvE+n+LPDeqRxjW7TS2nEUse5h8v2iKIiePllO3b82C2GYDWYzBgf+Ey/Z+69B4btyP8A0g6VU1rSzr2mXGmTePvgTZpcJtMtloyWsy8g5WSOyV1PHYjjI6Ghxo1Kbo1UnCW6/wCGithpzhJTg7Nbf1c+p/2kPhfovj7w1H+0t8IbG28Qre6WP+Eg06LKJ4i0fA3OQPmW5g2Ak43qYVI/eQAN8DeMfDEXh29t7rSp5rzQdXj+1aTeSKA0kWcNHIBws0bZR17MuRlWRm+jf2OP2gn+DHjyf4N+LfFFre+FdSvNljqNvKXtrK+JAWVGYAiGXCq2QADschcPnd/ae+BelfD/AF25a2t47D4e+N71pY5ckReF9eKnD452W0oGGA4CBuC1vED5+Ar1MsxP9n13dWvCX80e3+KP4rTsdOIpxxVP6zTVn9pdn39GfG5GKSrmr6Rqnh/VrvQ9bspLPUNPma3uYJMbo5FJBHBIPI6gkHsaqkA19OmnqjyxtFHSigBCM00jFPpCM00wG0UdKKb1AaRikIyCMA/Wn00jFCYHuH7N/wC1f41/Z/1CPTJVfXPB08u670iWTDQbj80ts5/1cncj7r/xDOGX9TPhR8VPAnxh8MQ+LvAGux6lYuRHMv3ZrWXGTFNH1jcDnB4I5UsCDX4hV2fwl+MXxA+B/iuPxj8P9YNrcABLq1kBe2vYs5MU0eQHU/UEHlSpwR85nPDtHMr1qXu1e/R+v+f5npYLMp4X3Jax/L0/yP3QtGHFb9ooMR47V5L8GfiLdfE34b+GvH1/oR0WbX7BL42RnE3lqxO0hwBlWADrkA7WGec16jaXQWHk9q+Ry6fsakqVXeN180eviI+0ipR2epg+IsAsCK4HUyGc4Fdt4hnDFjur5W/a++PXiP4F+CrPVfCvh+C9vtZupLCK9uXBhsZAm8MYv+WjEBtoJCjYS2fun57EYapmOOWGofFJ6a2/rQ9WjVjhaDq1NkXfjn8e/AvwO0UXviK4+2arcrmw0e3kH2i57BjnPlxZ6yMOxChjxX5tfF740eOPjV4hbW/Ft/ttYmYWOmQEi1skPZFJ5Y93OWbucAAcv4h8Ra94t1u78SeJ9WutT1S/kMtxdXMhd3Y+56AdABwAABgACs8iv1LIOGsNkked+9Ve8u3lHsvPd/gfJ5jmtXHvl2h2/wAxtBGRRRX0x5LQ2kIyKcRSUCGUUpFJQA0imkd6kIzTKpCG01h3pxGKSmG42iiirExtMI5qRh3pp6U0IbTT1p1IRxTAbRRRQSxlIwpzdaQjIpoQ2kYd6WkNUJjaKKKaBiHpTafTTwaoGJSNS0HpQhDaKKKoBD0ptPplJAFFFFMAPNMp9NPWgBKKKKACiiiglhRRRQIKKKKAGniilakqwCiiigAooooAKVaSnDpSYBRRRUgFFFFABRRRQNBRRRQUKOtOpoHNOoAKKKKAAc0+mrTqT3AKKKUdaYC0UUVICr1p1ItLQPoFA60UqjvUD2HUUUo60AhacvSm0+oAKKKUdaCkLS0UqjvQMWnAYFIBk06pYBSjrSU4dKTKFpVHekpw4qQ6igZNOpAOKWpYwpwGBSAZNOpAFOAwKQCloAKUc0lOAoZQtFFBzt46ngVI9tT9CP8Aglr4ANpY+Lvind24330sWh2MjLyI0xNOVPcFjbjjuhFfpFotwWCgZJPA9TXzH8CdG8PfAL4A+HrDxPqFpo1roulpd6vc3MgSOK5mzLNuY9SHkKAdTtUAE8V8e/tQf8FCfFPxEjvPAPwVu7zQPC8gaG71XmK/1NOhVe8EJ/uj52H3iASlfA4GtXzfM6takvcTtfpZaL797Hv16dPB4SMJ/E1e3W7P1A8OfH34R+L/AB1q/wAL/DHxB0bUvFGiKGvNOgnDOOu8Rn7spTGHEZYoSA2K3dTufMUrngjFfzxaVqOp6FqNtrGh6jdadqFlIstvdWszRSwyKcqyOpBUjsQeK/Rb9l//AIKRWuvpa+Af2h7qCx1LAhtPFIUJBcHoBeKBiJv+myjaf4wuC5+gzfD15UG6Ott11POwdWEanv6Hzl/wUF8BHwV+0treqW8ISy8WwQ65DtXC+Y4KTjPQnzo5WP8AvivnADNfov8A8FNfBia98PPDXxHsIxM+gag1rNLGwKm0u0DK+RwV8yJQCP8Anrx1r86R0rTI8Z9dwEKj3Wj9Vp+VmLHUfYV3Fbbr5i9KKKK9ZHIHWnAYoAxS0mwCiigDNIAAzTgAKKKACtDw7oF/4q12z8O6YYluLxyvmTPsjhQAs8sjfwoiBnZscKpPas/pXsnwf+GeteJpNG8GaFug8R/EiRoWnKn/AIlvh+Jibi4bB4MrRuB0JSB16TjOVeqqMHNu39b/ACWpcIOcrI+jv2M/hXpPirXU+L1/AYPBvglZdN8HR3eUWe4UlrrVJQ3AbOWzztYhQcW6189/tbftATfHj4kSHSJ5R4R8PF7LRYWG0Tc/vLph/ekIBAPRFjXAIOfo79tP4n6L8F/hPo37OHw4H2SXUtNS3uFVsva6QuV2uepkuHDFjzlRJn/WCvgMAAYArwcnovGVZZlVWj0gn0j39Zf59z0MZJUIrCxfnL17fIKs6bJpsUjf2gt2hb5ori2ceZC46HaeGGcZGVPQ7uMGoGB6f57VIFHevo2eduX9S8S6trcMn9pP511KUE12WPmXAXODKekrjJw7DfycseAKNrZ3eoXUGm6fazXN5dyJBBBChd5ZGICqqjliSQABySaOAK+zf2A/hBo2jwar+1R8SdlroPhaKc6NJMMr5sanz7vGPm8ofImM5lbj5oxXNisTDB0XVkttl3b2SLp05VZqKPXPDOi6f+wl8BrHRNL0m21r4zfEKRILezUB3nvjgJHjPzW9r5g3cgPK3UBgV8F0628LweG9a8S/ELxTLe+BLHUxc+MNYgnP2z4heIgfMTS7OTgtZxMdzSdMZmIy0Qiy/HXxa1L4nePNQ+IvinVToN34mtHgs2aPe3hfwmpKO0YzzdXIZo0AILec5BAuY2XxL4ofEST4i6lZ21jp39k+FvD1v/Z3hzRUfdHY2gOSWP8Ay0nkbMkspGXdiTgBVXzcPhak25VH7z1k/wBF6bL5y/lNalRbR2W39f12O+8a/tQ+JNY1dfGmnpaWniFLb7D4fS0j2WPg/TsALDp8fRbllA3T/eQfdw+DD4pJLdXEk091dzTS3L+ZO7yEtK+SdzE9Tkk59zX23+wf8JPhZ8UPhJ4stfHngbSdanGuCH7TPBi6hha2Xasc6kSx4YSH5WHJNZHx2/4J4eJ/DUN14q+Bs934k0uENLPok+G1G3UckQlQBcgDPygLJwAFfk1NDNcFRxUsAlySWmuz66P/AD/Nmk8HWdFYjdP8D49024j069hvG061vFhbd9nuQ/lOe2djKcZ56445BGQbrNrfi/WAkcEMt3MMJHDFHbwxIPRVCxxoM8nAUZJPWs+RJIZngniaKWNiro4KsrDggjsa0PDF5aWGu21xc6TpmovuCxRakzrao2cl32OhIAHTdg9CrZC17j7nFY6bTfhZeaqzWGnapLr+qqiudN8M6fLq0qA/33jxFj3SR/pWR4i8CeIPCcksfiCG006RBuFpLfQyXSg9A8KMZEPHRlFfQ3gzVtQ+JttH4MtLz4g/EqWOIMPCfge0j8PeHLdDn5biQRj5OPvtbx9P9Zk1u3/g3RfBMsOna94k+EfwvuzIEg0fw3pT+MvEe7GfLeSRphFIcHlZYx04rg+tSjLle/8AXz/8l+ZooXPj6OC7mtmu47ScwR/fkCEqvrkjpTQyt91ga+uPEXwkkv7EeJdS+FfxN12yAJGs/E/xJbeGrBD13x27kPsPXCz9CMCvFPGmn+F7FX086/4AsvL4+y+HLS81Fmz0U3F0GVj7pMa1hio1HZL9fy1+9IHA8zpYJprS5ivLaQxTwOskcinBVgcgj8aSS2ayl8h0kjUjMYlj2OR/u5P6Gl2munbYg6qL4g3muywQfE+68TeL7C2k32ti/iCSOONyMcK8cuM5x8m0810afDnWtO1W8+Jel6D4I0HSbJPtcGha/wCIrCYzLtAMCwTyiaQnk8qG9GyBXmJU+la3hfxVL4Rmku4fD+iapO33TqlkLxUGOgikzGfxU9aylTa1p/drZ/K9l62HdP4j0zwd4/u/G893DD4C+C+iG0VX/wCJvaw2SSBiRhGmkAYjHQHPIro5YtRkkB+w/s8Ljst7Zgf+ja4jV7VPilcWOq+Ofi38PPD4tLbyIYLXQZbVoYuqp5en2OxsHpuYkZOKxfDPi6ztp7bwhD8NfAOrzJK9umq6pLd2wuPmOHaV7uGJFx0LKnGM81xzoOWtPS3TX821c0UrfF/XyR6qbW+fGLH9nMY/6f7UfzlpZLbUWAP2P9nEAdlvrT/47WTPoXiQKof4N/BEZGQU8YQc/wDlZqEeHvEeMn4O/Bjn18Ywf/LiuVJfzL71/wDJGln2/r7jXNnqBwDa/s6/hqFp/SWke1vxwLL9ngZ9L+1/rLWYdA19VGfhD8ERnpnxlBn/ANPNIfDviIrx8Hvgmc+njODP/p5osv5l96/+SGr9v6+4x/iB4Rv9c0c3Dap8HtO/s5ZLnboes2sc8+Fzs2iQ7z8vyj1PHWvqn9mH4p6B+0r8GNV+CfxOcXesabYCznZ3DTXliCohu0LcmaFxGC3PIiYklmr5ofw34kUfN8I/gyv08ZW//wAuK56DWfHHwU+IOkfFfTdO8K6Y8FyqjT9E1+2vYJE2YkidI7m4kVJE3AljjLHbggYzxeE/tDD+xjJKpH3oO60ktejb1NaFb6tU55L3XpJd0afxd+HHiLRrjVfD2vxiXxV4BSK2vZo4sDVtFIVbS9TnLeWrRRt1PlvAP+WUhryAHIyK/Qr9ojTNL+Jfw48PftKfDe1h1C50KzNzPBIqsNQ0SUMl5Zz+vl7plcdla4xzivhPxx4es/DmvbNHnkn0bUoU1HSZpCC8lpJnaHxx5iMrxPjgSRuBwK6clzD69QvJWktGu0luv1Xk7dDPHYb6tUstU9U+66GCQDTSMU6ivYOIbRQRiigBCM00jFPpCM00wG0UdKKe4DSMVqeEfDV94z8W6J4P0sE3et6hb2EOBnDyyBAT7AsCfas09K+kf2BvAh8TfGmTxdPEWtfB9g92GzwLqb9zCD+DSOPeOuTH4tYLC1MRL7Kb+fT8TXD0XXqxpLqz9OvCtnZaLplloumxrFZafbxWlsqjAWKNQiD/AL5UUvxJ+Mnw8+DPhn/hJ/iN4nttIsmPlwq2XnuX7pDEuXkI6naMAckivnb9oT9sfwb8Crabw34dFv4h8agbRp4c/Z7AkcNdMvcDB8pSGPG4oCCfzd+IvxI8cfFjxPceMPH/AIguNV1K44BkOI4U7RxRj5Y0HZVAHU9SSfz7h7IcTjl9YxDcYP736eXn9x9JmeYUqH7qlrJfcj9q4/Fmg+LNEtfEfhnWbPVdLv4/Ntry0lEkUq+xHcHgg4IIwQDxXgH7Vvgo/EX4L+J9GhhMl5ZW/wDatkFGWM1tmQqvu0YlT/gVfnt8FP2g/iJ8CNWe68KX4udJunVr/RrolrW5HALYBzHJjgSLgjAByuVP6E/Cf4/eAvjbo51DwvcmLUrdN9/o12QLi39eOkkZ6b145+YKeK4M4yTGZDio4+l78ItO/az2l+V9vyOrAY6hmNF4eekmrW7+h+VC57/jTq7b41eBT8N/in4j8Hxx7bazvGey+XANrIBJDj/tm6A+4NcTX61RrQxFONWntJJr0Z8bUpunJwlunYaRg0lOIzTa3RmHWm06kYd6CRpGabT6aRQAlNIp1BGRTQEbDvSU6m1QhrUlOPNNqkAHmmU+mkc0yRh60UrDvSVQDDxRSt60lAmIelNp9NoJGHiilb1pKtANPWkpzDvTaAWoUjUtIelWLoNooooENPWilakqkAU09adTWpbMBKKKKYBTT1p1Iw70ANooooAKKKKCWFFFFAgooooAD0ptOptUgCiiimAUUUUAA606kWlqWAUUUUgCiiigAooooKQUUUUDHDpS0UUAFFFFADh0paQdKWktwClWkpw6UMAooopAPooopMfUKcOlNp1SDFpVpKdSYxR1p1ItLUjCnAcU2n0FBTh0po606hgOWloHFFSNABk0+mrTqljFA5pw5NIOlOWkwQtFFA5qBjgOKWigdaAHAYFFFFA0KBmnUg6UtSygAzXUfDLUPCejfEHQdb8cLcSaHpd4l9dwW8YeW4EX7xYFBwP3jKEySAN+T0rmQO9FROKnFxfUadmmj1b4+ftJeP8A4/6wsmuz/wBnaDaytJYaJbSEwQk/8tJDx5spHBdhxkhQoO2vKwox0oA70tY4fD0sLSVGhFRitki6lSdabnN3bCggHgiilAzWxJ7F4D/aO8QaP8MvEHwS8dCbXvB2s6dLb2IkIe40e6GJIJYSxG6ISqhaIkDqVKnO7x5RhQKWisaVCnRlKVNW5nd+b7+vfuVKcppKTvbYKcBSAU6tWyQoooqQADNOoAxRQAUUUUDSNvwV4bXxX4kt9Kubl7WwjWS81K6Vcm2soVMk0g4ILBFbaD95tq9WFfe/7KGj6L4O8B+Lf2qfHlkumQ6lbSDTbZVybDQbQBI4IsgHLtFHEn94QxnnfXyb8IfhzfeLm0HwDp0hh1P4kXoF1OoBaz0G1kLSydDgPLC7YPU2Sj+OvoD9v34lWHhrwp4c/Z68HwpZWhggvb63j4EVlCNlnb4x0yhkPf5Ij3r5nN6ksbXp5dT+38XlBfE/m1ZenmengoqhCWJl9nb1e33LU+QviT8QNc+KnjzWviB4icfbNZumm8sNlYIukcK9PlRAqD2UZ5rm4USZyklxHCMBlZtxVj1CnaCeR0/mBzT40eSVLaGMvLJwiqpJP0xXU2ek/EPSLDOpeANQvtHAPy3+lzeSoPXZLhWjHc7HXPfNfRJQowUIJJLRLbTyPOd5ttmYup6TbafI+lGVWlXFzp17EJo3JyN8UigFWxjsrKMgSNk1kJnHP4ewqzqT6LJMJtGtLq2ViRJbzusnlHJ+7IAu4exUY9W61X4AyaroI6f4YfDvWfiz8Q9B+HOgcXmuXa2/mEZWGPlpJWH91EDufZTX2v8Atg+NPC3hPQ9F/Zn8Ib7Twh4P0q31LxNHG5DzQRlfsdgzjnzZ5WWWRuoMiychGFYX7BfhHR/hh8N/Gv7VPjW2YW1paXFlpm4cvbxAPcMnPLSSeVAvGc+aO9fKXxK8aaz4t1G7vdbuDNquvXza/rUhB+a4lBMMQyMhIonIUZ+UyyL0UY8af+343l+xS/8ASn/8ituzZ1L9zRv1l+X/AATmNX1zVfEGpXurancs0t/IJJUQbYwBwiKvRVVflVeiqABwKqBVFLgDtVjS5dFSWV9Zgu7jy1UwW8DKizSE4w7nJVRxwFJboChO4eylZWRzH2r/AME1vGWjaHpvxMsvEOp29jYWcenaq0877UjUNNFIxP1kiHuSK+1rXxJNo3iLWvCVjfxX2s3dm+uaNDqd+hjkjb5TGqwR+ZFbROFG5gzHedpbHH5p/sIXtvd/FfxD4OunRYPFfhbUbOOMsm3zUCXCYaVJVG0QNhmR8dcHGK+5Z/GMd18JvBPxb0e/8Oa5L4buYrW8vJfEU9npkcBYW11OJpRAs7qgG3zYypZzsXJGfg88wvLmEppay5fvt7v3uLT12PbwVZugo9Ff/g/mef8A7Q/7L/h79pzw9J8R/BGlW/hv4mwLi/sJGSMX8yj/AFF0oOYp2ABilkCsyMglAyrR/mrq2m6lo+o3mh61YXFhqFhM9tdW08ZjlhlQlXRlIyGDAggjgiv2ZS60zwt4/tL7S5TJ4a8bwLcR3Mc2n2umQ3JAKSKFRZ7me53KdzO+d3HTA8A/4KAfsvr410C4+PHgfTgfEWiwBvEMMS/NqFjGuPtJA+9LCoAY9WiGf+WeG9LJs0cZrDVno/hfVf3X89F/lY58ZhVy+1p9N/8ANHx/8LfFF74khg8I6rB4z8UWuSbfwd4cuV0ywnwwzJdSRqQB/ecRFipy0qnNfRWj/EOz8A2sOhWXjzwX8LGucRr4Z+Emjr4h8S3Y248q51SR3RJQf7s5b/Z618O2F6LRvLn+0TWMkivdWsVwYhMF6DowBB74/wAR758Ov2gY/CWk7LPxLb/DbSZE2y2fgXRlk1+/jyf9bqNyxeMd8iZsc4hHFe9iaDesFp/Xr+V/NHmxd9z2PXPAU0aL4v1r4HWWnPLGPJ8V/Hzx1I11c55z9gjeJieny7JMn1rhrmw1rxMjW/grxprOuwu7JLZfCX4cPZWUZHG03e22crkYLFJM+tdV4eutWt4V8Z6L8JvAvw+tLwiUeOPjFqh1fWL3Ax51vDcLlmI5Hk2zKezc5q/4s0rUfiD4ZbXfFnxW+L/xJ0YR+Yt5GLXwV4RKk/dSe/IjdR6xwZwOPQ8LlbV/5/5pf+BI0SPlrx/8Mdf0PUJJNU0uTRJpct/xPvEVg92Rj+KH5JQfYg15/INkjQ7w5Q43qPlb6Zr6Tj+E9t4tuJtK+C/wn07XblMW+/RI9U8QG2kxnM13KbewA90Vh79q6jwV/wAEyPjz4mlGp+OtY8O+D0nGXh3Lc3Ce3lWw8r8pBXbDF06VO9Z29d/uuxezlN2grnyPUbmIDBI/Ov018H/8Ev8A4OaQIrjxl4u8TeJJ0HzxxGKwtnP+6BJIPwkFeqaH+x5+zV4WUR2Hwh0W6I4zqTTX5b6id2X9K86vxFhKGylL0X+djqpZdWqdl8z8gNG1u/8ADd7/AGnpEVobgDAa7sIblQPZZkZR9cV6la+ONF+JXh2Pw78SvifJo9pHIs4i0/wDp8gikGMlZbd4ZBkDB6Ajr2r9ZrHwj8P/AApYyz6V4U8NaJZ2kbSyPb6Za20cUaDLMWVBtUAEkk8AVFrfivw9oCX/ANu1WKAaXpw1a7REZmisizKJ9qAlkyjj5cn5emMV5NbiiFXWFBtrZ3V1/wCSs64ZTJaSml5a/wCaPxr0/W/AfhLU9R0qfwzp3jiz+0/6HqV1c3ti7RY4zHHMgTORkMCQQRuYYNetL8P7zcCP2ZvDBBAI/wCKyuMEHoQft3Sv0k+IPwn8E/Gbwhe+DvHGmR3ljdJvimQL51tLj5Z4XIO1xng9CCVYFSRX5g+LvhFJ8CfiPdfCvx/8PJfFt7qVzEfD1/b6pJZx3tu7lIyoAYFmbClScoysuW616GBzeGaxbheM10u3dd1rBadTmxOClg2ubWL6/wBXN9/h5dqMn9l/wwuRxjxpcf8AydTD8ProHB/Zl8MDPb/hM58/+l1SxfCPVmfb/wAMkeImI7f29OD/AOgVZf4P6ovH/DH3iMH1PiOf/wCIrb6x/f8A/Jv/ALqY8i7f1/4CU2+Hd1jJ/Zi8Mgf9jpN/8m1n6x8MtVvdMurSw/Z48O2FxNC6Q3SeLnlaBypCyBXvCpKnBwwIOORW43wi1JVz/wAMf64PdvEk/wDgKhk+E+pKAx/ZG1cD28RzmhYlp35//Jv/ALqHs09Lf1/4Cdt+w18Sb/wr4m1r9nnxoI/38k1zp1vLIsqLcquLm2BBKsska7gBwTG3Uvz558ePhSfBeseIfhrCrGDRhL4q8IyuSTJpUv8Ax+Wm4tyYtnmewt7g9ZRXI+OvDvi/4ba3ovxE0D4Vaj4DGj3ULpNJevdq10rmRGLNyOExt6HbjvX1v8b/ACPi/wDAzw1+0N4DtYn1Xwso15IPvj7KSE1CzkwfmVGQ7h3WOT+9XBWn9RzCGLp/BX0ltZTWz0bSvs9erudkI/WMLKjL4qeq84vf7tz89AcjNFdB480Cx8PeJpotGMjaPfxR6lpTyZLGznUPGrE9XQN5bn++jjtXP19dGSklJdTx2rBSEYpaDzTENooIxRQAhGRTafTSO9NMBD0r1vwF+0Dqnwk+Emo+Cvhwr2XiXxNfm41bXCoElraomyGC2weHO6VzIeVEgCgEbx5JRWdfD0sTDkrRurp2e2mquXCpKnLmg7MbJLNPM9xcSvLLKxeSR2JZ2JySSepzSUpFJWxAYHpVvRNc1rwvrFr4g8OapcadqVjIJbe5t3KPGw9CO2MgjoQSDwaqUjDvSaUlZ6oSbi7o9E+MXxbj+Mg0DxHrGmJZ+KbC0bTtTlgUC3vYlYtDMq/wP87qy42/KhXAO1fOCMUtBGanD0KeGpqlSVorZdvL07dtiqlSVWbnN3bG00jFOpD0rZEDaDzRRVEsbSEZFObrSUCGUUp60lADT1prDvT26U09KpCY2mkc06kaqQdBtIelLRVCYw02n0w9apCEIyKbT6YetABTWp1IelBI09KbTqaapCEptPph4piQUUUVSDqMopT1pKYhG6UlOPNNpoApD0paKGAyiiimAUHmiigBlFKetJQAUUUUCYUUUUEhRRRQAUjUtI3SmgEoooqgCiiigBV6UtA4oqWAUUUUgCiiigAooooKQUo60lKOtAx1FFFABRRSjrQA6iiikgCnU0dadQwClHWkpy0gQtFFFJj6ir1p1NWnVIdQHWnUi0tSxjx0ooopDQo606mrTqChVpw600dKetJgLRRQOaQxw6UtFKvWoGxaeOBTR1p1JjClWkpw6VIC0oHFJTqAClHWkpyjvQykLQKKVR3qRodRRSqO9SwQtFFFIaCnAYFIBTqT7DCgc0U5R3oegBS0UVIBTgMUijvS0AFFFFA0gq/4e0G+8U+IdM8Nabt+06pdx2sZf7ql2C7m9FGck9gCaoV2Xw/hurHT9f8AE1pA8t4LddC0tEzve8vg8R247i3W6xzw3l+oqKknCDa3/XoUld2Ps39jbQdCN34y+OF7m10Gzh/4R3QZpwQYNIs41aac57sscRb/AGxN618WfFf4gX/xV+JXiH4hajuV9YvXlhib/ljbr8sMX/AI1RP+A19q/tJXln+zz+ybpHwl0mVE1PV4ItDkaLALgfvtQlx3DyNsPtNXwBbC386Nbp5Vhz85jUO+PYZH5/z6V85kMfrdWtmL2k+WP+GP+b/FHpY9+xhDDLpq/V/5IXtUtlfahpzM2m6hc2jMeTBIUJ+uKkv7jQZ4xHodhewMG5lubtJyR7BY02/ju+tVgPavo91qjzOo6aae6ma5u55J5XGGeRyzH8TU2laRf+ItXsPD+kwGe+1S6is7WIHHmSyMFRfxYgfjUAX1r6P/AOCf3w8Pjf8AaJ0/Wp7cy2fhC0l1hsqChuBiO3B9/NlRx/1zNZYiusNRlWl9lXLpwdSagup7N+3JrukfBD4JfD39mfw5snVoobjUlGAJ7e1b+MDkefdGWUkDrF+FfBss091cTXl0++ad2lkcjBZ2OSTj1JJr2b9s3x9/wsT9pDxZfQzebY6HONBsj6R2v7tz7gyiVx/v14xXPl1H2OGjzfFL3n6vU0xE+eo7bLReiEYkDivTnhu9L+GNvd2Hhux8IabqFuVm1jUJTNquvyD76WakKUt8kKfLVU4KSzOcLXmAj82VIt6r5jBdzHAXPc+1e4weGNIl8N3Wq+DZpfFl3pkEcWu+PfEayQ6No4CgJb2UcoLyzYKqrOrStgeVApAcb15qHLfv/Xl99/JXMopvY5H9mbxavgj4++A/EszL5UWsQW8xHQRzHyZD9AkjfhX6U+G4rfU7v4pfB6bX7a5vhJJf2Z1LXk8T38Zb7skljcoIreNGFuY7diRluezH8lbjNrfmeyu5mjSUvb3LR+W7gH7+MnBznvX6v6N4slvfEnw/+LFtN4gGj+MtEtZL0LfWFlo1nNLGoMlz5m2a4uA7AKgJIx8ucba+d4kpPmhVju0/vi1Jfqejl0t4vv8Ano/0L0I1jxf8Bvtev6Lcw+KfB0n22zvPG2j2El5C0eHN79kgMkdu4iaRYwVLKYgdrcE+saL8QfCy+BLLx/rGuWNhod3bRSPd6nKkEOJDsw5chfmY7dvfOMdq8X+HcumfDP8AaF8Q/D/RtG0aytvESHUfs2heF73z42YNNHcahqMjmNf+XhVRAU3OAPLOQd/4T3ttBqfjX4Gy6/a2OrWckt9ZlfEc+uaxHBLhRfXLXURjikG63kSLnG7lT95vn5xUpcy2Vpq2nuy377PtdHdGXKrd9Pmj87v2xPgSPgP8YbzTtItXj8L+IA2qaG3URRMx322fWJ8p3Ozy2P3q8k8Iab4y1XxFbW/gDTdTvtbfP2dNOgeWdSeC6BBuBGfvDkZ6iv0f/aZ+Gt98VP2Z9U0/UtK1yPxV8M5ZdTsn1/UrS81XULJBm4nl+yk7Fkj3MqEAk2yDoc13X7Jup+DNY+B/hrXvBXh3S9FF5aiDUobC2EJa9hPlTGQ/fcll3guSdrrzX0mIz6WCwKrShzyvyvXS9rpv1X+RwUsB9Yrumnyrf+vQ8O+Cv7JPxmuJE8ReIYNA8HarcMsk+s61GviPXyVbOY0lJtbYleA2POXuTivqjwT+yT8H7LUovEnjqy1P4jeIUz/xNfGd8+puATnCQv8AuUUEDA2HAAGeK7uxO1h0rptOl6CvAw2c4jFVOaTt5L/Pf8bHoVcvpUY6as6KztbO1s47KztooLaJQkcMSBI0A6BUUAAfQVSvrYB92MDPJ9BVuCdI4i80iooHLMQAPxPFLcvEc19HWUa1HU86DdOdkcpYHVbrRIZNXtIdN1Oa3/fQwT/aY7eYgj5XKr5gBwclRnoRXN6tLZv9h8F69dXU95r1nc2wmt4ZIVmMcK+e3mR8W7EOWX5gc52kla63XX1COGNtIsoLqVriFHSWcxBYWcCRwQrZZVJIXA3EAZGc1y+st4xtobqYanoWmQQ61bSpLLHJIsukqIzOku4gR3BJlCuCVUCMnqRXzWIpxu09F/Vu7PSpzaV1qzlNM8VXOp23hRIfA2uLpXiWG4hvjqESpNpKpCSq3kLEkiQq8ZIJG4rnIeqejat8StStvCFzqvgax0yS7lubbxNZJdiR7CFElEM1s4IEkbPHGdpBbZKOAVbFbxQdZik1m4b4w2Fgmk+JLHVyZI4VFhppSPfpt0d4zHL+9KSNtYeYn3tvOX4i8K2d1D8QPDU/xdvdLudSuLLxTEEnX7T4cSLyyZEDPzbPJZsSpCpzIOdxJ81wpSdtLPyk93+ikn/26u+vVzTWvX5L+tvxNdde+KVpa2Dz+FNLlmHieSwv1t7nAfRC8ix30O5uJFUwM8TEn5ZcDJUVxX7U/wADbH4/fDK40i0to08UaRvvNAuuh8/A325PZJQoX0DiNjwDXcafpdlc+KdY8ZaR47e803xrpFnNY2UNwrxQ+VGy/bbNtxG145oidqbdyoxJyBU9tbeJdI0/QtPmvYtZePyrbVdQuv8ARppo1hYNcoiAoZGlVCU4XDvgggCsFiKmFrwq0GlKOuzXm079tY+Zsqca9NwqXaf9f8E/KXwF4V0PxNYzabafs++MvEeraNth1WXTtaMISUl8b4fsUjRZ2EYLdVPTpXUH4SpjA/ZI+I4PtrzZ/wDTdXa/tzfCTQ/Bfxl0z4kT6De3nh3xoJZL6206ZbeQ6igxLskMUiqXLxS8oxYtJjHUeYp8JIBIyN+zR8ZSw6L5xB/9NVfpFHEwxVKOJpytGSvu9+q+NbPyPlqlJ0pulJar+uxuJ8JW/wCjR/iYR7664/8AcdT5PhI4Tf8A8Mh/ElR2J15z/wC4+sU/CJAvzfsv/GbOOD9oP/ypo/4VJCqfP+y98Zjkcf6Ucf8Appq+b+9+L/8AlhGnb+vuLOp/CLU7mwnh0z9ln4j2l1JG629xJqkkyRSEEKxX7Au4A4OMjOMZHWvZv2BviBc6c/iz4EeLrORJ7Vpr63srpCCACIb22ZW6cbDtx/DKfWvDj8LbVUw37Lnxkx6m8Yf+4mszQ73WPgZ8WPDHj0fDzxZ4U022ulcWuuK7y3MIwtyqObeAPmNyMBfl3jJORXNjsIsxwdTDXvJq8dftLVfakb4Wv9Xrxq9Nn6PfojR+M3w6l8GyeIPBbqXm+H2pZtJWxun0O9bzIGyeWEcsi56/PeEduPHq+8/2t/C+nx+I/CHxFSdTo2vxSeD9ZuYwCptbpGe0uDkYwhZ5QT3ij+lfCeoadeaPqN3o+owmG7sLiS2njPVJEYqyn6EEfhW+R476/g4VZbta+uz/ABTfzROOofVq8qa26enT8CCiiivYOJoCM008U6kYd6BCUUUUAMIxRTiOKbVLUAIyKZT6Rh3o2AbRRRTBjTRSsO9JTRLGnrSU4im1QDT1pKcwptUhARkU2nU09aCRGptOptABTKfTT1poBh60UrUlUJDKKU9aSqF0Gt1prU9ulNPSqQhtNanUh6UwG0UUUEsZTT1p5601vWmhCU1qdSN0qhdRtFFFNAxGptOPSm1QmFNPWnUjdaaASiiihgMPWilbrSUwCiiigBp60lKetJQAUUUUCYUUUUEhRRRQAUHpRRTAbRQeKKoApVHekpV6UmAtFFFSAUUUUAFFFFABRRRQWFKOtJSjrQA6iiigApVpKcvShgLRRRQgFXrS0i0tSwCnDpTaeOlA0FFFFSwQ5elLSClpAhV6U5etIOlOWpYxaKKKRSHDpS0UDrQMdTh0ptPqWAUq0lOXpSZQtKOlJTh0qQ6jlpaQdKWpYwHNPpq9adSAVetLSL0paAQU8dKaOTTqTKCnDpSAZNOpDYU4dKaBk06oY/IKKKUdaBigYpaKKSAUDJp1NWnUmAUAZopR0pALRRRQAUUUUFATgE+lfUP7LngEa78SPh34aurcNBoNvc+PNXVvmHmsUSzQ9hxHaSDPad/evmzQdGufEWvaZ4fs2VZ9UvIbOIt0DyOFUn2yRX37+x5Fo9nY/En423IWLR579rKxbbhU0jTYd42+3lmJfrEK8LiHFvC4Kbh8VrL1fur82/kd2X0lWrxT23fotf0PAv28/HbeKPjWPClvMZLPwfZR2WO32qQCWdh75dEP/XIV4Lo2srY200LXEdqpJzJHYxy3Dk/3XfBjHbKMD3w1HifxDf8Ai7xRrHizVTm81m+nv5/mJxJLIXYDPYFjj2puiaLqGp3C3cQtYLO2fM1zePst1I52k9WPIOxQWI6KRmu/BYWGCwkMO9opL59fvZz16sq9aVTuyjY/YZbsrqtxcxROS7PDEs0h57hnTP1z17Gh/KEknkbzEWPl7vvbe2ffFaXiiWBry3ghvLi7aKMFZDaLbQMh6eTEANqEjIb5d3dQazvmV2idGV4ztYMpBB/GuzVq5jtoHSvvz/gnxaW3w1+AfxO+OeoQ7CvmtE7DO6Gwtmm+X2aSdV9ynsK+AnztOOuK+9/FF0fhX/wTT0jS7aXyrnxXBbKpHVxeXb3TD8YItv0NeRnD5qUMP/z8nGPy3f5HXhFaUqn8qbPg24urq/urjUL6YzXN1K800jdXdjksfcnmmUlvbzyhltoHk8qMyPsUkqijJJ9sUDkZr1zlGOCwCqMk8D3r600rQNR1vQdH0P4gJH428S6fbmTwx8LvD7xwaXoi7cve6vJCVSEchnVnErZHmyKCwX5KdQykHGO9fXXw/vdD1v4a23hdIn8HeCtWZYo/Cnh2cX/jDx7cqSAJ5Au6K3LA9Y0iA3bUfg15+YXUYtd/68/ut/iirs0pbv8Ar+v60Z8x/EK9urzxVevd63Yaq8JW3a406ER2SFcgRW4UKohXBC7VVeDtBXDN9mfBfxFpXiv9jvTNW1rWPDenXXwz1ya3Gra/oDawthDK6yKYbdQd0hM8arlWXMWDj7w+bfjzo8PhzUTo2swaVpesWq7IvCuhS+faeHIOB5dzcZYz3hO3zDuZt2N7/L5K+yf8E7vEt1Nrfjz4Vwa5faVL4h0X7bYXloV820uIGKGSIN8vmbJyRnj937ZrkzZKeAVaP2GpfJaPo+jfRr1RvhHavyP7Wn+X4n0v8addMuh/D34z2l1rmq2Vs8MjJdeLR4W0cSkiRLq7t5lMkjs6uFiXJ25BDLjPf+IdW8WWnxK8IeJvDVx4r1vw1rduqz2mh2mnppCI4AF5fXkpEzLsmR40XqIvlPOxuZ+HSX/i74Saz4W1W31cazos8ksNx4/S08QX4l5lS4mtIWO3biRI4j83A2lucweKdD0/4vfs6w3vi21sNauvDxa9W+8daRd+HtPlkt877ya0tmDrbiJm2ryrbBnHJHyMORONOW0W499JarstPJp+R60ru8u6T+a38zqIE8NeA/2gp9ImtvCFkvxDs3lNlZeHr2XV9UmHE0l3eDMEcO4OArbQd3ODyfCP2RPO+E/xo+KX7NF9M3kaXfvrOjB2LFrfKKTk93gktXx/ssa9y1HxJefEb4MeH/HXg/xN4i12XTpoLp4fAV4dHh1maJvKkiP2z5ltAwLMGbO1Dyw4rwr9om9T4eftSfBv4+2caw2Hi6FdH1ZYJ4pYoyMQyB5IyUfbFcoMqSD5HHSu2FN4qhPCz3cWvPmhqvPVf10Mub2NSNZdH+Etz7IaaS2sp7u3s5buWGJ5Et4mVXmYKSI1LEKGYgAEkDJ5IFSXM+vSWV/O+qQaBYQ21teLfrtmnhEbGS6SVHUxqnloF3gk4aQjBVScu61q20aKHV9T1mw0zTrNna9lviscTKFIA812VY8NgnrkccZzXiHin9tf9l34YC0x4vv/AB1rWl2U1lFNp0ZvJpYZWVpFe5fy4HDGOPJUtwi/j4+VYedZ3pxb9E/+G/4c7sbVjBWk7f1959C6jqnhbUrHxJZ6f4evvGEup6TaeIl06SQtYajGw228VtNOfs6Fjbq5QEAErI338nQ1658e3l3rmm6CmmWcc2jbtH1SYtcSR6qxlBE9sAA0SfuXyGy2XXsK/O3x5/wVJ8d6graf8LPhzo/h+1X5IrnUpGvZQgGBtjURxRkccFXGAK+dPHH7Un7RPxD3x+KPi74ge2kzutrO4+xwEH+ExQbEYc45U19rDAYmokp2jbu7vp20PBdanFtx1/A/Xjxt4s8J+GV1B/iN8bdG8O2Wo+Hf7JmsZL+3s2t7xvMEl7A7MJlcrIFC4OPLQjBzn5m8fftFfsgwwahpHiT4weIPF/8AaHhC18H6lBaWs8kd7DAzt9q3FEjFyxdsurY5HHevzMZ0d282Qu7ks2T1JPJNASLgR7R9K6XlFOSSnN/Ky/zM1iZJ3SXz1PvHXv20/wBljUW8V283wt8Z6lF4xs7XT9aaQwQi8htozHD92dmRlVj8y7WyAc5AqzJ+3n+zrfeJ38YX3wq8Xrqs2jHw/LcI1vIZNPMnmeSymVVYbsnJ+YZIzzXwVSYHpWTyDBtWfN/4FLyXfsl9yNFj6yd1b7kfoB4X/aX/AGPZJvADWuueLPDTfDw3MWkpfWDTk21xE0UtvK8TSs0ZDKexHlr2Few/Drxb4B8V+I/Gt38O/jPpesReLXt7+00uCYLd6VdC2ME0sccmHZZCkUm3ZwyN1Br8niAeozTSfLZXjYoyMGUqcYOeD+Fc2J4ao1otU6kk2ra2l15uqvvrua0synTabin+HS35eR+knx48E+NfiB+x7exfE+xhh8aeF7QardsrJIGntJHjlmXy8L+9tS8mABgsPlGNo+N/Cvhe08QeHNP1aD4ZfGbV3ngAlvNMuVa1mlX5ZDERYvhdwYY3MRjBJIr07VvHH7V37O3gabRfilYyeJ/BXizRptOhmvbg3AtXurV8IlzzJFIofPlyAoQjBV4LDy7wJ4ehPhaxmv8Awh8WpZpvMlEui4WzdGdihjBhJ6dTk5OajK6UqGGn78ZQc24uL013W+ln0u7CxdRVasXZppWd9/U2H+Hakf8AJFvj3yMDdIMf+m7pTP8AhXSAHd8FvjwPfzB/8r6t/wDCO2TkE+CvjuQOnzg/+0KG0Gz5z4P+OwT3cf8Axmuznff+v/AjnKY+HoYHd8GvjwRjs3/3BXP+NfAD2+hXF7pvwp+KthNZqZmu9bxJbQRDmRnAs4yvAB3bwBjnNdO2g2ePk8HfHQ/WQY/9EVHP4YtLqF4LnwR8cJYpFKOjkMrKRgggwcginCq4SUr/ANf+BA4pqx798Obg/tAfsX33hGRftOraTYy6UiZ+b7TZbZ7Tnr80flxk9/nr45+IznVb/S/GYO7/AISXTorudtuM3cZaC4J7FnlheU+0q+tfRn7Afia98OfEHxX8N9Vt7q1kvLZNQhtrpCjxT2z8qVPIYpK5PtH7V5v8evBUXhrU/HPhG1iITwh4nOp2IBIC6ZqSK3C/3UKWq8d5W9TXDlj+pZniMGvhbU4+k9H/AOTWOzF/v8LSr9V7r9Vt+FzxCiiivqjygooooJGkYopx6U2gAppGKdSHpTQDaQjIpaKbAZRSnrSUwA802nUhHNAvISmU+msKsSEplPpp600ISkaloPSmSxtNPWnU1qAEpGpaD0poBh6U2nU2qENakpx6U2qQAelMp9NNNEjKQ80p60VQDKKD1ooExGpp6U5ulNNMkbSHpS0VQmMooopobEPSm0+mVQmFI1LSN0oQhKKKKpgNakpx6U2kgCiiimA09aSlbrSUAFFFFABRRRQQFFFFABRRRQAjDvSU49KbVIApV6UlKvShgLRRRUgFFFFABRRRQAUUUUFhSjrSU4dKAFooooAKcOlNpw6UmAtFFFNAKvSloHSipYBT6aOtOoGtgoooHWpY0PoooHWkCHU5elNpw6VAC0DrRSr1oKQ6lXrSUq0DHDrTqaOtOqQCnDpTafUsrqA606mjrTx1pAh1FFFQMcvSlpB0pR1oAcOlFFFA0OWlpF6UtSykKtOpB0paQdRVpaB0oqR9Qpy02nDpSYxaKKVaNgFHFLRRUgFOpF9aWgAooooGgpaSnAd6Cjrfhm4sNb1LxMZET/hHtHu76MsM7Z2TyLdh7rcTwN+FfZHiuT/hUH7AdppKKYb3XdLtrZkk4YyajKbiZT7iDzFx7AV8nfDnw7PrXhufSYV2y+LvEuk+G4XGdxjZ3kmAx6OLUn619Lf8FFfEsFro3gnwBYKqW7XN1qRUfwpEqwQcf7pm/Wvls2f1nMMNhOjnzP0grr8Wz08H+6w9Wt5W/wDAnb8kfEaqjlIppTGrnDSAE7R68f5/nXV2GpQWVvDNaRraRIpVNSvkE0+ARuFtBnZHznBGdrf8tVzXIybd6Rl9uT0xnP14PHrxXTaPq8VpvurK4ewZF/e6rKvmXedoGy3XI2NjGCG3DIzIqtivpaiuv6/r8zzI6Mu30Wsi+/sjw5o9wmqXTEzTXMnnai45LSSHpbrtOSMBwMl2dfmrlruyWxmFtHexTuhxKYeUU9Nqt0b6j5eOCwINdbqV1cW2ixRNA2kafqiI8Gnwv5l9qmDlZrh8A7CxyuQFJwY4+XccZFxvOzadx4zkfhyeKVO9rg3diyHYFOe4z+Yr7t/4KASw+GPgV8H/AIb242CKKGXYPS1sIIf/AG4avhJ084pF038fmK+2P+Cod0n/AAmPgHSoxhLbTLyVcdAHmCY/8givOxkebG4Zecn9y/4J0UXalU+X5nxdbTTpBdwx3awRywgTITgzKJEIQcc/MEbBwPkz1AqMdKfBBayQ3Mt1dmJokHlRqu5pZCcAeigDJJPpjgsCGDpXqHMLXonwZ+J118P7y/sE8Sv4Ws9UhcahrWm6atxrRtgPms7OVseQ0vTcHjHGWY7VU+d12nwbsPE974+tbjwnFokd5YxSXTajraRtY6RGuM30plzGBF1G9XG4rhWfYKxrqMqclLa39d/yKjdNWNP4xxanZafpyReFI/BWg3aC60jQbiZptTvImJxf3jkB3L5bYzhFIP7mMIXNdz8H/D+vfs5+Pfhf8WvEt6todWvYzqelspSWz0u9Ro7eeQnhhNGLuRVHKiBS3LAD0Dwr8PPA+vHWP2kvGuna94z8CeCpvtU+pX0RbUfG2p+akcs7LIT5NjG7ACMnkJiQsd6x818XYNV8a3/irS9T1Z9bu7PUbm2sr05c3Wm3wbVdHZSeCCY7mIDoovUQYGBXm/WViF9W+zZqfzW3e6um766rrdLdQdO1Tr0/zPt/w1P4e+Hnxv1Twkt/4K0yfxWranYaNo3h+ePUbplJaS7vrsZjI3LOADtU7hjByG3Ph5p7+HPHHi3QJ9LmtoNTuf7TsrvU/F39p3uqg8Suto/zWsEe8IBk9s9jXnPw48Za78TfgV8O/iZpTeOdZ1PTGhivtE8M6jDZf2pdwHyZPthlxugDReYV3AESjIIOR6X42sNC8M/ETwh47Nxo2l3mpXDeH55R4Ze+1LU/MQtBapdx5NrCuHd2YbSFGWAFfEThKMnSn8TTT6+9DbRWeqXW/wDl7sWmlJbaNejHfDKHU9e0fxZ4F8fx+J/Etva302nz3/iPw5BpthqMEi7Wgs4ojiW2QLjcRzv4JGMfOX7VHhu38Vfsr6xp2n6j4Nn1X4VeIYmms/BttJbWWlxs7Qm22Och0EwZyMfNGeAQa+nY9Blsfi/a+JdO8HajenV9Ne11LXJPEBW006OPHlwx2LMdzyMiEsiDGSS2cg4vxE0aPxdrHjr4R3/jyK4k8X+ELh9N8NQaCYjY5Rka7kvVyJHeXG1WKnjgErmvRwNZ+1VWOi0l06aS0V7aX7f58+IjaHK/Nf5f1qfkD4s8deM/HV2NT8aeLtV1uYEusl9eSTbM9du4naPYYFVV0OT7Os7XVoZ5iqwWkcnmzzFsYG1M7Dkjhyp9AaoWygzJE8TsDIFMa/K5BP3RkHBOcdDz2r7c/Zo+D3iL4iSzad4d8Z6D8PtPtoiL8eD7dr7WmVmI2Tas29bdz18uObOAcwqBx9nisRDAUua1or7vwT/L7jxqcJV5WWrZ8n+IPhb4z8IaVHqnjGyg0Ga4EZtNMvpgmo3Ic4BFqMyxrjndIqKf4WJ4rqNF/Zu+Isul23ifx9JpPw88PXJ3w3/iy5Nk1yo5byLbBuZztyR5cbA/3h1r9LrH9lzwB8ONFlvfhzpOqWuuuxe41m1ht7/xBds/BEV1eZjtix5aRVXHXg814Zq2j2vhzxpdW2kTG28WKfMvI/C8beL/ABei4w0l9rd8fsmmYBBOwAqATkivKhnXt4/ul87fprb1180jeeFdJ2mdR8DfgX+zP4V8CWkvjfwhp2rXeqTrHpt54i8OzWlxq+4DAsrCeaW5lTPRjGpbOQNoyKn7QP7OH7HOjeHtY8Mtq3g/4f8Aiu5jM9hcTazKJYJgwYBrYyuRE3KECP5VYlRkCvOrP9qn4dfCu31rS/BXwrj8X+N9WtjHfXsWv3Gq3gt9mJDeawPnuHOQSloI4F7SuckfJHxA+K1z8RZvKHgXwZ4atVcyCDRNEigcnOctO++die+ZDnJzmppYDFV63tpVJRV77r8r2t8rPyH9ZhCHJyp/13Oa1XTpdH1S70ma7s7t7SVojPaTLNBLg8OjqSGUjkfXkA8VBTRtXgYHtXZfBn4e618V/ihoPgPQrWxnuNRnbP28zLaoiqWLTGH94E4wdpB5AyCcj6CUlCLlLZHJa7sjjty+opGUMOa/TnTf+CdvwcsvCmnab4vF5qusW8F1FNqenyvYrK0shdH8otIN0QO1MnaQBvVsAD84viJ4atfBnxE8S+CNNvZb6DRdXu9Mgmkj2SSiKdowSoJwTtHQ9a4MDmuHzCpOlRveO91+KN6+FqYeKnPZnoS+GvhVqtpAgsvi/dWhCywhdNt3TBHDL8+Oh4I7Gt2zHh/T7WKysdT+Pdvb28YjiiitkRI0AwFCiXAAHYVg+EfGE9n4asbPWPiV8YdOubdDD9l0iISWcMSsREsZa7jOAgXjaADkDIrV/wCE3tSDt+Lnx0x/16L/APJ9ROE7uN3b5/5Eq25eFxpTNn+1/j8w9fJXP/oyj7VpgJP9tfH8KO/krx/5FqgfGcDD5vi38civvaD/AOTqVfGdnjA+LXxzI9FtF/8Ak6o9lL+k/wDId0W31LTs5/4ST4+Ae8S//Haik1PTtuU8Q/Hkj/aRQP8A0bVY+NIM4HxZ+OOPT7Iuf/S6kk8aIVIX4t/HHHcG1GP/AEuo9i/6T/yHzIofDvxLa+Bf2j/CHiu2fxKbS41CCG7m15Al1Kk/7mdmIJDKEdiCT2r3T9rnwnt+K2nzrbLL/wAJr4Uv9FdMY3XtkfPg5/vGRbRfoK+YfiRqVlqMFjf23irx9q91bSlN/iK2WNIEPP7txcSkMSOmB0znivsL9pDV/wDhIfgT4B+NlrEHm0bU9H8QOMc7J4gJU/7/AAiBHtXl5inQzDC4hfaUqb9d4/iduGaqYWtSfRqS/J/gfAa46DtxS1teNtDi8NeM9d8P22fI07Ubi2hJ6tEkjKje+VAP41i19ZGSnFSXU8q1tGFFFFMTCmnrTqRqCRKKKKAGEYopWpKrcBGptPplCAKRqWg9KYmNpG6UtIelUhdRtI1LSHpTQMbRRRVEsbSHpSnrRQIZRRRQA2mHrTz1prVYmJTKfTD1poGFNPWnU1qoka1JSt0pKoBp60lK1JQJiHpTafTKCRpooPWirBjD1opT1pKELoFNPWnU09asHsJQelFFAhtFFFUAhptPplJAFFFFMBrUlOPSm0AFFFFABRRRQSwooooEFFFFAAelNpx6U2qQBSr0pKVelDAWiiipAKKKKACiiigEFFFFBYU4dKbT6ACiiigApw6U2nDpSYC0UUU0A6iiipAUdadTV606gfQKB1opR1qB9B1A60UDrQwQ6n0yn1ABSrSUq0FodSr0pKcOlADlpaRaWpBAOtPpo606pZSFWnDrTVpy9algh1FFA61Ix9A60Uq9aAFooooGh46UUUDrUlIfTS2Bk9KdXqf7LXw4HxX/AGgPBng6eAy2T6it7fjblRa24M0ob2ZYyn1YVnVqKlB1JbJXHGLlJRXU851fSNS8P6te6DrNnJaahp1xJa3UEgw0cqMVZT9CDVSvqT/go/8ADZ/A/wC0ddeI7e3Mdl400+HWEYDCfaBmKdR774t5/wCuor5brOhV9vSjU7oqUeSTj2FHWnU0dadWj3EFOWm04dKGAtFFAqQHDpRRRQAUUUUFIUcmnUi0MMqR6ikxn0l+y5okV98QvhLpvEohudZ8WXC5J2hE8mLI7Ylscg+rGqn7eGuDU/jsNISQlNC0aztCueFd1M5/HE4z9K9L/Y90aK4+LRmiUmPw58PbGBQR92a+aG5P4/6RL+Zr55/ac1dNf/aF8e38Tq6JrM9mpHcW58gfpEB+FfL4f9/nrl0hT/GUr/kz05r2eXpdZS/Jf5nlru3mbFX6kjj/AOvW9YxjTLi2aTTl1HV5yqWOntF5yozHCs8eD5jEn5YsEEnLBgdj5MFwlqTcqFaUf6vPRf8AaP8AT8+nXf8ADkGqTaiNG8PgN4g1XzIpbuV9v2OHaxmJduI/kDmRyRtQOCQN4r6eWx5a3K+uXr2F1cedqDanrdzk6jfb/NEZbhoo3yQ3XDyA4P3VJXLS464ORhhx3HWuri0jQBHdauiTTeF9EcRNcvuik1i9P3UXOGUHk9jHGGJ/ePiTm7830t19rvIlie7XzhGF2hUP3Aq9FXAwo9AuBtK5E09BFZ3aL94gyyHK/XtX2Z/wU3/fePPAeoRnMV1oUro3qDcSN/JxXxpIAVBY9CD+tfXn7cN83i/4V/A34gocx3fh/wAmU9/Ma3tGAP0bza83FtRxmHb68y++N/0Oqkm6NS3k/wAT5OsE0z7HqFzfyK86RLFawZ5Z3JBc/wCyqq/PZjH1BNVx0pihyC4Riq/eYDIH1Pan16L0Odai16R+zv8AD34ffEr4mWmj/EzxvYeHNDtgJ5RcXH2eTUDuAFtFKw2IWJ5LMOAcBjgVH+z78H7r46fFTTPAUV09pZMr3uqXSAFoLKLBkZQeNxyqL1G6RcjGa9z/AG+fAXwR8L2fh1/h/c6JpnibSDHot7omn3CtMLMRF4ppo1JZZAcKXfDSCRSSdtediMbCNeOBi2pzT1Svy+bOmFGTpuu7csX16novxy+IGgS+Jn8D6Lot94f0j4TXP9ia9oiybLTUfC2pQx2s13FCnaEyRbN2eLiOQHO4DDvNe8N/sufDLR9f+I+hJrXxKudNk8M6fo9wAbS4s7HUpXtr+VSCygBYlRt2WWJAm0b3WTwn4y8K/CD4HeB/jL8U9MF54mTwxcaJotsblDJ4hsJppWit7iJlJWG3jW3YTcjZIFwxCLXm/wCyze3/AO0p+1a/jj4q3Vtqk+nWc2rJZyQloQIiqQwwx8oqRmRGVSTny+dxJJ8GNFewm5p+xpX5nfWbV7pPezd23fqo9Hbscv3kbP35beSdtfW2n4npX7DN9d3Gi/EH9nb4i+EWR761i8R2OiXby2nnQzxR7owc740YNZEEE4BJOec/X3ws8YaVe/DsjTLDSGk8MwyafdaL4Svv7UjtJLdcrZRNhPMkCbBswPmOMkc1+e+p/F/xp4L/AGuE+L/ivWLHVLDSdaXQdWudLZjZQQOJEe2jYgNMY4t5LYOZEzk5Vm/QQeJND8BQ6v4q8W/EXw3beF9SeOfS0eG3s4LeJk+ciYOTdmVm3hgAcEAA8mvPzqlJVI1ZL+IlKyba5tFJL1VnrZ/kdOBmuVwT+G61ttun95o+NfGWraH8N4/HllcWPhPyjbXOoDxNp0129jbs4WSNoLJ2Yz5ZVADMoJ5rqI/Fmo3PiGw0u00HUZdLurb7YdUEsS20Um9dkDRlhKZGB3ZCYA6nOQPjrxH+378CPhLoKeDPgf4IuNYhsdy26W6tpunRFmJcgsDM5LEsfkXcTndzmvnbxx+37+0b4sE0Gj6zp3hS2k3AJo9mqyhT286UvID/ALSspz6Vph8mxdaNox5I66y0dn5LW682TUxtKDu5cz02OD8PfDTUfiJ+0XrPgrw7pdlf28Ot3sskd1fiythbxzlcyTAEqhJQHYC53AJ8xWv1u+GPha28D+DtL8LWum6Pp6WMW022kWr29ojk5by0dnfk9Wdi7Hljk18CfsC+AtDe9l+Ini3wnps11Nem30jV9X1SJcOoG5bOzYF5Zt5GZjgIBhDuLgfopYSEAZFc/FGPcsTHCp+7Bfe/v/yZtlOHSpOq93+R0cAR12kZzxiuN+IXwV8PfEHwofCPk2+n2e7fHAltvskkLAmV7NWSKeRQCUEwdAxyUbGD1tjLnANb9kAccVOXWqNNPUrFJWaZ8z/s4fse23wH8Ynxh4R1vXtCtLm2uNP1PR7u9tr86qgcG2uHmiijFuwO5jHGG/gG8Aup3/i1+xx+zt8TrybWfEHw8trXVJmLy32kytYySserOsf7t2P95kLe9fRTgeXwKw9SAIIxXr46rVor2kZvm79Thw9KnJ8rjofnX+0h+wrpWn+E9A0j9nnwDPcazd6wI9QuJ76SSRbbyXPmPJI6wxRhh83yglmTHQhup/Y0+HXxI+DPjC48Kt4X1/V7SWT7LrGrPbDSNEtNoDO9uZIxPqku5RGsmEUBjjKYavse4QBiSBwafbEBs4y3r3rw3nWIlReFre8u7vfe/wCHRaed9jveX0/ae1hp5ItXqCeE7hjI7V+UH7Xnw6X4TftTSeJrvVda0XRPFU/9u2epaLFvu7eZyTMIgZYgXWfcfvrhXQ98H9ZGG+PkV8wft3fCf/hZPwWvdZ0mFv7e8GsdbsJIgfMMaj/SY1IGeYwJAByWhUd61ynGrBY6Ll8M/dfz2f3/AIXJxtB18O7bx1PhQ/EOzBKj4/8Ax3GODm2/++dNPxFjBKr+0B8dCn/Xuf8A5Z1n6P8AFG6vNMt59V/aE+MUOoMgF1HbRtPFHJ/EA51JWce5VT7VM/xCjLFf+GifjOR72bZ/9OlfYum4u1vw/wDuZ4Sl/X9MtD4ixEED4/fHMD/r2z/7k6T/AIWFBtIHx++OOfT7Lx/6c6qt4+Xadv7Q3xnx72TY/wDTpUY+ICqDj9of4xj/ALc2/wDlpQoPt+H/ANzDm/r+mWv+FhxZIPx7+N3/AIC//fOll+IMIU4+PHxwP1tf/vnVUfEBTuA/aI+MhHp9jb/5aU0/ECMZX/hoT4xkZ/59G/8AlpT5H2/D/wC5hf8Aq/8AwTH8Z+KLPXvDt3Yy/Ff4oa2w2Sx2WtWgNo7Bhkuft8m3CliDsY5475r6e+HwPj/9gzVNLmP2i40zStSiCjrvtJ/tkQ+oTaK+b9R8ZWWoadd2Fz8d/ixdw3EDxSW1zYloZlZSCkgOpkFT0IIPBPB6V9F/sA3UHiD4ZeL/AAfcPvifU8Mp6eXd2zQn8D5NePxAnDARr2/h1IS2t1t/LHud+W2liHT/AJotfr3Z8lfEkSz63p2szOHbVdE065L4xudbZIpD+MsclcoRg11vjC0lTwv4Pupz++gtbzSpgeokhvJpSPwW4QfQCuTavqaL91Ltp92h5ctxtFFFaksKDRRQSNooPWigBD0ptOPSm1SAKaetOprdaOoCUjcKSfSlrR8N+H9S8W+I9J8K6PF5l/rN7BY2y9jJI4Vc+2SKbairsNyrqGlanpEkEeqWMts13bx3cAkGPMhcZRx6gjpVavtD/god8GbDwVYfD/xX4dtRHpun6dH4RkI44tk3WzEerJ52T/0zFfF9cmXY2GYYeOIhs7/g7GuJoSw1R05DD1opT1pK7jBjKKU9aSqJYjdaSlakoEMPWilPWkoAa1NantTG6VSExKaetOprVSDoJSNS0h6VQmNPSm049KbVIQ1qSnN0ptABTT1p1NPWgga3WkpW60lWgY09aSlakoBBTW606karF0G0UUUCG0UHrRVAFMp9MpIAooopgFMp9MoAKKKKACiiiglhRRRQIKKKKAA9KbTj0ptUgClXpSUq9KGAtFFFSAUUUUAFFFFAIKKKKCwp9NHWnUAFFFFABT6ZT6TAKKKB1poB1FFFSAq9adTVp1A+gUq9aSlWoG9h1KvWkpV60mCHDrTqaOtOqQCnL0ptOXpQWhacOlNpw6UMBy9KWkHSlqRoVetOpq06pYLYUdKetNHSnL0qWNC0o60lKvWpGOpVpKVelAC0o60lWNOsLnVdQttMszB591KsMXn3EcEe5jgbpJGVEGe7ED3oGiKlHWvao/2K/wBqCYBovhVO6sAyldTsyCCMgg+byCOQe9TJ+xB+1Ux+X4Q3jfTULQ/+1a41jcK9qsf/AAJf5mqpz/lf3HiNfoB/wSh+GhvNY8YfFi7t8rBHHoFjIR/E5Wa4x9FWAf8AAzXzl/wwx+1m6ny/g3fnHpfWh/8Aatfql+xx8ILv4N/Anwt4N1WwNprH2dr7VomKlkvJ2LujFcglBsjyCR+7HJrhzLEQqUVSpSTcmlo76bs3wsGp80lseJ/8FTfhc/iT4J6V8RbK233XgvUh5zBcsLK72xuOOwmW3+mTX5UA5GRX9CfxY8Aaf8R/hv4j8BamoFv4g0u5092Iz5ZkjIVx7q21h7qK/GZ/2Df2uIWKf8KZvmCkgML60wR6j970rXBSVGLpTdrar0f/AASa3vPnXU8GXrTq9zP7DP7WKfe+Dl+P+3+0/wDjtNH7Dv7V7HC/B2/P0vrU/wDtWun6zRT1mvvRnyy7Hh1PqzrOj3/h7WLvQdVSBbywmaCdYLmO4RZFPIEkTMjYPHBPIIqtWzJCgdaKB1qQHUUUUAFFFFBY5elNkbaMnpwT+dOXpVvR7E6lrNhpqjJvLqKAD13MB/WpbtqI/QD9j7TY0+JvxYuQcw6feaNoSey2yTRn9IV/KvgfxnqLa94w1/WFcgajqdzdlupPmSM5/PNff/7KV1BDo/xg8Rwjb53jTU5d3tHE8o/Lzf1r86tr+VtVjn7u49eO/wClfMZIubMsXU7Kmv8AyU9PGaYWjH/E/wAR1vKIGLwrmUcR46q3r9fTuDzxgE+j6P4W1GC5/wCFXaFdW9trGoxtN4q1JziLSbKIeZJA7/wrEqF5sfMXVY1GYyJOU8OXkXhO1/4StVjOpDMejxuufKkBwbv/AIByEP8Az0+bP7plPWX+k6roFjafBzw7btdeMPFMsLeImXPmRksr2+nbmwFCHbLNngShEbBt8n6OrK7sv6t1fkvzsjzEu5W1C90LxPdvcW1pNa+APBEX2extZZfLlvpXLFN5XpcXLozuVzsjjYKWWBFriL2/udUv7jUrxlaW4cuwUYVR2VQOFUDACjgAADAAFdR4pvtPv3tfBHhu5H/CN+F45JJrtQF+23JZRPec9fMYRxxBsYRYVIVi5PIRrGCRGAoBzgHOM806cbK/9f8ADvdh1HMoZSpHBGK+qNeJ+I//AAT+0fVElM138O/Ef2W5AHKwuzBQfbF5bj/gNfLNdd4V+Lfjjwb4F8TfDnQ7+3XQvFoiGo281ukp/dkkNGWBKE5GSOflXpiuXGYaVf2cobwkpfLZ/g2bUaip8yezTX+X4nJ26ebFNA96sEQHnYZvvyKGCADucuR9Cx7VEjEgEoyn0YYIp9vFDJPFHcSGOFnVZHHVV7nj0qS8uvt17c33liP7TM82wfw7mLY/Wu1syR7l+xd8XvC/wb+Mrap41uPsuja5pk2kT3vllxaM8kUiSMAC2zfCqtgHAcnBxive/jP4A/Y08HeINW/aC17xxF4zvdZmfUrHwraazBdW99eOdxJ8rc4gLnc28hQCV+fKxn4NIBGCMg1G6hQWGSeoHJ/KvLr5aq+J+sRqSi2rO3Veu69UdMcQ6dPkaTV7q/Rn15+zbZ+JPjz8TvFf7QPxP0+31Kw8NaXOumpIpW2s7xYy1vFbw4K7IIlkIUnCs8b/ADMd1ZH/AATw1pbP4i+LfCEl3bWo1/w9OkMoH+m+dE6bRbE8FgjSOVzz5an+Gvpr4M/D/T/hR+ydqkdtriau1zoGqa1cXUF6Lm1Mj2knFuQAFQKiAjGd4bJPb4y/Ym8Q6f4d/aN8PHUY4ymqC602GVwMwzSxOI2Unoxfagx/fx3NeIq/16hjVTXuxSjFL+6m9vU7fZqjUoc271fzPMNW0bQNK8HxMdO1t9eutUmiubm6t/s1tZxQjb9l2EEvOS6O/wAwEYCLhi7FcHYSoG4nAwMn/PvX6KeP/wBk6z+KUfjWLWl1ODV7GSSTwlJb+Xa6PCZt1yYra3Xc7lnZUnnkwXldio+TLfBPgTwJ4t+JPiQeEfCGkve6r9nuLowkhMRwRNK5JYgA7UOATyxC9SAfbwGaUMfTlKEvhs32V1dfK35M4a+FqYdpSW+3yMMADoMUHoaRHWQblORQxwpNeic59ofsWS2mh+F08RW3h3wN4Vj86SG/8Ya9qKXOoXYLnMVnbEx+SoXYhLNtY/8APQjaPvvTLqK4gimhYtHIiuhKlSQRkHBAI47EV+dn7EPhOw0mwuPij4i8CaTa6fZ3DD/hMPEmprDa2iJjcljA0YDTZ3BpjIAmNow25W+wfDvx1sPHV6bT4S+Fda8YxLI0UmsIosdHjcMQy/a5xumYEHKwxSH86/NuIMPOvjpukrpbu6svJtt29G15RXX6bLKsaeHXO99l1+639dz3KxccGujsZRxzzXHaTJcGCP7WIlm2jzRExZA/8QUkAkZ9QD7DpXT2EoGOaxyuq4OzNcXDmV0bkjAx1i3/AH4rSab5MZ7VlX7k54r2cfU5qZw4aNpGJdH5j0FV4n+b26VLcnBIqrHKofG4H0r5GpK0z2YrQ2UYmLisXU4UdHjdA6vkMrDIYHsR3B71rQyjyz8wrL1NutaYl3ppk0visflF8WfC+pfs5fGjXfAlp8S/GHgzwfqedZ0uTQzJKHWThEaIXMCkrtkiL7i37ocEHjJHxVs41Oz9rP4tD2Gmv/8ALSvq/wD4KCeApNW+G2m/E7SGkg1nwRqMUyXEORILaZ1UlSOQUmELA9tznjNfKll8Vrq7sra41D9qnx7bXM0KPPAmmSuI5CoLICLsBgGyM45xnA6V95lmJ/tPBQxDV5fDLRPVdfgk9VZnzeLofVq8qa23Xo/mim3xSgZju/at+LJU/wDThJz/AOVWpl+KVptI/wCGsfiwB6f2Y/8A8tavf8LRwP8Ak7Px+vb/AJA83/yZTT8UAQR/w1h49b2/smbn/wAm67fZP+X8P/uRhfz/AB/+2M8/FG1IYf8ADV3xYGen/Evfn/yq0f8AC0LMKR/w1b8V/b/iXPz/AOVWr6/E+UZz+1X4/X/uFTHP/k3T2+KL4/5O08fn2Gkzf/JlHsn/AC/h/wDcgv5/j/8AbGWvxRtc4P7VfxXVTxkac5OP/BpXp/8AwT41a1s/FvjrSrW6luIZbe1vIZJE2NIkM5QMV3MFJE/I3Hr1PWuAb4nSAbh+1V8QmPtpMuf/AEsrpv2Lb5Jf2gfFRt9butWivtFvpTe3MRjlu2N1BJ5rqWYhjtLEbjyTya4c2pc2V4iLVvdvtbZ3/kj+p04GXLi6T8/z+bPOPjDpYsoNdtdhVtH+IOu2+OwSbyAg/K3Y/ia8qPSvdf2kITaeLvijpyp8sXjexuhx08+2vXJ/NVrwo9K9zL5+0w8Jd0n96T/U4q8eWo15v87DaKKK7jIKKKKCWI3WkpWpKBBTD1p9Mc4yaaAKRq9a8OfsnftCeMNDs/Enhb4eHU9L1CIS213bapZyRyr7ES9QeCOoPBwa0z+xP+1ORx8Ib4/S+tT/AO1a5njcKpOLqxuv7y/zL9nN68r+48Qr6m/4Jy/DQ+N/j2fFd1AXsfBdi9/uPT7XL+6gU/8AfUjj3iriP+GIv2rDwvwc1I/S7tj/AO1K/QL/AIJ9/ADxL8FvhhqJ8d6G2l+Jdf1Nri7tpGR3igiXZChZCR1Mr9f+WlcGbY2k8JKFGacpe7o099/wudGEpN1k5LRa/cdN+2H8M1+If7Pni3QLa0Mt7bWf9q2KqoL+fanzQq57sgkT/gZr8ZFOfrX9B2vWgNuVZA3GdpHB9jX5DfFH9h3472XxH8SQeAPhzPqPhr+0p30u5ju7aNWtmYtGoV5Aw2qQp46qa8bhvFwwUquEryUVpJXdvJ7/ACO7M6TrRjWgr9H+h81N1pK9rk/Yu/agT73wouh/3EbT/wCO0w/sZftOdP8AhVV1/wCB9p/8dr6r+0cH/wA/o/8AgS/zPJ9hVf2X9zPFT1pK6j4hfDPxv8K9Yi0Dx9o6aVqUsXnC1N5BNKidi6xOxTPbdjI5Ga5euyE41IqcHdPqtjGSa0YjdKSnHpTaoka3WkpWpKAEbpTT0px6U09KpANprU6mtVIXQSkPSloPSqExlNp1NqkIQ9KbTj0ptABTT1p1NPWgga1JStSVSAa1JTm6U2mJBSNS0jVQdBtFFFMQ09aKD1oqkAUw9afTD1pIAooopgFNPWnU09aAEooooAKKKKCWFFFFAgooooAD0ptOPSm1SAKVelJSr0oYC0UUVIBRRRQAUUUUAgooooLFHWnU0dadQAUUUUAFPplPpMAoHWigdaaAdRRRUgOWlpFpaB9ApVpKVagbHUq9aSlXrSYIcOtOpo606pAKcOlNpw6UFoWnDpTacOlDAcOlLSDpS1I0KtOpq06pYdBw6U5elNHSnL0qWNC0q9aSlXrUjHUq9KSlXpQAtGMmilHWgpbHvn7PX7W3i34MND4d8QQSeIvCG4D7G7D7TYgnlrZ26DuY2+QnpsJLV+kvwy+Ingj4m+H4PFHgbWrXU9PlIRjGMSQSYyY5Yz80bgfwnqOQSCDX4wV1/wALfi148+DfidPFXgLWGtLgAJcW8g3213GDny5o84dfyI6qVOCPkM94VoZpevh7Qq/hL18/NfO57OXZvUwn7up70PxXp/kfuLoipxhF/Ku80UgbR+lfM/7Lvx9svj74CXxhb+H7rRpre6bT7u3mO+MzqiOxhfq8eJF5IBByDnGT9G6LcA4NfOZIp4PEPD1laUXZnp49qvS9pDVM6S//ANUPpXH6lGhJyi/lXT3typiryL42/FfRvg58Pta+I2u6ff31lo8aO9vZRh5ZGeRY0HJwo3OuWPCjJwele9nlRVZKnDVvRHm4CLppylshvjbxJ4U8E6BeeKfGOsWOkaTYJvuLu6YKiZ6Ad2YnhVUFmPABr8xv2nf22/EXxbN94H+Gqz6B4LcmGacfJe6qg6+YR/q4j/zyU8j75bO1fMfj9+0l8Rf2i/EI1TxddLaaRayM2maJasfstmp4zzzJIRw0jcnnG1cKPLa3yjhylg5LEYhKVT8F/m/P7u5GLzOpXXs6ekfxYIMYFPpo606vpmeWFKvWkpV60gFooooBBRRRQWOXpXR/DWNZ/iX4RgbpJrlipHsZ0rnF6V1HwrwPin4MJHTX9P8A/ShKzqO0W/JjW6Ps79mSZov2ffiZqynDyav4iuSfddOjNfAqumQsm7Bc5x1Izzj/ADj1r70/Zty/7LnxEUH5jc+Jsj3/ALNjr4NSISuFyiksRuY4CjPJJ7D1NfP5Gl9cxj/vpfcj0Md/Boryf5nX+FdSi0VpviTqqQzPpTC20KzkIKSXqhSjFSDujgUrIwOdzGFXyJGNTRXd54L8Jz+JruWSTxR40imhtZZjvmt9PclLi4LMS3mXBLwgnny1nz/rEaqOkW9l4o1qODU5ZoPDPh21ae6ZGVXW2RskLu482aV1Rc5AeZQfkHFyx1Nta1rVfipr9pbiy0loksbER/uGuNhSztFXI/dRJGCQcgxwFCcupr3JJX1X9dF893/ked/X/BMvXYf+Ec0u28Jxj/TpFW91Y87hKQTHbkEZHlocsOu93VgTGtYUEZjjAY5Y8sfep7s3Dg32oSyzXuou1xI8rFmILfeYnqSwJz1+UHkNVQu0kRaJcnGATx9M/wCfSt0tCdtSxRTIyuNoOdvBp9IoTjHFIXVWVD1bOOK0PDnh/VfFGt2vh7RNOlvr69Zkgt4pFjaRgpbhmBAwFJ5Hakn0TVLDXpPCOqwNZXiXgtLlHxmKQMUIz7EnkdcVDcb2b8x62KCOrqHQ5B6Gur+FXgrVfiH8RNB8J6PFcme7vIt0sFgt79mQON07wuQkkafeZXIUgEHriubvGtnvrmSzAEDTO0WOm0kkfoa9X/ZZ8OL4j+Lmk27+GrjWVS4jOLHW102/tCGB+0W5MimXZglkVSxAOChw1Y4qp7GhOonayb6frZF04884xfVn6J/FXQ9L8BfsxeONG0DTtN0+3tPCuoxpDp1klpbedLCwd0hThA8jlsc/e6nrX5Jaff32lX9rq+lXUlte2Vwl1bTRn5o5EbcrL7ggEe4r9Zf2stR/sz9m7x7cs4Hm2EdvkcAmW6hTj/vo1+ZXg/wDp13pln4n8canc2GkXknladY2CCbU9YlD7DHbR9EQOCpmk+UNkKJXBjr5fhKdsHUq1Os/v0R6ucR/fRjHov1P0l8A+OT8VvhvZ/HD4eaJpl941utL/sjybm8aGCzuRKHmifOQqLKRNwu+RPLAOCMZP7N/7IVn8HLTW/EmpeMbi+8c+INPmsW1WziCx6WJBlmt1cfPIHCNvdQPkACqCxb5C+G/xT8YfsmfEJkurK1l0DX2NxrHg+3v2uLnSIw58rzXK7IrpEP3ckkErKqEjZ+ifwm+LXgT4taGviDwFr8Op26gG4hHyXNqx/hmiPzRn0PKn+FmHNeLmWHxWUcyw/8AAqNa76dIt66Lp0fnsduFqUMbZ1f4ken6rzPyx/aK+EVx8EPipqHgtjq01mscc9nfakirJqCMuHuFCkgI0qyhfmJwoyc5rgdDuVt9ZtJW0NNZYSAR2Mm8pPIeEVljIdhuK/KpBPQHmvtf/gp5ofhCO68C+J7RIYvEl6t5bXBjQBrm0j8rY0hHUozuq55IJHRRj5D8BeANQ8ZT3WpzatDoPh/R1D6trl0GMNpG4ICKq/NNM43qkCZZznoqu6/d5fi1iMFCvUe619Vp+L7Hz+Io+yrSpx7ntei6lb674j0iL4hW1/8AFzxqgjh0XwNohEei6Qq4CxymEeXhRjMNuojUKfMf7yj6EsvGeuXer2/hf4k+ItQ8Sa7GiRwfC/4XxiCx06MEgLf3kbL8oBXdGZgi46MDivKNDtPDPww8C/2jrN/qXwz8DazCGitYNjeM/Gka/wATuDi0tWJGEXanJyZNwkPS+GvEviux8J291Y3Ojfs4/CWYZtnjHm+IdbReNyM4M0jMoz5oUY42mUV8/ioxqvmitFon59o2Ts/KCcv5pp6HfRbjo/69b/8Atzt2TPr3wJc/EFDZW3iTQ/Cnguy2f6LoNlctfXZRRnaZf3UK4HJ8qOT/AH+9er2FwcDNeB/APS/BUNnJq3gj4feILS2u0y/ibxPn+1NYP/PQeczXLRnk7mESHjYhByPdLIkAetfMyl7PEOK/K36t/e79z14e/Su/6/L8NDbEp21Su3+U81IrAr9arXbcE561116nNTMqcbSMa8Z8NtI3dsjIz9K+C/j545/bA/Z58Tp4j0/XpvE/g630/wDs+2vbm0WdAf3Re4vI0ACTtISFdsjGVUnpX3rdtwf5VjX0MV1C8FzEkscg2ukihldT2IPBHsa8vC4+ODqtzpqcXumvyfRnXVwzrwtGTi+jR+Weqft5/tJa34YuPDh8ZQ2cl3cSTSalZ2kcF2sTgAQRugAjRcEgoqvljljWpB+378eodU0y/uLvT5LLR7NreHTUjcQXUvleWkt4zM01wR98gyrlwDxyD6h+3T+zto2k+HLj4teC9LlFy+pyXWvlRNcSyGcjbLuLFYYEK7dqrjMqDpgL8NqwmXy9wG4YzuC9e+TwPrX6JgKeXZph1WpUo2d7qy0fX+ux81iHicLUcJyd/U+nfir+3h4m+Jvwhm+H1z4KsbTVNWgEGr6lHMxiZFlDgQQFfkLBUBJdsfNgDIK8zpHjfSdC0ax0fTP2rNctbWygSKK2h0CfZEoGdo/eDIBJq2NO+M6sEPwy+Da7QB/zLXOP+2vP1ofSfjU//NNPgyv+6vhb/wCOUqVDCYaHsqCjGN2/iT1fqmTOpWqy5ptt2ts/0Gn4mxFgf+Gs/EnHTGhTD/2rSSfEyOQ/vP2svEZ/7gc3/wAdpjaT8Z84Pw9+DgP/AHK3/wAcpBpnxjDYPw++DhPpnwt/8crTkpfzR++H/wAiTeXZ/c/8xzfEeBuT+1d4gP8A3Ap//jlRN8RYc7h+1NrxP/YDm/8AjlTNpnxkxn/hXnwcH0bwv/8AHaY2nfGI8H4efBv8G8L/APx2jlpfzR++H/yILn7P7n/mQt8TMoQ37UGufQ6JL/8AHK6H9k3VUv8A9p7UbuPxNNr4vNIvs6lLCYXuf3O7cUJJXlcde1c+9l8XUU+Z8Pvg6P8Awl//AI5W5+yquqj9qScazp+jWN7/AGZe+fb6OLb7HH/ofHl/ZSYcEYJ2H7xbPOa5cxjBZdiOVr4JbOL/ACSN8LzfWaV7/Eu/6sr/ALTkSt8QPjDgfc1rQZh9TZSf/HDXzselfR37TTAfED4ygHrqPh4fj9iFfOJ6V35Prg6b/uw/9IiYYv8AjS9X+bG0UUV6pzBRRRQSxGpKVqSgQU1qdTW600B6N8FPj/8AEH4Fa0194VvEudMupFfUNHu8ta3YGATjOUkxwJFwwwM5XKn9M/gP8ffh78ddEOoeFLoQalaoDqGkXJAurQ9zjpJHk8SLx2IVvlr8hTWj4a8T+JPBevWfirwjrd1pOq6fIJba6tnKOjD+YI4KnIIJBBBIr57O+G8Nm69ovdq/zd/J9/Xdfgelgczq4J8u8e3+R+6unqjYyi/lXYaOgAHGBXyH+xp+1Vd/tA6Tf6R4k8PvZeIvD0ULX13bIBZXSSEqjqM5jkJVspgqcEqRyq/XGlTgKDnFfFZfhp5bi3h8QrSR7eIrRxVH2lPZkuv7fJJA5xXm+rqN7ZQHn0r0DW7kFSPavLfHfiG18N6HqniC7guJ4NMs572WO3j3zOkUZdgi5G5tqnAyOa4OIJKtX5YbvQ6stXJTvLYydSltLSCW7vJIIYIEaSWWVlRI0AyWZjgKAOpJwK+KP2hf25Le1kufCHwOeKWdWaK58RPECi9iLRWHJz/y1Yf7o5D14n+0D+1V46+ON1LpETyaH4TWXdFpUEpJn2n5XuXGPMbPIXARTjAyNx8TAA6V9TkHBVPD2xGZJSl0j0Xr3flt6nlZjn0qidLC6Lv1fp2/Mdd3d3f3c1/qF3NdXVw7SzTzSF5JHY5LMx5JJ5JPJqKlbrSV+hpWWh80wPSm049KbQSNakpWpKAEPSmnpTj0pp6VSAbSN0paRulNE9BtB6UUHpVgxlNp1NqkIQ9KbTj0ptABTT1p1NPWgga1JStSVSARulNpzdKbTEgpG6UtI3SqQdBtFFFMQ09aKD1oqkAUw9afTD1pIAooopgFNPWnU09aAEooooAKKKKCWFFFFAgooooAD0ptOPSm1SAKVelJSr0oYC0UUVIBRRRQAUUUUAgooooLFHWnUyn0AFFFFABT6ZT6TAKB1oopoB1FFFSA5aWmr1p1A+gUq0lKtQN7DqVetJSr1pMEOHWnU0dadUgFOXpTacvSgtC04dKbTh0oYDh0paRelLUjQq06mr1p1Sw6Dh0py9KaOlOWpY0LSr1pKUdakY6lXpSUq0ALSjrSUo60DQ6kJxk/h+NLXTfC/wAHSfEL4j+G/BSKSmrajDBMVOCsO4GVv+AoGb8KyqVI0oOpPZK79EXGLm1GO7P1G/Y/8Nf8IH8EPCWhyI0dxcWY1S5VhhhLcnzcH3CNGv8AwGvqTQroFV55r581fxt4P+GHhyfxX4y1i30bSLTgPJ1JA+WKJB80j4GAign6DmvhD9o/9ufx58YornwZ4HkuvDHgt8xyRI+291Jf+niRTwh/55KdvXcX4x+T5Dh8Zm+MqYqKtFttye2r2Xd+X3n2GYzo4GhGi90krfqfr3H4k0vV9Ng1TRtTtL+yuVLQ3VpOs0MgBKkq6Eq2CCODwQRXnnxV8L2nxH8DeIPAl4wEWv6dcafu/uPIhCN9Vfa34V+SP7PP7VPxL/Z51HytEvW1bwzcSb73QbuVvIkJ6yRNyYZcfxqOeNwYACv0z+FHx88BfHLwz/wkfgbVS7xBRe6fOQt3YSHosqAnjIO11yjYODkEDu4kwuNwElXWsE1aS6Pz7fkcuV1aOITpvST6dz8cLmzutOu7jTr6Bobm1laGaNhgo6nDKfcEYqOvZv2w/BZ8FftC+J0igEVprsq65bAdCtz88mPTE3nD/gNeM1+g4TERxdGFeG0kn96PnqtN0akqct07AOtPplProZmFA60UDrUgOooooBBRRRQWOXpW/wDDydbT4ieFrpjgQ61ZSE/SZTWAvSpbO7awvbbUFPzWsqzDHqpzUTXMmgWjPvH9mOJpPgl8TNCA5g13X7Uj/fsIxXwIyFiGzwrE49Tniv0N/ZcEU978XvDiJtWPxrd4X/YnEqL+Yir88pEuI38ll2yK2HyOFI69ffivmshk3j8ZF94P743PTzBf7PQflJfczZkmuzplr4N0hWknv7hJrtYhuaec/LFDjGTsDN8vXfI4OcLjYv7e01C/s/B1pcg6H4ailuL66iKkTTHBuJlbGCWKxwxk8MEhzgsc4ej3z6LDc65GxF4Ue1s2ydyO64eQEHIKo2B3DOrKcpVi4Z9I8O2+gWu5r/WWS8vdnLeV1t4eDzkEykYwweH+JK+ka10/ru/kjy/UqmRtSlvtfmhSO3gKqiKPkDEYiiUegVSQDxtjK+lQG3ljt4I1QtNenKqOpQEqAD/tMDwf7iHvWxe2EcupWXg2K5EdtpgeTULhV3ATY3XD4/i2BNgAOG8oFeX5ZZSxXd3rHiZojDbafBttYwwO2RsRwJk9WRfnBxyIDmnzWX9fL7x26GFHGkRcK4cEk7h0b3/EYqQe1RQOZI9zDaSCcU/zEVSSw+UZNU73Etjr/hZ4el8ReKjap4MTxRHBayzy2DamLD5chA4lJH3WdTtHX6Zqz8V/CN14a1azuj4GHhW0vYSsNqurLqG+SMje+9SSv304Pvj2s/CTwlc+JG1O4j+Gp8XRQeVHtGrfYfs7MWOeoL5Cke2K3Pif8PdQ0jwo+sRfBU+Fo7O4iM+oHX/tnyOSgj8ssTy7p8wHGPQ158qyjilHmXa1/wBOb/225uo3pvT+vu/U8jJVFySAB+FfRv7JvwkPjvU7a6uNA8H+KtNivIZ762k1u50/WNKAdR50Zi2MwX7w+/GSAAyMc184+bJEyTW8jpLGQ6OhIKsOQQRyDmvvb9jmybxtq+leMfEngHQdYu7BpJLPxnohS3uLe4WMhrbUoUMbGUoSBI0bB8jmTPmDmzuvPDYOU46fPX81+Dv2T2NsDBVa6i/6/P8AI9G/b41VNL/Zr1WyY/NqmqafZx89SrtP/wC0K+LPhXazWHgV/Efh9D4VEPm2+sePNV+Z7csWxZaREp3NO0WCzIfN+cjdBHln+lP+CmviaG38FeCvBSE+Zf6nc6o4B/hgiWJc/X7RJ/3z7V478B5rLUtG0KWy0SX4j+MtDtpn06y1XFv4c8GWn2h2+0XbsVV2ZszdhjHzFwMeLlEHhsnU/wCaTf6a306fa08m7J9mNaq41rskv66/d+B13wr+APif4geG3s7CGb4YfDbVAsd7e3rJ/bviRCw2+a7YEcLdVjBWLkELOfnr1vVP+CfXhawFprHwX+IviPwN4hsY/LF557TLN/eLGMxvGzYAJUlePuVY+D+iWPxJ8Wr4x8aRa58RLuxZ5bXxTqFqtt4dt7gOD5WlWTkGUL0F0YzkxkgqTk/VumgsPmzz3zXi4zOMXRxPJTnburaa976ydv5kn2SR30MFRqUeaUfR9fw0Xyv6n5CftL+CfjB4H+KNro3x68UX2sNNFGLPXWlku4prLccmEyFTlCX3RnaQ2c4DB27fTtS07wponhrW5PCX9qape8/DjwD5ZuFXe2wazqMaAG4llZR5a4HmlRtCwpGo9s/4KNfDv4ky2emeNI/Fdlq/hOPVIFs9Cu4IVvbW/lTZ5VqyxiS4ikCbzHvLKVzgqu5fAPhpP8QfEnivxTo1pbXOhfETUHuk8VeKNYQWsXhbRIUVJ1hXhoGxmJmwpSNY4YlXexH11KssXgYVG1otbaL/AIHnbXotzxJw9lXlHXyv/Wvl972NfTotdfx5JLdRQ/FP43Xpae5lvZI7jRvCipy7ysT5E0sI6kkW0DYHzlcD0r4Q+DdQ8XeNpvEfhsx/FXxrC6jUvHviMSv4c0iQNuKWERAe9lTqp+RB8pUIp3VxmlW3gKz8JRWsDaxofwmublba2s7WMr4j+Jd/G4Xovzx2okIVUHyIWx80zEp9UeBtPutJTw6/xSFr4fM21PC/w28PjfFa7Du3yrHh7yZOGdnIt4iCzfMcjysfivYwtBavRfLokui6xTUY/bbeh1Yelzy12/rX/g7voktT1jwlHPoE0fh/WPE2teI9Ynha/ub67tAkSgMFwPKQQwAnOyIEudrElsFq7m3lxx0PoRWCF1X+2Y5I721GmRwNvhMLNM9yXGH3ltqoEB+XaSxbkgAA2tIsbbSLWOxso5EgQuyh5HkOWYsx3OSx+Zj346cAAV8a6icufr/Xpb0R76jZcvQ6WGU464ptw3HWoYZQVHNEz5BGa7JVLwMlG0jNu/U9K88+JHxh+GXwqtDdfEHxrpujkqXS2lcyXUoHdIEDSMPfbj3rp/iFoMniTwjqmkL4x1PwsJ4CZNX02eOG4tYl+Z2WSQFUG0EM3BCkkMp5Hz34Q/Yl/Z1S2g8W3s2rfEFtTC3kOq6tq7TR3KMOJF+z+WJFIxyxfPrWNCjhJJ1cVKSS6RV2/m9EOdStdQopX7t/puch4q/b0/Zs8QC68JanoPiXWNF1GJ7W8mbT4Ps7xsMHKNMJMehADA4I5Ar5e+N837LieDNO8O/s/wBvqV3rl3rC3F1d3qSiSO3EUiiANIFGC8inCqc7MsxIUV9seNf2Kf2ZfEdk3neFG8NTOUgjvdL1KSEq7sFQBJjJEWLEADZkkgA818WfHP8AZr0z4JXnhvxn4e8TWnjvwVrl+kMRSQQylgElEEjIzD54jkSKQcZO1cDd9bkc8rdRLCSqRd/hb0k7den4o8fMFi1F+2UX5rdenUuR/Dy4gRYrj9nHw20qKFct42dcsBgnH2zjnmpv+Fa3rqHX9m/w2FPTHjdv63lQTfDi4EzRj9my3jIJG3/hLWJH1/e1Mvwwvtm4/szW5GOp8XMP/atew6399ff/APdDh5fL8P8A7UR/hveIgJ/Zx8NAnufGzf8AyZQvw9lxhv2c/CoY9z47K/ob2mSfDe4Vdx/ZogUeo8Wv/wDHab/wrS8dd8X7OFsB/teLj/8AHRQqy/nX3/8A3QXL5fh/9qWB8NropuH7OPhYj1/4Ts//ACbTR8OLog4/Zy8Ln/ueT/8AJtQSfDW7Ubj+zfaKB/1NzH8/31I3w4udpdf2b7YDHX/hLmOPr+9o9sv519//AN0Dl8vw/wDtR83w8uUTc37OnhhPf/hNnP8A7e1tfsl6Wtv+0/rFumg2+iiy0a9JsLe9N3HbnYqYWYs+/luu49awf+FbXjKuP2b7c7jwf+Esbn/yLXU/sS6Uv/C+PGlxFpQ01LDR7u1Nms5mFsxvbdfLEhJ37dpXdnnGe9cmZ1U8txDUr+4+t9/+3pG+Ej/tVLTqv62Rzf7TN1G3j74vFSMyeIdDtx+Fncgj/wAg18+HpXtfx+uIr7X/AIl6kDn7R4/W3Q+ot47tD/6NH514oelerlcPZ4WEfKP4Riv0ObFS5qsn5v8ANjaKKK9I5wooooJYjUlK3WkoEFNPWnUw9aaAKa5AUk9KdVjTNKvtd1Wx0LS4fOvdSuYrS2iz9+WRgqL+LED8aG0tWG+x+lH/AATr8EDwr8Fn8UXMIS78WalLdgsuG+zQ5hiB9t4nYezCvs3TLr5Rgk5wABXiOgN4Z+EHw+srLUtXtNM0Lwrp0FnJeXUgSNViQJuJPUswJAGSxbgEmviz9o3/AIKBeKPGcd34L+C1xd6BoDh4LnWMGO/vlPB8sjm3jIz0/eEYyV5SvyjB0sXn+ZVMRRXut/E9kui9bW0R9fXlRy7CwpzfvW263P0wv9dsr+GSWwvre6jSSSBnhlWRRIh2umVJAZTwR1B4OK4PW7mObetwoeJgVkQ9GQ8MD9RkfjX5JfBT9oT4j/AfWmv/AAjqhn0y6kD6ho90S1rediSucpJjpIpDDA5Iyp/QX4W/tG+BfjppJm8OXTWOswxb73Rrpx9ogx95kI4lj6fOoyARuVScVz8TcP4zAS9vH36fddPVdPXY1ynMKGIXs3pLt39D80fiN4Tl8CePvEHg2VWH9kajPax7urRq5CN/wJdrfjXO19EftxeEzo3xYtPFMUIWDxLp0cjsP4riD9y//jiwn/gVfO9fquV4v69gqWI6yim/Xr+J8ljKH1avOl2b+7oNbrSUp60leijlYHpTaVulJQSNakpW60lACHpTT0pzdKaelUgG0jUtNaqQuglB6UUh6VRLG02nU2qQCHpTacelNoAKaetOpp60EDWpKVqSqQCN0ptK1JTEgpGpaRqoOg2iiimIaetFB60VSAKYetPph60kAUUUUwCmnrTqaetACUUUUAFFFFBLCiiigQUUUUAB6U2nHpTapAFKvSkpV6UMBaKKKkAooooAKKKKAQUUUUFhT6ZTx0oAKKKKACnCm04dKTAWiiimgHUUUVICr1p1NHWnUD6BSr1pKB1qB9B9A60UDrQwQ6n0yn1ABSrSUq0FodTh0ptKvSgB69KWkWlqQQo606mDrT6llIVactNWnDrUsEOoHWiipGPpVpKB1oAdRRRQND69Q/Z5+I3hb4R+Mr74ieILCXUr7TNNnj0XT48r597MBGGaTBEaLG0uTy3KgDqR5eOlFc+IoQxVKVCp8MlZ9NOq+ZrSnKlNTjujs/il8XPHXxk8Qf8ACQ+ONVNw0QKWlpECltZxk52RR5IUdMnlmwCxJGa48dqKKKVGnh6apUopRWyWyCU5VJOc3dsdW14M8beK/h14jtvFvgrXLjStVtCdk8J+8p+8jqcq6HAyrAg9waxaKcoxnFxkrp9BRbWq3Pbv2gfjpo3x+8OeFPEWoaYmleMtD83TdTghjY293bv+8SeJiSUCuJQY2JIMq7Swzt8Upo606sMNhqeDpqjRVoq9l2u729OxpVqyrTc5u7YU4dKbTlroZmLQOtFFSA6igdKKACiiigpDlpHGcfUUA4NK33Tj0pPcD7w/ZO1mKf4qfETEoKapa+H9fVf+usIkc/8AkytfFvxG08aD8QPFWkFSBp+s3ttjHP7uZ0/9lr6d/ZU1eCP4waGySAReJPh6ICOmZbObyR+S2L143+1lpC6L+0V40ijjKx3l3HqCZ/i+0QpOSP8AgUp/Kvlct/c51Wpv7VOD/wDAfdf4nq4l8+Bpy7Skvv1PMtFhtp7lbrVVZ7Oxj86ZASN4B+WIEcjc7AZGdu4t0FaGn39wk97441CTdcrI32PgDN22SHAxgCL74x0byhjDVh+e0lsLWLGx5BI3T5mGQv5ZOPdmFXkC6pc2unmVo7CyUl2VTwo+aSTB/iPOAeThEPQV9TKN7t/0jy0+xKANI8PFAALrWOSf7lqj8D0+aRfYjyh2etJ9NNv4d0nSNpMl+s+tXa7OfIjDrGh99sc5HTInX1rLhjvfFfiO2sbOFFuNRuYrO2iLfKmSEiTdjoBtXJ5wBnmun8QX1pLYeJNf07/j0vJ7bQNLbectZwBTvx/eCwWoP/XVvWs5Nppf12X9eQI4SQ/uXSPLFU9ecY6/lk1LaWP2lpYjkhoZGAPYxxswz9do/OrNjZ7Y7+7kUloIAx5+UFmVB+aSFvwNaLQmwbWgjgtBaRWrN6TB4lcfiqS1q58ui/rYSjfVnefCbwHda/oFxqj/AAbm8XQyXbJFdpr4sAm1VzHs/i5IO7/ax2rovGPw5ay8KateRfs6TaMba1aY6j/wlX2gWoXBLmPOHwAePesj4dfD6XXPB1hqg+BOseJBO02NSttf+zJOFlZcCLy227SpXrzjPetPxH8MLuz8O6reL+zhr2nGGynkF7J4hMq2u2MnzSnl/OFxuK55xivGq1v9otzde/6e0X/pPyOiEfc2/r7v1PDIxEZI0nkdIy4EjRoHYLnkhSVBPsWGfUda/R/9hjwB/wAIh4cvtfm0y1KX9vBFYa7pl8WstcsizMrSQE5jubd1eNiyRuBIVKk7mb85NNET6japJdw2i+emZp4/MjjO7hnUBiyg4yArHA4B6H9XPhVaaN8H/gbJ4j1XwxD4bWxtLrXtXsLW8+1WvnKmXktSHcLDOI0eONWwPNAwK8/iyvKnhI0Ybzdrd/x/zXzsztyimpV3OW0Vc+Kv2/8Axuvi74+3WhW87tbeFNPg03APy+eQZpSPfdKUP/XOuk+Cd1ZXvw58M+F9csI/G11eNPc6F8OPD0QiS+mjuHzf65N90gONqrISojjQlcbhXy94h1vUPFHiDVfFGqyeZe6tdzXtw2cgySOXY/TJNfTX7ONmLjwPo+l+IYG8MeFvEd89jLHonmNr3jq5WY/6MHQiSKyhVlWTYUThssXclOnGYeOEy6nR/lttvezvbrf/AA2fnFXksaVR1sTKff8Ar0+/Tyex92fDq18Z22jBvHt3o0upyybxBpFs0VrZw7VCW6MxLShcH5yBndgAADPolhJjH5VzenW8NpDHa20UccECrFEkYwiooCqqj0AAA9sVu2Tcg1+Uxqc9Vzsld9Fb8D7Fw5YKJn/FTT9S1H4f63NoGl21/wCINPsLm/0FZ4UlMWqRQubWSPeMLIsm3a3Y96/G3Utf8SWek+JxovxDfVdJ119Mm103U3k3GpXLRvPtMcredKsM3nq0g4ZlR2xvSv26iYkDivzr/ba+B/iqb4q6Q3h34ZaDNo2vQNoXhm08Oxpa3Juwglea6QIA21nlOchBGMllwxr7vhnGQhOVCpbXW7t01/4K7as+czWhKSVSPTQ4j4Y/FeWw8Xrq954VXU/jPqFzF4a8LaJe2jWml+FLQKscOyN8bf8AWFFUchVcs+6Ri/014Z8eeEfhd4j/AOEM0ae6+K/xl1xNut3VvKi7dnzMtxckGOys4j0hQHaMFkBIx8N+MfDd54S1bxb4Es/FPhTxxrM+nW2sax4llkzPptzbFpLi2s7maQea5ZlR2QM0gAUKpDAP+F3ivw4lqvgzxjr954H8GXNo2oa/PYQSTal4m2SbFt1kC4EZbcqoxWFNru+91yfYxmV0sXF1Yv3bbK+q3W3vcq1tFWu9W+pxUcVOi+VrX8v0v5vbofqD4b1Z9d8OarcfDfxda6/qc+pNDcalfzy3dja3BCealuEVFkjhUhUjjKqW+++7ea6rTvscfiLVWh0e7iu/LtFudQktykV3hG2LGxb5tgJDYACl8ZJzj528AfHzwHL8GrnU/EPg7/hB/h28aaT4T06HUX/tfWUXcJY4oISrgs2EG1yWLSs7gHcfTE8deEPCuoeAbbxd9u8P+I9dtI9N0rwfa3JuBamQDeXiiAUiJECNO/yIFYLzkn4rEYSrCUo8r3fZ7JPVp62tqto9Xc92lXg0nf8Ar5/0z2G3lyMZqWRiR1rzzRviFZr4ig8A6vqNrdeKE06TVNSi02B/stjAGG1pWdiYg25VQMdz4ZsKvTYvfFVvqFu8Xh7xDp0U0Fva6pLdTwtNajT2ky0gkDLGd0aSbWDkLw5BXAPJyVI+61p38u/ob80Zao0vEmi6P4l0e50DxFpNrqem3ihLm0uow8UyhgwVlPUZVTj2rxHx34G1L4fDVviBoPjDVIpr9ootV1FtPfVdSttOSRfI0zR7KJFt7dCxA3FCF+824jcvuzTpKgZCCrDcpBzkHoc/Ss+6dl6Eg+oPNTTxU8O9NY9V3++/5dr3sVLDxra7Poz5a8R/tveB/CN39g+KXw81XSJ554ri00hJILu/tYlAkjmvYnKLbSbtjJFuaQDDMF+Qt84/GL4s+Ffj42i/DP4D/C67t9E0u9Ou38NxKkEly6QxWyhcOyxosKog+ck7hwMfN9reKf2XPgZ498Rr4m8SeAbSe93yyyeRK9tHPNI255ZhCVMshPVmJ4A44r4u/ad+B3hf4Q/tBaTZ6H4Fl1Tw74vsEfT9Hg1BrYLeZMLRpIdzACQK+DniUDgdPq8jrZZVqpYeMo1LN6v3bry5tXbVX+88fMaeLpwbqtON7edvuMmT4bEsT/wzBKinOFHi5uPzalf4WXKxiQfswzonY/8ACWn/ABqrL8LbnBP/AAzZqyf9zR/itNj+GMmM/wDDN2qtx38VD+iV7ntrfb/8m/8Aup5fLfp+H/2pY/4VbcshZf2ZrgccH/hLDx+tMPwvuUXc/wCzVMQehbxZj+tRt8Nsjj9mrUlHt4pP6/LUbfDKQnC/s5aqp/7GkY/9Ap+2/v8A4/8A3UVvL8P+AWH+GEyqG/4ZskUEcH/hLv8A7KmD4aOo3N+zfP04/wCKsxj9ai/4VjcdT+znqRGO3ikf/E0h+Gc7E7P2ctVxj/oZs4/8do9t/f8Ax/8AuoW8vw/4BM/w4VCGf9mm929Tt8W5yB17GvRf+CeNlBPrPjjWYbQxwStp1vDltxRZJJXKZPXiNOfpXkeu+BE0rRb7U7v9n/VrKK2tpJGuj4iLrDhT85XZyAcHGecYr3j9i8jwf+z54u8bXKbN17fXiOeMx2tkrD8ndxXm55UcsqqxTu5OMVrfqv70v0O3LYr63Fvom/w9EfMXxJ1JtT0htVQARa34v17UlOeXQ/ZdhP4tLXnrdK6jxh5ttoHgzSnbiLR5Lph/ty3lwcn3MYh59q5YnJr6nDxUIcq2V/zPMm25XYlFFFbkBRRRQSNPWiiigBD0ptOPSm1SAK9B+AXi3wb8PvidZePvG6XM9r4dt5r+zs7eLc95ehdsEQY/LHh3Em9uAIzgE4U+fU09azrUo14SpT2krP0ZUZOElJbo9E+M/wAe/H3xy1n7Z4nvPs2k28jNp+jW7EW1oOgOCfnkxwZGyxyegwo86ooooUKWGpqlRioxWyQVak6snObu2NbrVnStV1TQdTttb0PUriw1CykEtvc28hSSJx0IYcjr+tVj1orayasyL22PY/in8ff+F0fDLSNH8aWSReL/AA7feZFfwRARahbSJtk3KOI5NyRMcDY2GwFOAfGaD1orDC4SlgqfsqCtG7duivq7eV+hpWrTry56juxp60lFFdZgxGpKVutJQIaetJQetFACNTD0pzU1qpCYlNanU09apB0EpD0paRqoTGnpTacelNqkIRulNpzU2gApp606mnrQQNbrSUrdaSrQMa1JSnrSUAgpGpaa3WrF0EooooENPWig0VQBTKfTKSAKKKKYBTTTqZQAUUUUAFFFFBLCiiigQUUUUAB6U2nHpTapAFKvSkpV6UMBaKKKkAooooAKKKKAQUUUUFhTh0ptKOtADqKKKACnDpTacOlJgLRRRTQDh0opF6UtSwFHWnUyn0DWwUDrRRUsaH0DrRRSBDqeOlMpy9KgBaVetJQOtBSH0q0lKvWgY5etOpo606pAKfTKcOlSyuo5etOHWmDrTqQIfRRRUDHDpSjrSL0paAHUUDpRQNDh0paRaWpZSHDpS01adSDqOHSikWlqRhTx0plOWkxi0q0lA4o3AfRSUtSAq+lLTelOoAKKKKCkFOB7U2lHFDGe9fADxANN8U/CXXJyFSx8RX3huSTdgCK5SPywfbfd3B/4DWr+3noMtr8VdH1xo9ser6FErP3aWGSSJh+CLF+deQeEdTntPCuuizlZbzR73TfEFr6KYZWhP5tdxn/gA9K+qf26dOtPFvwt8HfEzTE3xRXwwy8gW99AsyE+wMGPq/vXy2J/2bO8PV6TU4X/APJl+LPUo/vcBUh2tL9GfEZjLMqD5UTrjvxgCpI5ysEkMZ4nP7xh1Kg5C59MgEjkHCnqKZKGZNqcFuM+nvT0jRFCgYCjivqb6Hkrc3/BbnTZtW8SAODpemzGFlA4nmxAhB7Mpm8wd/3VN8SYtNO8OeHIAkkqWhv51jXlri5w45/2oBa/iKu6TpdzfaDo/hq0YR3XirWo/nJOEji/dQsR/dLzzg/9cx6cStc2+teP38RRqRYJd3F1boVwRa2kfmxoB6eUmz/gNYX99y7X/DT/ADLtdWEj0+0aOPS2BMOoa6lnkfdEFsoQsT3BW4BP+57Vzd5qLXcV5PJkSX139okAPCsobI/HzT/3zW0kkltFaxPcYFhpE0suOvmXG4I2T3Int+fYVy6g7pJCPvEHHYcVVNXbb/r+tAlpsew/Dv4fSa54RsdUP7P/AIw8TiZpgNT0/VGggn2ysuFQWz4242k7jkqTx0rU8TfC9tL8Narqk37MfjfS0trKaX+0LnXGeK0whxM6G0XcqnDEbhkDGR1rF8HfC+51XwxYalcfs7fEHX2ukaRdS0/UDDbXKb2CsifYJMAABfvtkqTxnAXxR8NodH8P6jqEn7OXxC0b7Nbl/t97qe+C1OQBJIv9nplQSON69RyK8ucr17KfXv5/9fF/6T8uhsl7m3T+vs/qY37PfgiT4g/GPw14YiTR5hLdiaW01ViIbuCP55oRgHLmJZMcryOCG219c/t4ePtL+Hnwv0L4F+Dwlmmrxw+ZbxuT9n0m1IWGPJJbDyIuCc5FuwPWvMf+CfvhSWPxfrHxQ1/w/Znw3othcKuv3Eqf8S28jWORtqbtwzA8pLFcYzg8GvD/AI2/E+9+MHxR1vx3c+YlveT+VYQOebezj+WGPHYhACccFix71yV6Lx+cRv8ABRSflzO9vu37r5nVTqfV8E7fFN2+S3OIAAAA6V9XfsaXcVrpl/eeGbWOPX7QSDV/FGuYOm+F9GDb2EAZgGmmYzfKSqggs2VDg/KVfQv7J9p4a8VyjwL498TXV1oja/a3Fj4Ms4DI2s6hKhAuLgLgm1gjtt77jtGRnGdr9mcxUsFPm2Wr0vp6dfR2X82lzHBtqtG2/wDX9d+2p+ingfxfo/jnw/aeKvDwujpmob3tJbm3eBpog5VZVVwG8tgu5GIG5SrYwa7Gyk6Y71y2h6ppmpxyvpN5bXMVrcSWUrQMGWOaI7XiOOAyH5SB90jHGMDpbRguCDX442o1HZNK+z3+eiPtd4q7ub1s3AziuC+Lt78M9fso/g9421B5rvxlE9rb6bZSSfbGTBJn/dZaGJSvMr4jz8p3Ala7S0Zm71X8U6Vrl9oOpJ4S1Oy0rXLi28i1v7mzFwkLZ4Lx5BkAyxCk4yQcHkH2sJOzUtn0d7WfR7Pbc4q6dmj8rv2g/Blr4R+Idp8ONM+G8Vtp/ha6is9A0b7DcveeKoZxvnvJbuEK0zEpEoVXGzeERRsevFfFOj+LvBerx+FfHAu49W8OmKKPS7txNHaRuTOYiN5EZ3S7mjCj5pH3YbIP6H/FLwB8YJNI1DwXB8Q9T8JeG9Nuxqut/ErxLrGL2/uyn3bKGGRRbW4wihcoDjABIO/89PEPgLxpoely+MNR0y+vfD9zqE1na6+IJltL+VctujklRSQwywJAJw3GVYD9IynGrEU1FyWnm3dvr5N6tx1lrrbY+WxdF05c1nr/AF/T2N7wD8Vovh3dzeLtK8LWV94yaVnsL+7iT7HpOf8AlpBaIojMwydrNlE4xHkBh0PhH9oTxL4Xv9Q8ZWs0134816T7Je+MdYLXbaVBIWBFrFgqrlVPztuwilERACW8mvEtIr+5g066a6tY5XSC4aPyzNGGIVyuTtyMHGTjOKZiu+phqNRtzje+/p29PLbuYRqTVuV7H0Ponxo8J6jptz8OYPFGpeHfB+oSjUPHXiW+DXHiDxYxPzW6KhbykfLIse8qFLNJK2WV/ZLz9pCx8W2+j6neaKLfw3bTQ23gX4Y2NyrXeu3CER21xqW35YrSNkURxHh3TOJAgZvhaKVIVmDWkUxljMamQsPLOQdy7SOeMc5GCeOmI5YYNkYhlllJTMnmxBdr56L8zbhgDn5eewxk8dXKaFWSls/8936va/RaRsawxVSCt/X9frvc/W3T/jLo2m+NPD3gjU/E0nizx/qdmlpqenaBKDpmmlSZbi8mUEiJFJVNzM8pRUwoLknc0b4y+CNevNc0eHxXpd5deELG3uPEWoWjbdMtJH3hlEzMQMGN8gk7QMElgQPx3iaaBXWG4kQSp5cgVvvrkHafUZAOPUCpTd38FlLpEOq3Bsrho55bdJXETyBcgspwCy7iuccHODjmvFq8I0qsbOo76a2W9/ytol822d9POKlN3Uf6/rqftf4P8Q6P4n0Ow8R6Ld/atO1S3S8s59jJ5sLDKuFYBgCCDyBwR6ivkL/gpNZWuoW/w9mSye7vRqV3bRQxnEkiOLcsi4BPJC9j196+fPg7+1X488FePI9c8V64L+HU5dPsdR1K7ga6uLLSoZQ0lvax7xHGrALwF4KAjB5rX+MHxB8X/tU/ECw8V6P8I/Fms+BtA8yzt7LT0ZZpWYbpGe4SGZI5GPlkqFYBEQDn5zxZfkOIyzMYVW17OKbvfumra26vy76aG+JzKnisLKLXvOyt+pXk+Fe53jT9krx8pBIwNfkOOf8Ar0qE/CmZOG/ZQ+IP461J/wDIdUP+FS5yB+yj8U//AAcHj/yl0yT4PTqcj9lf4noD66v/APeyvf5+8/8Ayb/7qeT8v6/8BNQ/C1wNrfsm/ETPqNbl/wDkKgfCafbk/sofET6nW3H/ALZVkD4QTD5v+GV/iiwHpqhP8tMpT8JZAeP2Uvij/wCDN/8A5WU+d/z/AI//AHULeX4f/amm3wquEIJ/ZR+IWB1/4nMp/X7HTX+F0mP+TUviGuf+o1J/8h1nSfCNwMj9lT4or/3FSf8A3GVCPhJKV3r+y58UAPX+1D/8rKOd/wA//k3/AN1C3l/X/gJmfELwlZ+HfC91ez/Ajxf4adnjih1HUNWaWCJy2dpQ2yBiyq4HzDHXnGK+jUx8Ov2Cgr4M2raM2f8Aa/tC8IH/AJAcfgK+VPHXg9NHudK0e0+FPinwtqmoTYhGs3wm+1DIULGv2SEj5jgnLdQMV9g/tTafZ6V4M+GvwfjbFtfazaWk8YA5sbGFY5Cf9keaGP8AumvOzX95LCYdu96nO+ukFd/al+Z24L3Y1qq6Rt85adkfF3xHVrXxW+lNL5h0mystOb/Zkhto45R/38SQ/UmuZq9r2ry+INf1PXpowkmpXk146f3WkcsR+ZNUa+rpR5IKL7Hlt3bYUUUVZLCkPSlpp60EhRRRQA1qSgnNFVsAUynN0ptCAKDxRSNTExKQ9KWkbpVIXUbSHpS0jdKaBjaKKKoljT1oopD0oENooooAaetNanHmmHrViYUw9afTKaBhSNS01utUSNbpSUrUlUA1qSlPWkoEwplOPSm0EjT1ooPWirBjT1pKD1ooQugU1utOpp61YdBKKKD0oENoooqgCmU6m0kAUUUUwA9KZTmptABRRRQAUUUUEsKKKKBBRRRQAHpTacelNqkAUq9KSlU9qGAtFFFSAUUUUAFFFFABRRRQWFKOtJSjrQA6iiigApy9KbSrQwHUUUUIBVpaRetLUsAp4plOHSgaFoooqWCHUtIvSlpAhw6U5aYvSnL1qWMdRRRSKQ+gdaQdKWgY6n0ynDpUsBacvSm0q0mUOpwptOHSpDqOHSlpFpaljFWnUwdafSAVelLSLS0AhQcGnUynikyhQeadTKcKQ2KOtOptOHSoH5hSjrSUUDH0UgOaWkgHLS00HBp1JgFOB4ptAOKQDqKKKACiiigo6f4bkz+Kk0IyBU8QW0+j4IyplnjKQZ9hOYm/4DX2N4OgPxj/AGHbvQlQzahpGlXNqsUY+YT6dILiFcerQCNMf7RFfCtvd3NjdQX9lM0U9rIs0Ui9UdTkMPcHmvuX9j3xVb6d8QPGfg9Riw1yK18ZaXbsoC+XMqmaIdjhZ44z/wBcW9K+Y4npyjh1iofFTcZr/t12f4O/yPUyuSdR0ntJOP37fivxPhlTkfTg0M2Pxrrfi94KPw4+KXijwQq4g0rUZUteck2zHfAfxiaNv+BVytusD3UAuRmHzF80f9M8/N+ma+ip1I1YKpDZq6+Z5kk4Nxe6Ottrg6Xq1xOMo3h7Q2t49nJW4mXy3GcfeSe5kcf7mfWnRW0ljZXkdqM3EWj2tkhcYJnvJFm2gdj5Typ/wH2rCtJ5NTDWk9z5dxrWpxmeUDhCM5J9Qxmz/wBs617zWEuBJqyRFft2rT6jGHOCqwJm2B9t0rp+FZuLTt/X9bl3Vv6/rsUdYvYXfW7i2RfKmnisbY+tqmSoHuPKgz9awuFXHrTUkBjEKAbI3Yj2JABH/ji1Nb2txfXdtY2ttNcTXEqQxwwqWkkZiAFQDksSQAO5NbpcuhF7nqek/DCGTSbKS+/Z++L11cSW8by3FoxSCZyoJkjU6axCNnIBZuCPmPWq/i3wDpmj+FtQ1EfA34saM8EaldQ1WYfY4CZFAaX/AIl8fBzgfOvzMvPat9/AWhEbLb4WfG8oowoYJ8oHsLWsbxl4UsbbwrqMln4F+LFnLDGr+bqu37HGBIuTKBApxjp8w+bbXmwrc1RWb37v/wCSN3H3Xp/X3Ho017afCb9hfSY9G8yDXfixqlzHfy+dkmztZ5EbYuMKpCxIR3Er89APmVFCqFHavWvi5q0mpfBn4IW6ZNtZ6Nq8Y9BMdVuN4/FFhP4ivJ60wNLkjOb3lOTf3tL7kkia0+blXRJL8L/mFe0/st+I4dC1nxRDf+KrDwrpdxpIfVddbjULexWZFkgsCAWWeZpI03KCwGWUFlXHi1ekfs6/Zz8V9NJ8A3HjLUVjkbSNKjYLE98BmKSctwIUILsTwAuTwDVZhBTws0+3l0166ffp3DDycasWv6+7X7j9GvhV4iEelaZC3h7T/BXhm+SOy8H6DcHZqM8UaPI8sibsKWQbxEAzqAzyOS4r1u1lY45r5i+HWr6nJ44utfutd0zxHrEMy2vi3xtfHy9I0uNnGND0dSQGcuyB5AcZO6Qu5WMfStqzA7WHIODX49mlL2NdNddf6vr53er3aV0faYOftKdu39f1bRbHS2LdOa1Uww61h2D8DJ6VrQufUVthJXVmKqtTyX41fDHSdWuY/HUnw51H4kazZGOHSdAvNWih0qwfa+67aOYiFf8AbkZZX+6FUDp8b+PrX4gfGzxQdON3D8TbvSJC/wDZOgs9p4M0F1XrcXzlPtbqrAnaycbgsrDKV+ifivw9oPizQrrQfEmi2+r6dcqPOsbgny7jadwRxkAqSACG+U/xAjNfHnxV1q41fUoPhne6CnirVrbaLH4T+BpTBpWmKBlX1m9jCeZj5cxARRA7flIO8/TZdiJRdkryjs30Xlrp56wXeWtjxcXT18n+L/r18kfC/j3wHpnhOGOfw74gbxTDBL9l1bV9OspBpEN4y7ltre5b/XEKrneVQNj5AyjceQr6O+K1hL4jm/4RPX9aHjPxfZWc0WmeE/A0SxeHvCqAEMzuqsrsnBcRjAKfvZyBg/N8bb13DkAgZ9znA/Q/ka+3wlV1qactX/XkvyS7X3PFqR5JWQ6iiiukzCrOkaNrfiHUI9J8PaNfapfyhjHa2Vu88zhQWbCICxwAScDoCarV0fw90i01fxE8F5oPifVkjtJJBD4ex9qRtyjecxv8mGIPHVl59VOXJFyBK7sdR4e+EWtx2ZHiv4GfFi+uixO/TLSS2jC54GJLKYk4xzkVqD4Uabt+T9nb43Ejv5i//Kqrp8C6IxJ/4Vb8bT/3wf8A21pV+H+ikEp8LPjhjviNP/kavNeIu7tv8f8A5I35LL+v8jO/4VTZEHb+zv8AGrP/AF1H/wAqqQfCO2xub9nL41t6HcMf+mqtH/hA9HXI/wCFX/G0L7qv/wAjVE3gjR84Pwz+NO3/AGlUf+21Ht/N/e//AJIOXy/r7ioPhPb4z/wzn8bB9HH/AMqqP+FUQE/8m6fGvH/XTn/01Vizav8ABu2mltp7H4jwywu0ckb6lbKyMpwVIMGQQQQRWvo+h+BfEdodQ8PeBfi/qVsHMZuLOWKWPcOo3LbEZ/GtHKcVeV19/wD8kLR6L+vwD/hVVkxO79nr40/TzV/+VdI/wps8YX9nr40e+ZFx/wCmurv/AAgmjDJPww+NIH+6n/yNUF14U8OWFrNf3vw8+MdvbWyNLNNJsRI41GWZmNvgAAE5PAqVW7N/e/8A5IfL/X9Is/AXwJput/tMeG9Es/Cmu6Ta6HcLqWo2OsyrJcwtaqZv3mIIdql0RQpTPzjk5r1H9rbxSL74pagjSM0HgnwfKnyHpe6i3lEE+vl3Mb/9sj6VZ/4J/wDhGCRvGXxJvgVR3j0a2nkOXRc+fckn2CW5J/2jXhPxa8YSeK49b8WuG3+OfE9xqERLEYsLRTHbLj0PnyL9YB6CvJt9czuS3VKCj85av/yW6O3+DgF3m2/kv+CeWrnHI5paKK+qPKCiiigkCcCm0pOaSgApD0paaxpoBKKKCcU2A1qSiimAUjdaWm0C8wprHtTqZViQU0nmnUymhBQelFI1MliU1qdTT1oASg9KKRulMBtNpx6U2qEIelNpWpKpAFNPWnGmU0SNPWiikqgGnrRRRQJiN0pppzU09KZI2iikPSqExtFFFNDewUynnpTKoTCkbpS0jUIQlFFFUwEPSm05qbSQBRRRTAa3WkpT1pKACiiigAooooICiiigAooooAD0ptKx7UlUgCiiimA6ikXpS1IBRRRSAKKKKACiiigpBSjrSUo60DHUUUUAFKOtJRQA+iiikgAdadTRTqGAU5abSr1pAh1FFFJjW4q06mr1p1SHUVadTB1p1Sxj6KB0opDQ5aWmjrTqChw6U5aYvpTh1pMB1A4NFFIfQfSr1po5pRxUDY8dadTKeOaTGFOHSm0q+lSA6nU2nDpQAU5T2ptKOtDKQ6nKe1NoHWpGh9Kp7UlFSwQ6iiikNCrTqZTgcik+4xacDTaAcGh6gPoooqQFU9qWm04HNABRRRQNMOvBr2v4K+P08Ja14B8d3M6pF4Z1WTw5qx34/wCJbeeY8bNnrgyXx9vLT2rxSur+HQ/tPU73wVIyhPFFqbG3DNgC+VhJan6tMiRZ7LK9cuMoxr0ZQntrf0as/wAGzajN05qUd/6sfRH/AAUC8Avpvibw58R7SE+Vqlq2kX7qBtFzbnMbE9cvC6qPaA18kyuwMaoB87YIPdSDn9K+/LFP+GmP2Pm05la58RaTZeUoOGl/tPT1+Uc9Gntzt+s/tXwKCrhZAQSoOMV5HDdef1V4Wr8dFuD9Fs/S23odeZ017b2sPhmlL790MjupI3Eij5mZoVI64ww3fUE/pVq4u9/kWyNkR2yrz3VnMufqGbH4VTaNYogdwGwHBPYnv+dSKmZGlZcM/OB27kfma+idtzzVckiVUBA6sSx+pre8DafFqPiuyF1Y6/c2tsWuJ/7BjD3sQUfI8eeBiQx5J6Z9cVhEgDJr0L4aLpukWtzqt/ffEXStQuT5cM3hu2Xy5bbCn5nMiE/MOgGPlBz6c9efJTb6mkFdpHfGPw/g/J8fRkdSEqjfWXh69sLqzlh+OEqzQuojmhR43bHyh1zyucZqQ+ItJbJbxr8djxyTGn/yRTP+Ek0I/f8AHXxyx6eWn/yRXjqMlqv1/wAjq0Oa8H2M/wAQfBw+Cl9iw8V6PqU2o+GUvWEQummREudNJYgRyuYYHizwXSRPvSpXnWoWGpaRfXGla1pt1p99aSGK4tbqJopYnHVXRgCrDuCMiu98UaH4G1iK+1S1ufiVfatMhZJdQ0qGQSSAADzH8/djAAzzgdjjFW/+F0+Or/RrfRfiz4K0zxxZWKLBb3OvWkqahbwj7saX0Lxz7R2WR3QYwFxXoQqSV5U1dPdbNPra+6fnbW+vQ53HWzPMOtdz8DprBfiTp9rqtz4iWxvYZ7ae08Poxv8AUVaJsWcZX7vnNtjZjgBXbkdap3WvfBm9lMsXgLxHpxP/ACztvFEDxg+yvZM/5yGuy/Z2l1OP4n6n4k+H2p2HhjTdK0qd7nXPEDLdLpFvIFiecAKiSzEyFY024YuBg4Jp4uclhptq2j3/AOBzfgn5alUUnVivP+ux9haJp50jV/Dlp4j8MWVx4phjEvhD4c6ROGsPD0OcfbbuXBQuuTuunBAYssId2zX0bp11Hcwx3FvPFNFIoZJInDo6nupHBB7GvlT4Z6ZZfElTaW13qGgeA/EV06y6hql35fiL4hXESkyF5ciRLQKrbljx8gKDaC4X6o02ytdMtYLCytIrW2to0hhgiiEaRRqAFRVGAqgAAAdAK/J86ioyjGT95dO34976au93KTk7L7DAXcW0tP6/rouytq+hspTmti3kBwc9qwbR84Gea17ZuBzXFhpWN6qM34g+KdD8H+E73WfEL6mbRlFosel201xeTSy5RI4EhBkMrE4UjGDzlcZHxR4/mbwL4YTSfFKN8HfA+qE/Y/B2gSrdeMPE7btu67nyfL3/ACBtzscsUfJxX3ewdztRmBPA5xXxb8ffGf8AYHiXU/G2m6fpnwsjvcwTeM9atTceJdUWPEZj0qwYmSCIBFAkbylIIbMfU/TZTU55+zS/H7rLXXfVKT7Jbnj42FlzN/16/wDBS7nzx8Sb680Hw2/hzxFZWvwj8H3CRzweC9KJl1/V1wPLl1F2IkAPJ3XJQDAMcLkc/OUNzeLZtpy3k62ckqTNb+YfLaRQwVyvQsA7gNjIDMO5r0LxV8T/AA/dyXei+APDt3aWOoMV1LWNWuhc65qoYkv5lywKQK46pEvOSJGmFcvN4K8VJda/b2mgXV1H4ZJOqy2bLexWSeYIw0k8G6PG8hdwO0npX6Dhabo07T0b/rzd/Vt/kfO1JKctDJopsIWZghlSP5WYM4ODhSccDqcYHbJFLXUQLWz4N1fSdE15bzW9Q12ysWhkjll0WZY7o5GVALcFSwXI9B6gVjUhGRg1MoqScX1GnZ3Pb1m8MyDMa/G91bkESxnIPf7tSKnh0g/6N8cyPZk/+Jrz7wx8Rdatrr7P4p8d+Nk05IRHCul6kwdCuAq7Wbbt28dsYFdS3xH8EEf8j98Xz9b6P/4uvKnh6kHZK/pf/I6FOLNUx6Llglt8b9o55ZOPr8tcJ4p8c6Y9tAPAvifx2sxkJmbU9RUp5eOAojA5z3J/nkReKviLq898IPCXjrxs2mtCFk/tTUm8x3Odw2odoXGB1OeenSuLVQq4FdWHw1vfqf16mc6nSJ6h8A/D/wAEfFWq6ppXxmm8bwNNHENOuvDlqlykLEsHM8ex5CeU27FP8WR92n/GDwDe/s6/F2/+HieLdSvdGjMF5u0+6NpPLbyxh0EgwwSUK2DkHOMjAYAdD+x/4W0bxn8R38L3HjLxt4V1W9jItNR8NavBZMyDl45PMIc5wD+78wnumAWH0z+0L+w3oGpeDf7e+Hn9uXuu6XBPK8JQ6hqev308sKq89zJKuFRVJIVMDLkAkkHgxOZUcJmCo15tRktraX6O/Ta3zu7WOilhqlag6lNXs9+p8fWPi7w7qKzfZJvidMLeMyzeVraOI0HVm/ccAeprF8S+M9AvdFns9D1Txv8Aapise3UdWSW3aM5DKyLGCc8d6guofit4CtNb8Ni517SbCxuvK1eOwu2NotwQE2yvCxiZuNuCTg7hwcitf4AeAIvix8ZtC8OPYL/ZZuTf6lFGGZI7OHMkiEsxOGC+WCSTl1616EoUaMJYiT92Kvv0Suc8XOpJU1u9D6q1SGX9n39jJNMIaDWdY09YNnSX7bqPzOvH8UdvlfrEK+N/iEyW2vQ+GYShi8NWkeknYMAzoWa5Pvm4knIPoRX1b+1t48W9+JGlaCxjksfAdjJ4q1JN37t7+QqtpCwHbe1uCP7tw/oa+Lnklnle4nkeSWVi7u5yzE8kknqa8nhulKVB4uqveqNzfz2XyWv/AG8d2aTSqKjDaCS+7f8AH8hKKKK+kPLbCkY9qWmk5oEFFFFACE4FNpSc0lUgCkb0pTxTKNwCiiimDEY9qSg9aKaJEJ4ptKetJVB0EJ4ptKetJVIQU09aceBTaCQplOPSm0AFNbrTqZTQCNSUHrRVCQ09aSiiqEI3SmnpSt1prVSEJSHpS01qYCUUUUEsaetNalpp600IKRulLTWqhdRKKKKaBiHpTac1NqhMKRutLTT1poAooooYDWpKD1opoAooooAaetJSnrSUAFFFFAmFFFFBIUUUUAFFFB6UANJzRRRVgFFFFACrS00dadUsAooopAFFFFABRRRQUgooooGPopB0paACiiigBw6UtIOlLSQBTh0ptKtDAWlFJRSAfRRRSY+oU+mU4dKkGLTqbSjpSYx60tNHWnVIwp9Mpw6UFCjrTqbTh0oYD6KRelLUjQq+lOpo606pY0OHSnLTFPanA4NJgh1A4NFFQMfQDzSA8UtADqKAc0UDQ4HIpaaDinVLKHA0tNBwadSBig9qWmjimucKT68ClYe2pM0UyRpM8MixSEhHKkK5HXB6HGRnFIDivr79oT4BS+Df2OvhjrosGj1Tw5K02rkgBgNTxLh8dTG6QxD/AHjXyAOlceDxlPHU3UpbJtfc/wBVr8zarRnQkoz7J/ePopFNLXUuxkKD2p1MpwOaGgFoBxRRUgOBzRTQcU6gApY5ZreWO5tpXimhcSRujFWVgcggjofekooGmfZP7LPxG/sr4qSWKSeTpfxQsxrNmqhtlvrUBf7RGoPChnW42j+6bf1FeKftWfDNfhh8Y9Si0+0MGi+IB/bGlgD5UjlY+ZCOMfu5RIgH91UP8Qrmvh9qWpT6fcaTo9wYNc0C4/4Sfw/KgG9Z4ArXEa8clookkx3Nqijlq+vvjxolh+01+zbp3xQ8M2SHWNHgfWoYYxuZFUbdQtB3+Ux+YB1IhGPv18pV/wCEnNY138FW0JeTXwP5rT5M9eH+2YR018UPeXp1X6nwPKvmqF7bgT9BzUlMVsjIpd2eByfSvqmeSW9IgsLrVLW31aa8hsWlX7VLZW6zzxxZG5kjZ0DHB4BdRnHNeyWvjTQdNsYNO0/46/Ha3srWJILeCGwVIoo1GFRVGp4VQAAAOABXP/D3V/C/hLTjd2Hxh+I/hbVL9FGoRaDo6iI7WbYvmrfxNIADnlBgk8dz0lx8TY5N2P2o/jU4PZtPfn/yq159eTqSslovJ/8AyL/M2guVXf8AX4kTfELSi+1vjx8d2QdCbZf/AJZ0/wD4T3RWOX/aA+OqqBxmyB/9ylVn+IMLKd37SvxnOOfmsH/+WtNbx/GR/wAnLfGTaOmbCT/5aVj7NPv9z/8AkDW/9XX+Zak8f6Mg+T4//Hdl9DaAD/06Ug+IGiyAgfH346tj+EWinP8A5VKgHxFtlUB/2l/jRx026e2P/TrWb4k+KF9Dok40D9oP4tahqEmFS2v43treRCcPuddRlP3d3Gw5PBwDmnGld2X5P/5AlySV7/195NL8UPDEasYvjZ8YHPq9rFz+WoH+dWPhD4BOoX1l4q8c2WoeKdU8STmXQfCEM7G41ycM2bq8cnMNor+Zl2IZ8SAEKruPYNI/Zb+Gnxj/AGYdD1D4HanY3njnTtt9rDXMwSeW5dAJrKVScW6qyjySRsYAksfMLr5j4F8V23wfS++HvxO8OeIPB91Lbzv4h1GOJ31bVrdCBDpdqzqos7d8HfKC2/HXaFWsPrUK1KpTwt+dOzT0lZdbaOz6W1eya3WnspU5RlV2aun0/r+tdn9C6DqWp2N1qviSbxxZQ3tvGun+K/iFFCPseiwAgJoPhy32lWcfKu9VPzYbDuUQfTfgaDT7HwlpFnpGkahpdmlohhtNRZmu4VYlsTlmZjKSSzZYncxzg8D5j8D6/a+KdZ0qy8HXfhPUPEGn2qSada2lwkvhzwHZMG+dFJVtR1EgNuYAYbdlkQMW+oPC2njS9DtIhq99qyyRic6heTebJdmT5vN3ABMNnIVAEUYCgACvz/Pm4qMZaO+35dPu6fyq3vS+jy1JtyW39f1+bvountGINbFrKNoGa5qPULUSSQi6h8yBkSVfMUmNnAKKwzwWBBUHkggjNW21vT7KS1gu7+2glvpGitY5ZVV53VSzLGpILkKpYhc4AJPFeFRk07HozSepu30/lWFy/wBrW02QSN9oYKwhwpPmENwQv3sHjjmvgXxvceF7Ke6+Jmh6neQ2t1L5Vx8WPG8AutQv3ClvK0DT9qLkbiFlWNFRd2GQKHP3G/ijRIpNQtptZsUl0mBbnUI2uUDWcLKzK82T+6UqjEF8cKT05rwv9orXPhhptjaeMp28P3vji+08R+E5bmwXVpmQ5kE9vbM4jCBWLeexWMfLuYgBT9HlOJdOr7NRbcrLT79dNuut0lq4s8nHUlOPNzJW/r+uvmj4N8Vf8K91Hw5pHi7w34V0W08JaHqohex1HXF/4SjxK5KNNLK0at5UQVVGEVI4zI20ysS1cR4i8UaZ4hvPE+r2Nl/wisWrS232Xw/o8TGwKIekjPLu+TYrDIfc8hI2AVhawLxtcvn1PUYb+7edpLi4gkEkckrHLlWHDDcT8wyD1BIINQ1+n06Kglrf5vun139d+1j5Zu5PcSrBfTBZbbUVEK26zqjqhAjCBlBCtkAD7y9RkjNVwMDFFGR61s3ckWikyPWpLW1vNRuorDTrSa6urhhHDBCheSRj0VVHJPsKWwyMsB3ppOe9WtY0XVvDuoy6PrlhJZX8AXzraYYliLKGCuvVGwRlWAI6ECmo9gNHKSaVc/bZLjMV99pAh8sDmPy9mS2cndv9BgYJL3V0Ir097e6itIr+SznW2mZkimMTBJGX7wVsYYjvimGvVPgx8O/2kteR9Z+DWia+unSybJrtHFvp8rKdpEjzMsEm3nKsTj0rOrVjRg5zaS83ZfeVGLk7JG1+yr43g8PeKf7JbxdceFp7qbzU1PydI8uEAKCTLqKYjP8AuNkjoOtfqn4cglt9FtoZdfutdd0Drf3Hkl7gNghgIUSPaRjG1cY9a+AP+Eb/AGifh8BqOua3+z3Fd9Wl1EeGo7iM+hPlqSfxNYnjT4wfEzWLWXTviT+2Do2nWDx4/s3wTaSXEzgDlM20UMBBHGGuMfhXx2aYB5xWVSjKKXW15N/dG/4nq4PFRwcWpJv8P1Pb/wBtr49fCLSPDE3w7uEg8VeJIpxPFpKXLmzsJwrKst4EYK5QOzLAc/MVLADGfPv2HfBemeAfhj4m+OHinbbwX8UqxzMBmPTLTLzsp6/PKgXHcwD1r5U0rwdpvxM+J+leBPhba6mINXuI7S3l1Z43nbq0txKIwFRFXc5UE7UT7zEFj9iftR6npXhnwV4T/Zy8JX4sLPULeNr+bPNnolkNzSvzkl2jeQ9dxhcc7qrGYGGDw1PKKEnzVXeTfSC1k7dO1uut7mlCu69WWNqJWgtPV7ep8p/EvxfqWvWl3rmrbk1Xx9qcmvXalm/dWUbSRWsI4Hy5M3HdUgb0rzqtTxPrg8R6/datFbfZrdysNpbg5FvbRqI4Ys99saoue+3NZdfYUKapU1FK39bfJafI8WpNzk2wo6UUhPatSBCc0UUUAFIT2oJwKbTSAKKKQnApsBGNKiPK6xRIzyOQqKoyWJ4AA7mm17z+xD8PF8f/ALQeiXN3aLcad4WRteukdNyM0JXyVPbmZouD1ANYYrEQwdCdee0U39xdOnKrNU47s8GBBGRSE9q7j45eAH+F/wAX/FXgYptg0zUZPshx961k/eQH8YnQ/U1wxOa1pVI1oRqQ1UkmvRkzi4ScZdApCcUtNJzWpG4lBOBRTSe1NAJRRRVEsRj2pKKQnFAhD1pKKKAEPSmnpSk801j2qkISkPSlpp61SDoJRRSHpVCYh5ph606m1SEFMPWnHgU2gApD0paRqCWNpp6049KbVIQUwnNPplMSCiiiqQdRp60lKaSmIKbSt0pKaAKKKQ9KGA2iiimAUUUUANPWkoooAKKKKBMKKKKCQooooAKRulLSNTQCUUUVQBRRRQAU4c02lXpSYC0UUVIBRRRQAUUUUDQUUUUFCqe1Opo606gAooooAVadTB1p9J7gFKvWkopgOoooqQHLS01etOoH0ClX0pKUdage6HUq0lFAIdT6ZTh0qAFpVpKKCkPpVPakoHFAx4606mU8cipYBTh0ptKvWkxjqdTaVT2qRjwcilpoPNOqWMUHmnUynA5FIBymlptOHNABTgeKbSg4oZQ6nKeK6TRfhd8UPEumxa14b+GvirVtPnLCK7sdFubiGQqcMFdEKnBBBweKvD4I/G3t8GvHWf8AsXLz/wCN1i6sE7OS+8pao46vTP2afhv/AMLY+OPhTwdNAZLB71bzUflyBaQZklB9mVCn1cVj/wDCj/jd/wBEY8d/+E5ef/G6+1P+CbfwO8TeGdS8VfELxt4V1LRb5xFo9hBqVjJbTiM4lncLIASpIgUEDHDDtXmZxj4YPBVKsZLmtZer0X3bnTgqPt68YPbr6I+tPi78O4viT8KvEvgKaJA2tabNbwkjhLjbugcf7sqxn8K/EeSKa3lktrmJopYXaN0YYZSDggj1r+gOSz/0fIHOODX5D/tTfs4fErR/j74vPgj4Z+J9Z0TUr3+1LW40zSLm6iH2gCV03RoQCrs67c8BRXzPCVV4edTCze6Ul8tH+n3HqZxFVFGqumn+R85Zx3p2RXbH4EfHQDP/AApPx9/4Td7/APGqQfAz45jn/hSnj3/wm73/AONV9u5w7o8K5xdHStnxH4I8b+DGt18ZeDNe0A3YZrcapps9oZgpG4p5qruxkZxWNVJqSuhjgc0tMBxTutJoBaAcUUUgHUU0HFOzmgCzpeq3+h6pZ63pU7QXunzpc28oAJSRGDKcHg8gcGvsb9kf4k2nhbx2vg23K2/hjx+p1jw9GcmOy1JMi4suVA6oyAHlljtzj97XxhXafDq9n1E/8IRDdm1v5rtNS8O3asFa21ZMbEDEjaJgix57SLbsSFQ15mbYGGPw0qc9Lrft1T+T19LrqdWDxEsNVU4/15fM639qz4OL8G/ifcLpVn5PhnxFv1HRdo+SJC37y26dYnO0DrsMbH71cD8Pz4dt9WOsaz481rwrd6c8U2n3emaX9rlMmSSwP2iExlcKQQTnPbFfdWo2+m/tpfs5i28iG08Yaa5+Rx5f2TWYkw6H+7FcL68KWXOTEa+cPgpca9qGlah4b8SftOP8M7nw1c/Yk0rUbaUjZlt2071wyyBwyEZGR6kDz8DmdSpgpQr/AMWm+We7flJJRle/pbc6MThYwrJ0/glrH/LdbEU3xRikXa37X/xSZemP7Hl6f+DKoZPiTYNwP2ufijjvnR5Rj/ypV6wLOY/Kf+Ch+jAf9eUw/lJVTVGXSrGfUJ/+ChNncLboXMVppdxLK+OyKJOT/nisY4mm9FF/+AS/+UA6cl1/Ff8AyZ5w3xPsZAFb9r/4pnAxgaPLj/05VG/xNt2G3/hrv4pEL66TNx/5Uq0fCGoftd/FXV54PhB4m8b+JNKgk8sancxCyh4OCWZpWjXHXHmZx27V5z4t+MnxuvYNU8C+LPH+pzQRzSWl9bC4VldkYq6F0JDrkEEAlWHqK9CnQc58icbq10nG6v5ez/OxjKfKubX8f/kjo/E/xf1yy0Xd4W/aa+JutagXVRa3ME1lCEzyxlF9Kc4zgbOvUivMNe8T+J/Ft2moeKvEWp6xcxp5aTX93JcOicnaC5JAyScdMk+tVLXTru7tLu/hjAt7FVaeVshVLHCpkA5Zj0HXAY9FYiFMyMqIpZmICqBkkntXo0sPCj8K172V/wAEjnlUc93+ZpeFvFHifwRrUXiHwf4gvtG1OD7lzZztE4BIypKkZU4GQeDjnNfQOk/tz+LdT0mPw38afhr4S+JGmxgBTf2aW9wG7tvRTGp91iBzzmvnW30y4uNJuNbLCK2ikSCNmU/v5W52J6kKCxPRflBwWUGnIWjZ45VKSRkhlbggg4OR9aivgsPi2nVgm112a9GtV95UK1SlpB2/L7j6IufEX7DXjaVjqngT4h+AppzukfSL6C+tlPptny+PZQPwrp9FsfhDbmGP4Wft5eJ/DiQBRFZ6vpWowRIAMBd0TiLgYHQivm5vBt5HpFrfXcxhurm3fUjDINqwWC/Ks0hPQyOQIxxn5eoljJwRaSC0S+kiHkSSGNGP8TAAtj1xuX/voVzPLozjyxqyt2dpf+lJv8S1XlF83Kvy/Jo+t4fBnj+C+trvwj+298Lb+5t9Xm16EahrohZtQkj8trl0ngcPIE4VnyV/hwalsfhB+1W/i258e6T+0f8ADzUPEF5atZtf2/jK1eRYGILRxFgvlKSo+VAo+lfImwqHIicLGAzHaQFBxgn25HPvSJE0sqQwiR5JGCIikksx4AAHUk9AKP7PmtnHVW1gtu2ltAddNdfvZ9Tt+y3+1c+gXnhdfiP4WutL1HUP7VvrY+L7R0vbrCjzJ90n74/Kv39wyM9eawvEn7IP7R2v6tc674q8U+Fr++uzme6u/F9k7OOwy02cDAAHYAAYAFfOccLyhjGHfahkOMkBfWpI7C8dJZRBIEgjEsjE7QqkgAnPqSAPqK1WHxUXeM4p/wCD/wC29DPng90/v/4B7ZL+yR41sgf7W+Jvwq0oL943fjG0GP8AvhmP6VmXPwM8I6Inm+Jf2k/hvGo6jSJb/VHP0ENrtP8A31XlR03UA8kZs7gPFKsDoQQyyNnCFTzu+Vvlxn5TxwaNQ06bS7+fT7tYxPbP5coVtwV8fMufUHIOMjI4JHNXGjiH/Eq/dFL82x88Okfx/wCGOs1nTPhHo0jRaf421/xI6jhrfR0sIWPtJJM7/nCK5y20m+8Q3f2fwv4e1K48obmjiVriXHqxRQCP+AjpVbTLW1v9Rt7O61SHT4ncB7qaOSRIx7rGjsfptOc84GTXtvirVn0fwQun3evfFbVNJVFijjgsF0HRMEgDCDzVk5wMlEJ9qqUpUbRTcpPv/wABJfkSkp6vRHh7BkLI6srISrKwwQR1BB6V0/gGOxt21HXr628Wzrp1uSyaCBCCjAqfOufm8lOQD+6cHJ6Y55VNhcKMpGzcZGdoPrjrj6V1vijWdPh8NWPhnRvGHinVLWKUyeTex/ZtPVAW5hhEsm478nedh4I29xrUV1yLr+RK7nIyPGS7IpSMklVJztHYZ711Hi3ybLStI0XT/itH4r0+BTJHZQ/bo4dOkYFnCx3MUaj5mbJQYJJPem/Dzw14m8R+JYX8NfDm+8bHTyLm60qC0u50kjBA/efZWWVVyRyGXnAz2rW+Kmm69Y3ULav8DD8O0LgJH9j1SHzTtPBN7LJnpnjHSk5xdRQ/y/4f7hpPlucMTwa7vwJpHwbu9IW6+JfxL8SWALuH0fRtDS5bAPyt50s8aKT1+63WuCNe3/A7XPidpnh7d4O+Ifw18B2sUsgOqaydOTUZznLKCYpbxlXIxtXbzgHOazxblCleLs/W3/tsvwVy6aTlr/X4o09P8M/s/XNmB4P+BPxx8YSH7slxewQJJ/wG2tZTj2yTWB491+7+G1rFa6F8ANM+Hc+oxsY7nV2lv9YQDgun2o/6PkEgOkEbdSrAjjo/HHxB1W+hlTxN+27r+uzopD2Wi2+pyQMfRRMbeJh+VeY/Bz4Xal8b/ila+ELG8uRZyySXeo37r88FkjZkmYHI3kFVA5Bd1BPOa4qEVyOviJPljq789rfPlT/8BZtLdQprV7Wt+l3+J9LfsTfDKy8F+CtX+PPjJlso7q1nisZZRj7Np0WTc3HtuKFB3xHIOj8+GfFv4jah4uudY8dX++HUfHUvlWVuzEmx0O3k2xp14MkkSgkf88JD0lr6Q/an8Y6Xa6dpf7PXhScaTpFvYxah4ie2Of7N0W3C+VbjjBd9qEKeWbyF/wCWtfEviXXpfE2t3GrvbpaxPtitbVDlLa3RQkUKnAJCIqrk8nGTyTXnZNTnj688zrL4/hXaC+Ff9vP3n6LudWOlHD044SH2d/OT3+7b/hjO6cCiimk5r6g8kUmkoooAKQnFLTSc00gEJzRRVnTNL1XW9St9H0TTLvUb+7fy7e1tIGmmmf8AuoiAsx46AVQbFbI9aaTmu0b4I/G4dfgx47H/AHLl7/8AG6Q/BH42D/mjPjv/AMJy8/8AjdZKrT/mX3oDiycAmv0e/wCCbPw5/sT4X638Q7u3xdeKr/yLdz/z52uVGPTMzyA+vlLXwza/Af4339zDZRfB7xojXEqRB5tAu441LEDLOY8KOeSeB1r9kvhZ4Bsfh94D0LwTpuDb6Jp8Nir4x5jIuHkPu77nPu1fK8XY1LCRwtN3c3r6LX87fievk1HmrOrLaP5s+BP+ClPw6fT/ABP4a+KFrARFqcDaNet2E0Pzwn6tGzD6Q18W1+v/AO2F8MJfib8EfEmg2Nk9xqVpCuqadHGm6R7mDLbEHdnjMsYA5O+vyzHwR+NoUE/BvxzyOCPDl5g/+Q624Sx8auXqjUl71NuOvbdfhp8ic5o+zxPPFaS1/wA/8zjCcCm12Z+Cnxr6n4OeOR/3Lt5/8bpP+FLfGfv8IPG46nnw9eD6/wDLOvp/b0v5l96PJs+xxpOKZSsGVijqVZDhlIwQfQikrdKxIUjHtS02gkKax7Up4ptABQeBRTWPamgEpp5pSeKSqF1EptK3pSVSAKa3WnUymSITSUHrRVANakoPJooBhTTzSnpTaCBGpKD1oq0AjdKbSt1pKAQUh6UtI1ULoNooopiEakoPWiqQBSNS009aXUBKKKKYBSMe1LTT1oASiiigAooooJYUUUUCCiiigAptOPSm1SAKKKKYBRRRQAUq9aSigB1FHWioAKKKKACiiigaCiiigoKfTKcOlAC0UUUAFOptOHSkwFooopoBw6UUi0tSwFp1Mpw6UDQtFFFSwQ4dKWmrTqQIUHinA80wHmnVLGPooHNFIaHKe1LTQcGnUFDgeKVT2pgODTqTAfRRRSGhw5pRxTVPanVDHuOpwORTFPanA80mA6lBxSUVIx9KDTQc0tADqKAc0UAmeifBr47/ABA+B+snUPCWpM+n3Ega/wBJnYm1vAOPmUEFXA6OuGGOuMg/o38D/wBoTwP8cNJ+1eHr+Wz1eBN17o1zN/pNv2LLjAlj6YdR3G4KeK/KCr+g67rXhjWbTxF4b1S503U7CQS211bSFJInHcEexIPqCQeCa+az7hnDZ1HnXuVekl18pd1+K/A9bLs1q4B8u8O3+XY/bXT3dmB3yf8AfRrs9FJ3LuJOPU5r4p/ZN/bJtfipqNl8OvH9l9k8XSK4trq2hP2bUQiF2JVR+5kCqxP8BwcbDhT9paRMG2kH0r8qnl2IynF+wxSs/wAGu68j65YqljaPtKL0OsmUfZcj0rktSBywBbjoATXSyXB+z4HpXN38yqxzXfm9SMkrdjkwcWm7mDPvzyz88feNfM37Sf7Zfhb4NrdeEfBzRa/4y2FWiEha001umbhlPzuP+eSnI/jK8A+QftR/t332r3N98P8A4H3c9lZKzW974hAMc83ZktQQGiXt5hw5527By3xUSzMzu5ZmOWYnJJ9TXuZBwc52xOZbbqHf/F/l9/Y4swztRvSwu/V/5f5m14x8beLfiH4jufFvjbXrrV9Vu+JLi4bJCjoigYCIM8KoCjsBWRTKUHFfpEYRhFRgrJdD5ltyd3uOoziiinuIcDmlpgOKcDmk0AtHSiikA4HNIwJ6Eg9j6UlKD60AfR/wQ+Nlx4K8TR/FOQu+n6i0OlePrSKIs25mPkaqqr1LEkucf6zzAcfaEFdt+3B8BotUgH7QHgWFLyGeOJtfFqQ6SRsAIr9MfeVgUVyO5R8fO5Hyh4W8Rz+FtWGopareWs0b21/ZSOVjvLVxiSJiORkchhyrBWXDKpH2t+yr8VdO0qa1+CPiq6OreGPEcEsng6/1BFdLm3k3LNpdwPu7wS6bOm4soyskJPy+Z0KuW4hZlhVdxVpL+aHVesd15f4T1cJOGJpvC1Xvs+z/AMn18/U+UdTb9nC08JQW2iWnj7WvFE9qjS3E09nYWMFwy5ZVjEc8kiq3HLpuA/h7d54d+F3w7+BGjWXjz9onTpNU8R3kS3mheAI5DFK8Z5jn1FwCYIiRxFjewByOHQbvxO+Gln+yF8X2+IFh4LTxH4cvYZ5vCMl/KzwabqeVKC5GD5zQcsqsR5gMb7gVYL87+IPEWu+MNevvFHifV7jU9W1OZp7u7uH3SSue59BwAAMAAAAAAAerSbxsFKhN+ykr819Xf7K/lS67Pou5xyXsJNVI+8tLdF5+fkegfFL9pH4rfFYiw1HWRovh6FfKs/D+jL9k0+3h6BPLT7/Hd9x64wOK80srG71C7g07T4TNc3MgiiTIG5icDkkAfUkD1plaHh7Rb/xBrEOl6fPHbtKrma5kcpFbwBT5ssjdkWPeW65GRg9D3U6VPDQ5aaUUjGUpVHeTuzY8W3EUOjW2geG1L+H9HnKXF7khNT1FlzJKOhKKF2xj+FAGIR5WDZ9nf6boOizagjxyazqheGFEA22MGcSNzx5j8qo/hQs2MtGy954g0rSddh0rwxo0DWFh9nM1mbtWzp+koTJNqdzg/wCvuCvmbRkrEsaIHV4qs6/o+hzTnwv5Mljo+gWyXWuTeVH9osbZSPKsAfum8lkIaXqPPlCEKlsTWcKsVFRa8/8Ah/V/5drjT3MfRra5v7fS72ytoopJkktfDNncPhIVTJutUmPQBNsh8w8B0YghLbZWT4f0HQ77VbnV3tZLvw5oZSBEUNFLq902RDAoHzKZWBYheUiRuSyru1PH2v6hpllPatE1prOt28KXlvHgJo+lgZttOTPKsyqjyZ+bAQMdxmBf8LNVtgP7V1CzlSx8MxZh+yhlMdzNgFo2x813MVWOIjcYwpl4+zLlXkqbmv6/r/g9UGjdjqPFGiyJZnRtcvlGtayX1XX74orwWFvD8rkInymOEAwQovDS+YE6WxrC1fw9Y3N8IH0VxDpRitlsI1PnfaJCRaaWCOWmYs8twy4O4ygBWRVbr2j1ewuvtDQQnxHf3ioIVKJajUII/liwSQtlpkIVnySpmCht8cOVz9OjsLe2GrC/ubfS7K0uJINTYbZxauwju9VIc7vtV1IPs9urcqMFiPKWWuWE3Bb/ANf1ovw1TRo9XsY914d+w2yJFPa3d88k3l3BTEUt1ED9qvtw4+y2ibo42A2tJ5jpkKyVj+HPC8Wl2cl6txLbXGqW006XE8Sk6doynbLdsvaSXmKJO+5gOZInrsNSEcn2uLXNMFvBbRWqavYQSOHgg4On+H7d/veYzJ5k7Abtys7DfC4e9ctq2mH7RJZpd+JNRv0T7PF5awXGrxoBHbqudq2enRlMgnYZyindFHlLVWVrd/6/rp8norLc4260ezSebTzpTJFbGFtRs4i/nB2z9j0lCBkzMQXlIGd/mNt3QENuW2lta3SvbwWuo6nBemG1iiCCK+17HOMkr9jsInHJ/d78c+VKdlTxDrFj4M8MwX+m3kl1O5ng0O5d28y6uXLJe6038WCymC33EHEbP8skZLcrbeLrKy0mGyndopL21NizWjZax0zO54Y+MGa4YsXcjAViPuyuq3yzqRutv6/r8N0mK6Tsdlp2n2/mW0+jX6slsLlNK1CdGO50P/Ew12U/e2JtKwg/MWWPGZInDeWR6c3iTxCdI8G6RdyrcSCKyt9u6ZkAADPt4BIG5iPlGTjCgY1fEXjqTVNLl06whjg/tIRR3G1yEhtIiPs1lGW6RptWRyeXk2s3Kb21NL8I/CCxsFu/GfxUv5rv+PTvDmgtdsg6gGe4lgQH1KCQehNaxTpJynfXyb/L+vvFbm0R1XhnSPGnwx02QJ8afBHg2WUlbg2N6t7qnUnb5thFPImM/dMigd8GvNvGmrSaxrJuZ/G+reKnVSrX+pK4kY8fdZ5HZl922n2q/wCIH+GqWU03gvwl4nmiJ8pdT1m/jZVfp/qool2njgGVq5IkEdQPqcD86KNJ8zqS+J+SX+b+9jm7LlW3qzovAgtLfVxqtz4w0/QjaMNj3WnyXjtkNzHGInTcPVimCRg5qt4y8Rar4o8QXF/qPinU/ECxEw217qIKytCCSoCF38teSQgYgZPSus07VtU8A+HnOj+N/CFtqIiysFpp4vL+Te43D7X5Dom1SeEnAwvQnFcBYafe6leW2laXZy3N5eSpBBBEpZ5JGICqoHJJJAwKuCUpuo/Rf1ZP8WiXorHYfDvR/htfxS3Pi/4yah4LvUlKxpa6C9/vQAEMXSaMqckjGD93Oeaz/HVj4Is9RDeEviNqni52/wBddXei/YVx2wTcSOfxUfWvovwv8Kv2m9N8P2emWv7I3w71aKzgWH7XqOl2k11JgY3yP9pVy56knHPavHvjNoXxB0u5EPjjwN4L8JFSGXT9IWwSbORztjd7jH1O31rioYuFbEWjNPyUoP8ABLm/E2nScIXa/B/8MeY12Xw2bw3Lcvp938I9T8fa3cMTa2UF/PHCqADrBbp50jZ3ZKyqMY4PWuNPSt3Rtf8AH2h+G7//AIRvWtX03RXmUXz2c7wRSyMAFSRlI8zgZCHOBuYD7xr0KkXOLit/Vr8VqYJ2dzofiZqOvR3UXgu++DOi+CLuTypEsbbTblL1gxOwMbqSSYZ9ARnjjBxX1/8ADXwxoP7HfwC1Lxp4xgRvE+qRxzX0DuAz3RB+zacpGeFOWkIzgiQ5IjWuA/Y2+ALxxx/H74iRrFDB5lxoMd4dqgJnfqEueAqYbYW/iVpP4FLcv8bPjkfG/iBfiGqS/wDCPaDNLZ+CtPnQBb6+H+s1KaNhykfyEKwwW8lMECevlMfN5nXWV0NacLOo1fV9IJ679ey9D18OlhKX1ufxP4V2/vf5HlnxL8Ta3G2oaVrt48/ifxHdLqviqclgySHLQWIH8IjDbnXoHKIQDbivPCQKJri5up5Lq7uJZ55nMkssjl3kcnJZmPJJPUnmm19VSpKlHlX9f1svI8icnN3YE5ooorQkKQnFBOKaTmmkAE5ooop7AFIHdHWSJ2R0IZXU4KkdCDQT2ptCA+y/2bP269R0d7PwN8b9QubuwwsFp4jLM88HZVuhyZUxx5gzIP4t+fl+89MvrbUrSDUNP1BLu1uolmgnhmEkcsbDKujKSGUjoQcGvxBIyCCM5r3T9m/9rPxh8BruPQ79Ztc8GSSl59NaT95alj80lqzcI3cofkY5zgnePhs/4Qhi74nALln1jsn6dn+D8j38uzqVG1LEax6Pqv8ANH6zWSuSAXYj3Y10+nqPJx7V594C8a6B498L6X4w8MXUlxpmrQC4tpJImiZkyRyrcgggg9enBIwT3tlKBFx6V8LgV7Kq4VFZrR+p72IfPFSjszE8RDGQBXC6gkm4kO//AH0a7jXpN2a8E/aB+PfhT4D+GYta16yu7+91BpIdNsbdSv2iVQCd8hBWNRuUk8tg/Kp7cU8PVxuK9hh480pPRI6YVYUKPtKrskbXinxX4e8EaHdeJvFuuQ6XplmMy3M8hCgnoqgcu56BFBY9hXwF+0R+2B4n+Kn2rwl4Jku9E8INmOX94RdakvfziDhYz/zyHH94txt8x+Lfxp8efGnXTrPjDUiLaFj9i0yDK2tmp7ImeWPd2yx7nAAHCV+o8PcIUcstiMXadX8I+nd+f3dz5TM87ni70qPuw/F/8AaBilooJwK+1Pn2Ix7UlFITgUAIT2pKKKAA8UylY9qaTVIQhOTRRTWPamAh5oooqxCMe1NJwKU800mmhCUhPFLTSeaYCUUUUEsax7UhOBRSMe1NCEpKWkbpVCY2iiimgYU0nJpx6UyqBhQelFI1CEJRRRVAFMpx6U2kgCiiimAU09adTKACiiigAooooJYUUUUCCiiigBGpKDyaKtAFFFFABRRRQAUUUUAKvpS0i9aWpYBRRRSAKKKKACiiigoKVT2pKWgY6iiigApR1pKKAH0UUUkADinU2nDpQwClB5pKKQD6KKKTH1AcU+mU4HipBi04HNNpVPakxj1PalplPqQCnA5FNpQcUFjqcDkU2gHBoAkU9qWmU8c1IBTgc02lBpModTutNpQe1SGw8HNLTQcU6pYwBxT6ZSg9qQDgcU6m0oOKAFpQcUlIx2qTjPtQNM+wf+CdPgo3fjLxF8RbmFvL0u0TS7RyPlM053SEe6xxkfSUV+kmiXAwpzXyz+yD4Em8DfBbw9bSQbLzWYzrNyAhDFrjBjBHXIhWEfXNYf7QX7c2g/C6O58IfDFrPxB4qTdFNdbhJY6c3QgkHE0oPGwHapzuJIKV+M5msVn+eVI4WPNyvlXZJaXb6K93+R9xhVSy7L4yrO19fm/+Afcct4ohwGBOASPTPT88HH0NctrNxIQxQ4I6exr8cvC/7S/xv8J/EW6+Kdj48v7vXtRKjUTet5sF9Ep4ili4UxjkKoA2A/Js4I/RD4D/ALWvgT4+6cumxgaJ4tijzcaNPJnzsDLPbOf9avBJX769wR8x24h4dxuApKt8cEtWunqu3n99jPLMyoYifI9H0v1/4Pkfn/8AtV+CT4C+PfirT4bcxWepXX9r2YPQx3I8049ldnT/AIBXlA6V9q/8FF/BW+Hwp8SraFcxvLol4wHJBzNBk+n/AB8fpXxQDX6Fw/jfr+WUaz3tZ+q0f32ufOZlh/q2LnBbXuvR6jqKKK9k4hQcU6mUoOKTQDqKAc0UXAcD60tMpQcUNAOopM5pakABxXUeDvElnaxSeFvEV9cW2i3twtzFdwqzyaVerwl3Go5IxhZFXl0Ax86RsvL0nXg1M4qasxp2d0fo98J/HmhftDeB9U+A3xvgt7rxHa2iG4lhkQjVbbaDBqlpJjaZQrK+4AqwbdgpI6r8R/G/4JeK/gP40k8KeIV+02VwGn0nVY0Ig1C2zgOuc7XH3XjJyjAjkFWav4C8a3Vpc6ZZS+IZtD1TRpvP8N68pwdOmLFjBMcHdbOzNkEHYzM2CryrJ90+E/Engb9rn4fal8KvirpK6T4w0dfMv7KIKJrScABdQsSSQ0TAruUErhgpJUxyV8pL2nD1d1Iq+Hk/eS+w/wCZf3e66fdf1ly5lTUX/EWz/m8n59u5+b9anhbUtM0zUZZtcWe508IsstjH8ovnRg0cEjjlYi+0vggkJxhgjDp/jP8ABjxl8DfFh8MeLIBLb3AaXTNThU/Z9QgBxvQnowyAyH5kbgjkE8NBBPdXEVpaxNJNO6xxooyWYnAA9ySK+phOFempwd4vZo8qUZU5cslZo6zSPiPr7aveamkL3Gu6rdCdZlxh5wR5C7MYEcTfOkQATekOQREqVsw6tpOg6Cl5KsN9b6bc+fAJHLjWtbI5nfP37e2VvlUjDFuQBPIE86ggE0U9zHdwxm3jDFWm2tKGIQqgHLcOSR02g5pHuJrmOFZpWdbePy4xgYRNxOAB0+ZmJ92JPJOSVGL0WgKT6ksFtrHibWRFG0t5qWpzlmkkfLSSMcs7ux9SSWY46kkcmvUNC1fSdNSHTvD+qKlh4f8ANmj1A8bJiQtxqhXgtJykNqhwQxRjsfJfyqG5ntmdredozIhjdlOCUbqM+hHB9QSOhIMkE2otapo9rE+y6nWZI40O6ZxlU6ctglwB2LN606lP2it0/r9Ai7M9TXXtONrcteW32CyFtDa3NtFNsaCwBZ7fSYnxkSzyfvbiTGR87EbvNjazH4n8x4NWSKzklW5V9PVUVLa71NIti3DBuFsrGIhYlPy5AJ+VplTyC8hu7a6nstQWZJ4JnWWOQnKy5w+Qe+VGfXAqTzNa1Td9mFzMthabW8pTtht1OCSF4Vdzck8Fnycs2Tj9Vi+v9f1/V9R8569p+pafpyWd7b608UcImn06+uA3mqSdt5rkiH5jKzAQ2yMd25U5DxhnradqGm6pfpZy+To9veWQs41WUA6VoXLCBWPyi4utzM8hGNjyOQVlcL5LdXt5fbnurp28xI4yM4XYi7UUAYAAXAAA4FMmle5uGuLmYzTSEszucsxJ5OTz3prDeev9f1/w7Hz+R2XxV8cWvjPxAkGixLDomlxra2CJEYw6Kqrv2nlRhVVVPKoqA5YMzcZgIpXCkEg52gkYz09P/rVI8YjYYdHyitlM4GVBwc9xnB9wa7j4e+Ar7UpbXxTfeOvC3g6ztZBNBd61cb3kZTjdFaxpLM+COG8vbkDDAjjRcmHppLRIn42bvwp+DPxK1qFvFNr8ANc8W2TRh7Oa8W4tdLbPId5E8syj0CzIPXdkAdP4g8SfFPwi8kE2k/CP4eSwL86afZaXdXWMcA7Bc3an68+9ZXi1vhNqTi58c/tLeNvH8ucGGy0KZtuP+m1/cRkL6YjP0rzrXNT+H0e+38HeEtT25+W71rUhcSgY6qkMcSqc9m8wVwxjLFT5qiuvOL0/8CaX/kpvdU1ZP8V+n+ZQ8U+JPEHibU5LjXPE97rXlkiKa4ld1x32Bvur6DA+g6Uzwpp0eqa5FYP4e1bXTKD5Vhpcmy4mfIwFPlycYzkBSenI60zw54a1nxTqP9j6DaLcXHltK/mTpCiRjGXeSQhEUZGWYgc16pBrGveAfBc/hyf9om10dfJLxaL4PBuJblzn5bm4tzFA46ZYzysB/CcAHrqVFSShC1+2v36J/p6mMVzO7/r7zz3xyY7bVv7E/wCFeR+ELjTS0c9o5uvtRdgp/fidzhgB0VIx8xyPSl4Vt/B9zrccXjy/1i00hVLSSaTYxXVwx4woWWWJRnn5txxj7pzxlDe5aWVmZ3JZmJyWJ6k17B+z3pfxu1GfUH+Dfw80bXnhcG5u9T0ewuFgJAGxZrxdiEjB2BgT1xSrz9hQcrpWW7dvxd7fO44Lnmlb8P0Cax/Y2hizDrnxjkkIyyDSNNGfbP2iuK8Tn4Xy77b4baD4umKxl2udZu4W8tV5ZhBFGMYHfzCB6V9fWvgf9ua5gMtz4T+FumqBybjTvDg2e/CNXi3xv074q2elzw/FL49+Cpo41OPD/h+/jd5X5Kq1tZQrbryPvSFcY4JPB8vCY1TqqPtFL0nzfgoL8WdFWk1Fvlt8rfmzwDPHWvfP2V/2aL/4x6wni7xXDND4I0i4+dRlW1S4GCbeIjkLwvmOOQMAfMykUv2ZP2ZNb+OWqDxBriXGneCbCbbdXajbJfOME29vkctgjc/IQHJySqt9I/Hb402XhXTZfgX8G7qy0FdHsjFrurwZFt4bsAdrRRlcs1yxbbxl977RumfKY5vmlVVP7PwD/evd9ILu/Psv+AbYPCR5frOI+BbL+Z9l5dzmv2m/jXpviX+0PhX4Y1X+zvCHh5Y4/Feo6aqrv28Q6VaY+XcTHtwPl/dnP7uGTPxr4l8Q3XifVTqM0CWtvCi29jZxEmKztk4SFM84GSSTyzFmYlmYm74q8TWmrR2ugeHLOWw8N6WzGztpCPNnkYAPdTleGlfavAyEUKikhQTgV35Xl1PLqKpwWvnu292/N/holtrz4vFSxU+aX9eS8l/wQoopK9M5RaQnFIT6UlUkAUUUUXAKaT6UE5pKLAFFFFMAqaw0+71jUbTR9Oi826vp47aCMfxyOwVV/EkD8agJzxXun7FXgJvG/wAeNMvZIBJaeGYZNYm3LlfMTCwj6+a8bD/dNc2NxMcFhqmJltFN/caUKTr1Y01u3Y/S74caRb+DvCeieEbI/wCj6LYW+nxn1EUYTP4kE/jXokOpwW1q1xc3EcMUYBaSRwqqCQOSeByQPqRXjvxJ+Jvgj4I+F/8AhKPHmsrZwHKWttGN9zeSD+CGPILHpljhVzlmFfnB+0L+1V8Qfj3dS6VNPJo3hGOQNb6JbyErJtOVkuG48584IyAq8bVByT+Q5DkmOzqq6z92DbvJ9X1t3f4eZ9pmONw+Bgqa1l0X+fY/WzWbzDMrZBBwQeoPp9a+W/23PBy+Nfghqt3BHuu/Dc0esw84+RMpN+HlSM3/AAAV89fs/wD7c/ibwdHbeDvi9Nd69oKbYrfVR+8vrFegDkn9/GPQneBnBPCV9mf2h4b+IHho3OnajaatoOt2skP2i3fzIpoJFKOPYgMQVOCDwQDUYnLsbw1mFPE1leKkmpLZrqvJ26MqhXoZrhpUoPVrVPdf0z8hN24Citbxf4avvBfizWPCOpA/adHvprKQkY3GNyu4exxkexrJr9thKM4qUdmfBSTi3F7hTSc0pPakqiQppOaUntTaACgnFFNJzTQCU0nNKT2pKoW4Uw80rHtSVSAKRjS00nNMkQnFNpWNJVAITim0pPakoAKRj2paaTmgkSm0rHtSVSEFNPWlJwKbTEgoooqkG7Gse1JSnmkpiCmnrTj0ptNAFFFFDAa1JQetFNAFFFFACMe1NpT1pKACiiigAooooICiiigApGpaRqaASiiiqAKKKKACiiigAooooAB1p1Np1SwCiiikAUUUUAFFFFBSCiiigY4dKWmqe1OoAKKKKAHL0paaOtOpbMApQaSimA6iiipAcp7UtNBxTqB7oKUHBpKKhj3H0UgORS0CQ6nKe1MU9qdUjHUUUUikOByKWmg4p1AxwORSg9qYDg06kwH0UgOaWkNDgc0tMBxT6loe44HNOB7VGDinUgQ+ikBzS1AxwOaWmdKd1oAcD2rb8E6Ro+u+MtF0nxFq1vpmk3N7Et/eXEmxILYMDK+RzkIGwACScAAkisOl6jmlJOUWk7DTs7n07+0L+2Xq3juGfwP8JkuvD3hVQbeW7B8u7v4gNoTj/Uw4A+QHcwxuOCUHzInAxSUVx4HL8PltH2OGjZfi33b6s6MRiauKnz1Xd/l6D6ktbq7sLuG/sLqa1uraRZYZ4XKSRupyrKw5BBAII6Hmogc0tdfkzFM+lR+04/xd+D2u/Cb4xXCDVzai50fX9oAuLmA+YkVyOiu4VkEo4O/5x1evmwZxzTQcU7rXHhMDQwPNHDrljJ3t0T627Xttsb18RUxFnUd2la/W3mKDinU2gHFdTVjH0HUUUUgTFBxSgg02ilYY+ikB9aWi9gClDetJRRuA+imA4p2RSsAEAjB6Gu88EfEC/sbzSVm8QT6JrGiuP7B8RxZMlh1/cTgAmW2OSMYYoGbCupaJ+EpCARg1nUpxqx5ZFRk4u6P0j8D/ABF8AftO+Fpvgx8bPDtpZ+J1iFw1isqhbhtny6hpc4LDJQ7sKWBQn/Wxk4+P/wBoP9l7xv8AAu+fUDu17whcSBbPWoIiBGT0huU58qX0ySrdUZsELwvhvxp9htLbQ/EBvpdPs5vtGnXllJsv9Im3bvMtnyPl3fMYiQpOSDG58wfa/wAJ/wBqexv9Lj8E/HibS7/SdYiNlZ+K/JV9L1aMgbre/jYYhlwRuDqB/EyqNsjfMSo4nIZueEjz0Xq4dV5w/WO/ruvUU6WYK1Z8s+ku/lL/ADPgq4lsBf8Anw6TOlncRt9mglmYs3ysgk3qF3YdSTgAZVhgdBNEdTtdJ1jRrq+jsIraaOW4spk2TTzo5jCfd3ZQSSHaxCgBv4iAfsT43/sLX1ndp4+/Z3nk3wsl5HoDXOZI2B3rJZTsfnGcMqMd/wDdaTIA+N7yI6N4lurPVtDvZJYJZoWs79XhuBLhlUyKDuVlbaxXPUFc969/BY/DZlT9phpcy/FeTXQ8+vh6uGly1VZlZ/sLWkIgac3Pz/aN4XywONgTHJ6NkkjOQABty1nUZLqa207UbrXBdXJQwJDuYyWkMQVY8kjAB+bAByNuSBuBMN3DeaRJeeHtQsrdLmC6Hnv8ryRum9TGrgkAfMcgHkqufujC6faXOoyS2VrbwtIY3uGkkfYY0ijdnG4sF5A6HklVC8nDdmm5iMsp5LO9tbmG2ineCZJFhliEkchUghWQ5DKcYKnggkVYvIb/AE/Wr2w1t5YJftDQ6ikBRjxIC64VgjEMucZAyo5FUtkT2ckxnj3rIqCAhizghiWHG3AKgEEg/OMAjOLRgS40hLjTtMvGazydSuid0Kl2xEoAXCDC9ySxLf3aNgI4LiCF7gmwiuBJE0cXnM37onHzjaVywGcZyOc4poknFsLP7RJ5AcyiPcdu8gAnHTOAKdd31zqE63F5IHcRxwrhAoCIgRRhQBwFHOOepySSbGgw6XdatBb6tDqM9qxJaPT1UzS4H3FLcLn+9hsddp6UN2VwKXmJkgMCfQVGfLH3lJA55HH619IeFbjxUtrHY/C39h21vSQC17rmjahrjsR/EXbZAv4RqPak17xf8etKmks/Eni3wN8LrYBfMtdLg0+0uYlJ6CLT43vFPX74A9xya4PrrcuWKXzkr/dHmNvYpK7b+7/Ox4jZeCfENxaf2neWR0rTANxv9QDQwEcnCEjMrcH5Iwzf7NYJdQWAOQDhSe9bXjrV7DWNcNxY+INb11UjCSalq7/v7px1YLuYonoC7HqSRu2r6D8G/g78XdRa3+JGkfC3SdT0CLzFS/8AFvl2+jk4KmQtcSxRzbeeMuuRypIxXROsqNL2lVpeuny1/ryIUXOXLEwvAOi+AdVWCGTwr458YeIpDu/sjSFjtYguenmKs8sgxycRxntnjJrfE6VrHUE8Kf8ACvtA8JrZN9oNrZTG7ugzDG24uHkkkDAZzHlAMgmMHGPS/HvjfVrPTpdK8YftAWF3A2QfDnw9tlisnQggJLNCkNttzxkCcj0PWvn7jJKhguTtDHJA7ZIxn8hWOGc60vay/wDbvwukvw+ZdRKC5V+n/B/MkJwM16hpHgP9muW2im8Q/H3V0umVTJBZeC5JVjbHKiRrhd3PGdory+2t7q+u4bG0iMs9w6xxxj+JmOAPzNe56T4x8a6FrGleANF/Z5+FOra1eBY7W1t9Ij1m6kOB99xcSuGxyQxBABJGBVYt1FFKk2n5OK/9KT/AVJRv736/pYxNZ8M/sk6Rp7z2HxE8f67eqMxW0Gg29mrt2BkkmYqM9wrH2Ndz+zT+xrrPxTktPHvxBhvNJ8GO4ms7NmIvdXjz8oQ4GyE8Zlx8w4jBJLJ7Z8NP2TdB0C5uPjJ+0jJ4fl1G3i+1to8ENvbaLpMY5HniMLFIV6bF/d5zkyk4HNfHD9qu+8c2FzpngnV7rwz4CO+3vfEZi26hrLLw1tp8TFWC4wCx24BAdogQj/PVc0r4hvC5dNyl9qo9Yx8o2S5n2sv+B6McHTpJVsUrLpFbv1vsjrPjH+0LYaFZ3Xwi+BV3pmjw6BbCDWfEUI26d4ctgSvk2+zPmXBOVG3c28kLvlJZPh3xZ4stdTgTw94cgubXQbebzz9oINzqNxgg3V0QSC5BYKgJWNWKqWLSSSReJfFz6zaQ+H9H08aP4cspWltdNSTeXkIwZ7iTAM0xHBcgAD5UVFwgwK9bLMqp5fDTWT1berb7t9/wXTq3yYrFzxMtdEtl0S7L+tQopMimk5r1rHIOLelNzmiinsAUUUhPpRfsApIFNJzSUUJAFFFFMLhSE9qCaSgXqIa+j/2d/jz4S/Zx+F3iLxBaWMWueO/FN6lvZWBciGztLdSVmuGHIDSSviNSGbylJKAgn5xppOawxmDpY6l7CtrF2uu9nez8jSjWnQn7SGjR0HxA+IfjL4peJ7nxf461ufU9SuDjc5wkSD7scaD5UQdlUAde5Nc9RSE4rohCNOKhBWS2SM5Scm23dgx4rv8A4O/HPx18E9Wa78M3YuNLunVr/Sbgk210BxnHVJAOA64I4HIyp8+oqa+HpYmm6NaKlF7pjp1Z0ZKcHZo9P/aG8X+D/iN43g+I/g9pIRr9lE2p2M4xNaXsQEbhuMMrIsbB14Ys2QCCB5gTignFNow1COFoxoQ2irK/ZbfcKtVdao6kt3qFITilphOa2MwoooJxQAhPamk4oppOatCYUhOKWmk5poNhKKKCcVQmIx7U0nFFNJzTQgpCcUtNJpgJRRRQJiE02lJyaaTTJEJzRRSHiqBiE0lFFAbBSE8UtNJyasXQSiiigQjHtSUGiqQBSHpS01qW7ASiiimAUUUjHtQA2iiigAooooEwooooJCiiigApG60tNPWmgCiiiqAKKKKACiiigAooooAKUGkoHWkwHUUUVIBRRRQAUUUUDQUUUUFCjinUynA8UALRRRQAU4dKbSrSYDqKKKaAVT2paaODTqTAKcDTaUHBpAh1FFFJj2FB5p1MpwORUgxadTaVT2pMY9T2paZTwc1IBTgabR0oLH0oPam0tADwcU6mA5pwPapaAWlB7UlFIY+lB7U0HNLUj8x/SnVGDmnA4pNAOpQcUlFSMfR0poNOoAcDmimg4p3WgApwOabRQUPoBxSA5pakY4HNLTKcDmgBQcU4HNNoqWg3HUUgPrS0h37hSgkUlFAxwOaWmZFKCaVgHUUgOaWi4BnFLupKKYDsitPQfEmqeHGnWyMU9pehVvbG5TzLa7VTlVkTvgkkMCGUklSp5rKpQSKmUVJWY07ao+mPgZ+0b4t8CNDpvge7bWNIZmaXwTrNyTJHk/8AMNuiPfiI/MemyY5evo2//wCGa/2zdNey1S0a08XWcZheOQLZ69YlOChyCLmNSSMEOFyR+7NfmwQD1FdhYfEW7mkth4ugn1c2mwW2pRTmDVLTb93y7kAlgvZZA4UDCBOteDjMkU6n1nCydOp/Mt36raS9bPzZ30Mc4x9lWXNHs/07HrvxK/Ye+Lvw+uG1vwRaxeO9JtWEyiyt83iqpBxLZtuZx2Pl+auM5Ir53uLZbSeKC8m8lixW5QREPbMrsrIysFG4bQcA4wwGQQQPr/4W/tcfEjSfs2nf2lB8StNTAFtc4sfEEIHYfeW5YAHAUyueMlK9iu/Gn7JH7TTf2f47tdPg8SHbC8GuIdK1iGQdI/tIIEpHPyl5B/s9q5oZxjsB7mY0eZL7cNf/AAKO69duxpLBUMRrhp2f8sv0ezPzluHitNTuDpEUyWc/mx2xvoY2ka3fcoLZBUNtP3l6N0PGarzia2eawS78yFZssYnYxSsm4K4yBnhmwSAcMeBk19r+O/8AgnJYu8l38NPiJLab13RWWv2+5WPbFzApyPfyR9a8M8U/scftG+FhMw+HNzrdrD/y86HKl+rj1EcJaUf8CQH2r1sJnOAxq/cVU32ej+56nJWwWIw7/eQa/L7zj/hd8IfiL8VtSI8F+B7zXLOwdWvpjIttZwr12y3MhWOPI7FgxGdvIyPorT9J+N/gSNNK079oL4IfC+0jjCPZ6ZrFolzwOrPBFLcSt7vIx968H0/w/bafY2vh742+J/HXhbTrSRjBpEWgNMFJOSypPPCqOTySAT61uSv+xro6eZDY/F7xNcKuRFcyafp1sx9yonkH4VljYyrT5Grrsoc34yfL+GncKLUVdaP1t+WpqfETxbpd80lv49/ax8XePdx2zWGkW15JbP7CS8kiUD3SJx7Vxm59C8IN448IfDSTTdKadrC217Xbj7ZNJMSTttQUjhLqFJLLEzR8fOrFSbdn8RfB9xqI0/4c/CLwd4aDjnUNfu5NVkhx0f8A0k+Rx6C3Legrn/i54ku/E2u2kl58QL/xfPa2ccct7JHJHaRyHJMNnE6qyQqNoGUTLBiEUYJ1w9KUWqbTS87flBKP3t+jFUkmnK9/T/N6/gZPgnQPD/ibX4dL8S+M7PwvpuxpbjUrm2luRGqj7qRRKWdycALwPVh1r2+w8P8AwP1FbfS/A/hf4sfGnUbGNYIshtO02BemFSNZbhVHoWQe461yPwt+I8HhnS4NN+Hf7PWkeJvFIwZ9V1i2l1mTfkkGC1AWOHAOBlXbjlm4A9Mu/hp+3l8dIY7HxJb6xouhXAIFrfzRaLYRoextB5e4fSJjWeMnU5+acuSC7yS+eiv/AOTL0HRUbWiuZ+Sv+en4M8a+Juu65pu7wivhrwp4Xt3H+kaboeyeZQj5RLi6Lyyu2Rko0pwQCUU4rgLWGe9uI7Gxt5bm4mYRxwwoXd2PAUAdSewr7e8C/wDBN/SLRF1L4ofEOe9Eah5rTQ4vKiQjkhrqcfdxx/qh9a721+JX7KX7OMn9h/DHRrXVPEbgwpbeGYDqWozN3RrxidvfKq/rhO1cLz/DQXscFF1Zr+VO3q5P89TqWXVX79dqC83r9x8+/CD9gv4k+NXttX+JEj+DNGk2v9nkTfqc6nBwsGR5ORkZlKkH+BulfR9z4s/Z8/ZMtD4I+HHhxtY8Y36eQdL0s/bNXvXAzturjafKX+LywBxkiLvXhHxb/at+I+vibTNX8Qx+ANKkyraN4flF3rU6nGVmuAQtv1ORlHH/ADzevnTVPiDeSafcaF4W05PD+lXa7LtIZTLd3y9xc3JAaQE8lAEizz5YPNYrBZhmzvjpctP+SL0/7el19Fp5ov2+HwmmHV5fzP8ARdPnr6nrXxo+O/iHxnqBb4j6taaxJbys9n4R0i5YaRYNj5Wu5kObqUf3Uc85/eJ80R8L1vXdW8R3w1HWrw3EyRrDEoRUjhiXO2KONQFjRcnCqAoycAVmgYGAadX0OGwdLCQUKasl/Wn9XfVs82pVnVk5Td2LupMk0UV1GYUUUE4pXAKQnFISaSiwCkk0lFFMAoopCcUCuKTimk5ooppBsFJ0oJxTSc0xCk5pKKQnFMLgTim0UVSQgooppOaCQJzRRTSe1AATmkoooAKaTmgmkJxVJAIT2pKKQnFMXmBPam0UVSF5hTSc0pOKbTQgJxTaCc0VQCE4ptBOaKACkJ7UtNPNBAlNJzSk9qSqQBTWPalJxTaYtwoooqkDEJxTaUnmkpiYUhNLTScmhAFFFFUwCmU5ulNpIAooopgFNPWlJwKbQAUUUUAFFFFBLCiiigQUUUUABOBTaVutJVIAooopgFFFFABRRRQAUUUUAFFFFADqKB0oqACiiigAooooAKKKKCwpR1pKKAH0UA5ooAKKKKAH0UgPalpLRgFKp7UlAOKbAdRRRUgOB4paaDinUD3QUoODSUVDHuPopAaWgSHA5pQcUwHFOqWMfRSA5paQ0xQe1OplOBzQUKDinU2lB7UASA5opoOKdUgHSnU2lBxSaKHU4HNNoBxUhsSA9qWmdacD2NJoYtKD2NJRUgPoBxTQexp1ADutFNBxTgc0AFOB9abRQVcfRTQadUjFB9adTKUHFAbjqASKTOaWk0FxwINBIHU02p7DT77WdRtNI06Az3d9cR20ES9ZJHbaqj6kgfjU7bj9DR1zwnr3hvT9B1XWLIw23iSwbU9Oc/8ALWBbia3J+u+3k49Cp71k198/t7fBWHwx8Bfhxf6NAXj+HscXh2eVR96CWJf3jeuZ4mP1nPrXwNXDl2OhmND20O7X3PT8LM3xFCWGnyT30ClyaSiu4xHAilplFKwD6KbuNKCKNQFoooouA0ruGCPaumT4g+IZ7eOy8RLa+I7WJDHHHqsZlkjXjCpOpWdAMcKkir7VzdFKUYz3Q02tj17wP8cdV8HhYvBnj7xf4MQEAWRlXVdMAx2hk2+WM/7MrY7+nuHhT9tf4n2/lLqdn8P/ABeu4Ir21+2j3J7ZIuNikn/Zj/xr4xppUE9OfbivLxeSYLGu9amm+7Wv3q0vxOujjq9BWhJr+u234H6TW/7alvJaiDxX8GfiFbQuMO9tAmpWePZyVVh9Aax7v9pb9jLV3P8Awlfg3So52+8uqeBbd5M+hKxsa/Pa0ubuwl+0WF5PbS4xvikKtj0yOa3I/iJ8QogFi8eeIlVRgKNTnC/luxXnf6sUKf8AAnKP+Gcl+fMdH9qVJ/xIxfrFP/I+5h8av+CfC/P/AMIn4QLdcf8ACBP/AC8jFXbD9pf9jTTpR/wifgXTLi4X7i6V4DtlkJ9iY1NfCTfE34jMMf8ACca39ftsmfzzUMvxD+IUyNHL498RPG3VG1Sdl/Itij/Vzo69RrzqP/5EX9opbU4f+Ar/ADP0EvP20Et4Hj8KfBDx08Sj5H1BItIs8e7/ADIB+VeV+LP21fileoRYXvw78EwyEqWW5fW7tfUhoRJFn/eVfwr4yuJri8ma5vLiWeZ/vSSOSzfU9TTAADnHNa0uGMBTd5R5n53f5tr8CZ5piJKydl5afl/meseOfjVf+M3x4w8Y+L/HWCf3F/cjTtOB7YtYS24e6tEfYdK4m98e+Ip7STS9Ma20PTphtktNKi+zpKuMbZXyZJh7Su9c9RXt08NSopRitF933bL5I4ZVJTd2xoWnUUVtcgKKQkCk3GjUB1ISKSkosAu40lFFMAqxp1hd6tqNrpOnQma7vpkt7eNeryOdqqPqSBVevdP2Jvh//wALA/aF0Fri3Elj4aSTXrkMuRmDHk/j57Q/rXPi8RHCUJ15bRTf3F0oOrUVOO7djxXVtMvtC1e90LVIfJvdOuZLS5jJ5SWNirL+BBFVScV7t+234EbwN+0Lr08MAjs/Eqx67bYXAJmyJvx89JvzFeD0YTERxeHhXjtJJ/eFak6NSVOXR2AnNFFJXUkZX7C0hOKQnNJTAKKKQn0oC4E4ptFFVYQUUU0nNBIE5oopCcUAIT2FJRRQAUhPagnFNqkgDpTSc0E5opi3CmE5pSaSqSDcKOlFNJzTJEpCaUnFNqkrAFNY9qUnFNoAKKKCcUEtiE9qb0opCe1NCE60UUhOKoGITSUUUBsFITgUtNJqxbCUUUUCAnim0E5NFUgCiikJxSYDTyaKKKYBRRRQA1utJRRQAUUUUAFFFFBAUUUUAFFFB6UANPWiiirAKKKKACiiigAooooAKKKKACiiigBVpaaOKdUsAooopAFFFFABRRRQUgooooGKp7U6mU8c0AFFFFAAOtPplOBpMBaKKKaAUGlpoOKdSYBTgabSg4pAh1FFFJoewDin0ylB7VIMdSg9qSikxjwcU6mDmlBqQHUA4oooKTHdaWmg4p1AxwOaUGmA4p3Wk0A+ikB7UtIaFB7U6mU4HtUtDFBxTqbQDikGxIDmlplOBzUtDFpQfWkopAPo6U0H1p1ADgc0U2lBzQAtKDikooGmPBzRTKcD60mhi9KcGr1LwF+zB8Z/ij4fXxR4B0LStX04t5bvFr+no8MnXZLG86vG2OcOoJHIyK6IfsN/tPN0+Htof+5g0z/5IrjqY/CUpOFSrFNdHJJ/maxo1Zq6i2vRnhle/fsLfDxfiD+0boUl1CJLHwykmu3AZcqWhwIR6Z854T9Aaij/AGEf2p5BmP4b25+mvab/APJFfZn/AAT/AP2aPGvwXsvE+u/ErRU03XNYuILWCAXUNxttIgW3bondRud8Yzn92PavKzfNcPHBVFQqRlJqySab106PotTrweFnKvHni0lrt2Pevjj8O0+JHwh8U+BWhSSTVtLmit94ztuVHmQN+EqRmvxBIeJmhlRkeMlWVhgqR2I7Gv6DL20ItsqPmAyD71+Vnx5/YW+N2ofGDxbrHw38G2954b1LUpL6xlfVrOA4m/eOgSWVWAR3ZBkYwoxXicN4mGBnUw9eSinaSu0lfZ7/AC+4780pOvGNWCu9nb7z5HznpRXvB/YT/aiX73w+sh9df03/AOSKVf2EP2o3+78PrM/TX9N/+SK+r/tPA/8AP+H/AIFH/M8f6vWX2H9zPBqK6Hx/8P8AxT8MPEc3hHxjBY2+rWyg3Fta6hb3hgJ/gkaCR1R+5QkMMjIGa54V2RkpxUou6ZntowooopgFLk0lFADt3tRkU2ilYB+R60ZFMoosA+imUUWAfRTKKLAPoyPWmUUWAdkUbvam0UWAXcaM0lFMAooooAKKKn02xn1TUbbTIJ7WGS5kESSXVxHbwqT0LySFURfVmIA7mgVyCivcYv2Jv2mp4o54Ph9aSRSoHjdPEGmMrqRkMpFzggjkEcGnD9h39qBunw5g/wDB9pv/AMkVxPMsEtHWh/4FH/M1VCs/sP7meFlsDiv0S/4JnfDuTTvAfiP4k3dviXxDerYWrHvbWwyxHs0smD7wj0r5l/4YT/alkU4+HNv06f27p2T/AOTFfqR8Cfhrb/DH4VeGPAsUaB9I06KK4KdHuGBed/8AgUryH8a+c4nzKhWwaw2GqKTm9bNPRa9POx6eVYaUa/takWlFdV1Pkr/gpV8PG1DwToHxFtYWaXQL5rG6Ydre5GVJ+kkYH/bWvzzr9sf2gPh1D8SPhh4m8EOkZk1XTpYrYuPlS5X54GP0lRDmvzF/4YZ/aZVQT4M04cdDr+ngj6/v6y4UzWhRwbwuJqKLg3a7S0evXzuaZxhKk6yrU4tqS6LqjwckCmk5r3Zv2H/2lV6+DNM/8KHTv/j9V779i/8AaH0uxuNT1Pwto9pZ2sbTXFxP4l0yOOGMdXdjcYVR6mvqFmuAk7KvC/8Aij/meS8NXiruD+5niNBOKWdDBNJAzo7ROULRsGUkHGQRwR7imV6NjnAnNJRRTBsKCcUE4pvWgkCc0UU0n0oAUn0ptFFABSE4oJxTaaQBSE5oJ7UlULcKaT2pScU2mkHkFFFITiqEBPamk4oppOaaQgooppNMBCc0UUUCbCmk5pSe1NoJAnFNoJzRVIAppOTSk9qbTEu4UUUVSQbiE4ptKTmkpiYUE4FFNJzQgCiiiqAKaetKTgU2kgCiiimAUjHtS03rQAlFFFABRRRQJhRRRQSFFFFABSNS00nJpoAoooqgCiiigAooooAKKKKACiiigAooooAKVT2pKKAHUUUVABRRRQAUUUUAgooooLClU9qSigB9FAOaKACgHFFFAD6Kap7U6lsAUqntSUUwHUUA5oqQHA9qWmU4HNA1roLRRRUsEOBzS0wHFPpBsAOKdTaUHtSaGPBpab0pwOakApQe1JRQWh9AOKQHNLQA6nA5pgNLSaAfRSA5paQ0OBzS0ynA5qWh+Q4HFLTaAcUg2JAc0tMpwPrUtDFpQcUlFIB9FMBxTgc0AOB9aWm0A4oAdRQCDRQNM6b4dfEvxv8ACjxHF4n8C63Np92mFlQHdDcx55jljPyuh9CPcYIBH6N/s2/tV+CvjYsOgXyRaH4wC/Ppckn7u7IGS1q55fjJMZ+cc43gFq/L6nQT3FpcxXdpPJBPA6yRSxsVeN1OVZSOQQQCD6ivBzrh7C51D94uWa2kt/n3Xl91j0cBmVbAS9x3j1X9bM/dXTdrYHHNdho8YUrgV8JfsN/tUeNPirqNx8NPHlhJqWo6VYtexa6mAZIUZE23I7yZdcOOW/iBILn7r0aYELX5hHL6uU436tiLXXbqujPqpYmGMoe1p7M3r0Ytse1cbqkWWJAzXXXsv7jj0rk9QmVW2kgZOOe2a2zycXb0M8Amjnr6S3tIZbq7mihhgRpZZZWCJGijLMzHhVA5JPAr4J/ac/bpnvWvfAHwKv3gtsmC98SR5V5OzJad0Xt5vDHnZtGGbzf9rP8Aav8AHHxb8Q6l4BsILrw54V0q8ltZtO8zFxeSxOVLXTLwcMDiMHap5O5gGr5vUgDA4r6bh3g+GH5cXj1zS3Ud0vN93+C8zzMyzqVS9HD6Lq+r9Owrs8jvNK7SSSEs7ucsxPUk96UE0UV99Y+duLupQQabRSsGg6im5NLuNIeotFJupcigLhRRkUUBcKKKktba7v7y30+wt3nubqVYYYkGWkdiAFHuScUBcjyBRXtH7WfwLHwC+I+m+FrYFrK98PaddJKB8r3KwLDdYPcm4hmf/gY9a8XrOjVhXpqrDZlSThJxluFFFFaE3CijI9aTdQFxaKTdSZPrQGo7OKTdSUU7C0DJpCARg0tFOwXPc/2fP2svG3wTkh8P6oJfEHg9pMvp0sn72zBPzPauc7D3MZ+RjnIBO8fpB8MfiL4M+KnhuHxV4G1qHUbGQhJMfLLby4yYpo+sbgdj1HKlgQa/GskV1vwt+LPjv4NeJk8VeAtYazuOFubeQF7a8jBz5c0eQHX8iOqlTgj5LP8AhTD5snWoWhV79Jev+f33PZy7OKuD/d1NYfivT/I/amyh5HArrdKG1MHsK8S/Z7+LyfGj4ZaT8QhoM2jtftLE9rJKJFDxOUdkbqULBgMgHgg5xk+0afcrsH0r82wlOWDxDo1laUXZ+qPpq01XpqcNmZ3iRTggVwV8rbyO1dx4gnzn3rwz49/FmP4OfDzVPHh0KTVnsmiiS2SURjfK2xGduoQMQDgE8gDGcjjr0Z4zFqjRV5Sdl6s6aNRUKPPPZK5P8RPiF4N+F3hmfxZ441mKwsYjsjB+aW5lxkRQpnMjkdhwByxUAmvzg+Pv7TPjL4338umo0uj+EoZt9ppMb8ybfuy3DD/WP3A+6vRR1ZuI+JnxU8b/ABe8Rv4n8cau13cYK28CDZb2kec+XDHnCL+ZPUknJPKV+rcO8J0MnSr17Trd+kfTz8/usfI5nnNTG3p09Ifi/X/IQDHApaKM4r688O4UhPpSE5ooEFFJSE5oACfSkoooAKQnFBOKbTSAKQnsKCe1JVC3CkJxQTim00g8goooJxVCAnFMpetNJ7U0hATSUUhOKYATim0UUAFITilppOaCBKQntQTikqkgCkJxS00nNMW4lFFFNIbCkJ7UpOKZVC2CiijpQIQntSUdaKpAFFFITSeoCE5NJRRTAKKKKAEY9qbSnmkoAKKKKACiiiglhRRRQIKKKKAEJpKD1oqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKAFB4paaDg06pYBRRRSAKKKKACiiigpBRRRQMUGnUynjpQAUUUUAFOHNNpQaTAdRRRQgFU0tNpwOaGAUoOKSikA+ikB7UtIfmFKD2pKKke4+ikBzS0CQ4HNKDimA4NOqWhj6KaDinUhhTgcim0A4oKH0oPam9aWgB1PBzUYNOBxSaAdRQDmikMcDmlplOBzUtD8mKDinU2gHFINiQH1paZ1pQaTQx1FFFSA4HNLTKUH1oAdSg+tJRQA6img4pSC+EQFmY7QFGSaAP0D/AOCbPgkaX4P8R/EK7hKy67epYWrMOtvbjc7D2aSQA+8VfeejT42quSScADvXz38JPDuk/A/4NaLpniXUbPSbXQNLjl1S6uJBHDFO/wC8nLMf+mrsAOSSAACcCvkL9pj9uvxH8Qo7rwJ8Irq80PwuxaK51IZivdTToQO8MJ/uj5mGNxAJQfkEMLi+JM4q16C9zmtzPZJaL5tK9v8Ahz7SVSjleBhTqP3rXt1u9T9NPD/xT8B+OrnWdL8G+MNL1m78PXJs9Ths7lZGtZR2YDqM5G4ZXcrLnIIFTWpmYOM9eK/DzwP448X/AA18SWvi/wAC6/d6Pq9mT5dxbvgsp+8jg5DocDKsCp7g1+jH7Pn7bHhr4ypbeEvGqW3h7xk6rGqbttnqT9MwMx+Ryf8Alkx5z8rN90dfEvDeKw1P29D34LfuvO3b02/ExynM6VWXs6vuvp2f/BPjv9srwePCH7Q3iUxRKltrpj1qAKMA+euZD/3+E35V4pX2z/wUZ8HlrXwl8QIYgDBLPot0235sN++hz9CLj9K+Jgc19vw5i/ruV0ard3az9Y6fpc8PM6P1fFzgtr3+/UM4pd1JRXtnBcdkUtMoyRQFh9FN3Uu4UBZi0UmR60UrBdi0U3zE/vr+dHmJ/fX86OULjq+gv2EPhkPiV+0boct5b+bpvhZG1+73LlS0JXyFz0B89oT9A3pXz35kf99fzr9Nv+CX/wAL20L4Y6t8S72DFx4tvfJtmPX7HbFkz7ZmaUe/livKzrE/VMFOS3l7q9X/AMC7OrBU/bV4p7LX7iv/AMFQPhy+r/DHw98R7SAtN4X1FrS5cHpa3QAyfXE0cYH/AF1PrX5p5z3r92Pjf4Bt/iR8LvE/gS4Rf+J3pc9pEzDPlzFcwv8AVZVjYfSvwouIZbG5msbyMwXFs7RSxPwyMpwVI9QeK4OGq/PQlh5bwf4PX87nTmlPlqKotpL8UJRTfMT++v50b0/vr+dfScp5lx1FIGB5BBoyPWiwXFopNwpN3tTCzHUmRTSSaKAsLu9KQkmiigLhSrHJO6QQRtJJKwREUZLE9gO5pK9f/ZG8BH4h/H/wvp8sBmstJnOtXo7CK2/eDPqGkEaEf7dYYmvHC0J157RTf3F04SrTjTju3Y/TX4L+Dv8AhXHw58N+CCAJNH0+G3nIGA0+N0zfjKzn8a7/AF/xp4b8CeHLvxX4v1u10nSbCPfcXdy+1EHYDuzE8BVBYngAmvLvjh8dPh98BvDq634u1HzNRukJsNJt2Bu71vVVP3IwesjfKOg3NhT+Ynxx/aC+Ifx713+0fF1+YNLtZGOnaPbsRa2anjIB+/IRw0jfMeegwo/JMiyDGZ3Wliq3u0223Lu3vy/57L8D7LMcwoYCmqUNZJWt29T9gH8SaT4h0m11zQtTttR06/hWe1u7aUSRTRsMhlYcEf8A6jzXkfxv8LHx98N/E3hJEV5dT06aO2DDI+0KN8P/AJERK/Ob4G/tJfEP4E3xj0W5Op+H7h995ol3KfIc93jPJhkx/Go543BgAK/QL4ZfGfwV8ZtF/tzwbqW6e3CteafOQt1ZsTwJEHVSRgOMqfUHKjLOsgxmQ11ioe9BNNSXSzuubt67P8DXL8xoZjTdGWkmrNd/Q/KZc9CCMcc06u/+P/g8eA/jL4q8PJHstxqD3dqNuB5E4EsYHsFkVfwrz4nNfslCtHE0o1obSSa+aufC1abpTdOW6dhScUlFFakBSE4pCfSkoAOtFFFABSE+lBPpTapIApCaQnNFMW4UhOKCcU2mkAUUUdKoQU0nNBOaQnFCQhCcUlFFUAlN60pOaSgAoopCe1BLEJzSE4oppOaaEFFFITiqBiE9qSiigNgoopCe1ULzEJzSUUUxBSMe1KTim00gCiiimwCmE5pWPakpIAooopgFIx7UtMoAKKKKACiiigTCiiigkKKKKACgnAoppOaaAKKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKVelJQDikwHUUUVIBRRRQAUUUUAFFFFBYU5T2ptL0oAdRRRQAUUUUAOBzS0wHFPpbAFAOKKKYDqKQGlqWAU8HNMpQcUAmOooopND2AHFO602lBxUjY6gHFFFAIdTge1MB7UtSA+ikBzS0hpgDin0ylBoKHU4HNNooAeDindaYDmlBxUtAOoo60UDHA5paZTgfWpaH6ig4pwOabR0pBsPBxTqYDmlpNDHUUgOaWpAAcU4HNNooAfXW/CTUvB+hfEjQfEPj37Q2h6PdDUbmC2j3y3LQgyRwKOmZHVEJYhQGJJ4rkA3rTqmpBVIOD6qw4vlaaPVvj3+0l49+P2siXXZBpug2sjPYaJbSMYISf8AlpIePNlI4LsO5ChQdteVim0Vnh8NSwlJUaEVGK2SKq1Z1pudR3bHUhByCCQRyCD0NAPrS1sQe4S/tL6z42+DGr/B74rPcao8cMVxoWt433MVxAwZIbjPMism+MSffUsM7l+74eMgD1oornw2Eo4TmVGPKpO7S2u9/S9japXnWt7R3srfIXcaXIptFdFjMfRTaA3rSsA6ikyKWkO4UhBIxkj6UtFAXPrT9nj4m/sweL5Lbwd8Yfg34R0bWpCI7fWQk6WV23QCYecBA5/vD92e/l8Z+v4f2Xf2eJB83wW8M847XI/9rV+RRUEYxX05+zN+2p4l+ETWng34gfatf8GoBFCwbdeaWvbyST88Q/55MQAPulcYb47Pslx074nLa00+sOZ2f+HXT027WPYy7G4aP7rFU013svx/zPuq0/ZM/ZvlPz/Bfw4c+91/8er3PwF4Y0LwfoVj4Y8M6Vb6bpemxCC1tIAdkKZJ2jcSepJySSSTzXHeBPGfhrx1oFn4p8Ia3aatpN8u6C6tn3KxHVSDyrA8MjAMp4IFeiaPIBg18PhcXiq1VUsXOTs9pN6P0fU96tQoU4c9GKV+qLurxK0GCO1fPmv/ALL/AOz5qWp3msal8IfD11fX08l1czyLOGlldizuQsoGSSTwAOa+g9Uk/d4HpXFapJ8zc+9bZpi6uEqOWHm4t9nb8icLRhXilVimvM8Qn/Zh/Z7QkR/Bjwv+Mdwf/a1eNfHlP2RvgNYmLVvg74U1PxFPF5tnokAnErg/deVvNPkxk/xEEtg7VOCRW/aX/bo0vwlJeeB/gzcW2qa4oaK51sASWli3QiEHKzSD+9zGpx9852/Amsaxq/iHVbnXdf1O61HUb2QzXN1cytJLK56szMSSa97IMlzTGWxOYV5xh0jzNN+uui/F+R5+Y4zB0L0sPTi5dXZWX+bLvi7xHH4s1+51uDw5pOgwzECLT9KhaK2gUdFUMzMfcszE+tZFFFfoiSikkfN3CiikyPWmFxaKQt6UmTTsIUkCk3elJRTsAHmva/2fPj3p37Pnh/xXr+jaMuqeNtdWHTdO+0RkW1haqTJLNIeshZ/JCxjA/dMWOMBvFKKwxOGp4uk6NZXi9131vb0Kp1ZUpKcHqjW8WeLfFHjzxDd+K/GeuXWr6tfPvnurl9zN6ADoqgcBVAAGAAAAKyaKQn0raMYwioxVkiHJyd2LWp4V8W+JfA2u2/ibwjrNxpmp2pzHPC2MjurA8MpHBVgQRwQaycmiiUYzi4yV0+gRk4vmi7M9L+N/xXsvjLc+H/F1zpX9n+JLewOnazHEP9Gm8ty0U0XUruWRlKHO3y1wSDx5pRSE1lh8PTwtJUaStFbLt5fLoVVqyrTdSe7AnFITmkorYgKKKCcUAFNJzQTmkJxVJAHSmk5oJzRTFuFITignFNppB5BRRRVCCmk5oJzSE4oSEBOKbR1oqgCmk5oJ7UlABRRQTiglsQnFNpetNJ7UxAT2pKKKoAphOaUmkoEgoooqkg3CmnmgnNJTBsKKKQntQIQnNFFFVsAUhOKWmk5pbgJRRRTAKKKKAEJ4ptKTmkoAKKKKACiiiglhRRRQIKKKKAA9KbSse1JVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQA4HNFNBwadUsAooopAFFFFABRRRQNMKKKKChQe1OplOBzQAtFFFABSg9qSigB9FIDmlpIApwPFNoBxTYDqKKKkBQe1OplOBoGuwtFFFSwQoPanUynA5pA9BacDmm0A4pNXGOp45FM60oOKkB1FFFA0xQexp1MpwOaChelOBzTaOlADwcU6mA5pQcVLQDqKKKBig+tOplKD61LQx1KD60lFIB1OB9aYD2paAH0U0GnVNhhSgkUlFIBwINLTKXd60AOozikBzS0AKDS02jOKAHUUm71pc0AFFFFA7hRRRQO4uT60u6m0UWAduFGRTadFDNdTx2ltE0s07iOONBlmYnAAHc0rID9F/+Cbfhe50P4X6z4snaQL4i1bZboZCU8m2TbuC9ATJJIpI5Plj04+49Jutqrk14b8HPBifDX4e+HvBEQQto1jFBOyjAe4xumYfWVnP5Vzvx7/bH+H/AMArSXR+Nf8AFxT91ottLgW5IyrXUgz5Q6HYMucjhQdw/FZ1q+c5vUnho8zlLS3ZaJ/dY+6VOngcFBVXay19XqfUV/dBouteJftBeHr3xx8KPF3hPTZJUvNR0i5jtfKkZGaZU3xrlecMyBSOhDEHg181fs+f8FHE8Q6g/hb4/RWWlyXtwxsdcsYTHaxBj8sNxHklFXoJQTgY3jgyV9cX91HcRJe2s8csUirNDLG4dJFPKsrDIZTwQRwRU51h8ZlWKhOtGzTTT3Ttro/6Y8BUoYylKMH5Pufh8m3HB/8Ar0/cK9B/aH8Ej4e/GnxZ4bhiMdqt+93ZjbgfZ58SxgewVwv/AAE155X7PQrQxNKNaG0kmvRq58PUpulN05bp2HbvakyfWkoraxAUUUUBcKKKKBXCiikLelAhaCRTSc0UABJNFFJQAtISBSbvSkoAUk0lFFABRRTSfSnYBScU2ikJqrCFJxTSc0UUAFIT6UE+lNppAFFFFUIKaTmgmk6UJCAnFNJzQTmiqAKaT2FKTim0AFFFFAmwpvWgnNJQSBOKbQTmiqSAKax7UpOKb1pi3CiiimkDCkJ7UE4ptUGwUUUUCA9KbQTmiqQBRRSE4pMAJ7U2iimgCiiigApCe1KTimUAFFFFABRRRQJhRRRQSFFFFABQTiimk800AUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSg0lA4pMB1FFFSAUUUUAFFFFABRRRQUFKDikooGPopAe1LQAUUUUAKtOplOBzSYC0UUU0wFB7UtNp3WkwClBxSUUgH0U0HtTqB7hR0ooqWNajgc0tNBxTqQtgBxTutNpQe1JoY4HFOplOB7VIC0UUUFJjgaWmU4HNAxQcU4HNNooAeDinA5plKDipaAdRRnNFAxQadTKUHFJoNh1AOKQc0tSOw6lBxTAcU4HNAXHAg0tMpwapaGLRRRSAM4pd3rSUUAPopgJFODUALRRRQAu40oOabRQA6im5NGTQA6ik3e1KDmgAr2f9kPwTaeMPjbpuo6w8EOjeEoJfEeoz3LBIYo7fBjLu2FUec0OSTjGa8Yq1b6tqtnp17pFpqNxBZakYjeW8chVLjyyWQOB94KxyAeMgHqBjnxdGWIoTowlyuStftfr69jSjUVOopyV7O9j7I/aE/btuJI7rwT8DLl4k5iuvEpQrI394WinlB281hu67QvDH4vuJp7q4lu7qeSe4ndpJZZWLPI7HLMxPJJJJJ9TTQAOAMUVzZZlWFyml7LDRt3fV+r/pLobYvG1sbPnqv5dF6CFQRg17h8Av2rvHXwUePQbwy6/4Rd8yaXPKd9qCfme1c58s9ymCjHOQCdw8QorpxeDoY6k6GIipRfR/1o/Myo16mHmqlJ2aPpz9se88I/EzTfCXx18A6kl/p9+j6DqJ+7LbXMeZYY5o+qSFHkHoRECpYc18x1JHc3cNtNZRXUyW9wyNNCrkJIy52ll6Ejc2M9Mn1qOssvway/Dxw0ZXjHa+9uifpsVicQ8TVdVqze/qFFFJu9q7TAWim7jRk+tADicUm40lFABRRRQAUUhNISTQApb0ppJNFFABRRRQAUEgUhIptNIBSc0lBOKaTmqE2BOaKKKAsFNJ9KCc0lNINwoooqhB0ppOaCc0lFriCmk5oJzRVAFITignFN60AFFFFAmwppNKTTaCQppOaUntSVSAKTpS00nNMW4hOaKKKEPYKKKQntVi21EJzSUUUCCkJ7UtNPJpoAooopsApGo6U3rSWoBRRRTAKKKQntQAhOaSiigAooooEFFFFBIUUUUAFFFFAATim0E5NFUgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAKD2pabTh0qWAUUUUgCiiigAooooGgooooKCnA5ptOWgBaKKKACgHFFFAD6KaDinUtgCgHFFFMB1FIDS1IBTgc02igE7D6KQHNLSGFOU02ipHuPopAc0tAkKD2pabTgc1LQxwNLTKf1pAFHSiigpMcDmlpgOKd1oGKDinA5ptAOKAHg4p1MBzSg4qWgHUUZzRQO4AkU4HNNopNBsPopAc0tSPcUN60tNpQ3rQHqOBxTsimZFFJoY+ikB9TS0gCiiikAZxShvWkooAfRTKUH1oAdRSZHrS0AFFFFABRk+tFFABk+tGT60UUAGT60ZPrRRQAZPrRRRQAUUUUAFFFJketAC0U0n0pKAHE+lNJJoooAKKKKACiikJ9DTAWmk5pKKaQBSE0FvSkpiv2AnNFFITigNgJxSEk0hOaKpINwooopiuFNJzQTmkoSEBOKaTmgnNFUAUhOKWmk5oAQnNFFFAmwpCcUtNNBIlITSk4ptNIAoopCcVQMCcCm0daKA2CiignFUICcUyl60lMTYUUUhPagAJpKKKoAooppPaluAE5pKKKYBRRRQAE4plObpTaACiiigAooooJYUUUUCCiiigApCe1LTaaQBRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAU4dKbTh0pMAoooqQCiiigAooooGgooooKClBxSUUAP60U0HFOoAKKKKACnDpTaUHFDAdRRRSQBSqe1JQDimwHUUUVICjrTqZTgexoGhaKKKTDZhTh0ptKDipGx1A4NFFAId1pelMBxTqlqwDgc0tNBwadSAKOlFFBSdx9FNBxS5zQMUHFOptAOKAHg4NOplLnFSwHUUDkUUDuFOBzTaKTQD6KaG9adUj3AcU7INNooFsOpc4poPrS0DHA5paZSg0rDHUUZFFSAUUUUAFFFFABk+tOyKbRQA7I9aWmUUAPoplFAD6KZRQA+kyPWm0UAOyKTJ9aSigAooooAKKKKACiijIoAKCQKaT6UlVYBck0lFIT6GmIXIFNJzRRQG4UUUhNAbATim5zRRVJCCiiimDCmk5oJzSUIQU0nNKTmkqgCikpCc0AB60lFFAMKCcUU0nNBIE5pKKaTTQgJzRRRVAxDTaUnsKSgEFFFFNCfYKa3WlJxTaoH2CiiigQhOKSgnNFUgCiiikwEPSm0pPakpoAooooAKKKaTQAE5pKKKACiiigAooooJYUUUUCCiiigAPSm049KbVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAU4dKbSg9qTAWiiipAKKKKACiiigAooooKTCiiigYU4HtTaKAH0UgOaWgAooooAUHtTqYOtPpPQAooopgKD2paaOtOpMAooopAOHSlpoOKdQPdBRRRUtAmKOtOplOBzSBi0oPrSUUDHUq01TS1ID6KQGlpDClBxSUUFD6KatOoAUdaWm0AkUAPBIpQc03rSg4qWgHUUAg0UDQUob1pKKQeg7OaWmDrTqTQ0xaKKKQNDgc0U2lB96AuLSg+ppKKBj6KZSg0rAOoooqQCiiigAooooAKKKKACiiigAooooAKKKKACiiigAopCfSm07AOJ9KbRRVAFGcUhPoaSgVwyaKKKAsFJS00nJppAwLelJRRTF6hRRRnFMGwJxTSSaCc0lCQgpGoJpKoAoopGoARj2pKKKACiikJxQSDU2ikJpiAmkooqgCmt6UpOKbQLcKKKKaQ2woPSimk5qhCUUUUCCkJ7UtNPWhAFFFFUAUhPalpp60twEooopgFFFITgUABNNoooAKKKKACiiigTYUUUUEhRRRQAUUUUAB6U2lY9qSqQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAcDmimg4p1S0AUUUUgCiiigAooooAKKKKCk7hRRRQMctLSLS0AFFFFABTgc02gHFDQD6KTrS1KAKUHFJRVAOopAe1LUgFOWm0oOKAQ6iiikN6BSjrSUVI9x9FNBp1AtgBxTgc02gdaTQx4OKcDmmUVID6KKKBoKcDmm0A4oKH0UgOaWgBQe1LTaVetADgcU4HNMpR1qQHUUUUDTsFFFFAbjgaWmUu41LQ7jqKKKQBSg5pKKBaodRTcmlBzQO4tLk+tJRQMXcadTKXJ9aVgHUU3Jo3GlYB1FN3GjcaLAOopu40bjRYB1FN3GjJosA6m7jRk+tJTSAXJ9aSiimAUUE4puTQK44nFNJzRRQLcKKKKBhSE4FJupMmnYLhRRRVCtYKKKKAbuFNJzQ3WkoEFITQ1JVAFFFITigAJxTaUnNJQAUUUUEsKaTmg9aSgQE4ppOaVqSqSAKKKaT2FMT1ButJRRQPYKKKKoS1EPSm0pNJTEwoopGPagAJ7CkooqgCiiipYCdKaeaUnNJTSAKKKKYBSN0paRulADaKKKACiiigQUUUUEhRRRQAUUUUAFBOKKaTmmkAUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH//2Q==";
var DATA = {
	words: [
		"кардинг",
		"прокси",
		"антик",
		"ролка",
		"дропы",
		"обнал",
		"залив",
		"вбивы",
		"бинка",
		"логи",
		"крипта",
		"биржа",
		"рефанд",
		"скупка",
		"мерчант",
		"гарант",
		"чекер",
		"сплит",
		"акки",
		"дедик",
		"соксы",
		"кошель",
		"профит",
		"ворк",
		"скам",
		"эскроу",
		"фишинг",
		"холдер",
		"арбитр",
		"трафик",
		"дамп",
		"матрас",
		"отстук",
		"клад",
		"обход"
	],
	fonts: [
		{
			"upm": 2048,
			"g": {
				"а": {
					"a": 1382,
					"c": [
						[
							"M",
							674,
							504
						],
						[
							"Q",
							562,
							504,
							506,
							466
						],
						[
							"Q",
							449,
							428,
							449,
							354
						],
						[
							"Q",
							449,
							286,
							494,
							248
						],
						[
							"Q",
							540,
							209,
							621,
							209
						],
						[
							"Q",
							722,
							209,
							791,
							282
						],
						[
							"Q",
							860,
							354,
							860,
							463
						],
						[
							"L",
							860,
							504
						],
						["Z"],
						[
							"M",
							1221,
							639
						],
						[
							"L",
							1221,
							0
						],
						[
							"L",
							860,
							0
						],
						[
							"L",
							860,
							166
						],
						[
							"Q",
							788,
							64,
							698,
							18
						],
						[
							"Q",
							608,
							-29,
							479,
							-29
						],
						[
							"Q",
							305,
							-29,
							196,
							72
						],
						[
							"Q",
							88,
							174,
							88,
							336
						],
						[
							"Q",
							88,
							533,
							224,
							625
						],
						[
							"Q",
							359,
							717,
							649,
							717
						],
						[
							"L",
							860,
							717
						],
						[
							"L",
							860,
							745
						],
						[
							"Q",
							860,
							830,
							793,
							870
						],
						[
							"Q",
							726,
							909,
							584,
							909
						],
						[
							"Q",
							469,
							909,
							370,
							886
						],
						[
							"Q",
							271,
							863,
							186,
							817
						],
						[
							"L",
							186,
							1090
						],
						[
							"Q",
							301,
							1118,
							417,
							1132
						],
						[
							"Q",
							533,
							1147,
							649,
							1147
						],
						[
							"Q",
							952,
							1147,
							1086,
							1028
						],
						[
							"Q",
							1221,
							908,
							1221,
							639
						],
						["Z"]
					]
				},
				"б": {
					"a": 1430,
					"c": [
						[
							"M",
							110,
							621
						],
						[
							"L",
							103,
							788
						],
						[
							"Q",
							88,
							855,
							88,
							922
						],
						[
							"Q",
							88,
							1118,
							146,
							1246
						],
						[
							"Q",
							253,
							1482,
							396,
							1530
						],
						[
							"Q",
							514,
							1571,
							1005,
							1610
						],
						[
							"Q",
							1055,
							1614,
							1112,
							1623
						],
						[
							"L",
							1192,
							1401
						],
						[
							"Q",
							1116,
							1381,
							726,
							1347
						],
						[
							"Q",
							555,
							1332,
							485,
							1284
						],
						[
							"Q",
							369,
							1205,
							360,
							1056
						],
						[
							"Q",
							507,
							1147,
							728,
							1147
						],
						[
							"Q",
							1017,
							1147,
							1180,
							991
						],
						[
							"Q",
							1342,
							835,
							1342,
							559
						],
						[
							"Q",
							1342,
							283,
							1180,
							127
						],
						[
							"Q",
							1018,
							-29,
							728,
							-29
						],
						[
							"Q",
							438,
							-29,
							274,
							127
						],
						[
							"Q",
							111,
							283,
							111,
							559
						],
						[
							"Q",
							111,
							597,
							110,
							621
						],
						["Z"],
						[
							"M",
							727,
							891
						],
						[
							"Q",
							609,
							891,
							546,
							806
						],
						[
							"Q",
							484,
							720,
							484,
							559
						],
						[
							"Q",
							484,
							398,
							546,
							312
						],
						[
							"Q",
							609,
							227,
							727,
							227
						],
						[
							"Q",
							845,
							227,
							907,
							312
						],
						[
							"Q",
							969,
							398,
							969,
							559
						],
						[
							"Q",
							969,
							720,
							907,
							806
						],
						[
							"Q",
							845,
							891,
							727,
							891
						],
						["Z"]
					]
				},
				"в": {
					"a": 1296,
					"c": [
						[
							"M",
							699,
							698
						],
						[
							"Q",
							761,
							698,
							793,
							724
						],
						[
							"Q",
							825,
							749,
							825,
							799
						],
						[
							"Q",
							825,
							849,
							793,
							874
						],
						[
							"Q",
							761,
							899,
							699,
							899
						],
						[
							"L",
							530,
							899
						],
						[
							"L",
							530,
							698
						],
						["Z"],
						[
							"M",
							711,
							224
						],
						[
							"Q",
							790,
							224,
							830,
							256
						],
						[
							"Q",
							870,
							287,
							870,
							350
						],
						[
							"Q",
							870,
							412,
							830,
							443
						],
						[
							"Q",
							790,
							474,
							711,
							474
						],
						[
							"L",
							530,
							474
						],
						[
							"L",
							530,
							224
						],
						["Z"],
						[
							"M",
							172,
							1120
						],
						[
							"L",
							685,
							1120
						],
						[
							"Q",
							934,
							1120,
							1046,
							1050
						],
						[
							"Q",
							1157,
							979,
							1157,
							824
						],
						[
							"Q",
							1157,
							742,
							1116,
							684
						],
						[
							"Q",
							1075,
							627,
							998,
							599
						],
						[
							"Q",
							1097,
							572,
							1152,
							500
						],
						[
							"Q",
							1206,
							427,
							1206,
							321
						],
						[
							"Q",
							1206,
							159,
							1089,
							80
						],
						[
							"Q",
							972,
							0,
							734,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"г": {
					"a": 1070,
					"c": [
						[
							"M",
							172,
							0
						],
						[
							"L",
							172,
							1120
						],
						[
							"L",
							1021,
							1120
						],
						[
							"L",
							1021,
							899
						],
						[
							"L",
							530,
							899
						],
						[
							"L",
							530,
							0
						],
						["Z"]
					]
				},
				"д": {
					"a": 1654,
					"c": [
						[
							"M",
							175,
							256
						],
						[
							"Q",
							289,
							294,
							337,
							420
						],
						[
							"Q",
							385,
							547,
							385,
							908
						],
						[
							"L",
							385,
							1120
						],
						[
							"L",
							1353,
							1120
						],
						[
							"L",
							1353,
							256
						],
						[
							"L",
							1539,
							256
						],
						[
							"L",
							1539,
							-283
						],
						[
							"L",
							1283,
							-283
						],
						[
							"L",
							1283,
							0
						],
						[
							"L",
							371,
							0
						],
						[
							"L",
							371,
							-283
						],
						[
							"L",
							115,
							-283
						],
						[
							"L",
							115,
							256
						],
						["Z"],
						[
							"M",
							995,
							864
						],
						[
							"L",
							743,
							864
						],
						[
							"L",
							743,
							833
						],
						[
							"Q",
							743,
							466,
							660,
							256
						],
						[
							"L",
							995,
							256
						],
						["Z"]
					]
				},
				"е": {
					"a": 1389,
					"c": [
						[
							"M",
							1290,
							563
						],
						[
							"L",
							1290,
							461
						],
						[
							"L",
							453,
							461
						],
						[
							"Q",
							466,
							335,
							544,
							272
						],
						[
							"Q",
							622,
							209,
							762,
							209
						],
						[
							"Q",
							875,
							209,
							994,
							242
						],
						[
							"Q",
							1112,
							276,
							1237,
							344
						],
						[
							"L",
							1237,
							68
						],
						[
							"Q",
							1110,
							20,
							983,
							-4
						],
						[
							"Q",
							856,
							-29,
							729,
							-29
						],
						[
							"Q",
							425,
							-29,
							256,
							126
						],
						[
							"Q",
							88,
							280,
							88,
							559
						],
						[
							"Q",
							88,
							833,
							254,
							990
						],
						[
							"Q",
							419,
							1147,
							709,
							1147
						],
						[
							"Q",
							973,
							1147,
							1132,
							988
						],
						[
							"Q",
							1290,
							829,
							1290,
							563
						],
						["Z"],
						[
							"M",
							922,
							682
						],
						[
							"Q",
							922,
							784,
							862,
							846
						],
						[
							"Q",
							803,
							909,
							707,
							909
						],
						[
							"Q",
							603,
							909,
							538,
							850
						],
						[
							"Q",
							473,
							792,
							457,
							682
						],
						["Z"]
					]
				},
				"ж": {
					"a": 2038,
					"c": [
						[
							"M",
							30,
							0
						],
						[
							"L",
							537,
							665
						],
						[
							"L",
							69,
							1120
						],
						[
							"L",
							461,
							1120
						],
						[
							"L",
							840,
							751
						],
						[
							"L",
							840,
							1120
						],
						[
							"L",
							1198,
							1120
						],
						[
							"L",
							1198,
							751
						],
						[
							"L",
							1577,
							1120
						],
						[
							"L",
							1969,
							1120
						],
						[
							"L",
							1501,
							665
						],
						[
							"L",
							2008,
							0
						],
						[
							"L",
							1638,
							0
						],
						[
							"L",
							1288,
							458
						],
						[
							"L",
							1198,
							371
						],
						[
							"L",
							1198,
							0
						],
						[
							"L",
							840,
							0
						],
						[
							"L",
							840,
							371
						],
						[
							"L",
							750,
							458
						],
						[
							"L",
							400,
							0
						],
						["Z"]
					]
				},
				"з": {
					"a": 1190,
					"c": [
						[
							"M",
							288,
							698
						],
						[
							"L",
							452,
							698
						],
						[
							"Q",
							599,
							698,
							652,
							730
						],
						[
							"Q",
							706,
							762,
							706,
							806
						],
						[
							"Q",
							706,
							909,
							470,
							909
						],
						[
							"Q",
							273,
							909,
							151,
							840
						],
						[
							"L",
							151,
							1099
						],
						[
							"Q",
							333,
							1147,
							548,
							1147
						],
						[
							"Q",
							800,
							1147,
							916,
							1076
						],
						[
							"Q",
							1032,
							1004,
							1032,
							853
						],
						[
							"Q",
							1032,
							655,
							813,
							604
						],
						[
							"Q",
							1060,
							543,
							1060,
							318
						],
						[
							"Q",
							1060,
							145,
							924,
							58
						],
						[
							"Q",
							788,
							-29,
							497,
							-29
						],
						[
							"Q",
							280,
							-29,
							100,
							27
						],
						[
							"L",
							100,
							303
						],
						[
							"Q",
							324,
							209,
							457,
							209
						],
						[
							"Q",
							603,
							209,
							668,
							248
						],
						[
							"Q",
							734,
							288,
							734,
							338
						],
						[
							"Q",
							734,
							477,
							446,
							477
						],
						[
							"L",
							288,
							477
						],
						["Z"]
					]
				},
				"и": {
					"a": 1435,
					"c": [
						[
							"M",
							1263,
							1120
						],
						[
							"L",
							1263,
							0
						],
						[
							"L",
							905,
							0
						],
						[
							"L",
							905,
							596
						],
						[
							"L",
							544,
							0
						],
						[
							"L",
							172,
							0
						],
						[
							"L",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							524
						],
						[
							"L",
							891,
							1120
						],
						["Z"]
					]
				},
				"к": {
					"a": 1390,
					"c": [
						[
							"M",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							741
						],
						[
							"L",
							929,
							1120
						],
						[
							"L",
							1321,
							1120
						],
						[
							"L",
							843,
							665
						],
						[
							"L",
							1360,
							0
						],
						[
							"L",
							990,
							0
						],
						[
							"L",
							631,
							463
						],
						[
							"L",
							530,
							367
						],
						[
							"L",
							530,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"л": {
					"a": 1500,
					"c": [
						[
							"M",
							113,
							0
						],
						[
							"L",
							113,
							256
						],
						[
							"Q",
							290,
							292,
							330,
							409
						],
						[
							"Q",
							360,
							498,
							360,
							937
						],
						[
							"L",
							360,
							1120
						],
						[
							"L",
							1328,
							1120
						],
						[
							"L",
							1328,
							0
						],
						[
							"L",
							970,
							0
						],
						[
							"L",
							970,
							864
						],
						[
							"L",
							718,
							864
						],
						[
							"L",
							718,
							827
						],
						[
							"Q",
							718,
							388,
							649,
							260
						],
						[
							"Q",
							509,
							0,
							113,
							0
						],
						["Z"]
					]
				},
				"м": {
					"a": 1674,
					"c": [
						[
							"M",
							172,
							1120
						],
						[
							"L",
							584,
							1120
						],
						[
							"L",
							836,
							560
						],
						[
							"L",
							1088,
							1120
						],
						[
							"L",
							1501,
							1120
						],
						[
							"L",
							1501,
							0
						],
						[
							"L",
							1144,
							0
						],
						[
							"L",
							1144,
							635
						],
						[
							"L",
							955,
							215
						],
						[
							"L",
							720,
							215
						],
						[
							"L",
							530,
							635
						],
						[
							"L",
							530,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"н": {
					"a": 1415,
					"c": [
						[
							"M",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							694
						],
						[
							"L",
							885,
							694
						],
						[
							"L",
							885,
							1120
						],
						[
							"L",
							1243,
							1120
						],
						[
							"L",
							1243,
							0
						],
						[
							"L",
							885,
							0
						],
						[
							"L",
							885,
							473
						],
						[
							"L",
							530,
							473
						],
						[
							"L",
							530,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"о": {
					"a": 1407,
					"c": [
						[
							"M",
							705,
							891
						],
						[
							"Q",
							586,
							891,
							524,
							806
						],
						[
							"Q",
							461,
							720,
							461,
							559
						],
						[
							"Q",
							461,
							398,
							524,
							312
						],
						[
							"Q",
							586,
							227,
							705,
							227
						],
						[
							"Q",
							822,
							227,
							884,
							312
						],
						[
							"Q",
							946,
							398,
							946,
							559
						],
						[
							"Q",
							946,
							720,
							884,
							806
						],
						[
							"Q",
							822,
							891,
							705,
							891
						],
						["Z"],
						[
							"M",
							705,
							1147
						],
						[
							"Q",
							994,
							1147,
							1156,
							991
						],
						[
							"Q",
							1319,
							835,
							1319,
							559
						],
						[
							"Q",
							1319,
							283,
							1156,
							127
						],
						[
							"Q",
							994,
							-29,
							705,
							-29
						],
						[
							"Q",
							415,
							-29,
							252,
							127
						],
						[
							"Q",
							88,
							283,
							88,
							559
						],
						[
							"Q",
							88,
							835,
							252,
							991
						],
						[
							"Q",
							415,
							1147,
							705,
							1147
						],
						["Z"]
					]
				},
				"п": {
					"a": 1415,
					"c": [
						[
							"M",
							1243,
							1120
						],
						[
							"L",
							1243,
							0
						],
						[
							"L",
							885,
							0
						],
						[
							"L",
							885,
							864
						],
						[
							"L",
							530,
							864
						],
						[
							"L",
							530,
							0
						],
						[
							"L",
							172,
							0
						],
						[
							"L",
							172,
							1120
						],
						["Z"]
					]
				},
				"р": {
					"a": 1466,
					"c": [
						[
							"M",
							530,
							162
						],
						[
							"L",
							530,
							-426
						],
						[
							"L",
							172,
							-426
						],
						[
							"L",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							956
						],
						[
							"Q",
							604,
							1054,
							694,
							1100
						],
						[
							"Q",
							784,
							1147,
							901,
							1147
						],
						[
							"Q",
							1108,
							1147,
							1241,
							982
						],
						[
							"Q",
							1374,
							818,
							1374,
							559
						],
						[
							"Q",
							1374,
							300,
							1241,
							136
						],
						[
							"Q",
							1108,
							-29,
							901,
							-29
						],
						[
							"Q",
							784,
							-29,
							694,
							18
						],
						[
							"Q",
							604,
							64,
							530,
							162
						],
						["Z"],
						[
							"M",
							768,
							887
						],
						[
							"Q",
							653,
							887,
							592,
							802
						],
						[
							"Q",
							530,
							718,
							530,
							559
						],
						[
							"Q",
							530,
							400,
							592,
							316
						],
						[
							"Q",
							653,
							231,
							768,
							231
						],
						[
							"Q",
							883,
							231,
							944,
							315
						],
						[
							"Q",
							1004,
							399,
							1004,
							559
						],
						[
							"Q",
							1004,
							719,
							944,
							803
						],
						[
							"Q",
							883,
							887,
							768,
							887
						],
						["Z"]
					]
				},
				"с": {
					"a": 1214,
					"c": [
						[
							"M",
							1077,
							1085
						],
						[
							"L",
							1077,
							793
						],
						[
							"Q",
							1004,
							843,
							930,
							867
						],
						[
							"Q",
							857,
							891,
							778,
							891
						],
						[
							"Q",
							628,
							891,
							544,
							804
						],
						[
							"Q",
							461,
							716,
							461,
							559
						],
						[
							"Q",
							461,
							402,
							544,
							314
						],
						[
							"Q",
							628,
							227,
							778,
							227
						],
						[
							"Q",
							862,
							227,
							938,
							252
						],
						[
							"Q",
							1013,
							277,
							1077,
							326
						],
						[
							"L",
							1077,
							33
						],
						[
							"Q",
							993,
							2,
							906,
							-14
						],
						[
							"Q",
							820,
							-29,
							733,
							-29
						],
						[
							"Q",
							430,
							-29,
							259,
							126
						],
						[
							"Q",
							88,
							282,
							88,
							559
						],
						[
							"Q",
							88,
							836,
							259,
							992
						],
						[
							"Q",
							430,
							1147,
							733,
							1147
						],
						[
							"Q",
							821,
							1147,
							906,
							1132
						],
						[
							"Q",
							992,
							1116,
							1077,
							1085
						],
						["Z"]
					]
				},
				"т": {
					"a": 1187,
					"c": [
						[
							"M",
							8,
							1120
						],
						[
							"L",
							1178,
							1120
						],
						[
							"L",
							1178,
							899
						],
						[
							"L",
							772,
							899
						],
						[
							"L",
							772,
							0
						],
						[
							"L",
							415,
							0
						],
						[
							"L",
							415,
							899
						],
						[
							"L",
							8,
							899
						],
						["Z"]
					]
				},
				"у": {
					"a": 1335,
					"c": [
						[
							"M",
							25,
							1120
						],
						[
							"L",
							383,
							1120
						],
						[
							"L",
							684,
							360
						],
						[
							"L",
							940,
							1120
						],
						[
							"L",
							1298,
							1120
						],
						[
							"L",
							827,
							-106
						],
						[
							"Q",
							756,
							-293,
							662,
							-368
						],
						[
							"Q",
							567,
							-442,
							412,
							-442
						],
						[
							"L",
							205,
							-442
						],
						[
							"L",
							205,
							-207
						],
						[
							"L",
							317,
							-207
						],
						[
							"Q",
							408,
							-207,
							450,
							-178
						],
						[
							"Q",
							491,
							-149,
							514,
							-74
						],
						[
							"L",
							524,
							-43
						],
						["Z"]
					]
				},
				"ф": {
					"a": 2032,
					"c": [
						[
							"M",
							669,
							887
						],
						[
							"Q",
							604,
							887,
							544,
							803
						],
						[
							"Q",
							483,
							719,
							483,
							559
						],
						[
							"Q",
							483,
							399,
							544,
							315
						],
						[
							"Q",
							604,
							231,
							669,
							231
						],
						[
							"Q",
							776,
							231,
							837,
							305
						],
						[
							"L",
							837,
							813
						],
						[
							"Q",
							776,
							887,
							669,
							887
						],
						["Z"],
						[
							"M",
							837,
							1556
						],
						[
							"L",
							1195,
							1556
						],
						[
							"L",
							1195,
							1074
						],
						[
							"Q",
							1301,
							1147,
							1446,
							1147
						],
						[
							"Q",
							1653,
							1147,
							1786,
							982
						],
						[
							"Q",
							1919,
							818,
							1919,
							559
						],
						[
							"Q",
							1919,
							300,
							1786,
							136
						],
						[
							"Q",
							1653,
							-29,
							1446,
							-29
						],
						[
							"Q",
							1301,
							-29,
							1195,
							44
						],
						[
							"L",
							1195,
							-426
						],
						[
							"L",
							837,
							-426
						],
						[
							"L",
							837,
							44
						],
						[
							"Q",
							731,
							-29,
							586,
							-29
						],
						[
							"Q",
							379,
							-29,
							246,
							136
						],
						[
							"Q",
							113,
							300,
							113,
							559
						],
						[
							"Q",
							113,
							818,
							246,
							982
						],
						[
							"Q",
							379,
							1147,
							586,
							1147
						],
						[
							"Q",
							731,
							1147,
							837,
							1074
						],
						["Z"],
						[
							"M",
							1363,
							887
						],
						[
							"Q",
							1256,
							887,
							1195,
							813
						],
						[
							"L",
							1195,
							305
						],
						[
							"Q",
							1256,
							231,
							1363,
							231
						],
						[
							"Q",
							1428,
							231,
							1488,
							315
						],
						[
							"Q",
							1549,
							399,
							1549,
							559
						],
						[
							"Q",
							1549,
							719,
							1488,
							803
						],
						[
							"Q",
							1428,
							887,
							1363,
							887
						],
						["Z"]
					]
				},
				"х": {
					"a": 1321,
					"c": [
						[
							"M",
							455,
							573
						],
						[
							"L",
							51,
							1120
						],
						[
							"L",
							430,
							1120
						],
						[
							"L",
							659,
							788
						],
						[
							"L",
							891,
							1120
						],
						[
							"L",
							1270,
							1120
						],
						[
							"L",
							866,
							575
						],
						[
							"L",
							1290,
							0
						],
						[
							"L",
							911,
							0
						],
						[
							"L",
							659,
							354
						],
						[
							"L",
							410,
							0
						],
						[
							"L",
							31,
							0
						],
						["Z"]
					]
				},
				"ч": {
					"a": 1406,
					"c": [
						[
							"M",
							816,
							0
						],
						[
							"L",
							816,
							433
						],
						[
							"L",
							448,
							433
						],
						[
							"Q",
							298,
							433,
							215,
							522
						],
						[
							"Q",
							132,
							610,
							132,
							784
						],
						[
							"L",
							132,
							1120
						],
						[
							"L",
							490,
							1120
						],
						[
							"L",
							490,
							921
						],
						[
							"Q",
							490,
							743,
							519,
							698
						],
						[
							"Q",
							548,
							654,
							624,
							654
						],
						[
							"L",
							816,
							654
						],
						[
							"L",
							816,
							1120
						],
						[
							"L",
							1174,
							1120
						],
						[
							"L",
							1174,
							0
						],
						["Z"]
					]
				},
				"ш": {
					"a": 2175,
					"c": [
						[
							"M",
							1260,
							256
						],
						[
							"L",
							1632,
							256
						],
						[
							"L",
							1632,
							1120
						],
						[
							"L",
							1990,
							1120
						],
						[
							"L",
							1990,
							0
						],
						[
							"L",
							172,
							0
						],
						[
							"L",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							256
						],
						[
							"L",
							902,
							256
						],
						[
							"L",
							902,
							1120
						],
						[
							"L",
							1260,
							1120
						],
						["Z"]
					]
				},
				"ы": {
					"a": 1852,
					"c": [
						[
							"M",
							1328,
							1120
						],
						[
							"L",
							1686,
							1120
						],
						[
							"L",
							1686,
							0
						],
						[
							"L",
							1328,
							0
						],
						["Z"],
						[
							"M",
							870,
							350
						],
						[
							"Q",
							870,
							413,
							830,
							444
						],
						[
							"Q",
							791,
							474,
							711,
							474
						],
						[
							"L",
							530,
							474
						],
						[
							"L",
							530,
							224
						],
						[
							"L",
							711,
							224
						],
						[
							"Q",
							790,
							224,
							830,
							256
						],
						[
							"Q",
							870,
							287,
							870,
							350
						],
						["Z"],
						[
							"M",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							695
						],
						[
							"L",
							733,
							695
						],
						[
							"Q",
							960,
							695,
							1082,
							612
						],
						[
							"Q",
							1205,
							528,
							1205,
							346
						],
						[
							"Q",
							1205,
							164,
							1082,
							82
						],
						[
							"Q",
							960,
							0,
							733,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"ь": {
					"a": 1295,
					"c": [
						[
							"M",
							870,
							350
						],
						[
							"Q",
							870,
							413,
							830,
							444
						],
						[
							"Q",
							791,
							474,
							711,
							474
						],
						[
							"L",
							530,
							474
						],
						[
							"L",
							530,
							224
						],
						[
							"L",
							711,
							224
						],
						[
							"Q",
							790,
							224,
							830,
							256
						],
						[
							"Q",
							870,
							287,
							870,
							350
						],
						["Z"],
						[
							"M",
							172,
							1120
						],
						[
							"L",
							530,
							1120
						],
						[
							"L",
							530,
							695
						],
						[
							"L",
							733,
							695
						],
						[
							"Q",
							960,
							695,
							1082,
							612
						],
						[
							"Q",
							1205,
							528,
							1205,
							346
						],
						[
							"Q",
							1205,
							164,
							1082,
							82
						],
						[
							"Q",
							960,
							0,
							733,
							0
						],
						[
							"L",
							172,
							0
						],
						["Z"]
					]
				},
				"э": {
					"a": 1214,
					"c": [
						[
							"M",
							268,
							663
						],
						[
							"L",
							742,
							663
						],
						[
							"Q",
							729,
							738,
							658,
							814
						],
						[
							"Q",
							586,
							891,
							433,
							891
						],
						[
							"Q",
							280,
							891,
							137,
							793
						],
						[
							"L",
							137,
							1085
						],
						[
							"Q",
							307,
							1147,
							481,
							1147
						],
						[
							"Q",
							784,
							1147,
							955,
							992
						],
						[
							"Q",
							1126,
							836,
							1126,
							559
						],
						[
							"Q",
							1126,
							282,
							955,
							126
						],
						[
							"Q",
							784,
							-29,
							481,
							-29
						],
						[
							"Q",
							305,
							-29,
							137,
							33
						],
						[
							"L",
							137,
							326
						],
						[
							"Q",
							266,
							227,
							426,
							227
						],
						[
							"Q",
							581,
							227,
							656,
							302
						],
						[
							"Q",
							731,
							377,
							744,
							462
						],
						[
							"L",
							268,
							462
						],
						["Z"]
					]
				}
			}
		},
		{
			"upm": 2048,
			"g": {
				"а": {
					"a": 1327,
					"c": [
						[
							"M",
							1128,
							653
						],
						[
							"L",
							1128,
							121
						],
						[
							"L",
							1280,
							121
						],
						[
							"L",
							1280,
							0
						],
						[
							"L",
							774,
							0
						],
						[
							"L",
							774,
							135
						],
						[
							"Q",
							704,
							51,
							618,
							11
						],
						[
							"Q",
							532,
							-29,
							422,
							-29
						],
						[
							"Q",
							259,
							-29,
							172,
							58
						],
						[
							"Q",
							84,
							146,
							84,
							309
						],
						[
							"Q",
							84,
							488,
							210,
							577
						],
						[
							"Q",
							335,
							666,
							588,
							666
						],
						[
							"L",
							774,
							666
						],
						[
							"L",
							774,
							729
						],
						[
							"Q",
							774,
							858,
							713,
							920
						],
						[
							"Q",
							652,
							981,
							524,
							981
						],
						[
							"Q",
							418,
							981,
							360,
							938
						],
						[
							"Q",
							303,
							894,
							279,
							795
						],
						[
							"L",
							166,
							795
						],
						[
							"L",
							166,
							1024
						],
						[
							"Q",
							261,
							1058,
							363,
							1075
						],
						[
							"Q",
							465,
							1092,
							578,
							1092
						],
						[
							"Q",
							863,
							1092,
							996,
							986
						],
						[
							"Q",
							1128,
							880,
							1128,
							653
						],
						["Z"],
						[
							"M",
							774,
							334
						],
						[
							"L",
							774,
							547
						],
						[
							"L",
							641,
							547
						],
						[
							"Q",
							542,
							547,
							489,
							493
						],
						[
							"Q",
							436,
							439,
							436,
							338
						],
						[
							"Q",
							436,
							237,
							474,
							187
						],
						[
							"Q",
							513,
							137,
							592,
							137
						],
						[
							"Q",
							674,
							137,
							724,
							191
						],
						[
							"Q",
							774,
							245,
							774,
							334
						],
						["Z"]
					]
				},
				"б": {
					"a": 1366,
					"c": [
						[
							"M",
							69,
							852
						],
						[
							"Q",
							69,
							1013,
							145,
							1156
						],
						[
							"Q",
							248,
							1352,
							403,
							1426
						],
						[
							"Q",
							533,
							1488,
							854,
							1512
						],
						[
							"Q",
							1009,
							1524,
							1054,
							1553
						],
						[
							"Q",
							1098,
							1582,
							1099,
							1590
						],
						[
							"L",
							1229,
							1590
						],
						[
							"Q",
							1220,
							1498,
							1096,
							1376
						],
						[
							"Q",
							1029,
							1310,
							887,
							1294
						],
						[
							"Q",
							558,
							1257,
							438,
							1217
						],
						[
							"Q",
							370,
							1194,
							274,
							1084
						],
						[
							"Q",
							225,
							1028,
							213,
							912
						],
						[
							"Q",
							370,
							1092,
							668,
							1092
						],
						[
							"Q",
							966,
							1092,
							1125,
							944
						],
						[
							"Q",
							1284,
							795,
							1284,
							532
						],
						[
							"Q",
							1284,
							270,
							1124,
							120
						],
						[
							"Q",
							965,
							-29,
							684,
							-29
						],
						[
							"Q",
							403,
							-29,
							252,
							113
						],
						[
							"Q",
							100,
							255,
							84,
							532
						],
						[
							"L",
							74,
							708
						],
						[
							"Q",
							69,
							796,
							69,
							852
						],
						["Z"],
						[
							"M",
							684,
							84
						],
						[
							"Q",
							796,
							84,
							842,
							180
						],
						[
							"Q",
							887,
							276,
							887,
							532
						],
						[
							"Q",
							887,
							788,
							842,
							884
						],
						[
							"Q",
							797,
							979,
							684,
							979
						],
						[
							"Q",
							571,
							979,
							525,
							882
						],
						[
							"Q",
							479,
							786,
							479,
							532
						],
						[
							"Q",
							479,
							278,
							525,
							181
						],
						[
							"Q",
							571,
							84,
							684,
							84
						],
						["Z"]
					]
				},
				"в": {
					"a": 1423,
					"c": [
						[
							"M",
							575,
							121
						],
						[
							"L",
							665,
							121
						],
						[
							"Q",
							783,
							121,
							880,
							166
						],
						[
							"Q",
							976,
							210,
							976,
							308
						],
						[
							"Q",
							976,
							401,
							888,
							450
						],
						[
							"Q",
							800,
							499,
							665,
							499
						],
						[
							"L",
							575,
							499
						],
						["Z"],
						[
							"M",
							575,
							654
						],
						[
							"L",
							654,
							654
						],
						[
							"Q",
							765,
							654,
							854,
							691
						],
						[
							"Q",
							942,
							728,
							942,
							800
						],
						[
							"Q",
							942,
							868,
							858,
							905
						],
						[
							"Q",
							773,
							942,
							654,
							942
						],
						[
							"L",
							575,
							942
						],
						["Z"],
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							788,
							1063
						],
						[
							"Q",
							1262,
							1063,
							1262,
							800
						],
						[
							"Q",
							1262,
							705,
							1176,
							649
						],
						[
							"Q",
							1089,
							593,
							942,
							580
						],
						[
							"Q",
							1124,
							566,
							1232,
							495
						],
						[
							"Q",
							1341,
							424,
							1341,
							308
						],
						[
							"Q",
							1341,
							150,
							1190,
							75
						],
						[
							"Q",
							1040,
							0,
							738,
							0
						],
						["Z"]
					]
				},
				"г": {
					"a": 1255,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							1124,
							1063
						],
						[
							"L",
							1124,
							774
						],
						[
							"L",
							1003,
							774
						],
						[
							"L",
							1003,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							726,
							121
						],
						[
							"L",
							726,
							0
						],
						["Z"]
					]
				},
				"д": {
					"a": 1365,
					"c": [
						[
							"M",
							70,
							-283
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							136,
							121
						],
						[
							"Q",
							243,
							121,
							286,
							300
						],
						[
							"Q",
							328,
							480,
							328,
							769
						],
						[
							"Q",
							328,
							769,
							328,
							942
						],
						[
							"L",
							177,
							942
						],
						[
							"L",
							177,
							1063
						],
						[
							"L",
							1281,
							1063
						],
						[
							"L",
							1281,
							942
						],
						[
							"L",
							1130,
							942
						],
						[
							"L",
							1130,
							121
						],
						[
							"Q",
							1130,
							121,
							1295,
							121
						],
						[
							"L",
							1295,
							-283
						],
						[
							"L",
							1176,
							-283
						],
						[
							"L",
							1160,
							-142
						],
						[
							"Q",
							1144,
							0,
							1044,
							0
						],
						[
							"L",
							321,
							0
						],
						[
							"Q",
							221,
							0,
							205,
							-142
						],
						[
							"Q",
							205,
							-142,
							189,
							-283
						],
						["Z"],
						[
							"M",
							380,
							135
						],
						[
							"Q",
							380,
							121,
							413,
							121
						],
						[
							"L",
							776,
							121
						],
						[
							"L",
							776,
							942
						],
						[
							"L",
							458,
							942
						],
						[
							"L",
							458,
							768
						],
						[
							"Q",
							458,
							486,
							419,
							312
						],
						[
							"Q",
							380,
							137,
							380,
							135
						],
						["Z"]
					]
				},
				"е": {
					"a": 1303,
					"c": [
						[
							"M",
							821,
							600
						],
						[
							"Q",
							821,
							810,
							782,
							894
						],
						[
							"Q",
							743,
							979,
							649,
							979
						],
						[
							"Q",
							558,
							979,
							518,
							896
						],
						[
							"Q",
							479,
							813,
							479,
							618
						],
						[
							"L",
							479,
							600
						],
						["Z"],
						[
							"M",
							1210,
							481
						],
						[
							"L",
							479,
							481
						],
						[
							"L",
							479,
							473
						],
						[
							"Q",
							479,
							267,
							541,
							176
						],
						[
							"Q",
							603,
							84,
							741,
							84
						],
						[
							"Q",
							856,
							84,
							927,
							145
						],
						[
							"Q",
							998,
							206,
							1018,
							322
						],
						[
							"L",
							1184,
							322
						],
						[
							"Q",
							1141,
							141,
							1013,
							56
						],
						[
							"Q",
							885,
							-29,
							655,
							-29
						],
						[
							"Q",
							379,
							-29,
							232,
							116
						],
						[
							"Q",
							84,
							262,
							84,
							532
						],
						[
							"Q",
							84,
							796,
							235,
							944
						],
						[
							"Q",
							386,
							1092,
							655,
							1092
						],
						[
							"Q",
							919,
							1092,
							1060,
							936
						],
						[
							"Q",
							1201,
							781,
							1210,
							481
						],
						["Z"]
					]
				},
				"ж": {
					"a": 2068,
					"c": [
						[
							"M",
							25,
							0
						],
						[
							"L",
							25,
							121
						],
						[
							"L",
							140,
							121
						],
						[
							"L",
							588,
							696
						],
						[
							"L",
							314,
							942
						],
						[
							"L",
							117,
							942
						],
						[
							"L",
							117,
							1063
						],
						[
							"L",
							602,
							1063
						],
						[
							"L",
							602,
							942
						],
						[
							"L",
							475,
							942
						],
						[
							"L",
							859,
							557
						],
						[
							"L",
							859,
							943
						],
						[
							"L",
							730,
							943
						],
						[
							"L",
							730,
							1063
						],
						[
							"L",
							1338,
							1063
						],
						[
							"L",
							1338,
							943
						],
						[
							"L",
							1209,
							943
						],
						[
							"L",
							1209,
							557
						],
						[
							"L",
							1593,
							942
						],
						[
							"L",
							1466,
							942
						],
						[
							"L",
							1466,
							1063
						],
						[
							"L",
							1951,
							1063
						],
						[
							"L",
							1951,
							942
						],
						[
							"L",
							1754,
							942
						],
						[
							"L",
							1480,
							696
						],
						[
							"L",
							1928,
							121
						],
						[
							"L",
							2043,
							121
						],
						[
							"L",
							2043,
							0
						],
						[
							"L",
							1433,
							0
						],
						[
							"L",
							1433,
							121
						],
						[
							"L",
							1558,
							121
						],
						[
							"L",
							1276,
							483
						],
						[
							"L",
							1209,
							412
						],
						[
							"L",
							1209,
							121
						],
						[
							"L",
							1338,
							121
						],
						[
							"L",
							1338,
							0
						],
						[
							"L",
							730,
							0
						],
						[
							"L",
							730,
							121
						],
						[
							"L",
							859,
							121
						],
						[
							"L",
							859,
							412
						],
						[
							"L",
							793,
							483
						],
						[
							"L",
							510,
							121
						],
						[
							"L",
							635,
							121
						],
						[
							"L",
							635,
							0
						],
						["Z"]
					]
				},
				"з": {
					"a": 1307,
					"c": [
						[
							"M",
							70,
							259
						],
						[
							"L",
							236,
							259
						],
						[
							"Q",
							257,
							221,
							326,
							152
						],
						[
							"Q",
							394,
							84,
							576,
							84
						],
						[
							"Q",
							703,
							84,
							784,
							149
						],
						[
							"Q",
							861,
							198,
							861,
							279
						],
						[
							"Q",
							861,
							500,
							478,
							500
						],
						[
							"L",
							417,
							500
						],
						[
							"L",
							417,
							637
						],
						[
							"L",
							465,
							637
						],
						[
							"Q",
							698,
							637,
							766,
							686
						],
						[
							"Q",
							815,
							721,
							824,
							750
						],
						[
							"Q",
							834,
							778,
							834,
							808
						],
						[
							"Q",
							834,
							979,
							536,
							979
						],
						[
							"Q",
							389,
							979,
							324,
							932
						],
						[
							"Q",
							258,
							886,
							245,
							868
						],
						[
							"Q",
							232,
							851,
							227,
							815
						],
						[
							"L",
							115,
							815
						],
						[
							"L",
							115,
							1028
						],
						[
							"Q",
							502,
							1092,
							613,
							1092
						],
						[
							"Q",
							1155,
							1092,
							1155,
							812
						],
						[
							"Q",
							1155,
							715,
							1074,
							652
						],
						[
							"Q",
							993,
							589,
							879,
							576
						],
						[
							"Q",
							1046,
							560,
							1136,
							484
						],
						[
							"Q",
							1225,
							407,
							1225,
							283
						],
						[
							"Q",
							1225,
							128,
							1064,
							50
						],
						[
							"Q",
							903,
							-29,
							635,
							-29
						],
						[
							"Q",
							220,
							-29,
							70,
							259
						],
						["Z"]
					]
				},
				"и": {
					"a": 1519,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							705,
							1063
						],
						[
							"L",
							705,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							460
						],
						[
							"L",
							944,
							823
						],
						[
							"L",
							944,
							942
						],
						[
							"L",
							813,
							942
						],
						[
							"L",
							813,
							1063
						],
						[
							"L",
							1450,
							1063
						],
						[
							"L",
							1450,
							942
						],
						[
							"L",
							1298,
							942
						],
						[
							"L",
							1298,
							121
						],
						[
							"L",
							1450,
							121
						],
						[
							"L",
							1450,
							0
						],
						[
							"L",
							813,
							0
						],
						[
							"L",
							813,
							121
						],
						[
							"L",
							944,
							121
						],
						[
							"L",
							944,
							597
						],
						[
							"L",
							575,
							234
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							705,
							121
						],
						[
							"L",
							705,
							0
						],
						["Z"]
					]
				},
				"к": {
					"a": 1479,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							943
						],
						[
							"L",
							70,
							943
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							705,
							1063
						],
						[
							"L",
							705,
							943
						],
						[
							"L",
							575,
							943
						],
						[
							"L",
							575,
							557
						],
						[
							"L",
							1004,
							942
						],
						[
							"L",
							877,
							942
						],
						[
							"L",
							877,
							1063
						],
						[
							"L",
							1362,
							1063
						],
						[
							"L",
							1362,
							942
						],
						[
							"L",
							1165,
							942
						],
						[
							"L",
							891,
							696
						],
						[
							"L",
							1339,
							121
						],
						[
							"L",
							1454,
							121
						],
						[
							"L",
							1454,
							0
						],
						[
							"L",
							844,
							0
						],
						[
							"L",
							844,
							121
						],
						[
							"L",
							969,
							121
						],
						[
							"L",
							674,
							500
						],
						[
							"L",
							575,
							412
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							705,
							121
						],
						[
							"L",
							705,
							0
						],
						["Z"]
					]
				},
				"л": {
					"a": 1444,
					"c": [
						[
							"M",
							195,
							-29
						],
						[
							"Q",
							132,
							-29,
							42,
							0
						],
						[
							"L",
							36,
							125
						],
						[
							"Q",
							111,
							94,
							174,
							94
						],
						[
							"Q",
							236,
							94,
							268,
							131
						],
						[
							"Q",
							341,
							217,
							364,
							326
						],
						[
							"Q",
							386,
							435,
							394,
							517
						],
						[
							"Q",
							401,
							599,
							401,
							769
						],
						[
							"L",
							401,
							942
						],
						[
							"L",
							250,
							942
						],
						[
							"L",
							250,
							1063
						],
						[
							"L",
							1374,
							1063
						],
						[
							"L",
							1374,
							942
						],
						[
							"L",
							1223,
							942
						],
						[
							"L",
							1223,
							121
						],
						[
							"L",
							1374,
							121
						],
						[
							"L",
							1374,
							0
						],
						[
							"L",
							718,
							0
						],
						[
							"L",
							718,
							121
						],
						[
							"L",
							869,
							121
						],
						[
							"L",
							869,
							942
						],
						[
							"L",
							531,
							942
						],
						[
							"L",
							531,
							768
						],
						[
							"Q",
							531,
							498,
							491,
							307
						],
						[
							"Q",
							421,
							-29,
							195,
							-29
						],
						["Z"]
					]
				},
				"м": {
					"a": 1779,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							637,
							1063
						],
						[
							"L",
							892,
							427
						],
						[
							"L",
							1146,
							1063
						],
						[
							"L",
							1709,
							1063
						],
						[
							"L",
							1709,
							942
						],
						[
							"L",
							1558,
							942
						],
						[
							"L",
							1558,
							117
						],
						[
							"L",
							1709,
							117
						],
						[
							"L",
							1709,
							0
						],
						[
							"L",
							1053,
							0
						],
						[
							"L",
							1053,
							117
						],
						[
							"L",
							1204,
							117
						],
						[
							"L",
							1204,
							867
						],
						[
							"L",
							920,
							157
						],
						[
							"L",
							636,
							157
						],
						[
							"L",
							351,
							867
						],
						[
							"L",
							351,
							121
						],
						[
							"L",
							502,
							121
						],
						[
							"L",
							502,
							0
						],
						["Z"]
					]
				},
				"н": {
					"a": 1499,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							705,
							1063
						],
						[
							"L",
							705,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							623
						],
						[
							"L",
							924,
							623
						],
						[
							"L",
							924,
							942
						],
						[
							"L",
							793,
							942
						],
						[
							"L",
							793,
							1063
						],
						[
							"L",
							1430,
							1063
						],
						[
							"L",
							1430,
							942
						],
						[
							"L",
							1278,
							942
						],
						[
							"L",
							1278,
							121
						],
						[
							"L",
							1430,
							121
						],
						[
							"L",
							1430,
							0
						],
						[
							"L",
							793,
							0
						],
						[
							"L",
							793,
							121
						],
						[
							"L",
							924,
							121
						],
						[
							"L",
							924,
							502
						],
						[
							"L",
							575,
							502
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							705,
							121
						],
						[
							"L",
							705,
							0
						],
						["Z"]
					]
				},
				"о": {
					"a": 1366,
					"c": [
						[
							"M",
							684,
							84
						],
						[
							"Q",
							796,
							84,
							842,
							180
						],
						[
							"Q",
							887,
							276,
							887,
							532
						],
						[
							"Q",
							887,
							788,
							842,
							884
						],
						[
							"Q",
							797,
							979,
							684,
							979
						],
						[
							"Q",
							571,
							979,
							525,
							882
						],
						[
							"Q",
							479,
							786,
							479,
							532
						],
						[
							"Q",
							479,
							278,
							525,
							181
						],
						[
							"Q",
							571,
							84,
							684,
							84
						],
						["Z"],
						[
							"M",
							684,
							-29
						],
						[
							"Q",
							403,
							-29,
							244,
							120
						],
						[
							"Q",
							84,
							270,
							84,
							532
						],
						[
							"Q",
							84,
							795,
							244,
							944
						],
						[
							"Q",
							403,
							1092,
							684,
							1092
						],
						[
							"Q",
							966,
							1092,
							1125,
							944
						],
						[
							"Q",
							1284,
							795,
							1284,
							532
						],
						[
							"Q",
							1284,
							270,
							1124,
							120
						],
						[
							"Q",
							965,
							-29,
							684,
							-29
						],
						["Z"]
					]
				},
				"п": {
					"a": 1499,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							1430,
							1063
						],
						[
							"L",
							1430,
							942
						],
						[
							"L",
							1278,
							942
						],
						[
							"L",
							1278,
							121
						],
						[
							"L",
							1430,
							121
						],
						[
							"L",
							1430,
							0
						],
						[
							"L",
							793,
							0
						],
						[
							"L",
							793,
							121
						],
						[
							"L",
							924,
							121
						],
						[
							"L",
							924,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							705,
							121
						],
						[
							"L",
							705,
							0
						],
						["Z"]
					]
				},
				"р": {
					"a": 1432,
					"c": [
						[
							"M",
							553,
							584
						],
						[
							"L",
							553,
							479
						],
						[
							"Q",
							553,
							293,
							600,
							210
						],
						[
							"Q",
							648,
							127,
							754,
							127
						],
						[
							"Q",
							863,
							127,
							908,
							215
						],
						[
							"Q",
							952,
							303,
							952,
							532
						],
						[
							"Q",
							952,
							761,
							908,
							848
						],
						[
							"Q",
							863,
							936,
							754,
							936
						],
						[
							"Q",
							648,
							936,
							600,
							853
						],
						[
							"Q",
							553,
							770,
							553,
							584
						],
						["Z"],
						[
							"M",
							199,
							942
						],
						[
							"L",
							47,
							942
						],
						[
							"L",
							47,
							1063
						],
						[
							"L",
							553,
							1063
						],
						[
							"L",
							553,
							928
						],
						[
							"Q",
							598,
							1011,
							674,
							1052
						],
						[
							"Q",
							750,
							1092,
							862,
							1092
						],
						[
							"Q",
							1089,
							1092,
							1220,
							942
						],
						[
							"Q",
							1350,
							793,
							1350,
							532
						],
						[
							"Q",
							1350,
							271,
							1220,
							121
						],
						[
							"Q",
							1089,
							-29,
							862,
							-29
						],
						[
							"Q",
							750,
							-29,
							674,
							12
						],
						[
							"Q",
							598,
							52,
							553,
							135
						],
						[
							"L",
							553,
							-305
						],
						[
							"L",
							717,
							-305
						],
						[
							"L",
							717,
							-426
						],
						[
							"L",
							47,
							-426
						],
						[
							"L",
							47,
							-305
						],
						[
							"L",
							199,
							-305
						],
						["Z"]
					]
				},
				"с": {
					"a": 1247,
					"c": [
						[
							"M",
							1155,
							332
						],
						[
							"Q",
							1117,
							150,
							1e3,
							60
						],
						[
							"Q",
							882,
							-29,
							680,
							-29
						],
						[
							"Q",
							396,
							-29,
							240,
							118
						],
						[
							"Q",
							84,
							265,
							84,
							532
						],
						[
							"Q",
							84,
							796,
							238,
							944
						],
						[
							"Q",
							392,
							1092,
							666,
							1092
						],
						[
							"Q",
							777,
							1092,
							890,
							1071
						],
						[
							"Q",
							1003,
							1050,
							1120,
							1008
						],
						[
							"L",
							1120,
							713
						],
						[
							"L",
							1008,
							713
						],
						[
							"Q",
							992,
							848,
							929,
							914
						],
						[
							"Q",
							866,
							979,
							752,
							979
						],
						[
							"Q",
							604,
							979,
							542,
							879
						],
						[
							"Q",
							479,
							779,
							479,
							532
						],
						[
							"Q",
							479,
							291,
							540,
							188
						],
						[
							"Q",
							601,
							84,
							739,
							84
						],
						[
							"Q",
							846,
							84,
							910,
							148
						],
						[
							"Q",
							975,
							212,
							989,
							332
						],
						["Z"]
					]
				},
				"т": {
					"a": 1269,
					"c": [
						[
							"M",
							66,
							774
						],
						[
							"L",
							66,
							1063
						],
						[
							"L",
							1174,
							1063
						],
						[
							"L",
							1174,
							774
						],
						[
							"L",
							1053,
							774
						],
						[
							"L",
							1053,
							942
						],
						[
							"L",
							797,
							942
						],
						[
							"L",
							797,
							121
						],
						[
							"L",
							927,
							121
						],
						[
							"L",
							927,
							0
						],
						[
							"L",
							292,
							0
						],
						[
							"L",
							292,
							121
						],
						[
							"L",
							443,
							121
						],
						[
							"L",
							443,
							942
						],
						[
							"L",
							187,
							942
						],
						[
							"L",
							187,
							774
						],
						["Z"]
					]
				},
				"у": {
					"a": 1311,
					"c": [
						[
							"M",
							691,
							-240
						],
						[
							"Q",
							643,
							-357,
							575,
							-406
						],
						[
							"Q",
							507,
							-455,
							392,
							-455
						],
						[
							"Q",
							343,
							-455,
							283,
							-444
						],
						[
							"Q",
							223,
							-433,
							152,
							-412
						],
						[
							"L",
							152,
							-190
						],
						[
							"L",
							265,
							-191
						],
						[
							"Q",
							268,
							-268,
							302,
							-305
						],
						[
							"Q",
							335,
							-342,
							402,
							-342
						],
						[
							"Q",
							467,
							-342,
							507,
							-306
						],
						[
							"Q",
							547,
							-271,
							587,
							-172
						],
						[
							"L",
							603,
							-135
						],
						[
							"L",
							140,
							942
						],
						[
							"L",
							25,
							942
						],
						[
							"L",
							25,
							1063
						],
						[
							"L",
							638,
							1063
						],
						[
							"L",
							638,
							942
						],
						[
							"L",
							511,
							942
						],
						[
							"L",
							781,
							313
						],
						[
							"L",
							1033,
							942
						],
						[
							"L",
							892,
							942
						],
						[
							"L",
							892,
							1063
						],
						[
							"L",
							1291,
							1063
						],
						[
							"L",
							1291,
							942
						],
						[
							"L",
							1162,
							942
						],
						["Z"]
					]
				},
				"ф": {
					"a": 1847,
					"c": [
						[
							"M",
							478,
							532
						],
						[
							"Q",
							478,
							276,
							520,
							188
						],
						[
							"Q",
							563,
							100,
							614,
							100
						],
						[
							"Q",
							696,
							100,
							733,
							155
						],
						[
							"L",
							747,
							177
						],
						[
							"L",
							747,
							887
						],
						[
							"L",
							733,
							908
						],
						[
							"Q",
							696,
							963,
							614,
							963
						],
						[
							"Q",
							563,
							963,
							520,
							875
						],
						[
							"Q",
							478,
							787,
							478,
							532
						],
						["Z"],
						[
							"M",
							1101,
							177
						],
						[
							"L",
							1115,
							155
						],
						[
							"Q",
							1152,
							100,
							1234,
							100
						],
						[
							"Q",
							1285,
							100,
							1328,
							188
						],
						[
							"Q",
							1370,
							276,
							1370,
							532
						],
						[
							"Q",
							1370,
							787,
							1328,
							875
						],
						[
							"Q",
							1285,
							963,
							1234,
							963
						],
						[
							"Q",
							1152,
							963,
							1115,
							908
						],
						[
							"L",
							1101,
							887
						],
						["Z"],
						[
							"M",
							83,
							532
						],
						[
							"Q",
							83,
							794,
							240,
							943
						],
						[
							"Q",
							397,
							1092,
							544,
							1092
						],
						[
							"Q",
							688,
							1092,
							733,
							1021
						],
						[
							"L",
							747,
							1e3
						],
						[
							"L",
							747,
							1436
						],
						[
							"L",
							589,
							1436
						],
						[
							"L",
							589,
							1556
						],
						[
							"L",
							1101,
							1556
						],
						[
							"L",
							1101,
							1e3
						],
						[
							"L",
							1115,
							1021
						],
						[
							"Q",
							1160,
							1092,
							1304,
							1092
						],
						[
							"Q",
							1451,
							1092,
							1608,
							943
						],
						[
							"Q",
							1765,
							794,
							1765,
							532
						],
						[
							"Q",
							1765,
							269,
							1608,
							120
						],
						[
							"Q",
							1451,
							-29,
							1304,
							-29
						],
						[
							"Q",
							1160,
							-29,
							1115,
							42
						],
						[
							"L",
							1101,
							64
						],
						[
							"L",
							1101,
							-305
						],
						[
							"L",
							1253,
							-305
						],
						[
							"L",
							1253,
							-426
						],
						[
							"L",
							595,
							-426
						],
						[
							"L",
							595,
							-305
						],
						[
							"L",
							747,
							-305
						],
						[
							"L",
							747,
							64
						],
						[
							"L",
							733,
							42
						],
						[
							"Q",
							688,
							-29,
							544,
							-29
						],
						[
							"Q",
							397,
							-29,
							240,
							120
						],
						[
							"Q",
							83,
							269,
							83,
							532
						],
						["Z"]
					]
				},
				"х": {
					"a": 1221,
					"c": [
						[
							"M",
							719,
							678
						],
						[
							"L",
							907,
							942
						],
						[
							"L",
							776,
							942
						],
						[
							"L",
							776,
							1063
						],
						[
							"L",
							1190,
							1063
						],
						[
							"L",
							1190,
							942
						],
						[
							"L",
							1049,
							942
						],
						[
							"L",
							778,
							563
						],
						[
							"L",
							1094,
							121
						],
						[
							"L",
							1235,
							121
						],
						[
							"L",
							1235,
							0
						],
						[
							"L",
							559,
							0
						],
						[
							"L",
							559,
							121
						],
						[
							"L",
							696,
							121
						],
						[
							"L",
							496,
							401
						],
						[
							"L",
							295,
							121
						],
						[
							"L",
							438,
							121
						],
						[
							"L",
							438,
							0
						],
						[
							"L",
							0,
							0
						],
						[
							"L",
							0,
							121
						],
						[
							"L",
							152,
							121
						],
						[
							"L",
							434,
							518
						],
						[
							"L",
							129,
							942
						],
						[
							"L",
							10,
							942
						],
						[
							"L",
							10,
							1063
						],
						[
							"L",
							659,
							1063
						],
						[
							"L",
							659,
							942
						],
						[
							"L",
							530,
							942
						],
						["Z"]
					]
				},
				"ч": {
					"a": 1499,
					"c": [
						[
							"M",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							705,
							1063
						],
						[
							"L",
							705,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							640
						],
						[
							"Q",
							575,
							572,
							604,
							547
						],
						[
							"Q",
							634,
							522,
							705,
							522
						],
						[
							"L",
							924,
							522
						],
						[
							"L",
							924,
							942
						],
						[
							"L",
							793,
							942
						],
						[
							"L",
							793,
							1063
						],
						[
							"L",
							1429,
							1063
						],
						[
							"L",
							1429,
							942
						],
						[
							"L",
							1278,
							942
						],
						[
							"L",
							1278,
							121
						],
						[
							"L",
							1429,
							121
						],
						[
							"L",
							1429,
							0
						],
						[
							"L",
							783,
							0
						],
						[
							"L",
							783,
							121
						],
						[
							"L",
							924,
							121
						],
						[
							"L",
							924,
							401
						],
						[
							"L",
							667,
							401
						],
						[
							"Q",
							468,
							401,
							344,
							454
						],
						[
							"Q",
							221,
							508,
							221,
							656
						],
						[
							"L",
							221,
							942
						],
						["Z"]
					]
				},
				"ш": {
					"a": 2201,
					"c": [
						[
							"M",
							70,
							0
						],
						[
							"L",
							70,
							121
						],
						[
							"L",
							221,
							121
						],
						[
							"L",
							221,
							942
						],
						[
							"L",
							70,
							942
						],
						[
							"L",
							70,
							1063
						],
						[
							"L",
							705,
							1063
						],
						[
							"L",
							705,
							942
						],
						[
							"L",
							575,
							942
						],
						[
							"L",
							575,
							121
						],
						[
							"L",
							924,
							121
						],
						[
							"L",
							924,
							942
						],
						[
							"L",
							793,
							942
						],
						[
							"L",
							793,
							1063
						],
						[
							"L",
							1408,
							1063
						],
						[
							"L",
							1408,
							942
						],
						[
							"L",
							1278,
							942
						],
						[
							"L",
							1278,
							121
						],
						[
							"L",
							1627,
							121
						],
						[
							"L",
							1627,
							942
						],
						[
							"L",
							1496,
							942
						],
						[
							"L",
							1496,
							1063
						],
						[
							"L",
							2132,
							1063
						],
						[
							"L",
							2132,
							942
						],
						[
							"L",
							1981,
							942
						],
						[
							"L",
							1981,
							121
						],
						[
							"L",
							2132,
							121
						],
						[
							"L",
							2132,
							0
						],
						["Z"]
					]
				},
				"ы": {
					"a": 2053,
					"c": [
						[
							"M",
							85,
							0
						],
						[
							"L",
							85,
							121
						],
						[
							"L",
							236,
							121
						],
						[
							"L",
							236,
							942
						],
						[
							"L",
							85,
							942
						],
						[
							"L",
							85,
							1063
						],
						[
							"L",
							741,
							1063
						],
						[
							"L",
							741,
							942
						],
						[
							"L",
							590,
							942
						],
						[
							"L",
							590,
							614
						],
						[
							"L",
							747,
							614
						],
						[
							"Q",
							1028,
							614,
							1168,
							540
						],
						[
							"Q",
							1308,
							465,
							1308,
							307
						],
						[
							"Q",
							1308,
							149,
							1168,
							74
						],
						[
							"Q",
							1028,
							0,
							747,
							0
						],
						["Z"],
						[
							"M",
							590,
							121
						],
						[
							"L",
							722,
							121
						],
						[
							"Q",
							800,
							121,
							872,
							169
						],
						[
							"Q",
							943,
							217,
							943,
							307
						],
						[
							"Q",
							943,
							397,
							872,
							445
						],
						[
							"Q",
							800,
							493,
							722,
							493
						],
						[
							"L",
							590,
							493
						],
						["Z"],
						[
							"M",
							1318,
							0
						],
						[
							"L",
							1318,
							121
						],
						[
							"L",
							1469,
							121
						],
						[
							"L",
							1469,
							942
						],
						[
							"L",
							1318,
							942
						],
						[
							"L",
							1318,
							1063
						],
						[
							"L",
							1975,
							1063
						],
						[
							"L",
							1975,
							942
						],
						[
							"L",
							1824,
							942
						],
						[
							"L",
							1824,
							121
						],
						[
							"L",
							1975,
							121
						],
						[
							"L",
							1975,
							0
						],
						["Z"]
					]
				},
				"ь": {
					"a": 1390,
					"c": [
						[
							"M",
							85,
							0
						],
						[
							"L",
							85,
							121
						],
						[
							"L",
							236,
							121
						],
						[
							"L",
							236,
							942
						],
						[
							"L",
							85,
							942
						],
						[
							"L",
							85,
							1063
						],
						[
							"L",
							741,
							1063
						],
						[
							"L",
							741,
							942
						],
						[
							"L",
							590,
							942
						],
						[
							"L",
							590,
							614
						],
						[
							"L",
							747,
							614
						],
						[
							"Q",
							1028,
							614,
							1168,
							540
						],
						[
							"Q",
							1308,
							465,
							1308,
							307
						],
						[
							"Q",
							1308,
							149,
							1168,
							74
						],
						[
							"Q",
							1028,
							0,
							747,
							0
						],
						["Z"],
						[
							"M",
							590,
							121
						],
						[
							"L",
							722,
							121
						],
						[
							"Q",
							800,
							121,
							872,
							169
						],
						[
							"Q",
							943,
							217,
							943,
							307
						],
						[
							"Q",
							943,
							397,
							872,
							445
						],
						[
							"Q",
							800,
							493,
							722,
							493
						],
						[
							"L",
							590,
							493
						],
						["Z"]
					]
				},
				"э": {
					"a": 1247,
					"c": [
						[
							"M",
							87,
							319
						],
						[
							"L",
							253,
							319
						],
						[
							"Q",
							264,
							213,
							328,
							148
						],
						[
							"Q",
							393,
							84,
							500,
							84
						],
						[
							"Q",
							636,
							84,
							699,
							188
						],
						[
							"Q",
							749,
							271,
							759,
							476
						],
						[
							"L",
							355,
							476
						],
						[
							"L",
							355,
							595
						],
						[
							"L",
							759,
							595
						],
						[
							"Q",
							753,
							789,
							694,
							884
						],
						[
							"Q",
							635,
							979,
							487,
							979
						],
						[
							"Q",
							361,
							979,
							304,
							920
						],
						[
							"Q",
							248,
							861,
							231,
							725
						],
						[
							"L",
							119,
							725
						],
						[
							"L",
							119,
							1020
						],
						[
							"Q",
							290,
							1092,
							573,
							1092
						],
						[
							"Q",
							847,
							1092,
							1001,
							944
						],
						[
							"Q",
							1155,
							796,
							1155,
							530
						],
						[
							"Q",
							1155,
							265,
							999,
							118
						],
						[
							"Q",
							843,
							-29,
							559,
							-29
						],
						[
							"Q",
							160,
							-29,
							87,
							319
						],
						["Z"]
					]
				}
			}
		},
		{
			"upm": 2048,
			"g": {
				"а": {
					"a": 1205,
					"c": [
						[
							"M",
							428,
							-20
						],
						[
							"C",
							583,
							-20,
							691,
							42,
							752,
							157
						],
						[
							"L",
							761,
							157
						],
						[
							"L",
							761,
							0
						],
						[
							"L",
							1089,
							0
						],
						[
							"L",
							1089,
							759
						],
						[
							"C",
							1089,
							999,
							870,
							1132,
							592,
							1132
						],
						[
							"C",
							312,
							1132,
							136,
							1001,
							92,
							810
						],
						[
							"L",
							408,
							769
						],
						[
							"C",
							427,
							839,
							492,
							884,
							589,
							884
						],
						[
							"C",
							684,
							884,
							741,
							840,
							741,
							763
						],
						[
							"L",
							741,
							759
						],
						[
							"C",
							741,
							690,
							665,
							676,
							476,
							660
						],
						[
							"C",
							250,
							641,
							60,
							558,
							60,
							310
						],
						[
							"C",
							60,
							89,
							213,
							-20,
							428,
							-20
						],
						["Z"],
						[
							"M",
							534,
							211
						],
						[
							"C",
							450,
							211,
							390,
							251,
							390,
							326
						],
						[
							"C",
							390,
							400,
							448,
							444,
							551,
							459
						],
						[
							"C",
							616,
							469,
							704,
							484,
							744,
							505
						],
						[
							"L",
							744,
							398
						],
						[
							"C",
							744,
							288,
							651,
							211,
							534,
							211
						],
						["Z"]
					]
				},
				"б": {
					"a": 1265,
					"c": [
						[
							"M",
							1068,
							1525
						],
						[
							"C",
							1014,
							1489,
							923,
							1490,
							802,
							1490
						],
						[
							"C",
							777,
							1490,
							751,
							1490,
							723,
							1490
						],
						[
							"C",
							297,
							1488,
							73,
							1233,
							72,
							684
						],
						[
							"L",
							72,
							601
						],
						[
							"C",
							72,
							197,
							285,
							-21,
							634,
							-21
						],
						[
							"C",
							982,
							-21,
							1193,
							196,
							1193,
							535
						],
						[
							"C",
							1193,
							854,
							1006,
							1053,
							713,
							1053
						],
						[
							"C",
							527,
							1053,
							412,
							971,
							349,
							836
						],
						[
							"L",
							338,
							836
						],
						[
							"C",
							366,
							1108,
							470,
							1206,
							735,
							1208
						],
						[
							"C",
							969,
							1210,
							1071,
							1222,
							1165,
							1295
						],
						["Z"],
						[
							"M",
							636,
							243
						],
						[
							"C",
							506,
							243,
							429,
							348,
							429,
							521
						],
						[
							"C",
							429,
							696,
							507,
							795,
							635,
							795
						],
						[
							"C",
							761,
							795,
							838,
							696,
							838,
							521
						],
						[
							"C",
							838,
							348,
							761,
							243,
							636,
							243
						],
						["Z"]
					]
				},
				"в": {
					"a": 1191,
					"c": [
						[
							"M",
							115,
							0
						],
						[
							"L",
							671,
							0
						],
						[
							"C",
							965,
							0,
							1127,
							110,
							1127,
							306
						],
						[
							"C",
							1127,
							445,
							1015,
							567,
							792,
							580
						],
						[
							"C",
							963,
							610,
							1059,
							698,
							1059,
							814
						],
						[
							"C",
							1059,
							1011,
							882,
							1118,
							596,
							1118
						],
						[
							"L",
							115,
							1118
						],
						["Z"],
						[
							"M",
							439,
							254
						],
						[
							"L",
							439,
							469
						],
						[
							"L",
							671,
							469
						],
						[
							"C",
							748,
							469,
							794,
							426,
							794,
							357
						],
						[
							"C",
							794,
							293,
							748,
							254,
							671,
							254
						],
						["Z"],
						[
							"M",
							439,
							660
						],
						[
							"L",
							439,
							857
						],
						[
							"L",
							596,
							857
						],
						[
							"C",
							681,
							857,
							733,
							820,
							733,
							759
						],
						[
							"C",
							733,
							698,
							685,
							660,
							605,
							660
						],
						["Z"]
					]
				},
				"г": {
					"a": 941,
					"c": [
						[
							"M",
							907,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							464,
							0
						],
						[
							"L",
							464,
							850
						],
						[
							"L",
							907,
							850
						],
						["Z"]
					]
				},
				"д": {
					"a": 1402,
					"c": [
						[
							"M",
							35,
							-329
						],
						[
							"L",
							375,
							-329
						],
						[
							"L",
							375,
							0
						],
						[
							"L",
							1018,
							0
						],
						[
							"L",
							1018,
							-329
						],
						[
							"L",
							1348,
							-329
						],
						[
							"L",
							1348,
							269
						],
						[
							"L",
							1175,
							269
						],
						[
							"L",
							1175,
							1118
						],
						[
							"L",
							277,
							1118
						],
						[
							"L",
							250,
							773
						],
						[
							"C",
							235,
							580,
							219,
							323,
							119,
							269
						],
						[
							"L",
							35,
							269
						],
						["Z"],
						[
							"M",
							460,
							269
						],
						[
							"C",
							523,
							374,
							548,
							532,
							562,
							773
						],
						[
							"L",
							568,
							856
						],
						[
							"L",
							849,
							856
						],
						[
							"L",
							849,
							269
						],
						["Z"]
					]
				},
				"е": {
					"a": 1230,
					"c": [
						[
							"M",
							636,
							-21
						],
						[
							"C",
							907,
							-21,
							1090,
							102,
							1146,
							296
						],
						[
							"L",
							835,
							347
						],
						[
							"C",
							807,
							272,
							736,
							232,
							642,
							232
						],
						[
							"C",
							510,
							232,
							421,
							312,
							415,
							474
						],
						[
							"L",
							1162,
							474
						],
						[
							"L",
							1162,
							562
						],
						[
							"C",
							1162,
							931,
							937,
							1132,
							623,
							1132
						],
						[
							"C",
							287,
							1132,
							72,
							900,
							72,
							555
						],
						[
							"C",
							72,
							197,
							285,
							-21,
							636,
							-21
						],
						["Z"],
						[
							"M",
							417,
							677
						],
						[
							"C",
							430,
							800,
							503,
							879,
							626,
							879
						],
						[
							"C",
							748,
							879,
							817,
							804,
							831,
							677
						],
						["Z"]
					]
				},
				"ж": {
					"a": 1815,
					"c": [
						[
							"M",
							33,
							0
						],
						[
							"L",
							440,
							0
						],
						[
							"L",
							701,
							425
						],
						[
							"L",
							733,
							425
						],
						[
							"L",
							733,
							0
						],
						[
							"L",
							1082,
							0
						],
						[
							"L",
							1082,
							425
						],
						[
							"L",
							1115,
							425
						],
						[
							"L",
							1375,
							0
						],
						[
							"L",
							1782,
							0
						],
						[
							"L",
							1408,
							585
						],
						[
							"L",
							1781,
							1118
						],
						[
							"L",
							1384,
							1118
						],
						[
							"L",
							1117,
							691
						],
						[
							"L",
							1082,
							691
						],
						[
							"L",
							1082,
							1118
						],
						[
							"L",
							733,
							1118
						],
						[
							"L",
							733,
							691
						],
						[
							"L",
							698,
							691
						],
						[
							"L",
							431,
							1118
						],
						[
							"L",
							35,
							1118
						],
						[
							"L",
							407,
							585
						],
						["Z"]
					]
				},
				"з": {
					"a": 1084,
					"c": [
						[
							"M",
							538,
							-16
						],
						[
							"C",
							826,
							-16,
							1022,
							125,
							1022,
							322
						],
						[
							"C",
							1022,
							457,
							930,
							563,
							750,
							580
						],
						[
							"L",
							750,
							585
						],
						[
							"C",
							885,
							595,
							983,
							681,
							983,
							810
						],
						[
							"C",
							983,
							999,
							803,
							1133,
							544,
							1133
						],
						[
							"C",
							269,
							1133,
							87,
							981,
							86,
							775
						],
						[
							"L",
							416,
							775
						],
						[
							"C",
							417,
							838,
							465,
							875,
							538,
							875
						],
						[
							"C",
							611,
							875,
							655,
							832,
							655,
							771
						],
						[
							"C",
							655,
							700,
							602,
							664,
							518,
							664
						],
						[
							"L",
							423,
							664
						],
						[
							"L",
							423,
							467
						],
						[
							"L",
							518,
							467
						],
						[
							"C",
							609,
							467,
							663,
							429,
							663,
							357
						],
						[
							"C",
							663,
							297,
							613,
							252,
							533,
							252
						],
						[
							"C",
							456,
							252,
							405,
							295,
							404,
							364
						],
						[
							"L",
							66,
							364
						],
						[
							"C",
							67,
							156,
							232,
							-16,
							538,
							-16
						],
						["Z"]
					]
				},
				"и": {
					"a": 1301,
					"c": [
						[
							"M",
							1186,
							0
						],
						[
							"L",
							1186,
							1118
						],
						[
							"L",
							891,
							1118
						],
						[
							"L",
							471,
							526
						],
						[
							"L",
							464,
							526
						],
						[
							"L",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							403,
							0
						],
						[
							"L",
							830,
							598
						],
						[
							"L",
							837,
							598
						],
						[
							"L",
							837,
							0
						],
						["Z"]
					]
				},
				"к": {
					"a": 1229,
					"c": [
						[
							"M",
							115,
							0
						],
						[
							"L",
							464,
							0
						],
						[
							"L",
							464,
							406
						],
						[
							"L",
							564,
							406
						],
						[
							"L",
							819,
							0
						],
						[
							"L",
							1228,
							0
						],
						[
							"L",
							846,
							558
						],
						[
							"L",
							1225,
							1118
						],
						[
							"L",
							821,
							1118
						],
						[
							"L",
							538,
							674
						],
						[
							"L",
							464,
							674
						],
						[
							"L",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						["Z"]
					]
				},
				"л": {
					"a": 1261,
					"c": [
						[
							"M",
							20,
							0
						],
						[
							"L",
							135,
							0
						],
						[
							"C",
							369,
							0,
							527,
							136,
							545,
							550
						],
						[
							"L",
							559,
							850
						],
						[
							"L",
							796,
							850
						],
						[
							"L",
							796,
							0
						],
						[
							"L",
							1145,
							0
						],
						[
							"L",
							1145,
							1118
						],
						[
							"L",
							225,
							1118
						],
						[
							"L",
							206,
							596
						],
						[
							"C",
							198,
							353,
							151,
							269,
							54,
							269
						],
						[
							"L",
							20,
							269
						],
						["Z"]
					]
				},
				"м": {
					"a": 1698,
					"c": [
						[
							"M",
							115,
							0
						],
						[
							"L",
							453,
							0
						],
						[
							"L",
							453,
							383
						],
						[
							"C",
							453,
							479,
							444,
							687,
							440,
							860
						],
						[
							"C",
							479,
							684,
							534,
							500,
							573,
							383
						],
						[
							"L",
							704,
							0
						],
						[
							"L",
							994,
							0
						],
						[
							"L",
							1123,
							383
						],
						[
							"C",
							1160,
							496,
							1218,
							684,
							1257,
							869
						],
						[
							"C",
							1254,
							692,
							1246,
							481,
							1246,
							383
						],
						[
							"L",
							1246,
							0
						],
						[
							"L",
							1582,
							0
						],
						[
							"L",
							1582,
							1118
						],
						[
							"L",
							1046,
							1118
						],
						[
							"L",
							937,
							750
						],
						[
							"C",
							909,
							646,
							874,
							452,
							850,
							288
						],
						[
							"C",
							828,
							453,
							795,
							646,
							765,
							750
						],
						[
							"L",
							650,
							1118
						],
						[
							"L",
							115,
							1118
						],
						["Z"]
					]
				},
				"н": {
					"a": 1301,
					"c": [
						[
							"M",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							464,
							0
						],
						[
							"L",
							464,
							426
						],
						[
							"L",
							837,
							426
						],
						[
							"L",
							837,
							0
						],
						[
							"L",
							1186,
							0
						],
						[
							"L",
							1186,
							1118
						],
						[
							"L",
							837,
							1118
						],
						[
							"L",
							837,
							694
						],
						[
							"L",
							464,
							694
						],
						["Z"]
					]
				},
				"о": {
					"a": 1268,
					"c": [
						[
							"M",
							634,
							-21
						],
						[
							"C",
							983,
							-21,
							1195,
							211,
							1195,
							555
						],
						[
							"C",
							1195,
							900,
							983,
							1132,
							634,
							1132
						],
						[
							"C",
							284,
							1132,
							72,
							900,
							72,
							555
						],
						[
							"C",
							72,
							211,
							284,
							-21,
							634,
							-21
						],
						["Z"],
						[
							"M",
							634,
							246
						],
						[
							"C",
							500,
							246,
							428,
							371,
							428,
							557
						],
						[
							"C",
							428,
							744,
							500,
							865,
							634,
							865
						],
						[
							"C",
							768,
							865,
							840,
							744,
							840,
							557
						],
						[
							"C",
							840,
							371,
							768,
							246,
							634,
							246
						],
						["Z"]
					]
				},
				"п": {
					"a": 1277,
					"c": [
						[
							"M",
							1162,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							464,
							0
						],
						[
							"L",
							464,
							850
						],
						[
							"L",
							813,
							850
						],
						[
							"L",
							813,
							0
						],
						[
							"L",
							1162,
							0
						],
						["Z"]
					]
				},
				"р": {
					"a": 1306,
					"c": [
						[
							"M",
							115,
							-418
						],
						[
							"L",
							464,
							-418
						],
						[
							"L",
							464,
							181
						],
						[
							"L",
							472,
							181
						],
						[
							"C",
							516,
							80,
							615,
							-16,
							786,
							-16
						],
						[
							"C",
							1034,
							-16,
							1234,
							179,
							1234,
							558
						],
						[
							"C",
							1234,
							950,
							1023,
							1132,
							788,
							1132
						],
						[
							"C",
							610,
							1132,
							514,
							1027,
							472,
							926
						],
						[
							"L",
							460,
							926
						],
						[
							"L",
							460,
							1118
						],
						[
							"L",
							115,
							1118
						],
						["Z"],
						[
							"M",
							667,
							256
						],
						[
							"C",
							534,
							256,
							456,
							375,
							456,
							558
						],
						[
							"C",
							456,
							743,
							534,
							859,
							667,
							859
						],
						[
							"C",
							802,
							859,
							875,
							740,
							875,
							558
						],
						[
							"C",
							875,
							376,
							801,
							256,
							667,
							256
						],
						["Z"]
					]
				},
				"с": {
					"a": 1219,
					"c": [
						[
							"M",
							634,
							-21
						],
						[
							"C",
							922,
							-21,
							1115,
							134,
							1150,
							384
						],
						[
							"L",
							828,
							436
						],
						[
							"C",
							807,
							315,
							741,
							246,
							638,
							246
						],
						[
							"C",
							504,
							246,
							428,
							365,
							428,
							557
						],
						[
							"C",
							428,
							750,
							504,
							865,
							638,
							865
						],
						[
							"C",
							741,
							865,
							805,
							798,
							827,
							681
						],
						[
							"L",
							1149,
							735
						],
						[
							"C",
							1114,
							978,
							919,
							1132,
							634,
							1132
						],
						[
							"C",
							284,
							1132,
							72,
							900,
							72,
							555
						],
						[
							"C",
							72,
							211,
							284,
							-21,
							634,
							-21
						],
						["Z"]
					]
				},
				"т": {
					"a": 1082,
					"c": [
						[
							"M",
							367,
							0
						],
						[
							"L",
							715,
							0
						],
						[
							"L",
							715,
							851
						],
						[
							"L",
							1062,
							851
						],
						[
							"L",
							1062,
							1118
						],
						[
							"L",
							20,
							1118
						],
						[
							"L",
							20,
							851
						],
						[
							"L",
							367,
							851
						],
						["Z"]
					]
				},
				"у": {
					"a": 1266,
					"c": [
						[
							"M",
							112,
							-392
						],
						[
							"C",
							164,
							-412,
							248,
							-426,
							334,
							-426
						],
						[
							"C",
							585,
							-426,
							707,
							-299,
							775,
							-118
						],
						[
							"L",
							1244,
							1118
						],
						[
							"L",
							880,
							1118
						],
						[
							"L",
							701,
							571
						],
						[
							"C",
							671,
							476,
							646,
							381,
							623,
							280
						],
						[
							"C",
							604,
							381,
							586,
							475,
							557,
							571
						],
						[
							"L",
							390,
							1118
						],
						[
							"L",
							22,
							1118
						],
						[
							"L",
							439,
							-2
						],
						[
							"L",
							440,
							-49
						],
						[
							"C",
							445,
							-140,
							360,
							-183,
							234,
							-149
						],
						[
							"L",
							190,
							-137
						],
						["Z"]
					]
				},
				"ф": {
					"a": 1693,
					"c": [
						[
							"M",
							671,
							-379
						],
						[
							"L",
							1020,
							-379
						],
						[
							"L",
							1020,
							-21
						],
						[
							"C",
							1374,
							-21,
							1621,
							216,
							1621,
							555
						],
						[
							"C",
							1621,
							895,
							1374,
							1132,
							1020,
							1132
						],
						[
							"L",
							1020,
							1490
						],
						[
							"L",
							671,
							1490
						],
						[
							"L",
							671,
							1132
						],
						[
							"C",
							318,
							1132,
							72,
							895,
							72,
							555
						],
						[
							"C",
							72,
							216,
							318,
							-21,
							671,
							-21
						],
						["Z"],
						[
							"M",
							1020,
							865
						],
						[
							"C",
							1169,
							865,
							1262,
							731,
							1262,
							555
						],
						[
							"C",
							1262,
							379,
							1169,
							246,
							1020,
							246
						],
						["Z"],
						[
							"M",
							671,
							246
						],
						[
							"C",
							525,
							246,
							432,
							379,
							432,
							555
						],
						[
							"C",
							432,
							731,
							523,
							865,
							671,
							865
						],
						["Z"]
					]
				},
				"х": {
					"a": 1217,
					"c": [
						[
							"M",
							33,
							0
						],
						[
							"L",
							396,
							0
						],
						[
							"L",
							502,
							194
						],
						[
							"C",
							540,
							265,
							572,
							338,
							603,
							410
						],
						[
							"C",
							636,
							338,
							670,
							265,
							708,
							194
						],
						[
							"L",
							816,
							0
						],
						[
							"L",
							1184,
							0
						],
						[
							"L",
							834,
							572
						],
						[
							"L",
							1169,
							1118
						],
						[
							"L",
							805,
							1118
						],
						[
							"L",
							715,
							958
						],
						[
							"C",
							676,
							888,
							643,
							814,
							611,
							742
						],
						[
							"C",
							579,
							814,
							547,
							887,
							510,
							958
						],
						[
							"L",
							424,
							1118
						],
						[
							"L",
							54,
							1118
						],
						[
							"L",
							380,
							574
						],
						["Z"]
					]
				},
				"ч": {
					"a": 1251,
					"c": [
						[
							"M",
							660,
							312
						],
						[
							"C",
							697,
							312,
							742,
							317,
							786,
							325
						],
						[
							"L",
							786,
							0
						],
						[
							"L",
							1135,
							0
						],
						[
							"L",
							1135,
							1118
						],
						[
							"L",
							786,
							1118
						],
						[
							"L",
							786,
							593
						],
						[
							"C",
							743,
							584,
							701,
							580,
							660,
							580
						],
						[
							"C",
							514,
							580,
							464,
							615,
							464,
							731
						],
						[
							"L",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							731
						],
						[
							"C",
							115,
							449,
							300,
							312,
							660,
							312
						],
						["Z"]
					]
				},
				"ш": {
					"a": 1792,
					"c": [
						[
							"M",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							1676,
							0
						],
						[
							"L",
							1676,
							1118
						],
						[
							"L",
							1328,
							1118
						],
						[
							"L",
							1328,
							268
						],
						[
							"L",
							1061,
							268
						],
						[
							"L",
							1061,
							1118
						],
						[
							"L",
							731,
							1118
						],
						[
							"L",
							731,
							268
						],
						[
							"L",
							464,
							268
						],
						[
							"L",
							464,
							1118
						],
						["Z"]
					]
				},
				"ы": {
					"a": 1710,
					"c": [
						[
							"M",
							464,
							791
						],
						[
							"L",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							667,
							0
						],
						[
							"C",
							974,
							0,
							1162,
							156,
							1162,
							392
						],
						[
							"C",
							1162,
							634,
							974,
							791,
							667,
							791
						],
						["Z"],
						[
							"M",
							1246,
							0
						],
						[
							"L",
							1595,
							0
						],
						[
							"L",
							1595,
							1118
						],
						[
							"L",
							1246,
							1118
						],
						["Z"],
						[
							"M",
							464,
							523
						],
						[
							"L",
							667,
							523
						],
						[
							"C",
							764,
							523,
							823,
							474,
							823,
							392
						],
						[
							"C",
							823,
							314,
							764,
							268,
							667,
							268
						],
						[
							"L",
							464,
							268
						],
						["Z"]
					]
				},
				"ь": {
					"a": 1234,
					"c": [
						[
							"M",
							464,
							791
						],
						[
							"L",
							464,
							1118
						],
						[
							"L",
							115,
							1118
						],
						[
							"L",
							115,
							0
						],
						[
							"L",
							667,
							0
						],
						[
							"C",
							974,
							0,
							1162,
							156,
							1162,
							392
						],
						[
							"C",
							1162,
							634,
							974,
							791,
							667,
							791
						],
						["Z"],
						[
							"M",
							464,
							523
						],
						[
							"L",
							667,
							523
						],
						[
							"C",
							764,
							523,
							823,
							474,
							823,
							392
						],
						[
							"C",
							823,
							314,
							764,
							268,
							667,
							268
						],
						[
							"L",
							464,
							268
						],
						["Z"]
					]
				},
				"э": {
					"a": 1219,
					"c": [
						[
							"M",
							585,
							-21
						],
						[
							"C",
							938,
							-21,
							1147,
							213,
							1147,
							555
						],
						[
							"C",
							1147,
							898,
							936,
							1132,
							586,
							1132
						],
						[
							"C",
							278,
							1132,
							78,
							954,
							70,
							682
						],
						[
							"L",
							396,
							682
						],
						[
							"C",
							410,
							795,
							477,
							865,
							580,
							865
						],
						[
							"C",
							686,
							865,
							761,
							792,
							784,
							654
						],
						[
							"L",
							485,
							654
						],
						[
							"L",
							485,
							466
						],
						[
							"L",
							785,
							466
						],
						[
							"C",
							763,
							324,
							688,
							246,
							580,
							246
						],
						[
							"C",
							482,
							246,
							410,
							315,
							396,
							434
						],
						[
							"L",
							70,
							434
						],
						[
							"C",
							79,
							160,
							273,
							-21,
							585,
							-21
						],
						["Z"]
					]
				}
			}
		}
	]
};
var W = 330;
var H = 120;
var SS = 2;
var SW = W * SS;
var SH = 240;
var rnd = (a, b) => a + randomInt(0, 1e6) / 1e6 * (b - a);
var pick = (arr) => arr[randomInt(0, arr.length)];
function normalizeCaptchaAnswer(s) {
	return (s || "").toLowerCase().replace(/ё/g, "е").replace(/[^а-яa-z]/g, "");
}
function randomCaptchaWord() {
	return pick(DATA.words);
}
function hsl(h, s, l) {
	s /= 100;
	l /= 100;
	const k = (n) => (n + h / 30) % 12;
	const a = s * Math.min(l, 1 - l);
	const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
	return [
		Math.round(f(0) * 255),
		Math.round(f(8) * 255),
		Math.round(f(4) * 255)
	];
}
function flatten(cmds) {
	const polys = [];
	let cur = [];
	let x = 0;
	let y = 0;
	for (const c of cmds) {
		const op = c[0];
		const n = c.slice(1);
		if (op === "M") {
			if (cur.length > 2) polys.push(cur);
			cur = [[n[0], n[1]]];
			[x, y] = [n[0], n[1]];
		} else if (op === "L") {
			cur.push([n[0], n[1]]);
			[x, y] = [n[0], n[1]];
		} else if (op === "Q") {
			for (let i = 1; i <= 8; i++) {
				const t = i / 8;
				const u = 1 - t;
				cur.push([u * u * x + 2 * u * t * n[0] + t * t * n[2], u * u * y + 2 * u * t * n[1] + t * t * n[3]]);
			}
			[x, y] = [n[2], n[3]];
		} else if (op === "C") {
			for (let i = 1; i <= 10; i++) {
				const t = i / 10;
				const u = 1 - t;
				cur.push([u * u * u * x + 3 * u * u * t * n[0] + 3 * u * t * t * n[2] + t * t * t * n[4], u * u * u * y + 3 * u * u * t * n[1] + 3 * u * t * t * n[3] + t * t * t * n[5]]);
			}
			[x, y] = [n[4], n[5]];
		} else if (op === "Z") {
			if (cur.length > 2) polys.push(cur);
			cur = [];
		}
	}
	if (cur.length > 2) polys.push(cur);
	return polys;
}
function fillPolys(buf, polys, paint, alpha) {
	let minY = Infinity;
	let maxY = -Infinity;
	for (const p of polys) for (const [, y] of p) {
		if (y < minY) minY = y;
		if (y > maxY) maxY = y;
	}
	const y0 = Math.max(0, Math.floor(minY));
	const y1 = Math.min(239, Math.ceil(maxY));
	for (let py = y0; py <= y1; py++) {
		const sy = py + .5;
		const xs = [];
		for (const p of polys) for (let i = 0; i < p.length; i++) {
			const [ax, ay] = p[i];
			const [bx, by] = p[(i + 1) % p.length];
			if (ay === by) continue;
			if (sy >= ay && sy < by || sy >= by && sy < ay) xs.push({
				x: ax + (sy - ay) / (by - ay) * (bx - ax),
				d: by > ay ? 1 : -1
			});
		}
		xs.sort((a, b) => a.x - b.x);
		const col = typeof paint === "function" ? paint(py) : paint;
		let wind = 0;
		for (let i = 0; i < xs.length - 1; i++) {
			wind += xs[i].d;
			if (wind === 0) continue;
			const from = Math.max(0, Math.ceil(xs[i].x - .5));
			const to = Math.min(659, Math.floor(xs[i + 1].x - .5));
			for (let px = from; px <= to; px++) {
				const o = (py * SW + px) * 3;
				buf[o] = buf[o] + (col[0] - buf[o]) * alpha;
				buf[o + 1] = buf[o + 1] + (col[1] - buf[o + 1]) * alpha;
				buf[o + 2] = buf[o + 2] + (col[2] - buf[o + 2]) * alpha;
			}
		}
	}
}
function disc(buf, cx, cy, r, col, alpha) {
	for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(239, Math.ceil(cy + r)); y++) for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(659, Math.ceil(cx + r)); x++) {
		if ((x - cx) ** 2 + (y - cy) ** 2 > r * r) continue;
		const o = (y * SW + x) * 3;
		buf[o] = buf[o] + (col[0] - buf[o]) * alpha;
		buf[o + 1] = buf[o + 1] + (col[1] - buf[o + 1]) * alpha;
		buf[o + 2] = buf[o + 2] + (col[2] - buf[o + 2]) * alpha;
	}
}
function noiseLine(buf, col, width) {
	const yA = rnd(.15, .85) * SH;
	const yB = rnd(.15, .85) * SH;
	const amp = rnd(6, 22) * SS;
	const fr = rnd(.006, .02) / SS;
	const ph = rnd(0, Math.PI * 2);
	for (let x = 0; x < SW; x += 1.5) {
		const y = yA + (yB - yA) * x / SW + amp * Math.sin(x * fr + ph);
		disc(buf, x, y, width * SS * .5, col, .9);
	}
}
var crcTable = null;
function crc32(b) {
	if (!crcTable) {
		crcTable = /* @__PURE__ */ new Uint32Array(256);
		for (let n = 0; n < 256; n++) {
			let c = n;
			for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
			crcTable[n] = c >>> 0;
		}
	}
	let c = 4294967295;
	for (let i = 0; i < b.length; i++) c = crcTable[(c ^ b[i]) & 255] ^ c >>> 8;
	return (c ^ 4294967295) >>> 0;
}
function chunk(type, data) {
	const len = Buffer.alloc(4);
	len.writeUInt32BE(data.length);
	const td = Buffer.concat([Buffer.from(type, "ascii"), data]);
	const crc = Buffer.alloc(4);
	crc.writeUInt32BE(crc32(td));
	return Buffer.concat([
		len,
		td,
		crc
	]);
}
function encodePng(rgb, w, h) {
	const raw = Buffer.alloc((w * 3 + 1) * h);
	for (let y = 0; y < h; y++) {
		raw[y * (w * 3 + 1)] = 0;
		Buffer.from(rgb.buffer, rgb.byteOffset + y * w * 3, w * 3).copy(raw, y * (w * 3 + 1) + 1);
	}
	const ihdr = Buffer.alloc(13);
	ihdr.writeUInt32BE(w, 0);
	ihdr.writeUInt32BE(h, 4);
	ihdr[8] = 8;
	ihdr[9] = 2;
	return Buffer.concat([
		Buffer.from([
			137,
			80,
			78,
			71,
			13,
			10,
			26,
			10
		]),
		chunk("IHDR", ihdr),
		chunk("IDAT", deflateSync(raw, { level: 9 })),
		chunk("IEND", Buffer.alloc(0))
	]);
}
function renderCaptcha(word) {
	const buf = new Uint8ClampedArray(SW * SH * 3);
	const c1 = hsl(rnd(30, 45), rnd(10, 30), rnd(3, 7));
	const c2 = hsl(rnd(32, 48), rnd(30, 55), rnd(11, 17));
	for (let y = 0; y < SH; y++) for (let x = 0; x < SW; x++) {
		const t = x / SW * .6 + y / SH * .4;
		const o = (y * SW + x) * 3;
		buf[o] = c1[0] + (c2[0] - c1[0]) * t;
		buf[o + 1] = c1[1] + (c2[1] - c1[1]) * t;
		buf[o + 2] = c1[2] + (c2[2] - c1[2]) * t;
	}
	const letterCol = () => hsl(rnd(34, 50), rnd(65, 95), rnd(48, 78));
	const goldGradient = (top, bottom) => {
		const a = hsl(rnd(40, 50), rnd(80, 100), rnd(74, 86));
		const b = hsl(rnd(30, 40), rnd(65, 85), rnd(42, 54));
		return (y) => {
			const t = Math.max(0, Math.min(1, (y - top) / Math.max(1, bottom - top)));
			return [
				a[0] + (b[0] - a[0]) * t,
				a[1] + (b[1] - a[1]) * t,
				a[2] + (b[2] - a[2]) * t
			];
		};
	};
	for (let i = 0; i < 420; i++) disc(buf, rnd(0, SW), rnd(0, SH), rnd(.6, 1.8) * SS, letterCol(), rnd(.2, .5));
	for (let i = 0; i < 3; i++) noiseLine(buf, letterCol(), rnd(1.5, 2.5));
	const font = pick(DATA.fonts);
	const letters = [...word];
	const scale = rnd(54, 64) * SS / font.upm;
	const advs = letters.map((ch) => (font.g[ch]?.a || font.upm * .6) * scale * rnd(.78, .92));
	let total = advs.reduce((a, b) => a + b, 0);
	const fit = Math.min(1, SW * .86 / total);
	total *= fit;
	let penX = (SW - total) / 2;
	const baseY = SH * .68;
	const wa = rnd(4, 9) * SS;
	const wf = rnd(.012, .03) / SS;
	const wp = rnd(0, Math.PI * 2);
	const wa2 = rnd(2, 5) * SS;
	const wf2 = rnd(.02, .05) / SS;
	for (let i = 0; i < letters.length; i++) {
		const g = font.g[letters[i]];
		const adv = advs[i] * fit;
		if (g) {
			const s = scale * fit * rnd(.88, 1.18);
			const sx = rnd(.85, 1.12);
			const rot = rnd(-28, 28) * Math.PI / 180;
			const shear = rnd(-.28, .28);
			const cosr = Math.cos(rot);
			const sinr = Math.sin(rot);
			const ox = penX + adv / 2;
			const oy = baseY + rnd(-10, 10) * SS;
			const cx = g.a / 2 * scale;
			const cy = font.upm * .35 * scale;
			const polys = flatten(g.c).map((poly) => poly.map(([fx, fy]) => {
				let x = fx * s * sx - cx;
				let y = -fy * s + cy;
				x += shear * y;
				const rx = x * cosr - y * sinr + ox;
				const ry = x * sinr + y * cosr + oy - cy;
				return [rx + wa2 * Math.sin(ry * wf2 + wp), ry + wa * Math.sin(rx * wf + wp)];
			}));
			let top = Infinity;
			let bottom = -Infinity;
			for (const poly of polys) for (const [, y] of poly) {
				if (y < top) top = y;
				if (y > bottom) bottom = y;
			}
			fillPolys(buf, polys, goldGradient(top, bottom), .97);
		}
		penX += adv;
	}
	for (let i = 0; i < randomInt(2, 4); i++) noiseLine(buf, letterCol(), rnd(1.2, 2.2));
	const out = new Uint8Array(W * H * 3);
	for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) for (let k = 0; k < 3; k++) {
		let sum = 0;
		for (let dy = 0; dy < SS; dy++) for (let dx = 0; dx < SS; dx++) sum += buf[((y * SS + dy) * SW + (x * SS + dx)) * 3 + k];
		out[(y * W + x) * 3 + k] = Math.round(sum / 4);
	}
	return encodePng(out, W, H);
}
var CUSTOM_EMOJI = {
	"👤": "6032693626394382504",
	"✏️": "6039779802741739617",
	"📄": "6034969813032374911",
	"💰": "5778421276024509124",
	"📎": "6039451237743595514",
	"📝": "5922693616953725714",
	"📊": "5936143551854285132"
};
var KEYS = Object.keys(CUSTOM_EMOJI).sort((a, b) => b.length - a.length);
function escapeRegExp(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function applyCustomEmoji(text) {
	let out = text;
	for (const base of KEYS) {
		const id = CUSTOM_EMOJI[base];
		out = out.replace(new RegExp(escapeRegExp(base), "g"), `<tg-emoji emoji-id="${id}">${base}</tg-emoji>`);
	}
	return out;
}
function hasCustomEmoji(text) {
	return /<tg-emoji\b/.test(text);
}
var BUTTON_EMOJI = {
	"🛡": "6030445631921721471",
	"📝": "5922693616953725714",
	"📣": "6039422865189638057",
	"👥": "6032609071373226027",
	"🌐": "5776233299424843260",
	"⬅️": "5960671702059848143",
	"✅": "5774022692642492953",
	"🔎": "6032850693348399258",
	"🌟": "5805331990618053402"
};
var BTN_KEYS = Object.keys(BUTTON_EMOJI).sort((a, b) => b.length - a.length);
function decorateButtons(markup, useIcons) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return markup;
	const rows = m.inline_keyboard.map((row) => row.map((btn) => {
		const text = typeof btn.text === "string" ? btn.text : "";
		if (!useIcons || !text) return { ...btn };
		for (const emoji of BTN_KEYS) if (text.startsWith(emoji + " ")) return {
			...btn,
			text: text.slice(emoji.length + 1),
			icon_custom_emoji_id: BUTTON_EMOJI[emoji]
		};
		return { ...btn };
	}));
	return {
		...markup,
		inline_keyboard: rows
	};
}
function markupHasIconableButton(markup) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return false;
	return m.inline_keyboard.some((row) => row.some((btn) => typeof btn.text === "string" && BTN_KEYS.some((e) => btn.text.startsWith(e + " "))));
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	allowCheck: () => allowCheck,
	allowEvidenceChunk: () => allowEvidenceChunk,
	allowEvidenceDownload: () => allowEvidenceDownload,
	allowEvidenceUpload: () => allowEvidenceUpload,
	appAccess: () => appAccess,
	appendEvidenceChunk: () => appendEvidenceChunk,
	bannerById: () => bannerById,
	bannerFilePath: () => bannerFilePath,
	blacklistEntry: () => blacklistEntry,
	captchaRequired: () => captchaRequired,
	checkCounterparty: () => checkCounterparty,
	configureFromOrigin: () => configureFromOrigin,
	consumeSubmitPass: () => consumeSubmitPass,
	diagnoseUserSearch: () => diagnoseUserSearch,
	evidenceBytesOnDisk: () => evidenceBytesOnDisk,
	evidenceOwnedBy: () => evidenceOwnedBy,
	featuresEnabled: () => featuresEnabled,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	hasSubmitPass: () => hasSubmitPass,
	hasUserbot: () => hasUserbot,
	isBannedUser: () => isBannedUser,
	isDisconnectError: () => isDisconnectError,
	listBanners: () => listBanners,
	listComplaintsForUser: () => listComplaintsForUser,
	listSponsors: () => listSponsors,
	newCaptchaImage: () => newCaptchaImage,
	postMatchesSubject: () => postMatchesSubject,
	recentBlacklist: () => recentBlacklist,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveChannelAsUser: () => resolveChannelAsUser,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	saveUserLocaleServer: () => saveUserLocaleServer,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	setAudienceBase: () => setAudienceBase,
	setSponsorLink: () => setSponsorLink,
	solveCaptcha: () => solveCaptcha,
	sponsorAvatarPath: () => sponsorAvatarPath,
	sponsorStats: () => sponsorStats,
	uploadedEvidencePath: () => uploadedEvidencePath,
	userbotStatus: () => userbotStatus,
	verifyAccountPair: () => verifyAccountPair,
	verifyEvidenceDownload: () => verifyEvidenceDownload,
	verifyTelegramInitData: () => verifyTelegramInitData,
	webhookSecret: () => webhookSecret,
	webhookSecretMatches: () => webhookSecretMatches
});
function botToken() {
	return process.env.TELEGRAM_BOT_TOKEN || "";
}
var warnedMissingToken = false;
function requireToken() {
	const token = botToken();
	if (!token && !warnedMissingToken) {
		warnedMissingToken = true;
		console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
	}
	return token;
}
function isDisconnectError(err) {
	const any = err;
	const code = String(any?.code || any?.cause?.code || "");
	const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
	return code === "ECONNRESET" || code === "EPIPE" || code === "ECONNABORTED" || code === "ERR_STREAM_PREMATURE_CLOSE" || /aborted|socket hang up|ECONNRESET|premature close/i.test(msg);
}
function installDisconnectGuards() {
	const swallow = (err) => {
		if (isDisconnectError(err)) return;
		console.error("[epb]", err);
	};
	process.on("uncaughtException", swallow);
	process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
function botApi() {
	return `https://api.telegram.org/bot${requireToken()}`;
}
var BOT_USERNAME = "EuropeBlack_bot";
function webhookSecret() {
	return `epb-${createHash("sha256").update(botToken()).digest("hex").slice(0, 24)}`;
}
function webhookSecretMatches(header) {
	const expected = webhookSecret();
	const got = String(header || "");
	const a = Buffer.from(got);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var RELAY_PATH = join(DATA_DIR, "telegram-relay-chats.json");
var BACKUP_DIR = join(DATA_DIR, "backups");
function writeJsonAtomic(path, value) {
	mkdirSync(dirname(path), { recursive: true });
	const tmp = `${path}.${process.pid}.tmp`;
	writeFileSync(tmp, JSON.stringify(value, null, 2));
	renameSync(tmp, path);
}
function readJson(path) {
	try {
		return JSON.parse(readFileSync(path, "utf8"));
	} catch {
		return null;
	}
}
function latestBackup(prefix) {
	try {
		const names = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		return names.length ? join(BACKUP_DIR, names[names.length - 1]) : null;
	} catch {
		return null;
	}
}
function backupDaily(prefix, value) {
	try {
		const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		writeJsonAtomic(join(BACKUP_DIR, `${prefix}-${day}.json`), value);
		const old = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		for (const name of old.slice(0, Math.max(0, old.length - 30))) unlinkSync(join(BACKUP_DIR, name));
	} catch {}
}
function mergeRelayLists(...lists) {
	const out = [];
	for (const list of lists) for (const chat of list || []) {
		if (!chat?.id) continue;
		const idx = out.findIndex((c) => sameChat(c.id, chat.id));
		if (idx < 0) out.push({
			...chat,
			id: String(chat.id)
		});
		else if (out[idx].status !== "on" && chat.status === "on") out[idx] = {
			...out[idx],
			...chat
		};
	}
	return out;
}
var bindingsLoadFailed = false;
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v4-admin";
function loadBindings() {
	let raw = readJson(BINDINGS_PATH);
	if (!raw && existsSync(BINDINGS_PATH)) {
		const backup = latestBackup("telegram-bindings");
		raw = backup ? readJson(backup) : null;
		if (!raw) {
			if (!bindingsLoadFailed) console.error("[epb] telegram-bindings.json is unreadable and there is no backup; it will not be overwritten");
			bindingsLoadFailed = true;
		}
	}
	const loaded = raw || {};
	const relayFile = readJson(RELAY_PATH);
	const relayBackup = relayFile ? null : readJson(latestBackup("telegram-relay-chats") || "");
	loaded.relayChats = mergeRelayLists(loaded.relayChats, relayFile, relayBackup);
	return loaded;
}
function invalidateCheckCache() {
	try {
		checkCache.clear();
	} catch {}
}
function saveBindings() {
	invalidateCheckCache();
	if (bindingsLoadFailed) return;
	try {
		writeJsonAtomic(BINDINGS_PATH, bindings);
		writeJsonAtomic(RELAY_PATH, bindings.relayChats || []);
		backupDaily("telegram-bindings", bindings);
		backupDaily("telegram-relay-chats", bindings.relayChats || []);
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids-verified.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var LOCALES_PATH = join(DATA_DIR, "telegram-locales.json");
var userLocales = {};
try {
	if (existsSync(LOCALES_PATH)) {
		const raw = JSON.parse(readFileSync(LOCALES_PATH, "utf8"));
		for (const [id, value] of Object.entries(raw || {})) if (isLocale(value)) userLocales[id] = value;
	}
} catch {
	userLocales = {};
}
function saveLocales() {
	try {
		writeJsonAtomic(LOCALES_PATH, userLocales);
	} catch {}
}
function langOf(userId) {
	return userLocales[String(userId || "")] === "en" ? "en" : "ru";
}
function hasLang(userId) {
	return isLocale(userLocales[String(userId || "")]);
}
function setLang(userId, locale) {
	userLocales[String(userId)] = locale;
	saveLocales();
}
function saveUserLocaleServer(userId, locale) {
	if (!isLocale(locale)) return;
	setLang(userId, locale);
}
function btUser(userId, key, vars) {
	return tb(langOf(userId), key, vars);
}
var idCache = {};
var legacyIds = {};
var pendingPosts = {};
legacyIds = readJson(join(DATA_DIR, "telegram-ids.json")) || {};
idCache = {
	...KNOWN_TELEGRAM_IDS,
	...readJson(ID_CACHE_PATH) || {}
};
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
for (const rec of Object.values(pendingPosts)) if (rec.status === "published" && rec.channelPosted === void 0) rec.channelPosted = true;
var BLACKLIST_CLEANUP = [
	"hugos",
	"mkcrd",
	"annuit1",
	"ballin812"
];
var BLACKLIST_CLEANUP_STAMP = "cleanup-v2";
if (bindings.blacklistCleanupStamp !== BLACKLIST_CLEANUP_STAMP) {
	let changed = false;
	for (const rec of Object.values(pendingPosts)) {
		if (rec.removedFromCheck) continue;
		if (pendingAccounts(rec).map((a) => a.username.replace(/^@/, "").toLowerCase()).some((n) => BLACKLIST_CLEANUP.includes(n))) {
			rec.removedFromCheck = true;
			changed = true;
		}
	}
	if (changed) savePending();
	bindings.blacklistCleanupStamp = BLACKLIST_CLEANUP_STAMP;
	saveBindings();
}
var FINDS_CLEANUP_STAMP = "finds-v1";
if (bindings.findsCleanupStamp !== FINDS_CLEANUP_STAMP) {
	if (bindings.recentFinds?.length) bindings.recentFinds = [];
	bindings.findsCleanupStamp = FINDS_CLEANUP_STAMP;
	saveBindings();
}
var idCacheTimer = null;
function saveIdCache() {
	if (idCacheTimer) return;
	idCacheTimer = setTimeout(() => {
		idCacheTimer = null;
		try {
			writeJsonAtomic(ID_CACHE_PATH, idCache);
		} catch {}
	}, 2e3);
}
function savePending() {
	invalidateCheckCache();
	try {
		const entries = Object.entries(pendingPosts);
		if (entries.length > 1200) {
			const drop = entries.filter(([, rec]) => rec.status === "published" || rec.status === "rejected").sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
			const extra = entries.length - 1e3;
			for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
		}
		writeJsonAtomic(PENDING_PATH, pendingPosts);
	} catch {}
}
function rememberUser(user) {
	if (!user?.id || !user.username) return;
	rememberHandle(user.username, String(user.id));
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	const keys = Object.keys(idCache);
	if (keys.length > 8e3) for (const extra of keys.slice(0, keys.length - 7e3)) delete idCache[extra];
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
var MAX_EVIDENCE_FILE = 1073741824;
var MAX_EVIDENCE_CHUNK = 2097152;
function sanitizeEvidenceId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9_-]/g, "");
	if (!safe || safe.length < 8 || safe.length > 80) return null;
	if (safe === ".." || safe.startsWith(".")) return null;
	return safe;
}
function evidenceOwnerPath(id) {
	return join(EVIDENCE_DIR, `${id}.own`);
}
function writeEvidenceOwner(id, userId) {
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(evidenceOwnerPath(id), String(userId || ""));
}
function readEvidenceOwner(id) {
	try {
		return readFileSync(evidenceOwnerPath(id), "utf8").trim();
	} catch {
		return "";
	}
}
function evidenceOwnedBy(id, userId) {
	const safe = sanitizeEvidenceId(id || "");
	if (!safe || !userId) return false;
	return readEvidenceOwner(safe) === userId && Boolean(uploadedEvidencePath(safe));
}
function evidenceHmacKey() {
	return createHmac("sha256", "EvidenceGet").update(botToken() || "none").digest();
}
function evidenceSig(key, exp) {
	return createHmac("sha256", evidenceHmacKey()).update(`${key}.${exp}`).digest("hex").slice(0, 32);
}
function verifyEvidenceDownload(key, exp, sig) {
	const safe = sanitizeEvidenceId(key);
	if (!safe) return false;
	const expMs = Number(exp);
	if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
	if (expMs > Date.now() + 1728e5) return false;
	const expect = evidenceSig(safe, expMs);
	const a = Buffer.from(expect, "hex");
	const b = Buffer.from(String(sig || ""), "hex");
	if (a.length !== b.length || a.length === 0) return false;
	return timingSafeEqual(a, b);
}
function isAllowedEvidenceMagic(bytes) {
	if (!bytes.length) return false;
	const head = bytes.subarray(0, 256).toString("utf8").replace(/^\uFEFF/, "").trimStart().toLowerCase();
	if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<script") || head.startsWith("<svg") || head.startsWith("<?xml") || head.startsWith("<?php") || head.startsWith("#!") || head.startsWith("import ") || head.startsWith("function ") || head.startsWith("const ") || head.startsWith("var ") || head.startsWith("{")) return false;
	if (bytes[0] === 77 && bytes[1] === 90) return false;
	if (bytes[0] === 127 && bytes[1] === 69 && bytes[2] === 76 && bytes[3] === 70) return false;
	if (bytes[0] === 202 && bytes[1] === 254 && bytes[2] === 186 && bytes[3] === 190) return false;
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return true;
	if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) return true;
	if (bytes.length >= 6 && bytes.subarray(0, 3).toString("ascii") === "GIF") return true;
	if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && (bytes.subarray(8, 12).toString("ascii") === "WEBP" || bytes.subarray(8, 12).toString("ascii") === "AVI ")) return true;
	if (bytes.length >= 4 && bytes[0] === 26 && bytes[1] === 69 && bytes[2] === 223 && bytes[3] === 163) return true;
	if (bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp") return true;
	return false;
}
function saveUploadedEvidence(userId, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
	if (!isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const id = randomUUID();
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	writeEvidenceOwner(id, userId);
	pruneEvidenceDir();
	return id;
}
var chunkCursor = /* @__PURE__ */ new Map();
function appendEvidenceChunk(userId, requestedId, index, total, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const safe = index === 0 ? randomUUID() : sanitizeEvidenceId(requestedId);
	if (!safe) throw new Error("bad chunk");
	if (index === 0 && !isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	if (index > 0 && readEvidenceOwner(safe) !== userId) throw new Error("forbidden");
	if (index === 0) writeEvidenceOwner(safe, userId);
	const part = join(EVIDENCE_DIR, `${safe}.part`);
	const dest = join(EVIDENCE_DIR, safe);
	const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
	if (existsSync(dest) && readEvidenceOwner(safe) === userId) return safe;
	const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
	if (index < expected) return safe;
	if (index !== expected) throw new Error("chunk order");
	if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
	if (index === 0) {
		if (existsSync(part)) unlinkSync(part);
		if (existsSync(dest)) unlinkSync(dest);
	}
	if ((existsSync(part) ? statSync(part).size : 0) + bytes.length > MAX_EVIDENCE_FILE) {
		try {
			unlinkSync(part);
		} catch {}
		chunkCursor.delete(safe);
		throw new Error("file too large");
	}
	appendFileSync(part, bytes);
	const next = index + 1;
	chunkCursor.set(safe, next);
	writeFileSync(idxPath, String(next));
	if (index !== total - 1) return safe;
	if (existsSync(dest)) unlinkSync(dest);
	renameSync(part, dest);
	try {
		unlinkSync(idxPath);
	} catch {}
	chunkCursor.delete(safe);
	pruneEvidenceDir();
	return safe;
}
function evidenceBytesOnDisk(id) {
	const path = id ? uploadedEvidencePath(id) : null;
	if (!path) return 0;
	try {
		return statSync(path).size;
	} catch {
		return 0;
	}
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	if (rateHits.size > 4e3) for (const [k, hits] of rateHits) {
		const keep = hits.filter((t) => now - t < 216e5);
		if (!keep.length) rateHits.delete(k);
		else rateHits.set(k, keep);
	}
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function isBannedUser(id, username) {
	if (id != null && isOwner(id)) return false;
	const uid = id != null ? String(id) : "";
	const un = (username || "").replace(/^@/, "").toLowerCase();
	return (bindings.bannedUsers || []).some((b) => uid && b.id === uid || un && (b.username || "").toLowerCase() === un);
}
function verifyTelegramInitData(initData) {
	const u = verifyInitDataRaw(initData);
	if (!u || isBannedUser(u.id, u.username)) return null;
	return u;
}
function appAccess(initData) {
	const u = verifyInitDataRaw(initData);
	if (!u) return {
		ok: false,
		banned: false
	};
	return {
		ok: true,
		banned: isBannedUser(u.id, u.username)
	};
}
function verifyInitDataRaw(initData) {
	if (!botToken() || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const groups = /* @__PURE__ */ new Map();
		for (const name of readdirSync(EVIDENCE_DIR)) {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			const key = name.replace(/\.(own|part|idx)$/, "");
			const group = groups.get(key) || {
				paths: [],
				mtime: 0,
				size: 0
			};
			group.paths.push(path);
			group.mtime = Math.max(group.mtime, st.mtimeMs);
			group.size += st.size;
			groups.set(key, group);
		}
		const list = [...groups.values()].sort((a, b) => a.mtime - b.mtime);
		let total = list.reduce((sum, g) => sum + g.size, 0);
		const maxBytes = 8589934592;
		const maxUploads = 400;
		const fresh = Date.now() - 18e5;
		let count = list.length;
		for (const group of list) {
			if (count <= maxUploads && total <= maxBytes) break;
			if (group.mtime > fresh) break;
			for (const path of group.paths) try {
				unlinkSync(path);
			} catch {}
			total -= group.size;
			count -= 1;
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes = 1) {
	if (bytes < 0) return {
		ok: false,
		error: "file required"
	};
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("up:global", 2e3, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowEvidenceDownload() {
	return !tooMany("evget:global", 240, 6e4);
}
function allowEvidenceChunk(initData, bytes) {
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("upchunk:global", 2e3, 6e4)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowNewComplaint(userId, storyLen) {
	const loc = langOf(userId);
	if (storyLen > 5e3) return tb(loc, "storyLong");
	if (tooMany(`app:${userId}`, 3, 216e5)) return tb(loc, "tooManyUser");
	if (tooMany("app:global", 40, 36e5)) return tb(loc, "tooManyGlobal");
	return null;
}
function readUploadedEvidence(id) {
	const path = uploadedEvidencePath(id);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
function uploadedEvidencePath(id) {
	const safe = sanitizeEvidenceId(id);
	if (!safe) return null;
	const path = join(EVIDENCE_DIR, safe);
	if (!path.startsWith(EVIDENCE_DIR)) return null;
	return existsSync(path) ? path : null;
}
var BANNER_DIR = join(DATA_DIR, "banners");
var MAX_BANNER_BYTES = 20971520;
var MAX_BANNERS = 20;
function sanitizeBannerId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9]/g, "");
	if (safe.length < 10 || safe.length > 40) return null;
	return safe;
}
function newBannerId() {
	return createHash("sha256").update(randomUUID()).digest("hex").slice(0, 24);
}
function saveBannerFile(id, bytes) {
	mkdirSync(BANNER_DIR, { recursive: true });
	writeFileSync(join(BANNER_DIR, id), bytes);
}
var SPONSOR_AVATAR_DIR = join(DATA_DIR, "sponsor-avatars");
function sanitizeAvatarKey(k) {
	const safe = String(k || "").replace(/[^a-f0-9]/g, "");
	return safe.length >= 8 && safe.length <= 64 ? safe : null;
}
function sponsorAvatarPath(key) {
	const safe = sanitizeAvatarKey(key);
	if (!safe) return null;
	const path = join(SPONSOR_AVATAR_DIR, safe);
	if (!path.startsWith(SPONSOR_AVATAR_DIR)) return null;
	return existsSync(path) ? path : null;
}
async function sponsorAvatarUrl(smallFileId) {
	if (!smallFileId) return "";
	const key = createHash("sha256").update(smallFileId).digest("hex").slice(0, 24);
	const path = join(SPONSOR_AVATAR_DIR, key);
	if (!existsSync(path)) {
		const bytes = await downloadTelegramFile(smallFileId);
		if (!bytes) return "";
		try {
			mkdirSync(SPONSOR_AVATAR_DIR, { recursive: true });
			writeFileSync(path, bytes);
		} catch {
			return "";
		}
	}
	return `/api/telegram/sponsor-avatar?a=${key}`;
}
function bannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	return (bindings.banners || []).find((b) => b.id === safe) || null;
}
function bannerFilePath(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	const path = join(BANNER_DIR, safe);
	if (!path.startsWith(BANNER_DIR)) return null;
	return existsSync(path) ? path : null;
}
function listBanners() {
	return (bindings.banners || []).map((b) => ({
		id: b.id,
		type: b.type,
		link: b.link,
		width: b.width,
		height: b.height,
		src: `/api/telegram/banner?id=${encodeURIComponent(b.id)}`
	}));
}
var sponsorsCache = null;
function invalidateSponsors() {
	sponsorsCache = null;
	statsCache = null;
}
var AUDIENCE_DEFAULT = 20178;
var statsCache = null;
async function sponsorStats() {
	if (statsCache && Date.now() - statsCache.at < 6e5) return statsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	let sum = 0;
	await Promise.all(chats.map(async (c) => {
		const n = await tgSoft("getChatMemberCount", { chat_id: c.id });
		if (typeof n === "number" && n > 0) sum += n;
	}));
	const base = typeof bindings.audienceBase === "number" ? bindings.audienceBase : AUDIENCE_DEFAULT;
	const value = {
		chats: chats.length,
		audience: Math.max(base, sum)
	};
	statsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setAudienceBase(n) {
	if (!Number.isFinite(n) || n < 0 || n > 1e9) return false;
	bindings.audienceBase = Math.round(n);
	saveBindings();
	statsCache = null;
	return true;
}
async function listSponsors() {
	if (sponsorsCache && Date.now() - sponsorsCache.at < 6e5) return sponsorsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	const value = await Promise.all(chats.map(async (c) => {
		const chat = await tgSoft("getChat", { chat_id: c.id });
		const title = chat?.title || c.title || "Чат";
		const avatar = await sponsorAvatarUrl(chat?.photo?.small_file_id);
		return {
			id: String(c.id),
			title,
			link: c.link || "",
			avatar
		};
	}));
	sponsorsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setSponsorLink(chatId, raw) {
	const relay = findRelay(chatId);
	if (!relay) return "bad";
	const text = (raw || "").trim();
	if (text === "-" || text === "—" || text === "") {
		delete relay.link;
		saveBindings();
		invalidateSponsors();
		return "cleared";
	}
	if (!(/^https:\/\/[^\s]+$/i.test(text) || /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text))) return "bad";
	relay.link = text.startsWith("http") ? text : `https://${text}`;
	saveBindings();
	invalidateSponsors();
	return "set";
}
function removeBannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return;
	bindings.banners = (bindings.banners || []).filter((b) => b.id !== safe);
	saveBindings();
	try {
		const path = join(BANNER_DIR, safe);
		if (path.startsWith(BANNER_DIR) && existsSync(path)) unlinkSync(path);
	} catch {}
}
async function downloadTelegramFile(fileId) {
	const info = await tgSoft("getFile", { file_id: fileId });
	if (!info?.file_path) return null;
	if (info.file_size && info.file_size > MAX_BANNER_BYTES) return null;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 6e4);
	try {
		const res = await fetch(`https://api.telegram.org/file/bot${requireToken()}/${info.file_path}`, { signal: ctrl.signal });
		if (!res.ok) return null;
		const bytes = Buffer.from(await res.arrayBuffer());
		if (bytes.length > MAX_BANNER_BYTES) return null;
		return bytes;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
function extractBannerMedia(msg) {
	if (msg.animation?.file_id) return {
		type: "video",
		fileId: msg.animation.file_id,
		mime: msg.animation.mime_type || "video/mp4",
		width: msg.animation.width,
		height: msg.animation.height
	};
	if (msg.video?.file_id) return {
		type: "video",
		fileId: msg.video.file_id,
		mime: msg.video.mime_type || "video/mp4",
		width: msg.video.width,
		height: msg.video.height
	};
	if (msg.photo?.length) {
		const ph = msg.photo.at(-1);
		return {
			type: "image",
			fileId: ph.file_id,
			mime: "image/jpeg",
			width: ph.width,
			height: ph.height
		};
	}
	const doc = msg.document;
	if (doc?.file_id && doc.mime_type) {
		if (doc.mime_type.startsWith("image/") && doc.mime_type !== "image/svg+xml") return {
			type: "image",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
		if (doc.mime_type.startsWith("video/")) return {
			type: "video",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
	}
	return null;
}
function normalizeBannerLink(raw) {
	const text = raw.trim();
	if (text === "-" || text === "—" || text.toLowerCase() === "нет") return "";
	if (/^https:\/\/[^\s]+$/i.test(text)) return text;
	if (/^tg:\/\/[^\s]+$/i.test(text)) return text;
	if (/^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text)) return text.startsWith("http") ? text : `https://${text}`;
	return null;
}
var TgError = class extends Error {
	code;
	retryAfter;
	migrateTo;
	constructor(json, method) {
		super(json.description || method);
		this.code = json.error_code;
		this.retryAfter = json.parameters?.retry_after;
		this.migrateTo = json.parameters?.migrate_to_chat_id ? String(json.parameters.migrate_to_chat_id) : void 0;
	}
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function tgOnce(method, body) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 45e3);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify(body),
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new TgError(json, method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
async function tg(method, body = {}) {
	let payload = body;
	for (let attempt = 0;; attempt++) try {
		return await tgOnce(method, payload);
	} catch (err) {
		if (!(err instanceof TgError) || attempt >= 3) throw err;
		if (err.migrateTo && payload.chat_id != null) {
			onChatMigrated(String(payload.chat_id), err.migrateTo);
			payload = {
				...payload,
				chat_id: err.migrateTo
			};
			continue;
		}
		if (err.code === 429 && (err.retryAfter ?? 0) <= 60) {
			await sleep(((err.retryAfter ?? 1) + 1) * 1e3);
			continue;
		}
		throw err;
	}
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function customEmojiEnabled() {
	if (typeof bindings.customEmoji === "boolean") return bindings.customEmoji;
	return process.env.EPB_CUSTOM_EMOJI === "0" ? false : true;
}
function isPrivateChat(chatId) {
	return Number(chatId) > 0;
}
function isCustomEmojiError(err) {
	return err instanceof TgError && /emoji/i.test(err.message || "");
}
function isNotModified(err) {
	return err instanceof TgError && /not modified/i.test(err.message || "");
}
async function sendCeMessage(chatId, text, extra = {}) {
	if (customEmojiEnabled() && isPrivateChat(chatId)) {
		const richText = applyCustomEmoji(text);
		const markup = extra.reply_markup;
		if (hasCustomEmoji(richText) || markupHasIconableButton(markup)) {
			const richExtra = markup ? {
				...extra,
				reply_markup: decorateButtons(markup, true)
			} : extra;
			try {
				return await tg("sendMessage", {
					chat_id: chatId,
					text: richText,
					parse_mode: "HTML",
					...richExtra
				});
			} catch (err) {
				if (!isCustomEmojiError(err)) return null;
			}
		}
	}
	return tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		...extra
	});
}
async function editCard(cb, caption, reply_markup) {
	const chatId = cb.message?.chat.id;
	const messageId = cb.message?.message_id;
	if (chatId == null || messageId == null) return;
	const isMedia = Boolean(cb.message?.photo || cb.message?.caption);
	const method = isMedia ? "editMessageCaption" : "editMessageText";
	const field = isMedia ? "caption" : "text";
	const build = (txt, markup) => ({
		chat_id: chatId,
		message_id: messageId,
		[field]: txt,
		parse_mode: "HTML",
		reply_markup: markup,
		...isMedia ? {} : { disable_web_page_preview: true }
	});
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const richText = useCe ? applyCustomEmoji(caption) : caption;
	if (useCe && (hasCustomEmoji(richText) || markupHasIconableButton(reply_markup))) try {
		await tg(method, build(richText, decorateButtons(reply_markup, true)));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
		if (!isCustomEmojiError(err)) {}
	}
	try {
		await tg(method, build(caption, reply_markup));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
	}
	await sendCeMessage(chatId, caption, { reply_markup });
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v4") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v4";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook && bindings.webhookStamp === webhookStamp()) {
		await applyMenuButton();
		return;
	}
	await registerMiniAppUrl(site);
}
function webhookStamp() {
	return createHash("sha256").update(webhookSecret()).digest("hex").slice(0, 16);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			language_code: "ru",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Open the app"
				},
				{
					command: "apply",
					description: "File a complaint in chat"
				},
				{
					command: "cancel",
					description: "Cancel the complaint"
				},
				{
					command: "lang",
					description: "Language / Язык"
				}
			],
			language_code: "en",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("deleteMyCommands", { scope: { type: "default" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
		for (const chat_id of arbiterCandidates()) await tgSoft("setMyCommands", {
			commands: [
				{
					command: "admin",
					description: "Панель управления"
				},
				{
					command: "relays",
					description: "Чаты рассылки"
				},
				{
					command: "channel",
					description: "Канал для постов"
				},
				{
					command: "id",
					description: "ID этого чата"
				}
			],
			scope: {
				type: "chat",
				chat_id
			}
		});
	}
	profileReady = true;
}
var statusCache = null;
function getBotStatus() {
	if (!statusCache || Date.now() - statusCache.at > 6e4) statusCache = {
		at: Date.now(),
		value: computeBotStatus()
	};
	return statusCache.value;
}
async function computeBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	for (const id of arbiterCandidates()) {
		if (!await chatReachable(id)) continue;
		arbiterOk = true;
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		channelOk
	};
}
var mtClient = null;
var mtIdleTimer = null;
var mtBlockedUntil = 0;
var mtMisses = /* @__PURE__ */ new Map();
var mtInflight = /* @__PURE__ */ new Map();
var MT_SESSION_PATH = join(DATA_DIR, "mtproto.session");
function mtproto() {
	if (!mtClient) {
		mtClient = (async () => {
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
			const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
			let saved = "";
			try {
				const [stamp, value] = readFileSync(MT_SESSION_PATH, "utf8").split("\n");
				if (stamp === webhookStamp() && value) saved = value.trim();
			} catch {}
			const client = new TelegramClient(new StringSession(saved), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 12,
				floodSleepThreshold: 0,
				deviceModel: "EPB",
				systemVersion: "Linux",
				appVersion: "1.0",
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.start({ botAuthToken: botToken() }), 2e4, "mtproto login timeout");
			try {
				mkdirSync(DATA_DIR, { recursive: true });
				writeFileSync(MT_SESSION_PATH, `${webhookStamp()}\n${client.session.save()}`, { mode: 384 });
			} catch {}
			return {
				client,
				Api
			};
		})();
		mtClient.catch(() => dropMtproto());
	}
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = setTimeout(() => dropMtproto(), 18e5);
	return mtClient;
}
function withTimeout(promise, ms, message) {
	let timer;
	const timeout = new Promise((_, reject) => {
		timer = setTimeout(() => reject(new Error(message)), ms);
	});
	return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function dropMtproto() {
	const pending = mtClient;
	mtClient = null;
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
function floodSeconds(err) {
	const e = err;
	if (typeof e?.seconds === "number" && e.seconds > 0) return e.seconds;
	const m = `${e?.errorMessage || ""} ${e?.message || ""}`.match(/FLOOD_WAIT_(\d+)|A wait of (\d+) seconds/);
	return m ? Number(m[1] || m[2]) : 0;
}
var USER_SESSION_PATH = join(DATA_DIR, "user-session.txt");
function userSession() {
	const env = (process.env.TELEGRAM_USER_SESSION || "").trim();
	if (env) return env;
	try {
		return readFileSync(USER_SESSION_PATH, "utf8").trim();
	} catch {
		return "";
	}
}
function hasUserbot() {
	return Boolean(userSession());
}
var userClient = null;
var userIdleTimer = null;
var userBlockedUntil = 0;
function userApiCreds() {
	return {
		apiId: Number(process.env.TELEGRAM_API_ID || bindings.userbotApi?.apiId || 0),
		apiHash: (process.env.TELEGRAM_API_HASH || bindings.userbotApi?.apiHash || "").trim()
	};
}
var OWNER_ID = "1457986905";
function isOwner(id) {
	return String(id || "") === OWNER_ID;
}
function checkEnabled() {
	if (typeof bindings.checkEnabled === "boolean") return bindings.checkEnabled;
	if (process.env.EPB_CHECK_ENABLED === "0") return false;
	return true;
}
function featuresEnabled() {
	return { check: checkEnabled() };
}
function saveUserSession(session) {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(USER_SESSION_PATH, session, { mode: 384 });
	} catch {}
}
function clearUserSession() {
	dropUserbot();
	try {
		if (existsSync(USER_SESSION_PATH)) unlinkSync(USER_SESSION_PATH);
	} catch {}
}
function userbot() {
	if (!userClient) {
		userClient = (async () => {
			const session = userSession();
			if (!session) throw new Error("no user session");
			const { apiId, apiHash } = userApiCreds();
			if (!apiId || !apiHash) throw new Error("set TELEGRAM_API_ID and TELEGRAM_API_HASH for the userbot");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 15,
				floodSleepThreshold: 0,
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.connect(), 2e4, "userbot connect timeout");
			return {
				client,
				Api
			};
		})();
		userClient.catch(() => dropUserbot());
	}
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = setTimeout(() => dropUserbot(), 12e5);
	return userClient;
}
var userEntitiesLoaded = false;
async function ensureUserEntities(client) {
	if (userEntitiesLoaded) return;
	userEntitiesLoaded = true;
	try {
		await withTimeout(client.getDialogs({ limit: 300 }), 25e3, "dialogs timeout");
		const saved = client.session?.save?.();
		if (typeof saved === "string" && saved) saveUserSession(saved);
	} catch {
		userEntitiesLoaded = false;
	}
}
async function userInputPeer(client, ref) {
	try {
		return await client.getInputEntity(ref);
	} catch {
		await ensureUserEntities(client);
		return client.getInputEntity(ref);
	}
}
function dropUserbot() {
	const pending = userClient;
	userClient = null;
	userEntitiesLoaded = false;
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
async function userbotStatus() {
	if (!userSession()) return {
		ok: false,
		error: "нет сессии"
	};
	const { apiId, apiHash } = userApiCreds();
	if (!apiId || !apiHash) return {
		ok: false,
		error: "нет TELEGRAM_API_ID / TELEGRAM_API_HASH"
	};
	try {
		const { client, Api } = await userbot();
		const u = (await withTimeout(client.invoke(new Api.users.GetUsers({ id: [new Api.InputUserSelf()] })), 12e3, "timeout"))?.[0];
		return {
			ok: true,
			name: u?.username ? `@${u.username}` : u?.firstName || "аккаунт"
		};
	} catch (err) {
		return {
			ok: false,
			error: err?.message || "ошибка"
		};
	}
}
async function resolveChannelAsUser(ref) {
	if (!userSession()) return null;
	try {
		const { client } = await userbot();
		const chan = await withTimeout(client.getInputEntity(ref), 12e3, "timeout");
		if (!chan?.channelId) return null;
		const id = `-100${chan.channelId.toString()}`;
		const full = await client.getEntity(ref).catch(() => null);
		return {
			id,
			title: full?.title,
			username: full?.username,
			addedAt: Date.now()
		};
	} catch {
		return null;
	}
}
function snippetAround(text, needle) {
	const flat = text.replace(/\s+/g, " ").trim();
	if (!needle) return flat.slice(0, 180);
	const i = flat.toLowerCase().indexOf(needle.toLowerCase());
	if (i < 0) return flat.slice(0, 180);
	const from = Math.max(0, i - 60);
	return (from > 0 ? "…" : "") + flat.slice(from, from + 180).trim() + (from + 180 < flat.length ? "…" : "");
}
var deletedCache = /* @__PURE__ */ new Map();
async function channelPostDeleted(rec) {
	if (!userSession() || Date.now() < userBlockedUntil) return false;
	const ids = rec.channelMsgIds || [];
	const chat = rec.channelChatId || bindings.channelId || "";
	if (!ids.length || !chat) return false;
	const cacheKey = `${chat}:${ids.join(",")}`;
	const cached = deletedCache.get(cacheKey);
	if (cached && Date.now() - cached.at < 3e5) return cached.deleted;
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, chat);
		const deleted = !(await withTimeout(client.getMessages(peer, { ids }), 12e3, "getMessages timeout") || []).some((m) => m && m.id && m.className !== "MessageEmpty");
		deletedCache.set(cacheKey, {
			at: Date.now(),
			deleted
		});
		return deleted;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) userBlockedUntil = Date.now() + (wait + 5) * 1e3;
		else if (!err?.errorMessage) dropUserbot();
		return false;
	}
}
function channelRef(channel) {
	if (channel.username) return `@${channel.username.replace(/^@/, "")}`;
	const n = Number(channel.id);
	return Number.isSafeInteger(n) ? n : channel.id;
}
var userbotQueue = Promise.resolve();
var userbotQueued = 0;
var USERBOT_GAP_MS = 350;
function paced(fn) {
	if (userbotQueued > 60) return Promise.reject(/* @__PURE__ */ new Error("userbot busy"));
	userbotQueued += 1;
	const run = userbotQueue.then(async () => {
		try {
			return await fn();
		} finally {
			await new Promise((r) => setTimeout(r, USERBOT_GAP_MS));
		}
	});
	userbotQueue = run.catch(() => {}).finally(() => {
		userbotQueued -= 1;
	});
	return run;
}
async function serverSearch(client, peer, query) {
	const c = client;
	return await paced(() => withTimeout(c.getMessages(peer, {
		search: searchQueryFor(query),
		limit: 60
	}), 15e3, "search timeout")) || [];
}
async function scanRecent(client, peer, limit = 800) {
	const c = client;
	return await paced(() => withTimeout(c.getMessages(peer, { limit }), 45e3, "scan timeout")) || [];
}
var scanCache = /* @__PURE__ */ new Map();
var SCAN_TTL = 12e4;
async function scanRecentCached(client, peer, channelKey) {
	const hit = scanCache.get(channelKey);
	if (hit && Date.now() - hit.at < SCAN_TTL) return hit.msgs;
	const msgs = await scanRecent(client, peer);
	scanCache.set(channelKey, {
		at: Date.now(),
		msgs
	});
	return msgs;
}
function searchQueryFor(raw) {
	return raw.replace(/[^\p{L}\p{N}]+/gu, " ").trim() || raw;
}
function escapeRe(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
var NON_ACCUSATION_LINE_RE = /(оспор|обжал|по\s*(всем\s*)?вопрос|для\s*связ|связ[ьи]|контакт|админ|administrator|\badmin\b|support|поддержк|dispute|appeal|помощ|реклам|сотруднич|менеджер|гарант|куп(лю|ить)|прод(ам|аж|ать)|прайс|услуг|сервис|магазин|\bshop\b|подписк|вступай|вступить|присоединя|заказать|скидк|акци|цен[аы])/iu;
var ACCUSED_LABEL_RE = /^(?:[📛🚫❌🤡⚠🔴🛑‼️\s])*(?:ответчик|обвиняем\w*|скамер|кидал\w*|мошенник|виновник|respondent|defendant)\s*:?\s*$/iu;
function isStrictChannel(channel) {
	return /wwh/i.test(channel.title || "") || /wwh/i.test(channel.username || "");
}
var IGNORE_USERNAMES = /* @__PURE__ */ new Set([
	"europepromo",
	"ctoroot",
	"sbepbank",
	BOT_USERNAME.toLowerCase()
]);
function isIgnoredHandle(uname) {
	return IGNORE_USERNAMES.has((uname || "").replace(/^@/, "").toLowerCase());
}
function usernameOnLine(line, uname) {
	if (!uname) return false;
	return new RegExp("@?(?<!\\w)" + escapeRe(uname) + "(?!\\w)", "iu").test(line);
}
function idOnLine(line, id) {
	const digits = (id || "").replace(/\D/g, "");
	if (digits.length < 5) return false;
	return new RegExp("(?<!\\d)" + digits + "(?!\\d)").test(line);
}
function arbitrationAccused(line, strict = false) {
	const marker = strict ? "(?:пользовател\\S*\\s+|юзер\\S*\\s+|user\\s+|@)" : "(?:пользовател\\S*\\s+|юзер\\S*\\s+|человек\\S*\\s+|аккаунт\\S*\\s+|user\\s+|@)?";
	const m = line.match(new RegExp("(?:^|\\s)(?:на|против|on|against)\\s+" + marker + "(.+)$", "i"));
	if (!m) return "";
	return m[1].split(/\s+(?:от|from|by|заявител\S*|подал\S*|reporter)\s+/i)[0] || "";
}
function postMatchesSubject(body, username, id, strict = false) {
	const uname = (username || "").replace(/^@/, "").toLowerCase();
	const ignoredName = !uname || IGNORE_USERNAMES.has(uname);
	if (ignoredName && !id) return false;
	let labelAbove = false;
	for (const line of body.split(/\r?\n/)) {
		if (/арбитраж|arbitr/i.test(line)) {
			const accused = arbitrationAccused(line, strict);
			if (accused && (!ignoredName && usernameOnLine(accused, uname) || idOnLine(accused, id))) return true;
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		const hasId = idOnLine(line, id);
		const hasU = !ignoredName && usernameOnLine(line, uname);
		if (!hasId && !hasU) {
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		let rest = line;
		if (uname) rest = rest.replace(new RegExp("@?" + escapeRe(uname), "ig"), " ");
		const idDigits = (id || "").replace(/\D/g, "");
		if (idDigits.length >= 5) rest = rest.replace(new RegExp(idDigits, "g"), " ");
		if (!NON_ACCUSATION_LINE_RE.test(rest)) {
			if (!strict) return true;
			if (labelAbove) return true;
		}
		if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
	}
	return false;
}
async function userSearchChannel(channel, query, subject) {
	if (Date.now() < userBlockedUntil) return [];
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(channel));
		const strict = isStrictChannel(channel);
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, query)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(channel.id))) if (m.id) byId.set(m.id, m);
		const out = [];
		for (const m of byId.values()) {
			const body = m.message || "";
			if (!m.id || !body || !postMatchesSubject(body, subject.username, subject.id, strict)) continue;
			out.push({
				channelId: channel.id,
				channelTitle: channel.title || "канал",
				messageId: m.id,
				link: messageLink(channel, m.id),
				date: (m.date || 0) * 1e3,
				snippet: snippetAround(body, subject.username || subject.id)
			});
		}
		return out;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) {
			userBlockedUntil = Date.now() + (wait + 5) * 1e3;
			console.warn(`[epb] userbot FLOOD_WAIT ${wait}s`);
		} else if (!err?.errorMessage) dropUserbot();
		return [];
	}
}
async function diagnoseUserSearch(input) {
	const parsed = parseTelegramInput(input);
	const uname = parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const q = uname || id;
	if (!q) return "Укажите @username или ID для проверки.";
	if (!hasUserbot()) return "Юзербот не подключён (нет сессии). Подключите: /userbot.";
	const channels = checkChannels();
	if (!channels.length) return "Не выбрано ни одного канала для поиска. Выберите: /userbot → каналы.";
	const st = await userbotStatus();
	if (!st.ok) return `Аккаунт не отвечает: ${st.error || "ошибка"}`;
	let resolvedId = id;
	if (uname && !resolvedId) {
		const r = await resolveUsernameMtproto(uname, "");
		if (r && r !== "busy" && r.id) resolvedId = r.id;
	}
	const idDigits = (resolvedId || "").replace(/\D/g, "");
	const mentions = (body) => uname && body.toLowerCase().includes(uname) || idDigits.length >= 5 && body.includes(idDigits);
	const lines = [`Аккаунт: ${st.name || "ок"}. Каналов: ${channels.length}. Ищу «${q}»${resolvedId && resolvedId !== q ? ` (id ${resolvedId})` : ""}…`];
	let total = 0;
	for (const ch of channels) try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(ch));
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, q)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(ch.id))) if (m.id) byId.set(m.id, m);
		const msgs = [...byId.values()];
		const strict = isStrictChannel(ch);
		const mentioned = msgs.filter((m) => m.id && mentions(m.message || ""));
		const relevant = msgs.filter((m) => m.id && postMatchesSubject(m.message || "", uname, resolvedId, strict));
		total += relevant.length;
		lines.push(`• ${ch.title || ch.username || ch.id}: просмотрено ${msgs.length}, упомянут ${mentioned.length}, в тему ${relevant.length}`);
	} catch (err) {
		lines.push(`• ${ch.title || ch.username || ch.id}: ошибка — ${err?.message || String(err)}`);
	}
	lines.push(`Итого по делу: ${total}.`);
	return lines.join("\n");
}
async function resolveUsernameMtproto(username, userId = "") {
	const key = username.toLowerCase();
	if (!botToken()) return null;
	if (Date.now() < mtBlockedUntil) return "busy";
	if (Date.now() - (mtMisses.get(key) || 0) < 18e5) return null;
	const running = mtInflight.get(key);
	if (running) return running;
	if (userId && tooMany(`mtproto:user:${userId}`, 8, 6e4)) return "busy";
	if (tooMany("mtproto:resolve", 30, 6e4) || tooMany("mtproto:resolve:h", 400, 36e5)) return "busy";
	const job = (async () => {
		try {
			const ask = async () => {
				const { client, Api } = await mtproto();
				if (client.connected === false) throw new Error("mtproto disconnected");
				return withTimeout(client.invoke(new Api.contacts.ResolveUsername({ username })), 1e4, "mtproto request timeout");
			};
			let raw;
			try {
				raw = await ask();
			} catch (err) {
				if (err?.errorMessage || floodSeconds(err)) throw err;
				dropMtproto();
				raw = await ask();
			}
			const result = raw;
			const user = result.users?.[0];
			const id = String(user?.id ?? result.peer?.userId ?? "");
			if (!/^\d{5,15}$/.test(id)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			return {
				username: user?.username || username,
				id
			};
		} catch (err) {
			const wait = floodSeconds(err);
			if (wait) {
				mtBlockedUntil = Date.now() + (wait + 5) * 1e3;
				console.warn(`[epb] MTProto FLOOD_WAIT ${wait}s, lookups paused`);
				return "busy";
			}
			const rpc = err?.errorMessage;
			if (rpc && /USERNAME_(NOT_OCCUPIED|INVALID)/.test(rpc)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			if (!rpc) dropMtproto();
			return null;
		} finally {
			mtInflight.delete(key);
			if (mtMisses.size > 5e3) mtMisses.clear();
		}
	})();
	mtInflight.set(key, job);
	return job;
}
async function lookupVerifiedId(username, userId = "") {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key) return null;
	const cached = idCache[key];
	if (cached) return {
		username,
		id: cached
	};
	const chat = await tgSoft("getChat", { chat_id: `@${key}` });
	if (chat?.id) {
		rememberHandle(chat.username || username, String(chat.id));
		return {
			username: chat.username || username,
			id: String(chat.id)
		};
	}
	const mt = await resolveUsernameMtproto(key, userId);
	if (mt && mt !== "busy" && mt.id) {
		rememberHandle(mt.username, mt.id);
		return mt;
	}
	return mt === "busy" ? "busy" : null;
}
async function verifyAccountPair(username, id) {
	const handle = username.replace(/^@/, "").trim();
	if (!handle || !id) return { check: "unknown" };
	const found = await lookupVerifiedId(handle);
	if (!found || found === "busy") return { check: "unknown" };
	return found.id === id ? { check: "ok" } : {
		check: "mismatch",
		realId: found.id
	};
}
async function resolveHandleServer(input, userId = "") {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (tooMany("resolve:global", 80, 6e4)) {
		const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
		if (cached && (!parsed.id || cached === parsed.id)) return {
			username: parsed.username,
			id: cached,
			source: "telegram"
		};
		return {
			username: parsed.username,
			id: parsed.id,
			source: parsed.id ? "parsed" : "unresolved"
		};
	}
	if (parsed.id) {
		if (parsed.username) {
			const pair = await verifyAccountPair(parsed.username, parsed.id);
			if (pair.check === "mismatch" && pair.realId) return {
				username: parsed.username,
				id: pair.realId,
				source: "telegram"
			};
			return {
				username: parsed.username,
				id: parsed.id,
				source: pair.check === "ok" ? "telegram" : "parsed"
			};
		}
		const chat = await tgSoft("getChat", { chat_id: parsed.id });
		if (chat?.username) rememberHandle(chat.username, parsed.id);
		return {
			username: chat?.username || "",
			id: parsed.id,
			source: chat?.username ? "telegram" : "parsed"
		};
	}
	const username = parsed.username;
	const found = await lookupVerifiedId(username, userId);
	if (found && found !== "busy") return {
		username: found.username,
		id: found.id,
		source: "telegram"
	};
	const legacy = legacyIds[username.toLowerCase()];
	if (legacy) return {
		username,
		id: legacy,
		source: "parsed"
	};
	return {
		username,
		id: "",
		source: "unresolved",
		busy: found === "busy"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function previousPosts(accounts, exceptKey = "") {
	const ids = new Set(accounts.map((a) => a.id || a.telegramId || "").filter(Boolean));
	const names = new Set(accounts.map((a) => (a.username || "").replace(/^@/, "").toLowerCase()).filter(Boolean));
	const hits = Object.entries(pendingPosts).filter(([key, rec]) => key !== exceptKey && rec.status === "published").filter(([, rec]) => pendingAccounts(rec).some((a) => a.id && ids.has(a.id) || a.username && names.has(a.username.replace(/^@/, "").toLowerCase()))).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
	if (!hits.length) return "";
	return `⚠️ По этому аккаунту уже был пост: ${hits.slice(0, 3).map(([key, rec]) => `${escapeHtml(key)} (${new Date(rec.createdAt || 0).toLocaleDateString("ru-RU")})`).join(", ")}${hits.length > 3 ? ` и ещё ${hits.length - 3}` : ""}`;
}
function accountCheckHtml(a) {
	if (!a.username) return "❔ указан только ID, проверить по username нельзя";
	if (a.check === "ok") return "✅ username и ID совпадают (проверено в Telegram)";
	if (a.check === "mismatch") return `⚠️ Заявитель указал чужой ID <code>${escapeHtml(a.claimedId || "?")}</code> — заменён на настоящий ID @${escapeHtml(a.username.replace(/^@/, ""))}`;
	return "❔ связку username и ID проверить не удалось";
}
function applicationBriefHtml(app) {
	const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
	const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const accounts = scammerAccounts(app);
	const scammer = accounts.map((a) => `${formatAccountLine(a.username, a.telegramId, true)}\n${accountCheckHtml(a)}`).join("\n");
	const brief = (app.summary || app.story).trim();
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		...previousPosts(accounts) ? [previousPosts(accounts)] : [],
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(brief)}`
	].join("\n");
}
function applicationDetailHtml(app) {
	const detail = app.story.trim();
	const brief = (app.summary || "").trim();
	if (!detail || detail === brief) return "";
	return `<b>Подробно</b>\n${escapeHtml(detail)}`;
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	const multi = accounts.length > 1;
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const name = handle ? `@${escapeHtml(handle)}` : "";
		const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
		const last = i === accounts.length - 1;
		if (multi) {
			const head = [name, id].filter(Boolean).join(" ");
			if (!last) return `${head} ;`;
			return scam ? `${head} - ${scam}` : head;
		}
		if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
		return [name, id].filter(Boolean).join("\n");
	});
}
function channelHtml(accounts, story, amount = "", currency = "", bodyHtml = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		bodyHtml.trim() || escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const scamLine = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	return [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`
	].join("\n").slice(0, 1024);
}
function splitHtml(html, max = 4090) {
	if (html.length <= max) return [html];
	const tokens = html.match(/<[^>]*>|&[#a-zA-Z0-9]+;|[\s\S]/g) || [];
	const parts = [];
	const closers = (stack) => stack.map((t) => `</${t.name}>`).reverse().join("");
	const openers = (stack) => stack.map((t) => t.tag).join("");
	let stack = [];
	let cur = "";
	let lastNl = null;
	let lastSpace = null;
	for (let i = 0; i < tokens.length; i++) {
		const token = tokens[i];
		if (cur.length + token.length + closers(stack).length > max && cur.trim()) {
			const lastBreak = lastNl && lastNl.at > max / 3 ? lastNl : lastSpace && lastSpace.at > max / 3 ? lastSpace : null;
			lastNl = null;
			lastSpace = null;
			if (lastBreak) {
				parts.push(cur.slice(0, lastBreak.at) + closers(lastBreak.stack));
				stack = [...lastBreak.stack];
				cur = openers(stack);
				i = lastBreak.next - 1;
				continue;
			}
			parts.push(cur + closers(stack));
			cur = openers(stack);
		}
		const tag = token.match(/^<(\/)?([a-zA-Z0-9-]+)/);
		if (tag) {
			const name = tag[2].toLowerCase();
			if (tag[1]) {
				const idx = stack.map((t) => t.name).lastIndexOf(name);
				if (idx >= 0) stack = stack.slice(0, idx);
			} else if (!token.endsWith("/>")) stack = [...stack, {
				name,
				tag: token
			}];
		}
		cur += token;
		if (token === "\n") lastNl = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
		else if (token === " ") lastSpace = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
	}
	if (cur.replace(/<[^>]*>/g, "").trim()) parts.push(cur);
	return parts.map((p) => p.replace(/^\n+/, ""));
}
function reviewKeyboard(appId = "") {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: appId ? `pub:${appId}` : "pub"
	}, {
		text: "Отклонить",
		callback_data: appId ? `rej:${appId}` : "rej"
	}]] };
}
function publishChoiceKeyboard(key = "") {
	const suffix = key ? `:${key}` : "";
	const rows = [[{
		text: "Опубликовать с рассылкой",
		callback_data: `puball${suffix}`.slice(0, 64)
	}], [{
		text: "Опубликовать без рассылки",
		callback_data: `pubch${suffix}`.slice(0, 64)
	}]];
	if (key && pendingPosts[key]) {
		rows.push([{
			text: "✏ Изменить текст",
			callback_data: `pedit:${key}`
		}, {
			text: "👁 Предпросмотр",
			callback_data: `pview:${key}`
		}]);
		if (pendingPosts[key].postHtml) rows.push([{
			text: "↩ Вернуть исходный текст",
			callback_data: `porig:${key}`
		}]);
	}
	return { inline_keyboard: rows };
}
async function tgForm(method, form) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 12e4);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			body: form,
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new Error(json.description || method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
var TG_UPLOAD_MAX = 51380224;
function mediaSize(file) {
	return file.size || evidenceBytesOnDisk(file.storageKey);
}
function evidencePublicUrl(storageKey) {
	if (!storageKey || !sanitizeEvidenceId(storageKey)) return "";
	const site = publicSiteUrl();
	if (!site) return "";
	const exp = Date.now() + 864e5;
	const sig = evidenceSig(storageKey, exp);
	return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}&exp=${exp}&sig=${sig}`;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const size = mediaSize(file);
	if (file.kind === "video" && size > TG_UPLOAD_MAX) return sendLargeVideo(chatId, file, opts);
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	if (blob.size > TG_UPLOAD_MAX && file.kind === "video") return sendLargeVideo(chatId, file, opts);
	const form = new FormData();
	form.set("chat_id", String(chatId));
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
async function sendLargeVideo(chatId, file, opts = {}) {
	const url = evidencePublicUrl(file.storageKey);
	const extra = { chat_id: chatId };
	if (opts.caption) {
		extra.caption = opts.caption;
		extra.parse_mode = "HTML";
	}
	if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
	if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
	if (url) {
		const video = await tgSoft("sendVideo", {
			...extra,
			video: url,
			supports_streaming: true
		});
		if (video) return {
			...video,
			fileId: video.video?.file_id,
			kind: "video"
		};
		const doc = await tgSoft("sendDocument", {
			...extra,
			document: url
		});
		if (doc) return {
			message_id: doc.message_id,
			chat: doc.chat,
			fileId: doc.document?.file_id,
			kind: "video"
		};
	}
	const link = url || file.name || "видео";
	return {
		...await tg("sendMessage", {
			chat_id: chatId,
			text: [
				opts.caption,
				`Видео: ${escapeHtml(file.name || "файл")}`,
				url ? `<a href="${url}">скачать</a>` : link
			].filter(Boolean).join("\n"),
			parse_mode: "HTML",
			disable_web_page_preview: false,
			reply_markup: opts.replyMarkup,
			reply_to_message_id: opts.replyTo
		}),
		kind: "video"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		summary: app.summary || "",
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? btUser(chatId, "pendingNotice", {
			id: appId,
			scam
		}) : kind === "published" ? btUser(chatId, "publishedNotice", {
			id: appId,
			scam
		}) : btUser(chatId, "rejectedNotice", {
			id: appId,
			scam
		}),
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
var loginStates = /* @__PURE__ */ new Map();
function ownerLoginActive(chatId) {
	const st = loginStates.get(String(chatId));
	if (!st) return false;
	if (Date.now() - st.touched > 6e5) {
		st.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(chatId));
		return false;
	}
	return true;
}
async function sendOwnerPanel(chatId) {
	const st = await userbotStatus();
	const connected = st.ok;
	const channels = checkChannels();
	const rows = [];
	if (connected) {
		rows.push([{
			text: "📡 Выбрать каналы для поиска",
			callback_data: "ub:chans"
		}]);
		rows.push([{
			text: "🔌 Переподключить аккаунт",
			callback_data: "ub:connect"
		}]);
		rows.push([{
			text: "❌ Отключить аккаунт",
			callback_data: "ub:off"
		}]);
	} else rows.push([{
		text: "➕ Подключить аккаунт",
		callback_data: "ub:connect"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Юзербот для поиска по блеклистам</b>",
			connected ? `Аккаунт: ${escapeHtml(st.name || "подключён")} ✅` : "Аккаунт не подключён",
			`Каналов выбрано для поиска: ${channels.length}`,
			"",
			connected ? "Поиск в мини-приложении идёт по выложенным жалобам EPB и по выбранным каналам (через аккаунт, по username, включая старые посты)." : "Подключите свой аккаунт Telegram, затем выберите каналы, по которым искать. Понадобятся api_id и api_hash с my.telegram.org."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
}
async function startOwnerLogin(chatId) {
	const existing = loginStates.get(String(chatId));
	if (existing?.client) await existing.client.disconnect?.().catch(() => {});
	loginStates.set(String(chatId), {
		step: "apiId",
		touched: Date.now()
	});
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Подключение аккаунта</b>",
			"",
			"Нужны api_id и api_hash: зайдите на https://my.telegram.org → API development tools.",
			"",
			"Пришлите <b>api_id</b> (число).",
			"Отмена: /cancel_userbot"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function handleOwnerLogin(chatId, text) {
	const key = String(chatId);
	const st = loginStates.get(key);
	if (!st) return false;
	st.touched = Date.now();
	const value = text.trim();
	const fail = async (msg) => {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: msg
		});
	};
	try {
		if (st.step === "apiId") {
			const n = Number(value);
			if (!n || !Number.isInteger(n)) return await fail("api_id — это число. Пришлите ещё раз."), true;
			st.apiId = n;
			st.step = "apiHash";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Теперь пришлите <b>api_hash</b>.",
				parse_mode: "HTML"
			});
			return true;
		}
		if (st.step === "apiHash") {
			if (!/^[a-f0-9]{16,}$/i.test(value)) return await fail("Похоже, это не api_hash. Пришлите ещё раз."), true;
			st.apiHash = value;
			st.step = "phone";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Пришлите номер телефона аккаунта в формате +7999…"
			});
			return true;
		}
		if (st.step === "phone") {
			if (!/^\+?\d{7,15}$/.test(value.replace(/\s/g, ""))) return await fail("Неверный номер. Пример: +79991234567"), true;
			st.phone = value.replace(/\s/g, "");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			st.client = new TelegramClient(new StringSession(""), st.apiId, st.apiHash, {
				connectionRetries: 2,
				baseLogger: new Logger("none")
			});
			st.Api = Api;
			await withTimeout(st.client.connect(), 25e3, "connect timeout");
			st.phoneCodeHash = (await withTimeout(st.client.sendCode({
				apiId: st.apiId,
				apiHash: st.apiHash
			}, st.phone), 25e3, "sendCode timeout")).phoneCodeHash;
			st.step = "code";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Код отправлен в Telegram на этот аккаунт. Пришлите код. Если боитесь, что Telegram заблокирует код в сообщении — вставьте пробелы: 1 2 3 4 5."
			});
			return true;
		}
		if (st.step === "code") {
			const code = value.replace(/\D/g, "");
			if (!code) return await fail("Пришлите код из Telegram."), true;
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.SignIn({
					phoneNumber: st.phone,
					phoneCodeHash: st.phoneCodeHash,
					phoneCode: code
				})), 25e3, "signin timeout");
			} catch (err) {
				const m = err?.errorMessage || err?.message || "";
				if (/SESSION_PASSWORD_NEEDED/.test(m)) {
					st.step = "password";
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "На аккаунте включена двухфакторная защита. Пришлите пароль."
					});
					return true;
				}
				if (/PHONE_CODE_INVALID|PHONE_CODE_EXPIRED/.test(m)) return await fail("Код неверный или просрочен. Пришлите ещё раз, либо начните заново: /cancel_userbot."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
		if (st.step === "password") {
			const { computeCheck } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const check = await computeCheck(await st.client.invoke(new st.Api.account.GetPassword()), value);
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.CheckPassword({ password: check })), 25e3, "password timeout");
			} catch (err) {
				const m = err?.errorMessage || "";
				if (/PASSWORD_HASH_INVALID/.test(m)) return await fail("Пароль неверный. Пришлите ещё раз."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
	} catch (err) {
		loginStates.delete(key);
		await st.client?.disconnect?.().catch(() => {});
		await fail(`Не удалось подключить аккаунт: ${err?.message || "ошибка"}. Начните заново: /userbot`);
		return true;
	}
	return true;
}
async function finishOwnerLogin(chatId, st) {
	saveUserSession(st.client.session.save());
	bindings.userbotApi = {
		apiId: st.apiId,
		apiHash: st.apiHash
	};
	saveBindings();
	await st.client.disconnect?.().catch(() => {});
	loginStates.delete(String(chatId));
	dropUserbot();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Аккаунт подключён ✅\nТеперь выберите каналы для поиска."
	});
	await sendChannelPicker(chatId);
}
async function sendChannelPicker(chatId, editMessageId) {
	const dialogs = [];
	try {
		const { client } = await userbot();
		const list = await withTimeout(client.getDialogs({ limit: 200 }), 2e4, "dialogs timeout");
		for (const d of list) {
			const e = d?.entity;
			if (!e || e.className !== "Channel") continue;
			dialogs.push({
				id: `-100${e.id?.toString?.() ?? e.id}`,
				title: d.title || e.title || "канал",
				username: e.username || void 0
			});
		}
	} catch (err) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось получить список каналов: ${err?.message || "ошибка"}`
		});
		return;
	}
	if (!dialogs.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "У аккаунта нет каналов. Подпишитесь на нужные каналы и откройте список снова: /userbot"
		});
		return;
	}
	const selected = new Set(checkChannels().map((c) => chatIdKey(c.id)));
	const rows = dialogs.slice(0, 60).map((d) => [{
		text: `${selected.has(chatIdKey(d.id)) ? "✅" : "▫️"} ${cut(d.title, 40)}`,
		callback_data: `ub:tgl:${d.id}`
	}]);
	rows.push([{
		text: "Готово",
		callback_data: "ub:done"
	}]);
	const text = "<b>Каналы для поиска</b>\nОтметьте, по каким каналам искать. Нажмите «Готово», когда закончите.";
	if (editMessageId) await tgSoft("editMessageText", {
		chat_id: chatId,
		message_id: editMessageId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	else await tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	dialogCache.clear();
	for (const d of dialogs) dialogCache.set(chatIdKey(d.id), d);
}
var dialogCache = /* @__PURE__ */ new Map();
async function toggleCheckChannel(id) {
	const list = [...checkChannels()];
	const idx = list.findIndex((c) => sameChat(c.id, id));
	if (idx >= 0) list.splice(idx, 1);
	else {
		const d = dialogCache.get(chatIdKey(id));
		list.push({
			id,
			title: d?.title,
			username: d?.username,
			addedAt: Date.now()
		});
	}
	bindings.checkChannels = list.slice(-100);
	saveBindings();
}
async function handleOwnerCallback(cb) {
	const data = cb.data || "";
	if (!data.startsWith("ub:")) return false;
	const chatId = cb.message?.chat.id;
	if (!chatId || !isOwner(cb.from?.id)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Недоступно",
			show_alert: true
		});
		return true;
	}
	const [, action, ...rest] = data.split(":");
	const answer = (t = "") => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: t || void 0
	});
	if (action === "connect") {
		await answer();
		await startOwnerLogin(chatId);
	} else if (action === "off") {
		clearUserSession();
		delete bindings.userbotApi;
		saveBindings();
		await answer("Аккаунт отключён");
		await sendOwnerPanel(chatId);
	} else if (action === "chans") {
		await answer();
		await sendChannelPicker(chatId);
	} else if (action === "tgl") {
		await toggleCheckChannel(rest.join(":"));
		await answer();
		await sendChannelPicker(chatId, cb.message.message_id);
	} else if (action === "done") {
		await answer("Сохранено");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Готово. Каналов для поиска: ${checkChannels().length}.`
		});
	} else await answer();
	return true;
}
var CHECK_INDEX_PATH = join(DATA_DIR, "telegram-check-index.json");
var checkIndex = readJson(CHECK_INDEX_PATH) || {};
var checkIndexTimer = null;
function saveCheckIndex() {
	if (checkIndexTimer) return;
	checkIndexTimer = setTimeout(() => {
		checkIndexTimer = null;
		try {
			writeJsonAtomic(CHECK_INDEX_PATH, checkIndex);
		} catch {}
	}, 3e3);
}
function checkChannels() {
	return bindings.checkChannels || [];
}
function isCheckChannel(id) {
	if (id == null) return void 0;
	return checkChannels().find((c) => sameChat(c.id, id));
}
function tokensFromText(text) {
	const usernames = /* @__PURE__ */ new Set();
	const ids = /* @__PURE__ */ new Set();
	for (const m of text.matchAll(/@([A-Za-z][A-Za-z0-9_]{3,31})/g)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/gi)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:tg:\/\/user\?id=|\bid[:\s=]*)(\d{5,15})/gi)) ids.add(m[1]);
	for (const m of text.matchAll(/\b(\d{7,15})\b/g)) ids.add(m[1]);
	return {
		usernames: [...usernames],
		ids: [...ids]
	};
}
function messageLink(channel, messageId) {
	if (channel.username) return `https://t.me/${channel.username.replace(/^@/, "")}/${messageId}`;
	return `https://t.me/c/${String(channel.id).replace(/^-100/, "").replace(/^-/, "")}/${messageId}`;
}
function addCheckHit(token, hit) {
	const list = checkIndex[token] || (checkIndex[token] = []);
	if (list.some((h) => sameChat(h.channelId, hit.channelId) && h.messageId === hit.messageId)) return;
	list.unshift(hit);
	if (list.length > 25) list.length = 25;
}
function indexCheckPost(channel, messageId, text, date) {
	invalidateCheckCache();
	const body = (text || "").slice(0, 4096);
	if (!body.trim()) return;
	const { usernames, ids } = tokensFromText(body);
	if (!usernames.length && !ids.length) return;
	const snippet = body.replace(/\s+/g, " ").trim().slice(0, 160);
	const hit = {
		channelId: String(channel.id),
		channelTitle: channel.title || "канал",
		messageId,
		link: messageLink(channel, messageId),
		date: date * 1e3 || Date.now(),
		snippet
	};
	for (const u of usernames) addCheckHit(`@${u}`, {
		...hit,
		username: u
	});
	for (const id of ids) addCheckHit(id, hit);
	const keys = Object.keys(checkIndex);
	if (keys.length > 2e5) for (const k of keys.slice(0, keys.length - 18e4)) delete checkIndex[k];
	saveCheckIndex();
}
function removeCheckChannelFromIndex(channelId) {
	for (const [token, list] of Object.entries(checkIndex)) {
		const kept = list.filter((h) => !sameChat(h.channelId, channelId));
		if (kept.length) checkIndex[token] = kept;
		else delete checkIndex[token];
	}
	saveCheckIndex();
}
var DEFAULT_MANUAL_SOURCE = "Сторонний источник";
var RECENT_FINDS_MAX = 25;
function recordFind(uname, id, display, result) {
	if (!result.channels.length) return;
	if (!uname && !id) return;
	const sources = [];
	for (const c of result.channels) {
		const title = c.channelTitle || "источник";
		const name = /wwh/i.test(title) ? "WWH" : title;
		if (!sources.includes(name)) sources.push(name);
	}
	const list = [...bindings.recentFinds || []];
	const same = (f) => uname && (f.username || "").toLowerCase() === uname || id && f.telegramId === id;
	const entry = {
		id: list.find(same)?.id || `find-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
		username: uname || void 0,
		telegramId: id || void 0,
		label: display || (uname ? `@${uname}` : `ID ${id}`),
		sources,
		at: Date.now()
	};
	bindings.recentFinds = [entry, ...list.filter((f) => !same(f))].slice(0, RECENT_FINDS_MAX);
	saveBindings();
}
function recentBlacklist(limit = 24) {
	if (!checkEnabled()) return [];
	const out = [];
	const shownKeys = /* @__PURE__ */ new Set();
	const key = (v) => (v || "").replace(/^@/, "").toLowerCase().trim();
	for (const [k, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		out.push({
			kind: "epb",
			id: k,
			account: scamLabel(rec),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
		for (const a of pendingAccounts(rec)) {
			if (a.username) shownKeys.add(key(a.username));
			if (a.id) shownKeys.add(key(a.id));
		}
	}
	for (const e of bindings.manualBlacklist || []) {
		out.push({
			kind: "manual",
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			date: e.addedAt || 0,
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note
		});
		if (e.username) shownKeys.add(key(e.username));
		if (e.telegramId) shownKeys.add(key(e.telegramId));
	}
	for (const f of bindings.recentFinds || []) {
		if (f.username && shownKeys.has(key(f.username)) || f.telegramId && shownKeys.has(key(f.telegramId))) continue;
		out.push({
			kind: "find",
			id: f.id,
			account: f.label,
			date: f.at,
			source: (f.sources || []).join(" · ")
		});
	}
	out.sort((a, b) => b.date - a.date);
	return out.slice(0, Math.max(1, limit));
}
function blacklistEntry(id) {
	if (!checkEnabled() || !id) return null;
	const rec = pendingPosts[id] || pendingPosts[id.toUpperCase()];
	if (rec && rec.status === "published" && rec.channelPosted && !rec.removedFromCheck) return {
		kind: "epb",
		id,
		account: scamLabel(rec),
		amount: rec.amount || "",
		currency: rec.currency || "",
		date: rec.createdAt || 0,
		summary: rec.summary || "",
		story: ""
	};
	const man = (bindings.manualBlacklist || []).find((e) => e.id === id);
	if (man) return {
		kind: "manual",
		id,
		account: man.username ? `@${man.username.replace(/^@/, "")}` : man.telegramId ? `ID ${man.telegramId}` : "",
		date: man.addedAt || 0,
		source: man.source || DEFAULT_MANUAL_SOURCE,
		note: man.note
	};
	const find = (bindings.recentFinds || []).find((f) => f.id === id);
	if (find) return {
		kind: "find",
		id,
		account: find.label,
		date: find.at,
		source: (find.sources || []).join(" · "),
		note: "Найден по запросу проверки контрагента."
	};
	return null;
}
function matchManualBlacklist(uname, id) {
	const out = [];
	for (const e of bindings.manualBlacklist || []) {
		const eu = (e.username || "").replace(/^@/, "").toLowerCase();
		if (uname && eu === uname || id && e.telegramId === id) out.push({
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note,
			date: e.addedAt || 0
		});
	}
	return out.sort((a, b) => b.date - a.date);
}
var checkCache = /* @__PURE__ */ new Map();
var CHECK_CACHE_TTL = 3e5;
async function checkCounterparty(input) {
	if (!checkEnabled()) return {
		query: {
			username: "",
			id: ""
		},
		epb: [],
		channels: [],
		manual: []
	};
	const cacheKey = (() => {
		const p = parseTelegramInput(input);
		return `${p.username.replace(/^@/, "").toLowerCase()}|${p.id}`;
	})();
	const hit = checkCache.get(cacheKey);
	if (hit && Date.now() - hit.at < CHECK_CACHE_TTL && cacheKey !== "|") return hit.res;
	const res = await checkCounterpartyUncached(input);
	if (cacheKey !== "|") {
		checkCache.set(cacheKey, {
			at: Date.now(),
			res
		});
		if (checkCache.size > 2e3) checkCache.delete(checkCache.keys().next().value);
	}
	return res;
}
async function checkCounterpartyUncached(input) {
	const parsed = parseTelegramInput(input);
	const uname = isIgnoredHandle(parsed.username) ? "" : parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const matched = [];
	for (const [key, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		const accounts = pendingAccounts(rec);
		if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) matched.push({
			key,
			rec
		});
	}
	const epb = [];
	for (const { key, rec } of matched) {
		if (await channelPostDeleted(rec)) {
			rec.removedFromCheck = true;
			savePending();
			continue;
		}
		const accounts = pendingAccounts(rec);
		epb.push({
			id: key,
			accounts: accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", "),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
	}
	epb.sort((a, b) => b.date - a.date);
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (list) => {
		for (const h of list) {
			const dkey = `${chatIdKey(h.channelId)}:${h.messageId}`;
			if (seen.has(dkey)) continue;
			seen.add(dkey);
			hits.push(h);
		}
	};
	const channels = checkChannels();
	if (hasUserbot() && channels.length) {
		let effectiveId = id;
		if (uname && !effectiveId) {
			const r = await resolveUsernameMtproto(uname, "");
			if (r && r !== "busy" && r.id) effectiveId = r.id;
		}
		const subject = {
			username: uname,
			id: effectiveId
		};
		const searchTerms = [uname, effectiveId].filter(Boolean);
		for (const channel of channels) for (const term of searchTerms) push(await userSearchChannel(channel, term, subject));
	} else for (const token of [uname ? `@${uname}` : "", id].filter(Boolean)) push(checkIndex[token] || []);
	hits.sort((a, b) => b.date - a.date);
	const result = {
		query: {
			username: uname,
			id
		},
		epb,
		channels: hits.slice(0, 30),
		manual: matchManualBlacklist(uname, id)
	};
	recordFind(uname, id, uname ? `@${parsed.username.replace(/^@/, "")}` : id ? `ID ${id}` : "", result);
	return result;
}
function allowCheck(initData) {
	if (!checkEnabled()) return {
		ok: false,
		error: "disabled"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`check:${user.id}`, 30, 6e4)) return {
		ok: false,
		error: "too many"
	};
	if (tooMany("check:global", 600, 6e4)) return {
		ok: false,
		error: "busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
var CAPTCHA_AFTER = 5;
var CAPTCHA_WINDOW = 18e4;
var CAPTCHA_CREDIT = 15;
var checkTimes = /* @__PURE__ */ new Map();
var captchaCredit = /* @__PURE__ */ new Map();
var captchaPending = /* @__PURE__ */ new Map();
var submitPass = /* @__PURE__ */ new Map();
function hasSubmitPass(userId) {
	const uid = String(userId);
	if (isOwner(uid)) return true;
	return (submitPass.get(uid) || 0) > Date.now();
}
function consumeSubmitPass(userId) {
	submitPass.delete(String(userId));
}
function captchaRequired(userId) {
	const uid = String(userId);
	if (isOwner(uid)) return false;
	const credit = captchaCredit.get(uid) || 0;
	if (credit > 0) {
		captchaCredit.set(uid, credit - 1);
		return false;
	}
	const now = Date.now();
	const times = (checkTimes.get(uid) || []).filter((t) => now - t < CAPTCHA_WINDOW);
	if (times.length >= CAPTCHA_AFTER) {
		checkTimes.set(uid, times);
		return true;
	}
	times.push(now);
	checkTimes.set(uid, times);
	if (checkTimes.size > 2e4) checkTimes.clear();
	return false;
}
function newCaptchaImage(userId) {
	const uid = String(userId);
	if (tooMany(`capimg:${uid}`, 12, 6e5)) return null;
	const word = randomCaptchaWord();
	captchaPending.set(uid, {
		word,
		exp: Date.now() + 3e5,
		tries: 0
	});
	if (captchaPending.size > 2e4) captchaPending.clear();
	return renderCaptcha(word);
}
function solveCaptcha(userId, answer) {
	const uid = String(userId);
	const p = captchaPending.get(uid);
	if (!p || Date.now() > p.exp) {
		captchaPending.delete(uid);
		return "expired";
	}
	if (normalizeCaptchaAnswer(answer) === normalizeCaptchaAnswer(p.word)) {
		captchaPending.delete(uid);
		checkTimes.delete(uid);
		captchaCredit.set(uid, CAPTCHA_CREDIT);
		submitPass.set(uid, Date.now() + 9e5);
		if (submitPass.size > 2e4) submitPass.clear();
		return "ok";
	}
	p.tries += 1;
	if (p.tries >= 3) {
		captchaPending.delete(uid);
		return "expired";
	}
	return "wrong";
}
function packCaption(full, _fallback = "") {
	if (full.length <= 1024) return {
		caption: full,
		leftover: ""
	};
	return {
		caption: "",
		leftover: full
	};
}
async function attachReviewButtons(chatId, messageId, leftover, keyboard) {
	if (!leftover) return (await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Опубликовать или отклонить:",
		reply_to_message_id: messageId,
		reply_markup: keyboard
	}))?.message_id || messageId;
	const parts = splitHtml(leftover);
	let lastId = messageId;
	for (let i = 0; i < parts.length; i++) {
		const sent = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: parts[i],
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_to_message_id: i === 0 ? messageId : void 0,
			reply_markup: i === parts.length - 1 ? keyboard : void 0
		});
		if (sent?.message_id) lastId = sent.message_id;
	}
	return lastId;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
function groupMedia(files) {
	const groups = [];
	let current = [];
	let currentDoc = false;
	for (const file of files) {
		const isDoc = (file.type || file.kind) === "document";
		if (current.length && (current.length >= 10 || isDoc !== currentDoc)) {
			groups.push(current);
			current = [];
		}
		currentDoc = isDoc;
		current.push(file);
	}
	if (current.length) groups.push(current);
	return groups;
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard, followUp = caption) {
	if (!files.length) {
		const parts = splitHtml(followUp);
		let lastId = 0;
		let lastChat = chatId;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id: chatId,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		return {
			chat_id: lastChat,
			message_id: lastId,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const packed = packCaption(followUp, caption);
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = { chat_id: chatId };
		if (packed.caption) {
			payload.caption = packed.caption;
			payload.parse_mode = "HTML";
		}
		if (!packed.leftover) payload.reply_markup = keyboard;
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		if (!packed.leftover) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	const packed = packCaption(followUp, caption);
	let firstId = 0;
	for (const [i, chunk] of groupMedia(files).entries()) {
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0 && packed.caption) {
				payload.caption = packed.caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard, followUp = caption) {
	const packed = packCaption(followUp, caption);
	const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
	const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
	const files = [];
	let firstId = 0;
	if (!small.length && large.length) {
		const sent = await sendMediaFile(chatId, large[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length > 1 ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		for (const extra of large.slice(1)) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && large.length === 1) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	if (small.length <= 1) {
		const sent = await sendMediaFile(chatId, small[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		firstId = sent.message_id;
		for (const extra of large) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && !large.length) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	for (let i = 0; i < small.length; i += 10) {
		const chunk = small.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 && packed.caption ? { caption: packed.caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	for (const extra of large) {
		const more = await sendMediaFile(chatId, extra);
		if (more.fileId) files.push({
			type: more.kind,
			file_id: more.fileId
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendDetail(chatId, html, replyTo) {
	for (const [i, part] of splitHtml(html).entries()) await tgSoft("sendMessage", {
		chat_id: chatId,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: i === 0 ? replyTo : void 0
	});
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const briefText = applicationBriefHtml(app);
	const detailText = applicationDetailHtml(app);
	const keyboard = reviewKeyboard(app.id);
	const blobs = app.evidence.filter((f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard, briefText) : null;
			if (sent) {
				if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard, briefText);
			if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const parts = splitHtml(briefText);
		let lastId = 0;
		let lastChat = chat_id;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		if (detailText) await sendDetail(lastChat, detailText, lastId);
		storePending(app, []);
		return {
			chat_id: lastChat,
			message_id: lastId
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const userId = app.victim.telegramId || "";
	const blocked = allowNewComplaint(userId, app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
	app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
		...file,
		name: String(file.name || "file").slice(0, 120),
		dataUrl: "",
		storageKey: evidenceOwnedBy(file.storageKey, userId) ? file.storageKey : void 0
	}));
	if (app.evidence.length > 30) return {
		ok: false,
		error: btUser(userId, "tooManyFiles")
	};
	for (const account of scammerAccounts(app).slice(0, 8)) {
		account.username = String(account.username || "").replace(/^@/, "").trim();
		account.telegramId = /^\d{5,15}$/.test(String(account.telegramId || "").trim()) ? String(account.telegramId).trim() : "";
		account.check = "unknown";
		if (account.username) {
			const found = await lookupVerifiedId(account.username);
			if (found && found !== "busy") {
				if (account.telegramId && account.telegramId !== found.id) account.claimedId = account.telegramId;
				account.telegramId = found.id;
				account.check = account.claimedId ? "mismatch" : "ok";
			}
		} else if (account.telegramId) {
			const chat = await tgSoft("getChat", { chat_id: account.telegramId });
			if (chat?.type === "private" && chat.username) {
				account.username = chat.username;
				rememberHandle(chat.username, account.telegramId);
				account.check = "ok";
			}
		}
	}
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		if (pendingPosts[app.id]) {
			pendingPosts[app.id].reviewChatId = String(sent.chat_id);
			pendingPosts[app.id].reviewMessageId = sent.message_id;
			savePending();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: btUser(userId, "addBotArbiter", { bot: BOT_USERNAME })
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseAppKey(text, data = "") {
	const fromCb = callbackKey(data);
	if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
	const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
	if (fromText?.[1]) return fromText[1];
	return parseEpbMarker(text)?.key || fromCb;
}
function stripServiceMarker(text) {
	return text.replace(/\n*#epb[^\n]*/gi, "").replace(/\n*#published[^\n]*/gi, "").replace(/\n*#rejected[^\n]*/gi, "").replace(/\n*Статус:[^\n]*/gi, "").trim();
}
function alreadyHandled(text) {
	return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
var PartialSendError = class extends Error {
	sentIds;
	answered;
	constructor(cause, sentIds) {
		super(cause instanceof Error ? cause.message : String(cause));
		this.sentIds = sentIds;
		this.answered = cause instanceof TgError;
	}
};
async function sendPostToChat(chat_id, html, files) {
	const ids = [];
	try {
		return await sendPostParts(chat_id, html, files, ids);
	} catch (err) {
		throw new PartialSendError(err, ids);
	}
}
async function sendPostParts(chat_id, html, files, ids) {
	const collect = (sent) => {
		for (const m of Array.isArray(sent) ? sent : [sent]) {
			const id = m?.message_id;
			if (id) ids.push(id);
		}
	};
	const packed = packCaption(html);
	const parts = packed.leftover ? splitHtml(packed.leftover, 4090) : [];
	if (!files.length) {
		const chunks = splitHtml(html, 4090);
		for (const part of chunks) collect(await tg("sendMessage", {
			chat_id,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: false
		}));
		return ids;
	}
	for (const [i, chunk] of groupMedia(files).entries()) {
		const firstCaption = i === 0 && packed.caption ? packed.caption : void 0;
		if (chunk.length === 1) {
			const file = chunk[0];
			const payload = {
				chat_id,
				caption: firstCaption,
				parse_mode: firstCaption ? "HTML" : void 0
			};
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			collect(await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload));
		} else collect(await tg("sendMediaGroup", {
			chat_id,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...firstCaption && idx === 0 ? {
					caption: firstCaption,
					parse_mode: "HTML"
				} : {}
			}))
		}));
	}
	for (const part of parts) collect(await tg("sendMessage", {
		chat_id,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: false
	}));
	return ids;
}
function isMissingRights(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /not enough rights|need administrator|have no rights|CHAT_WRITE_FORBIDDEN|not allowed to post|CHAT_SEND_\w+_FORBIDDEN/i.test(text);
}
function isChatGone(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /chat not found|bot was blocked|bot is not a member|kicked|chat was deactivated|group chat was upgraded/i.test(text);
}
function isGroupOrChannel(chat) {
	if (chat.type === "private") return false;
	if (chat.type === "group" || chat.type === "supergroup" || chat.type === "channel") return true;
	const id = Number(chat.id);
	return Number.isFinite(id) && id < 0;
}
function relayDestinations() {
	const skip = new Set([
		...channelCandidates(),
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId || "",
		...OFFICIAL_ARBITER_IDS
	].filter(Boolean).map((id) => chatIdKey(id)));
	const seen = /* @__PURE__ */ new Set();
	return (bindings.relayChats || []).filter((chat) => {
		const k = chatIdKey(chat.id);
		if (chat.status !== "on" || !isGroupOrChannel(chat) || skip.has(k) || seen.has(k)) return false;
		seen.add(k);
		return true;
	});
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	let lastError = "channel not found";
	for (const chat_id of ids) try {
		return {
			chatId: chat_id,
			messageIds: await sendPostToChat(chat_id, html, files)
		};
	} catch (err) {
		if (err instanceof PartialSendError && err.sentIds.length) return {
			chatId: chat_id,
			messageIds: err.sentIds,
			partialError: err.message
		};
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
var RIGHTS_NOTICE_EVERY = 864e5;
function isMediaForbidden(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /rights to send (photos|videos|documents|media|audios|voice)|CHAT_SEND_(PHOTOS|VIDEOS|MEDIA|DOCS|GIFS)_FORBIDDEN/i.test(text);
}
var BROADCAST_PATH = join(DATA_DIR, "telegram-broadcasts.json");
var broadcastJobs = readJson(BROADCAST_PATH) || [];
var migratedKeys = /* @__PURE__ */ new Map();
function saveBroadcastJobs() {
	try {
		writeJsonAtomic(BROADCAST_PATH, broadcastJobs);
	} catch {}
}
async function channelAllowsForwarding(chatId) {
	return !(await tgSoft("getChat", { chat_id: chatId }))?.has_protected_content;
}
function recordRelayDelivery(key, chatId, messageIds) {
	const ids = messageIds.filter((n) => Number.isFinite(n));
	if (!key || !ids.length) return;
	const rec = pendingPosts[key];
	if (!rec) return;
	const list = rec.relayDeliveries ||= [];
	const k = chatIdKey(chatId);
	const existing = list.find((d) => chatIdKey(d.chatId) === k);
	if (existing) {
		for (const id of ids) if (!existing.messageIds.includes(id)) existing.messageIds.push(id);
	} else list.push({
		chatId: String(chatId),
		messageIds: [...ids]
	});
	savePending();
}
async function runBroadcast(job) {
	const report = job.report;
	if (job.inflight && !job.done.includes(job.inflight)) {
		(report.unconfirmed ||= []).push(`${job.inflight}: сервер перезапустился во время отправки, повторно не отправляли`);
		report.sent += 1;
		job.done.push(job.inflight);
	}
	job.inflight = void 0;
	const done = new Set(job.done);
	const approved = relayDestinations().filter((c) => !done.has(chatIdKey(c.id)));
	report.total = Math.max(report.total, done.size + approved.length);
	let forward = Boolean(job.source?.messageIds.length) && await channelAllowsForwarding(job.source.chatId);
	if (job.source?.messageIds.length && !forward && !report.failed.some((x) => x.startsWith("пересылка"))) report.failed.push("пересылка из канала запрещена (защита контента), в чаты ушли копии");
	let forwardedOk = 0;
	let emptyInARow = 0;
	for (const chat of approved) {
		if (job.done.includes(chatIdKey(chat.id))) continue;
		const label = chat.title ? `${chat.title} (${chat.id})` : chat.id;
		job.inflight = chatIdKey(chat.id);
		saveBroadcastJobs();
		try {
			let viaForward = false;
			if (forward && job.source) {
				let result = null;
				let fwdErr = null;
				try {
					result = await tg("forwardMessages", {
						chat_id: chat.id,
						from_chat_id: job.source.chatId,
						message_ids: job.source.messageIds
					});
				} catch (err) {
					fwdErr = err;
				}
				if (!fwdErr && result && result.length >= job.source.messageIds.length) {
					viaForward = true;
					forwardedOk += 1;
					emptyInARow = 0;
					recordRelayDelivery(job.key, chat.id, result.map((m) => m?.message_id).filter((n) => typeof n === "number"));
				} else if (fwdErr instanceof TgError && /protected|CHAT_FORWARDS_RESTRICTED|message to forward not found|message can't be forwarded/i.test(fwdErr.message)) {
					forward = false;
					report.failed.push("пересылка из канала невозможна (защита контента или пост удалён), в чаты ушли копии");
				} else if (fwdErr instanceof TgError && (isChatGone(fwdErr) || isMissingRights(fwdErr) && !isMediaForbidden(fwdErr))) throw fwdErr;
				else if (fwdErr instanceof TgError && isMediaForbidden(fwdErr)) {} else {
					(report.unconfirmed ||= []).push(`${label}: ${fwdErr instanceof Error ? fwdErr.message.replace(/^Bad Request: /, "") : `переслано ${result?.length ?? 0} из ${job.source.messageIds.length}`}`);
					viaForward = true;
					if (!fwdErr && result && !result.length && !forwardedOk && ++emptyInARow >= 3) {
						forward = false;
						report.failed.push("пересылка из канала не работает (Telegram пропускает сообщения), остальным чатам ушли копии");
					}
				}
			}
			if (!viaForward) try {
				const ids = await sendPostToChat(chat.id, job.html, job.files);
				recordRelayDelivery(job.key, chat.id, ids);
				if (forward) (report.copies ||= []).push(label);
			} catch (err) {
				const refusedCleanly = err instanceof PartialSendError && err.answered && !err.sentIds.length;
				if (!job.files.length || !refusedCleanly || !isMediaForbidden(err)) throw err;
				const ids = await sendPostToChat(chat.id, job.html, []);
				recordRelayDelivery(job.key, chat.id, ids);
				(report.textOnly ||= []).push(label);
			}
			report.sent += 1;
		} catch (err) {
			if (isMissingRights(err)) {
				report.noRights.push(label);
				const relay = findRelay(chat.id);
				if (relay && Date.now() - (relay.rightsNoticeAt || 0) > RIGHTS_NOTICE_EVERY) {
					relay.rightsNoticeAt = Date.now();
					saveBindings();
					await tgSoft("sendMessage", {
						chat_id: chat.id,
						text: "Сообщение для администрации: Вы не выдали достаточно прав для отправки рассылки в Вашем чате."
					});
				}
			} else if (isChatGone(err)) report.gone.push(label);
			else {
				const noAnswer = !(err instanceof TgError) && !(err instanceof PartialSendError && err.answered) && !(err instanceof Error && err.message.startsWith("пересланы"));
				report.failed.push(noAnswer ? `${label}: Telegram не ответил (возможно, пост дошёл); повторно не отправляем, чтобы не было дублей` : `${label}: ${err instanceof Error ? err.message : String(err)}`);
			}
		}
		const k = chatIdKey(chat.id);
		job.done.push(k);
		job.inflight = void 0;
		const moved = migratedKeys.get(k);
		if (moved) job.done.push(moved);
		saveBroadcastJobs();
		await sleep(Math.max(50, 40 * ((forward ? job.source?.messageIds.length : job.files.length) || 1)));
	}
	return report;
}
async function finishBroadcast(job) {
	const report = job.report;
	bindings.lastBroadcast = {
		at: Date.now(),
		total: report.total,
		sent: report.sent,
		noRights: report.noRights.length,
		gone: report.gone.length,
		failed: report.failed.length
	};
	saveBindings();
	broadcastJobs = broadcastJobs.filter((j) => j.id !== job.id);
	saveBroadcastJobs();
	if (!job.reportTo || !report.total) return;
	await tgSoft("sendMessage", {
		chat_id: job.reportTo.chatId,
		text: broadcastReportHtml(report),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: job.reportTo.messageId
	});
}
async function deleteChatMessages(chatId, messageIds) {
	let ok = 0;
	let fail = 0;
	const ids = [...new Set(messageIds.filter((n) => Number.isFinite(n)))];
	for (let i = 0; i < ids.length; i += 100) {
		const batch = ids.slice(i, i + 100);
		if (await tgSoft("deleteMessages", {
			chat_id: chatId,
			message_ids: batch
		})) ok += batch.length;
		else for (const id of batch) if (await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: id
		})) ok += 1;
		else fail += 1;
		await sleep(40);
	}
	return {
		ok,
		fail
	};
}
async function deletePublishedEverywhere(key) {
	const channel = {
		ok: 0,
		fail: 0
	};
	const chats = {
		ok: 0,
		fail: 0
	};
	let chatCount = 0;
	const rec = pendingPosts[key];
	if (!rec) return {
		channel,
		chats,
		chatCount
	};
	if (rec.channelChatId && rec.channelMsgIds?.length) {
		const r = await deleteChatMessages(rec.channelChatId, rec.channelMsgIds);
		channel.ok += r.ok;
		channel.fail += r.fail;
	}
	for (const d of rec.relayDeliveries || []) {
		if (!d.messageIds.length) continue;
		chatCount += 1;
		const r = await deleteChatMessages(d.chatId, d.messageIds);
		chats.ok += r.ok;
		chats.fail += r.fail;
	}
	rec.deletedEverywhere = true;
	rec.channelPosted = false;
	rec.removedFromCheck = true;
	rec.relayDeliveries = [];
	rec.channelMsgIds = [];
	savePending();
	return {
		channel,
		chats,
		chatCount
	};
}
function enqueueBroadcast(job) {
	broadcastQueue = broadcastQueue.then(() => runBroadcast(job)).then(() => finishBroadcast(job)).catch((err) => console.error("[epb] broadcast", err));
}
function resumeBroadcasts() {
	const fresh = broadcastJobs.filter((j) => Date.now() - j.startedAt < 432e5);
	if (fresh.length !== broadcastJobs.length) {
		broadcastJobs = fresh;
		saveBroadcastJobs();
	}
	for (const job of fresh) {
		console.log(`[epb] resuming broadcast ${job.key}: ${job.done.length} chats already done`);
		enqueueBroadcast(job);
	}
}
function broadcastReportHtml(report) {
	const list = (items) => items.slice(0, 15).map((x) => `• ${escapeHtml(x)}`).join("\n") + (items.length > 15 ? `\n… и ещё ${items.length - 15}` : "");
	const unsure = report.unconfirmed?.length || 0;
	const lines = [`<b>Рассылка завершена</b>: доставлено ${report.sent - unsure} из ${report.total}` + (unsure ? `, без подтверждения ${unsure}` : "")];
	if (report.unconfirmed?.length) lines.push("", `<b>Telegram ответил ошибкой, но пост обычно доходит — проверьте чат, повторно не отправляли (${report.unconfirmed.length})</b>`, list(report.unconfirmed));
	if (report.copies?.length) lines.push("", `<b>Пересылка в чат не прошла, отправлено копией (${report.copies.length})</b>`, list(report.copies));
	if (report.textOnly?.length) lines.push("", `<b>В чате запрещены фото/видео, отправлен только текст (${report.textOnly.length})</b>`, list(report.textOnly));
	if (report.noRights.length) lines.push("", `<b>Нет прав (${report.noRights.length})</b>`, list(report.noRights));
	if (report.gone.length) lines.push("", `<b>Бот удалён или чат недоступен (${report.gone.length})</b>`, list(report.gone));
	if (report.failed.length) lines.push("", `<b>Ошибки (${report.failed.length})</b>`, list(report.failed));
	return lines.join("\n");
}
function entitiesToHtml(text, entities = []) {
	const tags = {
		bold: ["<b>", "</b>"],
		italic: ["<i>", "</i>"],
		underline: ["<u>", "</u>"],
		strikethrough: ["<s>", "</s>"],
		spoiler: ["<tg-spoiler>", "</tg-spoiler>"],
		code: ["<code>", "</code>"],
		pre: ["<pre>", "</pre>"],
		blockquote: ["<blockquote>", "</blockquote>"],
		expandable_blockquote: ["<blockquote expandable>", "</blockquote>"]
	};
	const opens = /* @__PURE__ */ new Map();
	const closes = /* @__PURE__ */ new Map();
	const usable = entities.filter((e) => typeof e.offset === "number" && typeof e.length === "number" && e.length > 0).filter((e) => tags[e.type] || e.type === "text_link" && /^https?:\/\//i.test(e.url || "")).sort((a, b) => a.offset - b.offset || b.length - a.length);
	for (const e of usable) {
		const [open, close] = e.type === "text_link" ? [`<a href="${escapeHtml(e.url || "")}">`, "</a>"] : tags[e.type];
		if (e.offset >= text.length) continue;
		opens.set(e.offset, [...opens.get(e.offset) || [], open]);
		const end = Math.min(e.offset + e.length, text.length);
		closes.set(end, [close, ...closes.get(end) || []]);
	}
	let out = "";
	for (let i = 0; i <= text.length; i++) {
		out += (closes.get(i) || []).join("");
		out += (opens.get(i) || []).join("");
		if (i < text.length) out += escapeHtml(text[i]);
	}
	return out;
}
var postEditPrompts = /* @__PURE__ */ new Map();
function postPreviewHtml(key) {
	const rec = pendingPosts[key];
	return channelHtml(pendingAccounts(rec), rec.summary || rec.story, rec.amount, rec.currency, rec.postHtml);
}
async function sendPostPreview(chatId, key, replyTo) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const repeat = previousPosts(pendingAccounts(rec), key);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `${`<b>Предпросмотр поста ${escapeHtml(key)}</b>${rec.postHtml ? " (текст изменён)" : ""}` + (rec.files?.length ? `\nК посту приложится доказательств: ${rec.files.length}` : "") + (repeat ? `\n${repeat}` : "")}\n━━━━━━━━━━\n${postPreviewHtml(key)}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: replyTo,
		reply_markup: publishChoiceKeyboard(key)
	});
}
async function askPostEdit(chatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			`<b>Новый текст поста ${escapeHtml(key)}</b>`,
			"",
			"Ответьте на это сообщение новым текстом. Можно жирный, курсив и ссылки.",
			"Строки с аккаунтом и суммой и подпись Subscribe бот добавит сам.",
			"",
			"Сейчас в посте:",
			rec.postHtml || escapeHtml((rec.summary || rec.story).trim())
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Новый текст поста"
		}
	});
	if (prompt?.message_id) {
		postEditPrompts.set(`${chatId}:${prompt.message_id}`, key);
		if (postEditPrompts.size > 200) postEditPrompts.delete(postEditPrompts.keys().next().value);
	}
}
async function handlePostEditReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const key = postEditPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!key) return false;
	const rec = pendingPosts[key];
	if (!rec || rec.status !== "pending") {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Заявка уже обработана, текст не изменён.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const text = (msg.text || msg.caption || "").trim();
	if (text.length < 5) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком коротко. Ответьте на сообщение бота ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	if (text.length > 3500) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком длинно: максимум 3500 символов.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const html = entitiesToHtml(msg.text || msg.caption || "", msg.entities || msg.caption_entities).trim();
	const previous = rec.postHtml;
	rec.postHtml = html;
	if (postPreviewHtml(key).length > 3900) {
		rec.postHtml = previous;
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пост получается слишком длинным для Telegram. Сократите текст и ответьте ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	savePending();
	postEditPrompts.delete(`${msg.chat.id}:${replyTo}`);
	await sendPostPreview(msg.chat.id, key, msg.message_id);
	return true;
}
var publishing = /* @__PURE__ */ new Set();
var broadcastQueue = Promise.resolve();
async function publishFromMessage(text, callbackId, extraFiles = [], relay = false, keyHint = "", reportTo) {
	const parsed = parseEpbMarker(text);
	const key = keyHint || parsed?.key || "";
	const stored = key ? pendingPosts[key] : void 0;
	if (!parsed && !stored) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	if (stored?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (stored?.status === "rejected") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Заявка уже отклонена",
			show_alert: true
		});
		return false;
	}
	const lock = key || `txt:${createHash("sha256").update(text).digest("hex").slice(0, 16)}`;
	if (!key && pendingPosts[lock]?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (publishing.has(lock)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже публикуем"
		});
		return false;
	}
	publishing.add(lock);
	const html = channelHtml(pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""), stored?.summary || stored?.story || parsed?.story || "", stored?.amount, stored?.currency, stored?.postHtml);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	let channelPost;
	try {
		channelPost = await sendChannelPost(html, files);
	} catch {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: relay ? "Не удалось опубликовать в канал. Чаты без прав пропускаются." : "Не удалось опубликовать. Бот должен быть админом канала.",
			show_alert: true
		});
		return false;
	}
	if (key && pendingPosts[key]) {
		pendingPosts[key].status = "published";
		pendingPosts[key].channelPosted = true;
		pendingPosts[key].channelChatId = channelPost.chatId;
		pendingPosts[key].channelMsgIds = channelPost.messageIds;
	} else pendingPosts[lock] = {
		username: "",
		id: "",
		story: "",
		amount: "",
		currency: "",
		files: [],
		createdAt: Date.now(),
		status: "published",
		channelPosted: true
	};
	savePending();
	if (relay) {
		const job = {
			id: randomUUID(),
			key: lock,
			html,
			files,
			source: channelPost,
			done: [],
			report: {
				total: 0,
				sent: 0,
				noRights: [],
				gone: [],
				failed: []
			},
			reportTo,
			startedAt: Date.now()
		};
		broadcastJobs.push(job);
		saveBroadcastJobs();
		enqueueBroadcast(job);
	}
	publishing.delete(lock);
	if (key && pendingPosts[key]) await notifyApplicant(pendingPosts[key], key, "published");
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: channelPost.partialError ? "Пост в канале вышел не целиком. Повторно не публикуем — проверьте канал." : relay ? "Опубликовано в канал, рассылка по чатам идёт" : "Опубликовано без рассылки",
		show_alert: Boolean(channelPost.partialError)
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
var channelSetup = /* @__PURE__ */ new Set();
var checkChannelSetup = /* @__PURE__ */ new Set();
var removeFromCheckSetup = /* @__PURE__ */ new Set();
var addBlacklistSetup = /* @__PURE__ */ new Set();
var sponsorLinkSetup = /* @__PURE__ */ new Map();
var bannerSetup = /* @__PURE__ */ new Map();
function gcSessions() {
	const now = Date.now();
	for (const [id, session] of sessions) if (now - (session.touched || 0) > 72e5) sessions.delete(id);
	if (sessions.size <= 400) return;
	const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
	for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard(locale) {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: tb(locale, "openApp"),
		web_app: { url }
	}]);
	rows.push([{
		text: tb(locale, "applyBtn"),
		callback_data: "apply"
	}]);
	if (checkEnabled()) rows.push([{
		text: tb(locale, "checkMenuBtn"),
		callback_data: "bcheck"
	}]);
	rows.push([{
		text: tb(locale, "sponsorsMenuBtn"),
		callback_data: "bsponsors"
	}]);
	rows.push([{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}, {
		text: tb(locale, "ownersBtn"),
		callback_data: "owners"
	}]);
	rows.push([{
		text: tb(locale, "langBtn"),
		callback_data: "lang"
	}]);
	return { inline_keyboard: rows };
}
var checkWait = /* @__PURE__ */ new Set();
function backToMenuKeyboard(locale) {
	return { inline_keyboard: [[{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function checkResultKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "checkMore"),
		callback_data: "bcheck"
	}], [{
		text: tb(locale, "inMenu"),
		callback_data: "home"
	}]] };
}
async function botSponsorsText(locale) {
	const list = await listSponsors().catch(() => []);
	const lines = [`<b>${tb(locale, "sponsorsMenuBtn").replace(/^\s*[^\p{L}\p{N}]+\s*/u, "")}</b>`, ""];
	if (!list.length) {
		lines.push(tb(locale, "sponsorsEmptyB"));
		return lines.join("\n");
	}
	for (const s of list.slice(0, 20)) lines.push(s.link ? `• <a href="${s.link}">${escapeHtml(s.title)}</a>` : `• ${escapeHtml(s.title)}`);
	if (list.length > 20) lines.push(`… +${list.length - 20}`);
	return lines.join("\n");
}
function formatBotCheck(locale, input, res) {
	const q = res.query.username ? `@${res.query.username}` : res.query.id ? `ID ${res.query.id}` : input.trim();
	if (!(res.epb.length || res.manual.length || res.channels.length)) return tb(locale, "checkClean", { q: escapeHtml(q) });
	const lines = [`🔎 <b>${escapeHtml(q)}</b>`, ""];
	if (res.epb.length) {
		lines.push(tb(locale, "checkEpbHdr"));
		for (const e of res.epb.slice(0, 6)) lines.push(`• ${escapeHtml(e.accounts)}${e.amount ? ` — ${escapeHtml(e.amount)} ${escapeHtml(e.currency)}` : ""}`);
		lines.push("");
	}
	for (const m of res.manual.slice(0, 6)) lines.push(`📛 ${escapeHtml(m.source)}: ${escapeHtml(m.account)}`);
	if (res.channels.length) {
		const allWwh = res.channels.every((c) => /wwh/i.test(c.channelTitle || ""));
		lines.push(allWwh ? tb(locale, "checkFoundForum") : tb(locale, "checkFoundChats"));
		for (const c of res.channels.slice(0, 8)) {
			const wwh = /wwh/i.test(c.channelTitle || "");
			const name = wwh ? "WWH" : c.channelTitle || "источник";
			lines.push(wwh ? `• ${escapeHtml(name)}` : `• <a href="${c.link}">${escapeHtml(name)}</a>`);
		}
		lines.push("");
	}
	lines.push(tb(locale, "checkDispute"));
	return lines.join("\n").slice(0, 3900);
}
var botCaptchaWait = /* @__PURE__ */ new Map();
var SUBMIT_CAPTCHA = "\0submit";
async function sendBotCaptcha(chatId, intro) {
	const png = newCaptchaImage(String(chatId));
	if (!png) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Слишком много попыток. Попробуйте через 10 минут."
		});
		return false;
	}
	const form = new FormData();
	form.set("chat_id", String(chatId));
	form.set("caption", intro);
	form.set("reply_markup", JSON.stringify({ inline_keyboard: [[{
		text: "🔄 Другая картинка",
		callback_data: "bcap:new"
	}], [{
		text: "✖ Отмена",
		callback_data: "bcap:x"
	}]] }));
	form.set("photo", new File([new Uint8Array(png)], "captcha.png", { type: "image/png" }));
	try {
		await tgForm("sendPhoto", form);
		return true;
	} catch {
		return false;
	}
}
async function runBotCheck(chatId, input, skipGate = false) {
	if (!skipGate) {
		if (tooMany(`check:${chatId}`, 30, 6e4)) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Слишком много проверок. Подождите минуту."
			});
			return;
		}
		if (captchaRequired(String(chatId))) {
			botCaptchaWait.set(String(chatId), input);
			await sendBotCaptcha(chatId, "🤖 Много проверок подряд. Напишите слово с картинки, чтобы продолжить.");
			return;
		}
	}
	const locale = langOf(chatId);
	await tgSoft("sendChatAction", {
		chat_id: chatId,
		action: "typing"
	});
	let res;
	try {
		res = await checkCounterparty(input);
	} catch {
		res = {
			query: {
				username: "",
				id: ""
			},
			epb: [],
			channels: [],
			manual: []
		};
	}
	await sendCeMessage(chatId, formatBotCheck(locale, input, res), {
		reply_markup: checkResultKeyboard(locale),
		disable_web_page_preview: true
	});
}
function applyCancelRow(chatId) {
	return [{
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}];
}
function startText(locale) {
	return tb(locale, "start");
}
function ownersText(locale) {
	return tb(locale, "owners", { bot: BOT_USERNAME });
}
function ownersKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}], [{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function langKeyboard(withBack = false) {
	const rows = [[{
		text: "Русский",
		callback_data: "lang:ru"
	}, {
		text: "English",
		callback_data: "lang:en"
	}]];
	if (withBack) rows.push([{
		text: "⬅️ Назад / Back",
		callback_data: "home"
	}]);
	return { inline_keyboard: rows };
}
var LANG_PROMPT = "Выберите язык / Choose language";
async function askLanguage(chatId, withBack = false) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Выберите язык / Choose language",
		reply_markup: langKeyboard(withBack)
	});
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	const candidates = [
		join(process.cwd(), "public/bot", name),
		join(process.cwd(), ".output/public/bot", name),
		join(process.cwd(), "public", name),
		join("/workspace/public/bot", name),
		join("/workspace/.output/public/bot", name)
	];
	try {
		const here = dirname(fileURLToPath(import.meta.url));
		candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
	} catch {}
	return candidates.find((p) => existsSync(p)) || null;
}
function cardBytes(kind) {
	if (kind === "welcome") try {
		return Buffer.from(WELCOME_JPEG_BASE64, "base64");
	} catch {}
	const path = cardPath(kind);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const rich = useCe ? applyCustomEmoji(caption) : caption;
	const plainMarkup = extra.reply_markup;
	const richMarkup = useCe ? decorateButtons(plainMarkup, true) : plainMarkup;
	const needsRich = useCe && (hasCustomEmoji(rich) || markupHasIconableButton(plainMarkup));
	const cap = needsRich ? rich : caption;
	const rest = (markup) => {
		const { reply_markup: _omit, ...other } = extra;
		return markup === void 0 ? other : {
			...other,
			reply_markup: markup
		};
	};
	const trySend = async (method, build) => {
		try {
			return await tg(method, build(cap, needsRich ? richMarkup : plainMarkup));
		} catch (err) {
			if (needsRich && isCustomEmojiError(err)) return await tgSoft(method, build(caption, plainMarkup));
			return null;
		}
	};
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await trySend("sendPhoto", (c, markup) => ({
			chat_id: chatId,
			photo: cached,
			caption: c,
			parse_mode: "HTML",
			...rest(markup)
		}))) return;
		if (bindings.cards) delete bindings.cards[kind];
		saveBindings();
	}
	const bytes = cardBytes(kind);
	if (bytes?.length) {
		const sendForm = (c, markup) => {
			const form = new FormData();
			form.set("chat_id", String(chatId));
			form.set("caption", c);
			form.set("parse_mode", "HTML");
			if (markup) form.set("reply_markup", JSON.stringify(markup));
			form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
			return tgForm("sendPhoto", form);
		};
		try {
			let sent;
			try {
				sent = await sendForm(cap, needsRich ? richMarkup : plainMarkup);
			} catch (err) {
				if (needsRich && isCustomEmojiError(err)) sent = await sendForm(caption, plainMarkup);
				else throw err;
			}
			const fileId = sent.photo?.at(-1)?.file_id;
			if (fileId) {
				bindings.cards = {
					...bindings.cards,
					[kind]: fileId
				};
				saveBindings();
			}
			return;
		} catch {}
	}
	await trySend("sendMessage", (c, markup) => ({
		chat_id: chatId,
		text: c,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		...rest(markup)
	}));
}
async function startCaption(locale) {
	return startText(locale);
}
async function replyStart(chatId, userId) {
	const locale = langOf(userId ?? chatId);
	await sendCard(chatId, "welcome", await startCaption(locale), { reply_markup: applyKeyboard(locale) });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		summary: "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: [],
		touched: Date.now()
	};
}
function parseAmount(text) {
	return parseDamageAmount(text);
}
function formatAmount(amount) {
	const [intPart, frac] = amount.split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return frac ? `${grouped}.${frac}` : grouped;
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session, userId) {
	if (!session.accounts.length) return btUser(userId, "emptyAccounts");
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function sendStep(chatId, text, extra = {}) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
	const sent = await sendCeMessage(chatId, text, extra);
	if (session && sent?.message_id) session.stepMsgId = sent.message_id;
	return sent;
}
function clearStepMessage(chatId, deleteIt = true) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		if (deleteIt) tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session, chatId) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: btUser(chatId, "moreAccount"),
		callback_data: "apply:more"
	}, {
		text: btUser(chatId, "next"),
		callback_data: "apply:next"
	}]);
	rows.push(applyCancelRow(chatId));
	await sendStep(chatId, session?.accounts.length ? btUser(chatId, "accountsListed", { list: listed }) : btUser(chatId, "stepAccounts"), { reply_markup: { inline_keyboard: rows } });
}
async function askSummary(chatId) {
	await sendStep(chatId, btUser(chatId, "stepSummary"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askStory(chatId) {
	await sendStep(chatId, btUser(chatId, "stepStory"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askAmount(chatId) {
	await sendStep(chatId, btUser(chatId, "stepAmount"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askCurrency(chatId, amount) {
	await sendStep(chatId, btUser(chatId, "pickCurrency", { amount: formatAmount(amount) }), { reply_markup: { inline_keyboard: [[{
		text: "💵 USD",
		callback_data: "apply:cur:USD"
	}, {
		text: "💶 EUR",
		callback_data: "apply:cur:EUR"
	}], applyCancelRow(chatId)] } });
}
async function askEvidence(chatId) {
	await sendStep(chatId, btUser(chatId, "stepEvidence"), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "done"),
		callback_data: "apply:done"
	}, {
		text: btUser(chatId, "skipFiles"),
		callback_data: "apply:skip"
	}], applyCancelRow(chatId)] } });
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? btUser(chatId, "filesCount", { n: session.evidence.length }) : btUser(chatId, "noFiles");
	await sendStep(chatId, btUser(chatId, "confirm", {
		accounts: formatSessionAccounts(session, chatId),
		victim,
		id: session.victimId,
		amount: session.amount,
		currency: session.currency,
		files,
		summary: session.summary,
		story: session.story
	}), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "sendReview"),
		callback_data: "apply:send"
	}, {
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}]] } });
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await sendCeMessage(chatId, btUser(from.id, "applyStart"));
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice) {
	clearStepMessage(chatId);
	sessions.delete(userId);
	await sendCeMessage(chatId, notice || btUser(userId, "cancel"), { reply_markup: applyKeyboard(langOf(userId)) });
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needAccountSubmit")
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (!session.summary.trim() || session.summary.trim().length < 10) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needSummary")
		});
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (!session.story.trim() || session.story.trim().length < 20) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needStory")
		});
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		summary: session.summary,
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || btUser(userId, "sendFail")
		});
		return;
	}
	consumeSubmitPass(userId);
	clearStepMessage(chatId);
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: btUser(userId, "sent", { id: app.id })
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: btUser(userId, "addAccountLeast")
					});
					return;
				}
				session.step = "summary";
				sessions.set(userId, session);
				await askSummary(chatId);
				return;
			}
			const resolved = await resolveHandleServer(raw, userId);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "parseAccount")
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "idNoNumeric", { user: resolved.username })
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (session.step === "summary") {
		const summary = (msg.text || msg.caption || "").trim();
		if (summary.length < 10) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needSummary")
			});
			return;
		}
		if (summary.length > 800) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "summaryLong")
			});
			return;
		}
		session.summary = summary;
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 20) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needStory")
			});
			return;
		}
		if (story.length > 5e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "storyLong")
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needAmount")
			});
			return;
		}
		session.amount = parsed.amount;
		if (!parsed.currency) {
			sessions.set(userId, session);
			await askCurrency(chatId, parsed.amount);
			return;
		}
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 30) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "fileAccepted", { n: session.evidence.length }),
				reply_markup: { inline_keyboard: [[{
					text: btUser(userId, "done"),
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "sendMedia")
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: btUser(cb.from?.id, "applyInDm"),
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(cb.from?.id, "applyOpen", { bot: BOT_USERNAME })
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: btUser(cb.from?.id, "restart")
		});
		return;
	}
	tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
		if (!session.amount) {
			await askAmount(chatId);
			return;
		}
		session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
		session.step = "evidence";
		sessions.set(userId, session);
		await askEvidence(chatId);
		return;
	}
	if (cb.data === "apply:keep") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "addAccountFirst")
			});
			return;
		}
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "nextAccount")
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") {
		if (!hasSubmitPass(userId)) {
			botCaptchaWait.set(String(chatId), SUBMIT_CAPTCHA);
			await sendBotCaptcha(chatId, "🤖 Последний шаг: напишите слово с картинки, чтобы отправить жалобу.");
			return;
		}
		await submitSession(chatId, userId, session);
	}
}
function findRelay(id) {
	return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}
function upsertRelay(chat, status) {
	const list = [...bindings.relayChats || []];
	const idx = list.findIndex((c) => sameChat(c.id, chat.id));
	const next = {
		id: String(chat.id),
		title: chat.title || list[idx]?.title,
		type: chat.type || list[idx]?.type,
		status
	};
	if (status === "pending") next.requestedAt = Date.now();
	if (idx >= 0) list[idx] = {
		...list[idx],
		...next
	};
	else list.push(next);
	bindings.relayChats = pruneRelays(list);
	saveBindings();
}
function pruneRelays(list) {
	const LIMIT = 5e3;
	if (list.length <= LIMIT) return list;
	const removable = list.filter((c) => c.status !== "on").sort((a, b) => (a.requestedAt || 0) - (b.requestedAt || 0)).slice(0, list.length - LIMIT);
	const drop = new Set(removable.map((c) => chatIdKey(c.id)));
	return list.filter((c) => !drop.has(chatIdKey(c.id)));
}
function onChatMigrated(oldId, newId) {
	if (!oldId || !newId || sameChat(oldId, newId)) return;
	migratedKeys.set(chatIdKey(oldId), chatIdKey(newId));
	let changed = false;
	const list = bindings.relayChats || [];
	const old = list.find((c) => sameChat(c.id, oldId));
	if (old) {
		const twin = list.find((c) => sameChat(c.id, newId));
		if (twin) {
			if (old.status === "on") twin.status = "on";
			bindings.relayChats = list.filter((c) => c !== old);
		} else {
			old.id = newId;
			old.type = "supergroup";
		}
		changed = true;
	}
	if (bindings.channelId && sameChat(bindings.channelId, oldId)) {
		bindings.channelId = newId;
		changed = true;
	}
	if (changed) {
		saveBindings();
		console.log(`[epb] chat ${oldId} migrated to ${newId}`);
	}
}
function dropRelay(id) {
	bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
	saveBindings();
}
function chatKindLabel(type) {
	if (type === "channel") return "канал";
	if (type === "supergroup") return "супергруппа";
	if (type === "group") return "группа";
	return type || "чат";
}
async function greetRelayChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: [
			`<b>${CHANNEL_NAME}</b>`,
			"",
			"Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает."
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function notifyArbitersAboutRelay(chat, addedBy) {
	const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
	const who = addedBy?.username ? `@${addedBy.username}` : addedBy?.first_name ? `${escapeHtml(addedBy.first_name)} (<code>${addedBy.id}</code>)` : "неизвестно";
	await tgSoft("sendMessage", {
		chat_id: arbiter,
		text: [
			"<b>Бот добавлен в чужой чат</b>",
			"",
			`Название: ${escapeHtml(chat.title || "без названия")}`,
			`Тип: ${chatKindLabel(chat.type)}`,
			`ID: <code>${chat.id}</code>`,
			`Кто добавил: ${who}`,
			"",
			"Подключить рассылку одобренных постов в этот чат?"
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [[{
			text: "Принять",
			callback_data: `rel:y:${chat.id}`
		}, {
			text: "Отклонить",
			callback_data: `rel:n:${chat.id}`
		}]] }
	});
}
async function replaceReplyMarkup(msg, markup, nextText) {
	const text = nextText ?? msg.caption ?? msg.text ?? "";
	const isMedia = Boolean(msg.caption || msg.photo || msg.video);
	if (nextText) {
		if (isMedia) {
			if (await tgSoft("editMessageCaption", {
				chat_id: msg.chat.id,
				message_id: msg.message_id,
				caption: text.slice(0, 1024),
				parse_mode: "HTML",
				reply_markup: markup
			})) return true;
		} else if (await tgSoft("editMessageText", {
			chat_id: msg.chat.id,
			message_id: msg.message_id,
			text,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: markup
		})) return true;
	}
	const markupOnly = await tgSoft("editMessageReplyMarkup", {
		chat_id: msg.chat.id,
		message_id: msg.message_id,
		reply_markup: markup
	});
	return Boolean(markupOnly);
}
function callbackKey(data) {
	const i = data.indexOf(":");
	return i >= 0 ? data.slice(i + 1) : "";
}
async function handleRelayDecision(cb, allow) {
	const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
	if (!raw) return;
	const chatId = raw;
	const relay = findRelay(chatId);
	const title = relay?.title || chatId;
	if (allow) {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "on");
		const wrote = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
			show_alert: !wrote
		});
	} else {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "off");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят."
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Отклонено"
		});
	}
	const next = allow ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.` : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
	if (cb.message) await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: next,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [] }
	});
}
async function bindChat(chat, from, justAdded = true) {
	if (!isGroupOrChannel(chat)) return;
	const id = String(chat.id);
	if (isOfficialArbiterChat(id)) {
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
				"",
				"Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
				"Сменить: /channel -100…"
			].join("\n"),
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialChannel(id)) {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${escapeHtml(chat.title ?? id)}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	const existing = findRelay(id);
	if (existing?.status === "on") {
		if (!justAdded) return;
		await tgSoft("sendMessage", {
			chat_id: chat.id,
			text: "Рассылка уже включена. Одобренные посты будут приходить сюда."
		});
		return;
	}
	if (existing?.status === "pending" && Date.now() - (existing.requestedAt || 0) < 864e5) return;
	if (existing?.status === "off" && !justAdded) return;
	if (tooMany("relay:global", 8, 6e4)) return;
	if (from?.id && tooMany(`relay:${from.id}`, 3, 36e5)) return;
	upsertRelay(chat, "pending");
	await greetRelayChat(chat);
	await notifyArbitersAboutRelay(chat, from);
}
var USERS_PATH = join(DATA_DIR, "telegram-users.json");
var botUsers = readJson(USERS_PATH) || {};
var isUserId = (id) => /^[1-9]\d{0,15}$/.test(String(id ?? ""));
if (!existsSync(USERS_PATH)) {
	const seed = /* @__PURE__ */ new Set([...Object.keys(userLocales), ...Object.values(pendingPosts).map((r) => r.victimId || "")]);
	for (const id of seed) if (isUserId(id)) botUsers[id] = {
		first: Date.now(),
		last: 0
	};
	try {
		writeJsonAtomic(USERS_PATH, botUsers);
	} catch {}
}
var usersTimer = null;
function saveUsers() {
	if (usersTimer) return;
	usersTimer = setTimeout(() => {
		usersTimer = null;
		try {
			writeJsonAtomic(USERS_PATH, botUsers);
		} catch {}
	}, 3e3);
}
function touchUser(id, blocked) {
	if (!isUserId(id)) return;
	const key = String(id);
	const now = Date.now();
	const user = botUsers[key] || {
		first: now,
		last: now
	};
	user.last = now;
	if (blocked !== void 0) user.blocked = blocked;
	else if (user.blocked) user.blocked = false;
	botUsers[key] = user;
	saveUsers();
}
function userStats() {
	const all = Object.values(botUsers);
	const blocked = all.filter((u) => u.blocked).length;
	return {
		total: all.length,
		active: all.length - blocked,
		blocked
	};
}
var DM_JOBS_PATH = join(DATA_DIR, "telegram-dm-broadcasts.json");
var dmDonePath = (id) => join(DATA_DIR, `dm-done-${id.replace(/[^a-z0-9-]/gi, "")}.log`);
var dmJobs = readJson(DM_JOBS_PATH) || [];
var dmDraft = null;
var dmPrompts = /* @__PURE__ */ new Map();
var dmAlbums = /* @__PURE__ */ new Map();
var dmQueue = Promise.resolve();
var dmStarting = /* @__PURE__ */ new Set();
function saveDmJobs() {
	try {
		writeJsonAtomic(DM_JOBS_PATH, dmJobs);
	} catch {}
}
function readDone(id) {
	try {
		return new Set(readFileSync(dmDonePath(id), "utf8").split("\n").filter(Boolean).map((l) => l.replace(/^\?/, "")));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function dmMarkup(draft) {
	return draft.buttons.length ? { inline_keyboard: draft.buttons } : void 0;
}
async function sendDmCopy(chatId, draft) {
	if (draft.srcIds.length > 1) {
		if (!(await tg("copyMessages", {
			chat_id: chatId,
			from_chat_id: draft.srcChat,
			message_ids: draft.srcIds
		}))?.length) throw new Error("сообщение не скопировалось");
		return;
	}
	await tg("copyMessage", {
		chat_id: chatId,
		from_chat_id: draft.srcChat,
		message_id: draft.srcIds[0],
		reply_markup: dmMarkup(draft)
	});
}
function parseDmButtons(text) {
	const rows = [];
	for (const line of text.split("\n").map((l) => l.trim()).filter(Boolean)) {
		const row = [];
		for (const part of line.split("|").map((p) => p.trim()).filter(Boolean)) {
			const m = part.match(/^(.+?)\s+[-–—]\s+(\S+)$/);
			if (!m) return `Не понял строку: «${part}». Формат: Текст - https://ссылка`;
			const url = m[2];
			if (!/^(https?:\/\/|tg:\/\/)\S+$/i.test(url)) return `Ссылка должна начинаться с https:// или tg:// — «${url}»`;
			row.push({
				text: m[1].slice(0, 64),
				url
			});
		}
		if (row.length > 8) return "В одном ряду максимум 8 кнопок";
		if (row.length) rows.push(row);
	}
	if (!rows.length) return "Не нашёл ни одной кнопки";
	if (rows.length > 10) return "Максимум 10 рядов кнопок";
	return rows;
}
function dmScreen() {
	const st = userStats();
	const running = dmJobs.find((j) => !j.stopped);
	const lines = [
		"<b>Пользователи бота</b>",
		`Всего: ${st.total}`,
		`Получат рассылку: ${st.active}`,
		`Заблокировали бота: ${st.blocked}`,
		"",
		"Рассылка уходит только в личные сообщения пользователям бота. В чаты и каналы она не отправляется."
	];
	const keyboard = [];
	if (running) {
		const done = readDone(running.id).size;
		lines.push("", `<b>Идёт рассылка</b>: ${done} из ${running.recipients.length}`);
		keyboard.push([{
			text: "⏹ Остановить рассылку",
			callback_data: `adm:ubstop:${running.id}`
		}]);
		keyboard.push([{
			text: "🔄 Обновить",
			callback_data: "adm:ub"
		}]);
	} else keyboard.push([{
		text: "✉ Новая рассылка",
		callback_data: "adm:ubnew"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function askDmContent(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Новая рассылка пользователям бота</b>",
			"",
			"Ответьте на это сообщение тем, что нужно разослать: текст, фото, видео, GIF, стикер или альбом, с подписью и форматированием.",
			"Премиум-эмодзи сохранятся, если у владельца бота есть Telegram Premium.",
			"",
			"Не удаляйте своё сообщение, пока рассылка не закончится: бот копирует именно его."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Сообщение для рассылки"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "content");
}
async function askDmButtons(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Кнопки под рассылкой</b>",
			"",
			"Ответьте на это сообщение. Каждая строка — ряд кнопок, кнопки в ряду через «|»:",
			"<code>Наш канал - https://t.me/+KkrYz9IKvoBmYTQy</code>",
			"<code>Сайт - https://example.com | Бот - https://t.me/EuropeBlack_bot</code>"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Текст - https://ссылка"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "buttons");
}
async function sendDmPreview(chatId) {
	const draft = dmDraft;
	if (!draft) return;
	const st = userStats();
	let previewOk = true;
	try {
		await sendDmCopy(String(chatId), draft);
	} catch (err) {
		previewOk = false;
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось показать предпросмотр: ${err.message}`
		});
	}
	const album = draft.srcIds.length > 1;
	const keyboard = [];
	if (!album) {
		keyboard.push([{
			text: draft.buttons.length ? "✏ Изменить кнопки" : "➕ Добавить кнопки",
			callback_data: "adm:ubbtn"
		}]);
		if (draft.buttons.length) keyboard.push([{
			text: "🗑 Убрать кнопки",
			callback_data: "adm:ubclr"
		}]);
	}
	if (previewOk) keyboard.push([{
		text: `🚀 Разослать (${st.active})`,
		callback_data: `adm:ubgo:${draft.id}`
	}]);
	keyboard.push([{
		text: "✖ Отменить",
		callback_data: "adm:ubcancel"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Предпросмотр рассылки — выше</b>",
			`Получат: ${st.active} пользователей бота (только личные сообщения, не чаты и не каналы).`,
			album ? "Это альбом: Telegram не позволяет добавить к альбому кнопки." : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: keyboard }
	});
}
async function handleDmReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const kind = dmPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!kind) return false;
	if (kind === "buttons") {
		if (!dmDraft) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Черновик рассылки не найден. Начните заново: /admin"
			});
			return true;
		}
		const parsed = parseDmButtons(msg.text || "");
		if (typeof parsed === "string") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `${parsed}\nОтветьте на сообщение с инструкцией ещё раз.`,
				reply_to_message_id: msg.message_id
			});
			return true;
		}
		dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
		dmDraft.buttons = parsed;
		await sendDmPreview(msg.chat.id);
		return true;
	}
	if (msg.media_group_id) {
		const albumKey = `${msg.chat.id}:${msg.media_group_id}`;
		const album = dmAlbums.get(albumKey);
		if (album) {
			album.ids.push(msg.message_id);
			return true;
		}
		const timer = setTimeout(async () => {
			const done = dmAlbums.get(albumKey);
			dmAlbums.delete(albumKey);
			if (!done) return;
			dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
			dmDraft = {
				id: randomUUID(),
				srcChat: done.chat,
				srcIds: [...done.ids].sort((a, b) => a - b),
				buttons: []
			};
			await sendDmPreview(msg.chat.id);
		}, 1500);
		dmAlbums.set(albumKey, {
			chat: String(msg.chat.id),
			ids: [msg.message_id],
			timer
		});
		return true;
	}
	dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
	dmDraft = {
		id: randomUUID(),
		srcChat: String(msg.chat.id),
		srcIds: [msg.message_id],
		buttons: []
	};
	await sendDmPreview(msg.chat.id);
	return true;
}
function collectDmAlbumItem(msg) {
	if (!msg.media_group_id) return false;
	const album = dmAlbums.get(`${msg.chat.id}:${msg.media_group_id}`);
	if (!album) return false;
	if (!album.ids.includes(msg.message_id)) album.ids.push(msg.message_id);
	return true;
}
async function updateDmStatus(job, final = false) {
	const done = readDone(job.id).size;
	const text = final ? [
		`<b>Рассылка пользователям ${job.stopped ? "остановлена" : "завершена"}</b>`,
		`Доставлено: ${job.sent}`,
		`Заблокировали бота / недоступны: ${job.blocked}`,
		job.failed ? `Ошибки: ${job.failed}` : "",
		`Обработано: ${done} из ${job.recipients.length}`
	].filter(Boolean).join("\n") : `<b>Идёт рассылка пользователям</b>: ${done} из ${job.recipients.length}\nДоставлено ${job.sent}, недоступны ${job.blocked}${job.failed ? `, ошибки ${job.failed}` : ""}`;
	const markup = final ? void 0 : { inline_keyboard: [[{
		text: "⏹ Остановить",
		callback_data: `adm:ubstop:${job.id}`
	}]] };
	if (job.statusMessage) {
		if (await tgSoft("editMessageText", {
			chat_id: job.statusChat,
			message_id: job.statusMessage,
			text,
			parse_mode: "HTML",
			reply_markup: markup
		}) || !final) return;
	}
	const sent = await tgSoft("sendMessage", {
		chat_id: job.statusChat,
		text,
		parse_mode: "HTML",
		reply_markup: markup
	});
	if (sent?.message_id && !final) {
		job.statusMessage = sent.message_id;
		saveDmJobs();
	}
}
async function runDmJob(job) {
	const done = readDone(job.id);
	let lastStatus = 0;
	await updateDmStatus(job);
	for (const chatId of job.recipients) {
		if (job.stopped) break;
		if (!isUserId(chatId) || done.has(chatId)) continue;
		appendFileSync(dmDonePath(job.id), `?${chatId}\n`);
		try {
			await sendDmCopy(chatId, job);
			job.sent += 1;
		} catch (err) {
			const text = String(err?.message || "");
			if (err instanceof TgError && (err.code === 403 || /blocked|deactivated|can't initiate|chat not found|user not found/i.test(text))) {
				job.blocked += 1;
				touchUser(chatId, true);
			} else job.failed += 1;
		}
		done.add(chatId);
		appendFileSync(dmDonePath(job.id), `${chatId}\n`);
		if (Date.now() - lastStatus > 4e3) {
			lastStatus = Date.now();
			saveDmJobs();
			await updateDmStatus(job);
		}
		await sleep(Math.max(45, 45 * job.srcIds.length));
	}
	await updateDmStatus(job, true);
	dmJobs = dmJobs.filter((j) => j.id !== job.id);
	saveDmJobs();
	try {
		unlinkSync(dmDonePath(job.id));
	} catch {}
}
function enqueueDmJob(job) {
	dmQueue = dmQueue.then(() => runDmJob(job)).catch((err) => console.error("[epb] user broadcast", err));
}
function resumeDmJobs() {
	for (const job of dmJobs) {
		if (Date.now() - job.startedAt > 864e5) continue;
		console.log(`[epb] resuming user broadcast ${job.id}: ${readDone(job.id).size} done`);
		enqueueDmJob(job);
	}
}
async function handleDmCallback(cb, action, arg) {
	const chatId = cb.message.chat.id;
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "ub") {
		await answer();
		await renderAdmin(cb, dmScreen());
		return true;
	}
	if (action === "ubnew") {
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Сначала дождитесь окончания текущей рассылки", true);
			return true;
		}
		await answer("Ответьте на сообщение бота тем, что нужно разослать");
		await askDmContent(chatId);
		return true;
	}
	if (action === "ubbtn") {
		await answer();
		if (!dmDraft) await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Черновик не найден. Начните заново: /admin"
		});
		else await askDmButtons(chatId);
		return true;
	}
	if (action === "ubclr") {
		if (dmDraft) dmDraft.buttons = [];
		await answer("Кнопки убраны");
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubcancel") {
		dmDraft = null;
		await answer("Рассылка отменена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: "Рассылка отменена."
		});
		return true;
	}
	if (action === "ubgo") {
		if (!dmDraft || dmDraft.id !== arg) {
			await answer("Этот черновик уже неактуален", true);
			return true;
		}
		await answer();
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Разослать это сообщение ${userStats().active} пользователям бота? Отменить уже отправленное будет нельзя.`,
			reply_markup: { inline_keyboard: [[{
				text: "✅ Да, разослать",
				callback_data: `adm:ubyes:${dmDraft.id}`
			}], [{
				text: "⬅ Назад",
				callback_data: "adm:ubback"
			}]] }
		});
		return true;
	}
	if (action === "ubback") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubyes") {
		if (!dmDraft || dmDraft.id !== arg || dmStarting.has(arg) || dmJobs.some((j) => j.id === arg)) {
			await answer("Эта рассылка уже запущена или отменена", true);
			return true;
		}
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Уже идёт другая рассылка", true);
			return true;
		}
		dmStarting.add(arg);
		const recipients = Object.entries(botUsers).filter(([id, u]) => isUserId(id) && !u.blocked).map(([id]) => id);
		const job = {
			...dmDraft,
			recipients,
			sent: 0,
			blocked: 0,
			failed: 0,
			startedAt: Date.now(),
			statusChat: String(chatId)
		};
		dmJobs.push(job);
		saveDmJobs();
		dmDraft = null;
		await answer("Рассылка запущена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Рассылка запущена: ${recipients.length} получателей.`
		});
		enqueueDmJob(job);
		return true;
	}
	if (action === "ubstop") {
		const job = dmJobs.find((j) => j.id === arg);
		if (job) {
			job.stopped = true;
			saveDmJobs();
		}
		await answer(job ? "Останавливаем…" : "Рассылка уже закончилась");
		return true;
	}
	return false;
}
var ADMIN_PAGE = 8;
var RELAY_FILTERS = [
	{
		key: "a",
		label: "Все",
		match: () => true
	},
	{
		key: "on",
		label: "✅ Вкл",
		match: (c) => c.status === "on"
	},
	{
		key: "pd",
		label: "⏳ Ждут",
		match: (c) => c.status === "pending"
	},
	{
		key: "off",
		label: "⛔ Выкл",
		match: (c) => c.status === "off"
	}
];
var statusIcon = (status) => status === "on" ? "✅" : status === "pending" ? "⏳" : "⛔";
var statusText = (status) => status === "on" ? "рассылка включена" : status === "pending" ? "ждёт решения" : "рассылка выключена";
function ago(ts) {
	if (!ts) return "давно";
	const min = Math.round((Date.now() - ts) / 6e4);
	if (min < 60) return `${Math.max(1, min)} мин назад`;
	const h = Math.round(min / 60);
	if (h < 48) return `${h} ч назад`;
	return `${Math.round(h / 24)} дн назад`;
}
function cut(text, max) {
	return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function pendingComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => (rec.status || "pending") === "pending").sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function publishedComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => rec.status === "published" && rec.channelPosted && !rec.deletedEverywhere).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function adminDeleteList(page) {
	const list = publishedComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => {
		const chats = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
		return [{
			text: `${cut(scamLabel(rec), 22)} · ${chats} чат. · ${ago(rec.createdAt)}`,
			callback_data: `adm:dlc:${key}`
		}];
	});
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:dl:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:dl:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:dl:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Удалить блеклист</b>: опубликовано ${list.length}\nВыберите запись — бот спросит подтверждение и удалит пост из канала и из всех чатов рассылки.` : "<b>Удалить блеклист</b>: опубликованных записей нет.",
		keyboard
	};
}
async function adminDeleteConfirm(key) {
	const rec = pendingPosts[key];
	const back = {
		text: "⬅ К списку",
		callback_data: "adm:dl:0"
	};
	if (!rec || rec.status !== "published") return {
		text: "Эта запись уже не опубликована.",
		keyboard: [[back]]
	};
	const chatCount = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
	const channelCount = rec.channelMsgIds?.length || 0;
	return {
		text: [
			"<b>Удалить блеклист везде?</b>",
			`Аккаунт: ${escapeHtml(scamLabel(rec))}`,
			`Ущерб: ${escapeHtml(rec.amount || "—")} ${escapeHtml(rec.currency || "")}`,
			"",
			`Будет удалено: пост в канале (${channelCount} сообщ.) и сообщения в ${chatCount} чатах рассылки.`,
			"Отменить удаление нельзя. Сообщения старше 48 часов Telegram может не дать удалить в некоторых чатах."
		].join("\n"),
		keyboard: [[{
			text: "🗑 Да, удалить везде",
			callback_data: `adm:dlgo:${key}`
		}], [back]]
	};
}
function adminHome() {
	const relays = bindings.relayChats || [];
	const all = Object.values(pendingPosts);
	const count = (st) => all.filter((r) => (r.status || "pending") === st).length;
	const last = bindings.lastBroadcast;
	return {
		text: [
			`<b>${CHANNEL_NAME} — панель</b>`,
			"",
			`<b>Заявки</b>: ждут решения ${count("pending")}, опубликовано ${count("published")}, отклонено ${count("rejected")}`,
			`<b>Чаты рассылки</b>: включено ${relays.filter((c) => c.status === "on").length}, ждут ${relays.filter((c) => c.status === "pending").length}, выключено ${relays.filter((c) => c.status === "off").length}`,
			`<b>Пользователи бота</b>: ${userStats().total} (заблокировали ${userStats().blocked})`,
			`<b>Канал</b>: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			last ? `<b>Последняя рассылка</b>: ${ago(last.at)}, доставлено ${last.sent} из ${last.total}` + (last.noRights ? `, без прав ${last.noRights}` : "") + (last.gone ? `, недоступно ${last.gone}` : "") : "<b>Последняя рассылка</b>: ещё не было"
		].join("\n"),
		keyboard: [
			[{
				text: `📝 Заявки без решения (${count("pending")})`,
				callback_data: "adm:ap:0"
			}],
			[{
				text: `🗑 Удалить блеклист (${count("published")})`,
				callback_data: "adm:dl:0"
			}],
			[{
				text: "📋 Чаты рассылки",
				callback_data: "adm:rl:a:0"
			}, {
				text: "⏳ Ждут решения",
				callback_data: "adm:rl:pd:0"
			}],
			[{
				text: "📢 Канал для постов",
				callback_data: "adm:ch"
			}],
			[{
				text: "📣 Рассылка пользователям бота",
				callback_data: "adm:ub"
			}],
			[{
				text: `🖼 Баннеры (${(bindings.banners || []).length})`,
				callback_data: "adm:bn"
			}],
			[{
				text: "🚫 Забанить",
				callback_data: "adm:ban"
			}, {
				text: `⛔️ Баны (${(bindings.bannedUsers || []).length})`,
				callback_data: "adm:bans:0"
			}],
			[{
				text: `🧹 Недавние проверки (${(bindings.recentFinds || []).length})`,
				callback_data: "adm:rf:0"
			}],
			...checkEnabled() ? [
				[{
					text: "➕ Добавить юзера в блеклист",
					callback_data: "adm:bladd"
				}],
				[{
					text: "🧹 Убрать юзера из блеклиста",
					callback_data: "adm:ccrm"
				}],
				[{
					text: "🔎 Каналы для проверки",
					callback_data: "adm:cc"
				}]
			] : [],
			[{
				text: "🔄 Обновить",
				callback_data: "adm:home"
			}, {
				text: "✖ Закрыть",
				callback_data: "adm:x"
			}]
		]
	};
}
function adminRelayList(filter, page) {
	const f = RELAY_FILTERS.find((x) => x.key === filter) || RELAY_FILTERS[0];
	const list = (bindings.relayChats || []).filter(f.match);
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const slice = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE);
	const keyboard = [RELAY_FILTERS.map((x) => ({
		text: x.key === f.key ? `• ${x.label}` : x.label,
		callback_data: `adm:rl:${x.key}:0`
	})), ...slice.map((c) => [{
		text: `${statusIcon(c.status)} ${cut(c.title || c.id, 40)}`,
		callback_data: `adm:rc:${c.id}:${f.key}:${p}`
	}])];
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:rl:${f.key}:${p - 1}`
	});
	nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:rl:${f.key}:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:rl:${f.key}:${p + 1}`
	});
	keyboard.push(nav, [{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: [`<b>Чаты рассылки</b> — ${f.label}: ${list.length}`, list.length ? "Нажмите на чат, чтобы открыть карточку." : "Здесь пока пусто."].join("\n"),
		keyboard
	};
}
async function adminRelayCard(chatId, filter, page, note = "") {
	const relay = findRelay(chatId);
	const back = {
		text: "⬅ К списку",
		callback_data: `adm:rl:${filter}:${page}`
	};
	if (!relay) return {
		text: "Этого чата уже нет в списке.",
		keyboard: [[back]]
	};
	const suffix = `${relay.id}:${filter}:${page}`;
	const toggle = relay.status === "on" ? {
		text: "⛔ Выключить рассылку",
		callback_data: `adm:roff:${suffix}`
	} : {
		text: "✅ Включить рассылку",
		callback_data: `adm:ron:${suffix}`
	};
	return {
		text: [
			`<b>${escapeHtml(relay.title || "без названия")}</b>`,
			`ID: <code>${escapeHtml(relay.id)}</code>`,
			`Тип: ${chatKindLabel(relay.type)}`,
			`Статус: ${statusIcon(relay.status)} ${statusText(relay.status)}`,
			`Ссылка спонсора: ${relay.link ? `<code>${escapeHtml(relay.link)}</code>` : "не задана"}`,
			relay.requestedAt ? `Запрос: ${ago(relay.requestedAt)}` : "",
			note ? `\n${note}` : ""
		].filter(Boolean).join("\n"),
		keyboard: [
			[toggle],
			[{
				text: relay.link ? "🔗 Изменить ссылку спонсора" : "🔗 Задать ссылку спонсора",
				callback_data: `adm:rlink:${suffix}`
			}],
			[{
				text: "🔍 Проверить права бота",
				callback_data: `adm:rchk:${suffix}`
			}],
			[back]
		]
	};
}
async function botRightsNote(chatId) {
	const member = await tgSoft("getChatMember", {
		chat_id: chatId,
		user_id: Number(botToken().split(":")[0])
	});
	if (!member) return "❌ Бот не видит этот чат: его удалили или чат закрыт.";
	if (member.status === "left" || member.status === "kicked") return "❌ Бота в этом чате нет.";
	if ((await tgSoft("getChat", { chat_id: chatId }))?.type === "channel") return member.status === "administrator" && member.can_post_messages !== false ? "✅ Бот админ канала и может публиковать." : "⚠️ Бот не может публиковать в канале: нужен админ с правом публикации.";
	if (member.status === "restricted" && (member.can_send_messages === false || member.can_send_photos === false)) return "⚠️ Боту запрещено отправлять сообщения или медиа в этом чате.";
	return member.status === "administrator" || member.status === "creator" ? "✅ Бот админ, рассылка будет доходить." : "✅ Бот участник чата и может писать. Лучше выдать админа, чтобы медиа точно доходили.";
}
function adminPendingList(page) {
	const list = pendingComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => [{
		text: `${key} · ${cut(scamLabel(rec), 24)} · ${rec.amount} ${rec.currency} · ${ago(rec.createdAt)}`,
		callback_data: `adm:as:${key}`
	}]);
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:ap:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:ap:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:ap:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Заявки без решения</b>: ${list.length}\nНажмите на заявку — бот пришлёт её ещё раз с кнопками.` : "<b>Заявки без решения</b>: нет, все разобраны.",
		keyboard
	};
}
async function adminShowComplaint(arbiterChatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return false;
	const accounts = pendingAccounts(rec).map((a) => formatAccountLine(a.username, a.id, true)).join("\n");
	const parts = splitHtml([
		`<b>Заявка ${escapeHtml(key)}</b> (повтор из панели, ${ago(rec.createdAt)})`,
		"",
		`<b>Аккаунт</b>\n${accounts}`,
		`<b>Ущерб</b>\n${escapeHtml(rec.amount)} ${escapeHtml(rec.currency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(rec.summary || rec.story)}`,
		rec.files?.length ? `\nДоказательств: ${rec.files.length} (в исходной заявке, они уйдут в пост)` : ""
	].join("\n"));
	for (const [i, part] of parts.entries()) {
		const payload = {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: i === parts.length - 1 ? reviewKeyboard(key) : void 0
		};
		if (i === 0 && rec.reviewMessageId && rec.reviewChatId && sameChat(rec.reviewChatId, arbiterChatId)) payload.reply_parameters = {
			message_id: rec.reviewMessageId,
			allow_sending_without_reply: true
		};
		await tgSoft("sendMessage", payload);
	}
	return true;
}
function adminCheck() {
	const list = checkChannels();
	const ub = hasUserbot();
	const lines = [
		"<b>Каналы для проверки контрагента</b>",
		`Подключено: ${list.length}`,
		`Аккаунт (юзербот): ${ub ? "подключён ✅" : "не подключён"}`,
		"",
		ub ? "Поиск идёт через подключённый аккаунт по всем постам этих каналов, включая старые. Бота в каналы добавлять не нужно — аккаунт должен быть на них подписан." : "Сейчас бот индексирует только новые посты каналов, где он сам состоит. Чтобы искать по старым постам чужих каналов без добавления бота, подключите аккаунт (юзербот) — см. HOSTING.md."
	];
	const keyboard = list.map((c) => [{
		text: `🗑 ${cut(c.title || c.username || c.id, 36)}`,
		callback_data: `adm:ccdel:${c.id}`
	}]);
	keyboard.push([{
		text: "🔌 Проверить аккаунт",
		callback_data: "adm:ccping"
	}]);
	keyboard.push([{
		text: "🧹 Убрать жалобу из блеклиста",
		callback_data: "adm:ccrm"
	}]);
	keyboard.push([{
		text: "➕ Добавить канал",
		callback_data: "adm:ccadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
function adminBanners() {
	const list = bindings.banners || [];
	const lines = [
		"<b>Баннеры в мини-аппе</b>",
		`Сейчас: ${list.length} из ${MAX_BANNERS}`,
		"",
		list.length ? "Баннеры показываются сверху в приложении. Видео и GIF идут без звука и по кругу. Тап по баннеру открывает ссылку." : "Пока нет ни одного баннера. Нажмите «Добавить баннер», пришлите картинку / видео / GIF, затем ссылку."
	];
	const keyboard = list.map((b, i) => [{
		text: `🗑 ${i + 1}. ${b.type === "video" ? "🎞" : "🖼"} ${cut(b.link || "без ссылки", 34)}`,
		callback_data: `adm:bndel:${b.id}`
	}]);
	if (list.length < MAX_BANNERS) keyboard.push([{
		text: "➕ Добавить баннер",
		callback_data: "adm:bnadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function handleBannerInput(msg) {
	const key = String(msg.chat.id);
	const st = bannerSetup.get(key);
	if (!st) return false;
	if (st.phase === "media") {
		const media = extractBannerMedia(msg);
		if (!media) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Пришлите картинку, видео или GIF одним сообщением (не текстом). Или /admin, чтобы выйти."
			});
			return true;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Загружаю медиа…"
		});
		const bytes = await downloadTelegramFile(media.fileId);
		if (!bytes) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Не удалось загрузить файл. Для баннера подойдёт картинка / видео / GIF до 20 МБ. Пришлите ещё раз."
			});
			return true;
		}
		const id = newBannerId();
		saveBannerFile(id, bytes);
		st.draft = {
			type: media.type,
			file: id,
			mime: media.mime,
			width: media.width,
			height: media.height
		};
		st.phase = "link";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа сохранено. Теперь пришлите ссылку (https://… или t.me/…), которая откроется по тапу на баннер.\nЕсли ссылка не нужна — отправьте «-»."
		});
		return true;
	}
	if (!msg.text) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пришлите ссылку текстом (https://…) или «-», чтобы без ссылки."
		});
		return true;
	}
	const link = normalizeBannerLink(msg.text);
	if (link === null) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Это не похоже на ссылку. Пришлите адрес вида https://… или t.me/…, либо «-» без ссылки."
		});
		return true;
	}
	const draft = st.draft;
	bannerSetup.delete(key);
	if (!draft) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа не найдено, начните заново: /admin → Баннеры."
		});
		return true;
	}
	const banner = {
		id: draft.file,
		type: draft.type,
		file: draft.file,
		mime: draft.mime,
		link,
		width: draft.width,
		height: draft.height,
		createdAt: Date.now()
	};
	bindings.banners = [...bindings.banners || [], banner].slice(-20);
	saveBindings();
	const view = adminBanners();
	await tgSoft("sendMessage", {
		chat_id: msg.chat.id,
		text: `Баннер добавлен${link ? "" : " (без ссылки)"}.\n\n${view.text}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
	return true;
}
async function applySponsorLink(arbiterChatId, raw) {
	const st = sponsorLinkSetup.get(String(arbiterChatId));
	sponsorLinkSetup.delete(String(arbiterChatId));
	if (!st) return;
	const res = setSponsorLink(st.relayId, raw);
	if (res === "bad") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не похоже на ссылку. Пришлите https://… или t.me/…, либо «-», чтобы убрать."
		});
		return;
	}
	const view = await adminRelayCard(st.relayId, st.filter, st.page, res === "set" ? "Ссылка спонсора сохранена." : "Ссылка спонсора убрана.");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function applyRemoveFromCheck(arbiterChatId, raw) {
	removeFromCheckSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	let removed = 0;
	const epbId = text.match(/\b(EPB-[A-Za-z0-9]+)\b/i)?.[1];
	if (epbId) {
		const rec = pendingPosts[epbId] || pendingPosts[epbId.toUpperCase()];
		if (rec && !rec.removedFromCheck) {
			rec.removedFromCheck = true;
			removed = 1;
		}
	} else {
		const parsed = parseTelegramInput(text);
		const uname = parsed.username.replace(/^@/, "").toLowerCase();
		const id = parsed.id;
		if (!uname && !id) {
			await tgSoft("sendMessage", {
				chat_id: arbiterChatId,
				text: "Не понял. Пришлите EPB-… или @username / ID."
			});
			return;
		}
		for (const rec of Object.values(pendingPosts)) {
			if (rec.removedFromCheck) continue;
			const accounts = pendingAccounts(rec);
			if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) {
				rec.removedFromCheck = true;
				removed += 1;
			}
		}
		const manual = bindings.manualBlacklist || [];
		const keptManual = manual.filter((e) => {
			const eu = (e.username || "").replace(/^@/, "").toLowerCase();
			return !(uname && eu === uname || id && e.telegramId === id);
		});
		if (keptManual.length !== manual.length) {
			removed += manual.length - keptManual.length;
			bindings.manualBlacklist = keptManual;
			saveBindings();
		}
	}
	if (removed) savePending();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: removed ? `Убрано из блеклиста: ${removed}. В проверке контрагента больше не показывается.` : "Ничего подходящего не нашёл."
	});
}
async function applyAddToBlacklist(arbiterChatId, raw) {
	addBlacklistSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	const firstTok = text.split(/\s+/)[0] || "";
	const note = text.slice(firstTok.length).trim();
	const parsed = parseTelegramInput(firstTok);
	const username = parsed.username.replace(/^@/, "");
	const id = parsed.id;
	if (!username && !id) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не понял. Пришлите @username или ID, можно с комментарием через пробел."
		});
		return;
	}
	const entry = {
		id: randomUUID(),
		username: username || void 0,
		telegramId: id || void 0,
		source: DEFAULT_MANUAL_SOURCE,
		note: note || void 0,
		addedAt: Date.now()
	};
	bindings.manualBlacklist = [...bindings.manualBlacklist || [], entry].slice(-5e3);
	saveBindings();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Добавлено в блеклист (проверка контрагента).",
			`Аккаунт: ${escapeHtml(username ? `@${username}` : `ID ${id}`)}`,
			`Источник: ${escapeHtml(DEFAULT_MANUAL_SOURCE)}`,
			note ? `Комментарий: ${escapeHtml(note)}` : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML"
	});
}
async function applyCheckChannel(arbiterChatId, raw) {
	checkChannelSetup.delete(String(arbiterChatId));
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала (-100…) или @username."
		});
		return;
	}
	let entry = null;
	const chat = await chatReachable(ref);
	if (chat && (chat.type === "channel" || chat.type === "supergroup")) entry = {
		id: String(chat.id),
		title: chat.title,
		username: chat.username,
		addedAt: Date.now()
	};
	else if (hasUserbot()) entry = await resolveChannelAsUser(String(ref));
	if (!entry) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: hasUserbot() ? "Не удалось открыть этот канал. Подключённый аккаунт должен быть подписан на него. Пришлите @username или ID ещё раз." : "Не вижу этот канал. Добавьте бота в канал (участником или админом) и пришлите ID ещё раз — или подключите аккаунт (юзербот), тогда бота добавлять не нужно."
		});
		return;
	}
	if (isOfficialChannel(entry.id) || isOfficialArbiterChat(entry.id)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный канал бота, добавлять его не нужно."
		});
		return;
	}
	const list = [...checkChannels()];
	if (!list.some((c) => sameChat(c.id, entry.id))) {
		list.push(entry);
		bindings.checkChannels = list.slice(-100);
		saveBindings();
	}
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал подключён для проверки.",
			escapeHtml(entry.title || entry.id),
			`ID: <code>${escapeHtml(entry.id)}</code>`,
			"",
			hasUserbot() ? "Поиск по этому каналу идёт через подключённый аккаунт, включая старые посты." : "Новые посты этого канала будут попадать в поиск. Для старых постов подключите аккаунт (юзербот)."
		].join("\n"),
		parse_mode: "HTML"
	});
}
function adminChannel() {
	return {
		text: [
			"<b>Канал для постов</b>",
			`Сейчас: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			"",
			"Чтобы сменить: нажмите кнопку и пришлите ID канала (-100…) или @username следующим сообщением. Бот должен быть админом канала."
		].join("\n"),
		keyboard: [[{
			text: "✏ Сменить канал",
			callback_data: "adm:chset"
		}], [{
			text: "⬅ В меню",
			callback_data: "adm:home"
		}]]
	};
}
async function sendAdminPanel(chatId) {
	const view = adminHome();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
var banSetup = /* @__PURE__ */ new Set();
function banLabel(b) {
	return [b.username ? `@${b.username}` : "", b.id ? `ID ${b.id}` : ""].filter(Boolean).join(" · ") || "—";
}
function adminBans(page) {
	const list = bindings.bannedUsers || [];
	const per = 8;
	const rows = list.slice(page * per, page * per + per).map((b) => [{
		text: `✅ Разбанить ${banLabel(b)}`.slice(0, 60),
		callback_data: `adm:unban:${b.id ? `i:${b.id}` : `u:${b.username}`}`
	}]);
	const nav = [];
	if (page > 0) nav.push({
		text: "⬅",
		callback_data: `adm:bans:${page - 1}`
	});
	if ((page + 1) * per < list.length) nav.push({
		text: "➡",
		callback_data: `adm:bans:${page + 1}`
	});
	if (nav.length) rows.push(nav);
	rows.push([{
		text: "🚫 Забанить ещё",
		callback_data: "adm:ban"
	}], [{
		text: "⬅ Назад",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Забаненные (${list.length})</b>\nНажмите, чтобы снять бан.` : "<b>Забаненных нет.</b>",
		keyboard: rows
	};
}
function adminRecentFinds(page) {
	const list = bindings.recentFinds || [];
	const per = 8;
	const rows = list.slice(page * per, page * per + per).map((f) => [{
		text: `🗑 ${f.label} — ${(f.sources || []).join(", ")}`.slice(0, 60),
		callback_data: `adm:rfdel:${f.id}:${page}`
	}]);
	const nav = [];
	if (page > 0) nav.push({
		text: "⬅",
		callback_data: `adm:rf:${page - 1}`
	});
	if ((page + 1) * per < list.length) nav.push({
		text: "➡",
		callback_data: `adm:rf:${page + 1}`
	});
	if (nav.length) rows.push(nav);
	rows.push([{
		text: "⬅ Назад",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Недавние проверки (${list.length})</b>\nПубличный список в приложении. Нажмите на ошибочную запись, чтобы удалить её.` : "<b>Недавних проверок нет.</b>",
		keyboard: rows
	};
}
async function applyBan(chatId, raw) {
	banSetup.delete(String(chatId));
	const parsed = parseTelegramInput(raw.trim().split(/\s+/)[0] || "");
	const username = parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	if (!username && !id) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Не понял. Пришлите @username или ID."
		});
		return;
	}
	if (id && isOwner(id)) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Владельца забанить нельзя."
		});
		return;
	}
	const list = (bindings.bannedUsers || []).filter((b) => !(id && b.id === id || username && (b.username || "").toLowerCase() === username));
	const entry = {
		id: id || void 0,
		username: username || void 0,
		at: Date.now()
	};
	bindings.bannedUsers = [entry, ...list];
	saveBindings();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `🚫 Забанен: ${banLabel(entry)}\nБот и мини-приложение для него закрыты. Снять бан: /admin → ⛔️ Баны.`
	});
}
async function renderAdmin(cb, view) {
	if (!cb.message) return;
	return await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function handleAdminCallback(cb) {
	const chatId = cb.message.chat.id;
	const [, action = "home", ...rest] = (cb.data || "").split(":");
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "x") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		return;
	}
	if (action === "home") {
		await answer();
		await renderAdmin(cb, adminHome());
		return;
	}
	if (action.startsWith("ub") && await handleDmCallback(cb, action, rest[0] || "")) return;
	if (action === "rl") {
		await answer();
		await renderAdmin(cb, adminRelayList(rest[0] || "a", Number(rest[1] || 0)));
		return;
	}
	const [target = "", filter = "a", page = "0"] = rest;
	if (action === "rc") {
		await answer();
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "ron" || action === "roff") {
		const relay = findRelay(target);
		if (!relay) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		upsertRelay({
			id: relay.id,
			title: relay.title,
			type: relay.type
		}, action === "ron" ? "on" : "off");
		if (action === "ron") await tgSoft("sendMessage", {
			chat_id: relay.id,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await answer(action === "ron" ? "Рассылка включена" : "Рассылка выключена");
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "rchk") {
		await answer("Проверяем…");
		await renderAdmin(cb, await adminRelayCard(target, filter, page, await botRightsNote(target)));
		return;
	}
	if (action === "rlink") {
		if (!findRelay(target)) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		sponsorLinkSetup.set(String(chatId), {
			relayId: target,
			filter,
			page
		});
		await answer("Пришлите ссылку");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ссылку на чат (https://… или t.me/…), которая будет прикреплена к названию на странице «Спонсоры проекта». Чтобы убрать ссылку — отправьте «-»."
		});
		return;
	}
	if (action === "ap") {
		await answer();
		await renderAdmin(cb, adminPendingList(Number(rest[0] || 0)));
		return;
	}
	if (action === "as") {
		const key = rest[0] || "";
		const shown = (pendingPosts[key]?.status || "pending") === "pending" && await adminShowComplaint(chatId, key);
		await answer(shown ? "Заявка отправлена ниже" : "Заявка уже обработана", !shown);
		if (!shown) await renderAdmin(cb, adminPendingList(0));
		return;
	}
	if (action === "cc") {
		await answer();
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "ccping") {
		await answer("Проверяем аккаунт…");
		const st = await userbotStatus();
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: st.ok ? `Аккаунт подключён: ${escapeHtml(st.name || "аккаунт")}` : `Аккаунт не подключён: ${escapeHtml(st.error || "ошибка")}`
		});
		return;
	}
	if (action === "ccrm") {
		removeFromCheckSetup.add(String(chatId));
		await answer("Пришлите номер жалобы или аккаунт");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите номер жалобы (EPB-…) либо @username / ID аккаунта, который нужно убрать из блеклиста (поиска). Жалоба останется в истории, но перестанет находиться в проверке контрагента."
		});
		return;
	}
	if (action === "ban") {
		banSetup.add(String(chatId));
		await answer("Пришлите @username или ID");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите @username или ID пользователя, которого нужно забанить. Ему закроется доступ к боту и мини-приложению."
		});
		return;
	}
	if (action === "bans") {
		await answer();
		await renderAdmin(cb, adminBans(Number(rest[0] || 0)));
		return;
	}
	if (action === "unban") {
		const [kind, ...v] = rest;
		const val = v.join(":").toLowerCase();
		bindings.bannedUsers = (bindings.bannedUsers || []).filter((b) => kind === "i" ? b.id !== val : (b.username || "").toLowerCase() !== val);
		saveBindings();
		await answer("Бан снят");
		await renderAdmin(cb, adminBans(0));
		return;
	}
	if (action === "rf") {
		await answer();
		await renderAdmin(cb, adminRecentFinds(Number(rest[0] || 0)));
		return;
	}
	if (action === "rfdel") {
		const before = (bindings.recentFinds || []).length;
		bindings.recentFinds = (bindings.recentFinds || []).filter((f) => f.id !== rest[0]);
		if (bindings.recentFinds.length !== before) saveBindings();
		await answer("Удалено из недавних");
		await renderAdmin(cb, adminRecentFinds(Number(rest[1] || 0)));
		return;
	}
	if (action === "bladd") {
		addBlacklistSetup.add(String(chatId));
		await answer("Пришлите @username или ID");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите @username или ID аккаунта, которого нужно добавить в блеклист (проверку контрагента). Можно с комментарием через пробел, например:\n@scammer кинул на сделке, инфа из чужого блеклиста\n\nИсточник отметится как «Сторонний источник»."
		});
		return;
	}
	if (action === "ccadd") {
		checkChannelSetup.add(String(chatId));
		await answer("Пришлите ID канала следующим сообщением");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ID канала (-100…) или @username для проверки. Бот должен быть в этом канале."
		});
		return;
	}
	if (action === "ccdel") {
		const target = rest.join(":");
		bindings.checkChannels = checkChannels().filter((c) => !sameChat(c.id, target));
		saveBindings();
		removeCheckChannelFromIndex(target);
		await answer("Канал убран");
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "dl") {
		await answer();
		await renderAdmin(cb, adminDeleteList(Number(rest[0] || 0)));
		return;
	}
	if (action === "dlc") {
		await answer();
		await renderAdmin(cb, await adminDeleteConfirm(rest.join(":")));
		return;
	}
	if (action === "dlgo") {
		const delKey = rest.join(":");
		if (!pendingPosts[delKey] || pendingPosts[delKey].status !== "published") {
			await answer("Запись уже удалена", true);
			await renderAdmin(cb, adminDeleteList(0));
			return;
		}
		await answer("Удаляю во всех чатах…");
		const res = await deletePublishedEverywhere(delKey);
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: [
				"Блеклист удалён.",
				`Канал: удалено ${res.channel.ok}${res.channel.fail ? `, не удалось ${res.channel.fail}` : ""}.`,
				`Чаты рассылки (${res.chatCount}): удалено ${res.chats.ok}${res.chats.fail ? `, не удалось ${res.chats.fail}` : ""}.`,
				res.channel.fail || res.chats.fail ? "Часть сообщений не удалилась — вероятно, они старше 48 часов или у бота нет прав на удаление в чате." : ""
			].filter(Boolean).join("\n")
		});
		await renderAdmin(cb, adminDeleteList(0));
		return;
	}
	if (action === "bn") {
		bannerSetup.delete(String(chatId));
		await answer();
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "bnadd") {
		if ((bindings.banners || []).length >= MAX_BANNERS) {
			await answer("Достигнут лимит баннеров", true);
			await renderAdmin(cb, adminBanners());
			return;
		}
		bannerSetup.set(String(chatId), { phase: "media" });
		await answer("Пришлите медиа для баннера");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите картинку, видео или GIF для баннера (до 20 МБ). Следующим сообщением попрошу ссылку."
		});
		return;
	}
	if (action === "bndel") {
		removeBannerById(rest.join(":"));
		await answer("Баннер удалён");
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "ch") {
		await answer();
		await renderAdmin(cb, adminChannel());
		return;
	}
	if (action === "chset") {
		await answer("Пришлите ID канала следующим сообщением");
		await askPublishChannel(chatId);
		return;
	}
	await answer();
}
function relayListHtml() {
	const list = bindings.relayChats || [];
	const by = (status) => list.filter((c) => c.status === status);
	const line = (c) => `• ${escapeHtml(c.title || "без названия")} — <code>${escapeHtml(c.id)}</code>`;
	const lines = [
		`<b>Чаты рассылки</b>: включено ${by("on").length}, ждут решения ${by("pending").length}, выключено ${by("off").length}`,
		"",
		"<b>Включены</b>",
		...by("on").length ? by("on").map(line) : ["—"]
	];
	if (by("pending").length) lines.push("", "<b>Ждут решения</b>", ...by("pending").map(line));
	lines.push("", "Включить вручную: /relay_on -100…", "Выключить: /relay_off -100…");
	return splitHtml(lines.join("\n"));
}
async function handleRelayCommand(arbiterChatId, cmd, arg) {
	if (cmd === "relays") {
		for (const part of relayListHtml()) await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true
		});
		return;
	}
	const raw = arg.trim().split(/\s+/)[0] || "";
	if (!/^-\d{5,20}$/.test(raw)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: `Укажите ID чата: /${cmd} -100…\nСписок: /relays`
		});
		return;
	}
	const chat = await tgSoft("getChat", { chat_id: raw });
	if (cmd === "relay_on" && !chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Бот не видит этот чат. Сначала добавьте бота в чат, потом повторите команду."
		});
		return;
	}
	if (chat && (isOfficialArbiterChat(chat.id) || isOfficialChannel(chat.id))) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный чат, рассылка туда не нужна."
		});
		return;
	}
	const target = chat ? {
		id: chat.id,
		type: chat.type,
		title: chat.title
	} : { id: raw };
	upsertRelay(target, cmd === "relay_on" ? "on" : "off");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: `${cmd === "relay_on" ? "Рассылка включена" : "Рассылка выключена"}: ${escapeHtml(chat?.title || raw)}\nID: <code>${escapeHtml(String(target.id))}</code>`,
		parse_mode: "HTML"
	});
}
async function parseChannelRef(raw) {
	const t = raw.trim().split(/\s+/)[0] || "";
	if (!t) return null;
	if (t.startsWith("@")) return t;
	const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
	if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
	const num = t.replace(/[^\d-]/g, "");
	if (/^-100\d{6,}$/.test(num)) return num;
	if (/^100\d{6,}$/.test(num)) return `-${num}`;
	if (/^\d{6,}$/.test(num)) return `-100${num}`;
	return t;
}
async function applyPublishChannel(arbiterChatId, raw) {
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
			parse_mode: "HTML"
		});
		return;
	}
	const chat = await chatReachable(ref);
	if (!chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз."
		});
		return;
	}
	if (chat.type !== "channel" && chat.type !== "supergroup") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не канал. Нужен ID канала, куда постить одобренные заявки."
		});
		return;
	}
	bindings.channelId = String(chat.id);
	saveBindings();
	channelSetup.delete(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал для постов обновлён.",
			escapeHtml(chat.title || "Канал"),
			`ID: <code>${chat.id}</code>`
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function askPublishChannel(arbiterChatId) {
	channelSetup.add(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			`Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
			"",
			"Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
			"Бот должен быть админом этого канала.",
			"",
			"Или сразу: /channel -100…"
		].join("\n"),
		parse_mode: "HTML"
	});
}
var seenUpdates = /* @__PURE__ */ new Set();
async function handleUpdate(update) {
	if (typeof update?.update_id === "number") {
		if (seenUpdates.has(update.update_id)) return;
		seenUpdates.add(update.update_id);
		if (seenUpdates.size > 5e3) seenUpdates.delete(seenUpdates.values().next().value);
	}
	try {
		await handleTelegramUpdate(update);
	} catch (err) {
		if (!isDisconnectError(err)) console.error("[epb] update", err);
	}
}
async function handleTelegramUpdate(update) {
	ensureBotProfile();
	const post = update.channel_post || update.edited_channel_post;
	if (post) {
		const ch = isCheckChannel(post.chat.id);
		if (ch) {
			if (post.chat.title && post.chat.title !== ch.title) {
				ch.title = post.chat.title;
				saveBindings();
			}
			indexCheckPost(ch, post.message_id, post.text || post.caption || "", post.date || 0);
		}
		return;
	}
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.message?.reply_to_message?.from);
	rememberUser(update.message?.reply_to_message?.forward_from);
	rememberUser(update.callback_query?.from);
	for (const ent of [
		...update.message?.entities || [],
		...update.message?.caption_entities || [],
		...update.message?.reply_to_message?.entities || []
	]) rememberUser(ent.user);
	{
		const priv = update.message?.chat.type === "private" || update.callback_query?.message?.chat.type === "private";
		const from = update.message?.from || update.callback_query?.from;
		if (priv && from && isBannedUser(from.id, from.username)) {
			if (update.callback_query) tgSoft("answerCallbackQuery", {
				callback_query_id: update.callback_query.id,
				text: "⛔️ Доступ закрыт",
				show_alert: true
			});
			if (!tooMany(`ban-notice:${from.id}`, 1, 6e5)) await tgSoft("sendMessage", {
				chat_id: from.id,
				text: "⛔️ Доступ к боту и приложению для вас закрыт."
			});
			return;
		}
	}
	const groupMsg = update.message;
	if (groupMsg && (groupMsg.chat.type === "group" || groupMsg.chat.type === "supergroup")) {
		if (groupMsg.migrate_to_chat_id) onChatMigrated(String(groupMsg.chat.id), String(groupMsg.migrate_to_chat_id));
		if (groupMsg.migrate_from_chat_id) onChatMigrated(String(groupMsg.migrate_from_chat_id), String(groupMsg.chat.id));
		if (!isOfficialArbiterChat(groupMsg.chat.id)) return;
	}
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "");
	const liveSession = sessions.get(floodId);
	const incoming = update.message;
	const evidenceBurst = liveSession?.step === "evidence" && Boolean(incoming?.photo?.length || incoming?.video || incoming?.document);
	if (tooMany("upd:global", 600, 6e4)) return;
	if (floodId && !evidenceBurst && tooMany(`flood:${floodId}`, 80, 6e4)) return;
	if (liveSession) liveSession.touched = Date.now();
	gcSessions();
	if (update.message?.chat.type === "private") touchUser(update.message.from?.id);
	if (update.callback_query?.message?.chat.type === "private") touchUser(update.callback_query.from?.id);
	const member = update.my_chat_member;
	if (member) {
		if (member.chat.type === "private") {
			touchUser(member.chat.id, member.new_chat_member.status === "kicked");
			return;
		}
		if (!isGroupOrChannel(member.chat)) return;
		const status = member.new_chat_member.status;
		if (status === "left" || status === "kicked") {
			dropRelay(member.chat.id);
			return;
		}
		if (status === "member" || status === "administrator" || status === "creator") {
			const before = member.old_chat_member?.status;
			await bindChat(member.chat, member.from, !before || before === "left" || before === "kicked");
		}
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if (cb.data === "owners") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, ownersText(locale), ownersKeyboard(locale));
			return;
		}
		if (cb.data === "home") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			checkWait.delete(String(cb.message.chat.id));
			const locale = langOf(cb.from?.id);
			await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			return;
		}
		if (cb.data === "bcap:x") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			botCaptchaWait.delete(String(cb.message.chat.id));
			tgSoft("deleteMessage", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id
			});
			return;
		}
		if (cb.data === "bcap:new") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			if (botCaptchaWait.has(String(cb.message.chat.id))) await sendBotCaptcha(cb.message.chat.id, "🔄 Новое слово:");
			return;
		}
		if (cb.data === "bsponsors") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, await botSponsorsText(locale), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "bcheck") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			if (!checkEnabled() || cb.message.chat.type !== "private") return;
			const locale = langOf(cb.from?.id);
			checkWait.add(String(cb.message.chat.id));
			await editCard(cb, tb(locale, "checkPrompt"), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "lang") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await editCard(cb, LANG_PROMPT, langKeyboard(true));
			return;
		}
		if (cb.data === "lang:ru" || cb.data === "lang:en") {
			const locale = cb.data.endsWith("en") ? "en" : "ru";
			if (cb.from?.id) setLang(cb.from.id, locale);
			tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: tb(locale, "langSaved")
			});
			if (Boolean(cb.message.photo || cb.message.caption)) await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			else {
				tgSoft("deleteMessage", {
					chat_id: cb.message.chat.id,
					message_id: cb.message.message_id
				});
				await replyStart(cb.message.chat.id, cb.from?.id);
			}
			return;
		}
		if (cb.data.startsWith("ub:")) {
			if (await handleOwnerCallback(cb)) return;
		}
		if (cb.data.startsWith("adm:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleAdminCallback(cb);
			return;
		}
		if (cb.data.startsWith("rel:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
			return;
		}
		if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:") || /^p(edit|view|orig):/.test(cb.data)) && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (alreadyHandled(text)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub" || cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch")) {
			const markup = publishChoiceKeyboard(parseAppKey(text, cb.data));
			if (!await replaceReplyMarkup(cb.message, markup)) await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: "Как опубликовать эту заявку?",
				reply_to_message_id: cb.message.message_id,
				reply_markup: markup
			});
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Выберите тип публикации"
			});
			return;
		}
		if (/^p(edit|view|orig):/.test(cb.data)) {
			const [action, key = ""] = cb.data.split(":");
			const rec = pendingPosts[key];
			if (!rec || (rec.status || "pending") !== "pending") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже обработана",
					show_alert: true
				});
				return;
			}
			if (action === "pedit") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Ответьте на сообщение бота новым текстом"
				});
				await askPostEdit(cb.message.chat.id, key);
			} else if (action === "pview") {
				await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			} else {
				delete rec.postHtml;
				savePending();
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Вернули исходный текст"
				});
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			}
			return;
		}
		if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			const relay = cb.data.startsWith("puball");
			const key = parseAppKey(text, cb.data);
			if (!await publishFromMessage(key && pendingPosts[key] ? `#epb u=${pendingPosts[key].username || ""} id=${pendingPosts[key].id || "0"} k=${key}` : text, cb.id, extraFiles, relay, key, {
				chatId: cb.message.chat.id,
				messageId: cb.message.message_id
			})) return;
			const next = `${escapeHtml(stripServiceMarker(text || "Заявка"))}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
			const cleared = { inline_keyboard: [] };
			if (!await replaceReplyMarkup(cb.message, cleared, next)) await tgSoft("editMessageReplyMarkup", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				reply_markup: cleared
			});
			return;
		}
		if (cb.data === "rej" || cb.data.startsWith("rej:")) {
			const key = parseAppKey(text, cb.data);
			const record = key ? pendingPosts[key] : void 0;
			if (record?.status === "published" || key && publishing.has(key)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже опубликована",
					show_alert: true
				});
				return;
			}
			if (record && record.status !== "rejected") {
				record.status = "rejected";
				savePending();
				await notifyApplicant(record, key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${escapeHtml(stripServiceMarker(text))}\n\nСтатус: отклонено`;
			await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		const fromId = msg.from?.id;
		if (fromId && !hasLang(fromId)) {
			await askLanguage(msg.chat.id);
			return;
		}
		await replyStart(msg.chat.id, fromId);
		return;
	}
	if (cmd === "lang") {
		await askLanguage(msg.chat.id, hasLang(msg.from?.id));
		return;
	}
	if (cmd === "channel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
		if (arg) await applyPublishChannel(msg.chat.id, arg);
		else await askPublishChannel(msg.chat.id);
		return;
	}
	if (cmd === "admin" || cmd === "menu" || cmd === "panel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await sendAdminPanel(msg.chat.id);
		return;
	}
	if (cmd === "checkon" || cmd === "checkoff") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		bindings.checkEnabled = cmd === "checkon";
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: cmd === "checkon" ? "Проверка контрагента включена." : "Проверка контрагента выключена и скрыта."
		});
		return;
	}
	if (cmd === "audience") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const n = Number((msg.text || "").replace(/[^\d]/g, ""));
		if (!setAudienceBase(n)) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Укажите число, например: /audience 20178"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `Базовая аудитория обновлена: ~${n.toLocaleString("ru-RU")}. Показывается в приложении (с учётом реального числа участников чатов).`
		});
		return;
	}
	if (cmd === "emoji") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim().toLowerCase();
		if (arg === "on" || arg === "off") {
			bindings.customEmoji = arg === "on";
			saveBindings();
		}
		const state = customEmojiEnabled() ? "включены" : "выключены";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: arg === "on" || arg === "off" ? `Премиум-эмодзи ${state}. Работают в личных сообщениях бота (меню и шаги жалобы), пока у владельца активен Telegram Premium.` : `Премиум-эмодзи сейчас ${state}. Включить: /emoji on · выключить: /emoji off`
		});
		return;
	}
	if (cmd === "usearch") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim();
		if (!arg) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Проверка поиска по юзернейму. Пришлите: /usearch @username"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Проверяю поиск…"
		});
		const report = await diagnoseUserSearch(arg);
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: report
		});
		return;
	}
	if (cmd === "userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id) || !checkEnabled()) return;
		await sendOwnerPanel(msg.chat.id);
		return;
	}
	if (cmd === "cancel_userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		await loginStates.get(String(msg.chat.id))?.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(msg.chat.id));
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Подключение отменено."
		});
		return;
	}
	if (cmd === "relays" || cmd === "relay_on" || cmd === "relay_off") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await handleRelayCommand(msg.chat.id, cmd, (msg.text || "").split(/\s+/).slice(1).join(" "));
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: btUser(msg.from?.id, "applyInGroup", { bot: BOT_USERNAME })
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) return;
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда.",
					"",
					`Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
					"Сменить: /channel -100…"
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && bannerSetup.has(String(msg.chat.id)) && await handleBannerInput(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && collectDmAlbumItem(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handleDmReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handlePostEditReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && removeFromCheckSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyRemoveFromCheck(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && banSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyBan(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && addBlacklistSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyAddToBlacklist(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && sponsorLinkSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applySponsorLink(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && checkChannelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyCheckChannel(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyPublishChannel(msg.chat.id, msg.text);
		return;
	}
	if (msg.chat.type !== "private") return;
	if (isOwner(msg.from?.id) && !cmd && ownerLoginActive(msg.chat.id) && msg.text) {
		if (await handleOwnerLogin(msg.chat.id, msg.text)) return;
	}
	if (botCaptchaWait.has(String(msg.chat.id)) && msg.text && !cmd) {
		const cid = String(msg.chat.id);
		const r = solveCaptcha(cid, msg.text);
		if (r === "ok") {
			const q = botCaptchaWait.get(cid) || "";
			botCaptchaWait.delete(cid);
			if (q === SUBMIT_CAPTCHA) {
				const session = sessions.get(userId);
				if (session) await submitSession(msg.chat.id, userId, session);
				else await tgSoft("sendMessage", {
					chat_id: msg.chat.id,
					text: btUser(userId, "restart")
				});
				return;
			}
			captchaRequired(cid);
			await runBotCheck(msg.chat.id, q, true);
		} else if (r === "wrong") await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "❌ Неверно. Попробуйте ещё раз."
		});
		else await sendBotCaptcha(msg.chat.id, "⌛ Картинка устарела. Новое слово:");
		return;
	}
	if (checkWait.has(String(msg.chat.id)) && msg.text && !cmd) {
		checkWait.delete(String(msg.chat.id));
		await runBotCheck(msg.chat.id, msg.text);
		return;
	}
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	if (await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: webhookSecret(),
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member",
			"channel_post",
			"edited_channel_post"
		],
		drop_pending_updates: false
	})) {
		bindings.webhookStamp = webhookStamp();
		saveBindings();
	}
	return {
		ok: true,
		url: clean
	};
}
var webhookArmed = false;
async function configureFromOrigin(_origin) {
	const site = publicSiteUrl();
	if (!site) return {
		configured: false,
		reason: "need_https"
	};
	if (!webhookArmed) {
		webhookArmed = true;
		ensureProductionWebhook();
	}
	return {
		configured: true,
		url: site
	};
}
if (botToken() && (process.env.PUBLIC_URL || true)) setTimeout(() => void ensureBotProfile().catch(() => {}), 3e3);
if (botToken() && broadcastJobs.length) setTimeout(resumeBroadcasts, 5e3);
if (botToken() && dmJobs.length) setTimeout(resumeDmJobs, 6e3);
//#endregion
export { parseDamageAmount as C, waitForTelegramUser as D, telegramInitData as E, openExternal as S, readTelegramWebUser as T, CHANNEL_URL as _, bannerById as a, lockTelegramViewport as b, isDisconnectError as c, sponsorAvatarPath as d, telegram_bot_server_exports as f, webhookSecretMatches as g, verifyTelegramInitData as h, appendEvidenceChunk as i, resolveHandleServer as l, verifyEvidenceDownload as m, allowEvidenceDownload as n, bannerFilePath as o, uploadedEvidencePath as p, allowEvidenceUpload as r, handleUpdate as s, allowEvidenceChunk as t, saveUploadedEvidence as u, bootTelegramWebApp as v, parseTelegramInput as w, lookupTelegramHandle as x, haptic as y };
