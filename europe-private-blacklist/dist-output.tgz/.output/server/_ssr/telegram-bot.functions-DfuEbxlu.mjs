import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.functions-DfuEbxlu.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus_createServerFn_handler = createServerRpc({
	id: "35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b",
	name: "getTelegramStatus",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getTelegramStatus.__executeServer(opts));
var getTelegramStatus = createServerFn({ method: "GET" }).handler(getTelegramStatus_createServerFn_handler, async () => {
	const { getBotStatus } = await import("./telegram-bot.server-BcqqUlrm.mjs").then((n) => n.o);
	return getBotStatus();
});
var resolveTelegramHandle_createServerFn_handler = createServerRpc({
	id: "ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093",
	name: "resolveTelegramHandle",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => resolveTelegramHandle.__executeServer(opts));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({ input: string().min(1).max(200) })).handler(resolveTelegramHandle_createServerFn_handler, async ({ data }) => {
	const { resolveHandleServer } = await import("./telegram-bot.server-BcqqUlrm.mjs").then((n) => n.o);
	return resolveHandleServer(data.input);
});
var evidenceSchema = object({
	id: string(),
	kind: _enum(["image", "video"]),
	name: string(),
	size: number(),
	mime: string(),
	dataUrl: string().optional().default(""),
	storageKey: string().optional()
});
var personSchema = object({
	username: string(),
	telegramId: string(),
	firstName: string().optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(4500),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().optional()
});
var submitToTelegram_createServerFn_handler = createServerRpc({
	id: "60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359",
	name: "submitToTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => submitToTelegram.__executeServer(opts));
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(submitToTelegram_createServerFn_handler, async ({ data }) => {
	const { sendApplicationToArbiters, verifyTelegramInitData } = await import("./telegram-bot.server-BcqqUlrm.mjs").then((n) => n.o);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		ok: false,
		error: "Откройте Mini App из бота Telegram."
	};
	if (data.victim.telegramId && data.victim.telegramId !== authed.id) data.victim.telegramId = authed.id;
	if (!data.victim.telegramId) data.victim.telegramId = authed.id;
	return sendApplicationToArbiters(data);
});
var configureTelegram_createServerFn_handler = createServerRpc({
	id: "308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e",
	name: "configureTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => configureTelegram.__executeServer(opts));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(configureTelegram_createServerFn_handler, async ({ data }) => {
	const { configureFromOrigin } = await import("./telegram-bot.server-BcqqUlrm.mjs").then((n) => n.o);
	return configureFromOrigin(data.origin);
});
var getMyComplaints_createServerFn_handler = createServerRpc({
	id: "8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da",
	name: "getMyComplaints",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getMyComplaints.__executeServer(opts));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({ telegramId: string().min(1).max(20) })).handler(getMyComplaints_createServerFn_handler, async ({ data }) => {
	const { listComplaintsForUser } = await import("./telegram-bot.server-BcqqUlrm.mjs").then((n) => n.o);
	return listComplaintsForUser(data.telegramId);
});
//#endregion
export { configureTelegram_createServerFn_handler, getMyComplaints_createServerFn_handler, getTelegramStatus_createServerFn_handler, resolveTelegramHandle_createServerFn_handler, submitToTelegram_createServerFn_handler };
