import { o as __toESM } from "../_runtime.mjs";
import { o as tb, r as isLocale } from "./i18n-BLMhGn6B.mjs";
import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-BAoYNCim.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+KkrYz9IKvoBmYTQy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{2,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{2,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{2,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
function parseDamageAmount(text) {
	const raw = String(text || "").trim();
	if (!raw) return null;
	const upper = raw.toUpperCase().replace(/Ё/g, "Е");
	let currency = null;
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	const numeric = raw.replace(/[\u00A0\u202F\u2009]/g, " ").replace(/[€$₽]/g, " ").replace(/\b(usd|eur|usdt|rub|евро|бакс\w*|доллар\w*|руб\w*)\b/gi, " ").replace(/[^\d.,\s]/g, " ").trim();
	if (!numeric) return null;
	const s = numeric.replace(/\s+/g, "");
	let normalized = "";
	if (/^\d{1,3}(,\d{3})+$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d+,\d{1,2}$/.test(s)) normalized = s.replace(",", ".");
	else if (/^\d+\.\d{1,2}$/.test(s)) normalized = s;
	else if (/^\d+$/.test(s)) normalized = s;
	else return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n <= 0) return null;
	return {
		amount: normalized.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ""),
		currency
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
async function lookupTelegramHandle(input) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 25e3);
	try {
		const res = await fetch("/api/telegram/resolve", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				input,
				initData: telegramInitData()
			}),
			signal: ctrl.signal
		});
		if (res.ok) {
			const json = await res.json();
			if (json?.username || json?.id) return json;
		}
	} catch {
		if (ctrl.signal.aborted) return {
			...await resolveTelegramId(input) || {
				username: "",
				id: ""
			},
			busy: true
		};
	} finally {
		clearTimeout(timer);
	}
	return resolveTelegramId(input);
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function telegramPlatform() {
	try {
		return String(window.Telegram?.WebApp?.platform || "").toLowerCase();
	} catch {
		return "";
	}
}
function isTelegramDesktop() {
	const p = telegramPlatform();
	if (/(tdesktop|macos|weba|webk|unigram|web)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Windows|Macintosh|Linux/i.test(ua) && !/Android|iPhone|iPad|Mobile/i.test(ua);
}
function isTelegramMobile() {
	const p = telegramPlatform();
	if (/(android|ios|android_x)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
function tgSafe(run) {
	try {
		run();
	} catch {}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tgSafe(() => tg.ready?.());
	tgSafe(() => tg.expand?.());
	tgSafe(() => tg.setHeaderColor?.("#080808"));
	tgSafe(() => tg.setBackgroundColor?.("#080808"));
	tgSafe(() => tg.setBottomBarColor?.("#080808"));
	tgSafe(() => tg.MainButton?.hide?.());
	tgSafe(() => tg.SecondaryButton?.hide?.());
	if (Boolean(tg.isVersionAtLeast?.("8.0")) && isTelegramMobile()) {
		tgSafe(() => tg.requestFullscreen?.());
		tgSafe(() => tg.disableVerticalSwipes?.());
	}
}
function telegramSafeTop() {
	const tg = window.Telegram?.WebApp;
	const safe = Number(tg?.safeAreaInset?.top || 0);
	const content = Number(tg?.contentSafeAreaInset?.top || 0);
	if (!Boolean(tg?.initData || /Telegram/i.test(window.navigator?.userAgent || ""))) return 0;
	if (isTelegramDesktop()) return Math.min(Math.max(safe + content, 0), 28);
	return Math.max(safe + content, 56);
}
function lockTelegramViewport() {
	const apply = () => {
		const root = document.documentElement;
		root.style.setProperty("--app-h", "100dvh");
		root.style.setProperty("--app-top", "0px");
		root.style.setProperty("--tg-safe-top", `${telegramSafeTop()}px`);
	};
	apply();
	const tg = window.Telegram?.WebApp;
	tgSafe(() => tg?.onEvent?.("safeAreaChanged", apply));
	tgSafe(() => tg?.onEvent?.("contentSafeAreaChanged", apply));
	return () => {
		tgSafe(() => tg?.offEvent?.("safeAreaChanged", apply));
		tgSafe(() => tg?.offEvent?.("contentSafeAreaChanged", apply));
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
function openExternal(url) {
	if (!url) return;
	try {
		const tg = window.Telegram?.WebApp;
		if ((/^tg:\/\//i.test(url) || /(?:t\.me|telegram\.me)\//i.test(url)) && tg?.openTelegramLink) {
			tg.openTelegramLink(url);
			return;
		}
		if (tg?.openLink) {
			tg.openLink(url);
			return;
		}
	} catch {}
	try {
		window.open(url, "_blank", "noopener,noreferrer");
	} catch {}
}
function haptic(style) {
	try {
		const hf = window.Telegram?.WebApp?.HapticFeedback;
		if (hf?.impactOccurred && window.Telegram?.WebApp?.isVersionAtLeast?.("6.1")) {
			hf.impactOccurred(style);
			return;
		}
	} catch {}
	try {
		const ms = {
			light: 10,
			soft: 14,
			medium: 20,
			rigid: 24,
			heavy: 32
		}[style];
		navigator.vibrate?.(ms);
	} catch {}
}
var WELCOME_JPEG_BASE64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCALQBQADASIAAhEBAxEB/8QAHgABAAIDAQEBAQEAAAAAAAAAAAECBwgJBgQKBQP/xABfEAABAwMDAQQEAxAPBgMFCQAAAQIDBAURBgcSCAkTITEUFUFRFiJhFxgZMjhYcXR2gZamsrTT1CM1NkJSV2Jnc3WCkbO15DM3VnKUoSSlsSU0g5KVQ0RGU2Oiw9Hh/8QAHAEBAQEAAwEBAQAAAAAAAAAAAAECAwUGBAcI/8QAQxEBAAEDAwIDBQYEAwYEBwAAAAECAxEEBSESMQZBURMiYXGBBxQykaHBcrHR8BVCUiMkNTay4SU0c8InM1OCkqLx/9oADAMBAAIRAxEAPwDl+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAML7gAJwo4qMiATx+UnihMioLYQYT3DIqC2E9wwnuGRUFiRkUBcDIoC4GRQFwMigLYT3DCe4ZFQWwnuGEGRUFuKEcflGRAJ4qMKXIgDC+4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMKTxGRALcUGE9xMiOPyk4QkEyIJAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjCe4jiWBcigLYT3DihcioJ4jClyIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPFScITIqTxUsCZEcUGEJAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQOKEgorxIwpcDIoC2EI4qXIgAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ4+8CCURVJwiEkyI4oSAQAAQAAAAAAAAAAFwAAGAABcAABgAAAABQAAAAAAAAAAAAAAAAAAAAEAADAAAYAAEwAAGAABAAAAAAAAAhUQkFFVRSC5GEUuRUE8fcQUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRvvAglG+8kkzkQSAQAAAAAAAAAAFwAALgAAUAAAAAAAAAwvuGFCAJ4qOPygygE8UJwgMqgthBhPcDKoLYT3DCe4GVQWATKoPquFvr7TX1NqutFUUdbRzPp6mmqI3RywyscrXsexyIrXNVFRUVMoqKinzkiYqjMLnHdUFsJ7hhPcUyqC2E9wwgMqgthCOKAygE8flHFQZQBhRhfcAAAUAAAAAAAAAATAAAmAABAAAAAAAAFVb7iMYLguRQEq33EGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRFUCCUb7yUTBJMiETBIBkAAAAAAABcAAC4AAFAAAAGFAAnj7ycIEyqML7iwCZRxHFCQDJhPcAAgAAAAAA+ipt9fRw0lTWUVRBFXwrUUskkbmtniSR8avjVUw5qSRyMymU5McnmiofOSJiexjAACgAfRb6mGjr6asqbfT18UEzJJKWodIkU7WuRVjesbmvRrkTC8HNdhVwqLhSTOIysQ+czH0k7Uzbu76aesklNTzWq0zNvd3bUQxzROo6d7FWN8T3Ij2yyLFCqJywkquVrmtVDZ/ps276JOou1VTKLaL1HqW3cn1tkm1JcZnpBywyeKTvm97GuWo5eKKx64cmHMc/Z/bDp72c2ar6267b6Jp7TW3CFtPUVLqmeplWJHcuDXzverGquFcjVRHK1iuzxbj8r8S/aLY0dm/t9Nm5b1GJiOqKcRM+eYrnPHMTGYnjyej2/Yq7tdF+a6aqM54mf3iPq5z9e+ifgd1IXmshp6CnpNTUlLe6eKkZw482LDM6RvFESR88E0iqmeXNHKvJzkTXY7Q7n9Pezm8tfRXXcjRNPdq23wup6epbUz00qRK7lwc+B7Fe1FyrUcqo1XPVuOTs6wdSe3fRJ06WqlZW7RevNS3Hi+iskOpLjC9YOWHzyyd87uo0w5GrxVXvTDUw17mcfhT7QNNd0um2v2F25fimKfdimYnpjGczXHlGZmcY5z6tblslym5c1PXTTRM55z5/KJ83P0H0XCphrK+prKa309BFPM+SOlp3SLFA1zlVI2LI5z1a1FwnNznYRMqq5U+c/WInMZeawAAqAB9FFb6+5zOprbRVFXKyGWodHBG6RyRRRukleqImeLI2Pe5fJGtVVwiKpJmKYzJEZ4h84AKAAADCe4ACOKDiSAuVcKCwBlUFsJ7iOPuC5QBhQFAAAAAAABMAACYAAEAAAIJAFVb7iC5CpkuRUEqikGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARMlkTBJkEb7yQCAACAAAAAC4AAFwAAKADCgASjfeSEyrhSeKEgJkwgACAAAAAAAAuAAAwAALgPot9vr7tX01qtVFUVlbWTMp6amp43SSzSvcjWMYxqKrnOVURERMqqoiGzHTntN0jbzw0mm9Uay1rpfWXcwskpqm6UEdHcKh8nd8aKR1Oquc5VjVIXYf+ycW96jHPNrtBdn7sjoDWdm1vRXfV1yq7HVx19LT19fB3Czxryje5IoI3rwejXonJEVWojkc3LV8RvHjzbtlrr0+oori5ETiJp4n0xOcTE+sTh2+l2a/qoiu3MTTPx7NfuvHYyg2z292orrFbKd8Vity6Vudzga2nbUStak0Llp+ao10knrCZzmoqq5683qqtzpkdqd6dltGb86MTRGt1r46SOrir6eooJ0inp52I5qParmuYuWPkYqPa5MPVURHI1yaz626C+lXbiwy6m11ujq6yW2Lknf1d0omd49GOf3cbfReUsitY9UjYjnu4rhFPJ+D/tA0en2+jR6+a6r3VV2pmqauqZq8vnMYxHbGHZbpsl2u/N2ziKMR3nGMRj9nO4Hptw37au1I9u09NqaKwMhjax2op6eSsllxl7lbAxrI25VGo3L1+LyVycuDfMn6/Zue1txXiYz5T3j5vMVU9MzGcgAORH0W+4V9pr6a62qtqKOto5mVFNU08jo5YZWORzHse1UVrmqiKiouUVEVDufp+jutusNtt99vPre5U1JDDWXD0dtP6ZO1iJJN3Tfix83IruCeDc4TyOLuyt603pjdfS+q9W3OoobVp+4x3mZ9PSrUSyupf2eOnYzk1OU0kbIkcqo1qyI5y8WqZF6h+sPcjfvvrFj4OaQk7h3qKmlSXvZI8rznn4NfLl68kZhsacI14q9nNfzjxt4a1ninWafTWIii3REzVXMf6piIiPOZ4mcROO3Vj3c97tOvtbdaruV81TiIj5ec/n/AEzy6q3CSbU+kqmXRupqeklu1ue61XmnjjrIonSxL3NUxqrwmaiua9EzxciJ44U4cXC4V92r6m63WtqKytrJn1FTU1EjpJZpXuVz3ve5VVznKqqqquVVVVTMXTZ1Taz6dLrVMoqT15pq48n1tkmqVhYs/HDJ4pOLu6kTDUcvFUexMOTLWOZ4req9ab1PuvqjVekrnUV1q1BcZLzC+opVp5YnVX7PJTvZycnKGSR8SuRVa5Y1c1eLkNeDPDWp8La7Uaa579quKZpriMdsxNM95ieYxEzicZp/zYm66+3uNm3cp4qjMTHz7TH5f18nigAforowA9Nt4/bVupGN3YptTS2B8MjXu07PTx1kUuMscjZ2OZI3KK1W5YvxuSOXjwdx3rnsrc14mceUd5+S009VURnDzJuL2duzNq15ddb6t1baPS7LFaJNORxzUrkZM+taqVCxVCKixyMgasbuHx+FX9M1F+NkzRPQX0q7j2GLU2hd0dXXu2y8U7+kulE/u3qxr+7kb6LyikRr2Ksb0a9vJMohsxststozYbRi6I0QtfJSSVctfUVFfOks9RO9GtV7la1rEwxkbERjWphiKqK5XOX8h8YfaBotRtt3Q6Ga6b1UxE5pmmaYzme/aeMevL0+17Jdov03r2JpjnvnPo4y6gsV10vfrlpm+0vo1ytFXNQVkHNr+6nierJGcmqrXYc1Uyiqi48FU+A6na97P3ZHX+s7zretu+rrbV3yrkr6qnoK+DuEnkXlI9qSwSPTm9XPVOSoiuVGo1uGpqj1GbTdI2zENXpvS+sta6o1l3MzI6amulBJR2+oZJ3fGtkbTorXNVJFWFuX/sfF3dI9rz1WzePNv3mujT2Ka6rsxGYiniJ88znERE+cz9XW6vZr2lia65iKY+Pdq+AD3DqMAACYAADAAAmAAAAABHFAqKSAuVQWIVvuC5QBhQFAAAAATAAAkwAAIAAAQqZJBRTyBZUyQqYLEiAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACUTIRMliTIgkAyAAAAAAAA1gAAUACIqhAIiqWwiAJkREAAQAAAABcAAC4AAAAAUAAAAAAAAOsvQxd9wtQ9P1v1FuFquov8ALcrjWyW2oqp3T1MdGyTuu7mkenJzkmjqHJlz8McxMoiI1vJo3c1h1rUGzW2tg2T2LpLRWXjTtujtV11DFTtfbFqW06JNPQNTj37nVLpJO+lYjHK1XcJUk5J4D7QNr1W+aWzt+itxVXVXnqntTTEcznyzMx25ntiXdbLqLekuV3rtWIiO3rM/Dz83Qo5F9Zt33Cm6gdWad11quou0VquL5LVTpO51NRUdRHHLDHFGqNbG7uVgbJxb8Z7FVVevxl+DaPqs3f2r1y3V8mrLvqOlq5kfd7ZdbjNNFcWqyONXOc9XKyZI4omsmRFc1I2tXkzLHf3usXcPb3ebVth3c29lp6eK7W59tuVunibDc4ayllX9mqmMy1zZIZqdsciPfySJzMtWJWp0fhPwlrPCm9x7eIuW7lExFcR+GqMTic8xmInntPHnw+vctytblpPc92qme3rH7+Xya/AA/W3mgAAAAAAAAAAAABnLoyu+4UPUDpPTuhdV1FpiutxZJdadZ3Npq2jp45JZo5Y0RzZHdyk7Y+TfiveiorF+MnXQ5NdHW4e3uzOrb9u5uFLT1EVptzLbbbdBE2a5zVlVKn7NSsfhrWxww1DZJFezikrWZcsqNX4N7esLd/eW8QTpeajS1noJu9orXZquaFqObOksMs8iORZpmKyJWvw1rXRo5jI1V2fyPxb4T1virfIixTFu1RTEVVzHeqczx51YiYj0jnnyem2zcrW26P356qpmcR8O3082+fXPd9wtPdP1w1Ft7quosEttuNFJcqilndBUyUb5O67uGRicmuWaSncuHMyxr0yqKrXcmjc3bLrAoNyNoLx0+751FPJdbzbprRZdT3RGvo0lfC9KaS4vXLmOimSFUqWtev0r38XRulfpkd/4B2rU7Fp7+3auiIrprzFURxXTMcTnz5ie/MdpiHxbzqbesrov2p4mO3pMd/2AAe9dMAAAAAAAAAAIAAGAABMAACAVEUACqooLDCKFyqCVaQFAAFAAEwAAMgAAAACqpgguVVPaaiRAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEonvCJ7yxJkAAZAAAAAFiAABQABQImSUT3khJkREQABkAAAABcAACgACgAAAAAAAAAAA9NQbc6tue3t23Po7VUSWCy3GltlVUpBKrUlnbI5F5o3gjWKyNr1VyKjqiBML3iHmTjt3rd2aoonPTOJ+E4icflMLNM04mY7gAORAEjC+4CAThRxUZTKAW4/KOPyjJlUFuI4oMmVQW4oOKEyZVBbig4oMmVQW4oOJcmVQW4/KOPyjJlUE8VHFRkygE4X3DCgQAAoAemr9udW2zb207n1lqqI7BerjVWylqVglRqywNjcq81bwVr1fI1io5VV1POmE7tTjuXrdqaYrnHVOI+M4mcflErFM1ZmI7PMgA5EAAAAAAAAAAAAAQAATAAAgFRFAAqqYBYhU9waiUAAKAAIAAJMAACAAAqqe4guQqe41EioAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASiZCJksSZAAGQAAAABYgAAaAAAJantCJ7yQzMgACAAC4AAFAAFAAAAAAAAACcKEQC3FCcJ7iZMq4GFPfbQb4bj7G36S+7e3z0T0vum19HNGktLXRxvRyMljX+01HtVsjWvejXN5LnqZsH1M7cdQFqb8G670LUNNSMqbnYqhV7+ky5WOVj1ajZ40cifHZ5I+Pmkbnow8b4o8Ta7w5T7enR+1s/wCqK5jH8UdE4jPaczHriZiHabdoLOvnom701ekx3+U55eK2j6YrI3pDTZ6+xVFHW6xtyXW6S1EE0ctLc5mxyxOfAsiKjqdY6disyxHrTryanNyHLO4W6utNfU2u60VRR1tHM+nqaaojdHLDKxytex7HIitc1UVFRUyioqKd3DyO6e6ejdnNG1mudc3L0WgpcMjjYiOnq51RVZBCxVTnI7C4TKIiI5zla1rnJ+TeGfHmu2/VX4mzN+q/X1RTFWMVT3x7tWcxiMcYimMPTbhs1m/bonr6IojGceX5x8fzcScJ7iTNXUl1S6y6i7rSsraT1Hpu3cX0VkhqVmYk/HD55ZOLe9k8XI1eKIxi4amXPc/Cp+/aC9qb+npuau3Fuue9MVdWPhnERM+uOPSZ7vEXqbdFc02quqPXGM/QAB9jjwAAGAAAwAAGAAAwAAGAAAwAAGAAAwAAGAYT3AzV029UusunS61TKKk9eabuPJ9bZJqlYWLPxwyeKTi7upPBqOXiqPYmHJlrHM+PX3tTY09VzSW4uVx2pmrpz8M4mIn0zx6zHdyWabddcU3aumPXGcfThhygt1ddq+mtVqoqisrayZlPTU1PG6SWaV7kaxjGNRVc5VVERETKqqIh1M3c6YrI7pDXZ6xRVFZW6Oty3W1y08E0ktVc4WySyuZAkiqrqhZKhiMy9GLUJxavBqGYtrN09G7x6No9c6GuXpVBVZZJG9EbPSToiK+CZiKvCRuUymVRUVrmq5rmuX1x+A+JvHmu3DVWIizNiqxX1TTNWc1R2z7tOMRmMc5iqcvb7ds1mxbrma+uK4xnGOPzn4fk4NYUYU7Fb+dTO3HT/anfCSu9N1DU0j6m2WKnVe/q8ORjVe9Gq2CNXKvx3+aMk4JI5isOWe7++G4++V+jvu4V89L9E71tBRwxpFS0Mcj1crIo0/stV7ldI5rGI5zuKY/WfC/ibX+I6fb1aT2Vn/VNczn+GOiMxnvOYj0zMTDzO46CzoJ6Iu9VXpEdvnOeHgAXwnuI4oeyy6vKoJ4qQUAAFAAAAAAAAAAAAAZwAAIhUILEKmQsSgABoAAAABmYAAEAABVU9pBcqqGokQACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASiZCJksSZAAGQAAAABYgAAaACUT3hEImS2MABJkAAQAAaiAABQAAAAAAJRFUCAW4oSTKZV4qThCQTKZAAEwAALgNxOzb2sqb7uPdN1rhbeVt0zSPo6CoesrP/aNQnFVjVE4ScKdZUe1yrx9IiXj4o5unZkul381lYto49mtFyfB+y13pUuoZKeRXz3qeZ6Jl73JmGNII4Ye7iVqPRsivV6SK1vQ+JNFq9z2+vQ6OYpm57s1T/lpn8U+s5j3YjzmecRmY+3QXbWnvxeuxnp5iPWfL+v0dNtQdXPT/pfcFdtb1r6ngukUzqWqm7iR1HR1KOjakM1QjeDXKsjsuyrI+5lSR0bkRFxZ2kmhfX+zVr1tSWvv6vSt3Z31T3/H0ahqW93J8RXIj+U6UaeCOcnmmG81OaJkvSe/mstP7cXnZ28yevdEXekqI2WmpkVnoVW5Wyw1MErU5s7uojjlWLKxPzIitRZFenitP9nX+CavTbhtl2aqrcx1xV/mjtV0zGMTiZiKZzE+dXfPb17797tXLGopxFUcTHlPln1584/L0xoAD9TedAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHS7s29C+oNmrprartfcVeqru/uanv+XpNDTN7uP4iOVGcZ1rE8Ua5fNct4KZT0/wBXPT/qjcFNtbLr6nnukszaWlm7iRtHWVKukasMNQreDnIsbcOyjJO+iSN0jlVE5k6s381lqDbizbO2aT1Foi0UlPG+000iv9Nq2q6WapnlcnN/eVEkkqRZSJmI0RqrGj1xoflmo+zr/G9Xqdw3O7NNVyZ6Ip/yx2p6pnOZxERNMYiPKrtj0VG+/dLVuxp6cxTHOfOfPH185/L13E7STaypsW49r3Wt9t423U1Iyjr6hiyv/wDaNOnFFkVU4R86dIkY1qpy9HlXj4K52nZkuq381lfdo5NmtaSfCCy0PosunpKiRWT2WeF6plj2pmaNYJJoe7lVyMR0asViRo12ND2vhvRavbNvo0OsmKpt+7FUf5qY/DPrGI92Y8pjjMYmeo1921qL83rUYirmY9J8/wCv1AAd8+LAAAmEYQjipYDK5VILkKiFyZVBKopBWgAAAAAAAAABJgAAZCFTBIBlUEqnuIDQAAoAAkwAAMgAAqqe0guVVMGokQACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKJkCU8iQDAAAAAAsQAANABZEwEmcIRMEgBkAAXGQABQABQAAACUTIRBPFSyIiAmUyhERCQCIAALgAAXAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAACYAqIoATsrx9xBcYyXK5UBKoQVQABQAAAAEAAEmAKmQAivkCypkr5BqJAAFAAGZgAAQIXxJAFASqYINgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZEwETBJmZAAEAAAAAGgAImQqW+8kAMAACxAAA0AAAAABKIqhE95YkykyhERCQCM9wABrAAAoAAAAAAAAAAAMp6e2Nr7907ar34ZcadkWnL5R2xKZZnI58Tka2deHdqiu7yqouC80Tik+UyjM4sPm0+rs6qq5TanPRV0z8JxE4/KYbrtVW4pmqO8Zj5dv2AAfSwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZT09sbX37p21Xvwy407ItOXyjtiUyzORz4nI1s68O7VFd3lVRcF5onFJ8plGZ+bVauzo6aar046qqaY+M1TiI/Nu3aquzMUR2iZ+kcyxYAD6WAAAAAAAAAAAAAEwBURQAnZVUVCC5Cp7ixKxKoAKoAAAAAAAMzAQvkSAioJVCA0AAKAAMzGAABEL4lfIuQqZLEioANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEtT2kFk8iSJABkAAAAAagACJkKImSwAZmQABAABoAAUAAAsiBEwSSZZmQAEIgAAaAAAAAAAAAAAAAGRNsOn7dreWgrbjtrpmnvMVtmbBVtbdaOCWFzm5aropZWvRrkReLuPFVa9EVVa5E9r84v1T/wAV3/ndu/WDDuktW6k0JqS36u0jeKi13i1zJPS1UCpyY7CoqKi5RzVRVa5rkVrmuVrkVFVF6idKvV3auof0zTN2sPqTVlrpGVc0EL3S0tZAndsknicqZixK9EWJ6qqNezD5Pj8fBeLt48Q7DTOs0Vu3csR3zTV1U/PFcZj4xEY844zPc7ZpdDrJ9leqqpr+cYn9OHpqLYeG39LLthIKK0OrXaXlt6rO+Saj9bSRue6pRz2q9GpVuWZqo3LPBWtbxRE57/OL9U/8V3/ndu/WDrUa79VXV3aunj0PTNpsPrvVl0pH1cMEz3RUtHAveMjnlciZlzKxUSJioqtY/L4/icvyrwl4m321qrml223TduXqprnqz385z1U4+Mz8HpNz2/R1W6bmoqmmmiMcenlHaXOjc/p+3a2aoKK47laZp7NFcpnQUjXXWjnlmc1uXK2KKVz1a1FTk7jxRXMRVRXNRcdn9fVurdSa71JcNXauvFRdLxdJlnqqqdU5PdhERERMI1qIiNa1qI1rWo1qIiIifyD+iNFGqpsUxrJpm559MTFP0iZmePXPPfEdnhrs25rn2UTFPx5n9IgAB9TjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyJth0/btby0FbcdtdM095itszYKtrbrRwSwuc3LVdFLK16NciLxdx4qrXoiqrXImOz+vpLVupNCakt+rtI3iotd4tcyT0tVAqcmOwqKiouUc1UVWua5Fa5rla5FRVRfl1saqqxVGjmmLnl1RM0/WImJ59c8d8T2clqbcVx7WJmn4cT+sSzF84v1T/xXf8Andu/WDoRRbDw2/pZdsJBRWh1a7S8tvVZ3yTUfraSNz3VKOe1Xo1KtyzNVG5Z4K1reKInmelXq7tXUP6Zpm7WH1Jqy10jKuaCF7paWsgTu2STxOVMxYleiLE9VVGvZh8nx+OxB/O/i7xNvt/UUaPc7dNuuzVFcRTnEz5TzVVE/DHrL3O2bfo6KJu6eqaoqjHP6x2hyV+cX6p/4rv/ADu3frB4rc/p+3a2aoKK47laZp7NFcpnQUjXXWjnlmc1uXK2KKVz1a1FTk7jxRXMRVRXNRei/VV1d2rp49D0zabD671ZdKR9XDBM90VLRwL3jI55XImZcysVEiYqKrWPy+P4nLl3q3VupNd6kuGrtXXioul4ukyz1VVOqcnuwiIiImEa1ERGta1Ea1rUa1ERERP1XwjvHiHfqY1mtt27die2Kauqr5ZrnEfGYnPlHOY83uel0Oin2Vqaqq/nGI/Tl/IAB710wAAAAAAAAAAAAAAAMzCFTJUuFTJYkiVASQVoAAAAAAAGAhUwSAZVBKpggNAABIAAyAACrk9pBZfIqagAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALJ4EN95YzIAAgAALAAA0FkTCFU8ywZkAAQAAaiAABQAACWkFmiUlIAMpEAADQAAAAAAAAAAAAAAAAb89nhJpvbnaDcXeTV2pqe3Wd1xgoapZ41RtO2ki5o9HIqrI6Ra5GNja3krmojeSvRE0GP6911bqS92Syabut4qKi16chngtdI5USKlbNM6aVWtTw5PkequcuXKiMaq8WNROh8R7PVv2h+4dfRRVVT1T3npierEfGZiPl35xifs0GqjRXvbYzMROPnPHP0z/fLfHUHaZ6boNwVt1h2/qLpo6nmdTyXL0pYqypbyj/8AEQwuYiNaiJPiJ7kdJyiVXQqjmr8HaHyab3G2g263k0jqanuNnbcZ6GlWCNVbUNq4uavVyqixujWhVjo3N5I5yo7irFRdBj+vatW6kslkvem7VeKinteo4YILpSNVFiqmwzNmiVzV8OTJGIrXJhyIr2ovF7kXorHgPQ7ZrNNrtr9yu1POZmeumYxVnOcVYmZiYjHliOJp+yveb2otXLOo5irt5YnvH0/v5/yAAe7dOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADfns8JNN7c7Qbi7yau1NT26zuuMFDVLPGqNp20kXNHo5FVZHSLXIxsbW8lc1EbyV6In36g7TPTdBuCtusO39RdNHU8zqeS5elLFWVLeUf/iIYXMRGtREnxE9yOk5RKroVRzV0OuurdSXuyWTTd1vFRUWvTkM8FrpHKiRUrZpnTSq1qeHJ8j1Vzly5URjVXixqJ/IPCXfAeh3HX39x3T/aVXJ4iJmIppiIpp7YmasRHfiO2JmOqe4p3m9Ys0WNN7sU+feZnvP0z/fk357Q+TTe420G3W8mkdTU9xs7bjPQ0qwRqrahtXFzV6uVUWN0a0KsdG5vJHOVHcVYqLoMf17Vq3Ulksl703arxUU9r1HDBBdKRqosVU2GZs0SuavhyZIxFa5MORFe1F4vci/yDvfDmz1bBovuHX10U1VdM9p6ZnqxPxiZn59+M4j49fqo1t722MTMRn5xxx9Mf3yAA758YAAAAAAAAAAAAAAAAAAzMId7ypZ3kVLCwAAqgAAAAJMZAAGRfEqWKr5hYAAGgABmQABAoqYLkO8iwKgA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKeYEomCQDAAAAAA1AAAonmWCJgBmZAACAABoAAAAACzSMZLImCSkgAIQAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkod5FS5VUwWEhAAK0AAAAAAADMhVfMsFTIIVAAaAAEkAAZCF8SQBQEuINgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWRMBEJMzIAAgAAAAA2AEtT2hEgAMgADUQAAKAAASiZJRPeSSZSZETAAIz3AAGgABQAAAAAAAAAAAAAAAAAAAAABs9oPpqZqPov1fu3JaKh9/bcW3W0yJNTI11soeUdS7Lk5taqSVrns5NV7qSBUauER+sJ1ug3TT7jXet2JzNquaKvnERM/zx84lz3tPXYiiquPxRmAAHZOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADZ7XnTUzTnRfpDduO0VDL+64uut2kWamVrbZXcY6Z2Wpzc1EjonMZycrHVc6q1MqjOt1+6afbq7Nu/OJu1xRT85iZj+WPnMOezp678V1Uf5YzPyawgA7JwAAAAAAAAAAAAAAAAAAAAAAAAgAAmMKqmCC5Cp7ixJEqgArQAAAACSAAMqr5glUIDUAACgADAAAIVMlfIuQqZLEioANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATzAuADAAAAAAsAADQWQqnmWDMgACAADYAABZE9pUunkSUkABGQABsAAAAAAAAAAAAAAAAAAAAAAAB7zaDRe3GvL9JYtwt1vgJ3vdNoKya0LWUs0jno1WSyJKzuMcmuR7k7vij1c5nFOW2v0Lf+fP8WP9WaHG8XZ/b+buX3WdNs1c5PhBpahtEksclRIxk9lghXDFY9U5zRq+SOHu1VysR0asVjI3Nd4XxnG+aLTVbjtWq6aaIzVRVTRjEedMzTM5+Ezz5c4ie42r7nduRY1NvMz2mJn9cT+sfX1b1aQ0zQaK0nZNG2qaolorDbqa2U0lQ5rpXxQRNjYr1aiIrlRqZVERM5wieRpZcOy6oJK+pktW9VRT0TpnupoajT7ZpY4lcvBr5G1DEe5EwiuRjUVcqjW+Sb1GtHXhu/uPtNtfQfAGD0Jmoqt9rrb6ydGz2/MavZHCz6ZJJWtlxMn+zSJ2MPex7fxLwruW807h912u9FFd+YzMxTMTjM5nqie2Z7cz2jMvW7jp9LNj2moozFEcYz+30aO9SWwujdgLrS6Vot2vhVqR/GWtt8NmSmZQQObliyy+kPxI7LVbHxzwXm5WorOeFQD+m9BYv6bT029Tdm7XHeqYinM/KmIiI9I5+My/Pr1dFyuardPTHpmZ/WQAH2OMAAAAAAAAAAAAAAAAAAAAAAAAM1dNuwujd/7rVaVrd2vgrqRnKWit81mSpZXwNbl6xS+kMzI3DldHxzwTm1XIj+GFQfHr7F/U6eq3prs2q57VREVYn5VRMTHrHHwmHJZrot1xVcp6o9MzH6w35t/ZdUEdfTSXXeqoqKJszHVMNPp9sMskSOTm1kjqh6McqZRHKxyIuFVrvJd09X6ZoNa6TvejbrNURUV+t1TbKmSnc1srIp4nRvViuRURyI5cKqKmcZRfI1/6D939x92dr6/4fQems07VstdFfXzo6e4YjR745mfTLJE10WZl/wBokrc5ex73bLn8yeKty3mrcPuu6XorrsTOJiKYiM4nMdMR3xHfmO04l+g7dp9LFj2mnoxFcc5z+7Q36Fv/AD5/ix/qzUrd/Re3Gg79HYtvd1vh33Xetr6yG0LR0sMjXq1GRSLK/v8APFzle1O74qxWufyXjtN2gO/m7li1nU7NWyT4P6WrrRHLJJTyMfPeoJlw9XvROcMaPjkh7tFar0bIr1eyRrW6On7b4MjfNbpqdx3XVdVNcZpoppoxifOqYpic/CJ48+cxHkt1+52bk2NNbxMd5mZ/SJn9Z+nqAA906cAAAAAAAAAAAAAAAAAAAAAAAAAAYQqe0qXKFhqAAFUAAAABgKliHeYWEAANAADMgACAAAovmCV8yDYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE8wE8wLgAwAAAAALAAA0lpJDfIkMyAAJAAA2AACU8yxDSSSzIACEAADQAAAAAAAAAAAAAAAAAAAAAAAAbidK+421/TFtHd91taR+l601f3zNPWqJY3z1dup3pFyR7WudSRvqu+R7pVTmlIisY9Y0R2nYOp3nabe96b7nfqmLczE1RHE1RHPTnyiZxn4RMRiZzH06XU1aS57WiPexx8Pi2P1B18dQFy3BXWVlvtParXDM5KXT3o8c1GlMro1WKZytR8rnJE3MuWvTnL3axNerTMW7PURtx1Z9OF/sVPavVWvrHm/wBHYqmsX4sdI9FqKiCdUjjnxRSVLliVO8+LIrY3cGvXQ4HV3/B21VV2L2ltxauWZiaZp47TnFX+qJ88+9PPvRmc/RRuupiK6LlXVTVnMT/OPT4eXwAAeqdcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN8dpuojbjpM6cLBYqi1etdfXzF/rLFTVi/Gjq3qtPUTzokkcGaKOmckSJ3nxo1dG3m56Yd0/wBfHUBbdwU1ler7T3W1zTNSq096PHDRrTI6RUihcjVfE5qSuxLlz14Rd4srWI01wB5Wx4O2qmu/e1VuLty9MzVNXPec4p/0xHlieqOPenEY7GvddTMUUW6ummnGIj4ec+vx8vg3E6qNxtr+p3aO0braLj9E1ppDuWahtUqxsnpLdUPWLkr3Na6rjZVdyjHRKvBKtVexiyKjdOwDtNm2m3smm+52Kpm3EzNMTzNMTz0584ic4+ExE5mMz8+q1NWrue1rj3sc/H4gAO2fMAAAAAAAAAAAAAAAAAAAAAAAAAAMyFV8yxDhBCoANNAAAAAMyEL5EhfIJCoADYAAzIAAgAAKr5kEr5kG4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnmAnmBcAGAAAAABYAAGkt8iSG+RIZkAAIAAGgAAWaSQ0kzLMgACwAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH9fSGma/WurLJo21TU8VbfrjTWymkqHObEyWeVsbFerUVUaiuTKoirjOEXyMV102qZrrnERzKxE1TiHz3KxXW0UdquFwpe6p73SOr6B/Nru+gbPLTq/CKqt/ZaeVuHYX4ucYVFX4DfntDNsKDS2zG18lqulQ6i0ZMmmKaGoY18s8UlI3hK+RvFEc1KBEVEZhyyKqceOF0GOl8Ob3R4g0Ea6iMZmqMemKpiPzpxM/N9ev0k6K9NmZzxH8v6gAO9fGAAAAAAAAAAAAAB99ksV11FWSW+zUvpFRFSVVe9nNrMQU0ElRM/LlRPixRSOx5rxwiKqoi/Ab49mVtn+6neOoq/fpmjgZJ/Q1FQ+Rqs+1kYqP/8AzeTfpVOj8R71TsG23NdVGZp7R6zM4iP3+T69BpJ1t+mzHGe/yaHA/va/0t8Btd6j0T6d6b8H7vWWr0nuu77/ALiZ8fecMu48uGcZXGcZXzP4J3Fq5Teoi5ROYmMx8pfLVTNMzTPeAAHIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkhDvIkh3kIZhUAGmwAAAAGZAvkAvkEhUABsAAZkAAQAAFV8yCV8yDcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATzATzAuADAAAAAAsAADSW+RJDSQzIAAQAANAAAs0kqnmWMyzIAAQAANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANnunS+9Gmp4aTSO+G2VPYbxHDDBHf/XdySjuMyycMzMbLikdhWOVyr3PhK5VhRGsXerQvSjsFtrqqh1tonQXq69W7vfRqn1pWzd33kbo3/Ekmcxcse5PFF88p44U47nVPs/LNX2vpqtFdWXyor4rvca+tpaeTlxoImzLAsDMuVOKyQSTeCNTlO7wzlzvx77R9uv7bpZ12n1d2mm5V0zbmuuaZ6onOOeIxE5pnMeUY4ifUbDfo1Fz2NdqmZiMxViInj6fr3Zy11oXSu5Wla7ROtrX6xstx7r0mm7+SHvO7kbIz48bmvTD2NXwVPLC+GUNaN39h+hDY2wx33cLRXonpfetoKOG73OWqrpI2K5WRRpUf8rVe5Wxtc9iOc3kmdraa4UFZNVU1HW088tBMlPVRxyNc6CVY2SIx6IuWuWOSN+FwvF7V8lRTkN1gWavsPUrr2huN8qLtLLcW1raiflyZFUQxzxQJlzl4xRyMhb444xphGphqeP8AaLVbrratFTq7lmimOuaaKqqertHlOI7xziZmMRHrHab3et6a1F6bdNUzOMzETjvP9Xg9w9Q6P1NqR9x0Lt9T6Ns6QsjitsdyqK93JE+NI+adVVzlVV+laxqNRqYVUc53mQD+jbNqmxbi3TnEcczMz9ZmZmfnMzLwlVU11TVP9P0gAByIAGYukrambd3fTT1kkpqea12mZt7u7aiGOaJ1HTvYqxvie5Ee2WRYoVROWElVytc1qofJr9Za27S3NXenFNETM/SP38nJZtVX7lNujvM4YluFvr7TX1NqutFUUdbRzPp6mmqI3RywyscrXsexyIrXIqKioqZRUVFPnNiOvXRPwP6j7zWQ09BT0mpqSlvdPFSM4cebFhldI3iiJI+eCaRVTPLmjlXk5yJrucW1a+ndNDZ1tPHXTFWPTMcx9J4a1NmdPeqtT5TMAAOwcIem281Do/TOpGXHXW31PrKzrDJHLbZLlUUDuSp8WRk0CorXIqJ9M17Varkwiq1zfMg471qm/bm3VnE8cTMT9JiYmPnExK01TRVFUf1/SXS7aDYfoQ3ysMl9290V6X6J3Ta+jmu9ziqqGSRiORksa1H/M1HtV0bnMejXO4rjZfQuhdK7a6VodE6Jtfq6y27vfRqbv5Ju77yR0j/AI8jnPXL3uXxVfPCeGEOTnR/Zq+/dSugqG3XyotMsVxdWuqIOXJ8VPDJPLAuHNXjLHG+F3jjjIuUcmWr15rbhQW2FtTca2npYnzRU7ZJ5GsasssjY4mIqrjk+R7GNTzVzkRMqqIfzl4/0Wp2rW0aGdXcvUVRFcU11VVdPM0x3nEz3xMRE44x5z7vZb1vU2ZvRbppmOJmIiM9p/oxZrrpR2C3K1VXa21toL1jerj3XpNT60rYe87uNsbPiRzNYmGMangieWV8cqaK9Rd96NNMQ1ekdj9sqe/XiSGaCS/+u7ktHbpkk4ZhY6XFW7CPcjkXufGJyLMiuYm2vaB2avunTVd66jvlRQRWi40FbVU8fLjXxOmSBIH4cicUknjm8UcnKBvhnDm8rD2H2cbdf3LSxrtRq7tVNurpi3FdcUx0xGM88xiYxTGI8pz2jq9+v0ae57Gi1TEzGZqxEzz9P17gAP2F5cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZkIcSVd5iCEAA00AAAAAzIF8gF8gkKgANgADMgACAAAqvmQSvmQbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACeYAFwAYAAAAAFgAAaE8yxUsGZAAEAAGwAAC6eRQs1fYSUlIAIyAANgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABtbub1t6ktuirPs3sfcqi32fTduhskmqO6SKsu8MNKyDvIYXIq0TXKj3oqOWb/AGSo6JUc1dUgdZr9n0e6XLdzV0dfs8zETzGZxzMeePLPHOcZxMfRZ1V3T01U2px1d583rdrN09ZbOazo9c6GuXotfS5ZJG9FdBVwKqK+CZiKnON2EymUVFRrmq1zWuTInVPvZpvqEu+mtx7dS1FovEduls1yscmZm0rYZ3Sw1DKnDUlbKlS9OPBrmOgdlFRzXLg4Fu7Vpbuto3GacXaYmOqPOmY7T6x5x5xPacTMTKdTcpszYz7s84+PrH9/sAA7JwB9FvqYaOvpqypt9PXxQTMkkpah0iRTta5FWN6xua9GuRMLxc12FXCouFPnBJjMYOzoB027edEvUXaqplFtH6j1JbuT62yTakuEz0g5YZPFJ3ze9j8Wo5eKKx64cmHMc/Z/bDp72d2ar6267b6Jp7TW3CFtPUVLqmeplWJHcuDXzverGquFcjVRHK1iuzxbjjRb7hX2mvprraq2oo62jmZUU1TTyOjlhlY5HMex7VRWuRURUVFyioiodzLBR3W3WG22++3n1vcqakhhrLh6O2n9MnaxEkm7pvxY+bkV3BPBucJ5H4H9oug1ey10xRrLlVm9n/Z1V11Y6cTPMzMVRmYxnmOO/d7TYr1rVxObVMVU496IiO+fhxPy/R4rc/p72d3lr6K67kaJp7tW2+F1PT1LamemlSJXcuDnwPYr2ouVajlVGq56txydnWDqS286JenS1UrK3aP15qS48X0Vkh1JcIXrByw+eWTvnd1H4ORq8VV70w1MNe5m5lwkm1NpOpl0bqanpZbtbnutV5p446yKJ0sS9zUsaq8JmormvRM8XIieOFOHdwuFfdq+put1raisrayZ9RU1NRI6SWaV7lc973uVVc5VVVVVXKqqqo+zvb9ZvFyum7q7lFqzjNumuunOc8cTEUxmJzjnv27m+X7WliJptUzVXn3piJ7Y+HP99y4VMNZX1NZTW+noIp5nyR0tO6RYoGucqpGxZHOerWouE5Oc7CJlVXKnzgH75EYjDxfcABRnHpY3s03093fUu49xpai73iS3RWa22OPMLaps07ZZqh9ThyRNiSmYnHg5z3TtwiI1zk8Vu/vhuPvlfo77uFfPS/RO9bQUcMaRUtDHI9XKyKNP7LVe5XSOaxiOc7imPBg6yjZ9HRrqtymjN6rEdU8zERGMU+nnnznPM4xEfROquzZixn3Y8vX5tntler6vte2tx6f91Kion0xerdUWOj1A1HT1Nhpp6eSH40KeNVDGrmK1iOa9jEe1qvRI426wgF0W1aXb7129pqembsxNUR26ozzjymfPy4zjMzMy7qbl+imi5OeniPl6AAOycAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwFCyr4FSw1AACqAAAAAwEO8ySoWAABoAAZkAAQAAFV8yCV8yDcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsi+BJTyLIuTMwJABAAAAABsJavsIASVgAGQABqAABQAAWRSShKL7yTDMwsACGcAACgACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD2uy1603pndbS+q9W3OoobXp+4x3mZ9PSrUSyupf2eOnYzk1OUskbIkcqo1qyI5y8WqZE6husLcffvvrFj4O6Qk7h3qKmlSXvZI8rznn4NfL8deSMw2NOEa8VezmuBgdZe2fR6nW0a+/R1XKIxTnmKec5iPWeOfLHGOc/RRqrtu1NmicUz3+P8A2/uWaum3ql1l06XWqZRUnrzTdx5PrbJNUrCxZ+OGTxScXd1J4NRy8VR7Ew5MtY5nit6b1pvU262qNV6SudRXWvUFxkvML6ilWnlidVfs8lO9nJycopJHxK5FVrljVzV4uQ8UC29q0tnW1bhapxcrjFUx/m7YmfjHbPpPOcRiVam5XZixVOaYnMfD+/78wAHZOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZzkIVcEKvuILEEQAArQAAAACTIAAyKvgVC+YDUAACgADAAABCrgFVXJYgAAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJb5kAC4IRckmAAAAABqAABVkXIKp5lgzMAABAAA0AAAAAJRcFihZpJSUgAhAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSFVXJLvIqWEgABWgAAAAAAAZkCrgEL5ghAADQAAkgADIAR5AQ4gL4g3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACW+4sU8i3mZkSACAAAsAADQnmWKlkXIZkAAQAAayAAKAAAWaVJaJSVjsN2euxeyWtek7SGo9ZbO6Hv12qZ7mk9fc9PUlVUSo2vna1HSSRq52GtRqZXwRET2HHk7fdmf9Rron7Yuv+Y1Bw3Oy0d2VvnYemr63nbP8EqD9EPnYemr63nbP8EqD9Ea3dqvuFr7bvafR1x2/1xqDTNXVaidBPPZrnNRSSx+jSLwc6JzVc3KIuF8MohzI+ee6lfrhtzPwtr/0pimmaozluZiHWfq/6fthdM9Mm41/03sjoG1XOhskstLW0OmqKCeB6K3DmSMjRzV+VFRTiYe+vfUDv1qa01Vg1Jvdr662yujWKqoq7UtbPBOxfNr43yK1yfIqKh4E5aaZpjlmZy7kdMvTv0/3/p12zvd92M2+uNxr9KWupq6yr0zRTT1Er6Ziukke6JXPcqqqqqqqqqmlfaw7bbd7c6q27p9vdA6c0vFW2+4PqY7NaoKJs7myRI1XpE1qOVEVcKucZU6LdJ/1MW1H3HWj81jNDO2T/dhtl/Vly/xYTion3mp7OdB2c6FdhdjNXdKOgNR6s2X0JertW01W6pr7jpyjqaiZUrZ2or5JI1c7DWtRMr5Iiew4xndbs9PqONt/tSt/P6g3c7JT3ak9rDtTtdtzpTbyp29220tpiWtuFeypks1np6J07WxxK1HrExquRFVcIucZU1b6D9Nac1h1Y6B05q2wW292msnrkqaC40sdTTzI2gqHNR8ciK12HNa5Mp4KiL7Dc3tk/wBx22X9Z3L/AAoTUTs7fqytuPti4f5dUin8BPd2G+dh6avreds/wSoP0QXpg6alTHzvO2f4JUH6IyYcG92OpXqLs27ms6K179bh0tLRaiuMNPTx6mrUhijZUyI1jWd5xRqIiIjcYREwcdMTU1MxDrdq7oa6TtZ0klJcdkNO0KvRUSW0QrbpGL7FRadWeXuVFT3opzF66OiGfpbuNv1VpG6Vd20Nfah1LTy1eFqaCq4q9KeVzURr0c1r3MeiJlGPRURWorugHZtb3bkb47E1923OuMl1uNjvs1qgucsaNkqoEghkRJFaiI57VlVFd5qnHOVyq/P2pTrY3pGvCV6sSd14tqUXLGVm77K4+Xukl+9ktMzTVhJiJjLiubMdGnRPqvqovc92rqyaxaGtMyRXG7NjR0tRLhFWmpkd8VZOKornLlrEciqjlVGrrjabXXXu60dltkCzVlfUR0tPGnm+V7ka1v31VEP0QbLbWWLZTa3Tm2OnYmNpbFQsgkla3C1E6pymnd/KkkV71/5jkrq6Y4ZpjLyu1fSL067OUEFLo3a2yrVQtRHXK40za2ukd7XLNKjnNyvjhnFvuRDLDrfQOpvQ3UNOsGMd0sTeGPdxxg0B7TXrF1ftdV0Gxm1N7mtF3uFElwvl1pX8aingeqtip4Xp4xvdxc9zkw5G93xVOSnLuLVuq4Lx8IodTXaO6o/vPTm1siVHPOeXeI7lnPjnJxxRNXMtTVjh3f3a6NenDeagnp9VbY2mjrpWrwu1ogZQ10bl8nd5Gid4qexJEe35Dkf1f9HWsulXVECVFU69aQvEjktF6bFwy5EytPO1PBkyJ4+C4eiK5vk5rd8OzP6v9Vb1W+67Q7o3Z901Lp6kbX265zLmeuoUcjHtmX9/JG58fx/NzX/GyrVc7Z/qS2dte/GyuqNtbhTRyVFwonyWyV6Jmnr40V1PIi+zEiIi4xlrnJ5KoiZonEkxExl+es7kdMvTv0/3/p12zvd92M2+uNxr9KWupq6yr0zRTT1Er6Ziukke6JXPcqqqqqqqqqnDmSOSGR0UrHMexytc1yYVqp5oqH6COk/6mLaj7jrR+axmrnZKe76vnYemr63nbP8ABKg/RHy3DpP6YrnC6Cp6fdvWNcitVafTtLA77zo2NVPsoppr2sO626O3Oqtu6fb3cjVOl4q233B9THZrxUUTZ3NkiRqvSJ7UcqIq4Vc4ypqhsX10dR23G4FmuN23R1JqqzSVsMdytd8uEteyop3PRHtY6ZXOjfhVVrmqmFRM5TKLmKZmM5WZiJbv9RHZVbV6tstXethll0jqOFjpIbbNUyT22scif7Ne8V0kDlXycjlan8D2pydvtju+mL3X6c1Bb5qC52upko6ylmbxkgmjcrXscnvRyKh+lI4qdqJpa3ab6tLvWW6FkXr+00F0qGsTCd8rFhcuPevcI5feqqvtNW6pmcSlUN0ez12L2S1r0naQ1HrLZ3Q9+u1TPc0nr7np6kqqiVG187Wo6SSNXOw1qNTK+CIiew2O+dh6avreds/wSoP0Rinsz/qNdE/bF1/zGoPCdqvuFr7bvafR1x2/1xqDTNXVaidBPPZrnNRSSx+jSLwc6JzVc3KIuF8MohiczVhe0NkfnYemr63nbP8ABKg/RGHur/p+2F0z0ybjX/TeyOgbVc6GySy0tbQ6aooJ4HorcOZIyNHNX5UVFOTHzz3Ur9cNuZ+Ftf8ApT4b31A79amtNVYNSb3a+utsro1iqqKu1LWzwTsXza+N8itcnyKiobiiYnunVDwIAOVkOgPZM7Z7b7j3Lc6PcPb7TWqG0EFoWkberTBWpTq91XzWPvmO4cuLc4xnimfJDn8dJuxm/bTdn7Xsv5VYYr/Csd293zsPTV9bztn+CVB+iKv6XummRisd09baoi/wdKUCL/ekWT5erC9XnTnTXuRfdPXattdyodO1c9LWUU74J4JEZ4PZIxUc1yexUVFOJVD1V9Tdvqo6yDqD3FfJE5HNSfUtZMxV+VkkitcnyKiocVNM1ebUzEOvO5HZ39KW4tBNAzbaDTFa9FSKv09ItG+JfekSZhd/ajX7xyj6selPWXSrrqHT17q23ax3Zj57LeY4ljbVRtVEex7MrwlZybyblUw5qoqovh1m6DN+dV9Q3T9R6w1z3ct+ttxqLNXVUcSRtrHRNje2bg1Ea1VZKxHI3CcmuVERFwngu1Y0tbr30rzX2qhYtXp2+UNXSyY+MneOWB7UX3KkuVT3tRfYWmqYnEkxExlpJ2XmhtFbgdRV0smvNH2TUluj0pWVLKO72+GsgbK2ppUbIjJWuajkRzkRcZw5fedVvnYemr63nbP8EqD9EcxeyN+qdu/3HV351RnXDVs01NpW81FPK+KWK31L45GOVrmOSNyoqKniiovtFyZ6ins8Q7pf6aXIrV6edtML7tJ0Cf8A8R4bXfQD0m69opaap2jttlne1Ujq7E51vkhX+E1sapGq/I9jk+Q48UXVV1NUFSyqg6g9xXPjVHIk2pqyZi/ZY+RWr9hUOznRRunrLebpq0huBr9yS3ytZVU9TVJEkaVfcVMkLZuLUREVzY0zhETkjlRETwRVTNPOSJiXI/rH6Tr50p7g01kdcn3fTN9ikqbHc3sRkkjGORJIZUTw72PkzKt8HI9jkxlWtwAdXO2LdbE2o0CyVWesV1DMtOi45dylM7vcfJyWHP3jlGctE5jLMxiX6C7Z0ydNsltpJJOnvbRznQRq5y6ToFVV4p4r+xHKbtNdFaN0F1KNsWhdJWbTlt+DtDP6HaaCKjg7xz5uT+7ia1vJcJlcZXCHaS0/tXR/a8f5KHHTtYfqqWfcxb/y5jitzy1PZvD0c6C6bN8unXR+uKzYXbSouzaT1beHO0pQK9a6n/Y5Hv8A2Lzk4tl+xIhrJ2q/Tbo3b6i0Zuptpoizactcz5bFdaaz2+Kjg75eU1PKscTWt5ORJ2q5UzhkaZ8j/bsgd4PV2qNW7H3KqxBeIG3+1sc7CJUxYjqGp73PjWJ32IFN7erLaNN7+nzWe38FMk1xqbe6rtaY+N6dAqSwIi+zk9iMVf4L3DPTUd4fn7PbbJ7a128O7Wk9srfzR+obpDSSyMTKwwZ5TS/2Imvf/ZPFKitVWuRUVPBUX2HQTshtovXe4uqN5rjS8qbTNElptz3J4LWVPjI5q+9kLVavyVCHLVOIyxEZl0Mh6XOmiCGOBnT1tsrY2oxFfpWhe5URMeLliVVX5VXKnGTrb1BoO9dSOq6DbPSdg0/pzTsyWOlp7LboaOCV9Pls8qtha1rnOmWXD8ZViMTOEQ7OdTO7UOx+xWsdyllYyrtduey3I7x510qpFTpj2p3r2Kv8lFX2H58JppqmaSoqJXyyyuV73vcquc5Vyqqq+aqpx2/Vqpt92ZGwdk3l3vrr/rPTtDedMaOtrqipo6+lZUUtRV1COip45I3orXJjvpEyi+MTTqn87D01fW87Z/glQfojDXZm7P8AzMOma2X6vpe6u2up3X+oVyfGSmciMpW59rViakifLM4yprLqG0/o/qM0JsBV90tZrK03CvWRzsOgkiwtMnuxIkVYnj++YxE88GapmZ4WIxDRbtVOmnRmhLJo/djbHQ9l05bmzyWO701mt0VHAr3ostPM6OJrW8vizMV6plf2NM+CIasdEGndP6s6qdvtO6qsVvvNqra6dlTQ3ClZUU87UpZnIj43orXIioi+KeaIp2f6mdpYd8NitY7arEx9XdLc99uV3hwrolSWnXPsTvWMRf5KqntOAFlvmptFX6G9advFzsN6tsju5q6KokpaqmkwrXcXsVHsXCuRcKi+KoclE5pwlXEv0A/Ow9NX1vO2f4JUH6IfOw9NX1vO2f4JUH6I4b/PPdSv1w25n4W1/wClOivZNbmbkbj2rcyTcPcDUuqH0FRaW0jr1dp61adHtquaRrM93DlxbnGM8Uz5GKqJpjOViYltn87D01fW87Z/glQfoh87D01fW87Z/glQfojz3WtqC/6V6WtwtQ6Xvlws91oraySmrqCpfT1EDu/iTkyRio5q4VUyi+SqcWPnnupX64bcz8La/wDSimmaozkmYhtx2s+2W223FZte3bzb3TWl23CK8rVpZbTT0SVCsWj4d53LG8+PN2M5xyXHmpuJ0y9O/T/f+nXbO933Yzb643Gv0pa6mrrKvTNFNPUSvpmK6SR7olc9yqqqqqqqqqcXNZ7m7k7jupHbh7hal1Q63pIlIt6u1RWrTo/jz7vvnu4cuDc4xnimfJDvL0n/AFMW1H3HWj81jLXE00xCRzL6vnYemr63nbP8EqD9EPnYemr63nbP8EqD9EaV9rDutujtzqrbun293I1TpeKtt9wfUx2a8VFE2dzZIkar0ie1HKiKuFXOMqaF/PPdSv1w25n4W1/6UkUTMZyszEOkvaR7I7MaF6X7lqDRO0WitPXSO72+NlbarBSUlQ1jpMOakkUbXIip5pnxORx7XVW928+urQ/T+tt3da6htcj2yPorrf6urp3PauWuWOWRzVVF8lx4HijlpjEYlx1TlDvIqWcVNwQAAqgAAAAIAAMhVfMsVCwAANAADMgACBDvIkoq5LAAA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFk8ipLV9hJFgAZAAAAAGoAi4AAsCEXBIZAAAAAbAAAAAF0XJ2+7M/6jXRP2xdf8xqDh8dwOzO8ejTRP2xdf8xqDhuxwtEctg9Y7e6B3EooLduBofT+pqSll7+CC82yGtjikwqc2tla5GuwqplPHCqeT+dh6avreds/wSoP0Rrd2q+4Wvtu9p9HXHb/XGoNM1dVqJ0E89muc1FJLH6NIvBzonNVzcoi4XwyiHMj557qV+uG3M/C2v/SmKaJmM5WaoicOkPaUbJ7M6E6Yq2/6I2j0Xp66MvVBE2ttVgpKSdGOc7k1JIo2uwvtTPickj2mqt7N5td2l1g1vu5rTUNrfI2V1Fdb/V1cCvb9K5Y5ZHNynsXHgeLOWmMRiWZnL9BXSf8AUxbUfcdaPzWM0M7ZP92G2X9WXL/FhN5OjW7U166Vtraylej2R6ZoqRVT+HAzuXp950bk+8aYdspp+u9I2v1UyFzqNGXS3yyInhHLmnkYir73J3mP+RTio/E3P4XNM7rdnp9Rxtv9qVv5/UHCk719DWn67THSXtna7jC6KZ9m9O4OTCoyplkqGf3tlav3zV3slPdq72yf7jtsv6zuX+FCaidnb9WVtx9sXD/Lqk2s7Za7U7bXtZYkeizyVF2q3NRfFrGtpmoq/ZVy4/5VNU+zt+rK24+2Lh/l1SKfwE/id0jXa7dnx0gXy+1upbttAypuNxqpa2qlffbniSaR6ve5WJUcUy5VXCJjx8sGxJxu1j2j/VloXeDU1ug15QXSz2fUFdSQWyuslGkKwRVD2sjc+KNkqpxaiZ55+XJx0xM9mpmI7us1n03o/ZrQTrToTRPodms0D5YLRY6NHSSL5uSONFRZJHLlVVVy5V8VVTjn11dY+pupPVEOkIdN1+l9K6Wq5e5tNwbwrZaxMsdNVM8mSNTkxI0zw5Pyqq7w619OW+mneovaWz7n6fi9GWsR1PcKFX83UNbHhJYVX2oiqjmrhMscxcJnBpL2sXTVROtlF1J6StjYqqCWK26oSFmEljdhtNVux++a7ELl81R8X8E1RxVylXMcNF+lijp6/qX2rpapEdE/WNoVzV8nYq41wv2cYP0HH5xNstWroDcjSmu2tc5dOXuhu3Fvm7uJ2S4+/wAD9GdvuFFdqCmultqY6mkrIWVFPNGuWyRvajmuRfaioqKn2S3fIpcM+0Or6u4dY24r6tzlWGpoqeNF/exsoadrcfJhM/fNczdftWdo7to/qDbudHRPWza5oYJG1DW/EbW00TYJYl9zu7ZC/wCXmuM4U0oOSntDE921XZi3Cro+sTSlPTuckddQ3SnnRPJY0opZERfk5xs+/g7bHJTskNo7rft37zvBU0b22bS1uloKeoc34slfU4Tg1fbxh7xXY8u8Zn6ZDqxqfUVq0hpu66svlQkFustFPcKuVV8GQxMV73fea1Tiuc1N09n55d6aOnt28eu7fSIiQUuprpDEieSMbVSIn/ZDuv0n/UxbUfcdaPzWM4DajvdTqXUN01HWIiVF1rZ62VEXOHyvV7v+7lO/PSf9TFtR9x1o/NYzVztCU92Mesrog+e3vGmLt8074KfBymqafu/Uvp3f969js57+Ljjh5YXOfYYz2V7JzbzbfW9s1nrrcmt1mlnqY6ylt7LU2gpnzMcjmLMneyukajkReKK1FwiLlMouTOsrrf8AnSLxpi0/Mx+Ffwjpqmo7z116D3HdPY3GO4l5Z5+eUxj2mtNw7Zm6SQObaunqlp5lReL6jVDpmovvVraVir/eZjrmOFnGeXTaoqIKSCSqqp44YYWOkkkkcjWsaiZVyqvgiIniqqcGetveW176dSGqdaadqEnscD4rVapk8pqenYjO9T+S9/eSJ/Jeh/a6gOvrqB6g7ZPpm83ik07pqo+LNaLHG6GOpb/Bnkc50kie9quRi+fHwTGt5uijp5lJnLt92Z/1Guifti6/5jUGwWsdvdA7iUUFu3A0Pp/U1JSy9/BBebZDWxxSYVObWytcjXYVUynjhVNfezP+o10T9sXX/Mag8J2q+4Wvtu9p9HXHb/XGoNM1dVqJ0E89muc1FJLH6NIvBzonNVzcoi4XwyiHFMZqw12hsj87D01fW87Z/glQfojVjtKNk9mdCdMVbf8ARG0ei9PXRl6oIm1tqsFJSToxzncmpJFG12F9qZ8Tm98891K/XDbmfhbX/pT+PqrezebXdpdYNb7ua01Da3yNldRXW/1dXAr2/SuWOWRzcp7Fx4HJFExOcszVDxYAOVkOk3Yzftpuz9r2X8qsObJ0m7Gb9tN2ftey/lVhiv8ACsd3QjeXbv5re1WqdsvXHqr4S2ya3em+j9/6P3jcc+75N5493JPsmhFD2MtDHVRvuXUTPPTI5O8jg0qkT3J7ketW9EX5eKm++8u4nzJNqtU7m+p/Wvwatk1x9C9I7j0ju254d5xdwz7+K/YOf7+2derVSPpwa13sV2r8on3vQkOKnqx7rc482/OyuzeithdurZtnoKmmjtltR7llqHo+epmevKSaVyIiK9y+5ERERERERERNLu1x3tsdu2/suxFsr45r3eK6K73OFjkVaaihR3do9PYskqtc35Ine9FMI7kdrhvnqigmtugNJaf0akyK30zLrhVx+H7x0iNiRfsxKaUah1FftW3us1Jqi81l2utwlWaqrayZ0s0z1/fOe5VVV/8A6N00TnMszVxiG5PZG/VO3f7jq786ozsBW0dNcKOe31kfeQVMToZWZVOTHIqOTKeKeCr5HH/sjfqnbv8AcdXfnVGddNT1lTb9N3a4Ucndz01DPNE/CLxe2NytXC+C+KJ5mLn4lp7MAUXZz9GVBUsqoNloHPjVHIk17uczFX5WPqFaqfIqGX9U3qx7K7by3CxaEudbadO0iMprJpi2tlmbCxPBkMDVamERPJMYORmg+1F6rNNaipLjq/VFv1famSN9Kt1XaaSl72PPxkZLTRRuY/GcOXkiLjLVTwOwG2u4Wm919BWLcbSNUs9p1BRsrKZzsI5mfB0b0TyexyOY5PY5qoKomO6xMT2cNurjqm1T1Ubhx6kutv8AVFks8b6Sy2lJOfosTnIr3yOwnKV6tbyVERMNY1Ppcrg03u7U/pqott9fUG9mj7Y2msetJnw3WKFnGOnuyIrlfhPBO/Yjn4/hxyqv0xoic1OJjhxz3fpWtP7V0f2vH+Shx07WH6qln3MW/wDLmOxdp/auj+14/wAlDjp2sP1VLPuYt/5cxxW+7dXZrlsJujWbLbyaR3Po1fiw3OKepYz6aWld8SojT/mhfI3+0foboK+julDTXO3VMdRSVcLJ4Jo1y2SN6I5rkX2oqKin5pjtv2a+8HzU+mOzWqvqu9u2iJXadqkcvxlhjRHUrse7uXMZn2rE41cjzSmfJzG66tovmNdTer7BSUvc2q71Hr61oiYb6NVKr1a1P4LJe9jT+jOsPQftF8xzpi0jZaul7m63uBdQXRFTDu/qkR7WuT2OZCkMa/LGeO60uktOoXcLaDUdLQpLFa78lu1GqJ9NZ1Rah6uX2IiwPjb/ACqlPM2vVYqeJXOVkcUbcqq4RrWon/ZEQxVVmIhYjEua3bBbwcINHbF2yq8ZFdqS7Ma796nKGlauPevpDlRf4LF9xoHsftlX7y7uaT2xt/NH6gucNLNIxMrDT55Ty/2ImyP/ALJ/e6p93H747+6x3GjndJQV1wdBbM+SUMKJFT4T2ZjY1yp/Cc73m3PZB7P+t9a6r3tuVLyp7BTJZLY9zfBaudEfO9q+xzIka37FQcv4KWe8upFrtlBZbZSWe1UrKaioII6amhYmGxRMajWNT5ERET7xw36luoy66h6zrrvRpqs72PSl/p4rGqP/AGN1Pb5EazH8iV0b3qn/AOqv2DuLebct3tFdaW19VQrW00tOlVSOa2eDm1W95Grkc1HtzlFVFTKJlF8jSf6EF01L/wDjjcz/AOp0H6kcVExHdqqJns3P0nqa1a00tZ9YWKfvrbfKCnuNJJ/Chmja9i//ACuQ4kdoZs/8yHqf1LHRUvc2jVSpqS34TDcVDnd81PYnGdsyIieTePvOzWz211n2W23sm2Gn7zd7pbLBE+CkqLtLHLU90sjnoxzo2MaqN5cW4amGtanjjJqN2tWz/wALdmLPuxbaXnX6Ir+6q3NTxW31atY5Vx58Zkgx7ke9feKJxUVRmHIo6edjP+0+6/2zZvyas5hnTzsZ/wBp91/tmzfk1Zy1/hZp7tp+vT6kLcz+qo/ziI4OHePr0+pC3M/qqP8AOIjg4S12WruH6Cuk/wCpi2o+460fmsZ+fU/QV0n/AFMW1H3HWj81jJd7FPd63WW1O12401LUbhbb6W1RLRNcymkvNnp610DXKiuRiyscrUVUTKJjOEPOfOw9NX1vO2f4JUH6I0r7WHdbdHbnVW3dPt7uRqnS8Vbb7g+pjs14qKJs7myRI1XpE9qOVEVcKucZU0L+ee6lfrhtzPwtr/0pmmiZjOSaoicN3u1c2m2r260BoSt2+200ppiorLxUxVEtms1NRPmYkCKjXuiY1XIi+OFOavkeq1lu1unuJTU9FuDuXqvU9PRvWWnivN5qa1kL1TCuY2V7kaqp4ZQ8mq5OamnEcsTzORVyQAbUAAAAAAAGAAhV9iAFX2EABoAAJAAGQAAQvkVJcvsINQAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACyLkkp5FkXJmYEgAgAALE4AAGglFwQAiwIapIZAAFiQABoAAA7gdmb9Rpon7Yu3+Y1Bw/M4bZ9a/U3s7oyh2+243M9UWC3OldTUnqa31HdrLI6R/x5oHvXL3uXxcuM4TCeBi5TNUYhYnDtpvFsNtPv9ZqHT+7elPXtvttUtZSw+nVNL3c3BWcuVPIxy/FcqYVVTx8jE30Nvos/iY/GK7frRzN+iS9an8c/4u2n9VH0SbrT/jn/ABdtP6qcfs647SuYdAt5Oz66Q9KbQ641RYNo/RbnZ9N3Ovop/X90f3U8VLI+N/F9SrXYc1Fw5FRceKKhxnNiNQ9oN1ear0/c9L37dz0q2XijmoK2D1Ba2d7BKxWSM5Mpkc3LXKmWqipnwVFNdzVMTHdiqY8nUHsp+p/T6aak6bdY3WKjuVLVS1mmHTvRraqKVyvmpWqvh3jZFfI1vm5JHY+k8d7d2toNvt8NF1OgdyrBHdbRUvbMjFe6OSCZueEsUjVRzHplfFF8UVUXKKqL+dSGaWnlZPBK+OWNyPY9jlRzXIuUVFTyVFNmdt+0d6rtuKCG0s11BqWip2o2KLUNI2re1E986K2Z39qRTNVHOYaivyl0A0r2VXSxprUMN+q2asv8UEqSttt1ucTqRVRcojmxQxvc3+S56ovkuU8DbetrbNpuzzXC4VVHa7XbadZJZpXthgpoGN8Vcq4axjWp8iIiHIer7XPqcqKdYYdNbeUr1THfRWurV6fLh9U5v/YwDvL1Zb/79wrQbk7h1tZa+aPbaqVjKSiRUXLVdFEjUkVF8nP5KnvJ0VT3a6ojs9b129RdF1H76Vd/05K9+l7DTts9kc5qt7+JjnOfUcV8U7yRzlTOF4JGioioqH+nZ2/VlbcfbFw/y6pNcT0e3W4msdp9Z23cHQF49VX+0OkdR1fo8U/dK+N0bviStcx2WPcni1fPPnhTkxxiGM85fo9Pzpb1/wC+XXn3T3T86kMy/RJOtP8Ajn/F20/qprpe7zctRXmv1Bean0i4XOqlrKqbg1neTSPV73cWojUy5yrhERE9iGaKJp7rVOW7fZS79/APdqt2bvtbws2umI+h5uw2K6QtVWY9id7HyYvtVzIkOrOv9EWHcrRN80Dqem7+1X+gmoKpnhlGSNVvJq+xzVVHNX2KiL7D85dkvV105eaDUNjrpaK5WupirKOpiXD4Z43I9j2/KjkRU+wbF/RJOtP+Of8AF20/qpKqJmcwsVYYR3T26v20m4uodtdTR8bjp6vlopXI1UbK1q/Elai/vXsVr2/yXIdJOzb629P3LS9s6eN1r3Fb7xamtpNNXGrkRsVdTeUdG56+DZWfSx58Ht4tT4zU5c4d1d29wN7NWv11uZe4rvfJYI6aSrZQU9KskcaKjOTYI2NcqIuOSpnCImcIiJ483NPVGJSJx2fo43J2w0Fu/pOq0RuPpmkvlmq1Rz6eoRUVj0zxkje1UdG9Mrh7VRyZXx8VNWIuya6WY7x6zfV63lpufL1c+7xej4z9LlIUlx7P9pn5TnltX17dUe0dDDZrHuRNdbVTtRsVDfIW17GNTya17/2VjUTwRrXoiJ7DLLu116m1p+4TS+3TX4x3yWus5/Zx6Xx/7HH0VR2XMS6x6D0Boza/StForQGnaOyWS3NVtPSUrcNblcuc5Vy57lXxVzlVyr4qqqc7+0p62tP3axVnTrtJe4rj6VIjNUXWkkR0LGMci+hRPTwe5XIiyORcIjeHirno3Undrrl6m95qCey6p3IqaOz1LVZLbbPEyhgkYvmx6xokkjV9rXvcnyGBS028TmSavQP0FdJ/1MW1H3HWj81jPz6mwWk+vvq10Npi06N0tux6FZ7HRw2+gpvUVsk7mniYjI2c307nuw1ETLlVV9qqarpmrskThsr2yf7sNsv6suX+LCc6DI28vUNvD1A1lsuG7ur/AF9PZopIaJ/q+lpe6ZIrVemKeNiOyrW/TZ8vAxyWmMRgmcyAA0jt92Z/1Guifti6/wCY1BmPeLYbaff6zUOn929Kevbfbapaylh9OqaXu5uCs5cqeRjl+K5Uwqqnj5HE3bPrW6mtndGUO323O5fqiwW50rqak9TW+o7tZZHSP+PNA965e9y+LlxnCYTwPU/RJOtP+Of8XbT+qnDNuc5hrqjDph9Db6LP4mPxiu360eP3k7PrpD0ptDrjVFg2j9Fudn03c6+in9f3R/dTxUsj438X1KtdhzUXDkVFx4oqHP8A+iSdaf8AHP8Ai7af1U/n6h7QXq81XYLnpe/7uelWy8Uc1BWweoLWzvYJWKyRnJlMjm5a5Uy1UVM+Copemr1Mw13ABysh0m7Gb9tN2ftey/lVhzZMk7M9Ru83T5Ldp9odZeoH3xsDa9fV1JVd8kKvWP8A94ifxx3j/pcZz45whmqMxgjiXbLrK+pW3T+5it/IOAhn/WXXp1Ybg6VuuidX7ren2W9Ur6OupfUVti76F6Yc3nHTte3Ke1qovymACUUzTHKzOQAG0btdkb9U7d/uOrvzqjOtus/3H33+rKr/AAnH57to96dy9idTzay2q1L6jvE9G+3yVPodPU8qd72PczhOx7Ey6Ni5xnw8/FTLlb2jHWVcKOe31m8XeQVMToZWfB61JyY5FRyZSmyngq+RxVUTM5aicNbTpp2Rm/fOG/dO9/rfGPnfdPo9371VRKqBufl4So1PfMpzLPQaB19q/a7V9s17oO9S2m/WeVZqOsjjY9Y3K1WO+K9HMcitc5qtcioqKqKhuqOqMMxOHfTqS2Ztu/2y+ptsK5ImVFypFkt0708Kauj+PTyZ80RHoiOx5tc5Pafn2u9puNhutbY7xRyUlfbqiSkqqeVMPhmjcrXscnsVHIqL9g2N+iSdaf8AHP8Ai7af1UwJrnW+pdyNW3TXWsq+Ktvd5nWprqmOlhpkmlVERX93C1jEVcZVUamVyq5VVUzRTNPdZnL9HNp/auj+14/yUOOnaw/VUs+5i3/lzHiYu0f6z4ImQRby8WRtRrU+DtqXCImE/wDuph3djeLcbfHVSa23R1F66vSUsdH6V6JBTfsLFcrW8IGMZ4K53jjPj5koommcyszmHjDdfspt4PgLv9Vbc3Cq7u26+oVpmNc7DUr6dHSwKv2WLOxPe57TSg/p6Z1JfNG6jterdM3B9Bd7NWQ19DVMRFdDPE9HseiORUXDkRcKiovkqKhyTGYwzHD9Jprn1/7wfMd6YtUV9HVdzdtSMTTlsVHYd3tS1ySOavmitgbM5F97WnMP6JJ1p/xz/i7af1UxzvL1Pb6dQNHbLfu7ruS/U1mllmookt9JSNjfIjUc5Up4o+a4aiJyzjxxjK54otzE8tzUxad7+irZ/wCYl026P0lVUvcXWspfXF2RW4f6ZU4kcx3yxtVkX/wkOC9DWT26tp7hSrGk1LKyaPvI2yN5NVFTLHIrXJlPJUVF8lRTZH6JJ1p/xz/i7af1U3XTNXEMxOG+nXr12au6YNVaa0RtpZ9OXS73ChluV0S8wTzNggV/CnRiQzRqjnKyZVyq+DW+Hiar/RfupX/gfbP/AOmV/wCumou526Wvd5dY1evtytQPvN9rWRRzVToIoUVkbEYxrY4mtY1Ea1PBrUyuVXKqqr5URRERyTVLqX0h9pZuRvVvjZ9r91NO6Pttuv8ADPBRVNppamGVta1nONrnS1EjVa5GPZhGoquczx80XfPcXRFo3L0FqHb6/MzQaittRbZ1xlWNlYrebf5TVVHIvsVEPzpac1DedJagtmqtOV76G62erhr6GpYiK6GeJ6PjeiKioqo5qLhUVPDxNh/oknWn/HP+Ltp/VTNVvnhYq9Wv2r9L3fRGq7zo2/wdxc7FXz26sj/gzQyKx6J8mWqdJexn/afdf7Zs35NWc49f691XuhrC5691xco7hfbxI2atqmUsNMkr0Y1vLu4WMYi4amcNTK5Vcqqqvr9mepje7p8hu1PtDrX1BHfHQvr09W0lV3yxI9I1/wDERP447x/0uM58c4Q3VEzGEicS7Kden1IW5n9VR/nERwcM86966Oqfc7SFz0HrjdL1lYrxEkFbSepLdD3rEcjkTnFTte3xai/FcnkYGJRTNMYlKqokP0FdJ/1MW1H3HWj81jPz6mwWk+vvq00Npe06N0vux6FZ7HRw2+gpvUVsk7mniYjI2c307nuw1ETLlVV9qqK6Zq7FNWJ5djN5emHY3qBrLZcN3dD+vp7NFJDRP9Z1lL3TJFar0xTysR2Va36bPl4GOfobfRZ/Ex+MV2/WjmavaTdafs3n/F20/qo+iS9an8c/4u2n9VM+zr9WsxPk3I6zOh3pc2o6aNbbg6A2w9V3+0QUj6Or9d3GfulfWQRuXhLO5jsse5PFq+efPCnJ4ztuJ1xdUe6+jblt9r/c/wBaWC7tjZWUnqS3Qd6jJGyNTnFA17cPY1fByeWPLKGCTloiYjlJx5AANIAAAAAzMgAVfAIhV9hAAaAAFAAGZnIAAgQq4HkVVcliA8wAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFwQALghPIkwAAAAALEgADR5FkXJUBJhYBFyAyAALEgACgACgAAEo73kAIuChbl7yYTCQM5BE7AAC5AAFAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAMgACZyAjl7iM5LgwlXe4qAVQABQAAAAEAAEmQAKuAgq4KquQq5AaiAABQABmZAAEACAIVfYQAbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKLgsUJRfYSYFgAZAAAAAFiQABoJRSAEWBCKSGQAAAAGonIAAoAAAAAEo5SAEWyiklCcqTCYWN3emjoh2o3l2bsm4ep9QaspblcpKtksVBV0zIGpFUSRt4o+B7k+KxFXLl8c+XkaQ8vedY+g1c9L2lP6a4/nsx+f/aPues2naaL+iuTRVNyIzHp01Tj9Id3sOmtanUzRepzHTP84eL+hobE/wDFmvP+vo/1U/wquzN2VfGqUWs9bRSex0tTSSIn3kp2/wDqel66d4Nxtm9B6dvW2+ovVFZXXdaWol9EgqOcXcvdxxMx6J4oi5REU1f2g68d+2bg2Og1tqCm1HZ7hXwUdVTyW2mgkbHI9GK+N0DGLzTOURcouMY8cnhdqt+Mt327/E9LrPd54mfenp78dOPlmXcamratLf8Au9y1zxzjjn65/R/a3a7OHWulbVU37bTVDNUx0zFlfbZqb0esVqeaRKjnMld7cfEVfJEVcIunb2Pje6ORjmPYqtc1yYVFTzRUO8JyC6x7BbtNdS2ubbaomR08lZDWqxnkklRTRTyfY+PI5fvno/s88Ya7fL1zQa+Yqqpp6oqxETiJiJicYjzjHHrnL4d82uzo6Kb1niJnEx/fyf7dI+yWld+9zqvResLhdqOhp7NPcGyW2WOOVZGSwsRFWSN6ccSO9mconiba3rs3NjrdZ6+4Qaq106SlppZmI+uo1armsVUzil8vAwX2bP8Av9uX3MVf5xTHSLVP7mLv9oVH+G46Tx54i3Xbd8jTaS/VRR008R257vs2bQ6bUaP2lyiJnMuGAAP3F5AAP6mltOXPWGprVpSzRd5XXithoaZvsWSR6Mbn5Mr4r7jFddNuma65xEcysRNU4ht70udDmi94NqqfcLcO86koJ7nVzpQQ2yeCJi0saoxHuSWF6q5ZGyeSonFG+8y79DQ2J/4s15/19H+qmzmjdLWzRGk7Po6zs40VloYaGDwwqtjYjUcvyrjKr71U/wA9Ia10/rmhrbhp2sSoht9yq7TUKn72op5XRyJ9jLeSL7WuavtP5m3Dxtvmq1N7U6a/VTa6uIjtTEzPTHb0h7+xtGjt26bdyiJqx+fq4tbh6MuO3eub7oa65WpslfNROeqY7xGOVGyJ8jm4cnyOQ88bi9pNtn6i3Fs25tDT8abU1J6JWOanh6XToiIqr/KiWNE/onGnR/QXh7dI3nbLOtjvVTz/ABRxV+sS8TrtPOk1Fdn0n9PL9Eo1XKjWoqqq4RE9pt1sb2emtNeW+m1NufdpNJ2yoakkNAyFH3CVi+SuR3xYMp5cuTve1D6ezy2It2ttTV+7eqKFlTbtMTsp7XDI3kyS4K1HrIqL4L3TVYqJ/Ckav706G6j1FZtJWG4an1FXx0VstdO+qqqiRfixxtTKr71X3Iniq4RPFT888ceOtVoNV/hW08XIx1VYzOZ7U0xzGfWeeeIxMO82jZ7d63951P4fKP3lgOy9n9002qBsNdpm63h7Uwstbd52ud8q9w6Nv9yH+OoOz46b7xTuitllvNikVF4y0N1lkVF+xUd4i/3Gt26naN7nXu8VFPtVQ0WnLPG9W089TTMqa2ZqL4PfzzGzKYXijVx/CU8rpvtB+o6y1bJ7vebPqCFFTlDXWuKJFT24WnSNUX+/7B1tnw145uURqZ1c01d+mblWfyxNP6vor1+z0z7P2WY9emP/AOv5vVN0m1fToltvFJq2K9Wa8VD6en7yBYamJ7W8sPRMtcmP3yKnj+9Q/k9I+yWld+9zqvResLhdqOhp7NPcGyW2WOOVZGSwsRFWSN6ccSO9mconiey6ouqrTnUXtvpiihsVVZb/AGm5STVtI93ewOY6Lij4pURMpnza5EVM+3zPv7Nn/f7cvuYq/wA4pj2NWs3jTeFb1/cJmnU0RVzxE8TxPHHbzju6qLWlublTRY5tzMfy+PLOl67NzY63WevuEGqtdOkpaaWZiPrqNWq5rFVM4pfLwObx3P1T+5i7/aFR/huOYvST0jXXe+5R6w1hDUUGh6KX4z0yyS6SNXxhiXzRiL4PkTy8Wt+NlW+a8DeLbsaLV6zer81U2+jGe/PVxEeczjs7DeNspm7ataSjE1Z/bu+XpW6Q73v3Vu1HqWats2iqZzo31kKNbPWyp4d3T82q3DV+meqKiY4oirnjspfuzu6cNL2as1DqHX2tbfbbfC6epqZ7lRNjiYnmqr6L/wD6q+CG1FTU6P200g6oqH0Fg05YKRMrhIoKWBiYRERPL2IiJ4qqoiZVTl91XdWF736vLtP6ffUW7RNvmzS0irxkrnp5Tzon/wC1nk1PevifHtu8eIvG251VaK5NjT098eUenxrn8o+Tl1Gl0O06eIu0xXXP6/0hhzcFu38eq62HbBL27TsLu7pJrxNHJUzonnIqRxsaxHeaNwqonmufBN4NqOz72Z11tjpTWl31NrSGuvtmpLhUR01bSNiZJLE17kYjqZyo3KrjKquPapz8Oz3Tn/uC26+5i2/m7D0P2i7nrdj0Gn+43qqZ6sTOeZiI85fDsWns6y9X7amJjGf1c7Osjp00T083jTNv0XdL5Wx3qmqZqhbpPDI5ro3sRvDu4o8J8Zc5z7DXQ3e7UD90+gvtCu/xIjSE9N4M1l/X7Hp9TqapqrqiczPefeqj+Tr91tUWNZXbtxiIx/KA2S6NOmzQ3URVasg1rdb7RNsMdE+m9Vzwxq9ZlmR3PvIpM47puMY818/Zrab09l1+2G4/9Davyqoz411uo2/Yr+p0tU0109OJjvGa6Yn9JXabVF/WUW7kZic/yl/T3k6AtnNvNq9U64supdZT19ktk1bTx1VZSuhc9jcoj0bTtcqfYVF+U0DOyfVB9TzuF/UFV+QcbDofs13bW7tob1zW3JrmK8RM+mIfZv8AprWmvUU2acRMfu2P6ZOjPU+/NJ8Lr5c36f0k2R0UdUkXOornNXDkgavgjUVFRZFymUVERyo7G49k7P8A6abVTNgr9MXS8vb5zVt3nY932UgdG3+5DN+gtLUGiNE2HSFrhbHS2e3QUcaNREzwYiK5ceaqqKqr7VVVNI+qzrX3c0RureduNu3UVjpLE6OF9XLRsqKmokdG16uxKjmNZ8dEaiNyqJnPjhPDxvfiLxtudzT7Xem1RGZiIqmmIpicZmY96ZnMevwiIdx900O06em5qaeqZ+Gefhnhm27dn/00XGNWUel7pa3KmEfSXeocqfL+zOen/Y1n6p+iXSeyOgJ9xdJa0u1VT09XBTLQXGGOR7u8djKTM4ImPdwXPvQ8dZO0A6l7VUNmrtT2u8sRfGKttEDWr9nuGxu/7n9nenrbfvns1Wbe6j0Q213mSrpqllXRVHOlkSN+XIrH/Hj8PL4z/vHpNr2fxntWvszf1HtbPVHX7/V7uefxxE/ly6/UavadTZr6KOmrE44xz9OPzfxejbpy0R1DXTVFDrS63yijslPSy062ueGNXLI6RHc+8ikynxExjHtNovoaGxP/ABZrz/r6P9VNJdh+o3W/TzWXiu0Xa7HWyXuKGKoS6QTSI1I1creHdyx4X465zn2GYfol++3/AAnoP/oKz9aPv8R7Z4u1O5V3NqvdNmcYjqiPKM8Y9cuHQanbLdiKdTRmvnPHxZ5+hobE/wDFmvP+vo/1UfQ0Nif+LNef9fR/qpm/p43Gve7Wzem9w9R0tDTXG8RzvniomPZA1WVEkacUe5zk+KxM5cvjn7BjvrH6itbdPNk01ctF2uyVst5qqiCdLpBNI1rY2MVFb3cseFy5c5yfm+m3nxVqty/wm3qqva9VVPeMZpznnHwl31zS7ba0/wB5qtx04ie3q8p9DQ2J/wCLNef9fR/qpoz1F7b2PaLebUe3em6uuqbbaH0zYJa6Rj53d5TRSu5KxrWr8aRUTDU8MfZM2/RMN9v+E9B/9BWfrRrpupuVfN3de3XcTUlJQ01yu6xOnioY3sgb3cLIm8Wvc5yfFjRVy5fFV+wfqnhLbvE+k1lde9Xeq30zER1RPvZpxPb0y85ud7b7tqI0lOKs+mOMT/2eVCqiFcqQfoWHR4SrvcQAVQABQAAAAAAASQABkAIVfcBKrgqAGsYAAFAAEmQABkAAAqq+wKvsINRAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFLFCUX2EmBYAGQAAAABYkAAaBnAAEouSSpKLkMzCQAEAAFyAANAAAAAAAAB1k6DPqXtKf01x/PZjk2dZOgz6l7Sn9Ncfz2Y/MftY/wCCW/8A1af+mt6Dw3/5ur+Gf5w9tvrsDo7qDsNu09rO53miprZWLWwutc0Ub3P4KzDlkjeiphy+SIufaY9256Cti9uNVUOr6aTUN7rbZM2ppI7tWRPhimauWScIoo+StVEVOSqmUTwPl6694dxtm9B6dvW2+ovVFZXXdaWol9EgqOcXcvdxxMx6J4oi5REU0+091/dS1nukNbdtWUN9pY3oslHWWmliZI32pygjjen2UU8N4d2HxPuWz9W26mKbNXVHR1TE9+e1OOf4nb67WbfY1WL9vNcY5xE/Lz/Z0u3O12/bfRlw1bFpa86hkoo1cygtVOss0i4XxXH0rEx8Z2FwmVwvkcaNwtcXncnW9613f1Z6feqt9VK1meMaL4Njbnx4tajWpnxw1DtLoTVlJrzRVh1tQQPhp79baa4xxPXLo0lja/gq+1U5YX7Bza7Qnayy6A3fpNR6eo46Sk1dRurp4I2o1jaxj+MzmonkjkWNy/ynOX2n3fZdrNPo9xu7fet4vVROKs/6eZpx5ds588fJw+IrNy9Ypv01e5Hl8/N9nZs/7/bl9zFX+cUx0i1T+5i7/aFR/huObfZsKvzfbl9zFX+cUx0k1T+5i7/aFR/huOr+0r/mOP4aP3fR4f40H1lwwBHJBlPef0Xh4PCTa7s6ts/hZvDVa6rafnQ6Oo1ljVUyi1k6OjiT7zEmd8itaaonV/oY2z+Z3sFaa2rp+7uWqnrfKnKfGSORESBufd3TWOx7Fe48N9oe7f4XslyimcV3fcj5T+L/APXMfWHc7FpvvGsiZ7U8/wBP1ZO3q3Ah2s2p1Pr2R7WyWm3yPpkd5OqXfEgav2ZXMT75p32aW5sy3rVu2N0rHSOuDUv9H3jsq6ZqpHUeK+bnI6Ff7DlNhurnZvcnfTQVv0NoC7WO3wrcG1lyfc6iaLvGRtVI4293FJlOTuS5xhWNxnxMA7F9Dm/Wz+7GnNwvhRomWntdX/4yKCuq1fLSyNWOZrUWmRFdwc7iiqickTxTzPy3Yo2ePDOq0+qv0037vMRPeOjmiPrOfpL0etnV/wCIW67dEzRT3+vf9P5NhusXbP5p+weobfTU/e3Kyxpe6BETLu9p0VXtRParollYie9yHIg7xOa17VY9qOa5MKiplFQ4ydRO2rtpd5dT6KjhWOipqx1Rb/DwWkmTvIURfbhrkaq+9qnpfsm3bqovbXXPb36flxFX64n6y6/xNpsTRqKflP8AOP3dHOhGy09o6ZNLzxMRstzlrq2dU/fPWqkYi/8AyRsT7x5PtHtT1tl2KorHRyuY2/3ynpqlEXHOCOOSbiv/AMSOJfvHo+gbUVNfOmmw0MUiOmslXXW+oRF+lf37pmov9iZh/K7Q3RVfqnYL1xboHSv0zdYLnO1qZX0dWPheuPkWVjl9yNVfYeT0802/HEzqv/r1d/4p6f1xh2dzNWz/AOz/ANEfy5/dy6AB/STwOQ2t7Nn/AH+3L7mKv84pjVI2t7Nn/f7cvuYq/wA4pjzPjL/gOq/gl2G1T/vtv5umNTTQ1lNLSVMfOGdjo5G5xya5MKnh8inz2+32vTlngtlpt8VHb7dAkUFNSw4bFExMIxjGp7ETCIiF7pW+rbZWXHuu89Fgkn4Zxy4tVcZ9mcHkdn94NGb26Np9ZaMru8ifiOqpZFRJ6KfGXRStTyVPYvk5MKiqin8t0WL9Viq9TEzbpmImfKJnOM/PE4fo010RXFEz70xw5tdWfVLqTfHUU2mrfFV2fSFpqHNp7dKixzVErFVFmqW/wvPDF8GfKuVNeTpV1i9HFPubBVbm7ZUEcGrYWLJXUMaI1l2aifTJ7EnRPJf3/kvjhTmzUU9RR1EtJVwSQTwPdHLFI1WvY9FwrXIviioqYVFP6a8E7lteu2ui3tlPRFHFVHnE+s+ue/V5/CYmI/Pt3saixqJnUTnPafKY/bHo/wAzs905/wC4Lbr7mLb+bsOMJ2e6c/8AcFt19zFt/N2HlPtb/wDIaf8Ajn/pdj4YnN6v5fu0/wC1A/dPoL7Qrv8AEiNITd7tQP3T6C+0K7/EiNIT1XgH/lzTfKr/AK6nXb3P+/3Pp/KA3p7Lr9sNx/6G1flVRosb09l1+2G4/wDQ2r8qqM/aF/y3qf8A7P8ArpNjn/f7f1/lLarqg+p53C/qCq/IONh2T6oPqedwv6gqvyDjYea+yT/h1/8Aj/8AbDsPE/8A8+j5fu7HdNW81i3p2stF9oK+J92oqaKkvNJyTvKeqa1Ecqt8+L1RXNXyVFx5oqJ9O6XTfs1vJUpcdd6Mgqbk1iRtuFPK+nqeKeSK+NU5onsR/JE9xyE0drrV+3t6j1DonUldZrjGnFJ6SZWK5vta5PJ7V9rXIqL7jZjRnaS7y2NkdPq6wWHUsTMcpVidR1L/ALLo1WNPvRnUbr9nO66DWVazYbuImZmIiqaKoz5RPaY+sfGPN9Wm33TX7UWtbT+mYn4swaw7Mrb+uZJLobcG92iZcq2O4wx1sWfcnBI3Inyqrl+yajb49L+6ewsrKnVduhrLNPJ3UF3t7lkpnP8ANGPyiOjdj2OREXC8VdhToB0+dau3+/F9j0b6lr9O6jmifNBSVEjZ4ahGNVz2xStRFVyNRzlRzG+CKqZwpmnX2jLPuJou86Iv1OyahvNHJSyI5ueCuT4r09zmu4uRfYrUU6/S+NPEXhrXU6Te4mqnjMVRGcT501R3/OYnGHPd2jQ7hZm5pOJ8pjtn0mJ/7OHZGULTwyU08lPKmHxPVjk+VFwp/mf0BERPLxWHXbon+pf0N/QVn57OYS7UH9ymg/6wrf8ADjM29E/1L+hv6Cs/PZzCXag/uU0H/WNb/hxn86bF/wA9z/613/3vdaz/AINH8NP7OewAP6MeGAAAAAAAAAAAAAZyAAIBVwFXBULECqqgANAAAAAMzIAAgAABVV9wVfYQaiAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWRfeSUJRfeSYFgAZAAAAAFiQABoAAEovvJKhFwEmFgEVFAZAAAAAXIAAoAAodZOgz6l7Sn9Ncfz2Y5Nm2WwvXl8xHa607bfMq9deq31L/AE3156N3nezvlx3fo78Y54+mXOM+HkeF+0LZtdvm10abQUddcVxOMxHEU1RnNUxHeYdxsmqs6PUTcvTiMTHnPnHo226xNgNY9QejbHp3Rlys1FU2y5rWzOuk0sbHM7pzMNWON6quXJ5oiY9prDp3syN0ZrpCzVmvdLUdu5p30ludUVM/H28WSRRtz9l3956n6KV/MX+M/wDpCkvakyqxUh2OYx/sV2pFcn9yUqf+p4fatB482bRxodHZimiM45tTMZ586v2dvqb2zaq77a7XMz8qv6N4tL6ctmj9NWrSdljdHb7NRQUFK1y5ckUTEY3K+1cNTK+1Tm/2jm4Vp1Xu9bNJWiqZUJpS3ugrHsdlGVcz+b4/dlrGxZ9yqqL4op8e43aIb2ayoJrTpiltekaadqsdPQtdLWcV80SZ64b9lrGuT2Khq5NNNUzSVFRK+WWVyvkke5XOe5Vyqqq+Kqq+07nwR4G1u066d03OqOvE4piczmrvMz27Z7Z75+fybvvFrU2fu+njjznt28obV9mx/v8Arl9zFX+cUx0uulF6ztlZbu97v0uCSDnxzx5NVM49uMnHrps32+d51/U65+C3r/0i1zW30X070Xjzkifz593JnHdYxx9vn4eOzn0Ur+Yv8Z/9Idb478Jb1vG8fe9BZ6qOmmM9VEcxnyqqif0fRs+56TS6X2V6rE5nyn9oPoWv8+n4sf6sfQtf59PxY/1Y+ilfzF/jP/pB9FK/mL/Gf/SF/wDiV/f3c/8AAP762Arp0yVNm6o7d0709+femyVdGlRXspPRl9GfCyonckfN+FZEr/33jx9mTrXSUtNQ0sNFRwshgp42xRRsTDWMamGtRPYiIiIcurN1mWy2dQ2oOoGq2m9Lq7vbYbdS29b5xSi4xxRvkSX0debnJFj6VuEc5PEyVfO0/uFfZa+htGzyW6uqaWWKmrF1D3qU0rmKjJeHozefFyovHkmcYynmZ8W+H/E3iKdLRVZz0W6eqeq3H+0qiOucRVHbERxGOJxwbbrdv0PtJirvM44n8MdvJl7VXaI7HaT1NddL1Fi1hXTWmsmopKmio6V8Er43qxzo3OqGq5uUXCqiZQ/l/RMdiP8AhPXv/QUf60c0XvdI5XvcrnOXKqq5VV95U9PR9l+w00xFUVTPnPV3dfPiHWTPGPydrtm94dJ75aJh13o1lbFRSVEtK+CtjYyohljXCte1jntRVRWuTDl+K5vkvgmpnaZ7ad5SaY3coKfLoHOsdxc1PHg7lLTuX5EXvkVV/hNQwL0v9W9z6b6C+2d+kPhJb7xNDUxwLcvRPRpmNVr3ovdScubeCKmE/wBmh7/eLr9tm8W21826uuyvosd3gRkdUmou8Wmma5HxSo30VOXF7WqqZTKZTKZPLbf4N3fw94kp1W32pq08Vd+qn8FUc8TVEzNOfTmYy7G/uml12gm3fqxXMek947eXn+7+D0K9RNu2g1tVaO1hXJTaZ1S6Nq1MjsR0VY3wjlcv71jkXg5fZhiqqI1Tp5V0tBdqCahrYIauirYXRSxSNR8c0T24c1UXwc1UVUx5KinCE2B2P6193NmKKDTzpYNTadp0RsVvuTnc6difvYZk+MxPJEa5HNT2NQ7rxv4Bu7xf/wAS2yYi7x1UzOOrHaYnyny54n1ie/ybRvNOlo+76j8PlPp/2Z83U7NOK43iouu0WsqW20lQ9XttV3ZI5lPlc8WTsRzlankiOYqoieLlPK6c7MbcGoq2Jq7cjT1BTZRXrbYZ6uRU9qIkjYkT7OfvGSLJ2nO2E8DXaj271RQzKnxmUT6eqai/I574lX+5D/HUHad7eU9O5dK7bair58LxbcJ4KRmfZlWOlX/sdHZ1X2hWqI0sW5mY46piiZ//ACmcT85y+uu1sdU+0mfpz/JizrK6ctt9gNr9I02jaOomuFddZWV10rJOdRUI2HKN8ERrGovk1qJ7M5XxP5nZsqnzfbl9zFX+cUxjHqA6odweoaejg1PTW632m2yumo7fRRLhj3JhXPkcqve7Hh5o3+Sh8vTZvt87zr+p1z8FvX/pFrmtvovp3ovHnJE/nz7uTOO6xjj7fPw8fZxs+73PC13Q6ufaamuKv80TmZnMRmcRxHHpHk6qdTpadxpvWvdtxMeXpHo696p/cxd/tCo/w3HHDZLe/WWxOsodWaSqucb+Mdwt8rl7iugz4sensVPFWuTxavyKqLtNdO099Z2yst3zEO79Lgkg5/CXPHk1Uzj0Xxxk0WOo8A+FNZtum1em3izEU3emMTNNUTEdWfwzOO8enwfVvW42tRctXNLXzTnnmMdvWHa3Z3ePRm9+jafWOja3nG7EdXSSKiT0U+MuilankvuXycmFTwMA9YvRzT7n09VuXtnQxwavgYslbRMRGsuzETzT2JOiJ4L+/wDJfHCmiGym9ms9itZQ6t0jVcmOxHX0Erl7iugz4xvRPJfNWuTxavintRds/opX8xf4z/6Q6G94K37w1u0avw9HXR8aqY486KoqmMx8Y+fEvsp3bR7hpvZa7iflP5xiJx/fk0SqYKijqJaOsp5YJ4HujlikYrXxvauFa5F8UVFRUVFOzfTn47Bbdfcxbfzdhy86id6tGb56hi1jZ9qvglfJPC41EN3SpirkRPiufH3EeJE8uaL4p4Ki+CpnLbntG/mf6A05ob5jnp/qC101t9K+EPdd/wB1G1nPh6M7jnjnHJce9T0XjfZ928S7Zpo0+nmLsVTNVM1Ue7xjv1YmM9sTnHeIfDtGp0236i5115pmOJxPP0xlsn1QdJ3zyNzsFx+H3wd9RwTwcPVXpffd45q5z30fHHH5c5MIfQt/58/xY/1ZH0Ur+Yv8Z/8ASD6KV/MX+M/+kPMbft/2g7XpqdJpKem3T2jNicZnPeZme8+rsL97ZNTcm7dnNU/xvEb2dAa7O7X33cn5rPrf1LHC/wBC9Q+j97zmZFjvPSH8cd5n6VfLHtyev7LlVW4bj/0Nq/Kqjx+9nX982La++7bfMm9Ueuo4Wem+vvSO64TRy57v0dnLPd4+mTzz7MGOelzqf+drqNRz/Af4R/CBlKzHrP0PuO5WVc/7KTlnvfkxx9ufD093bvEu6+GNVo90p6tTVVHTGbcZpiaJ70zFPlV3nP6Ovpvbfptwt3dPOLcROfxd8T68+jpB1Q/U8bhf1BVfkHGo3L3Q7RP5pO3modBfMe9XevqCWh9L+EHfdzzTHLh6M3lj3ck+yaaH3fZ1sWv2LRXrO4W+iqqrMc0zxiI/yzLi3zWWdZdpqsVZiI9Jjz+LpxqroE2X3G09bbzYPTNIXapoIJJJLfiSlkkdG1Vc+nf4J9iNzEMI3rsxt0IKhzdO7iaWrYE+lfWsqKV6/ZaxkqJ/ep/M227RzdLSVBS2fWGl7PqakpI2QslYq0NSrGphEVzEdGvgif8A2aGZ7V2nG1c0SLe9vtV0kntbSrTVDU++6SP/ANDyvsfH2yVTbs/7Wjy5pr/nit2PVsurjqq92frH8uH19L3QvX7M66pdytc6torldLbFMygo7ax/cRvkjdG6R8kiNc74j3ojeCeK5z4YNmNydb2vbbQd911eJo46azUUlSvNcJI9ExHGnyverWonvchqze+052wgp3O05t3qiunRPisrn09KxV+VzHyqn9ympvUB1W7j9QUkVvvfo9p0/Sy99T2iiV3dq/yR8r18ZXoiqiL4NT2NRVVV6+34S8R+K9yp1W909FEYiZnEe7E56aaY5855n1zmXPVueg22xNvSTmfr39ZmWGJJHyyOlkcrnPVXOVfaqlQD98eMdduif6l/Q39BWfns5hLtQf3KaD/rGt/w4zGOyfX98x3a+xbbfMm9b+pY5mem+vvR+95zSS57v0d/HHeY+mXyz7cHieqDq0+eRtNhtfwA+DvqSomn5+tfS++7xrW4x3MfHHHzyvmfi20+Et403iydzu2cWfaXKurqo7VdWJxFWecx5Z9Xq9TuWlubb93pq9/ppjGJ7xjPlhr0AD9peUAAAAAQAAMgADIAFVEAEKuCFXICxAAA0AAAAAzMgACAAAEKuAqlSxAAA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlF9hYoSi4JMCwAMgAAAAAAANZAAFCUd7yAEWzkFSUcEwkBFRQEAAAAAXIAAuQABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEyAAJkAAQAGcAAQrvcQFwlXe4gAKAAKAAJkAAZAAAAAAhV9hCr7EINRAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFwSVHkSYFwQi5JIAAIAAAAALkAAXIAAoMqABKKhJUBMLAjl7ycoEwAAIAAAAAuQAAyAALkAAMgAAAAKAAAAAAAAAAAAAAAAAAAAAgAAZAADIAAmQAAyAAIAAABlCFd7gYSFVCuVAXBlQAFAAFAAEyAAJkAAQAAAAhVwBJVVyQq5BqIAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRSABbOSShKO95nAsCCSAAAAAAAALkAAXIAAoAABPJSAETyQnJUAwsCuV95PJQmEgjl8hOUBgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKe8jkDCQRyUjK+8LhYjkhAC4TyUgAAAAoAAAACZAAEyAAIAAAAABAV3uK5yXAlXe4gA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGcFkd7yoJgXBRFVCyOJgSACAAAAAAAAAAAuQABcgACgAAAAAMr7wAGVJ5KQAmE8vkHJCADC2UGU95UAwtlPeCoCYWBUAwsCoyvvBhYFcr7xlQYWBUAwsMp7yoBhbKe8ZQqAuE8kHL5CADCeSkZUAGDK+8ABQAAAAAAAAABMgACZAAEyAAAAAAAAAhVQqqqpcCyqVVVUAuAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzgnl7yATAtnJJQlHKTAsCMoSQAAAAAAAAAAAAAXIAAZAAFyAAGQABQAAAAAAAAAAAAAAAAAAAAAAAAABMgABkAATIAAZAAEAAAAAAAAACFVEAkghXe4guBbl7iqqqgGsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKgATy95OUKgmBcFMqTy95MCwIyhJAAAAAAAAAAAAAAAAAAAAAAAAFyAAGQAAyAAGQABAAAAAAAAAAAAAAAAAAAACMoBIK8hlS4E5Qjl7iAXAZUAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOVHIgEwLZT3klCUcMCwI5IMp7yCQAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGUHJCiSMp7yOXyEDAtyI5KQC4AAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJypAAnko5fIQCYFuSDKFQMC2U94KgYFwUAwLgoMr7xgXBTK+8ZX3kwLgplfeMr7xgXBTK+8FwLgoBgWGU95UDAtlByQqBgTy+QclIAwJypABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//9k=";
var CUSTOM_EMOJI = {
	"👤": "6032693626394382504",
	"✏️": "6039779802741739617",
	"📄": "6034969813032374911",
	"💰": "5778421276024509124",
	"📎": "6039451237743595514",
	"📝": "5922693616953725714",
	"📊": "5936143551854285132"
};
var KEYS = Object.keys(CUSTOM_EMOJI).sort((a, b) => b.length - a.length);
function escapeRegExp(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function applyCustomEmoji(text) {
	let out = text;
	for (const base of KEYS) {
		const id = CUSTOM_EMOJI[base];
		out = out.replace(new RegExp(escapeRegExp(base), "g"), `<tg-emoji emoji-id="${id}">${base}</tg-emoji>`);
	}
	return out;
}
function hasCustomEmoji(text) {
	return /<tg-emoji\b/.test(text);
}
var BUTTON_EMOJI = {
	"🛡": "6030445631921721471",
	"📝": "5922693616953725714",
	"📣": "6039422865189638057",
	"👥": "6032609071373226027",
	"🌐": "5776233299424843260",
	"⬅️": "5960671702059848143",
	"✅": "5774022692642492953"
};
var BTN_KEYS = Object.keys(BUTTON_EMOJI).sort((a, b) => b.length - a.length);
function decorateButtons(markup, useIcons) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return markup;
	const rows = m.inline_keyboard.map((row) => row.map((btn) => {
		const text = typeof btn.text === "string" ? btn.text : "";
		if (!useIcons || !text) return { ...btn };
		for (const emoji of BTN_KEYS) if (text.startsWith(emoji + " ")) return {
			...btn,
			text: text.slice(emoji.length + 1),
			icon_custom_emoji_id: BUTTON_EMOJI[emoji]
		};
		return { ...btn };
	}));
	return {
		...markup,
		inline_keyboard: rows
	};
}
function markupHasIconableButton(markup) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return false;
	return m.inline_keyboard.some((row) => row.some((btn) => typeof btn.text === "string" && BTN_KEYS.some((e) => btn.text.startsWith(e + " "))));
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	allowCheck: () => allowCheck,
	allowEvidenceChunk: () => allowEvidenceChunk,
	allowEvidenceDownload: () => allowEvidenceDownload,
	allowEvidenceUpload: () => allowEvidenceUpload,
	appendEvidenceChunk: () => appendEvidenceChunk,
	bannerById: () => bannerById,
	bannerFilePath: () => bannerFilePath,
	blacklistEntry: () => blacklistEntry,
	checkCounterparty: () => checkCounterparty,
	configureFromOrigin: () => configureFromOrigin,
	diagnoseUserSearch: () => diagnoseUserSearch,
	evidenceBytesOnDisk: () => evidenceBytesOnDisk,
	evidenceOwnedBy: () => evidenceOwnedBy,
	featuresEnabled: () => featuresEnabled,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	hasUserbot: () => hasUserbot,
	isDisconnectError: () => isDisconnectError,
	listBanners: () => listBanners,
	listComplaintsForUser: () => listComplaintsForUser,
	listSponsors: () => listSponsors,
	postMatchesSubject: () => postMatchesSubject,
	recentBlacklist: () => recentBlacklist,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveChannelAsUser: () => resolveChannelAsUser,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	saveUserLocaleServer: () => saveUserLocaleServer,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	setAudienceBase: () => setAudienceBase,
	setSponsorLink: () => setSponsorLink,
	sponsorAvatarPath: () => sponsorAvatarPath,
	sponsorStats: () => sponsorStats,
	uploadedEvidencePath: () => uploadedEvidencePath,
	userbotStatus: () => userbotStatus,
	verifyAccountPair: () => verifyAccountPair,
	verifyEvidenceDownload: () => verifyEvidenceDownload,
	verifyTelegramInitData: () => verifyTelegramInitData,
	webhookSecret: () => webhookSecret,
	webhookSecretMatches: () => webhookSecretMatches
});
function botToken() {
	return process.env.TELEGRAM_BOT_TOKEN || "";
}
var warnedMissingToken = false;
function requireToken() {
	const token = botToken();
	if (!token && !warnedMissingToken) {
		warnedMissingToken = true;
		console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
	}
	return token;
}
function isDisconnectError(err) {
	const any = err;
	const code = String(any?.code || any?.cause?.code || "");
	const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
	return code === "ECONNRESET" || code === "EPIPE" || code === "ECONNABORTED" || code === "ERR_STREAM_PREMATURE_CLOSE" || /aborted|socket hang up|ECONNRESET|premature close/i.test(msg);
}
function installDisconnectGuards() {
	const swallow = (err) => {
		if (isDisconnectError(err)) return;
		console.error("[epb]", err);
	};
	process.on("uncaughtException", swallow);
	process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
function botApi() {
	return `https://api.telegram.org/bot${requireToken()}`;
}
var BOT_USERNAME = "EuropeBlack_bot";
function webhookSecret() {
	return `epb-${createHash("sha256").update(botToken()).digest("hex").slice(0, 24)}`;
}
function webhookSecretMatches(header) {
	const expected = webhookSecret();
	const got = String(header || "");
	const a = Buffer.from(got);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var RELAY_PATH = join(DATA_DIR, "telegram-relay-chats.json");
var BACKUP_DIR = join(DATA_DIR, "backups");
function writeJsonAtomic(path, value) {
	mkdirSync(dirname(path), { recursive: true });
	const tmp = `${path}.${process.pid}.tmp`;
	writeFileSync(tmp, JSON.stringify(value, null, 2));
	renameSync(tmp, path);
}
function readJson(path) {
	try {
		return JSON.parse(readFileSync(path, "utf8"));
	} catch {
		return null;
	}
}
function latestBackup(prefix) {
	try {
		const names = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		return names.length ? join(BACKUP_DIR, names[names.length - 1]) : null;
	} catch {
		return null;
	}
}
function backupDaily(prefix, value) {
	try {
		const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		writeJsonAtomic(join(BACKUP_DIR, `${prefix}-${day}.json`), value);
		const old = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		for (const name of old.slice(0, Math.max(0, old.length - 30))) unlinkSync(join(BACKUP_DIR, name));
	} catch {}
}
function mergeRelayLists(...lists) {
	const out = [];
	for (const list of lists) for (const chat of list || []) {
		if (!chat?.id) continue;
		const idx = out.findIndex((c) => sameChat(c.id, chat.id));
		if (idx < 0) out.push({
			...chat,
			id: String(chat.id)
		});
		else if (out[idx].status !== "on" && chat.status === "on") out[idx] = {
			...out[idx],
			...chat
		};
	}
	return out;
}
var bindingsLoadFailed = false;
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v4-admin";
function loadBindings() {
	let raw = readJson(BINDINGS_PATH);
	if (!raw && existsSync(BINDINGS_PATH)) {
		const backup = latestBackup("telegram-bindings");
		raw = backup ? readJson(backup) : null;
		if (!raw) {
			if (!bindingsLoadFailed) console.error("[epb] telegram-bindings.json is unreadable and there is no backup; it will not be overwritten");
			bindingsLoadFailed = true;
		}
	}
	const loaded = raw || {};
	const relayFile = readJson(RELAY_PATH);
	const relayBackup = relayFile ? null : readJson(latestBackup("telegram-relay-chats") || "");
	loaded.relayChats = mergeRelayLists(loaded.relayChats, relayFile, relayBackup);
	return loaded;
}
function saveBindings() {
	if (bindingsLoadFailed) return;
	try {
		writeJsonAtomic(BINDINGS_PATH, bindings);
		writeJsonAtomic(RELAY_PATH, bindings.relayChats || []);
		backupDaily("telegram-bindings", bindings);
		backupDaily("telegram-relay-chats", bindings.relayChats || []);
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids-verified.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var LOCALES_PATH = join(DATA_DIR, "telegram-locales.json");
var userLocales = {};
try {
	if (existsSync(LOCALES_PATH)) {
		const raw = JSON.parse(readFileSync(LOCALES_PATH, "utf8"));
		for (const [id, value] of Object.entries(raw || {})) if (isLocale(value)) userLocales[id] = value;
	}
} catch {
	userLocales = {};
}
function saveLocales() {
	try {
		writeJsonAtomic(LOCALES_PATH, userLocales);
	} catch {}
}
function langOf(userId) {
	return userLocales[String(userId || "")] === "en" ? "en" : "ru";
}
function hasLang(userId) {
	return isLocale(userLocales[String(userId || "")]);
}
function setLang(userId, locale) {
	userLocales[String(userId)] = locale;
	saveLocales();
}
function saveUserLocaleServer(userId, locale) {
	if (!isLocale(locale)) return;
	setLang(userId, locale);
}
function btUser(userId, key, vars) {
	return tb(langOf(userId), key, vars);
}
var idCache = {};
var legacyIds = {};
var pendingPosts = {};
legacyIds = readJson(join(DATA_DIR, "telegram-ids.json")) || {};
idCache = {
	...KNOWN_TELEGRAM_IDS,
	...readJson(ID_CACHE_PATH) || {}
};
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
for (const rec of Object.values(pendingPosts)) if (rec.status === "published" && rec.channelPosted === void 0) rec.channelPosted = true;
var BLACKLIST_CLEANUP = [
	"hugos",
	"mkcrd",
	"annuit1",
	"ballin812"
];
var BLACKLIST_CLEANUP_STAMP = "cleanup-v2";
if (bindings.blacklistCleanupStamp !== BLACKLIST_CLEANUP_STAMP) {
	let changed = false;
	for (const rec of Object.values(pendingPosts)) {
		if (rec.removedFromCheck) continue;
		if (pendingAccounts(rec).map((a) => a.username.replace(/^@/, "").toLowerCase()).some((n) => BLACKLIST_CLEANUP.includes(n))) {
			rec.removedFromCheck = true;
			changed = true;
		}
	}
	if (changed) savePending();
	bindings.blacklistCleanupStamp = BLACKLIST_CLEANUP_STAMP;
	saveBindings();
}
var idCacheTimer = null;
function saveIdCache() {
	if (idCacheTimer) return;
	idCacheTimer = setTimeout(() => {
		idCacheTimer = null;
		try {
			writeJsonAtomic(ID_CACHE_PATH, idCache);
		} catch {}
	}, 2e3);
}
function savePending() {
	try {
		const entries = Object.entries(pendingPosts);
		if (entries.length > 1200) {
			const drop = entries.filter(([, rec]) => rec.status === "published" || rec.status === "rejected").sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
			const extra = entries.length - 1e3;
			for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
		}
		writeJsonAtomic(PENDING_PATH, pendingPosts);
	} catch {}
}
function rememberUser(user) {
	if (!user?.id || !user.username) return;
	rememberHandle(user.username, String(user.id));
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	const keys = Object.keys(idCache);
	if (keys.length > 8e3) for (const extra of keys.slice(0, keys.length - 7e3)) delete idCache[extra];
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
var MAX_EVIDENCE_FILE = 1073741824;
var MAX_EVIDENCE_CHUNK = 2097152;
function sanitizeEvidenceId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9_-]/g, "");
	if (!safe || safe.length < 8 || safe.length > 80) return null;
	if (safe === ".." || safe.startsWith(".")) return null;
	return safe;
}
function evidenceOwnerPath(id) {
	return join(EVIDENCE_DIR, `${id}.own`);
}
function writeEvidenceOwner(id, userId) {
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(evidenceOwnerPath(id), String(userId || ""));
}
function readEvidenceOwner(id) {
	try {
		return readFileSync(evidenceOwnerPath(id), "utf8").trim();
	} catch {
		return "";
	}
}
function evidenceOwnedBy(id, userId) {
	const safe = sanitizeEvidenceId(id || "");
	if (!safe || !userId) return false;
	return readEvidenceOwner(safe) === userId && Boolean(uploadedEvidencePath(safe));
}
function evidenceHmacKey() {
	return createHmac("sha256", "EvidenceGet").update(botToken() || "none").digest();
}
function evidenceSig(key, exp) {
	return createHmac("sha256", evidenceHmacKey()).update(`${key}.${exp}`).digest("hex").slice(0, 32);
}
function verifyEvidenceDownload(key, exp, sig) {
	const safe = sanitizeEvidenceId(key);
	if (!safe) return false;
	const expMs = Number(exp);
	if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
	if (expMs > Date.now() + 1728e5) return false;
	const expect = evidenceSig(safe, expMs);
	const a = Buffer.from(expect, "hex");
	const b = Buffer.from(String(sig || ""), "hex");
	if (a.length !== b.length || a.length === 0) return false;
	return timingSafeEqual(a, b);
}
function isAllowedEvidenceMagic(bytes) {
	if (!bytes.length) return false;
	const head = bytes.subarray(0, 256).toString("utf8").replace(/^\uFEFF/, "").trimStart().toLowerCase();
	if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<script") || head.startsWith("<svg") || head.startsWith("<?xml") || head.startsWith("<?php") || head.startsWith("#!") || head.startsWith("import ") || head.startsWith("function ") || head.startsWith("const ") || head.startsWith("var ") || head.startsWith("{")) return false;
	if (bytes[0] === 77 && bytes[1] === 90) return false;
	if (bytes[0] === 127 && bytes[1] === 69 && bytes[2] === 76 && bytes[3] === 70) return false;
	if (bytes[0] === 202 && bytes[1] === 254 && bytes[2] === 186 && bytes[3] === 190) return false;
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return true;
	if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) return true;
	if (bytes.length >= 6 && bytes.subarray(0, 3).toString("ascii") === "GIF") return true;
	if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && (bytes.subarray(8, 12).toString("ascii") === "WEBP" || bytes.subarray(8, 12).toString("ascii") === "AVI ")) return true;
	if (bytes.length >= 4 && bytes[0] === 26 && bytes[1] === 69 && bytes[2] === 223 && bytes[3] === 163) return true;
	if (bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp") return true;
	return false;
}
function saveUploadedEvidence(userId, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
	if (!isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const id = randomUUID();
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	writeEvidenceOwner(id, userId);
	pruneEvidenceDir();
	return id;
}
var chunkCursor = /* @__PURE__ */ new Map();
function appendEvidenceChunk(userId, requestedId, index, total, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const safe = index === 0 ? randomUUID() : sanitizeEvidenceId(requestedId);
	if (!safe) throw new Error("bad chunk");
	if (index === 0 && !isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	if (index > 0 && readEvidenceOwner(safe) !== userId) throw new Error("forbidden");
	if (index === 0) writeEvidenceOwner(safe, userId);
	const part = join(EVIDENCE_DIR, `${safe}.part`);
	const dest = join(EVIDENCE_DIR, safe);
	const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
	if (existsSync(dest) && readEvidenceOwner(safe) === userId) return safe;
	const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
	if (index < expected) return safe;
	if (index !== expected) throw new Error("chunk order");
	if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
	if (index === 0) {
		if (existsSync(part)) unlinkSync(part);
		if (existsSync(dest)) unlinkSync(dest);
	}
	if ((existsSync(part) ? statSync(part).size : 0) + bytes.length > MAX_EVIDENCE_FILE) {
		try {
			unlinkSync(part);
		} catch {}
		chunkCursor.delete(safe);
		throw new Error("file too large");
	}
	appendFileSync(part, bytes);
	const next = index + 1;
	chunkCursor.set(safe, next);
	writeFileSync(idxPath, String(next));
	if (index !== total - 1) return safe;
	if (existsSync(dest)) unlinkSync(dest);
	renameSync(part, dest);
	try {
		unlinkSync(idxPath);
	} catch {}
	chunkCursor.delete(safe);
	pruneEvidenceDir();
	return safe;
}
function evidenceBytesOnDisk(id) {
	const path = id ? uploadedEvidencePath(id) : null;
	if (!path) return 0;
	try {
		return statSync(path).size;
	} catch {
		return 0;
	}
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	if (rateHits.size > 4e3) for (const [k, hits] of rateHits) {
		const keep = hits.filter((t) => now - t < 216e5);
		if (!keep.length) rateHits.delete(k);
		else rateHits.set(k, keep);
	}
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function verifyTelegramInitData(initData) {
	if (!botToken() || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const groups = /* @__PURE__ */ new Map();
		for (const name of readdirSync(EVIDENCE_DIR)) {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			const key = name.replace(/\.(own|part|idx)$/, "");
			const group = groups.get(key) || {
				paths: [],
				mtime: 0,
				size: 0
			};
			group.paths.push(path);
			group.mtime = Math.max(group.mtime, st.mtimeMs);
			group.size += st.size;
			groups.set(key, group);
		}
		const list = [...groups.values()].sort((a, b) => a.mtime - b.mtime);
		let total = list.reduce((sum, g) => sum + g.size, 0);
		const maxBytes = 8589934592;
		const maxUploads = 400;
		const fresh = Date.now() - 18e5;
		let count = list.length;
		for (const group of list) {
			if (count <= maxUploads && total <= maxBytes) break;
			if (group.mtime > fresh) break;
			for (const path of group.paths) try {
				unlinkSync(path);
			} catch {}
			total -= group.size;
			count -= 1;
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes = 1) {
	if (bytes < 0) return {
		ok: false,
		error: "file required"
	};
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("up:global", 2e3, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowEvidenceDownload() {
	return !tooMany("evget:global", 240, 6e4);
}
function allowEvidenceChunk(initData, bytes) {
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("upchunk:global", 2e3, 6e4)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowNewComplaint(userId, storyLen) {
	const loc = langOf(userId);
	if (storyLen > 5e3) return tb(loc, "storyLong");
	if (tooMany(`app:${userId}`, 3, 216e5)) return tb(loc, "tooManyUser");
	if (tooMany("app:global", 40, 36e5)) return tb(loc, "tooManyGlobal");
	return null;
}
function readUploadedEvidence(id) {
	const path = uploadedEvidencePath(id);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
function uploadedEvidencePath(id) {
	const safe = sanitizeEvidenceId(id);
	if (!safe) return null;
	const path = join(EVIDENCE_DIR, safe);
	if (!path.startsWith(EVIDENCE_DIR)) return null;
	return existsSync(path) ? path : null;
}
var BANNER_DIR = join(DATA_DIR, "banners");
var MAX_BANNER_BYTES = 20971520;
var MAX_BANNERS = 20;
function sanitizeBannerId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9]/g, "");
	if (safe.length < 10 || safe.length > 40) return null;
	return safe;
}
function newBannerId() {
	return createHash("sha256").update(randomUUID()).digest("hex").slice(0, 24);
}
function saveBannerFile(id, bytes) {
	mkdirSync(BANNER_DIR, { recursive: true });
	writeFileSync(join(BANNER_DIR, id), bytes);
}
var SPONSOR_AVATAR_DIR = join(DATA_DIR, "sponsor-avatars");
function sanitizeAvatarKey(k) {
	const safe = String(k || "").replace(/[^a-f0-9]/g, "");
	return safe.length >= 8 && safe.length <= 64 ? safe : null;
}
function sponsorAvatarPath(key) {
	const safe = sanitizeAvatarKey(key);
	if (!safe) return null;
	const path = join(SPONSOR_AVATAR_DIR, safe);
	if (!path.startsWith(SPONSOR_AVATAR_DIR)) return null;
	return existsSync(path) ? path : null;
}
async function sponsorAvatarUrl(smallFileId) {
	if (!smallFileId) return "";
	const key = createHash("sha256").update(smallFileId).digest("hex").slice(0, 24);
	const path = join(SPONSOR_AVATAR_DIR, key);
	if (!existsSync(path)) {
		const bytes = await downloadTelegramFile(smallFileId);
		if (!bytes) return "";
		try {
			mkdirSync(SPONSOR_AVATAR_DIR, { recursive: true });
			writeFileSync(path, bytes);
		} catch {
			return "";
		}
	}
	return `/api/telegram/sponsor-avatar?a=${key}`;
}
function bannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	return (bindings.banners || []).find((b) => b.id === safe) || null;
}
function bannerFilePath(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	const path = join(BANNER_DIR, safe);
	if (!path.startsWith(BANNER_DIR)) return null;
	return existsSync(path) ? path : null;
}
function listBanners() {
	return (bindings.banners || []).map((b) => ({
		id: b.id,
		type: b.type,
		link: b.link,
		width: b.width,
		height: b.height,
		src: `/api/telegram/banner?id=${encodeURIComponent(b.id)}`
	}));
}
var sponsorsCache = null;
function invalidateSponsors() {
	sponsorsCache = null;
	statsCache = null;
}
var AUDIENCE_DEFAULT = 20178;
var statsCache = null;
async function sponsorStats() {
	if (statsCache && Date.now() - statsCache.at < 6e5) return statsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	let sum = 0;
	await Promise.all(chats.map(async (c) => {
		const n = await tgSoft("getChatMemberCount", { chat_id: c.id });
		if (typeof n === "number" && n > 0) sum += n;
	}));
	const base = typeof bindings.audienceBase === "number" ? bindings.audienceBase : AUDIENCE_DEFAULT;
	const value = {
		chats: chats.length,
		audience: Math.max(base, sum)
	};
	statsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setAudienceBase(n) {
	if (!Number.isFinite(n) || n < 0 || n > 1e9) return false;
	bindings.audienceBase = Math.round(n);
	saveBindings();
	statsCache = null;
	return true;
}
async function listSponsors() {
	if (sponsorsCache && Date.now() - sponsorsCache.at < 6e5) return sponsorsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	const value = await Promise.all(chats.map(async (c) => {
		const chat = await tgSoft("getChat", { chat_id: c.id });
		const title = chat?.title || c.title || "Чат";
		const avatar = await sponsorAvatarUrl(chat?.photo?.small_file_id);
		return {
			id: String(c.id),
			title,
			link: c.link || "",
			avatar
		};
	}));
	sponsorsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setSponsorLink(chatId, raw) {
	const relay = findRelay(chatId);
	if (!relay) return "bad";
	const text = (raw || "").trim();
	if (text === "-" || text === "—" || text === "") {
		delete relay.link;
		saveBindings();
		invalidateSponsors();
		return "cleared";
	}
	if (!(/^https:\/\/[^\s]+$/i.test(text) || /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text))) return "bad";
	relay.link = text.startsWith("http") ? text : `https://${text}`;
	saveBindings();
	invalidateSponsors();
	return "set";
}
function removeBannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return;
	bindings.banners = (bindings.banners || []).filter((b) => b.id !== safe);
	saveBindings();
	try {
		const path = join(BANNER_DIR, safe);
		if (path.startsWith(BANNER_DIR) && existsSync(path)) unlinkSync(path);
	} catch {}
}
async function downloadTelegramFile(fileId) {
	const info = await tgSoft("getFile", { file_id: fileId });
	if (!info?.file_path) return null;
	if (info.file_size && info.file_size > MAX_BANNER_BYTES) return null;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 6e4);
	try {
		const res = await fetch(`https://api.telegram.org/file/bot${requireToken()}/${info.file_path}`, { signal: ctrl.signal });
		if (!res.ok) return null;
		const bytes = Buffer.from(await res.arrayBuffer());
		if (bytes.length > MAX_BANNER_BYTES) return null;
		return bytes;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
function extractBannerMedia(msg) {
	if (msg.animation?.file_id) return {
		type: "video",
		fileId: msg.animation.file_id,
		mime: msg.animation.mime_type || "video/mp4",
		width: msg.animation.width,
		height: msg.animation.height
	};
	if (msg.video?.file_id) return {
		type: "video",
		fileId: msg.video.file_id,
		mime: msg.video.mime_type || "video/mp4",
		width: msg.video.width,
		height: msg.video.height
	};
	if (msg.photo?.length) {
		const ph = msg.photo.at(-1);
		return {
			type: "image",
			fileId: ph.file_id,
			mime: "image/jpeg",
			width: ph.width,
			height: ph.height
		};
	}
	const doc = msg.document;
	if (doc?.file_id && doc.mime_type) {
		if (doc.mime_type.startsWith("image/") && doc.mime_type !== "image/svg+xml") return {
			type: "image",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
		if (doc.mime_type.startsWith("video/")) return {
			type: "video",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
	}
	return null;
}
function normalizeBannerLink(raw) {
	const text = raw.trim();
	if (text === "-" || text === "—" || text.toLowerCase() === "нет") return "";
	if (/^https:\/\/[^\s]+$/i.test(text)) return text;
	if (/^tg:\/\/[^\s]+$/i.test(text)) return text;
	if (/^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text)) return text.startsWith("http") ? text : `https://${text}`;
	return null;
}
var TgError = class extends Error {
	code;
	retryAfter;
	migrateTo;
	constructor(json, method) {
		super(json.description || method);
		this.code = json.error_code;
		this.retryAfter = json.parameters?.retry_after;
		this.migrateTo = json.parameters?.migrate_to_chat_id ? String(json.parameters.migrate_to_chat_id) : void 0;
	}
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function tgOnce(method, body) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 45e3);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify(body),
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new TgError(json, method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
async function tg(method, body = {}) {
	let payload = body;
	for (let attempt = 0;; attempt++) try {
		return await tgOnce(method, payload);
	} catch (err) {
		if (!(err instanceof TgError) || attempt >= 3) throw err;
		if (err.migrateTo && payload.chat_id != null) {
			onChatMigrated(String(payload.chat_id), err.migrateTo);
			payload = {
				...payload,
				chat_id: err.migrateTo
			};
			continue;
		}
		if (err.code === 429 && (err.retryAfter ?? 0) <= 60) {
			await sleep(((err.retryAfter ?? 1) + 1) * 1e3);
			continue;
		}
		throw err;
	}
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function customEmojiEnabled() {
	if (typeof bindings.customEmoji === "boolean") return bindings.customEmoji;
	return process.env.EPB_CUSTOM_EMOJI === "0" ? false : true;
}
function isPrivateChat(chatId) {
	return Number(chatId) > 0;
}
function isCustomEmojiError(err) {
	return err instanceof TgError && /emoji/i.test(err.message || "");
}
function isNotModified(err) {
	return err instanceof TgError && /not modified/i.test(err.message || "");
}
async function sendCeMessage(chatId, text, extra = {}) {
	if (customEmojiEnabled() && isPrivateChat(chatId)) {
		const richText = applyCustomEmoji(text);
		const markup = extra.reply_markup;
		if (hasCustomEmoji(richText) || markupHasIconableButton(markup)) {
			const richExtra = markup ? {
				...extra,
				reply_markup: decorateButtons(markup, true)
			} : extra;
			try {
				return await tg("sendMessage", {
					chat_id: chatId,
					text: richText,
					parse_mode: "HTML",
					...richExtra
				});
			} catch (err) {
				if (!isCustomEmojiError(err)) return null;
			}
		}
	}
	return tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		...extra
	});
}
async function editCard(cb, caption, reply_markup) {
	const chatId = cb.message?.chat.id;
	const messageId = cb.message?.message_id;
	if (chatId == null || messageId == null) return;
	const isMedia = Boolean(cb.message?.photo || cb.message?.caption);
	const method = isMedia ? "editMessageCaption" : "editMessageText";
	const field = isMedia ? "caption" : "text";
	const build = (txt, markup) => ({
		chat_id: chatId,
		message_id: messageId,
		[field]: txt,
		parse_mode: "HTML",
		reply_markup: markup,
		...isMedia ? {} : { disable_web_page_preview: true }
	});
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const richText = useCe ? applyCustomEmoji(caption) : caption;
	if (useCe && (hasCustomEmoji(richText) || markupHasIconableButton(reply_markup))) try {
		await tg(method, build(richText, decorateButtons(reply_markup, true)));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
		if (!isCustomEmojiError(err)) {}
	}
	try {
		await tg(method, build(caption, reply_markup));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
	}
	await sendCeMessage(chatId, caption, { reply_markup });
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v1") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v1";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook && bindings.webhookStamp === webhookStamp()) {
		await applyMenuButton();
		return;
	}
	await registerMiniAppUrl(site);
}
function webhookStamp() {
	return createHash("sha256").update(webhookSecret()).digest("hex").slice(0, 16);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			language_code: "ru",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Open the app"
				},
				{
					command: "apply",
					description: "File a complaint in chat"
				},
				{
					command: "cancel",
					description: "Cancel the complaint"
				},
				{
					command: "lang",
					description: "Language / Язык"
				}
			],
			language_code: "en",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("deleteMyCommands", { scope: { type: "default" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
		for (const chat_id of arbiterCandidates()) await tgSoft("setMyCommands", {
			commands: [
				{
					command: "admin",
					description: "Панель управления"
				},
				{
					command: "relays",
					description: "Чаты рассылки"
				},
				{
					command: "channel",
					description: "Канал для постов"
				},
				{
					command: "id",
					description: "ID этого чата"
				}
			],
			scope: {
				type: "chat",
				chat_id
			}
		});
	}
	profileReady = true;
}
var statusCache = null;
function getBotStatus() {
	if (!statusCache || Date.now() - statusCache.at > 6e4) statusCache = {
		at: Date.now(),
		value: computeBotStatus()
	};
	return statusCache.value;
}
async function computeBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	for (const id of arbiterCandidates()) {
		if (!await chatReachable(id)) continue;
		arbiterOk = true;
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		channelOk
	};
}
var mtClient = null;
var mtIdleTimer = null;
var mtBlockedUntil = 0;
var mtMisses = /* @__PURE__ */ new Map();
var mtInflight = /* @__PURE__ */ new Map();
var MT_SESSION_PATH = join(DATA_DIR, "mtproto.session");
function mtproto() {
	if (!mtClient) {
		mtClient = (async () => {
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
			const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
			let saved = "";
			try {
				const [stamp, value] = readFileSync(MT_SESSION_PATH, "utf8").split("\n");
				if (stamp === webhookStamp() && value) saved = value.trim();
			} catch {}
			const client = new TelegramClient(new StringSession(saved), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 12,
				floodSleepThreshold: 0,
				deviceModel: "EPB",
				systemVersion: "Linux",
				appVersion: "1.0",
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.start({ botAuthToken: botToken() }), 2e4, "mtproto login timeout");
			try {
				mkdirSync(DATA_DIR, { recursive: true });
				writeFileSync(MT_SESSION_PATH, `${webhookStamp()}\n${client.session.save()}`, { mode: 384 });
			} catch {}
			return {
				client,
				Api
			};
		})();
		mtClient.catch(() => dropMtproto());
	}
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = setTimeout(() => dropMtproto(), 18e5);
	return mtClient;
}
function withTimeout(promise, ms, message) {
	let timer;
	const timeout = new Promise((_, reject) => {
		timer = setTimeout(() => reject(new Error(message)), ms);
	});
	return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function dropMtproto() {
	const pending = mtClient;
	mtClient = null;
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
function floodSeconds(err) {
	const e = err;
	if (typeof e?.seconds === "number" && e.seconds > 0) return e.seconds;
	const m = `${e?.errorMessage || ""} ${e?.message || ""}`.match(/FLOOD_WAIT_(\d+)|A wait of (\d+) seconds/);
	return m ? Number(m[1] || m[2]) : 0;
}
var USER_SESSION_PATH = join(DATA_DIR, "user-session.txt");
function userSession() {
	const env = (process.env.TELEGRAM_USER_SESSION || "").trim();
	if (env) return env;
	try {
		return readFileSync(USER_SESSION_PATH, "utf8").trim();
	} catch {
		return "";
	}
}
function hasUserbot() {
	return Boolean(userSession());
}
var userClient = null;
var userIdleTimer = null;
var userBlockedUntil = 0;
function userApiCreds() {
	return {
		apiId: Number(process.env.TELEGRAM_API_ID || bindings.userbotApi?.apiId || 0),
		apiHash: (process.env.TELEGRAM_API_HASH || bindings.userbotApi?.apiHash || "").trim()
	};
}
var OWNER_ID = "1457986905";
function isOwner(id) {
	return String(id || "") === OWNER_ID;
}
function checkEnabled() {
	if (typeof bindings.checkEnabled === "boolean") return bindings.checkEnabled;
	if (process.env.EPB_CHECK_ENABLED === "0") return false;
	return true;
}
function featuresEnabled() {
	return { check: checkEnabled() };
}
function saveUserSession(session) {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(USER_SESSION_PATH, session, { mode: 384 });
	} catch {}
}
function clearUserSession() {
	dropUserbot();
	try {
		if (existsSync(USER_SESSION_PATH)) unlinkSync(USER_SESSION_PATH);
	} catch {}
}
function userbot() {
	if (!userClient) {
		userClient = (async () => {
			const session = userSession();
			if (!session) throw new Error("no user session");
			const { apiId, apiHash } = userApiCreds();
			if (!apiId || !apiHash) throw new Error("set TELEGRAM_API_ID and TELEGRAM_API_HASH for the userbot");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 15,
				floodSleepThreshold: 0,
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.connect(), 2e4, "userbot connect timeout");
			return {
				client,
				Api
			};
		})();
		userClient.catch(() => dropUserbot());
	}
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = setTimeout(() => dropUserbot(), 12e5);
	return userClient;
}
var userEntitiesLoaded = false;
async function ensureUserEntities(client) {
	if (userEntitiesLoaded) return;
	userEntitiesLoaded = true;
	try {
		await withTimeout(client.getDialogs({ limit: 300 }), 25e3, "dialogs timeout");
		const saved = client.session?.save?.();
		if (typeof saved === "string" && saved) saveUserSession(saved);
	} catch {
		userEntitiesLoaded = false;
	}
}
async function userInputPeer(client, ref) {
	try {
		return await client.getInputEntity(ref);
	} catch {
		await ensureUserEntities(client);
		return client.getInputEntity(ref);
	}
}
function dropUserbot() {
	const pending = userClient;
	userClient = null;
	userEntitiesLoaded = false;
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
async function userbotStatus() {
	if (!userSession()) return {
		ok: false,
		error: "нет сессии"
	};
	const { apiId, apiHash } = userApiCreds();
	if (!apiId || !apiHash) return {
		ok: false,
		error: "нет TELEGRAM_API_ID / TELEGRAM_API_HASH"
	};
	try {
		const { client, Api } = await userbot();
		const u = (await withTimeout(client.invoke(new Api.users.GetUsers({ id: [new Api.InputUserSelf()] })), 12e3, "timeout"))?.[0];
		return {
			ok: true,
			name: u?.username ? `@${u.username}` : u?.firstName || "аккаунт"
		};
	} catch (err) {
		return {
			ok: false,
			error: err?.message || "ошибка"
		};
	}
}
async function resolveChannelAsUser(ref) {
	if (!userSession()) return null;
	try {
		const { client } = await userbot();
		const chan = await withTimeout(client.getInputEntity(ref), 12e3, "timeout");
		if (!chan?.channelId) return null;
		const id = `-100${chan.channelId.toString()}`;
		const full = await client.getEntity(ref).catch(() => null);
		return {
			id,
			title: full?.title,
			username: full?.username,
			addedAt: Date.now()
		};
	} catch {
		return null;
	}
}
function snippetAround(text, needle) {
	const flat = text.replace(/\s+/g, " ").trim();
	if (!needle) return flat.slice(0, 180);
	const i = flat.toLowerCase().indexOf(needle.toLowerCase());
	if (i < 0) return flat.slice(0, 180);
	const from = Math.max(0, i - 60);
	return (from > 0 ? "…" : "") + flat.slice(from, from + 180).trim() + (from + 180 < flat.length ? "…" : "");
}
var deletedCache = /* @__PURE__ */ new Map();
async function channelPostDeleted(rec) {
	if (!userSession() || Date.now() < userBlockedUntil) return false;
	const ids = rec.channelMsgIds || [];
	const chat = rec.channelChatId || bindings.channelId || "";
	if (!ids.length || !chat) return false;
	const cacheKey = `${chat}:${ids.join(",")}`;
	const cached = deletedCache.get(cacheKey);
	if (cached && Date.now() - cached.at < 3e5) return cached.deleted;
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, chat);
		const deleted = !(await withTimeout(client.getMessages(peer, { ids }), 12e3, "getMessages timeout") || []).some((m) => m && m.id && m.className !== "MessageEmpty");
		deletedCache.set(cacheKey, {
			at: Date.now(),
			deleted
		});
		return deleted;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) userBlockedUntil = Date.now() + (wait + 5) * 1e3;
		else if (!err?.errorMessage) dropUserbot();
		return false;
	}
}
function channelRef(channel) {
	if (channel.username) return `@${channel.username.replace(/^@/, "")}`;
	const n = Number(channel.id);
	return Number.isSafeInteger(n) ? n : channel.id;
}
async function searchMessages(client, peer, query) {
	const c = client;
	const found = await withTimeout(c.getMessages(peer, {
		search: searchQueryFor(query),
		limit: 40
	}), 15e3, "search timeout") || [];
	if (found.length > 0) return found;
	return await withTimeout(c.getMessages(peer, { limit: 200 }), 2e4, "scan timeout") || [];
}
function searchQueryFor(raw) {
	return raw.replace(/[^\p{L}\p{N}]+/gu, " ").trim() || raw;
}
function escapeRe(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
var SCAM_WORDS_RE = /(скам|scam|кидал|кинул|кидок|кидалов|мошен|обман|развод|развёл|развел|афер|швыр|непорядочн|на[её]б|обул|обуть|не\s*верн|не\s*отда|невозврат|должник|кардер|арбитраж|arbitr|жалоб|ответчик|обвиняем|виновник|respondent|defendant|fraud|scammer|cheat|ч[её]рн\w*\s*списк|бл[еэ]к|blacklist|осторожн|внимани|alert|🚫|❌|🤡|⚠|🔴|🛑|📛)/iu;
var CONTACT_LINE_RE = /(оспор|обжал|по\s*(всем\s*)?вопрос|для\s*связ|связ[ьи]|контакт|админ|administrator|\badmin\b|support|поддержк|dispute|appeal|помощ|реклам|сотруднич|менеджер|\bгарант|куп(лю|ить)|прод(ам|аж|ать)|прайс|услуг|заказ|отзыв|подписку|канал\b)/iu;
var SUBJECT_LINE_RE = /(скам|scam|кидал|кинул|мошен|обман|развод|афер|швыр|непорядочн|должник|ответчик|обвиняем|виновник|respondent|defendant|🚫|❌|🤡|⚠|🔴|🛑|📛|id\s*[:#]|айди|ник[:\s]|тг[:\s]|телеграм|телега|юзернейм|юзер[:\s]|username)/iu;
var SUBJECT_LABEL_RE = /^(?:[📛🚫❌🤡⚠🔴🛑\s])*(?:ответчик|обвиняем\w*|скамер|кидал\w*|мошенник|виновник|respondent|defendant)\s*:?\s*$/iu;
var IGNORE_USERNAMES = /* @__PURE__ */ new Set([
	"europepromo",
	"ctoroot",
	"sbepbank",
	BOT_USERNAME.toLowerCase()
]);
function isIgnoredHandle(uname) {
	return IGNORE_USERNAMES.has((uname || "").replace(/^@/, "").toLowerCase());
}
function usernameOnLine(line, uname) {
	if (!uname) return false;
	return new RegExp("@?(?<!\\w)" + escapeRe(uname) + "(?!\\w)", "iu").test(line);
}
function idOnLine(line, id) {
	const digits = (id || "").replace(/\D/g, "");
	if (digits.length < 5) return false;
	return new RegExp("(?<!\\d)" + digits + "(?!\\d)").test(line);
}
function arbitrationAccused(line) {
	const m = line.match(/(?:^|\s)(?:на|против|on|against)\s+(?:пользовател\S*\s+|юзер\S*\s+|человек\S*\s+|аккаунт\S*\s+|user\s+|@)?(.+)$/i);
	if (!m) return "";
	return m[1].split(/\s+(?:от|from|by|заявител\S*|подал\S*|reporter)\s+/i)[0] || "";
}
function postMatchesSubject(body, username, id) {
	const uname = (username || "").replace(/^@/, "").toLowerCase();
	const ignoredName = !uname || IGNORE_USERNAMES.has(uname);
	if (ignoredName && !id) return false;
	const hasScamWord = SCAM_WORDS_RE.test(body);
	let labelAbove = false;
	for (const line of body.split(/\r?\n/)) {
		if (/арбитраж|arbitr/i.test(line)) {
			const accused = arbitrationAccused(line);
			if (accused) {
				if (!ignoredName && usernameOnLine(accused, uname)) return true;
				if (idOnLine(accused, id)) return true;
			}
			if (line.trim()) labelAbove = SUBJECT_LABEL_RE.test(line);
			continue;
		}
		const hasId = idOnLine(line, id);
		const hasU = !ignoredName && usernameOnLine(line, uname);
		if (!hasId && !hasU) {
			if (line.trim()) labelAbove = SUBJECT_LABEL_RE.test(line);
			continue;
		}
		const subjectLine = SUBJECT_LINE_RE.test(line) || labelAbove;
		if (!(CONTACT_LINE_RE.test(line) && !subjectLine)) {
			if (hasScamWord || subjectLine) return true;
		}
		if (line.trim()) labelAbove = SUBJECT_LABEL_RE.test(line);
	}
	return false;
}
async function userSearchChannel(channel, query, subject) {
	if (Date.now() < userBlockedUntil) return [];
	try {
		const { client } = await userbot();
		const msgs = await searchMessages(client, await userInputPeer(client, channelRef(channel)), query);
		const out = [];
		for (const m of msgs || []) {
			const body = m.message || "";
			if (!m.id || !body || !postMatchesSubject(body, subject.username, subject.id)) continue;
			out.push({
				channelId: channel.id,
				channelTitle: channel.title || "канал",
				messageId: m.id,
				link: messageLink(channel, m.id),
				date: (m.date || 0) * 1e3,
				snippet: snippetAround(body, subject.username || subject.id)
			});
		}
		return out;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) {
			userBlockedUntil = Date.now() + (wait + 5) * 1e3;
			console.warn(`[epb] userbot FLOOD_WAIT ${wait}s`);
		} else if (!err?.errorMessage) dropUserbot();
		return [];
	}
}
async function diagnoseUserSearch(input) {
	const parsed = parseTelegramInput(input);
	const uname = parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const q = uname || id;
	if (!q) return "Укажите @username или ID для проверки.";
	if (!hasUserbot()) return "Юзербот не подключён (нет сессии). Подключите: /userbot.";
	const channels = checkChannels();
	if (!channels.length) return "Не выбрано ни одного канала для поиска. Выберите: /userbot → каналы.";
	const st = await userbotStatus();
	if (!st.ok) return `Аккаунт не отвечает: ${st.error || "ошибка"}`;
	let resolvedId = id;
	if (uname && !resolvedId) {
		const r = await resolveUsernameMtproto(uname, "");
		if (r && r !== "busy" && r.id) resolvedId = r.id;
	}
	const idDigits = (resolvedId || "").replace(/\D/g, "");
	const mentions = (body) => uname && body.toLowerCase().includes(uname) || idDigits.length >= 5 && body.includes(idDigits);
	const lines = [`Аккаунт: ${st.name || "ок"}. Каналов: ${channels.length}. Ищу «${q}»${resolvedId && resolvedId !== q ? ` (id ${resolvedId})` : ""}…`];
	let total = 0;
	for (const ch of channels) try {
		const { client } = await userbot();
		const msgs = await searchMessages(client, await userInputPeer(client, channelRef(ch)), q);
		const mentioned = (msgs || []).filter((m) => m.id && mentions(m.message || ""));
		const relevant = (msgs || []).filter((m) => m.id && postMatchesSubject(m.message || "", uname, resolvedId));
		total += relevant.length;
		lines.push(`• ${ch.title || ch.username || ch.id}: просмотрено ${(msgs || []).length}, упомянут ${mentioned.length}, в тему ${relevant.length}`);
	} catch (err) {
		lines.push(`• ${ch.title || ch.username || ch.id}: ошибка — ${err?.message || String(err)}`);
	}
	lines.push(`Итого по делу: ${total}.`);
	return lines.join("\n");
}
async function resolveUsernameMtproto(username, userId = "") {
	const key = username.toLowerCase();
	if (!botToken()) return null;
	if (Date.now() < mtBlockedUntil) return "busy";
	if (Date.now() - (mtMisses.get(key) || 0) < 18e5) return null;
	const running = mtInflight.get(key);
	if (running) return running;
	if (userId && tooMany(`mtproto:user:${userId}`, 8, 6e4)) return "busy";
	if (tooMany("mtproto:resolve", 30, 6e4) || tooMany("mtproto:resolve:h", 400, 36e5)) return "busy";
	const job = (async () => {
		try {
			const ask = async () => {
				const { client, Api } = await mtproto();
				if (client.connected === false) throw new Error("mtproto disconnected");
				return withTimeout(client.invoke(new Api.contacts.ResolveUsername({ username })), 1e4, "mtproto request timeout");
			};
			let raw;
			try {
				raw = await ask();
			} catch (err) {
				if (err?.errorMessage || floodSeconds(err)) throw err;
				dropMtproto();
				raw = await ask();
			}
			const result = raw;
			const user = result.users?.[0];
			const id = String(user?.id ?? result.peer?.userId ?? "");
			if (!/^\d{5,15}$/.test(id)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			return {
				username: user?.username || username,
				id
			};
		} catch (err) {
			const wait = floodSeconds(err);
			if (wait) {
				mtBlockedUntil = Date.now() + (wait + 5) * 1e3;
				console.warn(`[epb] MTProto FLOOD_WAIT ${wait}s, lookups paused`);
				return "busy";
			}
			const rpc = err?.errorMessage;
			if (rpc && /USERNAME_(NOT_OCCUPIED|INVALID)/.test(rpc)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			if (!rpc) dropMtproto();
			return null;
		} finally {
			mtInflight.delete(key);
			if (mtMisses.size > 5e3) mtMisses.clear();
		}
	})();
	mtInflight.set(key, job);
	return job;
}
async function lookupVerifiedId(username, userId = "") {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key) return null;
	const cached = idCache[key];
	if (cached) return {
		username,
		id: cached
	};
	const chat = await tgSoft("getChat", { chat_id: `@${key}` });
	if (chat?.id) {
		rememberHandle(chat.username || username, String(chat.id));
		return {
			username: chat.username || username,
			id: String(chat.id)
		};
	}
	const mt = await resolveUsernameMtproto(key, userId);
	if (mt && mt !== "busy" && mt.id) {
		rememberHandle(mt.username, mt.id);
		return mt;
	}
	return mt === "busy" ? "busy" : null;
}
async function verifyAccountPair(username, id) {
	const handle = username.replace(/^@/, "").trim();
	if (!handle || !id) return { check: "unknown" };
	const found = await lookupVerifiedId(handle);
	if (!found || found === "busy") return { check: "unknown" };
	return found.id === id ? { check: "ok" } : {
		check: "mismatch",
		realId: found.id
	};
}
async function resolveHandleServer(input, userId = "") {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (tooMany("resolve:global", 80, 6e4)) {
		const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
		if (cached && (!parsed.id || cached === parsed.id)) return {
			username: parsed.username,
			id: cached,
			source: "telegram"
		};
		return {
			username: parsed.username,
			id: parsed.id,
			source: parsed.id ? "parsed" : "unresolved"
		};
	}
	if (parsed.id) {
		if (parsed.username) {
			const pair = await verifyAccountPair(parsed.username, parsed.id);
			if (pair.check === "mismatch" && pair.realId) return {
				username: parsed.username,
				id: pair.realId,
				source: "telegram"
			};
			return {
				username: parsed.username,
				id: parsed.id,
				source: pair.check === "ok" ? "telegram" : "parsed"
			};
		}
		const chat = await tgSoft("getChat", { chat_id: parsed.id });
		if (chat?.username) rememberHandle(chat.username, parsed.id);
		return {
			username: chat?.username || "",
			id: parsed.id,
			source: chat?.username ? "telegram" : "parsed"
		};
	}
	const username = parsed.username;
	const found = await lookupVerifiedId(username, userId);
	if (found && found !== "busy") return {
		username: found.username,
		id: found.id,
		source: "telegram"
	};
	const legacy = legacyIds[username.toLowerCase()];
	if (legacy) return {
		username,
		id: legacy,
		source: "parsed"
	};
	return {
		username,
		id: "",
		source: "unresolved",
		busy: found === "busy"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function previousPosts(accounts, exceptKey = "") {
	const ids = new Set(accounts.map((a) => a.id || a.telegramId || "").filter(Boolean));
	const names = new Set(accounts.map((a) => (a.username || "").replace(/^@/, "").toLowerCase()).filter(Boolean));
	const hits = Object.entries(pendingPosts).filter(([key, rec]) => key !== exceptKey && rec.status === "published").filter(([, rec]) => pendingAccounts(rec).some((a) => a.id && ids.has(a.id) || a.username && names.has(a.username.replace(/^@/, "").toLowerCase()))).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
	if (!hits.length) return "";
	return `⚠️ По этому аккаунту уже был пост: ${hits.slice(0, 3).map(([key, rec]) => `${escapeHtml(key)} (${new Date(rec.createdAt || 0).toLocaleDateString("ru-RU")})`).join(", ")}${hits.length > 3 ? ` и ещё ${hits.length - 3}` : ""}`;
}
function accountCheckHtml(a) {
	if (!a.username) return "❔ указан только ID, проверить по username нельзя";
	if (a.check === "ok") return "✅ username и ID совпадают (проверено в Telegram)";
	if (a.check === "mismatch") return `⚠️ Заявитель указал чужой ID <code>${escapeHtml(a.claimedId || "?")}</code> — заменён на настоящий ID @${escapeHtml(a.username.replace(/^@/, ""))}`;
	return "❔ связку username и ID проверить не удалось";
}
function applicationBriefHtml(app) {
	const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
	const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const accounts = scammerAccounts(app);
	const scammer = accounts.map((a) => `${formatAccountLine(a.username, a.telegramId, true)}\n${accountCheckHtml(a)}`).join("\n");
	const brief = (app.summary || app.story).trim();
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		...previousPosts(accounts) ? [previousPosts(accounts)] : [],
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(brief)}`
	].join("\n");
}
function applicationDetailHtml(app) {
	const detail = app.story.trim();
	const brief = (app.summary || "").trim();
	if (!detail || detail === brief) return "";
	return `<b>Подробно</b>\n${escapeHtml(detail)}`;
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	const multi = accounts.length > 1;
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const name = handle ? `@${escapeHtml(handle)}` : "";
		const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
		const last = i === accounts.length - 1;
		if (multi) {
			const head = [name, id].filter(Boolean).join(" ");
			if (!last) return `${head} ;`;
			return scam ? `${head} - ${scam}` : head;
		}
		if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
		return [name, id].filter(Boolean).join("\n");
	});
}
function channelHtml(accounts, story, amount = "", currency = "", bodyHtml = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		bodyHtml.trim() || escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const scamLine = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	return [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`
	].join("\n").slice(0, 1024);
}
function splitHtml(html, max = 4090) {
	if (html.length <= max) return [html];
	const tokens = html.match(/<[^>]*>|&[#a-zA-Z0-9]+;|[\s\S]/g) || [];
	const parts = [];
	const closers = (stack) => stack.map((t) => `</${t.name}>`).reverse().join("");
	const openers = (stack) => stack.map((t) => t.tag).join("");
	let stack = [];
	let cur = "";
	let lastNl = null;
	let lastSpace = null;
	for (let i = 0; i < tokens.length; i++) {
		const token = tokens[i];
		if (cur.length + token.length + closers(stack).length > max && cur.trim()) {
			const lastBreak = lastNl && lastNl.at > max / 3 ? lastNl : lastSpace && lastSpace.at > max / 3 ? lastSpace : null;
			lastNl = null;
			lastSpace = null;
			if (lastBreak) {
				parts.push(cur.slice(0, lastBreak.at) + closers(lastBreak.stack));
				stack = [...lastBreak.stack];
				cur = openers(stack);
				i = lastBreak.next - 1;
				continue;
			}
			parts.push(cur + closers(stack));
			cur = openers(stack);
		}
		const tag = token.match(/^<(\/)?([a-zA-Z0-9-]+)/);
		if (tag) {
			const name = tag[2].toLowerCase();
			if (tag[1]) {
				const idx = stack.map((t) => t.name).lastIndexOf(name);
				if (idx >= 0) stack = stack.slice(0, idx);
			} else if (!token.endsWith("/>")) stack = [...stack, {
				name,
				tag: token
			}];
		}
		cur += token;
		if (token === "\n") lastNl = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
		else if (token === " ") lastSpace = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
	}
	if (cur.replace(/<[^>]*>/g, "").trim()) parts.push(cur);
	return parts.map((p) => p.replace(/^\n+/, ""));
}
function reviewKeyboard(appId = "") {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: appId ? `pub:${appId}` : "pub"
	}, {
		text: "Отклонить",
		callback_data: appId ? `rej:${appId}` : "rej"
	}]] };
}
function publishChoiceKeyboard(key = "") {
	const suffix = key ? `:${key}` : "";
	const rows = [[{
		text: "Опубликовать с рассылкой",
		callback_data: `puball${suffix}`.slice(0, 64)
	}], [{
		text: "Опубликовать без рассылки",
		callback_data: `pubch${suffix}`.slice(0, 64)
	}]];
	if (key && pendingPosts[key]) {
		rows.push([{
			text: "✏ Изменить текст",
			callback_data: `pedit:${key}`
		}, {
			text: "👁 Предпросмотр",
			callback_data: `pview:${key}`
		}]);
		if (pendingPosts[key].postHtml) rows.push([{
			text: "↩ Вернуть исходный текст",
			callback_data: `porig:${key}`
		}]);
	}
	return { inline_keyboard: rows };
}
async function tgForm(method, form) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 12e4);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			body: form,
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new Error(json.description || method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
var TG_UPLOAD_MAX = 51380224;
function mediaSize(file) {
	return file.size || evidenceBytesOnDisk(file.storageKey);
}
function evidencePublicUrl(storageKey) {
	if (!storageKey || !sanitizeEvidenceId(storageKey)) return "";
	const site = publicSiteUrl();
	if (!site) return "";
	const exp = Date.now() + 864e5;
	const sig = evidenceSig(storageKey, exp);
	return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}&exp=${exp}&sig=${sig}`;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const size = mediaSize(file);
	if (file.kind === "video" && size > TG_UPLOAD_MAX) return sendLargeVideo(chatId, file, opts);
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	if (blob.size > TG_UPLOAD_MAX && file.kind === "video") return sendLargeVideo(chatId, file, opts);
	const form = new FormData();
	form.set("chat_id", String(chatId));
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
async function sendLargeVideo(chatId, file, opts = {}) {
	const url = evidencePublicUrl(file.storageKey);
	const extra = { chat_id: chatId };
	if (opts.caption) {
		extra.caption = opts.caption;
		extra.parse_mode = "HTML";
	}
	if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
	if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
	if (url) {
		const video = await tgSoft("sendVideo", {
			...extra,
			video: url,
			supports_streaming: true
		});
		if (video) return {
			...video,
			fileId: video.video?.file_id,
			kind: "video"
		};
		const doc = await tgSoft("sendDocument", {
			...extra,
			document: url
		});
		if (doc) return {
			message_id: doc.message_id,
			chat: doc.chat,
			fileId: doc.document?.file_id,
			kind: "video"
		};
	}
	const link = url || file.name || "видео";
	return {
		...await tg("sendMessage", {
			chat_id: chatId,
			text: [
				opts.caption,
				`Видео: ${escapeHtml(file.name || "файл")}`,
				url ? `<a href="${url}">скачать</a>` : link
			].filter(Boolean).join("\n"),
			parse_mode: "HTML",
			disable_web_page_preview: false,
			reply_markup: opts.replyMarkup,
			reply_to_message_id: opts.replyTo
		}),
		kind: "video"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		summary: app.summary || "",
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? btUser(chatId, "pendingNotice", {
			id: appId,
			scam
		}) : kind === "published" ? btUser(chatId, "publishedNotice", {
			id: appId,
			scam
		}) : btUser(chatId, "rejectedNotice", {
			id: appId,
			scam
		}),
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
var loginStates = /* @__PURE__ */ new Map();
function ownerLoginActive(chatId) {
	const st = loginStates.get(String(chatId));
	if (!st) return false;
	if (Date.now() - st.touched > 6e5) {
		st.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(chatId));
		return false;
	}
	return true;
}
async function sendOwnerPanel(chatId) {
	const st = await userbotStatus();
	const connected = st.ok;
	const channels = checkChannels();
	const rows = [];
	if (connected) {
		rows.push([{
			text: "📡 Выбрать каналы для поиска",
			callback_data: "ub:chans"
		}]);
		rows.push([{
			text: "🔌 Переподключить аккаунт",
			callback_data: "ub:connect"
		}]);
		rows.push([{
			text: "❌ Отключить аккаунт",
			callback_data: "ub:off"
		}]);
	} else rows.push([{
		text: "➕ Подключить аккаунт",
		callback_data: "ub:connect"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Юзербот для поиска по блеклистам</b>",
			connected ? `Аккаунт: ${escapeHtml(st.name || "подключён")} ✅` : "Аккаунт не подключён",
			`Каналов выбрано для поиска: ${channels.length}`,
			"",
			connected ? "Поиск в мини-приложении идёт по выложенным жалобам EPB и по выбранным каналам (через аккаунт, по username, включая старые посты)." : "Подключите свой аккаунт Telegram, затем выберите каналы, по которым искать. Понадобятся api_id и api_hash с my.telegram.org."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
}
async function startOwnerLogin(chatId) {
	const existing = loginStates.get(String(chatId));
	if (existing?.client) await existing.client.disconnect?.().catch(() => {});
	loginStates.set(String(chatId), {
		step: "apiId",
		touched: Date.now()
	});
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Подключение аккаунта</b>",
			"",
			"Нужны api_id и api_hash: зайдите на https://my.telegram.org → API development tools.",
			"",
			"Пришлите <b>api_id</b> (число).",
			"Отмена: /cancel_userbot"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function handleOwnerLogin(chatId, text) {
	const key = String(chatId);
	const st = loginStates.get(key);
	if (!st) return false;
	st.touched = Date.now();
	const value = text.trim();
	const fail = async (msg) => {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: msg
		});
	};
	try {
		if (st.step === "apiId") {
			const n = Number(value);
			if (!n || !Number.isInteger(n)) return await fail("api_id — это число. Пришлите ещё раз."), true;
			st.apiId = n;
			st.step = "apiHash";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Теперь пришлите <b>api_hash</b>.",
				parse_mode: "HTML"
			});
			return true;
		}
		if (st.step === "apiHash") {
			if (!/^[a-f0-9]{16,}$/i.test(value)) return await fail("Похоже, это не api_hash. Пришлите ещё раз."), true;
			st.apiHash = value;
			st.step = "phone";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Пришлите номер телефона аккаунта в формате +7999…"
			});
			return true;
		}
		if (st.step === "phone") {
			if (!/^\+?\d{7,15}$/.test(value.replace(/\s/g, ""))) return await fail("Неверный номер. Пример: +79991234567"), true;
			st.phone = value.replace(/\s/g, "");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			st.client = new TelegramClient(new StringSession(""), st.apiId, st.apiHash, {
				connectionRetries: 2,
				baseLogger: new Logger("none")
			});
			st.Api = Api;
			await withTimeout(st.client.connect(), 25e3, "connect timeout");
			st.phoneCodeHash = (await withTimeout(st.client.sendCode({
				apiId: st.apiId,
				apiHash: st.apiHash
			}, st.phone), 25e3, "sendCode timeout")).phoneCodeHash;
			st.step = "code";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Код отправлен в Telegram на этот аккаунт. Пришлите код. Если боитесь, что Telegram заблокирует код в сообщении — вставьте пробелы: 1 2 3 4 5."
			});
			return true;
		}
		if (st.step === "code") {
			const code = value.replace(/\D/g, "");
			if (!code) return await fail("Пришлите код из Telegram."), true;
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.SignIn({
					phoneNumber: st.phone,
					phoneCodeHash: st.phoneCodeHash,
					phoneCode: code
				})), 25e3, "signin timeout");
			} catch (err) {
				const m = err?.errorMessage || err?.message || "";
				if (/SESSION_PASSWORD_NEEDED/.test(m)) {
					st.step = "password";
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "На аккаунте включена двухфакторная защита. Пришлите пароль."
					});
					return true;
				}
				if (/PHONE_CODE_INVALID|PHONE_CODE_EXPIRED/.test(m)) return await fail("Код неверный или просрочен. Пришлите ещё раз, либо начните заново: /cancel_userbot."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
		if (st.step === "password") {
			const { computeCheck } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const check = await computeCheck(await st.client.invoke(new st.Api.account.GetPassword()), value);
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.CheckPassword({ password: check })), 25e3, "password timeout");
			} catch (err) {
				const m = err?.errorMessage || "";
				if (/PASSWORD_HASH_INVALID/.test(m)) return await fail("Пароль неверный. Пришлите ещё раз."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
	} catch (err) {
		loginStates.delete(key);
		await st.client?.disconnect?.().catch(() => {});
		await fail(`Не удалось подключить аккаунт: ${err?.message || "ошибка"}. Начните заново: /userbot`);
		return true;
	}
	return true;
}
async function finishOwnerLogin(chatId, st) {
	saveUserSession(st.client.session.save());
	bindings.userbotApi = {
		apiId: st.apiId,
		apiHash: st.apiHash
	};
	saveBindings();
	await st.client.disconnect?.().catch(() => {});
	loginStates.delete(String(chatId));
	dropUserbot();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Аккаунт подключён ✅\nТеперь выберите каналы для поиска."
	});
	await sendChannelPicker(chatId);
}
async function sendChannelPicker(chatId, editMessageId) {
	const dialogs = [];
	try {
		const { client } = await userbot();
		const list = await withTimeout(client.getDialogs({ limit: 200 }), 2e4, "dialogs timeout");
		for (const d of list) {
			const e = d?.entity;
			if (!e || e.className !== "Channel") continue;
			dialogs.push({
				id: `-100${e.id?.toString?.() ?? e.id}`,
				title: d.title || e.title || "канал",
				username: e.username || void 0
			});
		}
	} catch (err) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось получить список каналов: ${err?.message || "ошибка"}`
		});
		return;
	}
	if (!dialogs.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "У аккаунта нет каналов. Подпишитесь на нужные каналы и откройте список снова: /userbot"
		});
		return;
	}
	const selected = new Set(checkChannels().map((c) => chatIdKey(c.id)));
	const rows = dialogs.slice(0, 60).map((d) => [{
		text: `${selected.has(chatIdKey(d.id)) ? "✅" : "▫️"} ${cut(d.title, 40)}`,
		callback_data: `ub:tgl:${d.id}`
	}]);
	rows.push([{
		text: "Готово",
		callback_data: "ub:done"
	}]);
	const text = "<b>Каналы для поиска</b>\nОтметьте, по каким каналам искать. Нажмите «Готово», когда закончите.";
	if (editMessageId) await tgSoft("editMessageText", {
		chat_id: chatId,
		message_id: editMessageId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	else await tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	dialogCache.clear();
	for (const d of dialogs) dialogCache.set(chatIdKey(d.id), d);
}
var dialogCache = /* @__PURE__ */ new Map();
async function toggleCheckChannel(id) {
	const list = [...checkChannels()];
	const idx = list.findIndex((c) => sameChat(c.id, id));
	if (idx >= 0) list.splice(idx, 1);
	else {
		const d = dialogCache.get(chatIdKey(id));
		list.push({
			id,
			title: d?.title,
			username: d?.username,
			addedAt: Date.now()
		});
	}
	bindings.checkChannels = list.slice(-100);
	saveBindings();
}
async function handleOwnerCallback(cb) {
	const data = cb.data || "";
	if (!data.startsWith("ub:")) return false;
	const chatId = cb.message?.chat.id;
	if (!chatId || !isOwner(cb.from?.id)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Недоступно",
			show_alert: true
		});
		return true;
	}
	const [, action, ...rest] = data.split(":");
	const answer = (t = "") => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: t || void 0
	});
	if (action === "connect") {
		await answer();
		await startOwnerLogin(chatId);
	} else if (action === "off") {
		clearUserSession();
		delete bindings.userbotApi;
		saveBindings();
		await answer("Аккаунт отключён");
		await sendOwnerPanel(chatId);
	} else if (action === "chans") {
		await answer();
		await sendChannelPicker(chatId);
	} else if (action === "tgl") {
		await toggleCheckChannel(rest.join(":"));
		await answer();
		await sendChannelPicker(chatId, cb.message.message_id);
	} else if (action === "done") {
		await answer("Сохранено");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Готово. Каналов для поиска: ${checkChannels().length}.`
		});
	} else await answer();
	return true;
}
var CHECK_INDEX_PATH = join(DATA_DIR, "telegram-check-index.json");
var checkIndex = readJson(CHECK_INDEX_PATH) || {};
var checkIndexTimer = null;
function saveCheckIndex() {
	if (checkIndexTimer) return;
	checkIndexTimer = setTimeout(() => {
		checkIndexTimer = null;
		try {
			writeJsonAtomic(CHECK_INDEX_PATH, checkIndex);
		} catch {}
	}, 3e3);
}
function checkChannels() {
	return bindings.checkChannels || [];
}
function isCheckChannel(id) {
	if (id == null) return void 0;
	return checkChannels().find((c) => sameChat(c.id, id));
}
function tokensFromText(text) {
	const usernames = /* @__PURE__ */ new Set();
	const ids = /* @__PURE__ */ new Set();
	for (const m of text.matchAll(/@([A-Za-z][A-Za-z0-9_]{3,31})/g)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/gi)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:tg:\/\/user\?id=|\bid[:\s=]*)(\d{5,15})/gi)) ids.add(m[1]);
	for (const m of text.matchAll(/\b(\d{7,15})\b/g)) ids.add(m[1]);
	return {
		usernames: [...usernames],
		ids: [...ids]
	};
}
function messageLink(channel, messageId) {
	if (channel.username) return `https://t.me/${channel.username.replace(/^@/, "")}/${messageId}`;
	return `https://t.me/c/${String(channel.id).replace(/^-100/, "").replace(/^-/, "")}/${messageId}`;
}
function addCheckHit(token, hit) {
	const list = checkIndex[token] || (checkIndex[token] = []);
	if (list.some((h) => sameChat(h.channelId, hit.channelId) && h.messageId === hit.messageId)) return;
	list.unshift(hit);
	if (list.length > 25) list.length = 25;
}
function indexCheckPost(channel, messageId, text, date) {
	const body = (text || "").slice(0, 4096);
	if (!body.trim()) return;
	const { usernames, ids } = tokensFromText(body);
	if (!usernames.length && !ids.length) return;
	const snippet = body.replace(/\s+/g, " ").trim().slice(0, 160);
	const hit = {
		channelId: String(channel.id),
		channelTitle: channel.title || "канал",
		messageId,
		link: messageLink(channel, messageId),
		date: date * 1e3 || Date.now(),
		snippet
	};
	for (const u of usernames) addCheckHit(`@${u}`, {
		...hit,
		username: u
	});
	for (const id of ids) addCheckHit(id, hit);
	const keys = Object.keys(checkIndex);
	if (keys.length > 2e5) for (const k of keys.slice(0, keys.length - 18e4)) delete checkIndex[k];
	saveCheckIndex();
}
function removeCheckChannelFromIndex(channelId) {
	for (const [token, list] of Object.entries(checkIndex)) {
		const kept = list.filter((h) => !sameChat(h.channelId, channelId));
		if (kept.length) checkIndex[token] = kept;
		else delete checkIndex[token];
	}
	saveCheckIndex();
}
var DEFAULT_MANUAL_SOURCE = "Сторонний источник";
function recentBlacklist(limit = 24) {
	if (!checkEnabled()) return [];
	const out = [];
	for (const [key, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		out.push({
			kind: "epb",
			id: key,
			account: scamLabel(rec),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
	}
	for (const e of bindings.manualBlacklist || []) out.push({
		kind: "manual",
		id: e.id,
		account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
		date: e.addedAt || 0,
		source: e.source || DEFAULT_MANUAL_SOURCE,
		note: e.note
	});
	out.sort((a, b) => b.date - a.date);
	return out.slice(0, Math.max(1, limit));
}
function blacklistEntry(id) {
	if (!checkEnabled() || !id) return null;
	const rec = pendingPosts[id] || pendingPosts[id.toUpperCase()];
	if (rec && rec.status === "published" && rec.channelPosted && !rec.removedFromCheck) return {
		kind: "epb",
		id,
		account: scamLabel(rec),
		amount: rec.amount || "",
		currency: rec.currency || "",
		date: rec.createdAt || 0,
		summary: rec.summary || "",
		story: rec.story || rec.summary || ""
	};
	const man = (bindings.manualBlacklist || []).find((e) => e.id === id);
	if (man) return {
		kind: "manual",
		id,
		account: man.username ? `@${man.username.replace(/^@/, "")}` : man.telegramId ? `ID ${man.telegramId}` : "",
		date: man.addedAt || 0,
		source: man.source || DEFAULT_MANUAL_SOURCE,
		note: man.note
	};
	return null;
}
function matchManualBlacklist(uname, id) {
	const out = [];
	for (const e of bindings.manualBlacklist || []) {
		const eu = (e.username || "").replace(/^@/, "").toLowerCase();
		if (uname && eu === uname || id && e.telegramId === id) out.push({
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note,
			date: e.addedAt || 0
		});
	}
	return out.sort((a, b) => b.date - a.date);
}
async function checkCounterparty(input) {
	if (!checkEnabled()) return {
		query: {
			username: "",
			id: ""
		},
		epb: [],
		channels: [],
		manual: []
	};
	const parsed = parseTelegramInput(input);
	const uname = isIgnoredHandle(parsed.username) ? "" : parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const matched = [];
	for (const [key, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		const accounts = pendingAccounts(rec);
		if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) matched.push({
			key,
			rec
		});
	}
	const epb = [];
	for (const { key, rec } of matched) {
		if (await channelPostDeleted(rec)) {
			rec.removedFromCheck = true;
			savePending();
			continue;
		}
		const accounts = pendingAccounts(rec);
		epb.push({
			id: key,
			accounts: accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", "),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
	}
	epb.sort((a, b) => b.date - a.date);
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (list) => {
		for (const h of list) {
			const dkey = `${chatIdKey(h.channelId)}:${h.messageId}`;
			if (seen.has(dkey)) continue;
			seen.add(dkey);
			hits.push(h);
		}
	};
	const channels = checkChannels();
	if (hasUserbot() && channels.length) {
		let effectiveId = id;
		if (uname && !effectiveId) {
			const r = await resolveUsernameMtproto(uname, "");
			if (r && r !== "busy" && r.id) effectiveId = r.id;
		}
		const subject = {
			username: uname,
			id: effectiveId
		};
		const searchTerms = [uname, effectiveId].filter(Boolean);
		for (const channel of channels) for (const term of searchTerms) push(await userSearchChannel(channel, term, subject));
	} else for (const token of [uname ? `@${uname}` : "", id].filter(Boolean)) push(checkIndex[token] || []);
	hits.sort((a, b) => b.date - a.date);
	return {
		query: {
			username: uname,
			id
		},
		epb,
		channels: hits.slice(0, 30),
		manual: matchManualBlacklist(uname, id)
	};
}
function allowCheck(initData) {
	if (!checkEnabled()) return {
		ok: false,
		error: "disabled"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`check:${user.id}`, 40, 6e4)) return {
		ok: false,
		error: "too many"
	};
	if (tooMany("check:global", 1500, 6e4)) return {
		ok: false,
		error: "busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function packCaption(full, _fallback = "") {
	if (full.length <= 1024) return {
		caption: full,
		leftover: ""
	};
	return {
		caption: "",
		leftover: full
	};
}
async function attachReviewButtons(chatId, messageId, leftover, keyboard) {
	if (!leftover) return (await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Опубликовать или отклонить:",
		reply_to_message_id: messageId,
		reply_markup: keyboard
	}))?.message_id || messageId;
	const parts = splitHtml(leftover);
	let lastId = messageId;
	for (let i = 0; i < parts.length; i++) {
		const sent = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: parts[i],
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_to_message_id: i === 0 ? messageId : void 0,
			reply_markup: i === parts.length - 1 ? keyboard : void 0
		});
		if (sent?.message_id) lastId = sent.message_id;
	}
	return lastId;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
function groupMedia(files) {
	const groups = [];
	let current = [];
	let currentDoc = false;
	for (const file of files) {
		const isDoc = (file.type || file.kind) === "document";
		if (current.length && (current.length >= 10 || isDoc !== currentDoc)) {
			groups.push(current);
			current = [];
		}
		currentDoc = isDoc;
		current.push(file);
	}
	if (current.length) groups.push(current);
	return groups;
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard, followUp = caption) {
	if (!files.length) {
		const parts = splitHtml(followUp);
		let lastId = 0;
		let lastChat = chatId;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id: chatId,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		return {
			chat_id: lastChat,
			message_id: lastId,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const packed = packCaption(followUp, caption);
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = { chat_id: chatId };
		if (packed.caption) {
			payload.caption = packed.caption;
			payload.parse_mode = "HTML";
		}
		if (!packed.leftover) payload.reply_markup = keyboard;
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		if (!packed.leftover) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	const packed = packCaption(followUp, caption);
	let firstId = 0;
	for (const [i, chunk] of groupMedia(files).entries()) {
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0 && packed.caption) {
				payload.caption = packed.caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard, followUp = caption) {
	const packed = packCaption(followUp, caption);
	const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
	const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
	const files = [];
	let firstId = 0;
	if (!small.length && large.length) {
		const sent = await sendMediaFile(chatId, large[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length > 1 ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		for (const extra of large.slice(1)) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && large.length === 1) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	if (small.length <= 1) {
		const sent = await sendMediaFile(chatId, small[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		firstId = sent.message_id;
		for (const extra of large) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && !large.length) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	for (let i = 0; i < small.length; i += 10) {
		const chunk = small.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 && packed.caption ? { caption: packed.caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	for (const extra of large) {
		const more = await sendMediaFile(chatId, extra);
		if (more.fileId) files.push({
			type: more.kind,
			file_id: more.fileId
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendDetail(chatId, html, replyTo) {
	for (const [i, part] of splitHtml(html).entries()) await tgSoft("sendMessage", {
		chat_id: chatId,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: i === 0 ? replyTo : void 0
	});
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const briefText = applicationBriefHtml(app);
	const detailText = applicationDetailHtml(app);
	const keyboard = reviewKeyboard(app.id);
	const blobs = app.evidence.filter((f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard, briefText) : null;
			if (sent) {
				if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard, briefText);
			if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const parts = splitHtml(briefText);
		let lastId = 0;
		let lastChat = chat_id;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		if (detailText) await sendDetail(lastChat, detailText, lastId);
		storePending(app, []);
		return {
			chat_id: lastChat,
			message_id: lastId
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const userId = app.victim.telegramId || "";
	const blocked = allowNewComplaint(userId, app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
	app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
		...file,
		name: String(file.name || "file").slice(0, 120),
		dataUrl: "",
		storageKey: evidenceOwnedBy(file.storageKey, userId) ? file.storageKey : void 0
	}));
	if (app.evidence.length > 30) return {
		ok: false,
		error: btUser(userId, "tooManyFiles")
	};
	for (const account of scammerAccounts(app).slice(0, 8)) {
		account.username = String(account.username || "").replace(/^@/, "").trim();
		account.telegramId = /^\d{5,15}$/.test(String(account.telegramId || "").trim()) ? String(account.telegramId).trim() : "";
		account.check = "unknown";
		if (account.username) {
			const found = await lookupVerifiedId(account.username);
			if (found && found !== "busy") {
				if (account.telegramId && account.telegramId !== found.id) account.claimedId = account.telegramId;
				account.telegramId = found.id;
				account.check = account.claimedId ? "mismatch" : "ok";
			}
		} else if (account.telegramId) {
			const chat = await tgSoft("getChat", { chat_id: account.telegramId });
			if (chat?.type === "private" && chat.username) {
				account.username = chat.username;
				rememberHandle(chat.username, account.telegramId);
				account.check = "ok";
			}
		}
	}
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		if (pendingPosts[app.id]) {
			pendingPosts[app.id].reviewChatId = String(sent.chat_id);
			pendingPosts[app.id].reviewMessageId = sent.message_id;
			savePending();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: btUser(userId, "addBotArbiter", { bot: BOT_USERNAME })
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseAppKey(text, data = "") {
	const fromCb = callbackKey(data);
	if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
	const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
	if (fromText?.[1]) return fromText[1];
	return parseEpbMarker(text)?.key || fromCb;
}
function stripServiceMarker(text) {
	return text.replace(/\n*#epb[^\n]*/gi, "").replace(/\n*#published[^\n]*/gi, "").replace(/\n*#rejected[^\n]*/gi, "").replace(/\n*Статус:[^\n]*/gi, "").trim();
}
function alreadyHandled(text) {
	return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
var PartialSendError = class extends Error {
	sentIds;
	answered;
	constructor(cause, sentIds) {
		super(cause instanceof Error ? cause.message : String(cause));
		this.sentIds = sentIds;
		this.answered = cause instanceof TgError;
	}
};
async function sendPostToChat(chat_id, html, files) {
	const ids = [];
	try {
		return await sendPostParts(chat_id, html, files, ids);
	} catch (err) {
		throw new PartialSendError(err, ids);
	}
}
async function sendPostParts(chat_id, html, files, ids) {
	const collect = (sent) => {
		for (const m of Array.isArray(sent) ? sent : [sent]) {
			const id = m?.message_id;
			if (id) ids.push(id);
		}
	};
	const packed = packCaption(html);
	const parts = packed.leftover ? splitHtml(packed.leftover, 4090) : [];
	if (!files.length) {
		const chunks = splitHtml(html, 4090);
		for (const part of chunks) collect(await tg("sendMessage", {
			chat_id,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: false
		}));
		return ids;
	}
	for (const [i, chunk] of groupMedia(files).entries()) {
		const firstCaption = i === 0 && packed.caption ? packed.caption : void 0;
		if (chunk.length === 1) {
			const file = chunk[0];
			const payload = {
				chat_id,
				caption: firstCaption,
				parse_mode: firstCaption ? "HTML" : void 0
			};
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			collect(await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload));
		} else collect(await tg("sendMediaGroup", {
			chat_id,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...firstCaption && idx === 0 ? {
					caption: firstCaption,
					parse_mode: "HTML"
				} : {}
			}))
		}));
	}
	for (const part of parts) collect(await tg("sendMessage", {
		chat_id,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: false
	}));
	return ids;
}
function isMissingRights(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /not enough rights|need administrator|have no rights|CHAT_WRITE_FORBIDDEN|not allowed to post|CHAT_SEND_\w+_FORBIDDEN/i.test(text);
}
function isChatGone(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /chat not found|bot was blocked|bot is not a member|kicked|chat was deactivated|group chat was upgraded/i.test(text);
}
function isGroupOrChannel(chat) {
	if (chat.type === "private") return false;
	if (chat.type === "group" || chat.type === "supergroup" || chat.type === "channel") return true;
	const id = Number(chat.id);
	return Number.isFinite(id) && id < 0;
}
function relayDestinations() {
	const skip = new Set([
		...channelCandidates(),
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId || "",
		...OFFICIAL_ARBITER_IDS
	].filter(Boolean).map((id) => chatIdKey(id)));
	const seen = /* @__PURE__ */ new Set();
	return (bindings.relayChats || []).filter((chat) => {
		const k = chatIdKey(chat.id);
		if (chat.status !== "on" || !isGroupOrChannel(chat) || skip.has(k) || seen.has(k)) return false;
		seen.add(k);
		return true;
	});
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	let lastError = "channel not found";
	for (const chat_id of ids) try {
		return {
			chatId: chat_id,
			messageIds: await sendPostToChat(chat_id, html, files)
		};
	} catch (err) {
		if (err instanceof PartialSendError && err.sentIds.length) return {
			chatId: chat_id,
			messageIds: err.sentIds,
			partialError: err.message
		};
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
var RIGHTS_NOTICE_EVERY = 864e5;
function isMediaForbidden(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /rights to send (photos|videos|documents|media|audios|voice)|CHAT_SEND_(PHOTOS|VIDEOS|MEDIA|DOCS|GIFS)_FORBIDDEN/i.test(text);
}
var BROADCAST_PATH = join(DATA_DIR, "telegram-broadcasts.json");
var broadcastJobs = readJson(BROADCAST_PATH) || [];
var migratedKeys = /* @__PURE__ */ new Map();
function saveBroadcastJobs() {
	try {
		writeJsonAtomic(BROADCAST_PATH, broadcastJobs);
	} catch {}
}
async function channelAllowsForwarding(chatId) {
	return !(await tgSoft("getChat", { chat_id: chatId }))?.has_protected_content;
}
function recordRelayDelivery(key, chatId, messageIds) {
	const ids = messageIds.filter((n) => Number.isFinite(n));
	if (!key || !ids.length) return;
	const rec = pendingPosts[key];
	if (!rec) return;
	const list = rec.relayDeliveries ||= [];
	const k = chatIdKey(chatId);
	const existing = list.find((d) => chatIdKey(d.chatId) === k);
	if (existing) {
		for (const id of ids) if (!existing.messageIds.includes(id)) existing.messageIds.push(id);
	} else list.push({
		chatId: String(chatId),
		messageIds: [...ids]
	});
	savePending();
}
async function runBroadcast(job) {
	const report = job.report;
	if (job.inflight && !job.done.includes(job.inflight)) {
		(report.unconfirmed ||= []).push(`${job.inflight}: сервер перезапустился во время отправки, повторно не отправляли`);
		report.sent += 1;
		job.done.push(job.inflight);
	}
	job.inflight = void 0;
	const done = new Set(job.done);
	const approved = relayDestinations().filter((c) => !done.has(chatIdKey(c.id)));
	report.total = Math.max(report.total, done.size + approved.length);
	let forward = Boolean(job.source?.messageIds.length) && await channelAllowsForwarding(job.source.chatId);
	if (job.source?.messageIds.length && !forward && !report.failed.some((x) => x.startsWith("пересылка"))) report.failed.push("пересылка из канала запрещена (защита контента), в чаты ушли копии");
	let forwardedOk = 0;
	let emptyInARow = 0;
	for (const chat of approved) {
		if (job.done.includes(chatIdKey(chat.id))) continue;
		const label = chat.title ? `${chat.title} (${chat.id})` : chat.id;
		job.inflight = chatIdKey(chat.id);
		saveBroadcastJobs();
		try {
			let viaForward = false;
			if (forward && job.source) {
				let result = null;
				let fwdErr = null;
				try {
					result = await tg("forwardMessages", {
						chat_id: chat.id,
						from_chat_id: job.source.chatId,
						message_ids: job.source.messageIds
					});
				} catch (err) {
					fwdErr = err;
				}
				if (!fwdErr && result && result.length >= job.source.messageIds.length) {
					viaForward = true;
					forwardedOk += 1;
					emptyInARow = 0;
					recordRelayDelivery(job.key, chat.id, result.map((m) => m?.message_id).filter((n) => typeof n === "number"));
				} else if (fwdErr instanceof TgError && /protected|CHAT_FORWARDS_RESTRICTED|message to forward not found|message can't be forwarded/i.test(fwdErr.message)) {
					forward = false;
					report.failed.push("пересылка из канала невозможна (защита контента или пост удалён), в чаты ушли копии");
				} else if (fwdErr instanceof TgError && (isChatGone(fwdErr) || isMissingRights(fwdErr) && !isMediaForbidden(fwdErr))) throw fwdErr;
				else if (fwdErr instanceof TgError && isMediaForbidden(fwdErr)) {} else {
					(report.unconfirmed ||= []).push(`${label}: ${fwdErr instanceof Error ? fwdErr.message.replace(/^Bad Request: /, "") : `переслано ${result?.length ?? 0} из ${job.source.messageIds.length}`}`);
					viaForward = true;
					if (!fwdErr && result && !result.length && !forwardedOk && ++emptyInARow >= 3) {
						forward = false;
						report.failed.push("пересылка из канала не работает (Telegram пропускает сообщения), остальным чатам ушли копии");
					}
				}
			}
			if (!viaForward) try {
				const ids = await sendPostToChat(chat.id, job.html, job.files);
				recordRelayDelivery(job.key, chat.id, ids);
				if (forward) (report.copies ||= []).push(label);
			} catch (err) {
				const refusedCleanly = err instanceof PartialSendError && err.answered && !err.sentIds.length;
				if (!job.files.length || !refusedCleanly || !isMediaForbidden(err)) throw err;
				const ids = await sendPostToChat(chat.id, job.html, []);
				recordRelayDelivery(job.key, chat.id, ids);
				(report.textOnly ||= []).push(label);
			}
			report.sent += 1;
		} catch (err) {
			if (isMissingRights(err)) {
				report.noRights.push(label);
				const relay = findRelay(chat.id);
				if (relay && Date.now() - (relay.rightsNoticeAt || 0) > RIGHTS_NOTICE_EVERY) {
					relay.rightsNoticeAt = Date.now();
					saveBindings();
					await tgSoft("sendMessage", {
						chat_id: chat.id,
						text: "Сообщение для администрации: Вы не выдали достаточно прав для отправки рассылки в Вашем чате."
					});
				}
			} else if (isChatGone(err)) report.gone.push(label);
			else {
				const noAnswer = !(err instanceof TgError) && !(err instanceof PartialSendError && err.answered) && !(err instanceof Error && err.message.startsWith("пересланы"));
				report.failed.push(noAnswer ? `${label}: Telegram не ответил (возможно, пост дошёл); повторно не отправляем, чтобы не было дублей` : `${label}: ${err instanceof Error ? err.message : String(err)}`);
			}
		}
		const k = chatIdKey(chat.id);
		job.done.push(k);
		job.inflight = void 0;
		const moved = migratedKeys.get(k);
		if (moved) job.done.push(moved);
		saveBroadcastJobs();
		await sleep(Math.max(50, 40 * ((forward ? job.source?.messageIds.length : job.files.length) || 1)));
	}
	return report;
}
async function finishBroadcast(job) {
	const report = job.report;
	bindings.lastBroadcast = {
		at: Date.now(),
		total: report.total,
		sent: report.sent,
		noRights: report.noRights.length,
		gone: report.gone.length,
		failed: report.failed.length
	};
	saveBindings();
	broadcastJobs = broadcastJobs.filter((j) => j.id !== job.id);
	saveBroadcastJobs();
	if (!job.reportTo || !report.total) return;
	await tgSoft("sendMessage", {
		chat_id: job.reportTo.chatId,
		text: broadcastReportHtml(report),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: job.reportTo.messageId
	});
}
async function deleteChatMessages(chatId, messageIds) {
	let ok = 0;
	let fail = 0;
	const ids = [...new Set(messageIds.filter((n) => Number.isFinite(n)))];
	for (let i = 0; i < ids.length; i += 100) {
		const batch = ids.slice(i, i + 100);
		if (await tgSoft("deleteMessages", {
			chat_id: chatId,
			message_ids: batch
		})) ok += batch.length;
		else for (const id of batch) if (await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: id
		})) ok += 1;
		else fail += 1;
		await sleep(40);
	}
	return {
		ok,
		fail
	};
}
async function deletePublishedEverywhere(key) {
	const channel = {
		ok: 0,
		fail: 0
	};
	const chats = {
		ok: 0,
		fail: 0
	};
	let chatCount = 0;
	const rec = pendingPosts[key];
	if (!rec) return {
		channel,
		chats,
		chatCount
	};
	if (rec.channelChatId && rec.channelMsgIds?.length) {
		const r = await deleteChatMessages(rec.channelChatId, rec.channelMsgIds);
		channel.ok += r.ok;
		channel.fail += r.fail;
	}
	for (const d of rec.relayDeliveries || []) {
		if (!d.messageIds.length) continue;
		chatCount += 1;
		const r = await deleteChatMessages(d.chatId, d.messageIds);
		chats.ok += r.ok;
		chats.fail += r.fail;
	}
	rec.deletedEverywhere = true;
	rec.channelPosted = false;
	rec.removedFromCheck = true;
	rec.relayDeliveries = [];
	rec.channelMsgIds = [];
	savePending();
	return {
		channel,
		chats,
		chatCount
	};
}
function enqueueBroadcast(job) {
	broadcastQueue = broadcastQueue.then(() => runBroadcast(job)).then(() => finishBroadcast(job)).catch((err) => console.error("[epb] broadcast", err));
}
function resumeBroadcasts() {
	const fresh = broadcastJobs.filter((j) => Date.now() - j.startedAt < 432e5);
	if (fresh.length !== broadcastJobs.length) {
		broadcastJobs = fresh;
		saveBroadcastJobs();
	}
	for (const job of fresh) {
		console.log(`[epb] resuming broadcast ${job.key}: ${job.done.length} chats already done`);
		enqueueBroadcast(job);
	}
}
function broadcastReportHtml(report) {
	const list = (items) => items.slice(0, 15).map((x) => `• ${escapeHtml(x)}`).join("\n") + (items.length > 15 ? `\n… и ещё ${items.length - 15}` : "");
	const unsure = report.unconfirmed?.length || 0;
	const lines = [`<b>Рассылка завершена</b>: доставлено ${report.sent - unsure} из ${report.total}` + (unsure ? `, без подтверждения ${unsure}` : "")];
	if (report.unconfirmed?.length) lines.push("", `<b>Telegram ответил ошибкой, но пост обычно доходит — проверьте чат, повторно не отправляли (${report.unconfirmed.length})</b>`, list(report.unconfirmed));
	if (report.copies?.length) lines.push("", `<b>Пересылка в чат не прошла, отправлено копией (${report.copies.length})</b>`, list(report.copies));
	if (report.textOnly?.length) lines.push("", `<b>В чате запрещены фото/видео, отправлен только текст (${report.textOnly.length})</b>`, list(report.textOnly));
	if (report.noRights.length) lines.push("", `<b>Нет прав (${report.noRights.length})</b>`, list(report.noRights));
	if (report.gone.length) lines.push("", `<b>Бот удалён или чат недоступен (${report.gone.length})</b>`, list(report.gone));
	if (report.failed.length) lines.push("", `<b>Ошибки (${report.failed.length})</b>`, list(report.failed));
	return lines.join("\n");
}
function entitiesToHtml(text, entities = []) {
	const tags = {
		bold: ["<b>", "</b>"],
		italic: ["<i>", "</i>"],
		underline: ["<u>", "</u>"],
		strikethrough: ["<s>", "</s>"],
		spoiler: ["<tg-spoiler>", "</tg-spoiler>"],
		code: ["<code>", "</code>"],
		pre: ["<pre>", "</pre>"],
		blockquote: ["<blockquote>", "</blockquote>"],
		expandable_blockquote: ["<blockquote expandable>", "</blockquote>"]
	};
	const opens = /* @__PURE__ */ new Map();
	const closes = /* @__PURE__ */ new Map();
	const usable = entities.filter((e) => typeof e.offset === "number" && typeof e.length === "number" && e.length > 0).filter((e) => tags[e.type] || e.type === "text_link" && /^https?:\/\//i.test(e.url || "")).sort((a, b) => a.offset - b.offset || b.length - a.length);
	for (const e of usable) {
		const [open, close] = e.type === "text_link" ? [`<a href="${escapeHtml(e.url || "")}">`, "</a>"] : tags[e.type];
		if (e.offset >= text.length) continue;
		opens.set(e.offset, [...opens.get(e.offset) || [], open]);
		const end = Math.min(e.offset + e.length, text.length);
		closes.set(end, [close, ...closes.get(end) || []]);
	}
	let out = "";
	for (let i = 0; i <= text.length; i++) {
		out += (closes.get(i) || []).join("");
		out += (opens.get(i) || []).join("");
		if (i < text.length) out += escapeHtml(text[i]);
	}
	return out;
}
var postEditPrompts = /* @__PURE__ */ new Map();
function postPreviewHtml(key) {
	const rec = pendingPosts[key];
	return channelHtml(pendingAccounts(rec), rec.summary || rec.story, rec.amount, rec.currency, rec.postHtml);
}
async function sendPostPreview(chatId, key, replyTo) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const repeat = previousPosts(pendingAccounts(rec), key);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `${`<b>Предпросмотр поста ${escapeHtml(key)}</b>${rec.postHtml ? " (текст изменён)" : ""}` + (rec.files?.length ? `\nК посту приложится доказательств: ${rec.files.length}` : "") + (repeat ? `\n${repeat}` : "")}\n━━━━━━━━━━\n${postPreviewHtml(key)}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: replyTo,
		reply_markup: publishChoiceKeyboard(key)
	});
}
async function askPostEdit(chatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			`<b>Новый текст поста ${escapeHtml(key)}</b>`,
			"",
			"Ответьте на это сообщение новым текстом. Можно жирный, курсив и ссылки.",
			"Строки с аккаунтом и суммой и подпись Subscribe бот добавит сам.",
			"",
			"Сейчас в посте:",
			rec.postHtml || escapeHtml((rec.summary || rec.story).trim())
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Новый текст поста"
		}
	});
	if (prompt?.message_id) {
		postEditPrompts.set(`${chatId}:${prompt.message_id}`, key);
		if (postEditPrompts.size > 200) postEditPrompts.delete(postEditPrompts.keys().next().value);
	}
}
async function handlePostEditReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const key = postEditPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!key) return false;
	const rec = pendingPosts[key];
	if (!rec || rec.status !== "pending") {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Заявка уже обработана, текст не изменён.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const text = (msg.text || msg.caption || "").trim();
	if (text.length < 5) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком коротко. Ответьте на сообщение бота ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	if (text.length > 3500) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком длинно: максимум 3500 символов.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const html = entitiesToHtml(msg.text || msg.caption || "", msg.entities || msg.caption_entities).trim();
	const previous = rec.postHtml;
	rec.postHtml = html;
	if (postPreviewHtml(key).length > 3900) {
		rec.postHtml = previous;
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пост получается слишком длинным для Telegram. Сократите текст и ответьте ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	savePending();
	postEditPrompts.delete(`${msg.chat.id}:${replyTo}`);
	await sendPostPreview(msg.chat.id, key, msg.message_id);
	return true;
}
var publishing = /* @__PURE__ */ new Set();
var broadcastQueue = Promise.resolve();
async function publishFromMessage(text, callbackId, extraFiles = [], relay = false, keyHint = "", reportTo) {
	const parsed = parseEpbMarker(text);
	const key = keyHint || parsed?.key || "";
	const stored = key ? pendingPosts[key] : void 0;
	if (!parsed && !stored) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	if (stored?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (stored?.status === "rejected") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Заявка уже отклонена",
			show_alert: true
		});
		return false;
	}
	const lock = key || `txt:${createHash("sha256").update(text).digest("hex").slice(0, 16)}`;
	if (!key && pendingPosts[lock]?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (publishing.has(lock)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже публикуем"
		});
		return false;
	}
	publishing.add(lock);
	const html = channelHtml(pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""), stored?.summary || stored?.story || parsed?.story || "", stored?.amount, stored?.currency, stored?.postHtml);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	let channelPost;
	try {
		channelPost = await sendChannelPost(html, files);
	} catch {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: relay ? "Не удалось опубликовать в канал. Чаты без прав пропускаются." : "Не удалось опубликовать. Бот должен быть админом канала.",
			show_alert: true
		});
		return false;
	}
	if (key && pendingPosts[key]) {
		pendingPosts[key].status = "published";
		pendingPosts[key].channelPosted = true;
		pendingPosts[key].channelChatId = channelPost.chatId;
		pendingPosts[key].channelMsgIds = channelPost.messageIds;
	} else pendingPosts[lock] = {
		username: "",
		id: "",
		story: "",
		amount: "",
		currency: "",
		files: [],
		createdAt: Date.now(),
		status: "published",
		channelPosted: true
	};
	savePending();
	if (relay) {
		const job = {
			id: randomUUID(),
			key: lock,
			html,
			files,
			source: channelPost,
			done: [],
			report: {
				total: 0,
				sent: 0,
				noRights: [],
				gone: [],
				failed: []
			},
			reportTo,
			startedAt: Date.now()
		};
		broadcastJobs.push(job);
		saveBroadcastJobs();
		enqueueBroadcast(job);
	}
	publishing.delete(lock);
	if (key && pendingPosts[key]) await notifyApplicant(pendingPosts[key], key, "published");
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: channelPost.partialError ? "Пост в канале вышел не целиком. Повторно не публикуем — проверьте канал." : relay ? "Опубликовано в канал, рассылка по чатам идёт" : "Опубликовано без рассылки",
		show_alert: Boolean(channelPost.partialError)
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
var channelSetup = /* @__PURE__ */ new Set();
var checkChannelSetup = /* @__PURE__ */ new Set();
var removeFromCheckSetup = /* @__PURE__ */ new Set();
var addBlacklistSetup = /* @__PURE__ */ new Set();
var sponsorLinkSetup = /* @__PURE__ */ new Map();
var bannerSetup = /* @__PURE__ */ new Map();
function gcSessions() {
	const now = Date.now();
	for (const [id, session] of sessions) if (now - (session.touched || 0) > 72e5) sessions.delete(id);
	if (sessions.size <= 400) return;
	const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
	for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard(locale) {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: tb(locale, "openApp"),
		web_app: { url }
	}]);
	rows.push([{
		text: tb(locale, "applyBtn"),
		callback_data: "apply"
	}]);
	rows.push([{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}, {
		text: tb(locale, "ownersBtn"),
		callback_data: "owners"
	}]);
	rows.push([{
		text: tb(locale, "langBtn"),
		callback_data: "lang"
	}]);
	return { inline_keyboard: rows };
}
function applyCancelRow(chatId) {
	return [{
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}];
}
function startText(locale) {
	return tb(locale, "start");
}
function ownersText(locale) {
	return tb(locale, "owners", { bot: BOT_USERNAME });
}
function ownersKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}], [{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function langKeyboard(withBack = false) {
	const rows = [[{
		text: "Русский",
		callback_data: "lang:ru"
	}, {
		text: "English",
		callback_data: "lang:en"
	}]];
	if (withBack) rows.push([{
		text: "⬅️ Назад / Back",
		callback_data: "home"
	}]);
	return { inline_keyboard: rows };
}
var LANG_PROMPT = "Выберите язык / Choose language";
async function askLanguage(chatId, withBack = false) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Выберите язык / Choose language",
		reply_markup: langKeyboard(withBack)
	});
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	const candidates = [
		join(process.cwd(), "public/bot", name),
		join(process.cwd(), ".output/public/bot", name),
		join(process.cwd(), "public", name),
		join("/workspace/public/bot", name),
		join("/workspace/.output/public/bot", name)
	];
	try {
		const here = dirname(fileURLToPath(import.meta.url));
		candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
	} catch {}
	return candidates.find((p) => existsSync(p)) || null;
}
function cardBytes(kind) {
	if (kind === "welcome") try {
		return Buffer.from(WELCOME_JPEG_BASE64, "base64");
	} catch {}
	const path = cardPath(kind);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const rich = useCe ? applyCustomEmoji(caption) : caption;
	const plainMarkup = extra.reply_markup;
	const richMarkup = useCe ? decorateButtons(plainMarkup, true) : plainMarkup;
	const needsRich = useCe && (hasCustomEmoji(rich) || markupHasIconableButton(plainMarkup));
	const cap = needsRich ? rich : caption;
	const rest = (markup) => {
		const { reply_markup: _omit, ...other } = extra;
		return markup === void 0 ? other : {
			...other,
			reply_markup: markup
		};
	};
	const trySend = async (method, build) => {
		try {
			return await tg(method, build(cap, needsRich ? richMarkup : plainMarkup));
		} catch (err) {
			if (needsRich && isCustomEmojiError(err)) return await tgSoft(method, build(caption, plainMarkup));
			return null;
		}
	};
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await trySend("sendPhoto", (c, markup) => ({
			chat_id: chatId,
			photo: cached,
			caption: c,
			parse_mode: "HTML",
			...rest(markup)
		}))) return;
		if (bindings.cards) delete bindings.cards[kind];
		saveBindings();
	}
	const bytes = cardBytes(kind);
	if (bytes?.length) {
		const sendForm = (c, markup) => {
			const form = new FormData();
			form.set("chat_id", String(chatId));
			form.set("caption", c);
			form.set("parse_mode", "HTML");
			if (markup) form.set("reply_markup", JSON.stringify(markup));
			form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
			return tgForm("sendPhoto", form);
		};
		try {
			let sent;
			try {
				sent = await sendForm(cap, needsRich ? richMarkup : plainMarkup);
			} catch (err) {
				if (needsRich && isCustomEmojiError(err)) sent = await sendForm(caption, plainMarkup);
				else throw err;
			}
			const fileId = sent.photo?.at(-1)?.file_id;
			if (fileId) {
				bindings.cards = {
					...bindings.cards,
					[kind]: fileId
				};
				saveBindings();
			}
			return;
		} catch {}
	}
	await trySend("sendMessage", (c, markup) => ({
		chat_id: chatId,
		text: c,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		...rest(markup)
	}));
}
async function startCaption(locale) {
	let text = startText(locale);
	try {
		const st = await sponsorStats();
		if (st.chats > 0) {
			const audience = st.audience.toLocaleString(locale === "en" ? "en-US" : "ru-RU");
			text += `\n\n${tb(locale, "statsLine", {
				chats: String(st.chats),
				audience
			})}`;
		}
	} catch {}
	return text;
}
async function replyStart(chatId, userId) {
	const locale = langOf(userId ?? chatId);
	await sendCard(chatId, "welcome", await startCaption(locale), { reply_markup: applyKeyboard(locale) });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		summary: "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: [],
		touched: Date.now()
	};
}
function parseAmount(text) {
	return parseDamageAmount(text);
}
function formatAmount(amount) {
	const [intPart, frac] = amount.split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return frac ? `${grouped}.${frac}` : grouped;
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session, userId) {
	if (!session.accounts.length) return btUser(userId, "emptyAccounts");
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function sendStep(chatId, text, extra = {}) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
	const sent = await sendCeMessage(chatId, text, extra);
	if (session && sent?.message_id) session.stepMsgId = sent.message_id;
	return sent;
}
function clearStepMessage(chatId, deleteIt = true) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		if (deleteIt) tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session, chatId) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: btUser(chatId, "moreAccount"),
		callback_data: "apply:more"
	}, {
		text: btUser(chatId, "next"),
		callback_data: "apply:next"
	}]);
	rows.push(applyCancelRow(chatId));
	await sendStep(chatId, session?.accounts.length ? btUser(chatId, "accountsListed", { list: listed }) : btUser(chatId, "stepAccounts"), { reply_markup: { inline_keyboard: rows } });
}
async function askSummary(chatId) {
	await sendStep(chatId, btUser(chatId, "stepSummary"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askStory(chatId) {
	await sendStep(chatId, btUser(chatId, "stepStory"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askAmount(chatId) {
	await sendStep(chatId, btUser(chatId, "stepAmount"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askCurrency(chatId, amount) {
	await sendStep(chatId, btUser(chatId, "pickCurrency", { amount: formatAmount(amount) }), { reply_markup: { inline_keyboard: [[{
		text: "💵 USD",
		callback_data: "apply:cur:USD"
	}, {
		text: "💶 EUR",
		callback_data: "apply:cur:EUR"
	}], applyCancelRow(chatId)] } });
}
async function askEvidence(chatId) {
	await sendStep(chatId, btUser(chatId, "stepEvidence"), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "done"),
		callback_data: "apply:done"
	}, {
		text: btUser(chatId, "skipFiles"),
		callback_data: "apply:skip"
	}], applyCancelRow(chatId)] } });
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? btUser(chatId, "filesCount", { n: session.evidence.length }) : btUser(chatId, "noFiles");
	await sendStep(chatId, btUser(chatId, "confirm", {
		accounts: formatSessionAccounts(session, chatId),
		victim,
		id: session.victimId,
		amount: session.amount,
		currency: session.currency,
		files,
		summary: session.summary,
		story: session.story
	}), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "sendReview"),
		callback_data: "apply:send"
	}, {
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}]] } });
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await sendCeMessage(chatId, btUser(from.id, "applyStart"));
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice) {
	clearStepMessage(chatId);
	sessions.delete(userId);
	await sendCeMessage(chatId, notice || btUser(userId, "cancel"), { reply_markup: applyKeyboard(langOf(userId)) });
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needAccountSubmit")
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (!session.summary.trim() || session.summary.trim().length < 10) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needSummary")
		});
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (!session.story.trim() || session.story.trim().length < 20) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needStory")
		});
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		summary: session.summary,
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || btUser(userId, "sendFail")
		});
		return;
	}
	clearStepMessage(chatId);
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: btUser(userId, "sent", { id: app.id })
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: btUser(userId, "addAccountLeast")
					});
					return;
				}
				session.step = "summary";
				sessions.set(userId, session);
				await askSummary(chatId);
				return;
			}
			const resolved = await resolveHandleServer(raw, userId);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "parseAccount")
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "idNoNumeric", { user: resolved.username })
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (session.step === "summary") {
		const summary = (msg.text || msg.caption || "").trim();
		if (summary.length < 10) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needSummary")
			});
			return;
		}
		if (summary.length > 800) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "summaryLong")
			});
			return;
		}
		session.summary = summary;
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 20) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needStory")
			});
			return;
		}
		if (story.length > 5e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "storyLong")
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needAmount")
			});
			return;
		}
		session.amount = parsed.amount;
		if (!parsed.currency) {
			sessions.set(userId, session);
			await askCurrency(chatId, parsed.amount);
			return;
		}
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 30) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "fileAccepted", { n: session.evidence.length }),
				reply_markup: { inline_keyboard: [[{
					text: btUser(userId, "done"),
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "sendMedia")
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: btUser(cb.from?.id, "applyInDm"),
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(cb.from?.id, "applyOpen", { bot: BOT_USERNAME })
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: btUser(cb.from?.id, "restart")
		});
		return;
	}
	tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
		if (!session.amount) {
			await askAmount(chatId);
			return;
		}
		session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
		session.step = "evidence";
		sessions.set(userId, session);
		await askEvidence(chatId);
		return;
	}
	if (cb.data === "apply:keep") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "addAccountFirst")
			});
			return;
		}
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "nextAccount")
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") await submitSession(chatId, userId, session);
}
function findRelay(id) {
	return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}
function upsertRelay(chat, status) {
	const list = [...bindings.relayChats || []];
	const idx = list.findIndex((c) => sameChat(c.id, chat.id));
	const next = {
		id: String(chat.id),
		title: chat.title || list[idx]?.title,
		type: chat.type || list[idx]?.type,
		status
	};
	if (status === "pending") next.requestedAt = Date.now();
	if (idx >= 0) list[idx] = {
		...list[idx],
		...next
	};
	else list.push(next);
	bindings.relayChats = pruneRelays(list);
	saveBindings();
}
function pruneRelays(list) {
	const LIMIT = 5e3;
	if (list.length <= LIMIT) return list;
	const removable = list.filter((c) => c.status !== "on").sort((a, b) => (a.requestedAt || 0) - (b.requestedAt || 0)).slice(0, list.length - LIMIT);
	const drop = new Set(removable.map((c) => chatIdKey(c.id)));
	return list.filter((c) => !drop.has(chatIdKey(c.id)));
}
function onChatMigrated(oldId, newId) {
	if (!oldId || !newId || sameChat(oldId, newId)) return;
	migratedKeys.set(chatIdKey(oldId), chatIdKey(newId));
	let changed = false;
	const list = bindings.relayChats || [];
	const old = list.find((c) => sameChat(c.id, oldId));
	if (old) {
		const twin = list.find((c) => sameChat(c.id, newId));
		if (twin) {
			if (old.status === "on") twin.status = "on";
			bindings.relayChats = list.filter((c) => c !== old);
		} else {
			old.id = newId;
			old.type = "supergroup";
		}
		changed = true;
	}
	if (bindings.channelId && sameChat(bindings.channelId, oldId)) {
		bindings.channelId = newId;
		changed = true;
	}
	if (changed) {
		saveBindings();
		console.log(`[epb] chat ${oldId} migrated to ${newId}`);
	}
}
function dropRelay(id) {
	bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
	saveBindings();
}
function chatKindLabel(type) {
	if (type === "channel") return "канал";
	if (type === "supergroup") return "супергруппа";
	if (type === "group") return "группа";
	return type || "чат";
}
async function greetRelayChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: [
			`<b>${CHANNEL_NAME}</b>`,
			"",
			"Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает."
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function notifyArbitersAboutRelay(chat, addedBy) {
	const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
	const who = addedBy?.username ? `@${addedBy.username}` : addedBy?.first_name ? `${escapeHtml(addedBy.first_name)} (<code>${addedBy.id}</code>)` : "неизвестно";
	await tgSoft("sendMessage", {
		chat_id: arbiter,
		text: [
			"<b>Бот добавлен в чужой чат</b>",
			"",
			`Название: ${escapeHtml(chat.title || "без названия")}`,
			`Тип: ${chatKindLabel(chat.type)}`,
			`ID: <code>${chat.id}</code>`,
			`Кто добавил: ${who}`,
			"",
			"Подключить рассылку одобренных постов в этот чат?"
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [[{
			text: "Принять",
			callback_data: `rel:y:${chat.id}`
		}, {
			text: "Отклонить",
			callback_data: `rel:n:${chat.id}`
		}]] }
	});
}
async function replaceReplyMarkup(msg, markup, nextText) {
	const text = nextText ?? msg.caption ?? msg.text ?? "";
	const isMedia = Boolean(msg.caption || msg.photo || msg.video);
	if (nextText) {
		if (isMedia) {
			if (await tgSoft("editMessageCaption", {
				chat_id: msg.chat.id,
				message_id: msg.message_id,
				caption: text.slice(0, 1024),
				parse_mode: "HTML",
				reply_markup: markup
			})) return true;
		} else if (await tgSoft("editMessageText", {
			chat_id: msg.chat.id,
			message_id: msg.message_id,
			text,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: markup
		})) return true;
	}
	const markupOnly = await tgSoft("editMessageReplyMarkup", {
		chat_id: msg.chat.id,
		message_id: msg.message_id,
		reply_markup: markup
	});
	return Boolean(markupOnly);
}
function callbackKey(data) {
	const i = data.indexOf(":");
	return i >= 0 ? data.slice(i + 1) : "";
}
async function handleRelayDecision(cb, allow) {
	const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
	if (!raw) return;
	const chatId = raw;
	const relay = findRelay(chatId);
	const title = relay?.title || chatId;
	if (allow) {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "on");
		const wrote = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
			show_alert: !wrote
		});
	} else {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "off");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят."
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Отклонено"
		});
	}
	const next = allow ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.` : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
	if (cb.message) await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: next,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [] }
	});
}
async function bindChat(chat, from, justAdded = true) {
	if (!isGroupOrChannel(chat)) return;
	const id = String(chat.id);
	if (isOfficialArbiterChat(id)) {
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
				"",
				"Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
				"Сменить: /channel -100…"
			].join("\n"),
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialChannel(id)) {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${escapeHtml(chat.title ?? id)}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	const existing = findRelay(id);
	if (existing?.status === "on") {
		if (!justAdded) return;
		await tgSoft("sendMessage", {
			chat_id: chat.id,
			text: "Рассылка уже включена. Одобренные посты будут приходить сюда."
		});
		return;
	}
	if (existing?.status === "pending" && Date.now() - (existing.requestedAt || 0) < 864e5) return;
	if (existing?.status === "off" && !justAdded) return;
	if (tooMany("relay:global", 8, 6e4)) return;
	if (from?.id && tooMany(`relay:${from.id}`, 3, 36e5)) return;
	upsertRelay(chat, "pending");
	await greetRelayChat(chat);
	await notifyArbitersAboutRelay(chat, from);
}
var USERS_PATH = join(DATA_DIR, "telegram-users.json");
var botUsers = readJson(USERS_PATH) || {};
var isUserId = (id) => /^[1-9]\d{0,15}$/.test(String(id ?? ""));
if (!existsSync(USERS_PATH)) {
	const seed = /* @__PURE__ */ new Set([...Object.keys(userLocales), ...Object.values(pendingPosts).map((r) => r.victimId || "")]);
	for (const id of seed) if (isUserId(id)) botUsers[id] = {
		first: Date.now(),
		last: 0
	};
	try {
		writeJsonAtomic(USERS_PATH, botUsers);
	} catch {}
}
var usersTimer = null;
function saveUsers() {
	if (usersTimer) return;
	usersTimer = setTimeout(() => {
		usersTimer = null;
		try {
			writeJsonAtomic(USERS_PATH, botUsers);
		} catch {}
	}, 3e3);
}
function touchUser(id, blocked) {
	if (!isUserId(id)) return;
	const key = String(id);
	const now = Date.now();
	const user = botUsers[key] || {
		first: now,
		last: now
	};
	user.last = now;
	if (blocked !== void 0) user.blocked = blocked;
	else if (user.blocked) user.blocked = false;
	botUsers[key] = user;
	saveUsers();
}
function userStats() {
	const all = Object.values(botUsers);
	const blocked = all.filter((u) => u.blocked).length;
	return {
		total: all.length,
		active: all.length - blocked,
		blocked
	};
}
var DM_JOBS_PATH = join(DATA_DIR, "telegram-dm-broadcasts.json");
var dmDonePath = (id) => join(DATA_DIR, `dm-done-${id.replace(/[^a-z0-9-]/gi, "")}.log`);
var dmJobs = readJson(DM_JOBS_PATH) || [];
var dmDraft = null;
var dmPrompts = /* @__PURE__ */ new Map();
var dmAlbums = /* @__PURE__ */ new Map();
var dmQueue = Promise.resolve();
var dmStarting = /* @__PURE__ */ new Set();
function saveDmJobs() {
	try {
		writeJsonAtomic(DM_JOBS_PATH, dmJobs);
	} catch {}
}
function readDone(id) {
	try {
		return new Set(readFileSync(dmDonePath(id), "utf8").split("\n").filter(Boolean).map((l) => l.replace(/^\?/, "")));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function dmMarkup(draft) {
	return draft.buttons.length ? { inline_keyboard: draft.buttons } : void 0;
}
async function sendDmCopy(chatId, draft) {
	if (draft.srcIds.length > 1) {
		if (!(await tg("copyMessages", {
			chat_id: chatId,
			from_chat_id: draft.srcChat,
			message_ids: draft.srcIds
		}))?.length) throw new Error("сообщение не скопировалось");
		return;
	}
	await tg("copyMessage", {
		chat_id: chatId,
		from_chat_id: draft.srcChat,
		message_id: draft.srcIds[0],
		reply_markup: dmMarkup(draft)
	});
}
function parseDmButtons(text) {
	const rows = [];
	for (const line of text.split("\n").map((l) => l.trim()).filter(Boolean)) {
		const row = [];
		for (const part of line.split("|").map((p) => p.trim()).filter(Boolean)) {
			const m = part.match(/^(.+?)\s+[-–—]\s+(\S+)$/);
			if (!m) return `Не понял строку: «${part}». Формат: Текст - https://ссылка`;
			const url = m[2];
			if (!/^(https?:\/\/|tg:\/\/)\S+$/i.test(url)) return `Ссылка должна начинаться с https:// или tg:// — «${url}»`;
			row.push({
				text: m[1].slice(0, 64),
				url
			});
		}
		if (row.length > 8) return "В одном ряду максимум 8 кнопок";
		if (row.length) rows.push(row);
	}
	if (!rows.length) return "Не нашёл ни одной кнопки";
	if (rows.length > 10) return "Максимум 10 рядов кнопок";
	return rows;
}
function dmScreen() {
	const st = userStats();
	const running = dmJobs.find((j) => !j.stopped);
	const lines = [
		"<b>Пользователи бота</b>",
		`Всего: ${st.total}`,
		`Получат рассылку: ${st.active}`,
		`Заблокировали бота: ${st.blocked}`,
		"",
		"Рассылка уходит только в личные сообщения пользователям бота. В чаты и каналы она не отправляется."
	];
	const keyboard = [];
	if (running) {
		const done = readDone(running.id).size;
		lines.push("", `<b>Идёт рассылка</b>: ${done} из ${running.recipients.length}`);
		keyboard.push([{
			text: "⏹ Остановить рассылку",
			callback_data: `adm:ubstop:${running.id}`
		}]);
		keyboard.push([{
			text: "🔄 Обновить",
			callback_data: "adm:ub"
		}]);
	} else keyboard.push([{
		text: "✉ Новая рассылка",
		callback_data: "adm:ubnew"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function askDmContent(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Новая рассылка пользователям бота</b>",
			"",
			"Ответьте на это сообщение тем, что нужно разослать: текст, фото, видео, GIF, стикер или альбом, с подписью и форматированием.",
			"Премиум-эмодзи сохранятся, если у владельца бота есть Telegram Premium.",
			"",
			"Не удаляйте своё сообщение, пока рассылка не закончится: бот копирует именно его."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Сообщение для рассылки"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "content");
}
async function askDmButtons(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Кнопки под рассылкой</b>",
			"",
			"Ответьте на это сообщение. Каждая строка — ряд кнопок, кнопки в ряду через «|»:",
			"<code>Наш канал - https://t.me/+KkrYz9IKvoBmYTQy</code>",
			"<code>Сайт - https://example.com | Бот - https://t.me/EuropeBlack_bot</code>"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Текст - https://ссылка"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "buttons");
}
async function sendDmPreview(chatId) {
	const draft = dmDraft;
	if (!draft) return;
	const st = userStats();
	let previewOk = true;
	try {
		await sendDmCopy(String(chatId), draft);
	} catch (err) {
		previewOk = false;
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось показать предпросмотр: ${err.message}`
		});
	}
	const album = draft.srcIds.length > 1;
	const keyboard = [];
	if (!album) {
		keyboard.push([{
			text: draft.buttons.length ? "✏ Изменить кнопки" : "➕ Добавить кнопки",
			callback_data: "adm:ubbtn"
		}]);
		if (draft.buttons.length) keyboard.push([{
			text: "🗑 Убрать кнопки",
			callback_data: "adm:ubclr"
		}]);
	}
	if (previewOk) keyboard.push([{
		text: `🚀 Разослать (${st.active})`,
		callback_data: `adm:ubgo:${draft.id}`
	}]);
	keyboard.push([{
		text: "✖ Отменить",
		callback_data: "adm:ubcancel"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Предпросмотр рассылки — выше</b>",
			`Получат: ${st.active} пользователей бота (только личные сообщения, не чаты и не каналы).`,
			album ? "Это альбом: Telegram не позволяет добавить к альбому кнопки." : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: keyboard }
	});
}
async function handleDmReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const kind = dmPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!kind) return false;
	if (kind === "buttons") {
		if (!dmDraft) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Черновик рассылки не найден. Начните заново: /admin"
			});
			return true;
		}
		const parsed = parseDmButtons(msg.text || "");
		if (typeof parsed === "string") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `${parsed}\nОтветьте на сообщение с инструкцией ещё раз.`,
				reply_to_message_id: msg.message_id
			});
			return true;
		}
		dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
		dmDraft.buttons = parsed;
		await sendDmPreview(msg.chat.id);
		return true;
	}
	if (msg.media_group_id) {
		const albumKey = `${msg.chat.id}:${msg.media_group_id}`;
		const album = dmAlbums.get(albumKey);
		if (album) {
			album.ids.push(msg.message_id);
			return true;
		}
		const timer = setTimeout(async () => {
			const done = dmAlbums.get(albumKey);
			dmAlbums.delete(albumKey);
			if (!done) return;
			dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
			dmDraft = {
				id: randomUUID(),
				srcChat: done.chat,
				srcIds: [...done.ids].sort((a, b) => a - b),
				buttons: []
			};
			await sendDmPreview(msg.chat.id);
		}, 1500);
		dmAlbums.set(albumKey, {
			chat: String(msg.chat.id),
			ids: [msg.message_id],
			timer
		});
		return true;
	}
	dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
	dmDraft = {
		id: randomUUID(),
		srcChat: String(msg.chat.id),
		srcIds: [msg.message_id],
		buttons: []
	};
	await sendDmPreview(msg.chat.id);
	return true;
}
function collectDmAlbumItem(msg) {
	if (!msg.media_group_id) return false;
	const album = dmAlbums.get(`${msg.chat.id}:${msg.media_group_id}`);
	if (!album) return false;
	if (!album.ids.includes(msg.message_id)) album.ids.push(msg.message_id);
	return true;
}
async function updateDmStatus(job, final = false) {
	const done = readDone(job.id).size;
	const text = final ? [
		`<b>Рассылка пользователям ${job.stopped ? "остановлена" : "завершена"}</b>`,
		`Доставлено: ${job.sent}`,
		`Заблокировали бота / недоступны: ${job.blocked}`,
		job.failed ? `Ошибки: ${job.failed}` : "",
		`Обработано: ${done} из ${job.recipients.length}`
	].filter(Boolean).join("\n") : `<b>Идёт рассылка пользователям</b>: ${done} из ${job.recipients.length}\nДоставлено ${job.sent}, недоступны ${job.blocked}${job.failed ? `, ошибки ${job.failed}` : ""}`;
	const markup = final ? void 0 : { inline_keyboard: [[{
		text: "⏹ Остановить",
		callback_data: `adm:ubstop:${job.id}`
	}]] };
	if (job.statusMessage) {
		if (await tgSoft("editMessageText", {
			chat_id: job.statusChat,
			message_id: job.statusMessage,
			text,
			parse_mode: "HTML",
			reply_markup: markup
		}) || !final) return;
	}
	const sent = await tgSoft("sendMessage", {
		chat_id: job.statusChat,
		text,
		parse_mode: "HTML",
		reply_markup: markup
	});
	if (sent?.message_id && !final) {
		job.statusMessage = sent.message_id;
		saveDmJobs();
	}
}
async function runDmJob(job) {
	const done = readDone(job.id);
	let lastStatus = 0;
	await updateDmStatus(job);
	for (const chatId of job.recipients) {
		if (job.stopped) break;
		if (!isUserId(chatId) || done.has(chatId)) continue;
		appendFileSync(dmDonePath(job.id), `?${chatId}\n`);
		try {
			await sendDmCopy(chatId, job);
			job.sent += 1;
		} catch (err) {
			const text = String(err?.message || "");
			if (err instanceof TgError && (err.code === 403 || /blocked|deactivated|can't initiate|chat not found|user not found/i.test(text))) {
				job.blocked += 1;
				touchUser(chatId, true);
			} else job.failed += 1;
		}
		done.add(chatId);
		appendFileSync(dmDonePath(job.id), `${chatId}\n`);
		if (Date.now() - lastStatus > 4e3) {
			lastStatus = Date.now();
			saveDmJobs();
			await updateDmStatus(job);
		}
		await sleep(Math.max(45, 45 * job.srcIds.length));
	}
	await updateDmStatus(job, true);
	dmJobs = dmJobs.filter((j) => j.id !== job.id);
	saveDmJobs();
	try {
		unlinkSync(dmDonePath(job.id));
	} catch {}
}
function enqueueDmJob(job) {
	dmQueue = dmQueue.then(() => runDmJob(job)).catch((err) => console.error("[epb] user broadcast", err));
}
function resumeDmJobs() {
	for (const job of dmJobs) {
		if (Date.now() - job.startedAt > 864e5) continue;
		console.log(`[epb] resuming user broadcast ${job.id}: ${readDone(job.id).size} done`);
		enqueueDmJob(job);
	}
}
async function handleDmCallback(cb, action, arg) {
	const chatId = cb.message.chat.id;
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "ub") {
		await answer();
		await renderAdmin(cb, dmScreen());
		return true;
	}
	if (action === "ubnew") {
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Сначала дождитесь окончания текущей рассылки", true);
			return true;
		}
		await answer("Ответьте на сообщение бота тем, что нужно разослать");
		await askDmContent(chatId);
		return true;
	}
	if (action === "ubbtn") {
		await answer();
		if (!dmDraft) await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Черновик не найден. Начните заново: /admin"
		});
		else await askDmButtons(chatId);
		return true;
	}
	if (action === "ubclr") {
		if (dmDraft) dmDraft.buttons = [];
		await answer("Кнопки убраны");
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubcancel") {
		dmDraft = null;
		await answer("Рассылка отменена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: "Рассылка отменена."
		});
		return true;
	}
	if (action === "ubgo") {
		if (!dmDraft || dmDraft.id !== arg) {
			await answer("Этот черновик уже неактуален", true);
			return true;
		}
		await answer();
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Разослать это сообщение ${userStats().active} пользователям бота? Отменить уже отправленное будет нельзя.`,
			reply_markup: { inline_keyboard: [[{
				text: "✅ Да, разослать",
				callback_data: `adm:ubyes:${dmDraft.id}`
			}], [{
				text: "⬅ Назад",
				callback_data: "adm:ubback"
			}]] }
		});
		return true;
	}
	if (action === "ubback") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubyes") {
		if (!dmDraft || dmDraft.id !== arg || dmStarting.has(arg) || dmJobs.some((j) => j.id === arg)) {
			await answer("Эта рассылка уже запущена или отменена", true);
			return true;
		}
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Уже идёт другая рассылка", true);
			return true;
		}
		dmStarting.add(arg);
		const recipients = Object.entries(botUsers).filter(([id, u]) => isUserId(id) && !u.blocked).map(([id]) => id);
		const job = {
			...dmDraft,
			recipients,
			sent: 0,
			blocked: 0,
			failed: 0,
			startedAt: Date.now(),
			statusChat: String(chatId)
		};
		dmJobs.push(job);
		saveDmJobs();
		dmDraft = null;
		await answer("Рассылка запущена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Рассылка запущена: ${recipients.length} получателей.`
		});
		enqueueDmJob(job);
		return true;
	}
	if (action === "ubstop") {
		const job = dmJobs.find((j) => j.id === arg);
		if (job) {
			job.stopped = true;
			saveDmJobs();
		}
		await answer(job ? "Останавливаем…" : "Рассылка уже закончилась");
		return true;
	}
	return false;
}
var ADMIN_PAGE = 8;
var RELAY_FILTERS = [
	{
		key: "a",
		label: "Все",
		match: () => true
	},
	{
		key: "on",
		label: "✅ Вкл",
		match: (c) => c.status === "on"
	},
	{
		key: "pd",
		label: "⏳ Ждут",
		match: (c) => c.status === "pending"
	},
	{
		key: "off",
		label: "⛔ Выкл",
		match: (c) => c.status === "off"
	}
];
var statusIcon = (status) => status === "on" ? "✅" : status === "pending" ? "⏳" : "⛔";
var statusText = (status) => status === "on" ? "рассылка включена" : status === "pending" ? "ждёт решения" : "рассылка выключена";
function ago(ts) {
	if (!ts) return "давно";
	const min = Math.round((Date.now() - ts) / 6e4);
	if (min < 60) return `${Math.max(1, min)} мин назад`;
	const h = Math.round(min / 60);
	if (h < 48) return `${h} ч назад`;
	return `${Math.round(h / 24)} дн назад`;
}
function cut(text, max) {
	return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function pendingComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => (rec.status || "pending") === "pending").sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function publishedComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => rec.status === "published" && rec.channelPosted && !rec.deletedEverywhere).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function adminDeleteList(page) {
	const list = publishedComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => {
		const chats = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
		return [{
			text: `${cut(scamLabel(rec), 22)} · ${chats} чат. · ${ago(rec.createdAt)}`,
			callback_data: `adm:dlc:${key}`
		}];
	});
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:dl:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:dl:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:dl:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Удалить блеклист</b>: опубликовано ${list.length}\nВыберите запись — бот спросит подтверждение и удалит пост из канала и из всех чатов рассылки.` : "<b>Удалить блеклист</b>: опубликованных записей нет.",
		keyboard
	};
}
async function adminDeleteConfirm(key) {
	const rec = pendingPosts[key];
	const back = {
		text: "⬅ К списку",
		callback_data: "adm:dl:0"
	};
	if (!rec || rec.status !== "published") return {
		text: "Эта запись уже не опубликована.",
		keyboard: [[back]]
	};
	const chatCount = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
	const channelCount = rec.channelMsgIds?.length || 0;
	return {
		text: [
			"<b>Удалить блеклист везде?</b>",
			`Аккаунт: ${escapeHtml(scamLabel(rec))}`,
			`Ущерб: ${escapeHtml(rec.amount || "—")} ${escapeHtml(rec.currency || "")}`,
			"",
			`Будет удалено: пост в канале (${channelCount} сообщ.) и сообщения в ${chatCount} чатах рассылки.`,
			"Отменить удаление нельзя. Сообщения старше 48 часов Telegram может не дать удалить в некоторых чатах."
		].join("\n"),
		keyboard: [[{
			text: "🗑 Да, удалить везде",
			callback_data: `adm:dlgo:${key}`
		}], [back]]
	};
}
function adminHome() {
	const relays = bindings.relayChats || [];
	const all = Object.values(pendingPosts);
	const count = (st) => all.filter((r) => (r.status || "pending") === st).length;
	const last = bindings.lastBroadcast;
	return {
		text: [
			`<b>${CHANNEL_NAME} — панель</b>`,
			"",
			`<b>Заявки</b>: ждут решения ${count("pending")}, опубликовано ${count("published")}, отклонено ${count("rejected")}`,
			`<b>Чаты рассылки</b>: включено ${relays.filter((c) => c.status === "on").length}, ждут ${relays.filter((c) => c.status === "pending").length}, выключено ${relays.filter((c) => c.status === "off").length}`,
			`<b>Пользователи бота</b>: ${userStats().total} (заблокировали ${userStats().blocked})`,
			`<b>Канал</b>: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			last ? `<b>Последняя рассылка</b>: ${ago(last.at)}, доставлено ${last.sent} из ${last.total}` + (last.noRights ? `, без прав ${last.noRights}` : "") + (last.gone ? `, недоступно ${last.gone}` : "") : "<b>Последняя рассылка</b>: ещё не было"
		].join("\n"),
		keyboard: [
			[{
				text: `📝 Заявки без решения (${count("pending")})`,
				callback_data: "adm:ap:0"
			}],
			[{
				text: `🗑 Удалить блеклист (${count("published")})`,
				callback_data: "adm:dl:0"
			}],
			[{
				text: "📋 Чаты рассылки",
				callback_data: "adm:rl:a:0"
			}, {
				text: "⏳ Ждут решения",
				callback_data: "adm:rl:pd:0"
			}],
			[{
				text: "📢 Канал для постов",
				callback_data: "adm:ch"
			}],
			[{
				text: "📣 Рассылка пользователям бота",
				callback_data: "adm:ub"
			}],
			[{
				text: `🖼 Баннеры (${(bindings.banners || []).length})`,
				callback_data: "adm:bn"
			}],
			...checkEnabled() ? [
				[{
					text: "➕ Добавить юзера в блеклист",
					callback_data: "adm:bladd"
				}],
				[{
					text: "🧹 Убрать юзера из блеклиста",
					callback_data: "adm:ccrm"
				}],
				[{
					text: "🔎 Каналы для проверки",
					callback_data: "adm:cc"
				}]
			] : [],
			[{
				text: "🔄 Обновить",
				callback_data: "adm:home"
			}, {
				text: "✖ Закрыть",
				callback_data: "adm:x"
			}]
		]
	};
}
function adminRelayList(filter, page) {
	const f = RELAY_FILTERS.find((x) => x.key === filter) || RELAY_FILTERS[0];
	const list = (bindings.relayChats || []).filter(f.match);
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const slice = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE);
	const keyboard = [RELAY_FILTERS.map((x) => ({
		text: x.key === f.key ? `• ${x.label}` : x.label,
		callback_data: `adm:rl:${x.key}:0`
	})), ...slice.map((c) => [{
		text: `${statusIcon(c.status)} ${cut(c.title || c.id, 40)}`,
		callback_data: `adm:rc:${c.id}:${f.key}:${p}`
	}])];
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:rl:${f.key}:${p - 1}`
	});
	nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:rl:${f.key}:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:rl:${f.key}:${p + 1}`
	});
	keyboard.push(nav, [{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: [`<b>Чаты рассылки</b> — ${f.label}: ${list.length}`, list.length ? "Нажмите на чат, чтобы открыть карточку." : "Здесь пока пусто."].join("\n"),
		keyboard
	};
}
async function adminRelayCard(chatId, filter, page, note = "") {
	const relay = findRelay(chatId);
	const back = {
		text: "⬅ К списку",
		callback_data: `adm:rl:${filter}:${page}`
	};
	if (!relay) return {
		text: "Этого чата уже нет в списке.",
		keyboard: [[back]]
	};
	const suffix = `${relay.id}:${filter}:${page}`;
	const toggle = relay.status === "on" ? {
		text: "⛔ Выключить рассылку",
		callback_data: `adm:roff:${suffix}`
	} : {
		text: "✅ Включить рассылку",
		callback_data: `adm:ron:${suffix}`
	};
	return {
		text: [
			`<b>${escapeHtml(relay.title || "без названия")}</b>`,
			`ID: <code>${escapeHtml(relay.id)}</code>`,
			`Тип: ${chatKindLabel(relay.type)}`,
			`Статус: ${statusIcon(relay.status)} ${statusText(relay.status)}`,
			`Ссылка спонсора: ${relay.link ? `<code>${escapeHtml(relay.link)}</code>` : "не задана"}`,
			relay.requestedAt ? `Запрос: ${ago(relay.requestedAt)}` : "",
			note ? `\n${note}` : ""
		].filter(Boolean).join("\n"),
		keyboard: [
			[toggle],
			[{
				text: relay.link ? "🔗 Изменить ссылку спонсора" : "🔗 Задать ссылку спонсора",
				callback_data: `adm:rlink:${suffix}`
			}],
			[{
				text: "🔍 Проверить права бота",
				callback_data: `adm:rchk:${suffix}`
			}],
			[back]
		]
	};
}
async function botRightsNote(chatId) {
	const member = await tgSoft("getChatMember", {
		chat_id: chatId,
		user_id: Number(botToken().split(":")[0])
	});
	if (!member) return "❌ Бот не видит этот чат: его удалили или чат закрыт.";
	if (member.status === "left" || member.status === "kicked") return "❌ Бота в этом чате нет.";
	if ((await tgSoft("getChat", { chat_id: chatId }))?.type === "channel") return member.status === "administrator" && member.can_post_messages !== false ? "✅ Бот админ канала и может публиковать." : "⚠️ Бот не может публиковать в канале: нужен админ с правом публикации.";
	if (member.status === "restricted" && (member.can_send_messages === false || member.can_send_photos === false)) return "⚠️ Боту запрещено отправлять сообщения или медиа в этом чате.";
	return member.status === "administrator" || member.status === "creator" ? "✅ Бот админ, рассылка будет доходить." : "✅ Бот участник чата и может писать. Лучше выдать админа, чтобы медиа точно доходили.";
}
function adminPendingList(page) {
	const list = pendingComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => [{
		text: `${key} · ${cut(scamLabel(rec), 24)} · ${rec.amount} ${rec.currency} · ${ago(rec.createdAt)}`,
		callback_data: `adm:as:${key}`
	}]);
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:ap:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:ap:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:ap:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Заявки без решения</b>: ${list.length}\nНажмите на заявку — бот пришлёт её ещё раз с кнопками.` : "<b>Заявки без решения</b>: нет, все разобраны.",
		keyboard
	};
}
async function adminShowComplaint(arbiterChatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return false;
	const accounts = pendingAccounts(rec).map((a) => formatAccountLine(a.username, a.id, true)).join("\n");
	const parts = splitHtml([
		`<b>Заявка ${escapeHtml(key)}</b> (повтор из панели, ${ago(rec.createdAt)})`,
		"",
		`<b>Аккаунт</b>\n${accounts}`,
		`<b>Ущерб</b>\n${escapeHtml(rec.amount)} ${escapeHtml(rec.currency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(rec.summary || rec.story)}`,
		rec.files?.length ? `\nДоказательств: ${rec.files.length} (в исходной заявке, они уйдут в пост)` : ""
	].join("\n"));
	for (const [i, part] of parts.entries()) {
		const payload = {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: i === parts.length - 1 ? reviewKeyboard(key) : void 0
		};
		if (i === 0 && rec.reviewMessageId && rec.reviewChatId && sameChat(rec.reviewChatId, arbiterChatId)) payload.reply_parameters = {
			message_id: rec.reviewMessageId,
			allow_sending_without_reply: true
		};
		await tgSoft("sendMessage", payload);
	}
	return true;
}
function adminCheck() {
	const list = checkChannels();
	const ub = hasUserbot();
	const lines = [
		"<b>Каналы для проверки контрагента</b>",
		`Подключено: ${list.length}`,
		`Аккаунт (юзербот): ${ub ? "подключён ✅" : "не подключён"}`,
		"",
		ub ? "Поиск идёт через подключённый аккаунт по всем постам этих каналов, включая старые. Бота в каналы добавлять не нужно — аккаунт должен быть на них подписан." : "Сейчас бот индексирует только новые посты каналов, где он сам состоит. Чтобы искать по старым постам чужих каналов без добавления бота, подключите аккаунт (юзербот) — см. HOSTING.md."
	];
	const keyboard = list.map((c) => [{
		text: `🗑 ${cut(c.title || c.username || c.id, 36)}`,
		callback_data: `adm:ccdel:${c.id}`
	}]);
	keyboard.push([{
		text: "🔌 Проверить аккаунт",
		callback_data: "adm:ccping"
	}]);
	keyboard.push([{
		text: "🧹 Убрать жалобу из блеклиста",
		callback_data: "adm:ccrm"
	}]);
	keyboard.push([{
		text: "➕ Добавить канал",
		callback_data: "adm:ccadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
function adminBanners() {
	const list = bindings.banners || [];
	const lines = [
		"<b>Баннеры в мини-аппе</b>",
		`Сейчас: ${list.length} из ${MAX_BANNERS}`,
		"",
		list.length ? "Баннеры показываются сверху в приложении. Видео и GIF идут без звука и по кругу. Тап по баннеру открывает ссылку." : "Пока нет ни одного баннера. Нажмите «Добавить баннер», пришлите картинку / видео / GIF, затем ссылку."
	];
	const keyboard = list.map((b, i) => [{
		text: `🗑 ${i + 1}. ${b.type === "video" ? "🎞" : "🖼"} ${cut(b.link || "без ссылки", 34)}`,
		callback_data: `adm:bndel:${b.id}`
	}]);
	if (list.length < MAX_BANNERS) keyboard.push([{
		text: "➕ Добавить баннер",
		callback_data: "adm:bnadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function handleBannerInput(msg) {
	const key = String(msg.chat.id);
	const st = bannerSetup.get(key);
	if (!st) return false;
	if (st.phase === "media") {
		const media = extractBannerMedia(msg);
		if (!media) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Пришлите картинку, видео или GIF одним сообщением (не текстом). Или /admin, чтобы выйти."
			});
			return true;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Загружаю медиа…"
		});
		const bytes = await downloadTelegramFile(media.fileId);
		if (!bytes) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Не удалось загрузить файл. Для баннера подойдёт картинка / видео / GIF до 20 МБ. Пришлите ещё раз."
			});
			return true;
		}
		const id = newBannerId();
		saveBannerFile(id, bytes);
		st.draft = {
			type: media.type,
			file: id,
			mime: media.mime,
			width: media.width,
			height: media.height
		};
		st.phase = "link";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа сохранено. Теперь пришлите ссылку (https://… или t.me/…), которая откроется по тапу на баннер.\nЕсли ссылка не нужна — отправьте «-»."
		});
		return true;
	}
	if (!msg.text) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пришлите ссылку текстом (https://…) или «-», чтобы без ссылки."
		});
		return true;
	}
	const link = normalizeBannerLink(msg.text);
	if (link === null) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Это не похоже на ссылку. Пришлите адрес вида https://… или t.me/…, либо «-» без ссылки."
		});
		return true;
	}
	const draft = st.draft;
	bannerSetup.delete(key);
	if (!draft) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа не найдено, начните заново: /admin → Баннеры."
		});
		return true;
	}
	const banner = {
		id: draft.file,
		type: draft.type,
		file: draft.file,
		mime: draft.mime,
		link,
		width: draft.width,
		height: draft.height,
		createdAt: Date.now()
	};
	bindings.banners = [...bindings.banners || [], banner].slice(-20);
	saveBindings();
	const view = adminBanners();
	await tgSoft("sendMessage", {
		chat_id: msg.chat.id,
		text: `Баннер добавлен${link ? "" : " (без ссылки)"}.\n\n${view.text}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
	return true;
}
async function applySponsorLink(arbiterChatId, raw) {
	const st = sponsorLinkSetup.get(String(arbiterChatId));
	sponsorLinkSetup.delete(String(arbiterChatId));
	if (!st) return;
	const res = setSponsorLink(st.relayId, raw);
	if (res === "bad") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не похоже на ссылку. Пришлите https://… или t.me/…, либо «-», чтобы убрать."
		});
		return;
	}
	const view = await adminRelayCard(st.relayId, st.filter, st.page, res === "set" ? "Ссылка спонсора сохранена." : "Ссылка спонсора убрана.");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function applyRemoveFromCheck(arbiterChatId, raw) {
	removeFromCheckSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	let removed = 0;
	const epbId = text.match(/\b(EPB-[A-Za-z0-9]+)\b/i)?.[1];
	if (epbId) {
		const rec = pendingPosts[epbId] || pendingPosts[epbId.toUpperCase()];
		if (rec && !rec.removedFromCheck) {
			rec.removedFromCheck = true;
			removed = 1;
		}
	} else {
		const parsed = parseTelegramInput(text);
		const uname = parsed.username.replace(/^@/, "").toLowerCase();
		const id = parsed.id;
		if (!uname && !id) {
			await tgSoft("sendMessage", {
				chat_id: arbiterChatId,
				text: "Не понял. Пришлите EPB-… или @username / ID."
			});
			return;
		}
		for (const rec of Object.values(pendingPosts)) {
			if (rec.removedFromCheck) continue;
			const accounts = pendingAccounts(rec);
			if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) {
				rec.removedFromCheck = true;
				removed += 1;
			}
		}
		const manual = bindings.manualBlacklist || [];
		const keptManual = manual.filter((e) => {
			const eu = (e.username || "").replace(/^@/, "").toLowerCase();
			return !(uname && eu === uname || id && e.telegramId === id);
		});
		if (keptManual.length !== manual.length) {
			removed += manual.length - keptManual.length;
			bindings.manualBlacklist = keptManual;
			saveBindings();
		}
	}
	if (removed) savePending();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: removed ? `Убрано из блеклиста: ${removed}. В проверке контрагента больше не показывается.` : "Ничего подходящего не нашёл."
	});
}
async function applyAddToBlacklist(arbiterChatId, raw) {
	addBlacklistSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	const firstTok = text.split(/\s+/)[0] || "";
	const note = text.slice(firstTok.length).trim();
	const parsed = parseTelegramInput(firstTok);
	const username = parsed.username.replace(/^@/, "");
	const id = parsed.id;
	if (!username && !id) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не понял. Пришлите @username или ID, можно с комментарием через пробел."
		});
		return;
	}
	const entry = {
		id: randomUUID(),
		username: username || void 0,
		telegramId: id || void 0,
		source: DEFAULT_MANUAL_SOURCE,
		note: note || void 0,
		addedAt: Date.now()
	};
	bindings.manualBlacklist = [...bindings.manualBlacklist || [], entry].slice(-5e3);
	saveBindings();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Добавлено в блеклист (проверка контрагента).",
			`Аккаунт: ${escapeHtml(username ? `@${username}` : `ID ${id}`)}`,
			`Источник: ${escapeHtml(DEFAULT_MANUAL_SOURCE)}`,
			note ? `Комментарий: ${escapeHtml(note)}` : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML"
	});
}
async function applyCheckChannel(arbiterChatId, raw) {
	checkChannelSetup.delete(String(arbiterChatId));
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала (-100…) или @username."
		});
		return;
	}
	let entry = null;
	const chat = await chatReachable(ref);
	if (chat && (chat.type === "channel" || chat.type === "supergroup")) entry = {
		id: String(chat.id),
		title: chat.title,
		username: chat.username,
		addedAt: Date.now()
	};
	else if (hasUserbot()) entry = await resolveChannelAsUser(String(ref));
	if (!entry) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: hasUserbot() ? "Не удалось открыть этот канал. Подключённый аккаунт должен быть подписан на него. Пришлите @username или ID ещё раз." : "Не вижу этот канал. Добавьте бота в канал (участником или админом) и пришлите ID ещё раз — или подключите аккаунт (юзербот), тогда бота добавлять не нужно."
		});
		return;
	}
	if (isOfficialChannel(entry.id) || isOfficialArbiterChat(entry.id)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный канал бота, добавлять его не нужно."
		});
		return;
	}
	const list = [...checkChannels()];
	if (!list.some((c) => sameChat(c.id, entry.id))) {
		list.push(entry);
		bindings.checkChannels = list.slice(-100);
		saveBindings();
	}
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал подключён для проверки.",
			escapeHtml(entry.title || entry.id),
			`ID: <code>${escapeHtml(entry.id)}</code>`,
			"",
			hasUserbot() ? "Поиск по этому каналу идёт через подключённый аккаунт, включая старые посты." : "Новые посты этого канала будут попадать в поиск. Для старых постов подключите аккаунт (юзербот)."
		].join("\n"),
		parse_mode: "HTML"
	});
}
function adminChannel() {
	return {
		text: [
			"<b>Канал для постов</b>",
			`Сейчас: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			"",
			"Чтобы сменить: нажмите кнопку и пришлите ID канала (-100…) или @username следующим сообщением. Бот должен быть админом канала."
		].join("\n"),
		keyboard: [[{
			text: "✏ Сменить канал",
			callback_data: "adm:chset"
		}], [{
			text: "⬅ В меню",
			callback_data: "adm:home"
		}]]
	};
}
async function sendAdminPanel(chatId) {
	const view = adminHome();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function renderAdmin(cb, view) {
	if (!cb.message) return;
	return await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function handleAdminCallback(cb) {
	const chatId = cb.message.chat.id;
	const [, action = "home", ...rest] = (cb.data || "").split(":");
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "x") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		return;
	}
	if (action === "home") {
		await answer();
		await renderAdmin(cb, adminHome());
		return;
	}
	if (action.startsWith("ub") && await handleDmCallback(cb, action, rest[0] || "")) return;
	if (action === "rl") {
		await answer();
		await renderAdmin(cb, adminRelayList(rest[0] || "a", Number(rest[1] || 0)));
		return;
	}
	const [target = "", filter = "a", page = "0"] = rest;
	if (action === "rc") {
		await answer();
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "ron" || action === "roff") {
		const relay = findRelay(target);
		if (!relay) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		upsertRelay({
			id: relay.id,
			title: relay.title,
			type: relay.type
		}, action === "ron" ? "on" : "off");
		if (action === "ron") await tgSoft("sendMessage", {
			chat_id: relay.id,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await answer(action === "ron" ? "Рассылка включена" : "Рассылка выключена");
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "rchk") {
		await answer("Проверяем…");
		await renderAdmin(cb, await adminRelayCard(target, filter, page, await botRightsNote(target)));
		return;
	}
	if (action === "rlink") {
		if (!findRelay(target)) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		sponsorLinkSetup.set(String(chatId), {
			relayId: target,
			filter,
			page
		});
		await answer("Пришлите ссылку");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ссылку на чат (https://… или t.me/…), которая будет прикреплена к названию на странице «Спонсоры проекта». Чтобы убрать ссылку — отправьте «-»."
		});
		return;
	}
	if (action === "ap") {
		await answer();
		await renderAdmin(cb, adminPendingList(Number(rest[0] || 0)));
		return;
	}
	if (action === "as") {
		const key = rest[0] || "";
		const shown = (pendingPosts[key]?.status || "pending") === "pending" && await adminShowComplaint(chatId, key);
		await answer(shown ? "Заявка отправлена ниже" : "Заявка уже обработана", !shown);
		if (!shown) await renderAdmin(cb, adminPendingList(0));
		return;
	}
	if (action === "cc") {
		await answer();
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "ccping") {
		await answer("Проверяем аккаунт…");
		const st = await userbotStatus();
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: st.ok ? `Аккаунт подключён: ${escapeHtml(st.name || "аккаунт")}` : `Аккаунт не подключён: ${escapeHtml(st.error || "ошибка")}`
		});
		return;
	}
	if (action === "ccrm") {
		removeFromCheckSetup.add(String(chatId));
		await answer("Пришлите номер жалобы или аккаунт");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите номер жалобы (EPB-…) либо @username / ID аккаунта, который нужно убрать из блеклиста (поиска). Жалоба останется в истории, но перестанет находиться в проверке контрагента."
		});
		return;
	}
	if (action === "bladd") {
		addBlacklistSetup.add(String(chatId));
		await answer("Пришлите @username или ID");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите @username или ID аккаунта, которого нужно добавить в блеклист (проверку контрагента). Можно с комментарием через пробел, например:\n@scammer кинул на сделке, инфа из чужого блеклиста\n\nИсточник отметится как «Сторонний источник»."
		});
		return;
	}
	if (action === "ccadd") {
		checkChannelSetup.add(String(chatId));
		await answer("Пришлите ID канала следующим сообщением");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ID канала (-100…) или @username для проверки. Бот должен быть в этом канале."
		});
		return;
	}
	if (action === "ccdel") {
		const target = rest.join(":");
		bindings.checkChannels = checkChannels().filter((c) => !sameChat(c.id, target));
		saveBindings();
		removeCheckChannelFromIndex(target);
		await answer("Канал убран");
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "dl") {
		await answer();
		await renderAdmin(cb, adminDeleteList(Number(rest[0] || 0)));
		return;
	}
	if (action === "dlc") {
		await answer();
		await renderAdmin(cb, await adminDeleteConfirm(rest.join(":")));
		return;
	}
	if (action === "dlgo") {
		const delKey = rest.join(":");
		if (!pendingPosts[delKey] || pendingPosts[delKey].status !== "published") {
			await answer("Запись уже удалена", true);
			await renderAdmin(cb, adminDeleteList(0));
			return;
		}
		await answer("Удаляю во всех чатах…");
		const res = await deletePublishedEverywhere(delKey);
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: [
				"Блеклист удалён.",
				`Канал: удалено ${res.channel.ok}${res.channel.fail ? `, не удалось ${res.channel.fail}` : ""}.`,
				`Чаты рассылки (${res.chatCount}): удалено ${res.chats.ok}${res.chats.fail ? `, не удалось ${res.chats.fail}` : ""}.`,
				res.channel.fail || res.chats.fail ? "Часть сообщений не удалилась — вероятно, они старше 48 часов или у бота нет прав на удаление в чате." : ""
			].filter(Boolean).join("\n")
		});
		await renderAdmin(cb, adminDeleteList(0));
		return;
	}
	if (action === "bn") {
		bannerSetup.delete(String(chatId));
		await answer();
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "bnadd") {
		if ((bindings.banners || []).length >= MAX_BANNERS) {
			await answer("Достигнут лимит баннеров", true);
			await renderAdmin(cb, adminBanners());
			return;
		}
		bannerSetup.set(String(chatId), { phase: "media" });
		await answer("Пришлите медиа для баннера");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите картинку, видео или GIF для баннера (до 20 МБ). Следующим сообщением попрошу ссылку."
		});
		return;
	}
	if (action === "bndel") {
		removeBannerById(rest.join(":"));
		await answer("Баннер удалён");
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "ch") {
		await answer();
		await renderAdmin(cb, adminChannel());
		return;
	}
	if (action === "chset") {
		await answer("Пришлите ID канала следующим сообщением");
		await askPublishChannel(chatId);
		return;
	}
	await answer();
}
function relayListHtml() {
	const list = bindings.relayChats || [];
	const by = (status) => list.filter((c) => c.status === status);
	const line = (c) => `• ${escapeHtml(c.title || "без названия")} — <code>${escapeHtml(c.id)}</code>`;
	const lines = [
		`<b>Чаты рассылки</b>: включено ${by("on").length}, ждут решения ${by("pending").length}, выключено ${by("off").length}`,
		"",
		"<b>Включены</b>",
		...by("on").length ? by("on").map(line) : ["—"]
	];
	if (by("pending").length) lines.push("", "<b>Ждут решения</b>", ...by("pending").map(line));
	lines.push("", "Включить вручную: /relay_on -100…", "Выключить: /relay_off -100…");
	return splitHtml(lines.join("\n"));
}
async function handleRelayCommand(arbiterChatId, cmd, arg) {
	if (cmd === "relays") {
		for (const part of relayListHtml()) await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true
		});
		return;
	}
	const raw = arg.trim().split(/\s+/)[0] || "";
	if (!/^-\d{5,20}$/.test(raw)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: `Укажите ID чата: /${cmd} -100…\nСписок: /relays`
		});
		return;
	}
	const chat = await tgSoft("getChat", { chat_id: raw });
	if (cmd === "relay_on" && !chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Бот не видит этот чат. Сначала добавьте бота в чат, потом повторите команду."
		});
		return;
	}
	if (chat && (isOfficialArbiterChat(chat.id) || isOfficialChannel(chat.id))) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный чат, рассылка туда не нужна."
		});
		return;
	}
	const target = chat ? {
		id: chat.id,
		type: chat.type,
		title: chat.title
	} : { id: raw };
	upsertRelay(target, cmd === "relay_on" ? "on" : "off");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: `${cmd === "relay_on" ? "Рассылка включена" : "Рассылка выключена"}: ${escapeHtml(chat?.title || raw)}\nID: <code>${escapeHtml(String(target.id))}</code>`,
		parse_mode: "HTML"
	});
}
async function parseChannelRef(raw) {
	const t = raw.trim().split(/\s+/)[0] || "";
	if (!t) return null;
	if (t.startsWith("@")) return t;
	const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
	if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
	const num = t.replace(/[^\d-]/g, "");
	if (/^-100\d{6,}$/.test(num)) return num;
	if (/^100\d{6,}$/.test(num)) return `-${num}`;
	if (/^\d{6,}$/.test(num)) return `-100${num}`;
	return t;
}
async function applyPublishChannel(arbiterChatId, raw) {
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
			parse_mode: "HTML"
		});
		return;
	}
	const chat = await chatReachable(ref);
	if (!chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз."
		});
		return;
	}
	if (chat.type !== "channel" && chat.type !== "supergroup") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не канал. Нужен ID канала, куда постить одобренные заявки."
		});
		return;
	}
	bindings.channelId = String(chat.id);
	saveBindings();
	channelSetup.delete(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал для постов обновлён.",
			escapeHtml(chat.title || "Канал"),
			`ID: <code>${chat.id}</code>`
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function askPublishChannel(arbiterChatId) {
	channelSetup.add(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			`Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
			"",
			"Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
			"Бот должен быть админом этого канала.",
			"",
			"Или сразу: /channel -100…"
		].join("\n"),
		parse_mode: "HTML"
	});
}
var seenUpdates = /* @__PURE__ */ new Set();
async function handleUpdate(update) {
	if (typeof update?.update_id === "number") {
		if (seenUpdates.has(update.update_id)) return;
		seenUpdates.add(update.update_id);
		if (seenUpdates.size > 5e3) seenUpdates.delete(seenUpdates.values().next().value);
	}
	try {
		await handleTelegramUpdate(update);
	} catch (err) {
		if (!isDisconnectError(err)) console.error("[epb] update", err);
	}
}
async function handleTelegramUpdate(update) {
	ensureBotProfile();
	const post = update.channel_post || update.edited_channel_post;
	if (post) {
		const ch = isCheckChannel(post.chat.id);
		if (ch) {
			if (post.chat.title && post.chat.title !== ch.title) {
				ch.title = post.chat.title;
				saveBindings();
			}
			indexCheckPost(ch, post.message_id, post.text || post.caption || "", post.date || 0);
		}
		return;
	}
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.message?.reply_to_message?.from);
	rememberUser(update.message?.reply_to_message?.forward_from);
	rememberUser(update.callback_query?.from);
	for (const ent of [
		...update.message?.entities || [],
		...update.message?.caption_entities || [],
		...update.message?.reply_to_message?.entities || []
	]) rememberUser(ent.user);
	const groupMsg = update.message;
	if (groupMsg && (groupMsg.chat.type === "group" || groupMsg.chat.type === "supergroup")) {
		if (groupMsg.migrate_to_chat_id) onChatMigrated(String(groupMsg.chat.id), String(groupMsg.migrate_to_chat_id));
		if (groupMsg.migrate_from_chat_id) onChatMigrated(String(groupMsg.migrate_from_chat_id), String(groupMsg.chat.id));
		if (!isOfficialArbiterChat(groupMsg.chat.id)) return;
	}
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "");
	const liveSession = sessions.get(floodId);
	const incoming = update.message;
	const evidenceBurst = liveSession?.step === "evidence" && Boolean(incoming?.photo?.length || incoming?.video || incoming?.document);
	if (tooMany("upd:global", 600, 6e4)) return;
	if (floodId && !evidenceBurst && tooMany(`flood:${floodId}`, 80, 6e4)) return;
	if (liveSession) liveSession.touched = Date.now();
	gcSessions();
	if (update.message?.chat.type === "private") touchUser(update.message.from?.id);
	if (update.callback_query?.message?.chat.type === "private") touchUser(update.callback_query.from?.id);
	const member = update.my_chat_member;
	if (member) {
		if (member.chat.type === "private") {
			touchUser(member.chat.id, member.new_chat_member.status === "kicked");
			return;
		}
		if (!isGroupOrChannel(member.chat)) return;
		const status = member.new_chat_member.status;
		if (status === "left" || status === "kicked") {
			dropRelay(member.chat.id);
			return;
		}
		if (status === "member" || status === "administrator" || status === "creator") {
			const before = member.old_chat_member?.status;
			await bindChat(member.chat, member.from, !before || before === "left" || before === "kicked");
		}
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if (cb.data === "owners") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, ownersText(locale), ownersKeyboard(locale));
			return;
		}
		if (cb.data === "home") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			return;
		}
		if (cb.data === "lang") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await editCard(cb, LANG_PROMPT, langKeyboard(true));
			return;
		}
		if (cb.data === "lang:ru" || cb.data === "lang:en") {
			const locale = cb.data.endsWith("en") ? "en" : "ru";
			if (cb.from?.id) setLang(cb.from.id, locale);
			tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: tb(locale, "langSaved")
			});
			if (Boolean(cb.message.photo || cb.message.caption)) await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			else {
				tgSoft("deleteMessage", {
					chat_id: cb.message.chat.id,
					message_id: cb.message.message_id
				});
				await replyStart(cb.message.chat.id, cb.from?.id);
			}
			return;
		}
		if (cb.data.startsWith("ub:")) {
			if (await handleOwnerCallback(cb)) return;
		}
		if (cb.data.startsWith("adm:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleAdminCallback(cb);
			return;
		}
		if (cb.data.startsWith("rel:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
			return;
		}
		if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:") || /^p(edit|view|orig):/.test(cb.data)) && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (alreadyHandled(text)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub" || cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch")) {
			const markup = publishChoiceKeyboard(parseAppKey(text, cb.data));
			if (!await replaceReplyMarkup(cb.message, markup)) await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: "Как опубликовать эту заявку?",
				reply_to_message_id: cb.message.message_id,
				reply_markup: markup
			});
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Выберите тип публикации"
			});
			return;
		}
		if (/^p(edit|view|orig):/.test(cb.data)) {
			const [action, key = ""] = cb.data.split(":");
			const rec = pendingPosts[key];
			if (!rec || (rec.status || "pending") !== "pending") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже обработана",
					show_alert: true
				});
				return;
			}
			if (action === "pedit") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Ответьте на сообщение бота новым текстом"
				});
				await askPostEdit(cb.message.chat.id, key);
			} else if (action === "pview") {
				await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			} else {
				delete rec.postHtml;
				savePending();
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Вернули исходный текст"
				});
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			}
			return;
		}
		if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			const relay = cb.data.startsWith("puball");
			const key = parseAppKey(text, cb.data);
			if (!await publishFromMessage(key && pendingPosts[key] ? `#epb u=${pendingPosts[key].username || ""} id=${pendingPosts[key].id || "0"} k=${key}` : text, cb.id, extraFiles, relay, key, {
				chatId: cb.message.chat.id,
				messageId: cb.message.message_id
			})) return;
			const next = `${escapeHtml(stripServiceMarker(text || "Заявка"))}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
			const cleared = { inline_keyboard: [] };
			if (!await replaceReplyMarkup(cb.message, cleared, next)) await tgSoft("editMessageReplyMarkup", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				reply_markup: cleared
			});
			return;
		}
		if (cb.data === "rej" || cb.data.startsWith("rej:")) {
			const key = parseAppKey(text, cb.data);
			const record = key ? pendingPosts[key] : void 0;
			if (record?.status === "published" || key && publishing.has(key)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже опубликована",
					show_alert: true
				});
				return;
			}
			if (record && record.status !== "rejected") {
				record.status = "rejected";
				savePending();
				await notifyApplicant(record, key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${escapeHtml(stripServiceMarker(text))}\n\nСтатус: отклонено`;
			await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		const fromId = msg.from?.id;
		if (fromId && !hasLang(fromId)) {
			await askLanguage(msg.chat.id);
			return;
		}
		await replyStart(msg.chat.id, fromId);
		return;
	}
	if (cmd === "lang") {
		await askLanguage(msg.chat.id, hasLang(msg.from?.id));
		return;
	}
	if (cmd === "channel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
		if (arg) await applyPublishChannel(msg.chat.id, arg);
		else await askPublishChannel(msg.chat.id);
		return;
	}
	if (cmd === "admin" || cmd === "menu" || cmd === "panel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await sendAdminPanel(msg.chat.id);
		return;
	}
	if (cmd === "checkon" || cmd === "checkoff") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		bindings.checkEnabled = cmd === "checkon";
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: cmd === "checkon" ? "Проверка контрагента включена." : "Проверка контрагента выключена и скрыта."
		});
		return;
	}
	if (cmd === "audience") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const n = Number((msg.text || "").replace(/[^\d]/g, ""));
		if (!setAudienceBase(n)) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Укажите число, например: /audience 20178"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `Базовая аудитория обновлена: ~${n.toLocaleString("ru-RU")}. Показывается в приложении (с учётом реального числа участников чатов).`
		});
		return;
	}
	if (cmd === "emoji") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim().toLowerCase();
		if (arg === "on" || arg === "off") {
			bindings.customEmoji = arg === "on";
			saveBindings();
		}
		const state = customEmojiEnabled() ? "включены" : "выключены";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: arg === "on" || arg === "off" ? `Премиум-эмодзи ${state}. Работают в личных сообщениях бота (меню и шаги жалобы), пока у владельца активен Telegram Premium.` : `Премиум-эмодзи сейчас ${state}. Включить: /emoji on · выключить: /emoji off`
		});
		return;
	}
	if (cmd === "usearch") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim();
		if (!arg) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Проверка поиска по юзернейму. Пришлите: /usearch @username"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Проверяю поиск…"
		});
		const report = await diagnoseUserSearch(arg);
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: report
		});
		return;
	}
	if (cmd === "userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id) || !checkEnabled()) return;
		await sendOwnerPanel(msg.chat.id);
		return;
	}
	if (cmd === "cancel_userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		await loginStates.get(String(msg.chat.id))?.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(msg.chat.id));
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Подключение отменено."
		});
		return;
	}
	if (cmd === "relays" || cmd === "relay_on" || cmd === "relay_off") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await handleRelayCommand(msg.chat.id, cmd, (msg.text || "").split(/\s+/).slice(1).join(" "));
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: btUser(msg.from?.id, "applyInGroup", { bot: BOT_USERNAME })
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) return;
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда.",
					"",
					`Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
					"Сменить: /channel -100…"
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && bannerSetup.has(String(msg.chat.id)) && await handleBannerInput(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && collectDmAlbumItem(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handleDmReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handlePostEditReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && removeFromCheckSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyRemoveFromCheck(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && addBlacklistSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyAddToBlacklist(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && sponsorLinkSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applySponsorLink(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && checkChannelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyCheckChannel(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyPublishChannel(msg.chat.id, msg.text);
		return;
	}
	if (msg.chat.type !== "private") return;
	if (isOwner(msg.from?.id) && !cmd && ownerLoginActive(msg.chat.id) && msg.text) {
		if (await handleOwnerLogin(msg.chat.id, msg.text)) return;
	}
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	if (await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: webhookSecret(),
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member",
			"channel_post",
			"edited_channel_post"
		],
		drop_pending_updates: false
	})) {
		bindings.webhookStamp = webhookStamp();
		saveBindings();
	}
	return {
		ok: true,
		url: clean
	};
}
var webhookArmed = false;
async function configureFromOrigin(_origin) {
	const site = publicSiteUrl();
	if (!site) return {
		configured: false,
		reason: "need_https"
	};
	if (!webhookArmed) {
		webhookArmed = true;
		ensureProductionWebhook();
	}
	return {
		configured: true,
		url: site
	};
}
if (botToken() && (process.env.PUBLIC_URL || true)) setTimeout(() => void ensureBotProfile().catch(() => {}), 3e3);
if (botToken() && broadcastJobs.length) setTimeout(resumeBroadcasts, 5e3);
if (botToken() && dmJobs.length) setTimeout(resumeDmJobs, 6e3);
//#endregion
export { parseDamageAmount as C, waitForTelegramUser as D, telegramInitData as E, openExternal as S, readTelegramWebUser as T, CHANNEL_URL as _, bannerById as a, lockTelegramViewport as b, isDisconnectError as c, sponsorAvatarPath as d, telegram_bot_server_exports as f, webhookSecretMatches as g, verifyTelegramInitData as h, appendEvidenceChunk as i, resolveHandleServer as l, verifyEvidenceDownload as m, allowEvidenceDownload as n, bannerFilePath as o, uploadedEvidencePath as p, allowEvidenceUpload as r, handleUpdate as s, allowEvidenceChunk as t, saveUploadedEvidence as u, bootTelegramWebApp as v, parseTelegramInput as w, lookupTelegramHandle as x, haptic as y };
