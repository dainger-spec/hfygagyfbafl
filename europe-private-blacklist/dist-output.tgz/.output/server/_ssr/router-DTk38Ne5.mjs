import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { a as handleUpdate, c as saveUploadedEvidence, d as verifyEvidenceDownload, f as verifyTelegramInitData, i as appendEvidenceChunk, n as allowEvidenceDownload, o as isDisconnectError, p as webhookSecretMatches, r as allowEvidenceUpload, s as resolveHandleServer, t as allowEvidenceChunk, u as uploadedEvidencePath } from "./telegram-bot.server-DUCskWAZ.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as object, i as number, o as string, r as literal, s as union } from "../_libs/zod.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { Readable } from "node:stream";
import { createReadStream, statSync } from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DTk38Ne5.js
var router_DTk38Ne5_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-C1ah6X_Q.css";
var APP_NAME = "Europe Private Blacklist";
var TG_BOOT = `(function(){try{var h=location.hash||"";if(h.indexOf("tgWebApp")!==-1){try{sessionStorage.setItem("__tg_hash",h);}catch(e){}}else{var s="";try{s=sessionStorage.getItem("__tg_hash")||"";}catch(e){}if(s){history.replaceState(null,"",location.pathname+location.search+s);h=s;}}var q=new URLSearchParams(h.replace(/^#/,""));var d=q.get("tgWebAppData");if(!d)return;var u=new URLSearchParams(d).get("user");if(!u)return;window.__EPB_TG_USER=JSON.parse(u);}catch(e){}})();`;
var Route$4 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#080808"
			},
			{
				name: "description",
				content: "Закрытый европейский блеклист. Заявка, арбитраж, публикация."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		],
		scripts: [{ children: TG_BOOT }, { src: "https://telegram.org/js/telegram-web-app.js" }]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ru",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-bg font-sans text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter = () => import("./routes-C_usjPs_.mjs");
var Route$3 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var MAX_POST_BYTES = 2193152;
var Route$2 = createFileRoute("/api/telegram/evidence")({ server: { handlers: {
	GET: async ({ request }) => {
		if (!allowEvidenceDownload()) return new Response("too many requests", { status: 429 });
		const url = new URL(request.url);
		const key = url.searchParams.get("key") || "";
		const exp = url.searchParams.get("exp") || "";
		const sig = url.searchParams.get("sig") || "";
		if (!verifyEvidenceDownload(key, exp, sig)) return new Response("forbidden", { status: 403 });
		const path = uploadedEvidencePath(key);
		if (!path) return new Response("not found", { status: 404 });
		const stat = statSync(path);
		const stream = Readable.toWeb(createReadStream(path));
		return new Response(stream, { headers: {
			"content-type": "application/octet-stream",
			"content-disposition": "attachment; filename=\"evidence.bin\"",
			"x-content-type-options": "nosniff",
			"content-security-policy": "default-src 'none'",
			"x-frame-options": "DENY",
			"content-length": String(stat.size),
			"cache-control": "private, no-store"
		} });
	},
	POST: async ({ request }) => {
		try {
			const declared = Number(request.headers.get("content-length") || 0);
			if (!declared || declared > MAX_POST_BYTES) return Response.json({
				ok: false,
				error: "too large"
			}, { status: 413 });
			const form = await request.formData();
			const id = String(form.get("id") || "");
			const initData = String(form.get("initData") || request.headers.get("x-telegram-init-data") || "");
			const chunk = form.get("chunk");
			const file = form.get("file");
			const blob = chunk instanceof Blob && chunk.size ? chunk : file instanceof Blob ? file : null;
			if (!blob) return Response.json({
				ok: false,
				error: "file required"
			}, { status: 400 });
			const index = Number(form.get("index") || 0);
			const total = Number(form.get("total") || 1);
			const gate = index === 0 ? allowEvidenceUpload(initData, blob.size) : allowEvidenceChunk(initData, blob.size);
			if (!gate.ok) return Response.json({
				ok: false,
				error: gate.error
			}, { status: gate.error === "telegram auth required" ? 401 : 429 });
			const bytes = Buffer.from(await blob.arrayBuffer());
			if (bytes.length > 2097152) return Response.json({
				ok: false,
				error: "chunk too large"
			}, { status: 413 });
			if (total <= 1 && !(chunk instanceof Blob)) {
				const storageKey = saveUploadedEvidence(gate.userId, bytes);
				return Response.json({
					ok: true,
					storageKey
				});
			}
			const storageKey = appendEvidenceChunk(gate.userId, id, index, Math.max(1, total), bytes);
			return Response.json({
				ok: true,
				storageKey: storageKey || void 0
			});
		} catch (err) {
			if (isDisconnectError(err)) return Response.json({
				ok: false,
				error: "upload aborted"
			}, { status: 400 });
			const msg = err instanceof Error ? err.message : "";
			if (msg === "forbidden") return Response.json({
				ok: false,
				error: "forbidden"
			}, { status: 403 });
			if (msg === "not media") return Response.json({
				ok: false,
				error: "only photos and videos"
			}, { status: 400 });
			console.error("[epb] evidence", err);
			return Response.json({
				ok: false,
				error: "upload failed"
			}, { status: 500 });
		}
	}
} } });
var Route$1 = createFileRoute("/api/telegram/resolve")({ server: { handlers: { POST: async ({ request }) => {
	const body = await request.json().catch(() => ({}));
	if (!verifyTelegramInitData(String(body.initData || ""))) return Response.json({
		ok: false,
		error: "telegram auth required"
	}, { status: 401 });
	const input = String(body.input || "").slice(0, 200).trim();
	if (!input) return Response.json({
		ok: false,
		error: "empty"
	}, { status: 400 });
	const result = await resolveHandleServer(input);
	return Response.json(result || {
		username: "",
		id: "",
		source: "unresolved"
	});
} } } });
var MAX_WEBHOOK_BYTES = 256e3;
async function readJsonCapped(request, max) {
	if (Number(request.headers.get("content-length") || 0) > max) return { status: 413 };
	if (!request.body) return { status: 400 };
	const reader = request.body.getReader();
	const chunks = [];
	let size = 0;
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		size += value.byteLength;
		if (size > max) {
			try {
				await reader.cancel();
			} catch {}
			return { status: 413 };
		}
		chunks.push(value);
	}
	try {
		const text = Buffer.concat(chunks.map((c) => Buffer.from(c))).toString("utf8");
		return { json: JSON.parse(text) };
	} catch {
		return { status: 400 };
	}
}
var Route = createFileRoute("/api/telegram/webhook")({ server: { handlers: {
	GET: async () => new Response("not found", { status: 404 }),
	POST: async ({ request }) => {
		try {
			const secret = request.headers.get("x-telegram-bot-api-secret-token");
			const poller = webhookSecretMatches(request.headers.get("x-epb-poller"));
			if (!webhookSecretMatches(secret) && !poller) return new Response("forbidden", { status: 403 });
			const body = await readJsonCapped(request, MAX_WEBHOOK_BYTES);
			if ("status" in body) return new Response(body.status === 413 ? "too large" : "bad request", { status: body.status });
			handleUpdate(body.json);
			return new Response("ok");
		} catch (err) {
			if (!isDisconnectError(err)) console.error("[epb] webhook", err);
			return new Response("ok");
		}
	}
} } });
var rootRouteChildren = {
	IndexRoute: Route$3.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$4
	}),
	ApiTelegramEvidenceRoute: Route$2.update({
		id: "/api/telegram/evidence",
		path: "/api/telegram/evidence",
		getParentRoute: () => Route$4
	}),
	ApiTelegramResolveRoute: Route$1.update({
		id: "/api/telegram/resolve",
		path: "/api/telegram/resolve",
		getParentRoute: () => Route$4
	}),
	ApiTelegramWebhookRoute: Route.update({
		id: "/api/telegram/webhook",
		path: "/api/telegram/webhook",
		getParentRoute: () => Route$4
	})
};
var routeTree = Route$4._addFileChildren(rootRouteChildren)._addFileTypes();
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getRouter, router_DTk38Ne5_exports as t };
