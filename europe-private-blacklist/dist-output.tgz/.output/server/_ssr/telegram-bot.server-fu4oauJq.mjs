import { o as __toESM } from "../_runtime.mjs";
import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-fu4oauJq.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+VkDLqrlnIGxjN2Uy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{3,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{3,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
function parseDamageAmount(text) {
	const raw = String(text || "").trim();
	if (!raw) return null;
	const upper = raw.toUpperCase().replace(/Ё/g, "Е");
	let currency = null;
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	const numeric = raw.replace(/[\u00A0\u202F\u2009]/g, " ").replace(/[€$₽]/g, " ").replace(/\b(usd|eur|usdt|rub|евро|бакс\w*|доллар\w*|руб\w*)\b/gi, " ").replace(/[^\d.,\s]/g, " ").trim();
	if (!numeric) return null;
	const s = numeric.replace(/\s+/g, "");
	let normalized = "";
	if (/^\d{1,3}(,\d{3})+$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d+,\d{1,2}$/.test(s)) normalized = s.replace(",", ".");
	else if (/^\d+\.\d{1,2}$/.test(s)) normalized = s;
	else if (/^\d+$/.test(s)) normalized = s;
	else return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n <= 0) return null;
	return {
		amount: normalized.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ""),
		currency
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
async function lookupTelegramHandle(input) {
	try {
		const res = await fetch("/api/telegram/resolve", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				input,
				initData: telegramInitData()
			})
		});
		if (res.ok) {
			const json = await res.json();
			if (json?.username || json?.id) return json;
		}
	} catch {}
	return resolveTelegramId(input);
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function telegramPlatform() {
	try {
		return String(window.Telegram?.WebApp?.platform || "").toLowerCase();
	} catch {
		return "";
	}
}
function isTelegramDesktop() {
	const p = telegramPlatform();
	if (/(tdesktop|macos|weba|webk|unigram|web)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Windows|Macintosh|Linux/i.test(ua) && !/Android|iPhone|iPad|Mobile/i.test(ua);
}
function isTelegramMobile() {
	const p = telegramPlatform();
	if (/(android|ios|android_x)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
function tgSafe(run) {
	try {
		run();
	} catch {}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tgSafe(() => tg.ready?.());
	tgSafe(() => tg.expand?.());
	tgSafe(() => tg.setHeaderColor?.("#080808"));
	tgSafe(() => tg.setBackgroundColor?.("#080808"));
	tgSafe(() => tg.setBottomBarColor?.("#080808"));
	tgSafe(() => tg.MainButton?.hide?.());
	tgSafe(() => tg.SecondaryButton?.hide?.());
	if (Boolean(tg.isVersionAtLeast?.("8.0")) && isTelegramMobile()) {
		tgSafe(() => tg.requestFullscreen?.());
		tgSafe(() => tg.disableVerticalSwipes?.());
	}
}
function telegramSafeTop() {
	const tg = window.Telegram?.WebApp;
	const safe = Number(tg?.safeAreaInset?.top || 0);
	const content = Number(tg?.contentSafeAreaInset?.top || 0);
	if (!Boolean(tg?.initData || /Telegram/i.test(window.navigator?.userAgent || ""))) return 0;
	if (isTelegramDesktop()) return Math.min(Math.max(safe + content, 0), 28);
	return Math.max(safe + content, 56);
}
function lockTelegramViewport() {
	const apply = () => {
		const root = document.documentElement;
		root.style.setProperty("--app-h", "100dvh");
		root.style.setProperty("--app-top", "0px");
		root.style.setProperty("--tg-safe-top", `${telegramSafeTop()}px`);
	};
	apply();
	const tg = window.Telegram?.WebApp;
	tgSafe(() => tg?.onEvent?.("safeAreaChanged", apply));
	tgSafe(() => tg?.onEvent?.("contentSafeAreaChanged", apply));
	return () => {
		tgSafe(() => tg?.offEvent?.("safeAreaChanged", apply));
		tgSafe(() => tg?.offEvent?.("contentSafeAreaChanged", apply));
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
var WELCOME_JPEG_BASE64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCALQBQADASIAAhEBAxEB/8QAHgABAAIDAQEBAQEAAAAAAAAAAAECBwgJBgQKBQP/xABfEAABAwMDAQQEAxAPBgMFCQAAAQIDBAURBgcSCAkTITEUFUFRFiJhFxgZMjhYcXR2gZamsrTT1CM1NkJSV2Jnc3WCkbO15DM3VnKUoSSlsSU0g5KVQ0RGU2Oiw9Hh/8QAHAEBAQEAAwEBAQAAAAAAAAAAAAECAwUGBAcI/8QAQxEBAAEDAwIDBQYEAwYEBwAAAAECAxEEBSESMQZBURMiYXGBBxQykaHBcrHR8BVCUiMkNTay4SU0c8InM1OCkqLx/9oADAMBAAIRAxEAPwDl+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAML7gAJwo4qMiATx+UnihMioLYQYT3DIqC2E9wwnuGRUFiRkUBcDIoC4GRQFwMigLYT3DCe4ZFQWwnuGEGRUFuKEcflGRAJ4qMKXIgDC+4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMKTxGRALcUGE9xMiOPyk4QkEyIJAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjCe4jiWBcigLYT3DihcioJ4jClyIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABPFScITIqTxUsCZEcUGEJAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQOKEgorxIwpcDIoC2EI4qXIgAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ4+8CCURVJwiEkyI4oSAQAAQAAAAAAAAAAFwAAGAABcAABgAAAABQAAAAAAAAAAAAAAAAAAAAEAADAAAYAAEwAAGAABAAAAAAAAAhUQkFFVRSC5GEUuRUE8fcQUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRvvAglG+8kkzkQSAQAAAAAAAAAAFwAALgAAUAAAAAAAAAwvuGFCAJ4qOPygygE8UJwgMqgthBhPcDKoLYT3DCe4GVQWATKoPquFvr7TX1NqutFUUdbRzPp6mmqI3RywyscrXsexyIrXNVFRUVMoqKinzkiYqjMLnHdUFsJ7hhPcUyqC2E9wwgMqgthCOKAygE8flHFQZQBhRhfcAAAUAAAAAAAAAATAAAmAABAAAAAAAAFVb7iMYLguRQEq33EGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRFUCCUb7yUTBJMiETBIBkAAAAAAABcAAC4AAFAAAAGFAAnj7ycIEyqML7iwCZRxHFCQDJhPcAAgAAAAAA+ipt9fRw0lTWUVRBFXwrUUskkbmtniSR8avjVUw5qSRyMymU5McnmiofOSJiexjAACgAfRb6mGjr6asqbfT18UEzJJKWodIkU7WuRVjesbmvRrkTC8HNdhVwqLhSTOIysQ+czH0k7Uzbu76aesklNTzWq0zNvd3bUQxzROo6d7FWN8T3Ij2yyLFCqJywkquVrmtVDZ/ps276JOou1VTKLaL1HqW3cn1tkm1JcZnpBywyeKTvm97GuWo5eKKx64cmHMc/Z/bDp72c2ar6267b6Jp7TW3CFtPUVLqmeplWJHcuDXzverGquFcjVRHK1iuzxbj8r8S/aLY0dm/t9Nm5b1GJiOqKcRM+eYrnPHMTGYnjyej2/Yq7tdF+a6aqM54mf3iPq5z9e+ifgd1IXmshp6CnpNTUlLe6eKkZw482LDM6RvFESR88E0iqmeXNHKvJzkTXY7Q7n9Pezm8tfRXXcjRNPdq23wup6epbUz00qRK7lwc+B7Fe1FyrUcqo1XPVuOTs6wdSe3fRJ06WqlZW7RevNS3Hi+iskOpLjC9YOWHzyyd87uo0w5GrxVXvTDUw17mcfhT7QNNd0um2v2F25fimKfdimYnpjGczXHlGZmcY5z6tblslym5c1PXTTRM55z5/KJ83P0H0XCphrK+prKa309BFPM+SOlp3SLFA1zlVI2LI5z1a1FwnNznYRMqq5U+c/WInMZeawAAqAB9FFb6+5zOprbRVFXKyGWodHBG6RyRRRukleqImeLI2Pe5fJGtVVwiKpJmKYzJEZ4h84AKAAADCe4ACOKDiSAuVcKCwBlUFsJ7iOPuC5QBhQFAAAAAAABMAACYAAEAAAIJAFVb7iC5CpkuRUEqikGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARMlkTBJkEb7yQCAACAAAAAC4AAFwAAKADCgASjfeSEyrhSeKEgJkwgACAAAAAAAAuAAAwAALgPot9vr7tX01qtVFUVlbWTMp6amp43SSzSvcjWMYxqKrnOVURERMqqoiGzHTntN0jbzw0mm9Uay1rpfWXcwskpqm6UEdHcKh8nd8aKR1Oquc5VjVIXYf+ycW96jHPNrtBdn7sjoDWdm1vRXfV1yq7HVx19LT19fB3Czxryje5IoI3rwejXonJEVWojkc3LV8RvHjzbtlrr0+oori5ETiJp4n0xOcTE+sTh2+l2a/qoiu3MTTPx7NfuvHYyg2z292orrFbKd8Vity6Vudzga2nbUStak0Llp+ao10knrCZzmoqq5683qqtzpkdqd6dltGb86MTRGt1r46SOrir6eooJ0inp52I5qParmuYuWPkYqPa5MPVURHI1yaz626C+lXbiwy6m11ujq6yW2Lknf1d0omd49GOf3cbfReUsitY9UjYjnu4rhFPJ+D/tA0en2+jR6+a6r3VV2pmqauqZq8vnMYxHbGHZbpsl2u/N2ziKMR3nGMRj9nO4Hptw37au1I9u09NqaKwMhjax2op6eSsllxl7lbAxrI25VGo3L1+LyVycuDfMn6/Zue1txXiYz5T3j5vMVU9MzGcgAORH0W+4V9pr6a62qtqKOto5mVFNU08jo5YZWORzHse1UVrmqiKiouUVEVDufp+jutusNtt99vPre5U1JDDWXD0dtP6ZO1iJJN3Tfix83IruCeDc4TyOLuyt603pjdfS+q9W3OoobVp+4x3mZ9PSrUSyupf2eOnYzk1OU0kbIkcqo1qyI5y8WqZF6h+sPcjfvvrFj4OaQk7h3qKmlSXvZI8rznn4NfLl68kZhsacI14q9nNfzjxt4a1ninWafTWIii3REzVXMf6piIiPOZ4mcROO3Vj3c97tOvtbdaruV81TiIj5ec/n/AEzy6q3CSbU+kqmXRupqeklu1ue61XmnjjrIonSxL3NUxqrwmaiua9EzxciJ44U4cXC4V92r6m63WtqKytrJn1FTU1EjpJZpXuVz3ve5VVznKqqqquVVVVTMXTZ1Taz6dLrVMoqT15pq48n1tkmqVhYs/HDJ4pOLu6kTDUcvFUexMOTLWOZ4req9ab1PuvqjVekrnUV1q1BcZLzC+opVp5YnVX7PJTvZycnKGSR8SuRVa5Y1c1eLkNeDPDWp8La7Uaa579quKZpriMdsxNM95ieYxEzicZp/zYm66+3uNm3cp4qjMTHz7TH5f18nigAforowA9Nt4/bVupGN3YptTS2B8MjXu07PTx1kUuMscjZ2OZI3KK1W5YvxuSOXjwdx3rnsrc14mceUd5+S009VURnDzJuL2duzNq15ddb6t1baPS7LFaJNORxzUrkZM+taqVCxVCKixyMgasbuHx+FX9M1F+NkzRPQX0q7j2GLU2hd0dXXu2y8U7+kulE/u3qxr+7kb6LyikRr2Ksb0a9vJMohsxststozYbRi6I0QtfJSSVctfUVFfOks9RO9GtV7la1rEwxkbERjWphiKqK5XOX8h8YfaBotRtt3Q6Ga6b1UxE5pmmaYzme/aeMevL0+17Jdov03r2JpjnvnPo4y6gsV10vfrlpm+0vo1ytFXNQVkHNr+6nierJGcmqrXYc1Uyiqi48FU+A6na97P3ZHX+s7zretu+rrbV3yrkr6qnoK+DuEnkXlI9qSwSPTm9XPVOSoiuVGo1uGpqj1GbTdI2zENXpvS+sta6o1l3MzI6amulBJR2+oZJ3fGtkbTorXNVJFWFuX/sfF3dI9rz1WzePNv3mujT2Ka6rsxGYiniJ88znERE+cz9XW6vZr2lia65iKY+Pdq+AD3DqMAACYAADAAAmAAAAABHFAqKSAuVQWIVvuC5QBhQFAAAAATAAAkwAAIAAAQqZJBRTyBZUyQqYLEiAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACUTIRMliTIgkAyAAAAAAAA1gAAUACIqhAIiqWwiAJkREAAQAAAABcAAC4AAAAAUAAAAAAAAOsvQxd9wtQ9P1v1FuFquov8ALcrjWyW2oqp3T1MdGyTuu7mkenJzkmjqHJlz8McxMoiI1vJo3c1h1rUGzW2tg2T2LpLRWXjTtujtV11DFTtfbFqW06JNPQNTj37nVLpJO+lYjHK1XcJUk5J4D7QNr1W+aWzt+itxVXVXnqntTTEcznyzMx25ntiXdbLqLekuV3rtWIiO3rM/Dz83Qo5F9Zt33Cm6gdWad11quou0VquL5LVTpO51NRUdRHHLDHFGqNbG7uVgbJxb8Z7FVVevxl+DaPqs3f2r1y3V8mrLvqOlq5kfd7ZdbjNNFcWqyONXOc9XKyZI4omsmRFc1I2tXkzLHf3usXcPb3ebVth3c29lp6eK7W59tuVunibDc4ayllX9mqmMy1zZIZqdsciPfySJzMtWJWp0fhPwlrPCm9x7eIuW7lExFcR+GqMTic8xmInntPHnw+vctytblpPc92qme3rH7+Xya/AA/W3mgAAAAAAAAAAAABnLoyu+4UPUDpPTuhdV1FpiutxZJdadZ3Npq2jp45JZo5Y0RzZHdyk7Y+TfiveiorF+MnXQ5NdHW4e3uzOrb9u5uFLT1EVptzLbbbdBE2a5zVlVKn7NSsfhrWxww1DZJFezikrWZcsqNX4N7esLd/eW8QTpeajS1noJu9orXZquaFqObOksMs8iORZpmKyJWvw1rXRo5jI1V2fyPxb4T1virfIixTFu1RTEVVzHeqczx51YiYj0jnnyem2zcrW26P356qpmcR8O3082+fXPd9wtPdP1w1Ft7quosEttuNFJcqilndBUyUb5O67uGRicmuWaSncuHMyxr0yqKrXcmjc3bLrAoNyNoLx0+751FPJdbzbprRZdT3RGvo0lfC9KaS4vXLmOimSFUqWtev0r38XRulfpkd/4B2rU7Fp7+3auiIrprzFURxXTMcTnz5ie/MdpiHxbzqbesrov2p4mO3pMd/2AAe9dMAAAAAAAAAAIAAGAABMAACAVEUACqooLDCKFyqCVaQFAAFAAEwAAMgAAAACqpgguVVPaaiRAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEonvCJ7yxJkAAZAAAAAFiAABQABQImSUT3khJkREQABkAAAABcAACgACgAAAAAAAAAAA9NQbc6tue3t23Po7VUSWCy3GltlVUpBKrUlnbI5F5o3gjWKyNr1VyKjqiBML3iHmTjt3rd2aoonPTOJ+E4icflMLNM04mY7gAORAEjC+4CAThRxUZTKAW4/KOPyjJlUFuI4oMmVQW4oOKEyZVBbig4oMmVQW4oOJcmVQW4/KOPyjJlUE8VHFRkygE4X3DCgQAAoAemr9udW2zb207n1lqqI7BerjVWylqVglRqywNjcq81bwVr1fI1io5VV1POmE7tTjuXrdqaYrnHVOI+M4mcflErFM1ZmI7PMgA5EAAAAAAAAAAAAAQAATAAAgFRFAAqqYBYhU9waiUAAKAAIAAJMAACAAAqqe4guQqe41EioAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASiZCJksSZAAGQAAAABYgAAaAAAJantCJ7yQzMgACAAC4AAFAAFAAAAAAAAACcKEQC3FCcJ7iZMq4GFPfbQb4bj7G36S+7e3z0T0vum19HNGktLXRxvRyMljX+01HtVsjWvejXN5LnqZsH1M7cdQFqb8G670LUNNSMqbnYqhV7+ky5WOVj1ajZ40cifHZ5I+Pmkbnow8b4o8Ta7w5T7enR+1s/wCqK5jH8UdE4jPaczHriZiHabdoLOvnom701ekx3+U55eK2j6YrI3pDTZ6+xVFHW6xtyXW6S1EE0ctLc5mxyxOfAsiKjqdY6disyxHrTryanNyHLO4W6utNfU2u60VRR1tHM+nqaaojdHLDKxytex7HIitc1UVFRUyioqKd3DyO6e6ejdnNG1mudc3L0WgpcMjjYiOnq51RVZBCxVTnI7C4TKIiI5zla1rnJ+TeGfHmu2/VX4mzN+q/X1RTFWMVT3x7tWcxiMcYimMPTbhs1m/bonr6IojGceX5x8fzcScJ7iTNXUl1S6y6i7rSsraT1Hpu3cX0VkhqVmYk/HD55ZOLe9k8XI1eKIxi4amXPc/Cp+/aC9qb+npuau3Fuue9MVdWPhnERM+uOPSZ7vEXqbdFc02quqPXGM/QAB9jjwAAGAAAwAAGAAAwAAGAAAwAAGAAAwAAGAYT3AzV029UusunS61TKKk9eabuPJ9bZJqlYWLPxwyeKTi7upPBqOXiqPYmHJlrHM+PX3tTY09VzSW4uVx2pmrpz8M4mIn0zx6zHdyWabddcU3aumPXGcfThhygt1ddq+mtVqoqisrayZlPTU1PG6SWaV7kaxjGNRVc5VVERETKqqIh1M3c6YrI7pDXZ6xRVFZW6Oty3W1y08E0ktVc4WySyuZAkiqrqhZKhiMy9GLUJxavBqGYtrN09G7x6No9c6GuXpVBVZZJG9EbPSToiK+CZiKvCRuUymVRUVrmq5rmuX1x+A+JvHmu3DVWIizNiqxX1TTNWc1R2z7tOMRmMc5iqcvb7ds1mxbrma+uK4xnGOPzn4fk4NYUYU7Fb+dTO3HT/anfCSu9N1DU0j6m2WKnVe/q8ORjVe9Gq2CNXKvx3+aMk4JI5isOWe7++G4++V+jvu4V89L9E71tBRwxpFS0Mcj1crIo0/stV7ldI5rGI5zuKY/WfC/ibX+I6fb1aT2Vn/VNczn+GOiMxnvOYj0zMTDzO46CzoJ6Iu9VXpEdvnOeHgAXwnuI4oeyy6vKoJ4qQUAAFAAAAAAAAAAAAAZwAAIhUILEKmQsSgABoAAAABmYAAEAABVU9pBcqqGokQACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASiZCJksSZAAGQAAAABYgAAaACUT3hEImS2MABJkAAQAAaiAABQAAAAAAJRFUCAW4oSTKZV4qThCQTKZAAEwAALgNxOzb2sqb7uPdN1rhbeVt0zSPo6CoesrP/aNQnFVjVE4ScKdZUe1yrx9IiXj4o5unZkul381lYto49mtFyfB+y13pUuoZKeRXz3qeZ6Jl73JmGNII4Ye7iVqPRsivV6SK1vQ+JNFq9z2+vQ6OYpm57s1T/lpn8U+s5j3YjzmecRmY+3QXbWnvxeuxnp5iPWfL+v0dNtQdXPT/pfcFdtb1r6ngukUzqWqm7iR1HR1KOjakM1QjeDXKsjsuyrI+5lSR0bkRFxZ2kmhfX+zVr1tSWvv6vSt3Z31T3/H0ahqW93J8RXIj+U6UaeCOcnmmG81OaJkvSe/mstP7cXnZ28yevdEXekqI2WmpkVnoVW5Wyw1MErU5s7uojjlWLKxPzIitRZFenitP9nX+CavTbhtl2aqrcx1xV/mjtV0zGMTiZiKZzE+dXfPb17797tXLGopxFUcTHlPln1584/L0xoAD9TedAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHS7s29C+oNmrprartfcVeqru/uanv+XpNDTN7uP4iOVGcZ1rE8Ua5fNct4KZT0/wBXPT/qjcFNtbLr6nnukszaWlm7iRtHWVKukasMNQreDnIsbcOyjJO+iSN0jlVE5k6s381lqDbizbO2aT1Foi0UlPG+000iv9Nq2q6WapnlcnN/eVEkkqRZSJmI0RqrGj1xoflmo+zr/G9Xqdw3O7NNVyZ6Ip/yx2p6pnOZxERNMYiPKrtj0VG+/dLVuxp6cxTHOfOfPH185/L13E7STaypsW49r3Wt9t423U1Iyjr6hiyv/wDaNOnFFkVU4R86dIkY1qpy9HlXj4K52nZkuq381lfdo5NmtaSfCCy0PosunpKiRWT2WeF6plj2pmaNYJJoe7lVyMR0asViRo12ND2vhvRavbNvo0OsmKpt+7FUf5qY/DPrGI92Y8pjjMYmeo1921qL83rUYirmY9J8/wCv1AAd8+LAAAmEYQjipYDK5VILkKiFyZVBKopBWgAAAAAAAAABJgAAZCFTBIBlUEqnuIDQAAoAAkwAAMgAAqqe0guVVMGokQACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKJkCU8iQDAAAAAAsQAANABZEwEmcIRMEgBkAAXGQABQABQAAACUTIRBPFSyIiAmUyhERCQCIAALgAAXAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAACYAqIoATsrx9xBcYyXK5UBKoQVQABQAAAAEAAEmAKmQAivkCypkr5BqJAAFAAGZgAAQIXxJAFASqYINgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABZEwETBJmZAAEAAAAAGgAImQqW+8kAMAACxAAA0AAAAABKIqhE95YkykyhERCQCM9wABrAAAoAAAAAAAAAAAMp6e2Nr7907ar34ZcadkWnL5R2xKZZnI58Tka2deHdqiu7yqouC80Tik+UyjM4sPm0+rs6qq5TanPRV0z8JxE4/KYbrtVW4pmqO8Zj5dv2AAfSwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZT09sbX37p21Xvwy407ItOXyjtiUyzORz4nI1s68O7VFd3lVRcF5onFJ8plGZ+bVauzo6aar046qqaY+M1TiI/Nu3aquzMUR2iZ+kcyxYAD6WAAAAAAAAAAAAAEwBURQAnZVUVCC5Cp7ixKxKoAKoAAAAAAAMzAQvkSAioJVCA0AAKAAMzGAABEL4lfIuQqZLEioANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEtT2kFk8iSJABkAAAAAagACJkKImSwAZmQABAABoAAUAAAsiBEwSSZZmQAEIgAAaAAAAAAAAAAAAAGRNsOn7dreWgrbjtrpmnvMVtmbBVtbdaOCWFzm5aropZWvRrkReLuPFVa9EVVa5E9r84v1T/wAV3/ndu/WDDuktW6k0JqS36u0jeKi13i1zJPS1UCpyY7CoqKi5RzVRVa5rkVrmuVrkVFVF6idKvV3auof0zTN2sPqTVlrpGVc0EL3S0tZAndsknicqZixK9EWJ6qqNezD5Pj8fBeLt48Q7DTOs0Vu3csR3zTV1U/PFcZj4xEY844zPc7ZpdDrJ9leqqpr+cYn9OHpqLYeG39LLthIKK0OrXaXlt6rO+Saj9bSRue6pRz2q9GpVuWZqo3LPBWtbxRE57/OL9U/8V3/ndu/WDrUa79VXV3aunj0PTNpsPrvVl0pH1cMEz3RUtHAveMjnlciZlzKxUSJioqtY/L4/icvyrwl4m321qrml223TduXqprnqz385z1U4+Mz8HpNz2/R1W6bmoqmmmiMcenlHaXOjc/p+3a2aoKK47laZp7NFcpnQUjXXWjnlmc1uXK2KKVz1a1FTk7jxRXMRVRXNRcdn9fVurdSa71JcNXauvFRdLxdJlnqqqdU5PdhERERMI1qIiNa1qI1rWo1qIiIifyD+iNFGqpsUxrJpm559MTFP0iZmePXPPfEdnhrs25rn2UTFPx5n9IgAB9TjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyJth0/btby0FbcdtdM095itszYKtrbrRwSwuc3LVdFLK16NciLxdx4qrXoiqrXImOz+vpLVupNCakt+rtI3iotd4tcyT0tVAqcmOwqKiouUc1UVWua5Fa5rla5FRVRfl1saqqxVGjmmLnl1RM0/WImJ59c8d8T2clqbcVx7WJmn4cT+sSzF84v1T/xXf8Andu/WDoRRbDw2/pZdsJBRWh1a7S8tvVZ3yTUfraSNz3VKOe1Xo1KtyzNVG5Z4K1reKInmelXq7tXUP6Zpm7WH1Jqy10jKuaCF7paWsgTu2STxOVMxYleiLE9VVGvZh8nx+OxB/O/i7xNvt/UUaPc7dNuuzVFcRTnEz5TzVVE/DHrL3O2bfo6KJu6eqaoqjHP6x2hyV+cX6p/4rv/ADu3frB4rc/p+3a2aoKK47laZp7NFcpnQUjXXWjnlmc1uXK2KKVz1a1FTk7jxRXMRVRXNRei/VV1d2rp49D0zabD671ZdKR9XDBM90VLRwL3jI55XImZcysVEiYqKrWPy+P4nLl3q3VupNd6kuGrtXXioul4ukyz1VVOqcnuwiIiImEa1ERGta1Ea1rUa1ERERP1XwjvHiHfqY1mtt27die2Kauqr5ZrnEfGYnPlHOY83uel0Oin2Vqaqq/nGI/Tl/IAB710wAAAAAAAAAAAAAAAMzCFTJUuFTJYkiVASQVoAAAAAAAGAhUwSAZVBKpggNAABIAAyAACrk9pBZfIqagAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALJ4EN95YzIAAgAALAAA0FkTCFU8ywZkAAQAAaiAABQAACWkFmiUlIAMpEAADQAAAAAAAAAAAAAAAAb89nhJpvbnaDcXeTV2pqe3Wd1xgoapZ41RtO2ki5o9HIqrI6Ra5GNja3krmojeSvRE0GP6911bqS92Syabut4qKi16chngtdI5USKlbNM6aVWtTw5PkequcuXKiMaq8WNROh8R7PVv2h+4dfRRVVT1T3npierEfGZiPl35xifs0GqjRXvbYzMROPnPHP0z/fLfHUHaZ6boNwVt1h2/qLpo6nmdTyXL0pYqypbyj/8AEQwuYiNaiJPiJ7kdJyiVXQqjmr8HaHyab3G2g263k0jqanuNnbcZ6GlWCNVbUNq4uavVyqixujWhVjo3N5I5yo7irFRdBj+vatW6kslkvem7VeKinteo4YILpSNVFiqmwzNmiVzV8OTJGIrXJhyIr2ovF7kXorHgPQ7ZrNNrtr9yu1POZmeumYxVnOcVYmZiYjHliOJp+yveb2otXLOo5irt5YnvH0/v5/yAAe7dOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADfns8JNN7c7Qbi7yau1NT26zuuMFDVLPGqNp20kXNHo5FVZHSLXIxsbW8lc1EbyV6In36g7TPTdBuCtusO39RdNHU8zqeS5elLFWVLeUf/iIYXMRGtREnxE9yOk5RKroVRzV0OuurdSXuyWTTd1vFRUWvTkM8FrpHKiRUrZpnTSq1qeHJ8j1Vzly5URjVXixqJ/IPCXfAeh3HX39x3T/aVXJ4iJmIppiIpp7YmasRHfiO2JmOqe4p3m9Ys0WNN7sU+feZnvP0z/fk357Q+TTe420G3W8mkdTU9xs7bjPQ0qwRqrahtXFzV6uVUWN0a0KsdG5vJHOVHcVYqLoMf17Vq3Ulksl703arxUU9r1HDBBdKRqosVU2GZs0SuavhyZIxFa5MORFe1F4vci/yDvfDmz1bBovuHX10U1VdM9p6ZnqxPxiZn59+M4j49fqo1t722MTMRn5xxx9Mf3yAA758YAAAAAAAAAAAAAAAAAAzMId7ypZ3kVLCwAAqgAAAAJMZAAGRfEqWKr5hYAAGgABmQABAoqYLkO8iwKgA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKeYEomCQDAAAAAA1AAAonmWCJgBmZAACAABoAAAAACzSMZLImCSkgAIQAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkod5FS5VUwWEhAAK0AAAAAAADMhVfMsFTIIVAAaAAEkAAZCF8SQBQEuINgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWRMBEJMzIAAgAAAAA2AEtT2hEgAMgADUQAAKAAASiZJRPeSSZSZETAAIz3AAGgABQAAAAAAAAAAAAAAAAAAAAABs9oPpqZqPov1fu3JaKh9/bcW3W0yJNTI11soeUdS7Lk5taqSVrns5NV7qSBUauER+sJ1ug3TT7jXet2JzNquaKvnERM/zx84lz3tPXYiiquPxRmAAHZOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADZ7XnTUzTnRfpDduO0VDL+64uut2kWamVrbZXcY6Z2Wpzc1EjonMZycrHVc6q1MqjOt1+6afbq7Nu/OJu1xRT85iZj+WPnMOezp678V1Uf5YzPyawgA7JwAAAAAAAAAAAAAAAAAAAAAAAAgAAmMKqmCC5Cp7ixJEqgArQAAAACSAAMqr5glUIDUAACgADAAAIVMlfIuQqZLEioANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATzAuADAAAAAAsAADQWQqnmWDMgACAADYAABZE9pUunkSUkABGQABsAAAAAAAAAAAAAAAAAAAAAAAB7zaDRe3GvL9JYtwt1vgJ3vdNoKya0LWUs0jno1WSyJKzuMcmuR7k7vij1c5nFOW2v0Lf+fP8WP9WaHG8XZ/b+buX3WdNs1c5PhBpahtEksclRIxk9lghXDFY9U5zRq+SOHu1VysR0asVjI3Nd4XxnG+aLTVbjtWq6aaIzVRVTRjEedMzTM5+Ezz5c4ie42r7nduRY1NvMz2mJn9cT+sfX1b1aQ0zQaK0nZNG2qaolorDbqa2U0lQ5rpXxQRNjYr1aiIrlRqZVERM5wieRpZcOy6oJK+pktW9VRT0TpnupoajT7ZpY4lcvBr5G1DEe5EwiuRjUVcqjW+Sb1GtHXhu/uPtNtfQfAGD0Jmoqt9rrb6ydGz2/MavZHCz6ZJJWtlxMn+zSJ2MPex7fxLwruW807h912u9FFd+YzMxTMTjM5nqie2Z7cz2jMvW7jp9LNj2moozFEcYz+30aO9SWwujdgLrS6Vot2vhVqR/GWtt8NmSmZQQObliyy+kPxI7LVbHxzwXm5WorOeFQD+m9BYv6bT029Tdm7XHeqYinM/KmIiI9I5+My/Pr1dFyuardPTHpmZ/WQAH2OMAAAAAAAAAAAAAAAAAAAAAAAAM1dNuwujd/7rVaVrd2vgrqRnKWit81mSpZXwNbl6xS+kMzI3DldHxzwTm1XIj+GFQfHr7F/U6eq3prs2q57VREVYn5VRMTHrHHwmHJZrot1xVcp6o9MzH6w35t/ZdUEdfTSXXeqoqKJszHVMNPp9sMskSOTm1kjqh6McqZRHKxyIuFVrvJd09X6ZoNa6TvejbrNURUV+t1TbKmSnc1srIp4nRvViuRURyI5cKqKmcZRfI1/6D939x92dr6/4fQems07VstdFfXzo6e4YjR745mfTLJE10WZl/wBokrc5ex73bLn8yeKty3mrcPuu6XorrsTOJiKYiM4nMdMR3xHfmO04l+g7dp9LFj2mnoxFcc5z+7Q36Fv/AD5/ix/qzUrd/Re3Gg79HYtvd1vh33Xetr6yG0LR0sMjXq1GRSLK/v8APFzle1O74qxWufyXjtN2gO/m7li1nU7NWyT4P6WrrRHLJJTyMfPeoJlw9XvROcMaPjkh7tFar0bIr1eyRrW6On7b4MjfNbpqdx3XVdVNcZpoppoxifOqYpic/CJ48+cxHkt1+52bk2NNbxMd5mZ/SJn9Z+nqAA906cAAAAAAAAAAAAAAAAAAAAAAAAAAYQqe0qXKFhqAAFUAAAABgKliHeYWEAANAADMgACAAAovmCV8yDYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAE8wE8wLgAwAAAAALAAA0lpJDfIkMyAAJAAA2AACU8yxDSSSzIACEAADQAAAAAAAAAAAAAAAAAAAAAAAAbidK+421/TFtHd91taR+l601f3zNPWqJY3z1dup3pFyR7WudSRvqu+R7pVTmlIisY9Y0R2nYOp3nabe96b7nfqmLczE1RHE1RHPTnyiZxn4RMRiZzH06XU1aS57WiPexx8Pi2P1B18dQFy3BXWVlvtParXDM5KXT3o8c1GlMro1WKZytR8rnJE3MuWvTnL3axNerTMW7PURtx1Z9OF/sVPavVWvrHm/wBHYqmsX4sdI9FqKiCdUjjnxRSVLliVO8+LIrY3cGvXQ4HV3/B21VV2L2ltxauWZiaZp47TnFX+qJ88+9PPvRmc/RRuupiK6LlXVTVnMT/OPT4eXwAAeqdcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAN8dpuojbjpM6cLBYqi1etdfXzF/rLFTVi/Gjq3qtPUTzokkcGaKOmckSJ3nxo1dG3m56Yd0/wBfHUBbdwU1ler7T3W1zTNSq096PHDRrTI6RUihcjVfE5qSuxLlz14Rd4srWI01wB5Wx4O2qmu/e1VuLty9MzVNXPec4p/0xHlieqOPenEY7GvddTMUUW6ummnGIj4ec+vx8vg3E6qNxtr+p3aO0braLj9E1ppDuWahtUqxsnpLdUPWLkr3Na6rjZVdyjHRKvBKtVexiyKjdOwDtNm2m3smm+52Kpm3EzNMTzNMTz0584ic4+ExE5mMz8+q1NWrue1rj3sc/H4gAO2fMAAAAAAAAAAAAAAAAAAAAAAAAAAMyFV8yxDhBCoANNAAAAAMyEL5EhfIJCoADYAAzIAAgAAKr5kEr5kG4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAnmAnmBcAGAAAAABYAAGkt8iSG+RIZkAAIAAGgAAWaSQ0kzLMgACwAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH9fSGma/WurLJo21TU8VbfrjTWymkqHObEyWeVsbFerUVUaiuTKoirjOEXyMV102qZrrnERzKxE1TiHz3KxXW0UdquFwpe6p73SOr6B/Nru+gbPLTq/CKqt/ZaeVuHYX4ucYVFX4DfntDNsKDS2zG18lqulQ6i0ZMmmKaGoY18s8UlI3hK+RvFEc1KBEVEZhyyKqceOF0GOl8Ob3R4g0Ea6iMZmqMemKpiPzpxM/N9ev0k6K9NmZzxH8v6gAO9fGAAAAAAAAAAAAAB99ksV11FWSW+zUvpFRFSVVe9nNrMQU0ElRM/LlRPixRSOx5rxwiKqoi/Ab49mVtn+6neOoq/fpmjgZJ/Q1FQ+Rqs+1kYqP/8AzeTfpVOj8R71TsG23NdVGZp7R6zM4iP3+T69BpJ1t+mzHGe/yaHA/va/0t8Btd6j0T6d6b8H7vWWr0nuu77/ALiZ8fecMu48uGcZXGcZXzP4J3Fq5Teoi5ROYmMx8pfLVTNMzTPeAAHIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkhDvIkh3kIZhUAGmwAAAAGZAvkAvkEhUABsAAZkAAQAAFV8yCV8yDcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATzATzAuADAAAAAAsAADSW+RJDSQzIAAQAANAAAs0kqnmWMyzIAAQAANAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANnunS+9Gmp4aTSO+G2VPYbxHDDBHf/XdySjuMyycMzMbLikdhWOVyr3PhK5VhRGsXerQvSjsFtrqqh1tonQXq69W7vfRqn1pWzd33kbo3/Ekmcxcse5PFF88p44U47nVPs/LNX2vpqtFdWXyor4rvca+tpaeTlxoImzLAsDMuVOKyQSTeCNTlO7wzlzvx77R9uv7bpZ12n1d2mm5V0zbmuuaZ6onOOeIxE5pnMeUY4ifUbDfo1Fz2NdqmZiMxViInj6fr3Zy11oXSu5Wla7ROtrX6xstx7r0mm7+SHvO7kbIz48bmvTD2NXwVPLC+GUNaN39h+hDY2wx33cLRXonpfetoKOG73OWqrpI2K5WRRpUf8rVe5Wxtc9iOc3kmdraa4UFZNVU1HW088tBMlPVRxyNc6CVY2SIx6IuWuWOSN+FwvF7V8lRTkN1gWavsPUrr2huN8qLtLLcW1raiflyZFUQxzxQJlzl4xRyMhb444xphGphqeP8AaLVbrratFTq7lmimOuaaKqqertHlOI7xziZmMRHrHab3et6a1F6bdNUzOMzETjvP9Xg9w9Q6P1NqR9x0Lt9T6Ns6QsjitsdyqK93JE+NI+adVVzlVV+laxqNRqYVUc53mQD+jbNqmxbi3TnEcczMz9ZmZmfnMzLwlVU11TVP9P0gAByIAGYukrambd3fTT1kkpqea12mZt7u7aiGOaJ1HTvYqxvie5Ee2WRYoVROWElVytc1qofJr9Za27S3NXenFNETM/SP38nJZtVX7lNujvM4YluFvr7TX1NqutFUUdbRzPp6mmqI3RywyscrXsexyIrXIqKioqZRUVFPnNiOvXRPwP6j7zWQ09BT0mpqSlvdPFSM4cebFhldI3iiJI+eCaRVTPLmjlXk5yJrucW1a+ndNDZ1tPHXTFWPTMcx9J4a1NmdPeqtT5TMAAOwcIem281Do/TOpGXHXW31PrKzrDJHLbZLlUUDuSp8WRk0CorXIqJ9M17Varkwiq1zfMg471qm/bm3VnE8cTMT9JiYmPnExK01TRVFUf1/SXS7aDYfoQ3ysMl9290V6X6J3Ta+jmu9ziqqGSRiORksa1H/M1HtV0bnMejXO4rjZfQuhdK7a6VodE6Jtfq6y27vfRqbv5Ju77yR0j/AI8jnPXL3uXxVfPCeGEOTnR/Zq+/dSugqG3XyotMsVxdWuqIOXJ8VPDJPLAuHNXjLHG+F3jjjIuUcmWr15rbhQW2FtTca2npYnzRU7ZJ5GsasssjY4mIqrjk+R7GNTzVzkRMqqIfzl4/0Wp2rW0aGdXcvUVRFcU11VVdPM0x3nEz3xMRE44x5z7vZb1vU2ZvRbppmOJmIiM9p/oxZrrpR2C3K1VXa21toL1jerj3XpNT60rYe87uNsbPiRzNYmGMangieWV8cqaK9Rd96NNMQ1ekdj9sqe/XiSGaCS/+u7ktHbpkk4ZhY6XFW7CPcjkXufGJyLMiuYm2vaB2avunTVd66jvlRQRWi40FbVU8fLjXxOmSBIH4cicUknjm8UcnKBvhnDm8rD2H2cbdf3LSxrtRq7tVNurpi3FdcUx0xGM88xiYxTGI8pz2jq9+v0ae57Gi1TEzGZqxEzz9P17gAP2F5cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZkIcSVd5iCEAA00AAAAAzIF8gF8gkKgANgADMgACAAAqvmQSvmQbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACeYAFwAYAAAAAFgAAaE8yxUsGZAAEAAGwAAC6eRQs1fYSUlIAIyAANgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABtbub1t6ktuirPs3sfcqi32fTduhskmqO6SKsu8MNKyDvIYXIq0TXKj3oqOWb/AGSo6JUc1dUgdZr9n0e6XLdzV0dfs8zETzGZxzMeePLPHOcZxMfRZ1V3T01U2px1d583rdrN09ZbOazo9c6GuXotfS5ZJG9FdBVwKqK+CZiKnON2EymUVFRrmq1zWuTInVPvZpvqEu+mtx7dS1FovEduls1yscmZm0rYZ3Sw1DKnDUlbKlS9OPBrmOgdlFRzXLg4Fu7Vpbuto3GacXaYmOqPOmY7T6x5x5xPacTMTKdTcpszYz7s84+PrH9/sAA7JwB9FvqYaOvpqypt9PXxQTMkkpah0iRTta5FWN6xua9GuRMLxc12FXCouFPnBJjMYOzoB027edEvUXaqplFtH6j1JbuT62yTakuEz0g5YZPFJ3ze9j8Wo5eKKx64cmHMc/Z/bDp72d2ar6267b6Jp7TW3CFtPUVLqmeplWJHcuDXzverGquFcjVRHK1iuzxbjjRb7hX2mvprraq2oo62jmZUU1TTyOjlhlY5HMex7VRWuRURUVFyioiodzLBR3W3WG22++3n1vcqakhhrLh6O2n9MnaxEkm7pvxY+bkV3BPBucJ5H4H9oug1ey10xRrLlVm9n/Z1V11Y6cTPMzMVRmYxnmOO/d7TYr1rVxObVMVU496IiO+fhxPy/R4rc/p72d3lr6K67kaJp7tW2+F1PT1LamemlSJXcuDnwPYr2ouVajlVGq56txydnWDqS286JenS1UrK3aP15qS48X0Vkh1JcIXrByw+eWTvnd1H4ORq8VV70w1MNe5m5lwkm1NpOpl0bqanpZbtbnutV5p446yKJ0sS9zUsaq8JmormvRM8XIieOFOHdwuFfdq+put1raisrayZ9RU1NRI6SWaV7lc973uVVc5VVVVVXKqqqo+zvb9ZvFyum7q7lFqzjNumuunOc8cTEUxmJzjnv27m+X7WliJptUzVXn3piJ7Y+HP99y4VMNZX1NZTW+noIp5nyR0tO6RYoGucqpGxZHOerWouE5Oc7CJlVXKnzgH75EYjDxfcABRnHpY3s03093fUu49xpai73iS3RWa22OPMLaps07ZZqh9ThyRNiSmYnHg5z3TtwiI1zk8Vu/vhuPvlfo77uFfPS/RO9bQUcMaRUtDHI9XKyKNP7LVe5XSOaxiOc7imPBg6yjZ9HRrqtymjN6rEdU8zERGMU+nnnznPM4xEfROquzZixn3Y8vX5tntler6vte2tx6f91Kion0xerdUWOj1A1HT1Nhpp6eSH40KeNVDGrmK1iOa9jEe1qvRI426wgF0W1aXb7129pqembsxNUR26ozzjymfPy4zjMzMy7qbl+imi5OeniPl6AAOycAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwFCyr4FSw1AACqAAAAAwEO8ySoWAABoAAZkAAQAAFV8yCV8yDcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAsi+BJTyLIuTMwJABAAAAABsJavsIASVgAGQABqAABQAAWRSShKL7yTDMwsACGcAACgACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD2uy1603pndbS+q9W3OoobXp+4x3mZ9PSrUSyupf2eOnYzk1OUskbIkcqo1qyI5y8WqZE6husLcffvvrFj4O6Qk7h3qKmlSXvZI8rznn4NfL8deSMw2NOEa8VezmuBgdZe2fR6nW0a+/R1XKIxTnmKec5iPWeOfLHGOc/RRqrtu1NmicUz3+P8A2/uWaum3ql1l06XWqZRUnrzTdx5PrbJNUrCxZ+OGTxScXd1J4NRy8VR7Ew5MtY5nit6b1pvU262qNV6SudRXWvUFxkvML6ilWnlidVfs8lO9nJycopJHxK5FVrljVzV4uQ8UC29q0tnW1bhapxcrjFUx/m7YmfjHbPpPOcRiVam5XZixVOaYnMfD+/78wAHZOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZzkIVcEKvuILEEQAArQAAAACTIAAyKvgVC+YDUAACgADAAABCrgFVXJYgAAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJb5kAC4IRckmAAAAABqAABVkXIKp5lgzMAABAAA0AAAAAJRcFihZpJSUgAhAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSFVXJLvIqWEgABWgAAAAAAAZkCrgEL5ghAADQAAkgADIAR5AQ4gL4g3AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACW+4sU8i3mZkSACAAAsAADQnmWKlkXIZkAAQAAayAAKAAAWaVJaJSVjsN2euxeyWtek7SGo9ZbO6Hv12qZ7mk9fc9PUlVUSo2vna1HSSRq52GtRqZXwRET2HHk7fdmf9Rron7Yuv+Y1Bw3Oy0d2VvnYemr63nbP8EqD9EPnYemr63nbP8EqD9Ea3dqvuFr7bvafR1x2/1xqDTNXVaidBPPZrnNRSSx+jSLwc6JzVc3KIuF8MohzI+ee6lfrhtzPwtr/0pimmaozluZiHWfq/6fthdM9Mm41/03sjoG1XOhskstLW0OmqKCeB6K3DmSMjRzV+VFRTiYe+vfUDv1qa01Vg1Jvdr662yujWKqoq7UtbPBOxfNr43yK1yfIqKh4E5aaZpjlmZy7kdMvTv0/3/p12zvd92M2+uNxr9KWupq6yr0zRTT1Er6Ziukke6JXPcqqqqqqqqqmlfaw7bbd7c6q27p9vdA6c0vFW2+4PqY7NaoKJs7myRI1XpE1qOVEVcKucZU6LdJ/1MW1H3HWj81jNDO2T/dhtl/Vly/xYTion3mp7OdB2c6FdhdjNXdKOgNR6s2X0JertW01W6pr7jpyjqaiZUrZ2or5JI1c7DWtRMr5Iiew4xndbs9PqONt/tSt/P6g3c7JT3ak9rDtTtdtzpTbyp29220tpiWtuFeypks1np6J07WxxK1HrExquRFVcIucZU1b6D9Nac1h1Y6B05q2wW292msnrkqaC40sdTTzI2gqHNR8ciK12HNa5Mp4KiL7Dc3tk/wBx22X9Z3L/AAoTUTs7fqytuPti4f5dUin8BPd2G+dh6avreds/wSoP0QXpg6alTHzvO2f4JUH6IyYcG92OpXqLs27ms6K179bh0tLRaiuMNPTx6mrUhijZUyI1jWd5xRqIiIjcYREwcdMTU1MxDrdq7oa6TtZ0klJcdkNO0KvRUSW0QrbpGL7FRadWeXuVFT3opzF66OiGfpbuNv1VpG6Vd20Nfah1LTy1eFqaCq4q9KeVzURr0c1r3MeiJlGPRURWorugHZtb3bkb47E1923OuMl1uNjvs1qgucsaNkqoEghkRJFaiI57VlVFd5qnHOVyq/P2pTrY3pGvCV6sSd14tqUXLGVm77K4+Xukl+9ktMzTVhJiJjLiubMdGnRPqvqovc92rqyaxaGtMyRXG7NjR0tRLhFWmpkd8VZOKornLlrEciqjlVGrrjabXXXu60dltkCzVlfUR0tPGnm+V7ka1v31VEP0QbLbWWLZTa3Tm2OnYmNpbFQsgkla3C1E6pymnd/KkkV71/5jkrq6Y4ZpjLyu1fSL067OUEFLo3a2yrVQtRHXK40za2ukd7XLNKjnNyvjhnFvuRDLDrfQOpvQ3UNOsGMd0sTeGPdxxg0B7TXrF1ftdV0Gxm1N7mtF3uFElwvl1pX8aingeqtip4Xp4xvdxc9zkw5G93xVOSnLuLVuq4Lx8IodTXaO6o/vPTm1siVHPOeXeI7lnPjnJxxRNXMtTVjh3f3a6NenDeagnp9VbY2mjrpWrwu1ogZQ10bl8nd5Gid4qexJEe35Dkf1f9HWsulXVECVFU69aQvEjktF6bFwy5EytPO1PBkyJ4+C4eiK5vk5rd8OzP6v9Vb1W+67Q7o3Z901Lp6kbX265zLmeuoUcjHtmX9/JG58fx/NzX/GyrVc7Z/qS2dte/GyuqNtbhTRyVFwonyWyV6Jmnr40V1PIi+zEiIi4xlrnJ5KoiZonEkxExl+es7kdMvTv0/3/p12zvd92M2+uNxr9KWupq6yr0zRTT1Er6Ziukke6JXPcqqqqqqqqqnDmSOSGR0UrHMexytc1yYVqp5oqH6COk/6mLaj7jrR+axmrnZKe76vnYemr63nbP8ABKg/RHy3DpP6YrnC6Cp6fdvWNcitVafTtLA77zo2NVPsoppr2sO626O3Oqtu6fb3cjVOl4q233B9THZrxUUTZ3NkiRqvSJ7UcqIq4Vc4ypqhsX10dR23G4FmuN23R1JqqzSVsMdytd8uEteyop3PRHtY6ZXOjfhVVrmqmFRM5TKLmKZmM5WZiJbv9RHZVbV6tstXethll0jqOFjpIbbNUyT22scif7Ne8V0kDlXycjlan8D2pydvtju+mL3X6c1Bb5qC52upko6ylmbxkgmjcrXscnvRyKh+lI4qdqJpa3ab6tLvWW6FkXr+00F0qGsTCd8rFhcuPevcI5feqqvtNW6pmcSlUN0ez12L2S1r0naQ1HrLZ3Q9+u1TPc0nr7np6kqqiVG187Wo6SSNXOw1qNTK+CIiew2O+dh6avreds/wSoP0Rinsz/qNdE/bF1/zGoPCdqvuFr7bvafR1x2/1xqDTNXVaidBPPZrnNRSSx+jSLwc6JzVc3KIuF8MohiczVhe0NkfnYemr63nbP8ABKg/RGHur/p+2F0z0ybjX/TeyOgbVc6GySy0tbQ6aooJ4HorcOZIyNHNX5UVFOTHzz3Ur9cNuZ+Ftf8ApT4b31A79amtNVYNSb3a+utsro1iqqKu1LWzwTsXza+N8itcnyKiobiiYnunVDwIAOVkOgPZM7Z7b7j3Lc6PcPb7TWqG0EFoWkberTBWpTq91XzWPvmO4cuLc4xnimfJDn8dJuxm/bTdn7Xsv5VYYr/Csd293zsPTV9bztn+CVB+iKv6XummRisd09baoi/wdKUCL/ekWT5erC9XnTnTXuRfdPXattdyodO1c9LWUU74J4JEZ4PZIxUc1yexUVFOJVD1V9Tdvqo6yDqD3FfJE5HNSfUtZMxV+VkkitcnyKiocVNM1ebUzEOvO5HZ39KW4tBNAzbaDTFa9FSKv09ItG+JfekSZhd/ajX7xyj6selPWXSrrqHT17q23ax3Zj57LeY4ljbVRtVEex7MrwlZybyblUw5qoqovh1m6DN+dV9Q3T9R6w1z3ct+ttxqLNXVUcSRtrHRNje2bg1Ea1VZKxHI3CcmuVERFwngu1Y0tbr30rzX2qhYtXp2+UNXSyY+MneOWB7UX3KkuVT3tRfYWmqYnEkxExlpJ2XmhtFbgdRV0smvNH2TUluj0pWVLKO72+GsgbK2ppUbIjJWuajkRzkRcZw5fedVvnYemr63nbP8EqD9EcxeyN+qdu/3HV351RnXDVs01NpW81FPK+KWK31L45GOVrmOSNyoqKniiovtFyZ6ins8Q7pf6aXIrV6edtML7tJ0Cf8A8R4bXfQD0m69opaap2jttlne1Ujq7E51vkhX+E1sapGq/I9jk+Q48UXVV1NUFSyqg6g9xXPjVHIk2pqyZi/ZY+RWr9hUOznRRunrLebpq0huBr9yS3ytZVU9TVJEkaVfcVMkLZuLUREVzY0zhETkjlRETwRVTNPOSJiXI/rH6Tr50p7g01kdcn3fTN9ikqbHc3sRkkjGORJIZUTw72PkzKt8HI9jkxlWtwAdXO2LdbE2o0CyVWesV1DMtOi45dylM7vcfJyWHP3jlGctE5jLMxiX6C7Z0ydNsltpJJOnvbRznQRq5y6ToFVV4p4r+xHKbtNdFaN0F1KNsWhdJWbTlt+DtDP6HaaCKjg7xz5uT+7ia1vJcJlcZXCHaS0/tXR/a8f5KHHTtYfqqWfcxb/y5jitzy1PZvD0c6C6bN8unXR+uKzYXbSouzaT1beHO0pQK9a6n/Y5Hv8A2Lzk4tl+xIhrJ2q/Tbo3b6i0Zuptpoizactcz5bFdaaz2+Kjg75eU1PKscTWt5ORJ2q5UzhkaZ8j/bsgd4PV2qNW7H3KqxBeIG3+1sc7CJUxYjqGp73PjWJ32IFN7erLaNN7+nzWe38FMk1xqbe6rtaY+N6dAqSwIi+zk9iMVf4L3DPTUd4fn7PbbJ7a128O7Wk9srfzR+obpDSSyMTKwwZ5TS/2Imvf/ZPFKitVWuRUVPBUX2HQTshtovXe4uqN5rjS8qbTNElptz3J4LWVPjI5q+9kLVavyVCHLVOIyxEZl0Mh6XOmiCGOBnT1tsrY2oxFfpWhe5URMeLliVVX5VXKnGTrb1BoO9dSOq6DbPSdg0/pzTsyWOlp7LboaOCV9Pls8qtha1rnOmWXD8ZViMTOEQ7OdTO7UOx+xWsdyllYyrtduey3I7x510qpFTpj2p3r2Kv8lFX2H58JppqmaSoqJXyyyuV73vcquc5Vyqqq+aqpx2/Vqpt92ZGwdk3l3vrr/rPTtDedMaOtrqipo6+lZUUtRV1COip45I3orXJjvpEyi+MTTqn87D01fW87Z/glQfojDXZm7P8AzMOma2X6vpe6u2up3X+oVyfGSmciMpW59rViakifLM4yprLqG0/o/qM0JsBV90tZrK03CvWRzsOgkiwtMnuxIkVYnj++YxE88GapmZ4WIxDRbtVOmnRmhLJo/djbHQ9l05bmzyWO701mt0VHAr3ostPM6OJrW8vizMV6plf2NM+CIasdEGndP6s6qdvtO6qsVvvNqra6dlTQ3ClZUU87UpZnIj43orXIioi+KeaIp2f6mdpYd8NitY7arEx9XdLc99uV3hwrolSWnXPsTvWMRf5KqntOAFlvmptFX6G9advFzsN6tsju5q6KokpaqmkwrXcXsVHsXCuRcKi+KoclE5pwlXEv0A/Ow9NX1vO2f4JUH6IfOw9NX1vO2f4JUH6I4b/PPdSv1w25n4W1/wClOivZNbmbkbj2rcyTcPcDUuqH0FRaW0jr1dp61adHtquaRrM93DlxbnGM8Uz5GKqJpjOViYltn87D01fW87Z/glQfoh87D01fW87Z/glQfojz3WtqC/6V6WtwtQ6Xvlws91oraySmrqCpfT1EDu/iTkyRio5q4VUyi+SqcWPnnupX64bcz8La/wDSimmaozkmYhtx2s+2W223FZte3bzb3TWl23CK8rVpZbTT0SVCsWj4d53LG8+PN2M5xyXHmpuJ0y9O/T/f+nXbO933Yzb643Gv0pa6mrrKvTNFNPUSvpmK6SR7olc9yqqqqqqqqqcXNZ7m7k7jupHbh7hal1Q63pIlIt6u1RWrTo/jz7vvnu4cuDc4xnimfJDvL0n/AFMW1H3HWj81jLXE00xCRzL6vnYemr63nbP8EqD9EPnYemr63nbP8EqD9EaV9rDutujtzqrbun293I1TpeKtt9wfUx2a8VFE2dzZIkar0ie1HKiKuFXOMqaF/PPdSv1w25n4W1/6UkUTMZyszEOkvaR7I7MaF6X7lqDRO0WitPXSO72+NlbarBSUlQ1jpMOakkUbXIip5pnxORx7XVW928+urQ/T+tt3da6htcj2yPorrf6urp3PauWuWOWRzVVF8lx4HijlpjEYlx1TlDvIqWcVNwQAAqgAAAAIAAMhVfMsVCwAANAADMgACBDvIkoq5LAAA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFk8ipLV9hJFgAZAAAAAGoAi4AAsCEXBIZAAAAAbAAAAAF0XJ2+7M/6jXRP2xdf8xqDh8dwOzO8ejTRP2xdf8xqDhuxwtEctg9Y7e6B3EooLduBofT+pqSll7+CC82yGtjikwqc2tla5GuwqplPHCqeT+dh6avreds/wSoP0Rrd2q+4Wvtu9p9HXHb/XGoNM1dVqJ0E89muc1FJLH6NIvBzonNVzcoi4XwyiHMj557qV+uG3M/C2v/SmKaJmM5WaoicOkPaUbJ7M6E6Yq2/6I2j0Xp66MvVBE2ttVgpKSdGOc7k1JIo2uwvtTPickj2mqt7N5td2l1g1vu5rTUNrfI2V1Fdb/V1cCvb9K5Y5ZHNynsXHgeLOWmMRiWZnL9BXSf8AUxbUfcdaPzWM0M7ZP92G2X9WXL/FhN5OjW7U166Vtraylej2R6ZoqRVT+HAzuXp950bk+8aYdspp+u9I2v1UyFzqNGXS3yyInhHLmnkYir73J3mP+RTio/E3P4XNM7rdnp9Rxtv9qVv5/UHCk719DWn67THSXtna7jC6KZ9m9O4OTCoyplkqGf3tlav3zV3slPdq72yf7jtsv6zuX+FCaidnb9WVtx9sXD/Lqk2s7Za7U7bXtZYkeizyVF2q3NRfFrGtpmoq/ZVy4/5VNU+zt+rK24+2Lh/l1SKfwE/id0jXa7dnx0gXy+1upbttAypuNxqpa2qlffbniSaR6ve5WJUcUy5VXCJjx8sGxJxu1j2j/VloXeDU1ug15QXSz2fUFdSQWyuslGkKwRVD2sjc+KNkqpxaiZ55+XJx0xM9mpmI7us1n03o/ZrQTrToTRPodms0D5YLRY6NHSSL5uSONFRZJHLlVVVy5V8VVTjn11dY+pupPVEOkIdN1+l9K6Wq5e5tNwbwrZaxMsdNVM8mSNTkxI0zw5Pyqq7w619OW+mneovaWz7n6fi9GWsR1PcKFX83UNbHhJYVX2oiqjmrhMscxcJnBpL2sXTVROtlF1J6StjYqqCWK26oSFmEljdhtNVux++a7ELl81R8X8E1RxVylXMcNF+lijp6/qX2rpapEdE/WNoVzV8nYq41wv2cYP0HH5xNstWroDcjSmu2tc5dOXuhu3Fvm7uJ2S4+/wAD9GdvuFFdqCmultqY6mkrIWVFPNGuWyRvajmuRfaioqKn2S3fIpcM+0Or6u4dY24r6tzlWGpoqeNF/exsoadrcfJhM/fNczdftWdo7to/qDbudHRPWza5oYJG1DW/EbW00TYJYl9zu7ZC/wCXmuM4U0oOSntDE921XZi3Cro+sTSlPTuckddQ3SnnRPJY0opZERfk5xs+/g7bHJTskNo7rft37zvBU0b22bS1uloKeoc34slfU4Tg1fbxh7xXY8u8Zn6ZDqxqfUVq0hpu66svlQkFustFPcKuVV8GQxMV73fea1Tiuc1N09n55d6aOnt28eu7fSIiQUuprpDEieSMbVSIn/ZDuv0n/UxbUfcdaPzWM4DajvdTqXUN01HWIiVF1rZ62VEXOHyvV7v+7lO/PSf9TFtR9x1o/NYzVztCU92Mesrog+e3vGmLt8074KfBymqafu/Uvp3f969js57+Ljjh5YXOfYYz2V7JzbzbfW9s1nrrcmt1mlnqY6ylt7LU2gpnzMcjmLMneyukajkReKK1FwiLlMouTOsrrf8AnSLxpi0/Mx+Ffwjpqmo7z116D3HdPY3GO4l5Z5+eUxj2mtNw7Zm6SQObaunqlp5lReL6jVDpmovvVraVir/eZjrmOFnGeXTaoqIKSCSqqp44YYWOkkkkcjWsaiZVyqvgiIniqqcGetveW176dSGqdaadqEnscD4rVapk8pqenYjO9T+S9/eSJ/Jeh/a6gOvrqB6g7ZPpm83ik07pqo+LNaLHG6GOpb/Bnkc50kie9quRi+fHwTGt5uijp5lJnLt92Z/1Guifti6/5jUGwWsdvdA7iUUFu3A0Pp/U1JSy9/BBebZDWxxSYVObWytcjXYVUynjhVNfezP+o10T9sXX/Mag8J2q+4Wvtu9p9HXHb/XGoNM1dVqJ0E89muc1FJLH6NIvBzonNVzcoi4XwyiHFMZqw12hsj87D01fW87Z/glQfojVjtKNk9mdCdMVbf8ARG0ei9PXRl6oIm1tqsFJSToxzncmpJFG12F9qZ8Tm98891K/XDbmfhbX/pT+PqrezebXdpdYNb7ua01Da3yNldRXW/1dXAr2/SuWOWRzcp7Fx4HJFExOcszVDxYAOVkOk3Yzftpuz9r2X8qsObJ0m7Gb9tN2ftey/lVhiv8ACsd3QjeXbv5re1WqdsvXHqr4S2ya3em+j9/6P3jcc+75N5493JPsmhFD2MtDHVRvuXUTPPTI5O8jg0qkT3J7ketW9EX5eKm++8u4nzJNqtU7m+p/Wvwatk1x9C9I7j0ju254d5xdwz7+K/YOf7+2derVSPpwa13sV2r8on3vQkOKnqx7rc482/OyuzeithdurZtnoKmmjtltR7llqHo+epmevKSaVyIiK9y+5ERERERERERNLu1x3tsdu2/suxFsr45r3eK6K73OFjkVaaihR3do9PYskqtc35Ine9FMI7kdrhvnqigmtugNJaf0akyK30zLrhVx+H7x0iNiRfsxKaUah1FftW3us1Jqi81l2utwlWaqrayZ0s0z1/fOe5VVV/8A6N00TnMszVxiG5PZG/VO3f7jq786ozsBW0dNcKOe31kfeQVMToZWZVOTHIqOTKeKeCr5HH/sjfqnbv8AcdXfnVGddNT1lTb9N3a4Ucndz01DPNE/CLxe2NytXC+C+KJ5mLn4lp7MAUXZz9GVBUsqoNloHPjVHIk17uczFX5WPqFaqfIqGX9U3qx7K7by3CxaEudbadO0iMprJpi2tlmbCxPBkMDVamERPJMYORmg+1F6rNNaipLjq/VFv1famSN9Kt1XaaSl72PPxkZLTRRuY/GcOXkiLjLVTwOwG2u4Wm919BWLcbSNUs9p1BRsrKZzsI5mfB0b0TyexyOY5PY5qoKomO6xMT2cNurjqm1T1Ubhx6kutv8AVFks8b6Sy2lJOfosTnIr3yOwnKV6tbyVERMNY1Ppcrg03u7U/pqott9fUG9mj7Y2msetJnw3WKFnGOnuyIrlfhPBO/Yjn4/hxyqv0xoic1OJjhxz3fpWtP7V0f2vH+Shx07WH6qln3MW/wDLmOxdp/auj+14/wAlDjp2sP1VLPuYt/5cxxW+7dXZrlsJujWbLbyaR3Po1fiw3OKepYz6aWld8SojT/mhfI3+0foboK+julDTXO3VMdRSVcLJ4Jo1y2SN6I5rkX2oqKin5pjtv2a+8HzU+mOzWqvqu9u2iJXadqkcvxlhjRHUrse7uXMZn2rE41cjzSmfJzG66tovmNdTer7BSUvc2q71Hr61oiYb6NVKr1a1P4LJe9jT+jOsPQftF8xzpi0jZaul7m63uBdQXRFTDu/qkR7WuT2OZCkMa/LGeO60uktOoXcLaDUdLQpLFa78lu1GqJ9NZ1Rah6uX2IiwPjb/ACqlPM2vVYqeJXOVkcUbcqq4RrWon/ZEQxVVmIhYjEua3bBbwcINHbF2yq8ZFdqS7Ma796nKGlauPevpDlRf4LF9xoHsftlX7y7uaT2xt/NH6gucNLNIxMrDT55Ty/2ImyP/ALJ/e6p93H747+6x3GjndJQV1wdBbM+SUMKJFT4T2ZjY1yp/Cc73m3PZB7P+t9a6r3tuVLyp7BTJZLY9zfBaudEfO9q+xzIka37FQcv4KWe8upFrtlBZbZSWe1UrKaioII6amhYmGxRMajWNT5ERET7xw36luoy66h6zrrvRpqs72PSl/p4rGqP/AGN1Pb5EazH8iV0b3qn/AOqv2DuLebct3tFdaW19VQrW00tOlVSOa2eDm1W95Grkc1HtzlFVFTKJlF8jSf6EF01L/wDjjcz/AOp0H6kcVExHdqqJns3P0nqa1a00tZ9YWKfvrbfKCnuNJJ/Chmja9i//ACuQ4kdoZs/8yHqf1LHRUvc2jVSpqS34TDcVDnd81PYnGdsyIieTePvOzWz211n2W23sm2Gn7zd7pbLBE+CkqLtLHLU90sjnoxzo2MaqN5cW4amGtanjjJqN2tWz/wALdmLPuxbaXnX6Ir+6q3NTxW31atY5Vx58Zkgx7ke9feKJxUVRmHIo6edjP+0+6/2zZvyas5hnTzsZ/wBp91/tmzfk1Zy1/hZp7tp+vT6kLcz+qo/ziI4OHePr0+pC3M/qqP8AOIjg4S12WruH6Cuk/wCpi2o+460fmsZ+fU/QV0n/AFMW1H3HWj81jJd7FPd63WW1O12401LUbhbb6W1RLRNcymkvNnp610DXKiuRiyscrUVUTKJjOEPOfOw9NX1vO2f4JUH6I0r7WHdbdHbnVW3dPt7uRqnS8Vbb7g+pjs14qKJs7myRI1XpE9qOVEVcKucZU0L+ee6lfrhtzPwtr/0pmmiZjOSaoicN3u1c2m2r260BoSt2+200ppiorLxUxVEtms1NRPmYkCKjXuiY1XIi+OFOavkeq1lu1unuJTU9FuDuXqvU9PRvWWnivN5qa1kL1TCuY2V7kaqp4ZQ8mq5OamnEcsTzORVyQAbUAAAAAAAGAAhV9iAFX2EABoAAJAAGQAAQvkVJcvsINQAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACyLkkp5FkXJmYEgAgAALE4AAGglFwQAiwIapIZAAFiQABoAAA7gdmb9Rpon7Yu3+Y1Bw/M4bZ9a/U3s7oyh2+243M9UWC3OldTUnqa31HdrLI6R/x5oHvXL3uXxcuM4TCeBi5TNUYhYnDtpvFsNtPv9ZqHT+7elPXtvttUtZSw+nVNL3c3BWcuVPIxy/FcqYVVTx8jE30Nvos/iY/GK7frRzN+iS9an8c/4u2n9VH0SbrT/jn/ABdtP6qcfs647SuYdAt5Oz66Q9KbQ641RYNo/RbnZ9N3Ovop/X90f3U8VLI+N/F9SrXYc1Fw5FRceKKhxnNiNQ9oN1ear0/c9L37dz0q2XijmoK2D1Ba2d7BKxWSM5Mpkc3LXKmWqipnwVFNdzVMTHdiqY8nUHsp+p/T6aak6bdY3WKjuVLVS1mmHTvRraqKVyvmpWqvh3jZFfI1vm5JHY+k8d7d2toNvt8NF1OgdyrBHdbRUvbMjFe6OSCZueEsUjVRzHplfFF8UVUXKKqL+dSGaWnlZPBK+OWNyPY9jlRzXIuUVFTyVFNmdt+0d6rtuKCG0s11BqWip2o2KLUNI2re1E986K2Z39qRTNVHOYaivyl0A0r2VXSxprUMN+q2asv8UEqSttt1ucTqRVRcojmxQxvc3+S56ovkuU8DbetrbNpuzzXC4VVHa7XbadZJZpXthgpoGN8Vcq4axjWp8iIiHIer7XPqcqKdYYdNbeUr1THfRWurV6fLh9U5v/YwDvL1Zb/79wrQbk7h1tZa+aPbaqVjKSiRUXLVdFEjUkVF8nP5KnvJ0VT3a6ojs9b129RdF1H76Vd/05K9+l7DTts9kc5qt7+JjnOfUcV8U7yRzlTOF4JGioioqH+nZ2/VlbcfbFw/y6pNcT0e3W4msdp9Z23cHQF49VX+0OkdR1fo8U/dK+N0bviStcx2WPcni1fPPnhTkxxiGM85fo9Pzpb1/wC+XXn3T3T86kMy/RJOtP8Ajn/F20/qprpe7zctRXmv1Bean0i4XOqlrKqbg1neTSPV73cWojUy5yrhERE9iGaKJp7rVOW7fZS79/APdqt2bvtbws2umI+h5uw2K6QtVWY9id7HyYvtVzIkOrOv9EWHcrRN80Dqem7+1X+gmoKpnhlGSNVvJq+xzVVHNX2KiL7D85dkvV105eaDUNjrpaK5WupirKOpiXD4Z43I9j2/KjkRU+wbF/RJOtP+Of8AF20/qpKqJmcwsVYYR3T26v20m4uodtdTR8bjp6vlopXI1UbK1q/Elai/vXsVr2/yXIdJOzb629P3LS9s6eN1r3Fb7xamtpNNXGrkRsVdTeUdG56+DZWfSx58Ht4tT4zU5c4d1d29wN7NWv11uZe4rvfJYI6aSrZQU9KskcaKjOTYI2NcqIuOSpnCImcIiJ483NPVGJSJx2fo43J2w0Fu/pOq0RuPpmkvlmq1Rz6eoRUVj0zxkje1UdG9Mrh7VRyZXx8VNWIuya6WY7x6zfV63lpufL1c+7xej4z9LlIUlx7P9pn5TnltX17dUe0dDDZrHuRNdbVTtRsVDfIW17GNTya17/2VjUTwRrXoiJ7DLLu116m1p+4TS+3TX4x3yWus5/Zx6Xx/7HH0VR2XMS6x6D0Boza/StForQGnaOyWS3NVtPSUrcNblcuc5Vy57lXxVzlVyr4qqqc7+0p62tP3axVnTrtJe4rj6VIjNUXWkkR0LGMci+hRPTwe5XIiyORcIjeHirno3Undrrl6m95qCey6p3IqaOz1LVZLbbPEyhgkYvmx6xokkjV9rXvcnyGBS028TmSavQP0FdJ/1MW1H3HWj81jPz6mwWk+vvq10Npi06N0tux6FZ7HRw2+gpvUVsk7mniYjI2c307nuw1ETLlVV9qqarpmrskThsr2yf7sNsv6suX+LCc6DI28vUNvD1A1lsuG7ur/AF9PZopIaJ/q+lpe6ZIrVemKeNiOyrW/TZ8vAxyWmMRgmcyAA0jt92Z/1Guifti6/wCY1BmPeLYbaff6zUOn929Kevbfbapaylh9OqaXu5uCs5cqeRjl+K5Uwqqnj5HE3bPrW6mtndGUO323O5fqiwW50rqak9TW+o7tZZHSP+PNA965e9y+LlxnCYTwPU/RJOtP+Of8XbT+qnDNuc5hrqjDph9Db6LP4mPxiu360eP3k7PrpD0ptDrjVFg2j9Fudn03c6+in9f3R/dTxUsj438X1KtdhzUXDkVFx4oqHP8A+iSdaf8AHP8Ai7af1U/n6h7QXq81XYLnpe/7uelWy8Uc1BWweoLWzvYJWKyRnJlMjm5a5Uy1UVM+Copemr1Mw13ABysh0m7Gb9tN2ftey/lVhzZMk7M9Ru83T5Ldp9odZeoH3xsDa9fV1JVd8kKvWP8A94ifxx3j/pcZz45whmqMxgjiXbLrK+pW3T+5it/IOAhn/WXXp1Ybg6VuuidX7ren2W9Ur6OupfUVti76F6Yc3nHTte3Ke1qovymACUUzTHKzOQAG0btdkb9U7d/uOrvzqjOtus/3H33+rKr/AAnH57to96dy9idTzay2q1L6jvE9G+3yVPodPU8qd72PczhOx7Ey6Ni5xnw8/FTLlb2jHWVcKOe31m8XeQVMToZWfB61JyY5FRyZSmyngq+RxVUTM5aicNbTpp2Rm/fOG/dO9/rfGPnfdPo9371VRKqBufl4So1PfMpzLPQaB19q/a7V9s17oO9S2m/WeVZqOsjjY9Y3K1WO+K9HMcitc5qtcioqKqKhuqOqMMxOHfTqS2Ztu/2y+ptsK5ImVFypFkt0708Kauj+PTyZ80RHoiOx5tc5Pafn2u9puNhutbY7xRyUlfbqiSkqqeVMPhmjcrXscnsVHIqL9g2N+iSdaf8AHP8Ai7af1UwJrnW+pdyNW3TXWsq+Ktvd5nWprqmOlhpkmlVERX93C1jEVcZVUamVyq5VVUzRTNPdZnL9HNp/auj+14/yUOOnaw/VUs+5i3/lzHiYu0f6z4ImQRby8WRtRrU+DtqXCImE/wDuph3djeLcbfHVSa23R1F66vSUsdH6V6JBTfsLFcrW8IGMZ4K53jjPj5koommcyszmHjDdfspt4PgLv9Vbc3Cq7u26+oVpmNc7DUr6dHSwKv2WLOxPe57TSg/p6Z1JfNG6jterdM3B9Bd7NWQ19DVMRFdDPE9HseiORUXDkRcKiovkqKhyTGYwzHD9Jprn1/7wfMd6YtUV9HVdzdtSMTTlsVHYd3tS1ySOavmitgbM5F97WnMP6JJ1p/xz/i7af1UxzvL1Pb6dQNHbLfu7ruS/U1mllmookt9JSNjfIjUc5Up4o+a4aiJyzjxxjK54otzE8tzUxad7+irZ/wCYl026P0lVUvcXWspfXF2RW4f6ZU4kcx3yxtVkX/wkOC9DWT26tp7hSrGk1LKyaPvI2yN5NVFTLHIrXJlPJUVF8lRTZH6JJ1p/xz/i7af1U3XTNXEMxOG+nXr12au6YNVaa0RtpZ9OXS73ChluV0S8wTzNggV/CnRiQzRqjnKyZVyq+DW+Hiar/RfupX/gfbP/AOmV/wCumou526Wvd5dY1evtytQPvN9rWRRzVToIoUVkbEYxrY4mtY1Ea1PBrUyuVXKqqr5URRERyTVLqX0h9pZuRvVvjZ9r91NO6Pttuv8ADPBRVNppamGVta1nONrnS1EjVa5GPZhGoquczx80XfPcXRFo3L0FqHb6/MzQaittRbZ1xlWNlYrebf5TVVHIvsVEPzpac1DedJagtmqtOV76G62erhr6GpYiK6GeJ6PjeiKioqo5qLhUVPDxNh/oknWn/HP+Ltp/VTNVvnhYq9Wv2r9L3fRGq7zo2/wdxc7FXz26sj/gzQyKx6J8mWqdJexn/afdf7Zs35NWc49f691XuhrC5691xco7hfbxI2atqmUsNMkr0Y1vLu4WMYi4amcNTK5Vcqqqvr9mepje7p8hu1PtDrX1BHfHQvr09W0lV3yxI9I1/wDERP447x/0uM58c4Q3VEzGEicS7Kden1IW5n9VR/nERwcM86966Oqfc7SFz0HrjdL1lYrxEkFbSepLdD3rEcjkTnFTte3xai/FcnkYGJRTNMYlKqokP0FdJ/1MW1H3HWj81jPz6mwWk+vvq00Npe06N0vux6FZ7HRw2+gpvUVsk7mniYjI2c307nuw1ETLlVV9qqK6Zq7FNWJ5djN5emHY3qBrLZcN3dD+vp7NFJDRP9Z1lL3TJFar0xTysR2Va36bPl4GOfobfRZ/Ex+MV2/WjmavaTdafs3n/F20/qo+iS9an8c/4u2n9VM+zr9WsxPk3I6zOh3pc2o6aNbbg6A2w9V3+0QUj6Or9d3GfulfWQRuXhLO5jsse5PFq+efPCnJ4ztuJ1xdUe6+jblt9r/c/wBaWC7tjZWUnqS3Qd6jJGyNTnFA17cPY1fByeWPLKGCTloiYjlJx5AANIAAAAAzMgAVfAIhV9hAAaAAFAAGZnIAAgQq4HkVVcliA8wAaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFwQALghPIkwAAAAALEgADR5FkXJUBJhYBFyAyAALEgACgACgAAEo73kAIuChbl7yYTCQM5BE7AAC5AAFAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAMgACZyAjl7iM5LgwlXe4qAVQABQAAAAEAAEmQAKuAgq4KquQq5AaiAABQABmZAAEACAIVfYQAbAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABKLgsUJRfYSYFgAZAAAAAFiQABoJRSAEWBCKSGQAAAAGonIAAoAAAAAEo5SAEWyiklCcqTCYWN3emjoh2o3l2bsm4ep9QaspblcpKtksVBV0zIGpFUSRt4o+B7k+KxFXLl8c+XkaQ8vedY+g1c9L2lP6a4/nsx+f/aPues2naaL+iuTRVNyIzHp01Tj9Id3sOmtanUzRepzHTP84eL+hobE/wDFmvP+vo/1U/wquzN2VfGqUWs9bRSex0tTSSIn3kp2/wDqel66d4Nxtm9B6dvW2+ovVFZXXdaWol9EgqOcXcvdxxMx6J4oi5REU1f2g68d+2bg2Og1tqCm1HZ7hXwUdVTyW2mgkbHI9GK+N0DGLzTOURcouMY8cnhdqt+Mt327/E9LrPd54mfenp78dOPlmXcamratLf8Au9y1zxzjjn65/R/a3a7OHWulbVU37bTVDNUx0zFlfbZqb0esVqeaRKjnMld7cfEVfJEVcIunb2Pje6ORjmPYqtc1yYVFTzRUO8JyC6x7BbtNdS2ubbaomR08lZDWqxnkklRTRTyfY+PI5fvno/s88Ya7fL1zQa+Yqqpp6oqxETiJiJicYjzjHHrnL4d82uzo6Kb1niJnEx/fyf7dI+yWld+9zqvResLhdqOhp7NPcGyW2WOOVZGSwsRFWSN6ccSO9mconiba3rs3NjrdZ6+4Qaq106SlppZmI+uo1armsVUzil8vAwX2bP8Av9uX3MVf5xTHSLVP7mLv9oVH+G46Tx54i3Xbd8jTaS/VRR008R257vs2bQ6bUaP2lyiJnMuGAAP3F5AAP6mltOXPWGprVpSzRd5XXithoaZvsWSR6Mbn5Mr4r7jFddNuma65xEcysRNU4ht70udDmi94NqqfcLcO86koJ7nVzpQQ2yeCJi0saoxHuSWF6q5ZGyeSonFG+8y79DQ2J/4s15/19H+qmzmjdLWzRGk7Po6zs40VloYaGDwwqtjYjUcvyrjKr71U/wA9Ia10/rmhrbhp2sSoht9yq7TUKn72op5XRyJ9jLeSL7WuavtP5m3Dxtvmq1N7U6a/VTa6uIjtTEzPTHb0h7+xtGjt26bdyiJqx+fq4tbh6MuO3eub7oa65WpslfNROeqY7xGOVGyJ8jm4cnyOQ88bi9pNtn6i3Fs25tDT8abU1J6JWOanh6XToiIqr/KiWNE/onGnR/QXh7dI3nbLOtjvVTz/ABRxV+sS8TrtPOk1Fdn0n9PL9Eo1XKjWoqqq4RE9pt1sb2emtNeW+m1NufdpNJ2yoakkNAyFH3CVi+SuR3xYMp5cuTve1D6ezy2It2ttTV+7eqKFlTbtMTsp7XDI3kyS4K1HrIqL4L3TVYqJ/Ckav706G6j1FZtJWG4an1FXx0VstdO+qqqiRfixxtTKr71X3Iniq4RPFT888ceOtVoNV/hW08XIx1VYzOZ7U0xzGfWeeeIxMO82jZ7d63951P4fKP3lgOy9n9002qBsNdpm63h7Uwstbd52ud8q9w6Nv9yH+OoOz46b7xTuitllvNikVF4y0N1lkVF+xUd4i/3Gt26naN7nXu8VFPtVQ0WnLPG9W089TTMqa2ZqL4PfzzGzKYXijVx/CU8rpvtB+o6y1bJ7vebPqCFFTlDXWuKJFT24WnSNUX+/7B1tnw145uURqZ1c01d+mblWfyxNP6vor1+z0z7P2WY9emP/AOv5vVN0m1fToltvFJq2K9Wa8VD6en7yBYamJ7W8sPRMtcmP3yKnj+9Q/k9I+yWld+9zqvResLhdqOhp7NPcGyW2WOOVZGSwsRFWSN6ccSO9mconiey6ouqrTnUXtvpiihsVVZb/AGm5STVtI93ewOY6Lij4pURMpnza5EVM+3zPv7Nn/f7cvuYq/wA4pj2NWs3jTeFb1/cJmnU0RVzxE8TxPHHbzju6qLWlublTRY5tzMfy+PLOl67NzY63WevuEGqtdOkpaaWZiPrqNWq5rFVM4pfLwObx3P1T+5i7/aFR/huOYvST0jXXe+5R6w1hDUUGh6KX4z0yyS6SNXxhiXzRiL4PkTy8Wt+NlW+a8DeLbsaLV6zer81U2+jGe/PVxEeczjs7DeNspm7ataSjE1Z/bu+XpW6Q73v3Vu1HqWats2iqZzo31kKNbPWyp4d3T82q3DV+meqKiY4oirnjspfuzu6cNL2as1DqHX2tbfbbfC6epqZ7lRNjiYnmqr6L/wD6q+CG1FTU6P200g6oqH0Fg05YKRMrhIoKWBiYRERPL2IiJ4qqoiZVTl91XdWF736vLtP6ffUW7RNvmzS0irxkrnp5Tzon/wC1nk1PevifHtu8eIvG251VaK5NjT098eUenxrn8o+Tl1Gl0O06eIu0xXXP6/0hhzcFu38eq62HbBL27TsLu7pJrxNHJUzonnIqRxsaxHeaNwqonmufBN4NqOz72Z11tjpTWl31NrSGuvtmpLhUR01bSNiZJLE17kYjqZyo3KrjKquPapz8Oz3Tn/uC26+5i2/m7D0P2i7nrdj0Gn+43qqZ6sTOeZiI85fDsWns6y9X7amJjGf1c7Osjp00T083jTNv0XdL5Wx3qmqZqhbpPDI5ro3sRvDu4o8J8Zc5z7DXQ3e7UD90+gvtCu/xIjSE9N4M1l/X7Hp9TqapqrqiczPefeqj+Tr91tUWNZXbtxiIx/KA2S6NOmzQ3URVasg1rdb7RNsMdE+m9Vzwxq9ZlmR3PvIpM47puMY818/Zrab09l1+2G4/9Davyqoz411uo2/Yr+p0tU0109OJjvGa6Yn9JXabVF/WUW7kZic/yl/T3k6AtnNvNq9U64supdZT19ktk1bTx1VZSuhc9jcoj0bTtcqfYVF+U0DOyfVB9TzuF/UFV+QcbDofs13bW7tob1zW3JrmK8RM+mIfZv8AprWmvUU2acRMfu2P6ZOjPU+/NJ8Lr5c36f0k2R0UdUkXOornNXDkgavgjUVFRZFymUVERyo7G49k7P8A6abVTNgr9MXS8vb5zVt3nY932UgdG3+5DN+gtLUGiNE2HSFrhbHS2e3QUcaNREzwYiK5ceaqqKqr7VVVNI+qzrX3c0RureduNu3UVjpLE6OF9XLRsqKmokdG16uxKjmNZ8dEaiNyqJnPjhPDxvfiLxtudzT7Xem1RGZiIqmmIpicZmY96ZnMevwiIdx900O06em5qaeqZ+Gefhnhm27dn/00XGNWUel7pa3KmEfSXeocqfL+zOen/Y1n6p+iXSeyOgJ9xdJa0u1VT09XBTLQXGGOR7u8djKTM4ImPdwXPvQ8dZO0A6l7VUNmrtT2u8sRfGKttEDWr9nuGxu/7n9nenrbfvns1Wbe6j0Q213mSrpqllXRVHOlkSN+XIrH/Hj8PL4z/vHpNr2fxntWvszf1HtbPVHX7/V7uefxxE/ly6/UavadTZr6KOmrE44xz9OPzfxejbpy0R1DXTVFDrS63yijslPSy062ueGNXLI6RHc+8ikynxExjHtNovoaGxP/ABZrz/r6P9VNJdh+o3W/TzWXiu0Xa7HWyXuKGKoS6QTSI1I1creHdyx4X465zn2GYfol++3/AAnoP/oKz9aPv8R7Z4u1O5V3NqvdNmcYjqiPKM8Y9cuHQanbLdiKdTRmvnPHxZ5+hobE/wDFmvP+vo/1UfQ0Nif+LNef9fR/qpm/p43Gve7Wzem9w9R0tDTXG8RzvniomPZA1WVEkacUe5zk+KxM5cvjn7BjvrH6itbdPNk01ctF2uyVst5qqiCdLpBNI1rY2MVFb3cseFy5c5yfm+m3nxVqty/wm3qqva9VVPeMZpznnHwl31zS7ba0/wB5qtx04ie3q8p9DQ2J/wCLNef9fR/qpoz1F7b2PaLebUe3em6uuqbbaH0zYJa6Rj53d5TRSu5KxrWr8aRUTDU8MfZM2/RMN9v+E9B/9BWfrRrpupuVfN3de3XcTUlJQ01yu6xOnioY3sgb3cLIm8Wvc5yfFjRVy5fFV+wfqnhLbvE+k1lde9Xeq30zER1RPvZpxPb0y85ud7b7tqI0lOKs+mOMT/2eVCqiFcqQfoWHR4SrvcQAVQABQAAAAAAASQABkAIVfcBKrgqAGsYAAFAAEmQABkAAAqq+wKvsINRAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFLFCUX2EmBYAGQAAAABYkAAaBnAAEouSSpKLkMzCQAEAAFyAANAAAAAAAAB1k6DPqXtKf01x/PZjk2dZOgz6l7Sn9Ncfz2Y/MftY/wCCW/8A1af+mt6Dw3/5ur+Gf5w9tvrsDo7qDsNu09rO53miprZWLWwutc0Ub3P4KzDlkjeiphy+SIufaY9256Cti9uNVUOr6aTUN7rbZM2ppI7tWRPhimauWScIoo+StVEVOSqmUTwPl6694dxtm9B6dvW2+ovVFZXXdaWol9EgqOcXcvdxxMx6J4oi5REU0+091/dS1nukNbdtWUN9pY3oslHWWmliZI32pygjjen2UU8N4d2HxPuWz9W26mKbNXVHR1TE9+e1OOf4nb67WbfY1WL9vNcY5xE/Lz/Z0u3O12/bfRlw1bFpa86hkoo1cygtVOss0i4XxXH0rEx8Z2FwmVwvkcaNwtcXncnW9613f1Z6feqt9VK1meMaL4Njbnx4tajWpnxw1DtLoTVlJrzRVh1tQQPhp79baa4xxPXLo0lja/gq+1U5YX7Bza7Qnayy6A3fpNR6eo46Sk1dRurp4I2o1jaxj+MzmonkjkWNy/ynOX2n3fZdrNPo9xu7fet4vVROKs/6eZpx5ds588fJw+IrNy9Ypv01e5Hl8/N9nZs/7/bl9zFX+cUx0i1T+5i7/aFR/huObfZsKvzfbl9zFX+cUx0k1T+5i7/aFR/huOr+0r/mOP4aP3fR4f40H1lwwBHJBlPef0Xh4PCTa7s6ts/hZvDVa6rafnQ6Oo1ljVUyi1k6OjiT7zEmd8itaaonV/oY2z+Z3sFaa2rp+7uWqnrfKnKfGSORESBufd3TWOx7Fe48N9oe7f4XslyimcV3fcj5T+L/APXMfWHc7FpvvGsiZ7U8/wBP1ZO3q3Ah2s2p1Pr2R7WyWm3yPpkd5OqXfEgav2ZXMT75p32aW5sy3rVu2N0rHSOuDUv9H3jsq6ZqpHUeK+bnI6Ff7DlNhurnZvcnfTQVv0NoC7WO3wrcG1lyfc6iaLvGRtVI4293FJlOTuS5xhWNxnxMA7F9Dm/Wz+7GnNwvhRomWntdX/4yKCuq1fLSyNWOZrUWmRFdwc7iiqickTxTzPy3Yo2ePDOq0+qv0037vMRPeOjmiPrOfpL0etnV/wCIW67dEzRT3+vf9P5NhusXbP5p+weobfTU/e3Kyxpe6BETLu9p0VXtRParollYie9yHIg7xOa17VY9qOa5MKiplFQ4ydRO2rtpd5dT6KjhWOipqx1Rb/DwWkmTvIURfbhrkaq+9qnpfsm3bqovbXXPb36flxFX64n6y6/xNpsTRqKflP8AOP3dHOhGy09o6ZNLzxMRstzlrq2dU/fPWqkYi/8AyRsT7x5PtHtT1tl2KorHRyuY2/3ynpqlEXHOCOOSbiv/AMSOJfvHo+gbUVNfOmmw0MUiOmslXXW+oRF+lf37pmov9iZh/K7Q3RVfqnYL1xboHSv0zdYLnO1qZX0dWPheuPkWVjl9yNVfYeT0802/HEzqv/r1d/4p6f1xh2dzNWz/AOz/ANEfy5/dy6AB/STwOQ2t7Nn/AH+3L7mKv84pjVI2t7Nn/f7cvuYq/wA4pjzPjL/gOq/gl2G1T/vtv5umNTTQ1lNLSVMfOGdjo5G5xya5MKnh8inz2+32vTlngtlpt8VHb7dAkUFNSw4bFExMIxjGp7ETCIiF7pW+rbZWXHuu89Fgkn4Zxy4tVcZ9mcHkdn94NGb26Np9ZaMru8ifiOqpZFRJ6KfGXRStTyVPYvk5MKiqin8t0WL9Viq9TEzbpmImfKJnOM/PE4fo010RXFEz70xw5tdWfVLqTfHUU2mrfFV2fSFpqHNp7dKixzVErFVFmqW/wvPDF8GfKuVNeTpV1i9HFPubBVbm7ZUEcGrYWLJXUMaI1l2aifTJ7EnRPJf3/kvjhTmzUU9RR1EtJVwSQTwPdHLFI1WvY9FwrXIviioqYVFP6a8E7lteu2ui3tlPRFHFVHnE+s+ue/V5/CYmI/Pt3saixqJnUTnPafKY/bHo/wAzs905/wC4Lbr7mLb+bsOMJ2e6c/8AcFt19zFt/N2HlPtb/wDIaf8Ajn/pdj4YnN6v5fu0/wC1A/dPoL7Qrv8AEiNITd7tQP3T6C+0K7/EiNIT1XgH/lzTfKr/AK6nXb3P+/3Pp/KA3p7Lr9sNx/6G1flVRosb09l1+2G4/wDQ2r8qqM/aF/y3qf8A7P8ArpNjn/f7f1/lLarqg+p53C/qCq/IONh2T6oPqedwv6gqvyDjYea+yT/h1/8Aj/8AbDsPE/8A8+j5fu7HdNW81i3p2stF9oK+J92oqaKkvNJyTvKeqa1Ecqt8+L1RXNXyVFx5oqJ9O6XTfs1vJUpcdd6Mgqbk1iRtuFPK+nqeKeSK+NU5onsR/JE9xyE0drrV+3t6j1DonUldZrjGnFJ6SZWK5vta5PJ7V9rXIqL7jZjRnaS7y2NkdPq6wWHUsTMcpVidR1L/ALLo1WNPvRnUbr9nO66DWVazYbuImZmIiqaKoz5RPaY+sfGPN9Wm33TX7UWtbT+mYn4swaw7Mrb+uZJLobcG92iZcq2O4wx1sWfcnBI3Inyqrl+yajb49L+6ewsrKnVduhrLNPJ3UF3t7lkpnP8ANGPyiOjdj2OREXC8VdhToB0+dau3+/F9j0b6lr9O6jmifNBSVEjZ4ahGNVz2xStRFVyNRzlRzG+CKqZwpmnX2jLPuJou86Iv1OyahvNHJSyI5ueCuT4r09zmu4uRfYrUU6/S+NPEXhrXU6Te4mqnjMVRGcT501R3/OYnGHPd2jQ7hZm5pOJ8pjtn0mJ/7OHZGULTwyU08lPKmHxPVjk+VFwp/mf0BERPLxWHXbon+pf0N/QVn57OYS7UH9ymg/6wrf8ADjM29E/1L+hv6Cs/PZzCXag/uU0H/WNb/hxn86bF/wA9z/613/3vdaz/AINH8NP7OewAP6MeGAAAAAAAAAAAAAZyAAIBVwFXBULECqqgANAAAAAMzIAAgAABVV9wVfYQaiAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWRfeSUJRfeSYFgAZAAAAAFiQABoAAEovvJKhFwEmFgEVFAZAAAAAXIAAoAAodZOgz6l7Sn9Ncfz2Y5Nm2WwvXl8xHa607bfMq9deq31L/AE3156N3nezvlx3fo78Y54+mXOM+HkeF+0LZtdvm10abQUddcVxOMxHEU1RnNUxHeYdxsmqs6PUTcvTiMTHnPnHo226xNgNY9QejbHp3Rlys1FU2y5rWzOuk0sbHM7pzMNWON6quXJ5oiY9prDp3syN0ZrpCzVmvdLUdu5p30ludUVM/H28WSRRtz9l3956n6KV/MX+M/wDpCkvakyqxUh2OYx/sV2pFcn9yUqf+p4fatB482bRxodHZimiM45tTMZ586v2dvqb2zaq77a7XMz8qv6N4tL6ctmj9NWrSdljdHb7NRQUFK1y5ckUTEY3K+1cNTK+1Tm/2jm4Vp1Xu9bNJWiqZUJpS3ugrHsdlGVcz+b4/dlrGxZ9yqqL4op8e43aIb2ayoJrTpiltekaadqsdPQtdLWcV80SZ64b9lrGuT2Khq5NNNUzSVFRK+WWVyvkke5XOe5Vyqqq+Kqq+07nwR4G1u066d03OqOvE4piczmrvMz27Z7Z75+fybvvFrU2fu+njjznt28obV9mx/v8Arl9zFX+cUx0uulF6ztlZbu97v0uCSDnxzx5NVM49uMnHrps32+d51/U65+C3r/0i1zW30X070Xjzkifz593JnHdYxx9vn4eOzn0Ur+Yv8Z/9Idb478Jb1vG8fe9BZ6qOmmM9VEcxnyqqif0fRs+56TS6X2V6rE5nyn9oPoWv8+n4sf6sfQtf59PxY/1Y+ilfzF/jP/pB9FK/mL/Gf/SF/wDiV/f3c/8AAP762Arp0yVNm6o7d0709+femyVdGlRXspPRl9GfCyonckfN+FZEr/33jx9mTrXSUtNQ0sNFRwshgp42xRRsTDWMamGtRPYiIiIcurN1mWy2dQ2oOoGq2m9Lq7vbYbdS29b5xSi4xxRvkSX0debnJFj6VuEc5PEyVfO0/uFfZa+htGzyW6uqaWWKmrF1D3qU0rmKjJeHozefFyovHkmcYynmZ8W+H/E3iKdLRVZz0W6eqeq3H+0qiOucRVHbERxGOJxwbbrdv0PtJirvM44n8MdvJl7VXaI7HaT1NddL1Fi1hXTWmsmopKmio6V8Er43qxzo3OqGq5uUXCqiZQ/l/RMdiP8AhPXv/QUf60c0XvdI5XvcrnOXKqq5VV95U9PR9l+w00xFUVTPnPV3dfPiHWTPGPydrtm94dJ75aJh13o1lbFRSVEtK+CtjYyohljXCte1jntRVRWuTDl+K5vkvgmpnaZ7ad5SaY3coKfLoHOsdxc1PHg7lLTuX5EXvkVV/hNQwL0v9W9z6b6C+2d+kPhJb7xNDUxwLcvRPRpmNVr3ovdScubeCKmE/wBmh7/eLr9tm8W21826uuyvosd3gRkdUmou8Wmma5HxSo30VOXF7WqqZTKZTKZPLbf4N3fw94kp1W32pq08Vd+qn8FUc8TVEzNOfTmYy7G/uml12gm3fqxXMek947eXn+7+D0K9RNu2g1tVaO1hXJTaZ1S6Nq1MjsR0VY3wjlcv71jkXg5fZhiqqI1Tp5V0tBdqCahrYIauirYXRSxSNR8c0T24c1UXwc1UVUx5KinCE2B2P6193NmKKDTzpYNTadp0RsVvuTnc6difvYZk+MxPJEa5HNT2NQ7rxv4Bu7xf/wAS2yYi7x1UzOOrHaYnyny54n1ie/ybRvNOlo+76j8PlPp/2Z83U7NOK43iouu0WsqW20lQ9XttV3ZI5lPlc8WTsRzlankiOYqoieLlPK6c7MbcGoq2Jq7cjT1BTZRXrbYZ6uRU9qIkjYkT7OfvGSLJ2nO2E8DXaj271RQzKnxmUT6eqai/I574lX+5D/HUHad7eU9O5dK7bair58LxbcJ4KRmfZlWOlX/sdHZ1X2hWqI0sW5mY46piiZ//ACmcT85y+uu1sdU+0mfpz/JizrK6ctt9gNr9I02jaOomuFddZWV10rJOdRUI2HKN8ERrGovk1qJ7M5XxP5nZsqnzfbl9zFX+cUxjHqA6odweoaejg1PTW632m2yumo7fRRLhj3JhXPkcqve7Hh5o3+Sh8vTZvt87zr+p1z8FvX/pFrmtvovp3ovHnJE/nz7uTOO6xjj7fPw8fZxs+73PC13Q6ufaamuKv80TmZnMRmcRxHHpHk6qdTpadxpvWvdtxMeXpHo696p/cxd/tCo/w3HHDZLe/WWxOsodWaSqucb+Mdwt8rl7iugz4sensVPFWuTxavyKqLtNdO099Z2yst3zEO79Lgkg5/CXPHk1Uzj0Xxxk0WOo8A+FNZtum1em3izEU3emMTNNUTEdWfwzOO8enwfVvW42tRctXNLXzTnnmMdvWHa3Z3ePRm9+jafWOja3nG7EdXSSKiT0U+MuilankvuXycmFTwMA9YvRzT7n09VuXtnQxwavgYslbRMRGsuzETzT2JOiJ4L+/wDJfHCmiGym9ms9itZQ6t0jVcmOxHX0Erl7iugz4xvRPJfNWuTxavintRds/opX8xf4z/6Q6G94K37w1u0avw9HXR8aqY486KoqmMx8Y+fEvsp3bR7hpvZa7iflP5xiJx/fk0SqYKijqJaOsp5YJ4HujlikYrXxvauFa5F8UVFRUVFOzfTn47Bbdfcxbfzdhy86id6tGb56hi1jZ9qvglfJPC41EN3SpirkRPiufH3EeJE8uaL4p4Ki+CpnLbntG/mf6A05ob5jnp/qC101t9K+EPdd/wB1G1nPh6M7jnjnHJce9T0XjfZ928S7Zpo0+nmLsVTNVM1Ue7xjv1YmM9sTnHeIfDtGp0236i5115pmOJxPP0xlsn1QdJ3zyNzsFx+H3wd9RwTwcPVXpffd45q5z30fHHH5c5MIfQt/58/xY/1ZH0Ur+Yv8Z/8ASD6KV/MX+M/+kPMbft/2g7XpqdJpKem3T2jNicZnPeZme8+rsL97ZNTcm7dnNU/xvEb2dAa7O7X33cn5rPrf1LHC/wBC9Q+j97zmZFjvPSH8cd5n6VfLHtyev7LlVW4bj/0Nq/Kqjx+9nX982La++7bfMm9Ueuo4Wem+vvSO64TRy57v0dnLPd4+mTzz7MGOelzqf+drqNRz/Af4R/CBlKzHrP0PuO5WVc/7KTlnvfkxx9ufD093bvEu6+GNVo90p6tTVVHTGbcZpiaJ70zFPlV3nP6Ovpvbfptwt3dPOLcROfxd8T68+jpB1Q/U8bhf1BVfkHGo3L3Q7RP5pO3modBfMe9XevqCWh9L+EHfdzzTHLh6M3lj3ck+yaaH3fZ1sWv2LRXrO4W+iqqrMc0zxiI/yzLi3zWWdZdpqsVZiI9Jjz+LpxqroE2X3G09bbzYPTNIXapoIJJJLfiSlkkdG1Vc+nf4J9iNzEMI3rsxt0IKhzdO7iaWrYE+lfWsqKV6/ZaxkqJ/ep/M227RzdLSVBS2fWGl7PqakpI2QslYq0NSrGphEVzEdGvgif8A2aGZ7V2nG1c0SLe9vtV0kntbSrTVDU++6SP/ANDyvsfH2yVTbs/7Wjy5pr/nit2PVsurjqq92frH8uH19L3QvX7M66pdytc6torldLbFMygo7ax/cRvkjdG6R8kiNc74j3ojeCeK5z4YNmNydb2vbbQd911eJo46azUUlSvNcJI9ExHGnyverWonvchqze+052wgp3O05t3qiunRPisrn09KxV+VzHyqn9ympvUB1W7j9QUkVvvfo9p0/Sy99T2iiV3dq/yR8r18ZXoiqiL4NT2NRVVV6+34S8R+K9yp1W909FEYiZnEe7E56aaY5855n1zmXPVueg22xNvSTmfr39ZmWGJJHyyOlkcrnPVXOVfaqlQD98eMdduif6l/Q39BWfns5hLtQf3KaD/rGt/w4zGOyfX98x3a+xbbfMm9b+pY5mem+vvR+95zSS57v0d/HHeY+mXyz7cHieqDq0+eRtNhtfwA+DvqSomn5+tfS++7xrW4x3MfHHHzyvmfi20+Et403iydzu2cWfaXKurqo7VdWJxFWecx5Z9Xq9TuWlubb93pq9/ppjGJ7xjPlhr0AD9peUAAAAAQAAMgADIAFVEAEKuCFXICxAAA0AAAAAzMgACAAAEKuAqlSxAAA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlF9hYoSi4JMCwAMgAAAAAAANZAAFCUd7yAEWzkFSUcEwkBFRQEAAAAAXIAAuQABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEyAAJkAAQAGcAAQrvcQFwlXe4gAKAAKAAJkAAZAAAAAAhV9hCr7EINRAAAoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlFwSVHkSYFwQi5JIAAIAAAAALkAAXIAAoMqABKKhJUBMLAjl7ycoEwAAIAAAAAuQAAyAALkAAMgAAAAKAAAAAAAAAAAAAAAAAAAAAgAAZAADIAAmQAAyAAIAAABlCFd7gYSFVCuVAXBlQAFAAFAAEyAAJkAAQAAAAhVwBJVVyQq5BqIAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJRSABbOSShKO95nAsCCSAAAAAAAALkAAXIAAoAABPJSAETyQnJUAwsCuV95PJQmEgjl8hOUBgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKe8jkDCQRyUjK+8LhYjkhAC4TyUgAAAAoAAAACZAAEyAAIAAAAABAV3uK5yXAlXe4gA0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGcFkd7yoJgXBRFVCyOJgSACAAAAAAAAAAAuQABcgACgAAAAAMr7wAGVJ5KQAmE8vkHJCADC2UGU95UAwtlPeCoCYWBUAwsCoyvvBhYFcr7xlQYWBUAwsMp7yoBhbKe8ZQqAuE8kHL5CADCeSkZUAGDK+8ABQAAAAAAAAABMgACZAAEyAAAAAAAAAhVQqqqpcCyqVVVUAuAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzgnl7yATAtnJJQlHKTAsCMoSQAAAAAAAAAAAAAXIAAZAAFyAAGQABQAAAAAAAAAAAAAAAAAAAAAAAAABMgABkAATIAAZAAEAAAAAAAAACFVEAkghXe4guBbl7iqqqgGsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKgATy95OUKgmBcFMqTy95MCwIyhJAAAAAAAAAAAAAAAAAAAAAAAAFyAAGQAAyAAGQABAAAAAAAAAAAAAAAAAAAACMoBIK8hlS4E5Qjl7iAXAZUAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABOVHIgEwLZT3klCUcMCwI5IMp7yCQAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGUHJCiSMp7yOXyEDAtyI5KQC4AAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJypAAnko5fIQCYFuSDKFQMC2U94KgYFwUAwLgoMr7xgXBTK+8ZX3kwLgplfeMr7xgXBTK+8FwLgoBgWGU95UDAtlByQqBgTy+QclIAwJypABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//9k=";
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	WEBHOOK_SECRET: () => WEBHOOK_SECRET,
	allowEvidenceChunk: () => allowEvidenceChunk,
	allowEvidenceDownload: () => allowEvidenceDownload,
	allowEvidenceUpload: () => allowEvidenceUpload,
	appendEvidenceChunk: () => appendEvidenceChunk,
	configureFromOrigin: () => configureFromOrigin,
	evidenceBytesOnDisk: () => evidenceBytesOnDisk,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	isDisconnectError: () => isDisconnectError,
	listComplaintsForUser: () => listComplaintsForUser,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	uploadedEvidencePath: () => uploadedEvidencePath,
	verifyTelegramInitData: () => verifyTelegramInitData
});
var TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
if (!TOKEN) console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
function isDisconnectError(err) {
	const any = err;
	const code = String(any?.code || any?.cause?.code || "");
	const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
	return code === "ECONNRESET" || code === "EPIPE" || code === "ECONNABORTED" || code === "ERR_STREAM_PREMATURE_CLOSE" || /aborted|socket hang up|ECONNRESET|premature close/i.test(msg);
}
function installDisconnectGuards() {
	const swallow = (err) => {
		if (isDisconnectError(err)) return;
		console.error("[epb]", err);
	};
	process.on("uncaughtException", swallow);
	process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
var API = `https://api.telegram.org/bot${TOKEN}`;
var BOT_USERNAME = "EuBlackList_bot";
var WEBHOOK_SECRET = `epb-${createHash("sha256").update(TOKEN).digest("hex").slice(0, 24)}`;
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v2-private-only";
function loadBindings() {
	try {
		return JSON.parse(readFileSync(BINDINGS_PATH, "utf8"));
	} catch {
		return {};
	}
}
function saveBindings() {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(BINDINGS_PATH, JSON.stringify(bindings, null, 2));
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var idCache = {};
var pendingPosts = {};
try {
	idCache = {
		...KNOWN_TELEGRAM_IDS,
		...JSON.parse(readFileSync(ID_CACHE_PATH, "utf8"))
	};
} catch {
	idCache = { ...KNOWN_TELEGRAM_IDS };
}
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
function saveIdCache() {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(ID_CACHE_PATH, JSON.stringify(idCache, null, 2));
	} catch {}
}
function savePending() {
	try {
		const entries = Object.entries(pendingPosts);
		if (entries.length > 1200) {
			const drop = entries.filter(([, rec]) => rec.status === "published" || rec.status === "rejected").sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
			const extra = entries.length - 1e3;
			for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
		}
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(PENDING_PATH, JSON.stringify(pendingPosts, null, 2));
	} catch {}
}
function rememberUser(user) {
	const username = user?.username?.replace(/^@/, "").toLowerCase();
	if (!user?.id || !username) return;
	const id = String(user.id);
	if (idCache[username] === id) return;
	idCache[username] = id;
	saveIdCache();
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	const keys = Object.keys(idCache);
	if (keys.length > 8e3) for (const extra of keys.slice(0, keys.length - 7e3)) delete idCache[extra];
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
var MAX_EVIDENCE_FILE = 1073741824;
var MAX_EVIDENCE_CHUNK = 2097152;
function saveUploadedEvidence(id, bytes) {
	if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	pruneEvidenceDir();
	return id;
}
var chunkCursor = /* @__PURE__ */ new Map();
function appendEvidenceChunk(id, index, total, bytes) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9._-]/g, "");
	if (!safe || index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const part = join(EVIDENCE_DIR, `${safe}.part`);
	const dest = join(EVIDENCE_DIR, safe);
	const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
	if (existsSync(dest)) return index === total - 1 ? safe : null;
	const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
	if (index < expected) {
		if (index === total - 1 && existsSync(dest)) return safe;
		return null;
	}
	if (index !== expected) throw new Error("chunk order");
	if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
	if (index === 0) {
		if (existsSync(part)) unlinkSync(part);
		if (existsSync(dest)) unlinkSync(dest);
	}
	if ((existsSync(part) ? statSync(part).size : 0) + bytes.length > MAX_EVIDENCE_FILE) {
		try {
			unlinkSync(part);
		} catch {}
		chunkCursor.delete(safe);
		throw new Error("file too large");
	}
	appendFileSync(part, bytes);
	const next = index + 1;
	chunkCursor.set(safe, next);
	writeFileSync(idxPath, String(next));
	if (index !== total - 1) return null;
	if (existsSync(dest)) unlinkSync(dest);
	renameSync(part, dest);
	try {
		unlinkSync(idxPath);
	} catch {}
	chunkCursor.delete(safe);
	pruneEvidenceDir();
	return safe;
}
function evidenceBytesOnDisk(id) {
	const path = id ? uploadedEvidencePath(id) : null;
	if (!path) return 0;
	try {
		return statSync(path).size;
	} catch {
		return 0;
	}
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	if (rateHits.size > 4e3) for (const [k, hits] of rateHits) {
		const keep = hits.filter((t) => now - t < 216e5);
		if (!keep.length) rateHits.delete(k);
		else rateHits.set(k, keep);
	}
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function verifyTelegramInitData(initData) {
	if (!TOKEN || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(TOKEN).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const files = readdirSync(EVIDENCE_DIR).map((name) => {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			return {
				path,
				mtime: st.mtimeMs,
				size: st.size
			};
		}).sort((a, b) => a.mtime - b.mtime);
		let total = files.reduce((s, f) => s + f.size, 0);
		const maxBytes = 8589934592;
		const maxFiles = 400;
		while (files.length && (files.length > maxFiles || total > maxBytes)) {
			const drop = files.shift();
			if (!drop) break;
			total -= drop.size;
			try {
				unlinkSync(drop.path);
			} catch {}
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes = 1) {
	if (bytes < 0) return {
		ok: false,
		error: "file required"
	};
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany(`upchunk:${user.id}`, 240, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("up:global", 200, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowEvidenceDownload() {
	return !tooMany("evget:global", 240, 6e4);
}
function allowEvidenceChunk(initData, bytes) {
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`upchunk:${user.id}`, 240, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("upchunk:global", 800, 6e4)) return {
		ok: false,
		error: "server busy"
	};
	return { ok: true };
}
function allowNewComplaint(userId, storyLen) {
	if (storyLen > 5e3) return "Слишком длинное описание.";
	if (tooMany(`app:${userId}`, 3, 216e5)) return "Слишком много заявок. Подождите несколько часов.";
	if (tooMany("app:global", 40, 36e5)) return "Сейчас слишком много заявок. Попробуйте позже.";
	return null;
}
function readUploadedEvidence(id) {
	const path = uploadedEvidencePath(id);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
function uploadedEvidencePath(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9._-]/g, "");
	if (!safe) return null;
	const path = join(EVIDENCE_DIR, safe);
	return existsSync(path) ? path : null;
}
async function tg(method, body = {}) {
	const json = await (await fetch(`${API}/${method}`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(body)
	})).json();
	if (!json.ok) throw new Error(json.description || method);
	return json.result;
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v1") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v1";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook) {
		await applyMenuButton();
		return;
	}
	await tgSoft("setWebhook", {
		url: hook,
		secret_token: WEBHOOK_SECRET,
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member"
		],
		drop_pending_updates: false
	});
	await registerMiniAppUrl(site);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				}
			],
			scope: { type: "all_private_chats" }
		});
		await tgSoft("deleteMyCommands", { scope: { type: "default" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
	}
	if (profileReady) return;
	profileReady = true;
	await tgSoft("setMyShortDescription", { short_description: "Закрытый европейский блеклист. Mini App → жалоба → арбитры." });
	await tgSoft("setMyDescription", { description: [
		"Europe Private Blacklist - закрытый европейский блеклист.",
		"",
		"1. /start и «Открыть приложение»",
		"2. Mini App подтягивает ваш Telegram",
		"3. На главной - Подать жалобу",
		"4. Арбитры: Принять или Отклонить, затем рассылка по чатам"
	].join("\n") });
}
async function getBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	for (const id of arbiterCandidates()) {
		if (!await chatReachable(id)) continue;
		arbiterOk = true;
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		channelOk
	};
}
async function resolveUsernameMtproto(username) {
	if (!TOKEN || tooMany("mtproto:resolve", 12, 6e4)) return null;
	let client = null;
	try {
		const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
		const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
		const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
		const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
		const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
		client = new TelegramClient(new StringSession(""), apiId, apiHash, {
			connectionRetries: 1,
			timeout: 12,
			deviceModel: "EPB",
			systemVersion: "Linux",
			appVersion: "1.0",
			autoReconnect: false,
			baseLogger: new Logger("none")
		});
		await client.start({ botAuthToken: TOKEN });
		const result = await client.invoke(new Api.contacts.ResolveUsername({ username }));
		const user = result.users?.[0];
		const id = String(user?.id ?? result.peer?.userId ?? "");
		if (!/^\d{5,15}$/.test(id)) return null;
		return {
			username: user?.username || username,
			id
		};
	} catch {
		return null;
	} finally {
		try {
			await client?.disconnect?.();
		} catch {}
		try {
			await client?.destroy?.();
		} catch {}
	}
}
async function resolveHandleServer(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (tooMany("resolve:global", 80, 6e4)) {
		const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
		return {
			username: parsed.username,
			id: parsed.id || cached || "",
			source: parsed.id || cached ? "telegram" : "unresolved"
		};
	}
	if (parsed.id) {
		if (parsed.username) rememberHandle(parsed.username, parsed.id);
		else {
			const chat = await tgSoft("getChat", { chat_id: parsed.id });
			if (chat?.username) rememberHandle(chat.username, parsed.id);
			return {
				username: chat?.username || "",
				id: parsed.id,
				source: "parsed"
			};
		}
		return {
			username: parsed.username,
			id: parsed.id,
			source: "parsed"
		};
	}
	const username = parsed.username;
	const cached = idCache[username.toLowerCase()];
	if (cached) return {
		username,
		id: cached,
		source: "telegram"
	};
	for (const rec of Object.values(pendingPosts)) {
		const hit = pendingAccounts(rec).find((a) => a.username.replace(/^@/, "").toLowerCase() === username.toLowerCase() && a.id);
		if (hit?.id) {
			rememberHandle(username, hit.id);
			return {
				username,
				id: hit.id,
				source: "telegram"
			};
		}
	}
	const chat = await tgSoft("getChat", { chat_id: `@${username}` });
	if (chat?.id) {
		const id = String(chat.id);
		rememberHandle(chat.username || username, id);
		return {
			username: chat.username || username,
			id,
			source: "telegram"
		};
	}
	const mt = await resolveUsernameMtproto(username);
	if (mt?.id) {
		rememberHandle(mt.username, mt.id);
		return {
			username: mt.username,
			id: mt.id,
			source: "telegram"
		};
	}
	return {
		username,
		id: "",
		source: "unresolved"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function applicationHtml(app) {
	const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
	const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const scammer = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Суть обмана</b>\n${escapeHtml(app.story.trim())}`
	].join("\n");
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	const multi = accounts.length > 1;
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const name = handle ? `@${escapeHtml(handle)}` : "";
		const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
		const last = i === accounts.length - 1;
		if (multi) {
			const head = [name, id].filter(Boolean).join(" ");
			if (!last) return `${head} ;`;
			return scam ? `${head} - ${scam}` : head;
		}
		if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
		return [name, id].filter(Boolean).join("\n");
	});
}
function channelHtml(accounts, story, amount = "", currency = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const scamLine = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	const head = [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		""
	].join("\n");
	let story = app.story.trim();
	const budget = 1024 - head.length;
	if (story.length > budget) story = `${story.slice(0, Math.max(0, budget - 1))}…`;
	return `${head}${escapeHtml(story)}`;
}
function reviewKeyboard(appId = "") {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: appId ? `pub:${appId}` : "pub"
	}, {
		text: "Отклонить",
		callback_data: appId ? `rej:${appId}` : "rej"
	}]] };
}
function publishChoiceKeyboard(key = "") {
	const suffix = key ? `:${key}` : "";
	return { inline_keyboard: [[{
		text: "Опубликовать с рассылкой",
		callback_data: `puball${suffix}`.slice(0, 64)
	}], [{
		text: "Опубликовать без рассылки",
		callback_data: `pubch${suffix}`.slice(0, 64)
	}]] };
}
async function tgForm(method, form) {
	const json = await (await fetch(`${API}/${method}`, {
		method: "POST",
		body: form
	})).json();
	if (!json.ok) throw new Error(json.description || method);
	return json.result;
}
var TG_UPLOAD_MAX = 51380224;
function mediaSize(file) {
	return file.size || evidenceBytesOnDisk(file.storageKey);
}
function evidencePublicUrl(storageKey) {
	if (!storageKey) return "";
	const site = publicSiteUrl();
	if (!site) return "";
	return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}`;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const size = mediaSize(file);
	if (file.kind === "video" && size > TG_UPLOAD_MAX) return sendLargeVideo(chatId, file, opts);
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	if (blob.size > TG_UPLOAD_MAX && file.kind === "video") return sendLargeVideo(chatId, file, opts);
	const form = new FormData();
	form.set("chat_id", String(chatId));
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
async function sendLargeVideo(chatId, file, opts = {}) {
	const url = evidencePublicUrl(file.storageKey);
	const extra = { chat_id: chatId };
	if (opts.caption) {
		extra.caption = opts.caption;
		extra.parse_mode = "HTML";
	}
	if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
	if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
	if (url) {
		const video = await tgSoft("sendVideo", {
			...extra,
			video: url,
			supports_streaming: true
		});
		if (video) return {
			...video,
			fileId: video.video?.file_id,
			kind: "video"
		};
		const doc = await tgSoft("sendDocument", {
			...extra,
			document: url
		});
		if (doc) return {
			message_id: doc.message_id,
			chat: doc.chat,
			fileId: doc.document?.file_id,
			kind: "video"
		};
	}
	const link = url || file.name || "видео";
	return {
		...await tg("sendMessage", {
			chat_id: chatId,
			text: [
				opts.caption,
				`Видео: ${escapeHtml(file.name || "файл")}`,
				url ? `<a href="${url}">скачать</a>` : link
			].filter(Boolean).join("\n"),
			parse_mode: "HTML",
			disable_web_page_preview: false,
			reply_markup: opts.replyMarkup,
			reply_to_message_id: opts.replyTo
		}),
		kind: "video"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	for (const a of accounts) rememberHandle(a.username, a.id);
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? `Жалоба ${appId} на ${scam} принята.\nСтатус: подано. Арбитры проверят материалы.` : kind === "published" ? `Жалоба ${appId} на ${scam} одобрена и опубликована в Europe Private Blacklist.` : `Жалоба ${appId} на ${scam} отклонена арбитрами. Публикации не будет.`,
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
async function attachReviewButtons(chatId, messageId, caption, keyboard) {
	const sent = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: caption,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: messageId,
		reply_markup: keyboard
	});
	if (sent?.message_id) return sent.message_id;
	if (await tgSoft("editMessageCaption", {
		chat_id: chatId,
		message_id: messageId,
		caption,
		parse_mode: "HTML",
		reply_markup: keyboard
	})) return messageId;
	return messageId;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard) {
	if (!files.length) {
		const sent = await tg("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: keyboard
		});
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = {
			chat_id: chatId,
			caption,
			parse_mode: "HTML",
			reply_markup: keyboard
		};
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
	}
	let firstId = 0;
	for (let i = 0; i < files.length; i += 10) {
		const chunk = files.slice(i, i + 10);
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0) {
				payload.caption = caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 ? {
					caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, caption, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard) {
	const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
	const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
	const files = [];
	let firstId = 0;
	if (!small.length && large.length) {
		const sent = await sendMediaFile(chatId, large[0], {
			caption,
			replyMarkup: keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		for (const extra of large.slice(1)) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
	}
	if (small.length <= 1) {
		const sent = await sendMediaFile(chatId, small[0], {
			caption,
			replyMarkup: large.length ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		firstId = sent.message_id;
		for (const extra of large) {
			const more = await sendMediaFile(chatId, extra, extra === large[large.length - 1] ? { replyMarkup: keyboard } : {});
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (large.length) return {
			chat_id: chatId,
			message_id: await attachReviewButtons(chatId, firstId, caption, keyboard),
			files
		};
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
	}
	for (let i = 0; i < small.length; i += 10) {
		const chunk = small.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 ? { caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 ? {
					caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	for (const extra of large) {
		const more = await sendMediaFile(chatId, extra);
		if (more.fileId) files.push({
			type: more.kind,
			file_id: more.fileId
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, caption, keyboard),
		files
	};
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const keyboard = reviewKeyboard(app.id);
	const blobs = app.evidence.filter((f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard) : null;
			if (sent) {
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const sent = await tg("sendMessage", {
			chat_id,
			text: applicationHtml(app),
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: keyboard
		});
		storePending(app, []);
		return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const userId = app.victim.telegramId || "";
	const blocked = allowNewComplaint(userId, app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
	app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
		...file,
		name: String(file.name || "file").slice(0, 120),
		dataUrl: (file.dataUrl || "").slice(0, 4e5),
		storageKey: file.storageKey && uploadedEvidencePath(file.storageKey) ? file.storageKey : void 0
	}));
	if (app.evidence.length > 30) return {
		ok: false,
		error: "Слишком много файлов."
	};
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: `Добавьте @${BOT_USERNAME} в чат арбитров админом и напишите там /id`
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseAppKey(text, data = "") {
	const fromCb = callbackKey(data);
	if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
	const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
	if (fromText?.[1]) return fromText[1];
	return parseEpbMarker(text)?.key || fromCb;
}
function stripServiceMarker(text) {
	return text.replace(/\n*#epb[^\n]*/gi, "").replace(/\n*#published[^\n]*/gi, "").replace(/\n*#rejected[^\n]*/gi, "").replace(/\n*Статус:[^\n]*/gi, "").trim();
}
function alreadyHandled(text) {
	return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
async function sendPostToChat(chat_id, html, files) {
	const caption = html.length > 1024 ? `${html.slice(0, 1023)}…` : html;
	if (!files.length) {
		await tg("sendMessage", {
			chat_id,
			text: html,
			parse_mode: "HTML",
			disable_web_page_preview: false
		});
		return;
	}
	for (let i = 0; i < files.length; i += 10) {
		const chunk = files.slice(i, i + 10);
		const firstCaption = i === 0 ? caption : void 0;
		if (chunk.length === 1) {
			const file = chunk[0];
			const payload = {
				chat_id,
				caption: firstCaption,
				parse_mode: firstCaption ? "HTML" : void 0
			};
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload);
		} else await tg("sendMediaGroup", {
			chat_id,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...firstCaption && idx === 0 ? {
					caption: firstCaption,
					parse_mode: "HTML"
				} : {}
			}))
		});
	}
}
function relayDestinations() {
	const skip = new Set([
		...channelCandidates(),
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId || "",
		...OFFICIAL_ARBITER_IDS
	].filter(Boolean).map((id) => chatIdKey(id)));
	return (bindings.relayChats || []).filter((chat) => chat.status === "on" && !skip.has(chatIdKey(chat.id)));
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	let lastError = "channel not found";
	let posted = false;
	for (const chat_id of ids) try {
		await sendPostToChat(chat_id, html, files);
		posted = true;
		break;
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	if (!posted) throw new Error(lastError);
}
async function broadcastPublished(html, files) {
	await sendChannelPost(html, files);
	const approved = relayDestinations();
	const keep = [...bindings.relayChats || []];
	for (const chat of approved) try {
		await sendPostToChat(chat.id, html, files);
	} catch {
		if (!await chatReachable(chat.id)) {
			const idx = keep.findIndex((c) => sameChat(c.id, chat.id));
			if (idx >= 0) keep.splice(idx, 1);
		}
	}
	bindings.relayChats = keep.slice(0, 250);
	saveBindings();
}
var publishing = /* @__PURE__ */ new Set();
async function publishFromMessage(text, callbackId, extraFiles = [], relay = false, keyHint = "") {
	const parsed = parseEpbMarker(text);
	const key = keyHint || parsed?.key || "";
	const stored = key ? pendingPosts[key] : void 0;
	if (!parsed && !stored) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	if (stored?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (key && publishing.has(key)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже публикуем"
		});
		return false;
	}
	if (key) publishing.add(key);
	const html = channelHtml(pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""), stored?.story || parsed?.story || "", stored?.amount, stored?.currency);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		if (key) publishing.delete(key);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	try {
		if (relay) await broadcastPublished(html, files);
		else await sendChannelPost(html, files);
	} catch {
		if (key) publishing.delete(key);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: relay ? "Не удалось отправить. Проверьте права бота в канале и чатах." : "Не удалось опубликовать. Бот должен быть админом канала.",
			show_alert: true
		});
		return false;
	}
	if (key && pendingPosts[key]) {
		pendingPosts[key].status = "published";
		savePending();
		await notifyApplicant(pendingPosts[key], key, "published");
	}
	if (key) publishing.delete(key);
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: relay ? "Опубликовано с рассылкой" : "Опубликовано без рассылки"
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
var channelSetup = /* @__PURE__ */ new Set();
function gcSessions() {
	const now = Date.now();
	for (const [id, session] of sessions) if (now - (session.touched || 0) > 72e5) sessions.delete(id);
	if (sessions.size <= 400) return;
	const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
	for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard() {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: "Открыть приложение",
		web_app: { url }
	}]);
	rows.push([{
		text: "Наш канал",
		url: CHANNEL_URL
	}]);
	rows.push([{
		text: "Для владельцев чатов",
		callback_data: "owners"
	}]);
	rows.push([{
		text: "Подать жалобу в чате",
		callback_data: "apply"
	}]);
	return { inline_keyboard: rows };
}
function startText() {
	return [
		"<b>Europe Private Blacklist</b>",
		"",
		"Откройте приложение, чтобы подать жалобу.",
		"",
		"Арбитры проверят материалы: одобрили - пост в канале, отклонили - без публикации."
	].join("\n");
}
function ownersText() {
	return [
		"<b>Для владельцев чатов</b>",
		"",
		"Бот можно добавить в группу или канал. Тогда при публикации с рассылкой туда уйдёт тот же пост, что в Europe Private Blacklist.",
		"",
		"<b>Как подключить</b>",
		`1. Добавьте @${BOT_USERNAME} в чат или канал.`,
		"",
		"<b>2. Сделайте бота администратором и выдайте права:</b>",
		"- группа: отправка сообщений и медиа",
		"- канал: публикация сообщений и медиа",
		"",
		"3. Все новые блеки будут автоматом публиковаться в Ваш чат/канал"
	].join("\n");
}
function ownersKeyboard() {
	return { inline_keyboard: [[{
		text: "Наш канал",
		url: CHANNEL_URL
	}], [{
		text: "Назад",
		callback_data: "home"
	}]] };
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	const candidates = [
		join(process.cwd(), "public/bot", name),
		join(process.cwd(), ".output/public/bot", name),
		join(process.cwd(), "public", name),
		join("/workspace/public/bot", name),
		join("/workspace/.output/public/bot", name)
	];
	try {
		const here = dirname(fileURLToPath(import.meta.url));
		candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
	} catch {}
	return candidates.find((p) => existsSync(p)) || null;
}
function cardBytes(kind) {
	if (kind === "welcome") try {
		return Buffer.from(WELCOME_JPEG_BASE64, "base64");
	} catch {}
	const path = cardPath(kind);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await tgSoft("sendPhoto", {
			chat_id: chatId,
			photo: cached,
			caption,
			parse_mode: "HTML",
			...extra
		})) return;
		if (bindings.cards) delete bindings.cards[kind];
		saveBindings();
	}
	const bytes = cardBytes(kind);
	if (!bytes?.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			...extra
		});
		return;
	}
	const form = new FormData();
	form.set("chat_id", String(chatId));
	form.set("caption", caption);
	form.set("parse_mode", "HTML");
	if (extra.reply_markup) form.set("reply_markup", JSON.stringify(extra.reply_markup));
	form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
	try {
		const fileId = (await tgForm("sendPhoto", form)).photo?.at(-1)?.file_id;
		if (fileId) {
			bindings.cards = {
				...bindings.cards,
				[kind]: fileId
			};
			saveBindings();
		}
	} catch {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: caption,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			...extra
		});
	}
}
async function replyStart(chatId) {
	await sendCard(chatId, "welcome", startText(), { reply_markup: applyKeyboard() });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: [],
		touched: Date.now()
	};
}
function parseAmount(text) {
	return parseDamageAmount(text);
}
function formatAmount(amount) {
	const [intPart, frac] = amount.split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return frac ? `${grouped}.${frac}` : grouped;
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session) {
	if (!session.accounts.length) return "пока пусто";
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: "Ещё аккаунт",
		callback_data: "apply:more"
	}, {
		text: "Далее",
		callback_data: "apply:next"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: session?.accounts.length ? `Аккаунты:\n${listed}\n\nПерешлите сообщение следующего аккаунта или напишите @username. Когда все добавлены - «Далее».` : "Шаг 1/4. Аккаунты.\nПерешлите сообщение, @username или t.me.\nЕсли несколько аккаунтов - пришлите по очереди, затем «Далее».",
		reply_markup: rows.length ? { inline_keyboard: rows } : void 0
	});
}
async function askStory(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 2/4. Суть обмана одним сообщением."
	});
}
async function askAmount(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 3/4. Сумма ущерба. Например: 15 000, 15,000 или 250 USD."
	});
}
async function askCurrency(chatId, amount) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `Сумма ${formatAmount(amount)}. Выберите валюту:`,
		reply_markup: { inline_keyboard: [[{
			text: "USD",
			callback_data: "apply:cur:USD"
		}, {
			text: "EUR",
			callback_data: "apply:cur:EUR"
		}]] }
	});
}
async function askEvidence(chatId) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Шаг 4/4. Скрины и видео. Пришлите файлы, можно несколько. Когда закончите - «Готово».",
		reply_markup: { inline_keyboard: [[{
			text: "Готово",
			callback_data: "apply:done"
		}, {
			text: "Без файлов",
			callback_data: "apply:skip"
		}]] }
	});
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? `${session.evidence.length} файл(ов)` : "без файлов";
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"Проверьте заявку:",
			"",
			"Аккаунт:",
			formatSessionAccounts(session),
			`Пострадавший: ${victim} · ${session.victimId}`,
			`Ущерб: ${session.amount} ${session.currency}`,
			`Доказательства: ${files}`,
			"",
			session.story
		].join("\n"),
		reply_markup: { inline_keyboard: [[{
			text: "Отправить на рассмотрение",
			callback_data: "apply:send"
		}, {
			text: "Отмена",
			callback_data: "apply:cancel"
		}]] }
	});
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Заявка на блеклист. Отмена - /cancel."
	});
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice = "Заявка отменена.") {
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: notice,
		reply_markup: applyKeyboard()
	});
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Добавьте хотя бы один аккаунт."
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || "Не удалось отправить арбитрам."
		});
		return;
	}
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `Заявка ${app.id} ушла арбитрам. Если одобрят - пост в канале, если нет - публикация не выйдет.`
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "Сначала добавьте хотя бы один аккаунт."
					});
					return;
				}
				session.step = "story";
				sessions.set(userId, session);
				await askStory(chatId);
				return;
			}
			const resolved = await resolveHandleServer(raw);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: "Не разобрал. Перешлите сообщение или напишите @username."
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: `@${resolved.username} принял, но ID не найден. Перешлите любое его сообщение или допишите числовой ID.`
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 8) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Нужно описание схемы - хотя бы пару предложений."
			});
			return;
		}
		if (story.length > 5e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Описание слишком длинное - сократите до 5000 символов."
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Напишите сумму, например 15 000 или 15000 USD."
			});
			return;
		}
		session.amount = parsed.amount;
		if (!parsed.currency) {
			sessions.set(userId, session);
			await askCurrency(chatId, parsed.amount);
			return;
		}
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 30) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: `Файл ${session.evidence.length}/30 принят. Ещё или «Готово».`,
				reply_markup: { inline_keyboard: [[{
					text: "Готово",
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите скрин или видео, либо нажмите «Готово»."
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявку нужно подать в личке с ботом",
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: `Откройте @${BOT_USERNAME} в личных сообщениях и нажмите /apply`
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Начните заново: /apply"
		});
		return;
	}
	await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
		if (!session.amount) {
			await askAmount(chatId);
			return;
		}
		session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
		session.step = "evidence";
		sessions.set(userId, session);
		await askEvidence(chatId);
		return;
	}
	if (cb.data === "apply:keep") {
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Сначала добавьте аккаунт."
			});
			return;
		}
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите следующий аккаунт: перешлите сообщение или @username."
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") await submitSession(chatId, userId, session);
}
function findRelay(id) {
	return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}
function upsertRelay(chat, status) {
	const list = [...bindings.relayChats || []];
	const idx = list.findIndex((c) => sameChat(c.id, chat.id));
	const next = {
		id: String(chat.id),
		title: chat.title || list[idx]?.title,
		type: chat.type || list[idx]?.type,
		status
	};
	if (idx >= 0) list[idx] = {
		...list[idx],
		...next
	};
	else list.push(next);
	bindings.relayChats = list.slice(-250);
	saveBindings();
}
function dropRelay(id) {
	bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
	saveBindings();
}
function chatKindLabel(type) {
	if (type === "channel") return "канал";
	if (type === "supergroup") return "супергруппа";
	if (type === "group") return "группа";
	return type || "чат";
}
async function greetRelayChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: [
			`<b>${CHANNEL_NAME}</b>`,
			"",
			"Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает."
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function notifyArbitersAboutRelay(chat, addedBy) {
	const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
	const who = addedBy?.username ? `@${addedBy.username}` : addedBy?.first_name ? `${addedBy.first_name} (<code>${addedBy.id}</code>)` : "неизвестно";
	await tgSoft("sendMessage", {
		chat_id: arbiter,
		text: [
			"<b>Бот добавлен в чужой чат</b>",
			"",
			`Название: ${escapeHtml(chat.title || "без названия")}`,
			`Тип: ${chatKindLabel(chat.type)}`,
			`ID: <code>${chat.id}</code>`,
			`Кто добавил: ${who}`,
			"",
			"Подключить рассылку одобренных постов в этот чат?"
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [[{
			text: "Принять",
			callback_data: `rel:y:${chat.id}`
		}, {
			text: "Отклонить",
			callback_data: `rel:n:${chat.id}`
		}]] }
	});
}
async function replaceReplyMarkup(msg, markup, nextText) {
	const text = nextText ?? msg.caption ?? msg.text ?? "";
	const isMedia = Boolean(msg.caption || msg.photo || msg.video);
	if (nextText) {
		if (isMedia) {
			if (await tgSoft("editMessageCaption", {
				chat_id: msg.chat.id,
				message_id: msg.message_id,
				caption: text.slice(0, 1024),
				parse_mode: "HTML",
				reply_markup: markup
			})) return true;
		} else if (await tgSoft("editMessageText", {
			chat_id: msg.chat.id,
			message_id: msg.message_id,
			text,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: markup
		})) return true;
	}
	const markupOnly = await tgSoft("editMessageReplyMarkup", {
		chat_id: msg.chat.id,
		message_id: msg.message_id,
		reply_markup: markup
	});
	return Boolean(markupOnly);
}
function callbackKey(data) {
	const i = data.indexOf(":");
	return i >= 0 ? data.slice(i + 1) : "";
}
async function handleRelayDecision(cb, allow) {
	const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
	if (!raw) return;
	const chatId = raw;
	const relay = findRelay(chatId);
	const title = relay?.title || chatId;
	if (allow) {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "on");
		const wrote = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
			show_alert: !wrote
		});
	} else {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "off");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят."
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Отклонено"
		});
	}
	const next = allow ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.` : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
	if (cb.message) await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: next,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [] }
	});
}
async function bindChat(chat, from) {
	const id = String(chat.id);
	if (isOfficialArbiterChat(id)) {
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
				"",
				"Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
				"Сменить: /channel -100…"
			].join("\n"),
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialChannel(id)) {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${chat.title ?? id}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	const existing = findRelay(id);
	if (existing?.status === "on") {
		await tgSoft("sendMessage", {
			chat_id: chat.id,
			text: "Рассылка уже включена. Одобренные посты будут приходить сюда."
		});
		return;
	}
	if (existing?.status === "pending") return;
	if (tooMany("relay:global", 8, 6e4)) return;
	if (from?.id && tooMany(`relay:${from.id}`, 3, 36e5)) return;
	upsertRelay(chat, "pending");
	await greetRelayChat(chat);
	await notifyArbitersAboutRelay(chat, from);
}
async function parseChannelRef(raw) {
	const t = raw.trim().split(/\s+/)[0] || "";
	if (!t) return null;
	if (t.startsWith("@")) return t;
	const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
	if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
	const num = t.replace(/[^\d-]/g, "");
	if (/^-100\d{6,}$/.test(num)) return num;
	if (/^100\d{6,}$/.test(num)) return `-${num}`;
	if (/^\d{6,}$/.test(num)) return `-100${num}`;
	return t;
}
async function applyPublishChannel(arbiterChatId, raw) {
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
			parse_mode: "HTML"
		});
		return;
	}
	const chat = await chatReachable(ref);
	if (!chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз."
		});
		return;
	}
	if (chat.type !== "channel" && chat.type !== "supergroup") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не канал. Нужен ID канала, куда постить одобренные заявки."
		});
		return;
	}
	bindings.channelId = String(chat.id);
	saveBindings();
	channelSetup.delete(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал для постов обновлён.",
			`${chat.title || "Канал"}`,
			`ID: <code>${chat.id}</code>`
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function askPublishChannel(arbiterChatId) {
	channelSetup.add(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			`Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
			"",
			"Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
			"Бот должен быть админом этого канала.",
			"",
			"Или сразу: /channel -100…"
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function handleUpdate(update) {
	try {
		await handleTelegramUpdate(update);
	} catch (err) {
		if (!isDisconnectError(err)) console.error("[epb] update", err);
	}
}
async function handleTelegramUpdate(update) {
	await ensureBotProfile();
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.message?.reply_to_message?.from);
	rememberUser(update.message?.reply_to_message?.forward_from);
	rememberUser(update.callback_query?.from);
	for (const ent of [
		...update.message?.entities || [],
		...update.message?.caption_entities || [],
		...update.message?.reply_to_message?.entities || []
	]) rememberUser(ent.user);
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "");
	if (tooMany("upd:global", 240, 6e4)) return;
	if (floodId && tooMany(`flood:${floodId}`, 45, 6e4)) return;
	const liveSession = sessions.get(floodId);
	if (liveSession) liveSession.touched = Date.now();
	gcSessions();
	const member = update.my_chat_member;
	if (member) {
		const status = member.new_chat_member.status;
		if (status === "left" || status === "kicked") {
			dropRelay(member.chat.id);
			return;
		}
		if (status === "member" || status === "administrator" || status === "creator") await bindChat(member.chat, member.from);
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if (cb.data === "owners") {
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: ownersText(),
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: ownersKeyboard()
			});
			return;
		}
		if (cb.data === "home") {
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await replyStart(cb.message.chat.id);
			return;
		}
		if (cb.data.startsWith("rel:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
			return;
		}
		if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:")) && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (alreadyHandled(text)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub" || cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch")) {
			const markup = publishChoiceKeyboard(parseAppKey(text, cb.data));
			if (!await replaceReplyMarkup(cb.message, markup)) await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: "Как опубликовать эту заявку?",
				reply_to_message_id: cb.message.message_id,
				reply_markup: markup
			});
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Выберите тип публикации"
			});
			return;
		}
		if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			const relay = cb.data.startsWith("puball");
			const key = parseAppKey(text, cb.data);
			if (!await publishFromMessage(key && pendingPosts[key] ? `#epb u=${pendingPosts[key].username || ""} id=${pendingPosts[key].id || "0"} k=${key}` : text, cb.id, extraFiles, relay, key)) return;
			const next = `${stripServiceMarker(text || "Заявка")}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
			const cleared = { inline_keyboard: [] };
			if (!await replaceReplyMarkup(cb.message, cleared, next)) await tgSoft("editMessageReplyMarkup", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				reply_markup: cleared
			});
			return;
		}
		if (cb.data === "rej" || cb.data.startsWith("rej:")) {
			const key = parseAppKey(text, cb.data);
			if (key && pendingPosts[key]) {
				pendingPosts[key].status = "rejected";
				savePending();
				await notifyApplicant(pendingPosts[key], key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${stripServiceMarker(text)}\n\nСтатус: отклонено`;
			await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		await replyStart(msg.chat.id);
		return;
	}
	if (cmd === "channel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
		if (arg) await applyPublishChannel(msg.chat.id, arg);
		else await askPublishChannel(msg.chat.id);
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `Заявку подайте в личке: @${BOT_USERNAME}`
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) return;
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда.",
					"",
					`Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
					"Сменить: /channel -100…"
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyPublishChannel(msg.chat.id, msg.text);
		return;
	}
	if (msg.chat.type !== "private") return;
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: WEBHOOK_SECRET,
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member"
		],
		drop_pending_updates: false
	});
	return {
		ok: true,
		url: clean
	};
}
async function configureFromOrigin(_origin) {
	const site = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (!site.startsWith("https://") || isGatedHost(site)) return {
		configured: false,
		reason: "need_https"
	};
	const registered = await registerMiniAppUrl(site);
	if (!registered.ok) return {
		configured: false,
		reason: "grok_gate"
	};
	return {
		configured: true,
		url: registered.url
	};
}
//#endregion
export { parseDamageAmount as _, appendEvidenceChunk as a, telegramInitData as b, resolveHandleServer as c, uploadedEvidencePath as d, verifyTelegramInitData as f, lookupTelegramHandle as g, lockTelegramViewport as h, allowEvidenceUpload as i, saveUploadedEvidence as l, bootTelegramWebApp as m, allowEvidenceChunk as n, handleUpdate as o, CHANNEL_URL as p, allowEvidenceDownload as r, isDisconnectError as s, WEBHOOK_SECRET as t, telegram_bot_server_exports as u, parseTelegramInput as v, waitForTelegramUser as x, readTelegramWebUser as y };
