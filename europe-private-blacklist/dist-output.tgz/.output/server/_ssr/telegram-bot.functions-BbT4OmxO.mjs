import { a as t } from "./i18n-DRcgfq3J.mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.functions-BbT4OmxO.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus_createServerFn_handler = createServerRpc({
	id: "35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b",
	name: "getTelegramStatus",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getTelegramStatus.__executeServer(opts));
var getTelegramStatus = createServerFn({ method: "GET" }).handler(getTelegramStatus_createServerFn_handler, async () => {
	const { getBotStatus } = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	return getBotStatus();
});
var resolveTelegramHandle_createServerFn_handler = createServerRpc({
	id: "ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093",
	name: "resolveTelegramHandle",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => resolveTelegramHandle.__executeServer(opts));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({
	input: string().min(1).max(200),
	initData: string().max(4096).optional()
})).handler(resolveTelegramHandle_createServerFn_handler, async ({ data }) => {
	const { resolveHandleServer, verifyTelegramInitData } = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	if (!verifyTelegramInitData(data.initData || "")) return {
		username: "",
		id: "",
		source: "unresolved"
	};
	return resolveHandleServer(data.input);
});
var evidenceSchema = object({
	id: string().max(40),
	kind: _enum(["image", "video"]),
	name: string().max(200),
	size: number().nonnegative().max(2147483647),
	mime: string().max(80),
	dataUrl: string().max(80).optional().default(""),
	storageKey: string().max(80).optional()
});
var personSchema = object({
	username: string().max(64),
	telegramId: string().max(20),
	firstName: string().max(64).optional()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: personSchema,
	scammer: personSchema,
	scammers: array(personSchema).max(8).optional(),
	story: string().min(1).max(5e3),
	summary: string().min(10).max(800),
	damageAmount: string().max(32),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(30),
	initData: string().max(16384).optional(),
	locale: _enum(["ru", "en"]).optional()
});
var submitToTelegram_createServerFn_handler = createServerRpc({
	id: "60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359",
	name: "submitToTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => submitToTelegram.__executeServer(opts));
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(submitToTelegram_createServerFn_handler, async ({ data }) => {
	const bot = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	const locale = data.locale === "en" ? "en" : "ru";
	const authed = bot.verifyTelegramInitData(data.initData || "");
	if (!authed) return {
		ok: false,
		error: t(locale, "errOpenBot")
	};
	bot.saveUserLocaleServer(authed.id, locale);
	const app = {
		id: data.id,
		createdAt: data.createdAt,
		status: data.status,
		victim: {
			username: authed.username || "",
			telegramId: authed.id
		},
		scammer: data.scammer,
		scammers: data.scammers,
		story: data.story,
		summary: data.summary,
		damageAmount: data.damageAmount,
		damageCurrency: data.damageCurrency,
		evidence: data.evidence
	};
	return bot.sendApplicationToArbiters(app);
});
var configureTelegram_createServerFn_handler = createServerRpc({
	id: "308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e",
	name: "configureTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => configureTelegram.__executeServer(opts));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(configureTelegram_createServerFn_handler, async ({ data }) => {
	const { configureFromOrigin } = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	return configureFromOrigin(data.origin);
});
var getMyComplaints_createServerFn_handler = createServerRpc({
	id: "8c249d9a156f3f7b00e754777618a7a5ec6999aa17976c2ba190753acdde39da",
	name: "getMyComplaints",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getMyComplaints.__executeServer(opts));
var getMyComplaints = createServerFn({ method: "POST" }).validator(object({
	telegramId: string().min(1).max(20),
	initData: string().max(4096).optional()
})).handler(getMyComplaints_createServerFn_handler, async ({ data }) => {
	const { listComplaintsForUser, verifyTelegramInitData } = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	const authed = verifyTelegramInitData(data.initData || "");
	if (!authed) return [];
	return listComplaintsForUser(authed.id);
});
var saveUserLocale_createServerFn_handler = createServerRpc({
	id: "11d2abc3e6b37013d6db0d65775d802606c07fa20c30974f0bdb6267adcd933f",
	name: "saveUserLocale",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => saveUserLocale.__executeServer(opts));
var saveUserLocale = createServerFn({ method: "POST" }).validator(object({
	initData: string().max(16384),
	locale: _enum(["ru", "en"])
})).handler(saveUserLocale_createServerFn_handler, async ({ data }) => {
	const { verifyTelegramInitData, saveUserLocaleServer } = await import("./telegram-bot.server-DUCskWAZ.mjs").then((n) => n.l);
	const authed = verifyTelegramInitData(data.initData);
	if (!authed) return { ok: false };
	saveUserLocaleServer(authed.id, data.locale);
	return { ok: true };
});
//#endregion
export { configureTelegram_createServerFn_handler, getMyComplaints_createServerFn_handler, getTelegramStatus_createServerFn_handler, resolveTelegramHandle_createServerFn_handler, saveUserLocale_createServerFn_handler, submitToTelegram_createServerFn_handler };
