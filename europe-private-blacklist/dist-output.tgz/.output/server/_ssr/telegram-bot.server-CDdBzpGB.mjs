import { o as __toESM } from "../_runtime.mjs";
import { o as tb, r as isLocale } from "./i18n-BSUu3cSU.mjs";
import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-CDdBzpGB.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function scammerAccounts(app) {
	if (app.scammers?.length) return app.scammers.filter((s) => s.username || s.telegramId);
	return app.scammer?.username || app.scammer?.telegramId ? [app.scammer] : [];
}
var CHANNEL_URL = "https://t.me/+KkrYz9IKvoBmYTQy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const tgUser = trimmed.match(/tg:\/\/user\?id=(\d{5,15})/i);
	if (tgUser?.[1]) return {
		username: "",
		id: tgUser[1]
	};
	const openMsg = trimmed.match(/(?:user_id|peer)=(\d{5,15})/i);
	if (openMsg?.[1] && !/t\.me\//i.test(trimmed)) return {
		username: "",
		id: openMsg[1]
	};
	const webTg = trimmed.match(/web\.telegram\.org\/[a-z]+\/#(\d{5,15})/i);
	if (webTg?.[1]) return {
		username: "",
		id: webTg[1]
	};
	if (/^\d{5,15}$/.test(trimmed)) return {
		username: "",
		id: trimmed
	};
	const fromUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(fromUrl)) return {
		username: "",
		id: fromUrl
	};
	const urlName = trimmed.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{2,31})/i);
	const atName = trimmed.match(/@([A-Za-z][A-Za-z0-9_]{2,31})/);
	const bare = trimmed.match(/^@?([A-Za-z][A-Za-z0-9_]{2,31})$/);
	const username = (urlName?.[1] || atName?.[1] || bare?.[1] || "").replace(/^@/, "");
	let id = trimmed.match(/\bid[:\s]*(\d{5,15})\b/i)?.[1] ?? "";
	if (!id && username) {
		const extra = trimmed.replace(username, " ").match(/(?:^|[\s,;|/])(\d{5,15})(?:$|[\s,;|/])/);
		if (extra?.[1]) id = extra[1];
	} else if (!id && !username) {
		const any = trimmed.match(/\b(\d{5,15})\b/);
		if (any?.[1]) id = any[1];
	}
	return {
		username,
		id
	};
}
function parseDamageAmount(text) {
	const raw = String(text || "").trim();
	if (!raw) return null;
	const upper = raw.toUpperCase().replace(/Ё/g, "Е");
	let currency = null;
	if (/\bEUR\b|€|ЕВРО/.test(upper)) currency = "EUR";
	else if (/\bUSD\b|\$|БАКС|ДОЛЛАР/.test(upper)) currency = "USD";
	const numeric = raw.replace(/[\u00A0\u202F\u2009]/g, " ").replace(/[€$₽]/g, " ").replace(/\b(usd|eur|usdt|rub|евро|бакс\w*|доллар\w*|руб\w*)\b/gi, " ").replace(/[^\d.,\s]/g, " ").trim();
	if (!numeric) return null;
	const s = numeric.replace(/\s+/g, "");
	let normalized = "";
	if (/^\d{1,3}(,\d{3})+$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+$/.test(s)) normalized = s.replace(/\./g, "");
	else if (/^\d{1,3}(,\d{3})+\.\d{1,2}$/.test(s)) normalized = s.replace(/,/g, "");
	else if (/^\d{1,3}(\.\d{3})+,\d{1,2}$/.test(s)) normalized = s.replace(/\./g, "").replace(",", ".");
	else if (/^\d+,\d{1,2}$/.test(s)) normalized = s.replace(",", ".");
	else if (/^\d+\.\d{1,2}$/.test(s)) normalized = s;
	else if (/^\d+$/.test(s)) normalized = s;
	else return null;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n <= 0) return null;
	return {
		amount: normalized.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, ""),
		currency
	};
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id) return {
		username: parsed.username,
		id: parsed.id
	};
	const known = KNOWN_TELEGRAM_IDS[parsed.username.toLowerCase()];
	if (known) return {
		username: parsed.username,
		id: known
	};
	return {
		username: parsed.username,
		id: ""
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const sdk = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (sdk?.id) return {
		telegramId: String(sdk.id),
		username: sdk.username ?? "",
		firstName: sdk.first_name ?? ""
	};
	const cached = window.__EPB_TG_USER;
	if (cached?.id) return {
		telegramId: String(cached.id),
		username: cached.username ?? "",
		firstName: cached.first_name ?? ""
	};
	const hash = window.location.hash || (() => {
		try {
			return sessionStorage.getItem("__tg_hash") || "";
		} catch {
			return "";
		}
	})();
	if (!hash.includes("tgWebAppData")) return null;
	try {
		const data = new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData");
		if (!data) return null;
		const raw = new URLSearchParams(data).get("user");
		if (!raw) return null;
		const user = JSON.parse(raw);
		if (!user?.id) return null;
		return {
			telegramId: String(user.id),
			username: user.username ?? "",
			firstName: user.first_name ?? ""
		};
	} catch {
		return null;
	}
}
async function lookupTelegramHandle(input) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 25e3);
	try {
		const res = await fetch("/api/telegram/resolve", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				input,
				initData: telegramInitData()
			}),
			signal: ctrl.signal
		});
		if (res.ok) {
			const json = await res.json();
			if (json?.username || json?.id) return json;
		}
	} catch {
		if (ctrl.signal.aborted) return {
			...await resolveTelegramId(input) || {
				username: "",
				id: ""
			},
			busy: true
		};
	} finally {
		clearTimeout(timer);
	}
	return resolveTelegramId(input);
}
function telegramInitData() {
	if (typeof window === "undefined") return "";
	try {
		const live = window.Telegram?.WebApp?.initData;
		if (live) return live;
	} catch {}
	try {
		const hash = window.location.hash || sessionStorage.getItem("__tg_hash") || "";
		return new URLSearchParams(hash.replace(/^#/, "")).get("tgWebAppData") || "";
	} catch {
		return "";
	}
}
function telegramPlatform() {
	try {
		return String(window.Telegram?.WebApp?.platform || "").toLowerCase();
	} catch {
		return "";
	}
}
function isTelegramDesktop() {
	const p = telegramPlatform();
	if (/(tdesktop|macos|weba|webk|unigram|web)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Windows|Macintosh|Linux/i.test(ua) && !/Android|iPhone|iPad|Mobile/i.test(ua);
}
function isTelegramMobile() {
	const p = telegramPlatform();
	if (/(android|ios|android_x)/.test(p)) return true;
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
	return /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
}
function tgSafe(run) {
	try {
		run();
	} catch {}
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tgSafe(() => tg.ready?.());
	tgSafe(() => tg.expand?.());
	tgSafe(() => tg.setHeaderColor?.("#080808"));
	tgSafe(() => tg.setBackgroundColor?.("#080808"));
	tgSafe(() => tg.setBottomBarColor?.("#080808"));
	tgSafe(() => tg.MainButton?.hide?.());
	tgSafe(() => tg.SecondaryButton?.hide?.());
	if (Boolean(tg.isVersionAtLeast?.("8.0")) && isTelegramMobile()) {
		tgSafe(() => tg.requestFullscreen?.());
		tgSafe(() => tg.disableVerticalSwipes?.());
	}
}
function telegramSafeTop() {
	const tg = window.Telegram?.WebApp;
	const safe = Number(tg?.safeAreaInset?.top || 0);
	const content = Number(tg?.contentSafeAreaInset?.top || 0);
	if (!Boolean(tg?.initData || /Telegram/i.test(window.navigator?.userAgent || ""))) return 0;
	if (isTelegramDesktop()) return Math.min(Math.max(safe + content, 0), 28);
	return Math.max(safe + content, 56);
}
function lockTelegramViewport() {
	const apply = () => {
		const root = document.documentElement;
		root.style.setProperty("--app-h", "100dvh");
		root.style.setProperty("--app-top", "0px");
		root.style.setProperty("--tg-safe-top", `${telegramSafeTop()}px`);
	};
	apply();
	const tg = window.Telegram?.WebApp;
	tgSafe(() => tg?.onEvent?.("safeAreaChanged", apply));
	tgSafe(() => tg?.onEvent?.("contentSafeAreaChanged", apply));
	return () => {
		tgSafe(() => tg?.offEvent?.("safeAreaChanged", apply));
		tgSafe(() => tg?.offEvent?.("contentSafeAreaChanged", apply));
	};
}
function waitForTelegramUser(ms = 2500) {
	return new Promise((resolve) => {
		const start = Date.now();
		const tick = () => {
			bootTelegramWebApp();
			const user = readTelegramWebUser();
			if (user) {
				resolve(user);
				return;
			}
			if (Date.now() - start >= ms) {
				resolve(null);
				return;
			}
			window.setTimeout(tick, 80);
		};
		tick();
	});
}
function openExternal(url) {
	if (!url) return;
	try {
		const tg = window.Telegram?.WebApp;
		if ((/^tg:\/\//i.test(url) || /(?:t\.me|telegram\.me)\//i.test(url)) && tg?.openTelegramLink) {
			tg.openTelegramLink(url);
			return;
		}
		if (tg?.openLink) {
			tg.openLink(url);
			return;
		}
	} catch {}
	try {
		window.open(url, "_blank", "noopener,noreferrer");
	} catch {}
}
function haptic(style) {
	try {
		const hf = window.Telegram?.WebApp?.HapticFeedback;
		if (hf?.impactOccurred && window.Telegram?.WebApp?.isVersionAtLeast?.("6.1")) {
			hf.impactOccurred(style);
			return;
		}
	} catch {}
	try {
		const ms = {
			light: 10,
			soft: 14,
			medium: 20,
			rigid: 24,
			heavy: 32
		}[style];
		navigator.vibrate?.(ms);
	} catch {}
}
var WELCOME_JPEG_BASE64 = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCALQBQADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD8uqKKKACiiigAooooAKKKKACiiigAooooAKKKKAClUd6SnCkwCiiipAKKKKACiiigsKfTR1p1ABRRRQAU4dKbTh0pMBaKKKaAVelLSL0palgFPpo606gfQKB1opR1qB7DqB1ooHWgEOpw6U2njpUAFKtJSrQWh1KtJSr0oAcvWnU1etOqQQU+mU+pZXUB1p1NHWnUgQ+iiioGKo706kXpS0AKvWlpF6UtABTlptPpMoKUdaSlX1pDWw6iiikwQ6iiipBBRRRQUOHSlpB0paS3AKKKKYDgKWkpakAooopAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSEZpaKAGUUUVYBQelFB6UmAyiiimAUUUUCY09aKD1oqkJjW60lObpTaYdBD0ptPpp600ISkaloPSmSxtNYd6dSHpQA2iiigBp601utOPWmt1qxMSmGn0w9aaBhSNS0jVQmNPSm049KbVCGt60lObpTaACmU+mUECN1pKVutJVoGNPWkpW60lAdApp606mtVi6CUHpRQelCENoooqmAh6U2nHpTaSAKKKKYBTT1p1NbrQAlFFFABRRRQQFFFFACMKSnU2qQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnU0dadSYBRRRUgFFFFA0FFFFBQo606mjrTqACiiigApw6U0c0+kwCiigDJpgOHSiiipAcvSlpB0paBsKUdaSlWoGx1A60Uq+tDBC0+mjrTqgApVpKcvSgsWlHSkpw6UAOX1paQdKWpGgHNPpo606pY0A606kWnL1pAh1FFFQMcvSlpB0paAFXpS0DgUUAhR1p1NHWnUmUFOHSm0+kNhQOtFA61LGh1FFFIEFFFFAxw6UtIOlLSW4BRRRTAfRRRUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAMPWig9aKtAFB6UUGkwGUUUUwCiiigTGnrRSt1pKaDoJTafTD1qgQU09adTT1pokSg9KKKZLG0h6UtJQA2iiigBp601qe1MbpVITEpp606mtVIGJSN0paD0qhMYelNp1NqkIRulNpx6U2gAplPprUEDW60lK1JVIBrdaSlakpggpD0paD0qkJDKKKKYhtFKwpKoAplPppGDSQCUUUUwCmt1p1NbrQAlFFFABRRRQSwooooEFNPWnUjdaaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAFWloFFSAUUUUgCiiigpBRRRQMUdadTR1p1ABRRRQAq9adTVp1LqAUq0lKvSmwFoooqQHDpS0DiikMKcBgU2n1IMKcOlNpw6UmMctLSLS1Iwp9MHWn0FAOtOpo606hgPoooqRoctLSL0palj6Dh0py9KaOlOXpUsBaBzRSjrUjHUUUq9aAFooooGhR1p1ItLSYwp9MHNPpDYUo6UlOHSpYdAooopFBSjrSU5aGAtFFFJAFFFFMB9FFFQAUUUUAFFFFABRRRQAUUVPp2n32r6laaRplq9ze306W1vCgy0krsFVR7kkAUAQUV2Xxl+GOrfBn4p+Jfhdrdwtxd+Hb5rUzqu0TRkB45AO26NkbH+1XG0AFFFFABRRRQAUUUUAFFFFADD1ooPWirQBRRRSYDT1pKc3Sm0IAooopgB6U2nHpTaaJ6BTD1p9NPWqBCU09adSHpQhDaKKKoTGnrRStSUCGkYNJSt1pKAEPSm049KbVIBtIelLSHpTRK2G0UUVYMaetNbrTj1prdaaEJTD1p9NPWmAlI3SlpG6UEsaeabTqbVIQh5ptPph60xIKD0ooqkC3GUUUUxCHpSU49KbTQBTWp1I3SjqA2iiimAU1utOprdaAEooooAKKKKBMKKKKCQoPSiigBtFFFWAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUDrQA6iiioAKKKKACiiigpBRRRQMUdadSDpS0AFFFFADl6UtIvSlpdQClXpSU6hgFKOtJTlpAhaKKKTH1Cn0wDJp9SDCnU0dadSYxwHFLRRUjQo606mqO9OoKFXrTh1pB0py+tJgLRRQOtIfQcOlLRSr1qBsWnjpTR1p1JjClXrSU5akBaVaSlXpQAtFFFA0OXpS0g6UtSykKo706kHSloBhTh0ptOHFQxhRRRQMKctNpw6UmAtFFFNAFFFKvWgB1FIGBJUEZHUelLUAFFFFABRRRQAUhIHUgUtdp8J/F/gbwd4mS8+IvwzsfG2hXBSO6s57u4tp4UBOZIJIZEw/PRwytgDA+8E3ZN2uBxQKn+IfnX07/wTm+Fg+Jv7Ufh+8urYT6b4Pjk8RXW5cr5kOBbjPQHz3hYeoVq+yfg3+zr+wV8c/DEfiz4f/DvTtRtCVS4hOq6jHc2ch/5ZzxfacxtwcdVbGVLDmvpn4Ifs7fBn4H3OpXnws8EQaDNrEcUd66XdxOZVjLFBmaR9oBYn5cZ4znAxhhsXTxU/ZxTT6pq36l1aUqUeZ2a8j8+/wDgrf8ACU6D8RfCvxfsbYrbeI7FtJ1BwPlF3bYMbMf7zwyKo9oDXwLlf7w/Ov6GfjT8Ifhv8aPDsPhf4neF4Nd0y2u0voYJZZYtk6qyq4aJlYHa7jg4IY5r5v8AF/7GX7GXg3Q73xJ4i+Gmj6TpWnRmW6vLvWtQjiiXpksbjqTgADknAAJ4pYvF0sFLlmm/RXChSnWjdW+Z+Ou5c4yKWvZ/2hvHf7P+vag/h/4AfCS10LSLeT59cubm9e8vSDx5cUszJDEcHhlLkEZKcrXjFb05+0ipWav0e/6kyXK7XuFFFFUIKKKKACiikJCjJOKAGnrRSnnmkq0AUUUUAIelNp56UykgCiiimAHpTadTTxQJdgprDvTqKsQykPSloPIoBjKKKKoliNSU49KbQIa1JTj0ptABTKfTT1qkAw9aKVqSmJDKKU9aSqF0Gt1prU9ulNPIqkIbTW606kYd6YDaQjIpaKCWMpp6089aa3WmhCUw9afTSOaoXUSiiimgY09aSnNTaoTA9KbTqaeDTQBSHpS0h6UMBtFFFMApG9aWg9KAGUUUUAFFFFAmFFFFBIUUUUANPWilPWkq0AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUqjvSU4dKTAKKKKkAooooAKKKKCkFFFLQMcOlFFFABRRQOtADqWiikgAdadTR1p1DAKcvSm05elIaFoooqWCFWnUg6UtIEKtOHWmr0pw61LGOooopFIcOlLSCloGOHSnL0ptOHSpYC0o60lKtJjHUq0lOHSpH1FHWnUi0tSxhTh0ptPpAFOHFNp1ABSjmkpR1oKQ6iiipGhw6UtFFIEKvWlpF60tSPqFFFFAwp46U0dadSYBRRUtpaXeoXcNhYWs1zdXMixQwQxl5JXY4VVUckkkAAUwIqU5Ckjr2rsP8AhS/xkyV/4VH40yOCP7Buv/iK7T4P/sy/FXx58U/CfhHXPhn4q07StU1a3h1C7u9IuIIYbXeDMzOyALiMNjJ64FS5K1wPVP2lf2arj4cfsk/A74jxWHl3r200OvN5eJA9+zXlrvx02RmSPnuFFfJNfvh+1R8HU+MH7OHjD4eadZg3c2mG50qJBjF3bETW6DHQFoxH9HNfiD/wpP40oMP8IPGwI9dAuh/7JRyuK94mLTONorqNT+FPxT0Swn1XWvhp4r0+xtU8ye5utGuIool6bmdkAUcjk1y9K9ygooooAKcBimjrTqAOw+FHxR+Ivwg8aWXi74Y65c6fq6uIfKiG+O8RiMwSxH5ZUb+6QecEYIBH7++Dr3UZdJsX1pYE1E20RvFgBESz7B5gTJJ2h9wGSTjHNfiH+xX8O1+JH7RvheyurfztP0OU69ejtstsNGD6gzeSpHo5r7d/aO/4KP8Ahf4VLdeCvg5HZeKvFUZMU+oO2/TdPfvgr/x8yD0UhAerMQUrzauIf16FKmrtK79Htf7jojTXsHOT8kfd2sXiBCSeB1xX4mftwfF/4veOfjV4l8CfELVxFpXhTVp7bTNIsw0dmkQY+VOVJJeV4irF2JPzkDC/KPcv2cv+CmniCCWLwh+0fMdRtpnIh8UW9uqzwFmyFuYYlCugzgPGoZQBlX7ebf8ABRfw1pUvxN8P/F3w1e2l/o3jnSUZLyzkEsM89sFjMiyKSrAwtb4x6N6HESryjmKhVj8SfK/Na6fK5Spp4fmg9t0fJuKaeKdTT1r1TlCiiigAooroND+HXxC8T2A1Xw14C8R6vZFzGLmx0ueeIuOq70UjIyMjNDaW4HP19H/sK/A+x+NXxO12DX7bzNF0jw7fLOxGVE93E1rDn3HnPKPeH2ryEfBf4yMcD4SeNDn/AKgV1/8AEV+nH/BNz4I6t8PfglqPiPxPod1pmt+LNSkmlt7y3aG4itbfMUKOjgMMuZ3GRyHU1w5hUlHDSVJ+89F/XobYeKlUXNsflFrmjah4d1vUfDurReVfaVdzWVygOdksTlHX8GBH4VQr64/bx/Z+8aad+0JqviLwV4I1zVtM8T28WqO+m6dJPHDckGOZCY1OCXjMnP8Az1r51b4P/FwZz8K/GA/7glz/APEVthsVCvRjUbSuvx6/iKrSdObh2ORoq7rGia34dv30rxBo99pd7GFZ7a9t3glUEZBKOAcEEEVSrqTTV0ZBTKfTW60IBKKKKYBSNS0jUC6iUUUVSExlFBopgxp60lK3WkqkJhTadTT1oJCmU+mHg0AFNbrTqRqaAY3Skpx6U2qF1Gt1pKVqSqQhD0ptPNMpoQ2kPSlPFFUAyiiigTGt1prdKc1IelNEjaRulLSVQmNooopoGIelNpx6U2qBhTT1p1I1NCEooooYDKKU9aSmAUUUUAMopT1pKACiiigTCiiigkKKKKAAjim049KbVIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAU4dKbTqTAKKKKkAooooAKKKKCgpR1pKUdaBjqKKKAClWkpw6UMBaKKKSAVaWkXpS0mAU8dKaOtOoGgoooqWND6KKKQkOHSnLTacOlQMWiilHWgpDqB1opVoGOHNOpo606pAKcOlNpw4pMrqLThTRzTqkEOHSlooqRijrTqavWnUgAdadSL60tABSqO9JTh0pMoWlA5pKVaRXQdRRRSYkKtLQBgUVI+oUUUUDFWnUgHFLU7sAoBIIIJBHII7UUVQH2p+yr/wAFBNb8EXFp4H+OeoX2r6ANsNrroLS3lgOgEwHzXEQ45/1i843jCD9SfBPiLSvE2l2et6DrVvqemX8Sz2t3a3AmhnjPRlYEhh/nrX88XYnGe1fs7+wN4Of4ffs5+EdOuFcXerxPrc4bOd102+MYPIIh8kEeua+exuHw2ArQr01yuTtZbPz8j0KFSrXg6ctUl9x9dSMBbde1eK/Hr40fD34H+FpvGPxE8Q/YrbJS2t428y6vZf8AnlBFkF26ZPCqOWKjmuq0H4yfDfxjr+s+DPCnjjRtW1zw6Qup2FpdLJLbE9cgfeAPysVyFb5WweK/P7/grR4Me7h8C/EyAZW2ludCujz/ABjz4PYfduP09K7cwqUcZUp4eb0f+RzYaM6MZVI9D5c/aU/a0+IX7ReryWl3NNo3g+3l3WOgwzFkOD8stw3HnS+5AVeiheS3h1LRXZRoU8PBU6SskZTnKpLmk7sKKKK1JAdadQBiigDd8P8AjjxX4V0fXND8OaxLp1v4jhjttSe3+SWe3Ri3k+YPmEbEgsoOG2qGyBisEAKMClopKKTbS3C4EZ61qP4o8Qy+GE8GTavcS6JDe/2hDZSNujhuNhQumfubgfmAwGwpOdq4y6KGk90NNrYKaetOopiG0UEYooAK7/4N/HX4kfAnxD/b3gLW3ihmYfbdNmZms75R2ljBGT6OMMvOGGTngKKipShWg6dRXT3TKjKUHzRdmfsl+zL+1Z4C/aC01ItJvjpXiW3i8y/0G5uMzRYxukhY486LJ+8ACMjcq5GfpnTpFNuxZiSR3r8a/wDgnr4En8V/tEWPiMo4s/CFnPqcrj7pmZfJhQn1LS7h7RtX6oeL/i/8PPhVpFpf/ELxlpegW9/cLaWz3s4TzZCQMAddoyCz/dQcsQOa+PcKOVY54ehdpq9t2r308z2OaeKw/tammtr9yx4rZjLIschAPXBxXwN+01+23Z+Fp73wJ8G7+PUNZXMV3rqsJLayboVt+olkH985RT03nJX7O+I0Nl4w8M6poMkyPaa5YTWZkjfKmOeJk3qw6jD5BBr8QNQ0670jULvSdQhMV1ZTyW88Z/hkViGH4EEV5OQZZg83xtWtiPe5GrR6a31ffbbbud+YYqvgqEIU9Obr/X5iX9/qGrX0+qatf3F7e3UhlnubiVpJZXPJZmYksT6k5qCiiv0tJJWR8tuFI3rS0hGRS6gNoooqgCkaloPIoExtFFFUhMaw70lObpTaYdBGHem0+mU0IKRutLSN0pkiU1utOprUAJQelFFADKbTqaetWJiHpTafTKaAKaetOprVRI1utJSt0pKoBh60UrdaSgTEPSm0+mUEjaKD1oqwYw9aKD1ooQdAplPpp61YnsJSN0paD0oQhtFFFUwGtSU49KbSQBRRRTAaetJTm9abQAUUUUAFFFFBAUUUUAB6U2nU09apAFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAAdadSL1palgFFFFIAooooBBRRRQWFOHSm08dKACiiigAp9Mp9JgFFFFMBw6UUUVICr1p1ItLQPoFKOtJTlqB9BaB1opV60mAtPpo606pAKVfWkpw6UFi0q9KSnAYoAVadSAcUtSNBT6aOtOqWNAOtPpq05etIEOoooqBjl6UtIOlLQA4dKKKKAQU8U0dadSZQU5abT6Q+gUDrRQOtSwQ6iiikNBRRSgZNAx1FFFSgCiiiqA3/AHh6y8V+NtE8O6rqNvp+n3t7Gt9eXEwijtrRTunlZzwAkYdv8AgNfU37SP7eOreKLOb4a/Aee50HwrGn2WfVkVoby9iA2iOEcNBDtGP77DGSoyh+PAOOaWuGvgqWIrwr1NeS9l0u935vRW7G0K86cHCOl9zS8K+J/EfgbX7HxV4O1u80fWNNkE1reWkpjkjYe46gjIIPBBIIIJFfYmv/tZ6N+1H+z54j+FfxPitdH8eWlqmpaVdxgJaarPanzNqA8QzvGJU2fdYv8AIVJCV8U0hAIwRVYnCU8Vyyl8UWmn1Vv07omnVlSuls9wU5Az1paKK6TMKVR3pKcOlABRU1lZ3upXSWWm2VxeXMnCQ28TSSMcZwFUEk49K7fwd8F/GXjXVP7G0m0lu75SN9jpVtLqd4o6cx2yuIyDxiZo+h54pOSjuFrnBUV9g+E/+Cbfxr1yAXF94NutOgI3faNd1y00wAf7UMC3jj3yVP0roJf2CdA0A+V4v+M3wQ0R14aO6128mkH1PnW//oIrJ4iCK5WfD1FfbTfsVfC26xFo/wC0f8CbuYniP+07sZPoD/aD/wAqo6p/wTn+IU9q9/4Wbwh4miAyn/CP+LCm7323Fsy/h5w+tZyxlKPxO3rZfqUqUpbanxnRXsPj39l74nfD2OS48ReFvEGk28Q3SXF/pZktEHp9ps2ni645coO9eWahoeraZEtzdWm62Zti3UEizQM390SxkoWGDlQcjvW1OtTqq8HdEyjKLtJFAikpwII4ptaEhSdKWigD6y/Z2+Ofgr9lr4I6j4ma1i1zx743vS1lpaPtFvZW+6OKS6YconmtOQg+ZxtxtU7x86fEn4m+N/i74puPGPj/AF2bUtQn+VAxxFbRA/LFDGPljQdgB6k5JJPLhQOgxS1x0MDRoVp4hK857vy6Jdkl95tOvOcI02/dXQ95/Z//AGt/GnwcEXhjXWufEHg4t/x4vIDPYgnlrV26epjY7Cf7pJeuM/aIn8K6l8WtZ8T+CdRtrzRfEvl61bNDwUacZlSRDyjiYSgqeeB1BBPnNIRxxU08uoUcW8ZTVpSVpW2eqd2u6tv56lyxVSdFUJO6TuvL/gDaKKK9E5goooqWA09aSlI5pKpAFFFFAmNPWilakpoT2EPSm0+mHiqBBTKfTT1poQlB6UUUxMbSHpS0UCGUUUUANPWmt1p7UxulWhMSmnrTqa1NAxKRqWgjIqhMYelNp1NqkIRqbTj0ptABTTxTqaetBA1utJStSVSAa3Wkpx6U2mCCkalpD0qxdBtFFFAhtFB60VQBTDT6YetJAFFFFMAPSmU+mUAFFFFABRRRQSwooooEFNPWnUjU0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACqO9LRRUgFFFFIAooooBBRRRQWFPFNHWnUAFFFFAAOtPpo606kwCgdaKVabAWiiipAcvSlpB0paTGFOHSm06pBi0o6UlOpMYo606kWlqRoKcKbT6CgHWnU0dadQwHjpRRRUjQ5aWkHSlqWPoOHSnLTR0pw6VLBC0UUo61Ix1A60Uo60ALRRRQNCr1p1ItLUsoB1p9NHWnUAwpVpKcOlSx9AooopDQUq+tdx8DvhtdfF/4weEfhraqSNe1SG3uCDjZbA7p3/wCAxLI3/Aa6n9rr4axfCX9pHx34NsrQW2nLqj6hpsSptRLS5AniRB02osoT/gBqW1flA8gooopoAoopVHemAtLRRUAFFFFABRRVvSdI1HXL1dP0yASSlWkZmYJHFGoy0juxCoijJLMQAOpobtqwKqI8sixRIzyOQqooyzE8AAV7R8HP2X/iD8WNbGkaRoF1f3MRT7VbQyCGGxBOD9tumUpbsByIQJJztYeWvDV698Ff2avBvhLwTF8a/jl4jn8JeDoirx3jq0Op66CpIisoyPNtoHGQHCi4lQMwEEbE1xvxs/bZ8ReKtDX4YfBDRk+Gnw5tIzBBp+mgQ3l2mfmaaWM/KG6siHnLb3lzmuN151pOGHW276L/AIPkvm0a8iirzPW9S0H9kD9mC0fSviv4lPxJ8UxY83wh4Vzb6VBIMHbcvv3zlT/z8Su2CcQgcV5/4w/4KO/F2609fCXwU8LeG/hd4ehCrb2Wh6dHLOi5AALMnljOQMpEh5618uado6zqJ724+zwbXP3Tu2qD8wx1UYYnGDiKQDDAAxyalO0Xk2yLbxBgy7TlxgnA3A4P8HIAyY0PBGa2hh4r43zP8PuIcm9tDqvGHxF+J/j5Z774hfETxBrwYFjBeanJON3IGEdigAOzIX+GQMARXGxtbx7vNR5dw4G8pg9PfPc8d8e4r3X4FfsYfGf47xwa9p2kJoHhq4O4a3qqNHHMvrbxgb5+OhUbM5BZa+mvBfwF/Y2+EeoDw/cw6z8bPH0AzJpOk2D6nscHawNtAfs8S56i5mbHPTHGFbH0MO3Tj70l0j+vRfNlwoTn7z0XdnwDpWi6r4mum0/w14T1LUboo2IbLzp5FJZypCqCSACg5HOz3JrX0zwf8U7DXtRj8OeE/FWn6tohUXlva29wl3Zlz+7VxsEiH0BwSMnjBNfqBqXxf8e+HIF8NeG/B3wv+FFvGdkNhrWsfbdR2diulaQpKn/ZaT618ZfEPxN4ktPGnxX8W+Lo9G8YWFzqVkmqRX2kXekSzGGNIIpLaNiJLaREuflMgJwof72DWFDMateTXIkraa3vqvl+Jc6MYJe9r6f0/wADD+F37Xf7S3hLxDbeHbD4nyTwNK0Jh8XyLNBHgniWeUmRAMc4kTBOPevUI/j7+zT8VdWuNJ+NXw4TwB4mlPly+K/B1ykttOx25aYRBllRsDIkW4GOCRzjwu68f6L438aReJ0udT0GHTdNFrbxza5dtOkjyO7LHcx20r+UgkZERwMIF5OCKs6hq/h3U7eS01TxpqV3bTDbJDP4j1F0cZzhgdPwRxU1cHTnLnVNwk1vHR/ho/ndDhWlFcrd156/8FHf/Fj9jzWdM0b/AIT3wFqen+LvCs0Znj17w9CZFEYxlrmzhLlQCSWktt6qF5iTk180avoupaHcrbajCoEi74ZonEkM6f3o5FJVxnIyCcEEHkED2HwD8VPFPwN1uTxH8H/iDY2FrsEl1oc73t3b37qOjIbaJdxAADZVh2dc17pDpvwW/bI0+5n8DadZeCviT815qvhW6cR2OsSFctNC4H7uXjPnxgMORMkiEvSWJr4Ff7T70P5rWt/iXT1Wn+Er2cK/8LSXb/J/pv6nw7SV1nxB+HmueAdbv9M1HTb22Gn3H2W6gvIwlxZSkErHMo4+ZQWSRcxyp8yE4ZV5PjPvXrRkprmjscrVtGGaWikpiFooooAYRiinEU2qQBRRRQwEam5q/oujaj4k1rTvDujwedf6rdw2VrHnG+aVwiL+LMB+NeuftefBa0+BnxdPhbSIdmkXelWV3ZMAcNiIRTHPcmaKVj7MKxeIpwqxoN+9JNr5Wv8An+ZahJxc1sv1PFKKKK3IYHpTacelNoQlsFNPWnU1qsSEpGpaQ9KEA2iiiqJY09aKVvWkoEMPWilakoAQ9KbTz0plUgG0h6UtIelNCWw2iiirExlNPWnnrTW600ISmU+mnrTASkb1paQ9KCWNPSm06mnrVIQhptPplMSCkPSloNUgGUUUUxCN1pKVqSqQBTT1p1NbrS6gJRRRTAKZT6aetACUUUUAFFFFBLCiiigQUhHFLRTAbRQeKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1opR1oYC0UUVABRRRQAUUUUDQUUUUFCjrTqaOtOoAKKKKAFXrTqRelLS6gFKtJSr0psBaKKUdakB1FFFJj6hT6aOtOqQ6hTqaOTTqTGOHSloFFSNCr1p1NWnUFCqO9OHWkHSnLSYC0UUDrSH0HUo60Uq9agbFp4po606kxhSrSU5elSAtKtJTh0oAKKKKBoeOlFFFSUhVp1IOlLQDCnU0cmnVA2T21jfXu/7FZT3Hl43+VGW25zjOOmcH8jUp0XWh10a+H/bBv8K3fhv8UPHnwj8Sw+K/h94ju9Jv4yBIIpCIrmMf8s5k+7IhyflYEdxggEfqx+yZ+2b4O+PsEPh3Ubr/AIR/xtEn77SJbpjHeYGTJaMxy46kxn51wfvqN9efjsZVwdpRpc0OrT1XqrbeZ0UKMK2jnZ+n6nz/AP8ABJf4PXmo/EjxR8WtZ06aGHw/YrpNh50WN1zc8yMuecrDGy/ScVrf8FdPhNfx+L/A/wAVtH0ye4Go2M2hX7QxltrwMZYCQO7JNIM+kQ9K/SrQZPMYF2LHpknNaWpSbBlGZTjqDiuqhUjVovEGFSLhU9mfzef2Fr3/AEAtQ/8AAdv8KiudN1KyQSXunXVujHaGliKgn0BPev2v/an/AGxPh7+zZpTWup3r6z4vuofM0/w7bXJWVgc7ZbhhnyIsjgkbmwdoIBYfkT8afjz8Tvj/AOKG8VfEnxDLeOhZbOxjLJZ2EZ/5ZwRZIUdMkks2AWZjzU0asquvLZd7/pYqUeXrc8+pw6U2nCt2SLRRRUgFFFOjilnlSCCJ5ZZWCIiKSzMTgAAck0AWdJ0m91zUItM09EMsm5i0jhI4kUFnkdjwqKoLMx4ABJ6V9o/Cj4YfDH4CfDKH46fG+2M2kSFJfD2gTR7brxLdL80VxNE4yIAcNFCw2hcSygkxoed/Zv8Agz4K8PeE9W+M3xjRYvBfhaRZL8SKGXXNQjYFLGMZxLbxShAwB2TXAVSWjhLV4R8fPjr4u+P/AI+ufG3imUw2ybodK0xXJh0+1zlUX1Y/edyMsxJ4GFXzJzljqro0naMfifn2Xn37LzenSoqjHnlu9l+v9bjvjj8dviD+0X45PiXxpqIjiUumm6bG7fZNNg6kIp78ZeQ8tjJOAoHLjSYtGgM9xMr3W11eFjuVhn5gV77SQGUEOqukqFgCRUtUGkRTXd1K0dxhfswRsOkoPOQcMkiMOCCCDjIZJMlmi6Brfi7XLXw9oOmzalq2r3KQW1nbplppWOFVVAAAGcDgAD0r0YwjSioR0ijnbc3d7jtJ0vxJ431bTvDWg6fdatqV7KIbKztoi8s0rYH3QOWO0ZOB0JPJJP3N8Lv2XvhZ+zwmk618ctOf4gfE3Vv3mh+BtJQXaxnn55EzskVeS80pFumGx5pUNVz4f+GvC37H+jXPhvQTpesfGG+tIm8S+IriI3Nh4Tt5/wDVW0aqC01xKeIrZP3lww3NthUA2NK0LS7M6vqHxMuLlBfX0Y1+z1G7eS71G5YAwx65cQbpJpmG0xaFZbgo2CXPL14WNzCVX3abah5by9Oy/F6apNM7KVFR+Lf8F/wfy8zt/wC0/id+0FNJYalKdb0bPkTeHfDeqPYeFrIjKmHUdaQedqbqCA1vZL5YK43LXsPhn4D6Lo2kwaD4x8VRQ6fJ80fhfwzD/YGkHPX9xbN9puvdppX3dSBmvPpvjE2ixHQbprjQF063QjRrCK1XV4LcD5Dc/MLHQLfGMLLIZsd1biuesv2sPAOmyNbWnjLRLHzGYSwaLfJ+8YHk3WtX2HnbrkWsLkc4c14sJV6nuxjaK2t/n+q9G7nU/ZrVu78/6/rsfV+heB/CPg/Sms/B3hrTtEg25MdhaJbbvdtgBY+7ZNfk3+1l4pabx78UtMifm88dTQS5PJjhhRSP++1T8q+3dF/bt/Z10hXg8R/E/TYmPHkaXpWq3+D6vdSQAyH3CAfWvzI+NHiqy8a/Fvxv4q0a9a50nWPEmpalYSGNoy8M05KOVYBlyiocEAjoa9TJsJUVeVWpFx06rfUyxlWEqcYxdzrvhfZa/p3hdbmxUR/b5nm3bdfjYqPlXJsl8lxwxBBJ+Yg9MDqmuPFpOGuG69PO8V8f+O1gaF4b0CfRrGSy8JapeRm3Qi4j8Ma04lbHzPujvQhJOclQATnAHSrf/CL6eWJPw/1kEDj/AIpfXef/ACer0KijKbbb+7/gnHHY0ZJvFpY/vzwO8virn/x2sLU/D2uX9/DrVjLHpms20kclvq1tB4iku4GRsrseSJsex6jtg1bHhPT2I/4oLWuf+pX13/5NqKTwlZZ58B62nPbwxrn/AMm1MUoO6b+7/glavc908HeMtJ/at0qH4Z/FyG38P/F3TbJ7fRNaurRoYPENqCSYLiPCllYpuKAAhh5sO11ZD8k/E34c6t8OvEl9pGo6dcWT2Vz9lurWdg0tlMV3LGzDh0dfnilX5ZU+ZcFXVO21HwQkyRS6P4X8SaXqFvLHPBfWXhbVxcxOh3KUaS5cLzznGQeRg17zouoJ+1v8P7vRfEujx2/xs8F6eYbqyulFpJ4j03Iby3DAbX3FWVsYjmKOMJKwXnjUWWy54fwXuv5G+q/ut7/yvXZm7j9ZVn8fT+9/wfz9T4h5pa1PEnh+58OaibWZZvIlBktnljMblAxUrIh5SRGVkdOdrKwyRhjl176akro4NgooooAKZT6ZVICS3tbq7cxWdrLcOqlysSFiFGBnA7ZI/MVP/ZGsDro97/34arvhLxj4r8A6/a+KvBXiC90XV7M5hu7SUo4HdT2ZTjlSCpHBBHFfpj+yn+23oHxia18EeN7gaD40ICRL5zLaao3rASfkkP8AzyJ5z8hPKr5maY6vgIe1p0eePWzs18rPQ6sLQhiJckp8r6ab/ifLv/BPL4Q6h41/aCtPE2p6bPFp3gu1fVmaWLCvcn93bpz33sZB/wBcTX0V/wAFM/hVP4g+HGkePdLsHnvfC995M3lqSxs7nCtwOuJUi+m9q+29LkMjqsju2P7zE4/OsvxgRGSUYqw6FTgj8a+Ox2bynOGaRVuRqyv01ur+d30PYw+DSUsI38XX8vuPwR/sXW/+gNff+A7f4VFPp2pWsfnXWnXMMeQu6SIqMnoMn6Gv1m+Ofx58IfBPRf7T8V6xcyXt0rGw0q3nJubwjuBn5IwesjfKOg3NhT+a3xl+PPxA+N+s/bfFeqSx6ZbyM2n6RFKxtrRegIBPzyY6yN8x56DCj6HI87xOc/vPq/JT/mct/Rcqv67fPQ4MfgKeB932nNLtb89TzqmnrTqaetfSHlrcKRulLSHpVCG0UUUwYyilPWkqhMRulJTj0ptBIjdKbTj0ptABTKfTT1poBh60UrUlUIZRSnrSVQug1qaw709ulNPSqQhtNanUjdKYDaKKKCWMpp606mnrTQgph60+mtVC6iUUUVSDqNPWkpW60lMQjdKSnHpTaaAKa1OpD0o6gNooopgFNbrTqa3WgBKKKKACiiiglhRRRQIKKKKAEbrSUrUlWgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApwGBTQOadSYBRRRUgFFFFABRRRQNBRRRQUKOtOpo606gAooooAcKWiikgCnDpTadQwClXrSU5aQIWiiipY+oq06mrTqQdRVp1NWnDrUsY6iiikUhVp1IOlLQMcOlOXpTacvSkwFpR1pKVetSxjqVaSlWpGOHWnU1etOqWMKcOlNp1IBacOlNp1ABSikpVoKQ6iigdakaH0UUUmCFXrS0i0tSPqFdX8J/CmreOPif4U8J6Fc3Nrfanq9rBFc2zlJbbMikzKwIKmMAvkcjbntXKV9I/sS3Xg3wL4v1344/EXUoNP0TwhYG3tXkUtJNf3IZUSBesknkrcfKOmQSVGTXJj8Q8Lhp1Yq7S0XdvRL5uxtQpqrUjBuy6+nX8D9k9C1a1sbB7y6u1htrSJpJZ55QAkSDJd3Y4AAGSxPqTVv/AISrStc0i01zQdTtNS0+9iW4tbq1mWaC4jPIdHUlWU+oNfix+0r+2f8AEL4+vN4Z02Sfw54ISTMelQzHzL3aflku3XG89xGPkU4wGI3nJ/Zw/a4+J37OWoi00m6bWvCdxJvvfD93KfJJJ5kgbBMEv+0owf4lbAx5uGw2Mhl/s3pO236X7m9WpReI5kvdMD9qHwvq/g/9obx9oWt6hd39wmsz3EV1dytLLLbzESwFnYksfKePJz1ry+vpj9tbxZ4I+MeoeFPjx8PbxpbTWbE6RqtrKFS5sbyA7kSdAThmjkAVgSrCE7TwcfM9ejgK0q+GhOorStZrs1o/xMK8FTqOMXddPQKfTB1p9dbMgoooqQCvZf2avg7q3xS8cadpNlJJayX4kk+2RsA+nWCHbcXozxvyRDCeR5rlsqYs15PomlHWtTi08z+REQ0txOV3CGBFLySY/i2orHaOTjA5Ir658b64f2af2cYdGsYX0/x78W7dWeHefN0fQkTZFDuwCG8tsEnDGSa4bO5BXnZjXnCKoUf4k3ZeXdvySu36W6nThqak3Ofwx1f+XzPOf2tfjdpPjrWdP+E3w2ENr8OPAYFlpcFuxMd5Oi7GuSf4gMsqMckgs+cytXg2ntZxXTTXsCSRou8KWIYkdNp2sufZgVIyOuKht4ZrqX7PaRNLIBuYKCSqjqxABOB1PHTNJIoSV4S6OUOCUIYHvwa68Nh44WkqUNl977t+be5jVqOrJzkSXtxHc3rzRK/koixxBySVQDhRkkgDoBlsAAZOM19n/BjwnZ/sufDmy+I2tCGP4s+PrB5dDhurfzV8M6KxCPfyRdTLIXRI4z80jyRxKMtKteQ/sofC/wAOeJ/Eeq/FX4lIF8AfDa3XV9X3plb24yfs1moPDmRxyvO4DYfviofiX+0T4r8S+ONe8YXrsPEt9cLNG6yFk0mZVaONITwP9GiYxxMBxLJPPnf5TDlxLlipvDQ2Xxfov1flZdS4fu17Tr0/z/yO+8QfFLw38J57qxOo303im0mmnvpIrtZbzTbqb/XRpcYZW1abj7VfkN9lX9xbjcuV8fvv2ifiKyB9Dey0KeCKW20+XTozHJpdrJnzILJ2LNbmQndJOD9olYkyTPkg+s/8E/PBfgbx/wCO/GHhHxt4U0rXIbnQRcRRX1ushTbcwq7Rt96Nv3g+ZCDwOa6X9oj9gmbw9pk3j74E3k+rab5D3tz4ZuSTqVrCrYeSAHDzRr0KsokXH/LQkkcUcTg6OLlg6y97TV7O/Ty67/fe5u6NWVFV47eW6PkpzqmsONH0zUNRv7RHN2yXDbFErffmYbiqdcFyfqRnAhuvDWsWNoL6bTZTYklftSIWtt3HAlGY2Jz/AAsan8H6yNE8QW1+AhBYIZD5QeIZ+8jyRSeUR97eqlvlwvJr6k0rQNC19bS/1aaNtV1CNTA0zNBc3Rxw0El0l/rd2MHGbe1t0PJBUHj16tV0rKxxxXMfIgMZAAAwc4/DrTjyMcj6V9I/EXwNo+k3TxXljZ2l3cDZJDfrFb3kgxwRHqFxe6i59ALSE57Cvn3xHod34a1iWwurWeFHO6LzIJYywPceZFGx/wC+AB6VVKqquwNWHWM+kzsEv7c29xlFt7kT7baALj5povJkaXODnBB5GeMivRby8XSIZNW8T+ErG00KaUQafqVn4QV1vJNu44WeaEgbQTkbs+1eU8Gtjwx4qv8AwvK6WscP2edXjn22lsZzGy4ZUlkidkBHXHFFSm56oE7Hrg8PQKEK+Fp2DAMN3g2z5B5B/wCP+nt4XjcNjwtOB7eDbL/5PridHtLWCMXXhR7M2c3ktc6dPZ22u6pGOd8iGS0jQKO6ZH1bkjobO2stXtY9Ss9Zs/s867oy/hfw3Ece6tOCD7EZrz5wqRfxr7n/AME2TT6GifDC5B/4RWb/AMI6y/8Ak+qwTxf4I17S/iL4CsL7T9X8OO1zEF8P29nBKmP3glMd3IWUpuUrt5VmGRnNL/YaAA/2vp/v/wAU94X/APkimPoUcgJXWLH8PD3hkfyuKi0npKSae6aeq+4pO2qWp6l8fvC/hL4w+AtP/aC8BQwwaf4llWPXInfnSNb+SMSNnAVJiEhlb5QSbaY53EH5Fkimt5Ht7mF4pomKSRupVkYcEEHkEHsa+mfgB4z034feP7v4aeMbmO+8DfEyJtOvopXtUWG7f5VkEdrLIkKnzAhI24DBuPKFeZfHz4b6t8PfGV/puqFpbjT7kWNzcFSPtSspe1u8nqZoR82MnzYZ9xyajLajw1R4GbukrwfeO1vWL0f/AG71bNMTFVYLER66Pyf/AAd/vPMaKKK9o4gpp606mnrTQCVb0fTNQ1rWtP0fSEZr++u4ra1CnBMzuFQA9ssQKqV7H+ylbeGbH4rRfEHxxqUOn+HvA9rJrV1PMpYNMuEt41UcvIZXRlRQWPlnsCRjiqzw9CdVK7SbS7vovm9DSlD2k1C9rs/X7wRu0LQrDSptQmu/7Ms4rZ7q5lLyS+VGFMsjscknaWLE9yTWfe+NPD3i/R117wtr+n6xp8zPHHeWNyk8LshKuA6EgkEEEdq/Lf8AaL/bK8afGZLjwj4Ua68OeCjlHtFkAudRX1uXX+H/AKZKdg7lyAw8z+EPxx+IPwT1k6l4P1VjZXDD7fpVwxe0vFH99OzDs64YdjgkH4JcLY3EZe1UmlUevL09G+j/AAX5fQf2tQpYlcqvBaXOr/bJ8P6poX7QXiGXUby5uodXEWp2TzzNIVgkX7gJ6KkiyIqjgBABXilfS/7SfxD8G/tAfDzRPiZ4azZa34bmNjrGkzOpnggnIKSBuPNiWUFQ4AwZwGVSRXzRX1+RzqywFOFePLOC5WvOOn4qz+Z4+YRgsRKVN3jLVP1/y2CkaloPSvWOLqNoooqkJjDRSnrSUwY09aSnNTapCCm06mnrQSIabT6ZQAU1utOpGpoBjUlOPSm1Quo1utJStSVSEIelNpx6U2qQhtI3SlNIelMBtFFFAmNPWmtTm60h6U0SNprU6kbpVCY2iiimgYjU2nNTaoTCm06mmmgCiiihgMooPWimAU1utOprdaAEooooAKKKKCWFFFFAgooooADzTadSMO9NAJRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAKtLSLS1LAKKKKQBRRRQAUUUUDQUUUUFCqO9OoHAooAKB1ooHWgB9FFFJAA606mjrTqGAU5elNpw6UhoWiiipYIcvSlpB0paQ0KvSnL1pq9KcvWpYDqKKKRSH0UUDrQMdT6aOtOqWAU5abTh0pMoWnDpTadUh1HLS0g6UtSxgOtPpo606kADrTqRetLQAU5abTl6UMoWlHWkpR1qSkOooopMSHDpRQOlFSNbhSl3MaxF2MasWVCeAxwCQPU7V/IelJRQMcopaQdKWp6gJgZz+NLRRVAKOtOpq9adUsAooqWzsrjUry3020UNPdzJBEpOAXZgFGe2SQKQHvf7JfwttfHfjSzTXI0/sRFbWtaeUfuxpdnICI2JBXbNcqgYHDBbaUjgmuB/aB+LN58bPizrfjuUyfY55vsmlwvwYbKMlYlIONpIy7eju9e56lqEHwf/ZI1bW9Nby9T+LF6uj6aWQpIuiWytEGKk8eYiys2AMm8BxXyYsJ+yG7MsQXO1U3gu5/3RyPqcCvIwP+1Ympi3snyR+XxP7/AHf+3Ttr/uqUaS3fvP8AT8NfmaMmnCz0pJrqPy9p3x3FnfR3ClhjHmIGOG/2sjb/AHTWUu9ugYySHOCdxLE/rzS478/nXtn7G/w+sviH+0H4dg1lEOjeHvM8RaoXOFW3tB5g3eqmTylI6YY16dWqqFOVSeyuzkjHnkorqd98cr0/s/fCPwZ+zxpUnka2sCeLvFjRn5n1a5XFrC5HUQRqWwQQWjgJ618rcRpwBwOnSux+L/xDvvix8UPE/wARL+Rydb1Ka5hVhgxwZCxJj/ZiWNP+ACqPw+tL+78Y6eNOaaOWAvO00V9FZGBFRiZPtEoMcGP+ejD5Tgj5torHDUnh6N5/E9Zer1fy6LyKqS55abbI9X/ZD1bUPDPx3fRNNl1Cxv8AVdC1DT4mdHhmWcWxuUG1csoZ4I1wMlgQQPm21+iJ1qIXd5r+j+Y/2Syh8aadLGxZWtJxtv7VSQixDKFwGkzuJbZhCp/Lvwx4hPw0+Onhnxy0iLaWerWeptIscyxyWpdWlK+f+9dHTdh5ACwbOMGv0atdVj8C/wBi+IL6WFU+H3iS78N39wJEYJpV2waNmc+YY0AaM4M0IUBdwACxV81n9FPEQqpfEvva/pR+Z6WAnaDj2f8AX6s+ev29f2ZNP0+0T9oz4X2CJpOotFJ4htraPYkUkxBivkQgbVkZlDjAxIynH7w7fn34WfFmPQbObw/fJceRd5823tvPSK8U/wAEkNmYJr6TPIWe7WP5jwcAV+nEV5Y2PgXxD4C8R2EGoaFo99JpGrxT7lE+h3QOyUSSFVyqyjJUzMdmP9Y2F+Hfh5+wenif4ueOPh74r8ePptt4I1CKMxW9oXvL6znVntrhGbbHGGQKSfm2scbehrqwGaUo4OSxktIdd21pZ6ddV96MsRhZSrL2K+Lp59TptG1jTLzQp7XTv7H0fSoCy3SxThIUyBgS2ukG0sYG5PyXt/LJxyGJNcq37MXxP+KlmE+GXgW/1KKVif7Ug0yx0bTypPUzLEFkA/2LiUn1PWvvX4Sfs3fBv4cJp7aT4Tj1G901Qtrf605v7iDH/PHzB5cH/bFEFfRVpKbiP5yWIHUnPFLBZnSxU26N7ef9fqOtgqlFe+flv4K/4JWePLiOKT4hfE/RtJAwXt9KtJL59vpvcxKp+m4fWvVtJ/4Jtfs/6BNGPEWueKtalc7VinvoLZHYDJCrHFvPAJxvPANfbGrQw2MkurPNPthhbcilmXaDuLCNc5bjAwCccDrXAa4ZraRTp1prDW1iyMlraaYhDCKQJIgklIJV0nUjbg7YHKMTlT5uYZhjrtKpb0svx3OvD4fDpXcbnhUP7H37NHhSSSTR/BGuRTKWDvZ61qofK7M58qVQeJFI9RuxnaceIftL/sf6B8KdC/4Wn8KNGV9EsVH/AAkej3NvDqcsNupObu3e8SUqAT+8HPGG+6Dt+r4bfXRJAZtG8Y6gLY2zmS61eGMSNHM9lLlEIUhreT7WQMLJtUjZKOZ9FjutIsp11bR9dEMttJDdRahdjUEEdpm3Q4GWc3EIEpwp387gHJDePSzXFYWp7V1HNbNOV0/x7bO252ywlGtH2aiovvax+Y1qunXUaSrpfhfYyhlzeeEUOCM8hkBB9jyO9Sm201VIGkeGD/3EvB//AMRXXfGPwP8A8KJ+J+o+Cba4vIPDWoQnWvD8n9pwWccdtK5325aW1lLukhdR8wO1Qx5auTTxTYjk6/ID1z/wlNjn/wBN1fb05e3gqtNJxauvT7/vPn5xdOThLdGP4j0uy1LR7mzi03QYJmTdC8Gs+GISJB93c0ASTbnqAwyK9e8XzwfH39nbQ/itdSr/AG34aVfCvi2ZsZ+zs6G3vJDjJEcxglbGBia5GcCvOn8T2EpBbxHLg9j4rs+Py02up/Zm8S6HYfFvWvhbqV8t14b+KGmzWN3H/aC3RF0VcqTIkcShmzMoAQHMqcnFc2OhOnSWJjH3qT5tOq2mt301Xmkb4ZxlP2Lek9Pn0f3/AIM+Zp7ee0nltLqJop4HaOVHGGRgcEH3Bpldh8U/C+oeFvFFzY6mM3ltPNp18wBCteWzeXI4zyfMXypyT/z36muPr6CnNVIKcdmefKLi2mFNbrTqa1WhCUc4K5OCQSM8Ejp/M/nRRVAFIelLQanqAzH69aKKKoAoPSiigTG0UUVSExrdaSlbrSUxsQ9KbTj0ptNEhSN1paRqZIlNPWnU1utACUh6UtB6U0Aw02nU01QmIelNpx6U2qQdQplPpp600SMPWilbrSVQDDRQetFAmI1NPSnNTT0pokbSHpS0hqhMbRRRTQ2IelNp56UyqEwpp606kbrTQhKKKKGA09aSlPWkpoApGHelooAZRRRQAUUUUCYUUUUEhRRRQAUjdKWkbpTQCUUUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFACrS0i0tSwCiiikAUUUUAFFFFBSCiilHWgY6iiigAoHWigdaAH0UUUkADrTqRetLSYBTx0plPoGgoooqWCHUtFFIEOHSnLTacvSoGLQOtFA60FIfSr1pKVetAxw606mjrTqlgFOHSm04dKTK6i06mjrTqkB46UUDpRUDFXrTqavWnUAKtLSLS0Agpy9KbTh0oZQtKOtJSrUj6DqKKKlghw6UUUUhoKKKKBjx0oooqUAUUUVQCrTqatOqWAV1fw18PX3iPxEljpuBd3LR6ZZFshftd2628fI5BUSNKMf88TyK5SvpT9iXw5a3/xN0fVb8qtrpC3/AIkvN65HlW0Igt3z2xJdzH1zH7VxZhiPqmFqVuyb/wCB8zbD0vbVY0+7KP7cev2DfE3TPhd4ewmi/DvRbbR7WJeAshjVnIP+55KH3iNfPs0kU8kN7NGhQYikWFoo2OO4CrlewyytyMEmtbxl4kufHfjnWvFd7Iyy67qdxfNuUuR5khcIAO43bQPYDI61LPbpeW1vZ2trcSqzkW9vDtVZXUHLsRw2F2k48xgMhpF4p4Ch9TwtOjLdLX16v5u7DEVPbVZTXV/8N+Bz/c4ztycZIJx2zivp/wDZxdfAX7MPx2+LRbZd6hZ2vg/T3Xh0a5YCfB7fJLE3/AM18wGNoZHiYqdp6q+8Z7gHvj1BIPYmvpDxVLH4d/YE8EabaybJfF3jbUNRuQB/rEto2t8H1wwT8qnH3lGFL+aUV8l7z/BBQ0bl2T/y/U+cV4Ueveu0+DVldX/xN0OCyjuHnEzOgttNiv5gQjHckMxEJYdd8pCR43sQErjPkIQouDtw3zE5O5uSOx7cYGAO+SZ7C+l0y+g1CCOGR7eRZAk8QlicqwIDo3yuuQMq2QRwQQa66kXKLiuqMk7O56V8e9KEep22r6fGsllMZWF0l216b1w+JJjeyASag24EPdKiwGTesPyrk/cXwt1NPir4T0oteefdfEHwBCpZZQH/ALW0tjAzrtVpUIePO8NGqlvl3SNuHxl8ZPFFz448M6Vr1lZ3m3XGjVpJCfMu549q7GmZEe8kjBC7IY4rS2XbHGhaTcfpT9lga14P8H3Xgbxa7Qa38LPE1prMkCXDbIrO/iEU8LBUfzHimR1ZEjZhISqMM76+czaEpYOEvtRfz/pT5bnfg5JVWns/6/K5774R1N9Vn8K6vqktukPjbQJfC2tPbOsoj1C3DKgkubdpDuHzp896zBiURTIXYcLqN3L4F+Lnwn8fXOy2i1mO6+FfiM79sf2qBy9gwCgRsxZduVLBQu3exBNekazpckMfi7QrR5J7zRr238WaLAJSblIjjesQBubhV3LImIYIR83lx8l3rkP2qNAbUvh3401PQJdmoT6bZeOtMaRlMkVzpkieayx4LjFu2DlwinCqpO414OGcK79k/hnp9+33KSf/AG6ehUTp++t46/d/w34n0GdRe02JazQrKVY7PKaaXcFLqojUjO5Uk6kZOMZPFTa74v0fwZZDUvHGu2GjafDLG51DxDrEdojCK4JDJGpVdxidip7lUV0OM1+VXjX9vT9orxrLLaaL4ksPB9rMGymkRrBIV5ODcSlpMjn7rr7CvJdV8JfFrxTqdvf69Za/rWsamcW0d3JJcajdrgkSLCxM7R4BO8rt6854r1sryKthI3rTUX5a/wCX6nLjMfCvK0E2j9PPFX7fn7P3hK4C3vxUvfEl1bmFntvDWhkwysjyll824KqVkVowwWQ4MeVI3EV82+OP+CgHgLWIW0/TPhp4y1+B7f7M0mveKmtmZDbfZ3JS3jI3OnzMQ/8ArBvGG5ry/wCB/wCyRbeM9ZmX4s+NLXwtpcKlCLGVLqcT9ondcwo54Ai3GbPHl1H+0j+zV8N/g3Yfa/A3xy0XxNf29xsv9Emngjv7eJseWwVJG3MDkOpCsODtwGx6H1fL5VFQk3KT9bffGy/E5lUrpOotPu/JnV6n+3bpOti8j1b4CWEsV+uppOI/Ed3GzLqCot2A2CF3+WhGB8rLuUKcmuy8M/t7/Dme7E+veFfGvh6SbWbbV7h7LV49SgJjgWB4ikqxHyZEUM6gk78uMNXw4DxmkOCCM4rapkWBqR5eVr/t6X6tr8CY46vF3T/BH3H+0F4z8IfFD4S6L8RfCfxOtdd1fwj4pf8A0i1M1hqFtpV/I6iGVEAmQqFijMiIQ4QkZLEHxf8At+/VSn/Cw9UXHGDrviL/AOQ8Vi2nhS68YeHfCl/aeGdPg/sm3X9/pvhbUw1+QwJFzNbjbMwZSvmIVbqN3Ax0n9jeK93zeHpj6n+y/FXH/kxXLh8PTwlL2Kbdm+2ivttbu9Et7FVasq8+e29u5SbxBesQP+Fjaocemu+Iv/kOud8Wa5qFqdN8S6Z4qmvdS8P30WoWhnvNWuyjKwOV+1WyIvIRidwyExzwK61tH8WAZ/4R1+emdL8Vc/8AkxVS/wDD/iS7sprS48M7op0aJz/ZXic4DDHRpyp+hBHqDXRB04yT1/Az946X9r/SrXxBd6X8TtGgC6f410Oz8QwdyJ4ljgnjC9iYprRmP/TE5r5g619VaQ0njb9kbSYdTJjvfh94qk0W7adSHhsr0GBxyMrtN2oHp5IHavlZo5IpHhmjKSRsVZSMFSOx96rJW4Yd4Z705OPyXw/+S2fzNMcuaoqq+0k/v3/G4UjUtI3SvYRxDaKKKoAoooqWAyilPWkqgCiiigTG0UHrRTQMa1JTmptULoIelNp56UymhBSNS0jdKZLEprU6mtQAlFFFADKaetOpp61YmIelNp9MpoApp606mt1qkSNakpWpKoBp60lKetJQJiNTacelNoJG0UHrRVgxlFB60U0J7BTKfTKoGFI1LSNQhCUUUU2A09aSlPWkpoAooooAaetJSnrSUAFFFFAmFFFFBIUUUUAFI3SlpG6U0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAq0tItLUsAooopAFFFFABRRRQUgpR1pKUdaBjqKKKAClHWkpR1oYDqKKKSAVetLSLS0mAU+mU+gaCiiipY0PooopCQ6nDpTacOlQMWgdaKUdaCkOpV60lKvWgY4dadTR1p1SAU4dKbTh0qWV1FHWnU0dadSBDx0ooHSioGKvWnU1etOoAVaWkWloBBTh0ptOHSkyhaVaSnL0pD6C0UUVLGh1FFBOBmkCAEE4BGR1or6i+Nv7OD+BP2PvhH8UksfL1G9uLh9ZZYyGMd+POsy/cbYodvPeSvl2sqNWNaPNHu19zLlFwdmPoooq0SFFFFUAq06mr1p1SwEOcHHWvqz4PM3gj9nj4s+NtwiK+HNO8O2U4+/vvQ80mD7G/iAH+xXymQTwoJPYDqfavqvx4ieE/2M763hfnxX8QLiJCO8FsHjQfQCySvGzn34UqH884r7mpP8EztwXuylU/li/ysvxZ8nGQRyxyHb8vzbSM8+uOmPrx+Ga6eS9aPSJUuJ2MhCrKv8MIySqyH+Jsg7IFwi7AWHyvjnLdgZfMjbaRyJB1GO49/Q9j05wR1T6Ag01G1NVgtrSNJJIUIzCJBmKM8fNcTbC3Q7I0zghdkfsztpc4kcoo2REY9TxXv/xnuW/4ZU/Z9tIiBCw8USNj++NRQf1NeD3MEtvdzwTxRxOjkPHHnCN3XknoeO/Tqep9s8aXUOu/sdfDe5iwX8LeK9a0eYd1NykN2o/EBj+BrkxTSqUW/wCb84yX6mtJe7NLt+qPFZI5IxF5kPl74gy8nLDc3JGeDx6DI2nnqY24U5pFYkncckYGd2eMDHP049sY7V7/APstfCD4eeM7Lxp8TvjFPcjwV4KsUW5gtt/mzT3O9EYGM7/3YUsAOrmPJ2hwdMTiIYWk6tS9l21bvokl3b0Jp03VkoRPSfB/hhvh18MfDvxL8R+HVPiaK0gTwjpeqOt3cvIyv5d7dRMwaG2cq1raIg2RSXEcrbnZXrU+ElrZfDX4v+BofEmu6bJa/EvTLvw5LZzXJe6n0qcD+y7yZFOAsuyEfMQxLy9Oc8d8NNdXw/4CHiDxnpuqeMbmGe9T4f6TfM4n1DTVjLyvOgJK2EbxRXAYMNktu3lnmUjntf1Zo/gAvxi13U7JfiF8SvFks0WoXFnuuIbLT2jIFmVyII0mVVJVcnEUYXYuR8/OnOrOVOT0k+W/reyXW0dW3/MrLrbuTjBKS6K/5b+uiXkfpF4Qt473TtC1a8vdNX+z7W58O6mkk67bh1dYkjCwsltu3JgrscruMaEfMWuDw14fu/D+k+DZNah+y2F3daBNFeQSaek8c1tJG1vb28Pk28rKjhUOyRFVHKguCw+bov22v2fbbwYfEmta5qF5q2v/AGLVLnQ9KsbhLy01CJEEo+0SsIwPMT5ShUCPoDuJrxbx3/wUd8e6jqV9d/DL4f8Ah/wz9smE8l7eIb+9eRUEaS5YLErBAAP3ZwBjJHXxcJleOqSfLBx9dEvv1e7Wmh31sVQUUm7+h5p+yr8I9d8f/GWbwva3y2aaQzm/vEneGWJVfB8to0aQFtrD5Xi648wZw36fW/7Pnw10vwddeGfB/hLTtMFziSZ1jDy3sgzzcyyiRpySfvTCYDrtJxXz/wD8E9tDi0z4V3HiFxfPf+JL2S8vLiY3AhnZWZVKCREQsAPmaPzBk8v/AAL9k6VLkhTSzXNJ18xlQTtGOnq11+/YrB4OMMMqj1b/AAPirxD8P/2hPBfxQ0jQvAGjpYNqDi0fxVDpyak2l28hEZe3gndppFTepcptiRTuaGPgjxP4v/sLftc33jMy6jcWXjaCaVkt9Ui1WGGKJGPeGZkaHPBKopX0J61+tdrHF5W8qCcYzisLW0Dk8ZxXp1cfVwFFVKai5W6r+n+Njkp4WFao4ybsfjr+yl8BNJ+J/wAY7HQPiJePp+i2888ZjJMP9qzRAhraCQ4O7OWOzLBVOdvDD6J/4KG/AnwN4K+EOkeKfh/8PtI0t9M1mCC+vLG1WKUWr27xr5rDmQb0iG58ndjn5mz9s2GhaFaanHqcGiafFexQm2juUtI1lSEsWMauF3KhJJKg4JJOKp/FPwRo3xG8Da14H8QR5sdcspLOVgATEWHySrn+JHCuPdRXmVM/nXxNPFO6jBq6v06nXDLlTpSp6NvqfkRpHgOx03T0trzwLrN9Lku01z4ZR5OQONy6ioIHb5RVn/hEtGPK/DnUvw8Kj/5Z1DFol54fu9R8I+JpdJsdY8PXk2l3kU+naBFh4mKhla72SyAqFPmEEMSeTUps7PGRq/h4nHaHwp/SSvrnVne6mvxPDUVtYR/CmkbQD8ONRGe//CLD/wCWVMk8JaOAD/wrrUB/3K4H/uSoFrZ9P7Y8On/tj4V/+OUNaWgyDq3h/wD78+Fh/wC1KPaz/nX4j5V2PQ/2frA6ro3xq+Eo06e2Gs+GTqmnWdxa+QUlhU7SIhJJt/eSxY+duEHToPnLxYRL4jvbxRtW/KagF/ufaEWbb+AkA/Cvoj9l+/t9E/aW8P24u7GeHXdLvNOk+zHTgpAjeXBWxdkBzGvLYY+4Arwj4iaO2g68mlSAiS0jms3z1P2e5mtlP/fMC1z4J8mYVo/zRhL52cX/AOkI3rrmw0JdnJfk1+ZzFI1LTWr3EcIlFFFUAUUUVLAaetISB1pT1r6I/Yp+BNv8b/G/ia31a3D6ZpXh67hMh/5ZXl5G9vbtj1UPLID2MQrHFYmGDoyr1NooulTlWmoR3Z87UVa1XS7/AELVb3Q9VtzBfadcy2lzEescsbFXU/RgR+FVa3TTV0ZsaetFB60VSExG6U2nHpTaoOgHpTKeelMpoQUjdKWkbpTJYlNanU1qAEooooAZTT1p1NPWrEwplPplNAwprdadTW61RI1qSlakqgGnrSUrdaSgTA9KZTz0plBI09aKD1oq0DGHrRQetFCF0CmnrTqaetWDEpGpaRqEISiiiqYDW60lK3WkoQBRRRQA1utJSt1pKACiiigTCiiigkKKKKACkbpS0jdKaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAVaWkWlqWAUUUUgCiiigAooooKQUo60lKOtAx1FFFABSjrSUo60MB1FFFJAKtLSLS0mAU+mU+gaCiiipY0PooopCQ6nDpTacOlQMWlHWkoHWgpD6VetJSr1oGOHWnU0dadUgFOHSm04dKlldRR1p1NHWnUgQ8dKKB0oqBir1p1NXrTqAFWlpFpaAQU4dKbTh0pMoWlWkpVpD6DqsabpmpazqEGlaPYXF9e3TiOC2t42kllc9FVVBLE+gFV6QjNSwR3Y+BPxyOdvwZ8dH6eHbz/wCN10/w1/Zc+M3jT4geHPC+sfCvxjpWm6pqdvbX1/d6JdW8Ntbs482RpHjCrtTcRkjkAdTXqn7OH7cms+CZLXwn8YZbnV9DXZFb6wqmS8sV6ASjrPGBj/poOcF+Er9Nvh74i0XxJpNnrmgava6lp97GJbe5tpRJFKh7qw//AFg8HB4r5PGZ5jcDX9hXoJJ7SUm0/wAN/L/hz16GX0K9P2lOpdrdW1/P8Sj+0R8G7X4ofs5eKvhvp1gvmy6SW0mFRjZdWwElso9PmjVPoxr8Yj+z78fEGX+CHj8fXw1e/wDxqv3/ABIraaOR0rxj42/F7wB8GPC0/jD4g66ljZqTHBCvz3F5NjIigjzl3P4Ko5YqBmuirjZZZCMKMOdytZX6/czKFBYmTlOXKkfi9f8AwV+M+lWFzqmqfCLxrZ2dnE09zcXHh+7jihjUZZ3dowFUepOK43Oele3/ALR37WHjz9oHUZdOLvong6KYPaaJDJnzCp+WW5fjzZO46KvG0A5ZvEK9rDTrTpqVeKjLsne3zstTiqKEZNQd13tYKKKK6SBR1p1NHWnVLA1PClst54s0S0kGUn1G3jYezSKP617/APG+7e3/AGSPg3psuQ+q3uq6vKD1LPO7/wDtc14L4Iz/AMJv4cx/0F7I/wDkdK9w/aZYw/Av4B2ychtAvJcds4tT/wCzV4+P97GYWH99v7oTOzD6Uar8v/bonhvhHTJLq+jm+xpdXEsohsbV8eW03XfLngRRg7mLfL0B+UuR0uranDb2UU+n3ElxFbyyppMs0TK17dkg3WqSFvmGCAEzjGE5Jik3Yfh1WNu1otx9nmvIGW6u9pP2GwX5pcAY+aTkYGCwO0Z84ik8Qai8tqLtLc25vIhFYW5Yn7Hp6MVUZ6bnYHJwpJ3kj99XpyXPU/r+v6fkcmyOdiXaoHHHpxXe6D8RLCw+Dfi34V6tp1xctq+qadrGkToyhLS5h8xJy+eSHhlKjHdRniuBTbGqRZycfn6mn1VWnGqrS7p/c7oIycdh3yGNWyu8ZTCgAgA5y3rndgeyn0FeifBr48/EP4FajqF94GurFoNXhWHULDULYXFrdKu7YXQ85Xe2CCOGYcgkHzfzR8wTBZex4564p53gMskZR1JUqeoIOMUVaUK8HCqrp9GEZODvF2Z9ffA6DxR8SfCPxt/aU+IOoRahqMXhbUtLsJhKAbdjZuZESBBtijWLy0QcYDMAOpFH4KfD7VvjP+zzpWheH9ZktNX8PeML+xgmRjDHZQX9nGrSzMiSSMmVcZVf7wZkUFx6x4B8O6R4I/4J++Jr63s2ivNa8P3kt5NJHGGmaWXy12uhbfGA/wApLHO5jhCxUfOX7IfxSg+FfiuSTxpakeA/FUkOl6jczITBDdxnzbeU8fN5bfeA6LISf4QflIzq4iGJq4Za05pRXlFWaS9G7Lq35nruMKbpQq7Sjq/V3v8AkeQ6z4H8UeHdZ8Q6DqGjT/avCsrw6u0UbNHbbZ1g3M2MBTK6KrHGS6461iE8E1+s9t+zD8P9e8G+NrCW/vNW1v4jA3mpa5NcbWupSxlt9qwMiC3WQowjVgGCruc4BH5S3GmapoPiN9C1KxaHUdOvzZ3Fs0SzFJ45NrIU5V8MCCvIOCK9fKc2p5rGThvG35b997/Kxx4zBzwjSl1P0D/Yx8S6f4L+Fmn+IfHms2OjRX4FnpwnsZo7jUArEIsckzvNdbQAFjto1iXtubcF+0fDGqjUbWO8WzvLZZOVjvLdoJQOxMbfMueuGAOOoFfnJ8OrnX9GjvPFN/fvpd7bhbXVtUudTS1vYQSNsF/rEiN/Zy42hdPsEa624R9pAc/YXwC1XUdT063u43vxpLxGW1ddIOk2FxnGZIIrlnv7lTn/AF85UN1A5r4vNcJy15Yq+rfy9Nv11Wumx7WDr3hGjbSx9J2c4MHJ7Vk6u45xTrOdvL5PaqmpuWGM0YnEe0w6RVKly1TIVwsoJOKuXzK1qG68Y/Gvnn9oX4V/GLxRcweKvgn8XtR8Ma1aqY30+e6cafchlCF8BW8twoGPlIyCRtYkn8+/GH7QH7WHg3xRqHhvxp8SvFGna1bWkOm3dtNcqGSEbZFAKcKxyN0ikO3IcnkVnleUf2lTl7GrG/VO918rbeaKxeN+qyXPB+vRn0J+3F4M/wCEO+I+ifFbSoES18WJ/Y+rgTW9uPtkK5glaWeGVV3RfKfl6QdRmvn9tehdgzXFj7f8VRpI/wDcfWn4k+NXxc+Leh+HNP8AiP8AEDw3fafpd7/bCrHqMGnXrXG1xEXljXMbR7yFCqMdxnBFF/EVwCceMbn/AMONOf8A2SvrMBhauGw0KOItKUbq6b2vp22XkeJiasKtWVSndJ/n1IH8RR8Ay2RGe3ifSf8A5Apx1+Db/rrLn/qadJ/+V9OOv3L8t4yuSff4izZ/9AqJ9auSMr4yuAT/ANVClOP/AByuz2cf5Px/4Jjd9zU+GWtonx6+G17FLDlNW+ykxaraXZAm2pyILeLb948tuz2xg55H9omxNl8SvEcJzmDxNrMAz2U3Hngf+TFb/hvUJ5fij8O5X8QyX5TxXpwCP4nfU9u6eMEhGUbPTd36VF+1ZCsXxS8TkADf4n1Bj+NrYn+tc9G0cygkrXpv8Jf8E2lrhX/i/Nf8A8VprdadTW6176OASiiiqAK6bQPhf8TvFemprPhb4c+KNZ0+R2jS70/R7m4hZ1OGUPGhUkHqM8VzNd58IPjd8QPgh4g/tzwXqpW3mI+3abOS1peoD92RM9fRxhl7EZOefEOrGm3QScuibsn89bFQUXJKbsvLUhHwI+OR6fBfx4f+5bvf/jdfpt/wTx+C2r/DX4GS6l4o0S80vXfE+oTX11a3lu0M8EMf7qFHRgGX7skgDDP72tX9mz9pbwD8fNJEmiXX9na9axh9Q0O5lBng6AvGePOiyR84AIyNyqSM/TOmFVs2JPbvXxtbNcRmTlgsVS9m1q1e+3y263Pbhg6eGtXpT5k9tLH5I/tr/s5/ECz/AGgdc17wL4A8Qa1pPiRE1Yy6Xpc1zHDcPlZ0YxqQGMis+Dg4kFeCt8EPjWhw3we8bj/uXrz/AON1+03i6WOAzTyzJHGgLuzsFVVHJJJ4AA7mvg39on9uTT9Ka58I/BK4g1C++aO48QFQ9vAen+jKRiVv+mhGwcbQ2dwyyriHMMROOBw1BT5Ek5NtJJbN6f8ABfQvF5Zh6cXiKtTlvra138tT4m8Q+GfEvhLUBpPivw7qei3xjWYW2oWkltL5bZ2tskAODg4OKzas6nqmp63qNxq+s6hcX19dyGW4ubiVpJZXPVmZiST7mq1ffw5uVc2589K19BG6U2lakqxdAPSmU89KZTQgpG6UtI3SmSxKa1OprUAJRRRQAymnrTqaetWJhTKfTKaBhTW606mt1qiRrUlK1JVANbrSUp60lAmB6UynnpTKCRp60UHrRVoGMPWig9aKELoFNPWnU09asGJSN0paRulCEJRRRVMBrdaSlbrSUIAooooAa3WkpW60lABRRRQJhRRRQSFFFFABSN0paRulNAJRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAKtLSLS1LAKKKKQBRRRQAUUUUFIKUdaSlHWgY6iiigApR1pKUdaGA6iiikgFWlpF60tJgFPplPoGgoooqWCH0UUUgQ6nDpTacvSoGLQOtFA60FIfSr1pKVetAxw606mjrTqlgFOHSm04dKlldRR1p1Np1IB46UUg6UtQMVetOpq9adQAq0tIvWloAKcvSm05elDKFpR1pKUdakpDqKKKTEgb7nTNfrJ+wRoH/AAhXwI8O2kq7Z9ZaXWZcE8idh5X/AJCSI/jX5U6Fpseta3p2kT38FjFe3cVvJdTuEigVmAMjseAq5ySeABX1R8bf207pbB/hx8AZ5tJ0S2gFi+uqDFdTRIuwLbDgwJtAG/iQ9tmMH5jiLDYvMPY4TCreXNJ9El39b6LfQ9XLKlHD89as+lkurb/4Y/UfT/i14B1bXtT8BaR4y0i98RaLGsmoaXBdq9zbKe7oDnjjcByuV3Y3DPwT/wAFSvCDX9h4N+JVvuZbOefRLrqRiQGaE+g5ScZ75X0FfBWh+Idf8M67a+KPD+s3mn6xZTfaLe+t5WSaOTn5gw55yQfUEjvX1dqP7VemftCfAvxB8Kviw0GneMEsxd6VqKKI7XU7q3PmIhH3YJnVWj7I5fA2EhTjiMBi8Di6GJpPnhGykuqT0bt1S37r8SqVejXpTpT0k9V2729T5DX0paYpPen19S9zygoooqgAdafTKcOlJgbXgkZ8beHRnH/E3s/y89M17f8AtHsb74A/AfUIiNsejXtuG9x9mH/shrwTQ74aXrum6oxAFndw3BJ9EYH+lfQvxm08n9kz4cGTiTRPEWq6OSP4QJ7naPb5YVrxcwfJi8LP+/b74T/4B24b3qNWP93/ANuieAaO8Ulo9g0rLbyAT6jMhAf7OhG2JSePmbbgfdLGIHG2l1czXtw008aRySxLdSxoMLBBtCwxL1wuwoB14ZAfumqOlSRKsgdAbaI+bIpJHm7eFTjnknqOcEnHy1fkkIDvfESux+33pccSSHPlxkAY53ZO3Bw7ZGUr2HpL+v6/pHEtjGe1ki2kAjZtDtjkZGQp+oB69CGFP7Vd1MTra2ySYMjsbq6JYb98uSgIHUFVDg9f3h9azVkklJ2JlQcE+2f8/mKrWWotjrZLGzm+HkEqxWK3UVw8+/8AtGyE5UsEIMIjFyfuqQDIVABYLzWPpOl6j4k1RLKzSSaedmmlcQySbF6ySMsSM+0DLHapOM8V6hpghbwXFpE/iXV41l0/y3t/7R1lYMuhJXyUsWi25PKhyh/vEHNee/D231G68Z6SdMtpLie3uEuQI3nVlCEEuDb/AL8BPvlowWVUZsEKRXLTqNxm7Wtc0aV0feXxTh/4Qz9gG4srbUILtL+Gyht5oJ4Zo5I5b6N/lkihhEmURzuaMPkkOSwJrwjwl4J1nW9OihEVtHYQaVbwaveavdLaWdjGQrJFfTxEC2jZjlbC2P2iYlmmcHaB7H/wUP8AFB0H4Q+Bvhsb64nu9SvBe3LzzLNJIlrD5ZMkiqocmS4J3BV3FCcCk+AfhKDV9U8LaVeXuoRTaLawXdvbWlhGG0yN08xZWh+aDTBN/wA9X8y/uc7/ANyjEV8dha7wuWvFPTnnOX5L81+vQ9utT9rilSXRRX9f15HoHgH4BfHj4S+CoJPgf8cLHVomtjdLo3iPSyLEyMN6tauWZ7YHj5GwpJy/U4+M/hnpt9aeItZ17xVp2q3PjGTV7mylgVhDf3OoAlpoIH6W5GWkubsgeRHjbh5FNfrbp8Frd2ktneQR3EFxG0U0Uqh0kRgQysDwQQSCD1Br8yPj74E8Ffs7fGzVtN0TRtUutFvbS4vbrSLZylq9vLtktrQszNceQGRftEqv84JjXZjdSyDHyxyqwqfHLW6STdu7Vv66oWZYdYdwcfhXm9PvuanhiHWvEOpaPJpdvDfXVsWg0P8As3TI5LW1SNszJoVjMRCkaMMS6rdnYGVmBaRN0n2z8FfC8fgrQhqGppbyXWpw/bbrUxey6i7KMc3OpTkNcuc5yqRxAK2xAoBPyt8F73RvFbyXlteWeti5UX98t5KtrYR20B2Lfa00ZCw2cZQraaVGQoVEZx/y1r7F8JeJ9K8QWOn6zp80muQSxRW9nqVtFg3ccpO6cQAARQZjysjcMq5QsMF+POqs/wCElZLf/L79fva3aW+AhH42/T+v67dj02yuCVGOlNv33Kax9B1IXljBdrNbyCeMPvt5C8TZ7oxxke+K0biQMORXie1vT5WejyWldHjfxT/aK+Dnwpnew8X+NbQamDgaVYg3d9kjIBhjyY846yFR718M/tBfFv8AZc+PGqT+Mb2Lx3ofiHStOmsraMWNqE1N1VjbiRvNfy9rkAkjOzjggEfcmvX9v8M9f1jxVqfgTwxYaReXBuLrxDp8MNrPGrMqhryR8bsYkkkmZlHzRRxpK5JrxL9pjxx+z3478C6zPqWveBNRvk0m4+ywywPH4iju2jJtvJGBKuZfLykoC7SS3Fevk6pYevGVOnNt/ai113VkvzfocONlOrTalKOnRr8b3/I+Q/DXiCW10HTLcPp4MdpEg3eItJiIG0YBSSyd1IGMhmZgc5JNaL+Jbrkm40s46Y8U6L/8gVU0nULmPT7GO/8AGXiETpbRJIn9s65GVcIAV2pZMq4PGFZlHQEjmrcmrk7lXxh4kGB0/t7Xj/7Y19rKK5m+T8/8zwU7L4hV8Sy5AFzpwJ658VaP/wDK+kPiOYgg3OmcdB/wlWjf/IFMTVCR/wAjb4jzjn/ie69z/wCSNM/tVsbW8XeIhz1Oua7/APINLlX/AD7/AD/zHzP+Ys+FbuTWvi18OrENbt/xVNjL+51iyvMbZozyLe2iK9+SSOOnesz9qO8W7+KPillbIXxVqSD/AIDBZp/ND+VdR8HnXXP2ifhzYLrepagIb+4umW71C/uQhSIuCBdQRbf9UeVznHOMDPnHx4vje/EPW5twZbvXNXvlYdCr380a/wDjsK1hRiv7Sjpa1Pb1k/8A5E1k/wDZX5y/JL/M87pp606mV7yOAKKKKoApG6Ypaax7+lTuwPp//gnj4I/4SH47P4wuIibbwjp0tyr7iMXM4MEQ9/leZv8AtnX6i+IPid4K8A6VaXXjTxbpWhw6jcLZWj390kInnboi7jye5PRRySBzX5gfBD48+EP2aPgtNd6fDb69478W3b3i2CviKyt48xQG6deRz5sgiBDMHXJQEMfAPiN8S/HHxY8STeKvHuv3Gp30vyxhziK3jzxHFGPljQeigep5JJ+QrZXis2zOpXm+SlFcqfV23su129evS57MMVRwmFjTjrN6vsv6R+u/xw0pfHngTxL4OMgX+2tLubONs9JHjPlt+D7D71+MLRvCzwyxskkbFWVhgqR2PvXvnwM/a38Y/DCG18KeK5LnXvCcIEcUJYG609QePIdjyg/55Mdv90pyT5r8Zf8AhGpfib4g1HwbqUV/omqXR1Kymj4+ScCUoVPKMjOyFWAIKEVfDmW4vJsRWw1f3oStKMls7aO/Z7aeWlxZpiaONpU6tPSS0a/L5bnF0UUV9gjxWNbrSUrdaSmN7CHpTacelNpokKRqWkamSJTWp1NagBKKKDQAymnrTqaetWJhTKcabTQMKa3WnU09apEjWpKVqSqAaetJSnrSUCYHpTKcelNoJGnrRQetFWDGHrRQetFNC6BTT1p1NNUDEpGpaRqEISiiiqYDW60lK3WkoQBRRRQA1utJSt1pKACiiigTCiiigkKKKKACkbpS0jdKaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAVaWkWlqWAUUUUgCiiigAooooKQUo60lKOtAx1FFFABQOtFA60APooopIBV60tNHWnUmAU8dKZTh0oGhaKKKlgh9FIOlLSBDh0py0xelOXrUsY6gdaKKRSH0DrRQOtAx4606mU+pYBTh0ptKtJlDqdTaUdKkOo8dKWkWlqWMUdadTKfSAB1p1Np1ABTlptKOtDKQ6gdaKKkaH0Ug5paQCj0pcAdKaOKdUj6hRgUUUDCnDpTactJgLRRRQgClBxSUUwHMNwwRkHrX1Lq7L4o/Y/wDGYk/eSaL4vg1u27ssN6kLrx2/4+5Pyr5ZHIxX1D+zhjxp4H+Ifw6GXvPEng0XVspGUN1YvLFGB/tbWtM/QV4mdr2dGFf+ScX8uZX/APJbnbgfenKn/Mmvw0/Gx8tRzFSq7AUZ9wQjhsdM+o/xODzWlaQy6te2ulJNiS9uVaaZhn52ONzd8KCSc8gl+1ZzLvUBeN3BPX5f/r1r+HrWWWa4NsgeZofsturNgNLMREFJ/wBx3Yf7le1JpK5xIn8RmTUZLOCwtWUzublYWI3QrI4SGLjjaI0gx7OazporW1t7iW1z5VxHtCsOQxlLofb5Ix+YrSmmgbVL3VbW4PlQTLHZsQQBDFG5iz648q35/wBoetZGprIb2eNuDGqW7AcbmjGzd/47+tTHpEH3Pf7bSfFXkxRxaJqAjVFVANI8S424AHAucdPTisH9jnwhL4t+PXh+3+wvcQ6a/wDaE5VGPkrEVZX3I6yRESeXtkXOHKBlKMwqzLoGl28T+b4JdtqnO7wvbnGBz/zEv1rp/wBmrxKvwQ+CHxD+NsluI9W1EQeGvDcrrC4kvGDs5Q/6xWiXErL8qsu37xxjwa85xwlVUneUrRXrLT8L3+R3UYxdaLnstX6LU5/9tb4jp8Q/jvq8NjcrNpvhhF0O1ZWOxmiJM7AdBmZ5RkdQF9q+v/2NbFYvBFveeQII5tPtZLWNGNtC8bD95LFZn5wrSIVN3MTJO6Pt2xRoD+ZbNI5aSV2eRyWZmOSSepJPWv0P/YqexuvB+karN4hiibyzY22l2plxcXEcW2Sa5mfm6mSFEVIl/dW0LRjG+TNebxJhY4TKI0Ke0bLbt6d7avbfyOzLKrrY11Jbs+ydLfGK8H/bW/Z6f4zeCrXXNDtNMTV9CcS3Ur6Wbi7ubFQ+Y45IyJsR+ZJMsKBvMcKMZxXuGmvtwas+I9M1DV9HI024ukurVxdwQQ37WaXcseWSGaVVZliZ9u7aOQMEMMqfisoxU8NVjVpuzR7uNoxqwcZLRn47+Pbm98Ha5d6RZR3dvBBcPdzxa/aRNNdtJCbi3fUUid1a4L+aVt5kIjPyvuBevp/4F/tNeHYvD2rWP9n29hate215e6rq19LJIApUyX+p3yMDNK4VY4bCGPJKBPucnif2lfg74rbxPeW3hn4f6U/ibXJ2a4tILu4uL+aUzPPcXunWO+T7LZFhtM0+15DlkWNXK18hfLsSNJw6kbio3fKemDkDnAHTIxj8P0xYfD5vhlffT/h9H3Wnp6o+T9pUwlV2P1l0r9qTwksIv8XVnZmWW8nGp3K+ZY6UXDDUr1sE23mZZLezAaWXdDtUBgV9J0z4taDq+q29k9zcWMw0+K+ubG5jUTWqzxCSFbpfvQzsFkCW4LSOFdtu1c1+Men6/relXNtcWWq3SG2vEv0XzCVW4XpMFOQJAM4bGQa6/wAM/Hj4q+D7qK+0LxKEu7cXb29zJBHLJDcXWPtF2C6nNy6jYZ23SBPlDBQAPJxHCkGm6Mtdd/6f9emvbTzeafvo/Y6/ktbuEhgki/I5R15QkBl3KeVOCCMgEcGvlT9pT9lH4R6d8HvGHj/wb4Qg0vxHpm3Xku0ubgg+U6tMm3zMKpj3ngA7gDnNfI2l/tf/ABz0qGC0tvE2y1ttOOmRooO9Qzo0tzvYkvcvsx50m9l3NtK9vZtY/bhm+JnwO8Q/Du88OeZ4z8QpLpVtb2oK2xtpt5kclvuiOEBBlnd3JY7RXm0shzPLMRCrQlePMr2dtL/aWmnc655jhMXScKis7O11+R5bb2vie+s7bU7TRdTaK5iSeN4dM8RPGysoYFX+1YYc8EE5HOal/s/xdg48PawxPJYaV4j/APkqsqz8LaZbWsNsfCl1OYo0jMk3hi2LuQoG5j/aQyTjJPel/wCEc0wkj/hC2POcjw1B/wDLKvp3a+kjxVe2xoHTPFZO5tB1kccH+yvEP/yVTTpXin/oXtXwOn/Eq8Q//JNVP+Ee0zHHgt8f9ixB/wDLKoJPD2mMpx4LfrjP/CNQf/LGldfzfgCR6L+zPa3SftCTaxrdnLBH4W8NXeot50V5GYy2FyVu5HcZWUkYIUgZx1J+a/Fl7Pe39q1w26QWcUztn7zXGblj/wB9TtX0D8GYE0D4QfHDx3YWRgW9gh8L2ESW4gcTzHyWUIHkCndNCxAduec186eI54J9ev3tHD26TtFbkdPJQ7Y//HAo/Cnl8XPG1p9EoR+aXM//AEs1rvlw9OPe7+92/wDbTOJ7UlFFe6cIUUUUmAGmU49KbQgDAooopgFIcDgUtNPWgW7CiiiqQhp60lFFMGI1NpT1pKpCCkbrS009aCQprdadTDQAUh6UtI1NANptOPSm1QhD0ptObpTapB1CmnrTqaaaJGt1pKD1oqgGnrSUHrRQJiNTac1NPSmSNoooqgYw9aKKKaB7BTKeelMqhMKRqWkbrQhCUUUU2A09aSlPWkpoAooooAaetJSnrSUAFFFFAmFFFFBIUUUUAFI3SlpG6U0AlFFFUAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAq0tItLUsAooopAFFFFABRRRQUgooooGPopFpaACgdaKB1oAfRRRSQAOtOptOoYBTl6U2nLSGhaKKKlghy9KWmrTqQdRV6U5etNWnDrUsY6iiikUhw6UtItLQMdTh0po6U5aTAWlXrSUo61LGOpVpKVetSNjh1p1NHWnVLGFOHSm05aQC04dKbSrQAtFFFA0PopB0pakoVT2p1NHWnUAwpw6U2lX0qGPoLRRRQCClHWkooGPopAe1LU7AFFFFUADivcP2UPGI8J/FDw5eSyusC6r9hnVRkNDfx+QWf/AGUmS15/2q8Pra8IXLxaytjHKYjqUbWauGK7ZWIMLbhyoWZYnJ9Frkx2HjisPOjLaSa+9WNaFR0qsZrozoPjj4L/AOFefF7xX4RSMRwWepSPaqBgC2l/eQj/AL9un41zGl3f2SPegbzEZ5+BlgyoVgdR6iSQ/lX0F+1vbxeO/DXw9/aB02NdnibS103Vdn3Yr+HdlT3zkTJ9LevmRJbiKZZY3w8bEqT0A3DAPtwTWOV1pYvBwlU+K1pf4o6S/FF4uCo1pKO269HqvwOi1S6htFEGY7m3VyjdDujDrGD9cWin/gdZ+mRm71a0immQGe4QPJK8aLywySZSIx/wMhfXiqAY3DlnjCCPaigdOAM49sjP410vgRIv+ElhuZxblLWN5is19bWgJxtAD3CSRk5YHaUOQDjGMjtl+7gzBe8z0Gd9NWK4I1jQciNyMWPhU/wn0fI/4Dz6c4rN+JutxxfCz4U+CNPiSK1ttIvtbuygC+feXOoXEZZ8feZYraFQTyBwOK3ZdZsHwrWunlMYYDxFoWcd8f6F1rj49GTxlp1n4StdS0y38Q+HjJa2MU19GIdStJJWmWKO5JERmSWWYgEr5gkCrhkCP5tOzalJJcrvpbs109TaTsml1/zTOEr66/ZL8a3Wk+DkJ1KGFdImlzGL1vMNv5qy7ruXB+waessufJjBmvJ2CKGC7R8qa34f17wzctZ+I9Ev9LnXrHeW7wt+TAGvpP8AZTtZP+EQe8vLu4hgj1ie4slhuIRcO8dvH5klrGQFidEb59QuWMdqjnygJHZhlnahUwTctVdf1/W261RtgHKNdWP0e0i48yOKQhxvVWw6FGGRnlW5U+x5HQ8119nIDGFI4NeZ+ANUt9V8MaVf2Sxi3ltk8ryzK0ZQDAKNMBI6EDKyMAXGG6MK9AsJiVANfkuGbpVXB9GfZVffgpHiH7S/w0GtWDw6Tc/2bZ687f2na2du8j6pcgEgvbWypNfuEXhZ7iO2jVN0gYZA/O/42eCdCstJTxD4XgVrW1uvImvUliliuCcJ5YuUMdvPLHtQeRYxvFDH1lkPzD9Lv2krHWtd8KppNjoUt9pyf6TfvI09xbSDIVIG061In1JyxBW3LJATgysVG2vzy+OGuTSaPqtzcyvLcIq6XPcs9vc3UZV/ltpZ4gLOxRQwYWFirMqhlmf5c1+g5BWnLlSfXb/P/g7adz5fMIRjJ6f1/X6nz1RSBiwBcKCFVflQKMAAdAOvHJ6k5JySTS19kzyDQ8Paba6trENlfXK29s4dpXNzBAQApIw07omc44LdM4yeK9Ms7PSLK3itoNa0ZkiXaDNF4XlfHuzyFmPuSTXm/hjV49D1qHUJ7ZriJVdHjQwhjuUgYM0ciDkjkoeM9Oo9RGvW6kf6Hp4wf+hi0P8A+Qq48S5ppJK3nb9TWmkR40s8NrGhcc8WnhX/AOLpyppcmTHqejsOmRZeFj/7NVbU/Flpp1o97Np9tJGhUbLfWdHnkOTjhEscn39BXM+Eb7wt4y+INnbfEiO+TRrkSQK2mXthpksC/MyO8s0QgYL3yELdARwKyhCUouTSsvJMptJ2udZKumqMf2roatnkG08Lf/F1VvbjTrSznuhqmjOYY2dVj07w1KSQOAERizc9lBPsao63fRfD/wAZal4G02c6zpFrd+Xo1/PbW2n/AGq1diYp2a6t3O11ZGDMQuDkEqQRLo0d58T/ABjpPwusNONvNrGqQ2stwkllMiwrJ+8kRobaPIULv3B8YUjBzTs4r2jS5bXvZLTfYE7vlW/6nrPiTd8Nf2Wvh94baTy77xHd3HjK7KrtVkiTdbB8dAzyWIx3IPHp8rDGOOnavob9r/xja6r48v8ARdJKLp2iRweGLJI2yqxWwEtyuOgImkhTI/59yO1fPNZZJCX1b28171RuT/7ed19ysvka45r2vs47RSX3aP73qFFFFeucYUUUhOKl6gI1JRRVAFFFFAMKbSt0pKBIKRjS01utWJCUUUHpQDGUUUVQmBptOPSm0EiHpTacelNoAKa3WnU09aaAa3SkpWpKoXUa1JSt1pKpCA9KZTj0ppqkIaaKKQ9KYDaKKKBMRqaelK3WmnpTRIlIelLSN0qhMbRRRTQMQ9KbTm6U2qBhSN1paaetNCCiiihgNPWkpT1pKaAKKKQ9KAEPWkoooAKKKKBMKKKKCQooooAKRulLSN0poBKKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBVpaaDzTqlgFFFFIAooooAKKKKBoKKKKChR1p1NHWnUAFFFFAD6KQdKWkgCnDpTaVelDAWlXrSUo60gQ6iiikx9RV606mjrTqkOoq9aWm06pYx9FA6UUhoVadTR1p1BQq9KctNHWnDrSYDqKKKQx1KOKQdKWoG9h1OHSmjpTlpMBaUdaSipGPoHWiigB1FA5ooGhQeadTKfSYwpwOabSg9qRW6HUdKKKTEhwOaKRaWpHsBIAyTgClIKkqwIIOCD1Br0f9nP4cSfFb42eFPBvlb7We+W5v/lyBaQgyy59MojKPdhXR/tk/D1vhz+0T4qsY7dYbLW5xr1kq9PLusu4A7BZfNQD0SuV4yksUsJf3nHm+V7GyoydL23S9jxUcGnUylB7V0tGQ6iiihAFIc9R1HIpaKYH1p8H2X41/CDxn8GJiH1DUbX/hKfD+9j8uoIwW5hBIIQNOFIUEkR3jHAr5LnikUSQyIyyrlGVlwVPQgjqK9E+CXj/UfAfi+w1jTg0l1pVydRtIgeZ127bq2HB/10G4DuXjiA612n7XPw807QPGll8UfCO2fwp8RIP7Xs5o1IRLlgGmQ/3SxdZAP+mhX+A14mG/2HHzoP4anvR/xJe8vmrP1Ujuq/7Rh1U6x0fp0fyen3HhACxrgcACvU/A0Wj+H9IEzeMZdPvrzbJcLaazfWRAH3Y5EjsnBZSW53sPmOKwPh14J1PxDdf2yNLlnsrN/k8zT7+eCeTH3d9mhdSuQ33l5x1Ga9bl/wCE8lwPsl/gnGdvisg89eWrrxVaN/Zv5nPTg/iMP/hIbGQ5HxM1Zfr4r1IY/PT6z9XHhHXIo4Nc8ZzakiP5iC78SX8yq+CNwDadwcE10z2PjdS2bW9A9fI8UjP5msvX9d1rwvbRTa1qEVmZlYwJdS+JbczFRyqmR1B6ge2RmuWHI5Lkvf1/4Bo721sczLc+H9EtpLfR/iHfW0EalltLPxBdqCcZCgHTwMnjGcdeter/AAL0DUNN8M2djrmm20sl7qEdzdWcNr9okvbk/vYEukZh9tuQgDxWRZYIRm5uiqrtfgPh/wCN/gr4o0HxN4N+NujX+n33iC9jvNO8YWge/uNKEaEJbtHKzSPByQdrF23YPKoyet+FdC8ZaTZW9h4HTwb8T9HgtRZQy+HNXhFzFbFoz5c2mzFJmDYeWSEBftEpTz5JI1EdYZhNqm6LVndaytZ6bqW2/Ru91f11w6Skp3v6fqt/0PtzwLr9x4k8PWuuXD2TPeGSRfscrTQhN5ChZWAE2MYMqAI5BKfLgnu9PnGBk18w6T+0X4d8B+G5F8W/Df4saNdWyyOw1vw7L5l3IOh81f3Y3YXAAVEGFUBVApkn7f3wCsri0tRquqyST3bwT/8AEumUWkSk/v5MruYMBlUQM3zLu8vnH5wspx0qspUqMnG72V/yPqfruHUEp1Fc9a/aVv2X4d/2Sk0Stq10tqYi13JJdDaWMMdra4kuywBzEZIosAtK4jDA/mX460zRbvWINa1nx3PfaRY3H2CaGCK3uLfTI2gdo7eGO2lghkd2jYtFajyIg6gzSFiT9e+If+CiXwS1LQLqzn8Ka5qkV3a3SS6fPboFmUP5ccEm7K4lXLtjcqpxmRiUHwN8RfGP/CeeNNR8WtA9sNQdWW3JAjtwAAsMagALGihUUeig8Z2j7nhzCYugpRrQcPN21fkv19N9T53M6tGpJOnLmMvU2sS1mLC0gthFb26zyRStLvlILO5STGW5AIHyDbjvmqQ6DNaVr4Y8TXts15ZeGtVuLdRkyxWcjoB65UGs6RWhma3lG2RfvDIOD6H0PtX1iaei6Hk+YVp6b4r8UaLbCy0jxPq1hbAlhDbX0sUYJ6kKrADNQ6Npcur3pgWK8NvDG011LbW/nNBEoyXKllGOgyzKORkim6fDG811cIwMNrBLKplgZg3ykKGAyFJJHJOAcc+qajLRjWmo3UtU1bW7tbzWNSvNRuQgiWS6neZwoPCgsSccnj3Nejfs0eIV8IfHDw9qtxcC1eCcxbJ702cUzNhfJmkMbgI2TkMAMgc5wD5hGiyukTh9rsFOxNzYJ7LkZPtkV9W+EPDniTQPDqXml2vxxuJoVBiutQsrHSrJRjjyxdPNhfdW/CuLH1IQoulL7Sa7GtGLc+ZdNT66/aI+CfwX+Jfhi38a/GKWHQm0iLzJdVg1AQqobaWjMpTE27ZGoJRn2qAgGa+Mv2YtC8PeAE+IX7QCTtqmj+D7eXTdAlltvJN7fTYVcR5ZlYh40xknFyPTFcT8U/EPibxlJY+HNQub3xJ4g1a8Fpax6l4x/t66t3ZlVREtuEtYdx+Xa25xk8L96vQvj5qOn/CLwB4Z+BXhy9WRvCkMep6zPC3FxrVwrGEdcgIDNOAwI2i3BxxXzlHBVsPh44CVVy9q7W6Rgvitq3rflv3lsepKvCrUeJULcnXq5Pbttv8AI+cvGWo3Ooa5Il1dtdS2mYpp2bcZrgszzybv4g0zysDx8pX0rDpFG0ADt6UtfZRiopRR4zd3cKKKKbEFNJyaUntTaEAUA55H1ra8FeFNR8d+MdD8F6QubzXNQgsITgna0jhdxx2Gcn2Br3b9u74TWHwx+LWn3OgWgg0XW9GtRaqowqyWsa2zqB/uxwufeWuWpjaVPEwwsvimm18rf8H7maxozlTlVWyt+J830UUjdK6zFiE5ooopoTEptKx7UlUGyCmse1Opp600ISiiimJiN1pKKKBDW60lB60UAB4plOPSm1SAaTk0UUh6UxIbRRRVi6CNTT0pT1prelNCEpGpaa1MBKKKKCWNprUtNPWmhBTWp1NbrVC6iUUUVSB7iNTaVutJTEwptOPSm00AUUUlDAaetFFFMAprdadTW60AJRRRQAUUUUEsKKKKBBRRRQAUjdKWkY9qaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKcDmm0oPakwFoooqQCiiigAooooGgooooKFHWnU0dadQAUUUUAKtOpo606l1AKVaSlWmwFoooqQH0Ug6UtJjCnU2nDpUgxadTaUGkxj1paaOtOqRhT6ZTh0oKFHWnU2nA5FDAfRSLS1I0KtOplPqWNCqe1OBwaYOtOpAh9FA5oqBjlpaaOtOoAVT2paaDinUAFOB7U2loKHUUUVI0OHNLTQe1OoB6HTeAPhr41+KOrTaH4E0iLU9Qhi842pvreCV07lFmkQyY77c4GCcZFehR/sc/tLSY8v4XXDfTVLH/wCPV47ZX19pl5BqOmXtxZ3ds4lhuLeVo5InByGVlIKkHoQc19xfs2/tw2Opy23g743XcFjdnbHbeISAkE56YugOI26fvR8p53BcFj4Gd4rM8FD22BpxqRW6d+b1Vnr6b+p6GBo4XES5MRJxfR6W/wCAd3/wT6/Zh8efDLxN4k8bfE3wwdI1Ca1i03TIpJ4pWMTNvnfMbMACUiUc5+9Wv/wUK/Zp8c/FiXwn4n+GXhxtX1bTRcWF9Ak8MTG2YiSN90rKMK/mjGc/vBX1r4WlixHJHIrqwBBUggg9wR1q/wCIHjlevhY51WlU/tV29ona2trWtbe9uu+570sDBR+qJ+7367n43t+xZ+0+n3vhRcj/ALith/8AH64P4i/CP4hfCW7tdP8AiHoMekXV4hlht21C1nlKZxuKRSOyqecFgAcHBODX3N+0/wDtv6H4DkvfA3whuLXWPEsZaG61TAls9ObowT+GaYfiinrvIKj89tb1vWfE2sXfiDxDqlzqOp38pmubu5kLySue5Y8noB9AB2r7fJcZmePh7fGU4wg9lrzPz1ei/F/ieFjqGGw8uSjJyfXa3/BKgPalplOBzXvNHALRRRQmA+C4ntLiK7tJWingdZYpEOGR1OQQexBr60+DF7oHxy+Feo/s+eIJLe1bUhNqvhC4kCqun6lFue4tFA5VFLtKoGT5E8ozuTA+SK6HwN4ru/CetQ3VtqM1gpminS7hTdJZ3ERJhuUHcoxOVwdyNIvG7I4cxwjxdL3HacXeL7Nbf8HurrqdGGrexnqrp6NeX9f5npPhzw98NNBtJNE+I/iXQfDHiXTJ5bHUdMvNE1m4mjkibZvaS2nETFsZ+UD6YwTrHSvg5ej7J4U8WaP4l1iX5LPSNL8L6+91dynpHGr3Sgsfc/nXpPxO028+LHg8ftKfCuz060+IHhaAWfi3Tls4boPEIsreQLKjqw8rDxyjloT8r5hOfCtf+J1t4Ot7nQvhbq8smrapGf8AhI/GKK0V3qEj8yW1qWAe3tQeDgK8xGXwm2JfMw0qmNXPGclK9nG6tFrdP3b8trcru3JNebW9WEaD5Wk10dt19+/fTRj/AB7p+rfDpba28UeCPBUOpXZmjfToNZubi9sCu3BuI4rthCx3ZCP83ynK8YPmFxFfCzt9QvndopyyQNKxLOF+8V/2ckDPc5AyQ2K8ceXSNUZtzBQq8k+wru7rwrdanq1gWeBI7K3L3Jdt9vaxxH/VDJwVUqyF8/M6XDnKrvb2oR9ikpu776/q3Y4pPmeiORh0rULiGS4S3YJGExu4LlxuGPbZl8nA2jOeRldF0S61xpBaoVSNQMsOHlfiOIZIBZj+Shm+6rEdTIv/AAjumXWr6zcSXN1dSNKgkXas3mgMke3PDOvlyzYyRH5Me4eaQOg8Krax+HjcWNxuub0SiOYkI8Ctlbq7Lt0d/wDUxngIodz0mIc6rjG6Eld6nJ6T8Rfiv4TiWHw/8RPFGmwnf5Y07V7mBGVCQWARl+XhucAfK2ehx1Fl+0j+0fbzpZR/FXxTLKc7Y7y6ec8Egk+aTwCCDnpg5xg1JHp9pPd+YtsfKh8uGKNFwwIKeUihuAx/dths4P2dX4iuajg0TTzJLqTrHteFMypASvkkLtWMP8zK4MeF4ZozAhO+7bGElh5u8qab9EWpTWibJ1/ac/aMuxHGvji8mM2AoNhbMxyyqOsefvOo+px1qC4+OX7RF3lZPiLrVpGyFzJbzi0Aj2by/wC72tt2ENwM4ZMD5l3Ub6Wz066gt7vyWmvg7NDNOzxogVlfc6DlcmRCy8sDdyLnzYSK2oeKILuF00rfd3144S3Uxqshkchi7qnQ7v3hAOBIY1Hy2qhl9XoNpqlH7kHtJ/zP7zDuNa+IPxHvodO1DW/EHiO7flI57qa8dQOrfMWOB1J/GtTxxb6VoWl22g2cNut0pBuCLa3EgcYzukFxPKCf7p8oYP3e1WLLQrPwhpBu9dsvBd1fByVN3rLXjr2CLDYyELz183Iz2Fcksd74l1ZdmnbpJyN8Wn2iAoncqibQdoPUkdOT3raNpS93SK+4l3S13ZcmtX0nw1Hcz2ksVxqz/uzc2CENAvO+GRn3DJK/MsYyDgP1FaWiWotfA2rXi58y+BiBg8WWVsTGvVZdPbM8w3DI6A9getZfibbda42naZCsywMLW3jisooHdwcFSImfe28kBi7k8c9q9U8TeF7vSfAK6Xb2d/cLHCFLS/DCK3ucAdWvH+c+77t3epqVVDlT3k/P9PlvoVGLle3Q8WhlEU0UhXcEdWI3Fc4PqOR+Fe5Ta14NsNDvNSsrbwJLMrM0suneGtU1iRTnjfNqbiLPQcfL6cV4Mf3kXGDuH4Gvb/AHhfxF+0Z4o03wDp2o+Ln0yxKXWs6hqeq/aLa2tQBzFBsVIWJ4RNz5JXkKGIjHKEIe1qStGN23fSy7rqVRvKXJFXb2Oz/Zo0KPQLHW/wBqXx9p0M0GkKbDw1Y29mlv/aGoOPLAihiUKOWEY2Ljc7t1iNeEfEbxPqPijxLdXep36Xtw1zNc3dxG26Oe8lIMzof+eYIWNAOPLijwBzXsv7RvxZ0O8g0vwd8PTFB4V8NQNYeHI7eUlZSA0c+oE/xfxRQsckkzy5ViufnEDAxXLltKdacsdWVnLRL+WK2Xr1fm7dEb4mahFUIO6W77vq/0Xlr1Fooor12ziCkJoJxSdaSQG14N8GeJPiD4ht/CnhKxivdVuwxt7eS8gtjMR/ChmdFZz2QEscHAODXp4/Yx/acPT4VXR/7iVj/8erxZHeN1kjdkdCGVlOCCOhBr7T/Zh/blfTXsvAXxxvpJrbKwWXiR8vJEOipd93XoPN5Yfx7hll8nOK+Y4Wn7bAQjO26ad/VWav6b9rnZg6eGqz5MRJxvs9LfM1/2KP2R/ih4O+MaeO/in4Ok0e10SylfTfNuYJTLdyDywQInbAWNpDzjnbivbv27vgXrnxa+Glmvg7Sft3iLQ9RS5tIFeONpopB5cyBpCqgY8t+SP9V+FfRfhy5s7qOC7s7iKaCZFljlicOkiMMqysOCCCCCOCDTPFzI4xnjFfm2JzvEV60c0lZTg0ktbWW63vrd316n01LAU6cHhF8Mr3Z+P5/ZB/aQQ4f4YzD/ALilj/8AHq5L4g/Bf4l/C21tbzx94cTSEvXKW6yahaySS46lY45GcqOhYDAJAJBIr7m/aO/a28I/Cea68LeD/s+v+LVDI8YO6009+n79gfncH/lkpyMfMV6H8+/F3jDxP491+58UeMNZuNT1K6PzzTHoB0RVGAijPCqAB2Ar7zIcfm2ZpV8VTjCn00lzP0u9F5vfoup4OYYbB4N+zozcpfKy/wCCY9FFNJ7V9QeTuJRRRQDEJ7U2lJyaSqQgpGNLTScmgkKQ9KWmnrQAlFFFADSeaax7UtNPWrEwprelOpp600DEoopD0qhMbTT1px4ptUhBTD1px4ptABSHpS01utBIlNNOJwKbVIQUynGm0xIKKKDVIOo09aSiimIRulJStSU0AUjdKWmt1o6gJRRRTAKa3WnU1utACUUUUAFFFFBLCiiigQUUUUAFNpWPakqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgdaKKAHUUUVABRRRQAUUUUAgooooLFHWnUynjmgAooooAB1p9Mp9JgFA60UUwHUUDpRUgOWlpo606gfQKVT2pKB1qB7j6VetJQOKAQ+nUynL0qAFpV60lA4oKQ+lWkoHFAx4606mU8dKlgFOBptKDzSZQ6nA8U2lBqQ6jlp1NHFOqWMKcOlNpQeaQDqVelJQDigB1FFFA0KD2p1Mp4OaTQwpwORTaAcUitx9dl8G/BP8Awsb4peGfBroGt9Q1CP7VnoLZPnmP/ftX/GuMBzXs/wCzb8SfBXwavPEPxI8RwSalrUNkNO0LSovlM8spzJK74IjRVQKW5Y+aQoOCRxZjOtTwtR4dXna0V5vRfc9X5G2GjCVaKqu0b6+nU/VO9+JPg34aeGJ/FnjXW7TRtIsl+aWY4GcfLHGo+Z3IGFRQSccCmeDvjN4E+MvhhfFvw68RQ6lZghZVA2T2suM+XNGfmjb0zwRypI5r8fvit8YfHnxm17+3fG+qmVYcraWMOUtLNCfuxR5IGe7HLNgbicCqHw7+JXjX4VeI4fFPgXW59OvY/llVTuhuY88xyxn5ZEPoR6EYIBHw1Pgmp9QdOVX97v8A3fTv8/wPelnkfrPPGPufj6/8A639p3wOPh/8dfFmiwQeVZ3V4dSswAAvk3AEoC+ylyn/AACvLq9m/aG+MHh747WvhnxwmmrpPimxgk0rWLJdzRyxhjJDNC56pl5gVY7lO0ZYfNXjNfaZY6/1OmsSrTSs/VaX+dr/ADPExfs/bydJ3i3dfPX8NgooorvOcUH1p1MpQcUmgHUdaKKVwPXfgH8bfEvww8V2F7ptwjvAPswt55NkN/aFtzWcrH7h3EvDL/yzk4bKOxTtv2jPgP4futF/4X/8DYHuPB+ps0mr6WkW2XRLnOJAY+scYc4ZP+WTHA+RozXzYRng17l8AP2idf8AhrrRhneK8tL9Rb6hZXcgW31OELtCyM2VjnCkqsrDaynZJleR5WMw1WjU+uYP4vtR2Ul29V0fTro9OujVhOPsa23R9n/l3X6niNpcm0vLe8TcTDIr/K+xiAecMMlT6MOQcHtW/ZeM7yS4uFvorJbe6mjkliEJ8p1QKscbDn91Gqr8gySqBRjcxPvnxf8A2aNC8b6Lc/GP9mffqGiu7/2v4XEbLf6RcrzLGkJy429TCcsvVDIhBX5iKmeOWS3R3RNs0hEQXYCQpJIzgB2VR2+bsTiu3C4mjjoc8N1o090+zXR/8OjCrSnQlyy/4D9DT1XWIdd1lGvbi5j06Jm2h2DzMpJd2J/ilkYsxJ43N/CgG3bi8b28cEUSKkKuoLRJEJUjjXiOM54cKOSCcN0Y/vriuRvRALm5ELov7390iEsgU7jgM2CcYUDjkZOeOSd0DSrGkW2VkmXZuPlggnywW543bTnPKDk9Tu6cWkmZ31O0XxzaSpGk42icNlXdnEYLEP5jD5nL7m34wzJ5wHzXLlXf8J7przQpK16bVpTJKVUfackszSbmIAlIZ8MOkkruMCOEDi5FQuYYrfHmiJ0PmCVuUzgFcDksMjGQRjgggwkx8lBgFQMseQ3GT+eR9DU/V4BzM0/E+vP4n1u41iWyhs0fZFb20AGy3hRQkca57KiqOnbOOa7f4b+GPD8X/E0vNe0nUL9oQ0OlRaFearPCSOCyKEtycdmdwO4BFcFokWqNqML6HprXlzC29IRaLcKTz1iZWVh7EEcV2HifxT8abqyltvGPibxHZWax8WN7dS2sTADhY7YkAjoPkXAzzgDIirFtKlB2Xrr91mXF295lPxx4l1ORjoheW1jBZpoBo1rpGQSfle3tx/6Gxz6d6qaRp+l6Vokmv6jf+HLi5kXNpp1ybmW4yDjIEP7peCTiV+g4U0zwL4VvfE2qD7LZapNFZ4mIsNJbUHdgQQnlZVCDzneyrgGr3xF1u7uL5PDSahfNY6aR/ozy2q23nY5dLe0HkwthipAZ2BBBbOQBcqapQ+fT9OoO/wATK3wz06K+8V2s1y1p5dn++K3PiO30Ukj7u24mPBBx90Fvp1r17x/LaXvh2aCW60RLZVyFu/iidaVf923t23sfoDXn3wkGgWF1Pq+peLfCFncsDAllrvh651b5eCXEawSRc9ASSevAzz6zpR+InxS8RW3gT4IXfgm+l2H+1NR0j4f2ejwadETtDS3DW4mU53Y2AMSMLubiuDGSkq3Psord8yS67/Cb0leNlu+is/w3PAfAHgDxR8T/ABRZ+CfB1gb7ULw43E4ihjH3ppHI+SNRyWI/AkgH6f8Aib4o8Mfs+eAbv4J+B9QbUbqdj/wmevK2yfULxl+axibJKkhsSHJ8mIlTullIOjrfiz4efsxeC9S+Hvwt1n7d4jmcweKPGACmc3QwWtbXkgzLu+7kpACGctKQB8h69r114gvBcToIYIQUtrdWLLCmSTyeWYklmY8sxJPWuePPnNVVJq1CLuk9HJ9JPyW8V/28+iNm44KDitaj3fZdl5938l1KuoX9zql9Lf3ZTzJcDai7URVAVUVRwqqoVQBwAABwKr0UV7u2iPPCkJ7CkJ9KSmkAUUUUwCtnwZ4XvfG/i/RfB2nBvtGs30NkjAZ2b3Cl/ooOT7A1jV6t+zb478E/Cvx7cfEzxrBPenQdPmOk6dbj97eX8o8tBuI2oio8rM7dNq4DMQK58XUqUqE50Y3kk7Lu+n4mlKMZVIqbsr6+nU/VSHxf4R+GHhL+1PEWr2mieH9FtooPPuG2RxRIoSNAByzEABUUFieADWJ4L/aA+G/xt0WbWPAHiBLwWxK3VpMvlXVtyQpkiJyFbHDDKnpnIIH5Z/Gj48ePvjnrp1PxbfCHT4GJ0/SLYlbSzU8fKv8AE5HV2yx9cYA4/wALeK/EvgjXLfxJ4R1q60rU7VsxXFu+CB3Ug8Mp6FWBBHBBHFfBUeBpzwTjXq/vnr/dXk+r83+D6/QTz6KrqVOHuL7/AOvI9h/bT8Gr4X+Oeo6tbQ7LTxPBHqyYXC+a2UmA9T5kbsf98V4TXt/xm+OmlfHX4faNLr+mppnjPw3dFWMKn7Nf2sygSNH18t1eOMlG4wzFT1UeH9K+zyWOIp4GnSxStOC5X520Tv1urM8XHunPESnRd4vVfPp94E4FNpSc0leqcmwUjHtS9Kb1pokSiiimJgelNoJzRQIQ8U2lY9qSgApGpaaTmmgEPSm0rHtSVQuohOBTaVj2pKpAFNanUymSI3SkoPWiqAa1JQTk0UAwpp60p6U2ggRqSgnNFWgYjHtTaU9aSgEFIelLTWqxdBKKKKBDT1oooqgCmnrTqYetJAFFFFMApp606mUAFFFFABRRRQSwooooEFFFFACN1pKDyaKsAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAFWlpF60tSwCiiikAUUUUAFFFFBYUqntSUo60AOooooAKcOlNpV60MB1FFFCAUdKWkHWlqWAU+mU4dKBoWiiipYIcDmlpq06kCHDpSg00HmlqWMfRRRSGhw6UtNHWnUFDgc0qntTQead0pMB1FFFIa7Dh0paaDzTqhj3Q4HNOU9qYvWloBD6KKKgY4HNLTAcU+gBQe1LTacDmgApQcUlFBSH0U0HtTqkYoOKWm0oNA9x1FFFJoSYoOaWm0ob1qR+gtFFFAJhRRRQMKcG9abmigB9BGRimUu40rAelfCj43+L/hdrMGpaNq8lpLGqRGfZ5qSwr92C5iyBPEOg5V4+DGw27T9B6x4Y+A/wC1n5d/Y3Nr8OPiVe7hG52yabrb8bihAAdzuGeEuFLfPHKRmvjPIq5p2q3ulmVbZo2huABPbzRiSGYDoHRgQcZOD1UnIIPNebicvVSp7ehJwqd118mtmvJ/Kz1OmliXGPs5rmj2f6dn/Tudj8U/gt8Tvg/qA0/xt4eu7SF8W41GJzLYXQU4XZIi46KpKN84xkqCcVwhR44d5t/mgk2usshAw4JUbOGHKuSQcfMOh+99G/DD9sTxp4Wsl8Oa/Ja6/okq+VNpfiDdcwtHg/JHckPKi8gBJlnQAdV7dZqvhX9jL4tp9tjm1b4T6vctgsNs2kvLjosiF7cAHsskI4PyislmVfC+7jaT/wAUE5J+sfiX3SS7lvDU62tCfyej+/Z/h6HyQXEKeX5jLIj5jZY1XMbDklvvHI24B6DPrXcfDL4by+Mi2ombWyttJ+7t9J8Mz6xO7DnJj+SEr7NJk91wefYL/wDYI+It3bjV/hh498H+MdPAEkE0F0I2fHI+Uh4ce3mkV0uq/C3452+mRWnijwD8ZdflgQRizsPGNpHpqKBjbHBbxTBEA6Ku38KKub4atG2Gqxb9VdfJ/qKODqwd6kGl6O33o4rxd4h1vRdOg0vUPFPxOsbdV2mz1XULXwvbxxgdrCIyuy+yrn0rx2PQdb+I3iuPw74M8PJezRhzt0yCVy6jmSd3mbeVyfvSMoAxwmSK9e0z4Q/Gq1nv5/C37PfiTw5eCN/sU8OlS3M5dgQC11dORAQTu3wxq5xgFc7hq/DD9lP49WCFZvgJ4dn1KWQsupeKL9ZI7dCAAEtUmCkg5JMkcnXAAqYYrD4Om5SnFPzcVr5q9vuYeynWklGLfyb/AEucp4pbw34K8Lv4VimSWCzeSWPT9R8WnWwkgP30tdPC2cDGTGVmlc88hjxXh4E11OFijMk88mFjjQAs7HgKqjAyTgAD2FfYmu/s7eH9Khhh/aR/aU8N6NBb/OvhrwzBEhVs4Hl28ca4bnGVtmJz1qMfG34FfAlJIfgZ8MbaDV4sx/8ACQ+KAz3nbJitwTONwzjP2ZCRzkGsqGZRUbYaLqSfVX5f/ApfpzM0nhne9VqKXff7l+tjO+Dn7P3xH0DwfH4v+JXxH8R/CDwbAWmv92vPaz3ofGwR2oVfIZhlcyl3Y42xtmpPif8AtIeHPBXh4/DT4JaNP4W8PBnF0UzFq+qORjzJXJL2yMOS75uHUqAIkOR4l8Qfjv46+IOqDVdX169vbxNwivLkqptwcZFrCmI7UHAOUBkz1kIJrzhmZmLyOWZjksTkk+tXDLZ4mftsc0+vKvh9X1k10b26JMl4qNKPJh/ve/8AwF6fNst6pqt3q86TXPlxxwr5dvbwrsht485CRqOAMkk9ySWYliSalN3Gkr2lG2hxDi3pTaKKqwBRRRQAUUUUCbsFISB25oJxSUB6hRRRVJCbCmk0E9qSmMKKKQntQIQnNJRRVCYUhOKXpTTzQSFITilppOaAEooooAQmm0p5NNaqQmJSUtNY9qaDZCUUUVYhGPamk4pSc01j2poQlIelLTWpgJRRRQJiMe1NNKetNY9qaJEpKWkPSqExtFFFNAwpp6049KZVAwoPSikahCEoooqmAh6U2lakpIAooopgIx7U2lPWkoAKKKKACiiiggKKKKACg9KKRqaASiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAp1NpQe1JgLRRRUgFFFFABRRRQUgpR1pKKBj6KAciigAoHWiigB9FIDkUtJAFOptKOlDAWlXrSUUgH0UUUmPqAOKfTKcDkVIMWnU2lWkxj1paaDinVIBTgc02lBoLHU4dKbSg80APU9qWmU+pAKcDmm0oOKTKHU4HIptAOKkNh6ntTqZTgc1LGLSqe1JRSAfQDikBzS0AOopAaWgApwPam0UFD6KQGlqRig06mUoOKB7jqKKKVhXsKDilptGcVNh7jqRiQMgZpBIO4P5Guh+HvhG9+Ifjzw94F01JTPrupW9iGRclBI4Vn5/uglj7A0pSUIuUtkCu3ZHp/xd+Bb+APgN8JfiWtkUuPFNvdnVJQTgu8hls+PVrck/8BrxGv2E/bA+Edr4q/Ze1/w7o1iqHw7YxanpkSJkoLJc7VHqYBKg+tfjyH45BH4GvHyPHyzChKVT4lJ/c9V+dvkduOw6w00o7NL/ACY6ik3A8YP5Glr2TjClyaSigBc56irFlqF9pspn069uLWQrtLwyFCR6ZB6VWopNJ6Ab2l+M9Z0e9XULPyI7lfuzW4azkB6532xjc8+rGu50z9pf4s6aAIviB4xjx/DFr8siD8LkTH9a8oorCrhKFf8AiwT9UaQrVKfwyaPap/2svjDNH5Z+InjMD/Z1W3U/mtsD+tctrvxz+IXiJHh1nxLrmpwyDBj1DXb6Yf8AfCzLH+GzFefUVlTy7CUXenTSfkrFSxFaatKTfzNRvEmseWYre6WyRhh1soUtt49H8sLvH+9mssYAwBRRXYopbGO4uTSUUUwCiik3D3/KgBa9e/Ze+C4+OXxHuvC1yGFla6Jf3czjI2SGExW5yOhFxLC3uFNeQbh7/ka/SD/gmf8ADKTTvhp4h+JF1AVm8S3ws7Vj3tbUHLD0zLI4P/XIV5Ge42WAwM6tP4novV/5K7OzAUFiMRGEtt36H5yXNrc2N1PY3sDwXFtI0U0TjDRupwVI9QeKjr3H9tP4fj4d/tDeIoIbfyrLXyuu2oUHGJ8mX/yOsw+gFeGeYO2fyNd+ExEcZh4YiO0kn96OavTdGpKm+jsOpCfSm7s0tdFjMKKKKq1hN3Cmk+lBOaSmFu4UUUhOKAAnFNooqkrCCiikJ7UEiE5oopCcUABNNoooAKRj2pScUymkAHim0pNJVC3EPFNpSe1JVIApCaWmnk0yRKbSse1JVAJ0ptKx7UlABSHpS00nJoJEppOaU9KSqQgppPNKeKbTEFFFFUg3YjelNpT1pKYmFNPWnHpTaaAKKKQ8UMBD1pKKKYBRRRQA09aSiigAooooEwooooJCiiigApp604nFNqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKB1ooHWgB1FFFQAUUUUAFFFFA0FFFFBQqntTqbTqACiiigBVPanUwcU+kwCgdaKKYDqKKKkByntS00HBp1A90FKOtJRUMe4+gcUg5paAQ6nA0wGnA4qQHUUUUikOBzS00HFOoGOByKVT2pgOKdSYD6KQHNLSGhwOaWmA4p3WpaGOB7U4HFMpwOaQIfRTQadUsYA4p1NpQcUgHUoPakooAdRSA+tLQAU4H1ptFBQ+img+tOqRhnFOBBptFA9x9T2F/e6Xe2+pabdSW11ayLNDNG2GR1OQQfqKrBvWnUhH3N+zh+2F4P8AEtxaeDfjVo+gadqbARW+unTbaO1um6AXACBYXP8AfAEZ5yE6n7t8MeHfDkdxBeWmgaTDNEQ0csNjCjrkdVZVBHB6g9DX4VsARyK/Wr9hGy8Q6R+z94XPiPVLu7lvRNd2qXEpf7NZs5WCJM9E2IHA6DzMDjAr854oymjlzjjKM3FSlZxu7a3d1221W3a2x9LlWLliU6E4ptK6dlf5/wCZ9U6rBDJpnlyIrKy4IYZBB6givIvF1n8PvCGk3niHxHYeHdL0ywQy3F3c2VukcS9Bk7O5wABkkkAAk4r0281izuIZrWK6ikmtSqzxpIC8TMu5Q4HKkqcjOMjkcV+d/wDwU5h8Qz2fgvVI9UvP7DE91a3FkJSIPtWFeKQoOC5Qyrk9AhAxls+R7GOZ5hSwkZuCl1Xkr/j0OxT+rYeVZxUrf5nkX7S/7Wq/E03ngj4ZaBY6J4SJaKe8FhDFe6muepKrmGI44QHcR9887F+bB0pAaXIr9RweDpYGiqFFaL5t+bfc+TrVp1puc92FFFFdRncKKKKB3Ciiur+FHgK9+KXxN8M/Dyw3CTXdShtXZescRbMsn/AEDt/wE1M5KEXKWy1Gk27I5UgqSrAgjqD2pK+jP2+PhnbfDj9oXUJdKsltdI8R2VtqtlGibUT5fKkQduJInb/gYr5zrPDV44mjGtHaSuVUg6U3B9AooorYi4UUUUCuFev/AAH/AGjdd+DF8mn32iaf4i8LzS77nTry2ieWHP3pLeV1Jjbvt5RucjJ3DyDIpC1Y4jD08VTdKqrxf9fIqnUlTkpx3R+wvwk8U/CX4v8AhuHxV4Is9Cv7RiEnjbTLdJ7WXGTFNHtyjenUMOVLDmvcPDljaWGn/ZbS1gt4UU7Y4Y1jRc8nCqABz6CvyU/YJtvElx+0FYy6Nql5aWFlY3N3q0cMjLHcwBdiRyAcMDLJEcH0yORkfq1aa1b2Nmst5dRQo7JCrSyBA0jnaiAk4LMSAB1J4FfkuaYKOTZj9XjNzi1dX3V76PufYYSs8Zhva8qi7206nMeL9MsLu9aa606zuHUbQ01tHIQM9AWBwK+X/wBov9o74e/Bm3n8P6Jo+ia14yZcJYCzhMNiSMh7kquQcHIiBDHjJQEE/QfxTOq6n4b1vTdB1KfT9Su7C5gs7qBtskFw0bCN1PYhypzX4w3Ml1NdzzXzyvcvIzTNKSZC5OWLE87iSc55zW3CmUU83rTq15vlg17qbV79/LTZb/mZxjJYKnGMIq8uttrfqafizxXr/jjX7vxP4mvhdaheNukZY1jRQOAqIgCooHAVQAPSsmimlvSv1uMVBKMVZI+Md5O7FJAppOaKKoewUUUhPpQICcU2iiqsIKKKQmglu4E9qSiigAphOaUnNJQAUUUhPamAhOaaTilJxTetUJhSE4paYTmmkGwUUUE4qhMRj2pp4opCaaEJSUtNY9qYCUUUUCYhOKbSk5pCcCgkaetFFFWDGt6UlFFAbBSE8UtNJ5qxbISiiigQjUlFFUAUjHtS009aW7ASiiimAUjHtS009aAEooooAKKKKCWFFFFAgooooAaetFB60VaAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAHUUintS1IBRRRSAKKKKACiiigsKcOlNpV60AOooooAKcOlNpQeaGA6iiikgFU9qWmjinUMApw6U2lBwaQIdRRRSY9mKp7U6mU4HNSAoOKdTaVT2pMY8HtS00cU6pAKcDmm0A4oLH0oPakooAeDinUwHNOB7VLQC0oOKSikMfQDimg9qdUj3HU4HsajBxTqAQ+ikBzS1IxQcU6mUoOKQDqUH1pKKAHUUgOKWgApQcUlFBVx4INFMpwb1pWAWjOKKKQ7mx4P8M6j438W6N4O0lC15rV9BZQ4UttaRwu4gdhnJ9ga+3Pjf+2bovwq0dfhR8ArmC9v9MtU05tcTbJa2CRoEVbccrNKAo+cgxqem88r8H29zc2kontLmWCUKyb4nKNtZSrDI7FSQR3BINRjjpXlY7KaGZV6dXE6xhe0ejb6vva2i9bnZh8ZPDU5QpaOXXrbyO+8AfHP4q/DXxvP8QvDXjC+bWL6TfqTXkrXCakM5K3Ksf3oOTyTuGcqQea+o/ib8cPBv7Vn7PHiGyhij0nxl4djj1xtInfO4QE+dLbOf9YnkvMSPvrjkFcMfh/d61JDNLBIJreZ4pFyA6MVYZGDyPaljsnw+Mq08RblqQaakvLo+66eXQMPjauHhKlvGSaa/VeYwdKWiivVscdwyaXcaSilYd0LurovA3gDxf8StZ/4R3wRpK6nqZjMqWguYopJFHXYsjKXI6kLkgc9K5yn29xc2dxFeWdxJBcW8iyxSxMVeN1OVZSOQQQCCOhqZqTi+Tfpf+kC5b6nsS/seftMMMr8JtRb6XNuf/alfUP7AX7KvxG8C/FbUPiD8U/CFxov9l6cbfSUuHjcyzzna8i7WONkQde3+tFYX7Mf7dlrI1r4I+O93HDKSsVn4lKYRuwW8A6H/AKbAY/vjrJX6GeF7i2nEU8DxvHIodHjYMrKRkEEcEEdCK+BzPOczo1HgcZTjFS05lezXWzb+/qrn0GFwOFnFYijNu3R209T5i/4KJfs++K/i94S8Nap8P/Dz6t4g0K/kiMETqjvZzp85yxAO14o+M9Hb3r4Nf9jr9piPiT4T36/W6th/7Ur9nfE0iFD06V8T/tN/tneFPhVPdeEfAkdn4h8WjdHKdwez01un70qf3kgP/LNTgEHeR9w44POcxo1v7PwNNT1b1von3d9EaVsDhqkPrOIm4/qfBPxA+DnxK+FcFpcfEHw1/YwvmK20ct5bvLLjqwjRy+0dC2MZIGcmuL3Vp+KPFXiTxtrt14m8W61darqd426a5uGyx9AAOFUdAqgADgADisuv0Ggqvs17a3N1te3yvdnzs+TmfJe3nuLupMn1oorWxN0FFFFOwrn2L+yJ4w+H/wCz38IfEXxj+Id4Vu/E93/Z+jadDta7vorUZcxKeiGWUK0jYUGLHJwp8L+OX7RfxD+PGspd+Ir02Gj2cpk03RrWRvs9r2Dk8GSXHBkbnrgKDtHmEk80qxJNPJIsCGOJXckRqWLbVB6DczHA7k+tR7q8uhlFCljJ4+a5qkur6K1kl8t3u/TQ654yrOhHDrSK/F+Z9XfAn9tfW9EW18H/ABivrjUtLjCxWutkNLd2oHAE/Vp0HHzf6wY/j4A8U/aB0HT/AA/8XPEB0SeK50jVpxrGm3MLh4Z7a5AlVo2HBUF2T6oR2rzs89ac0kjhA7swjXYgJztXJOB6DJJ+pNLDZPh8Hi5YvDrl51aSWzd7p+T38nfuVVxtSvQVGrryvR9fQaSTRRRXrHFcKM4pC3pTadhCk5pKKKYXCiikJ9KCQJ9KSiigAppNBNJQAUUUhOKAAnFNopCatCEJzRRSE4oDYQntSUUVQgppOaUntTaaVxATim0daKoBCcU2lJzSUAFITilppOaCRKaTmlJpKpCCmse1L0ptMW7CiiimgeoHgUylJpKoTCkJpaaTk0IAoooqmAh4FNpWPakpIAooopgB4plOam0AFFFFABRRRQSwooooEFFFBPFMBpoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAHWnU2nUmAUUUVIBRRRQAUUUUFIKKKKBj6KRfSloAKKKKAHDmlpqntTqWzAKVaSgHFNgOoooqQHA5FLTQcU6ge4UoNJRUMe4+ikBzS0CQ4c0oPamA4p1Sxj6KQHNLSGmKD2p1MpwOaChQcU6m0oPagB4OaWm9KcDmpAKcDmm0UmPzH0oNNBzS1Ix1OBzTAe1LRYB9FIDS1IxQcUvWm0ZxSAfQDikBzS0AOBzRTaUN60ALRRRQO4ucUob1ptFFhj6KbnFKG9aVgFooyKKQ7hk0u40lFAXHZFLTKKAsh9FMyfWlyaAsdH8PPB918QPHmgeCrNXMms6hDasU6pGzje/0VdzH2U1+z9v4w8KfD7wzJrOv6tZaLoekworT3MgiihiUBUX3OAAFAJJwACa/J79mfx94G+E3iXV/ij4wV7280axNvomlQD99dXc+ULhiNsaJEJQznJHmLgMeKwfjN8efiD8cdaGoeLtR8vT7dy1hpFsStpZgjHyr/E5HV2yxz1xgD5HOcpxOdZhTjflpU1q+7e6S66Ja7LXfY9nA4ulgcNJ7zk9uyXf8T9dPB3xv+H3xq8Lt4m+HPiSLUrWNzFOu0x3Fs+SAJYmwyZxlSRhhyCa/Kz9rzwWvgn9oHxPBBAIrTWZV1q2A6bbgb3+mJfNX/gNeeeAviH4z+GHiODxX4G1240vUYPlLRnKTIescqH5ZEPdWBHAPUCvS/j/APGrQvjz4d8NeKruwTSvGOjtJp2p2kas0Fzbv+8jnhY5IVXEoKMSQZVwWGSFgMlr5RmvtqT5qNRNPvF7q/fa1/PWw8RjaeMwfs5q04u67Po/+G8jxWim5NJk+tfXni2H0mRTaKAshd1Jk0UUBdBRRRQFwopC3pSZJp2EKSKQkmkop2AKKKKBXCgnFIT6UlAgJzRRSE4oAWmk5pCc0UAFFFITigAJxTaKQntVJCAntSUUhOKYeYE4ptHWiqSEFITil6U0nNMQlITmgntSVSAKaT2pScU2gAoooJxQS2Ix7U2ikJ7U0IQnNFFITiqBiE9qSiigNgoJwKKaTVi2EooooEB6U2gnJoqkAUUU1j2pbsBKKKKYBRRSHpQAh5NJRRQAUUUUCYUUUUEhRRRQAU09adTT1poAoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApQaSgdaTAdRRRUgFFFFABRRRQNBRRRQUKODTqZTgeKAFooooAKcOabSqaTAdRRRTQCqe1LTelO60mAU4HtTaXpSBDqKKKTQ9gBxT6ZSg9qkGOpQaSikxjwcU6mA5pQcVIDqOlFFBSY4HNLTAcU+gYoNOBxTKcDmhoB/Wimg4p1SAU4HNNopNDH0oOKaDmlqRjqcD61GDindaAH0U0HFOqbDClDetJRSAfRTAcU4EGgBQSKUNSUUAOopuSKUN60ALRRRQO4UuTSUUDuO3UZFNopWAfRTKXJ9aLAOopu40u72pWAXA60Um72o3CiwC0Y70m4UbvaizAWik3e1JuNFgHUU3JpKdgHZFG6m0UWAXJpKKKYXCiiigVwopCRSZJoEOJAppJNFFABRSEgUhOaAAt6UlFFABRRTSfSnYBSabRSE5qhXAn0pKKQnFAeoE4pvWjrRVJC3Ciimk5piAnNITignFNqkgCkpaaTmgBCc0UUUCbCmk5oJ7UlBIE4ptBOaKpAFNJzSk9qbTEu4UUUVSQbiE4ptKTmkpiYUE4oppOaEgCiiiqYBTDzSse1JSQBRRRTAKaTk0pOBTaACiiigAooooJYUUUUCCiiigAJwKbStSVSAKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAOHNFID2palgFFFFIAooooAKKKKCgpQcUlFAx9FIDS0AFFFFADgc0tNBwadS2AKUHtSUUwHUUA5oqQFB7U6mU4HNA0LRRRUtAuw4HNLTOlO60g2FBxTqbSg0mhjwe1LTKcDmpAWlBxSUUFJj6KaDinUDHA5pQcUynA5oaAfRTQcU7rUgFOBptFIfoPozimhvWnVI9xwOaXOKZSg+tAX7jwc0tMpQaVhjqKM5oqQFBIpcg02igB9FNBNLkUALS7qSigB2RRTaKAHUU3caXd7UALRRkUUBcKKKKB3CiiigLhRRRQFwooooC4UUUZHrQK4UUm72o3GgBaMim0UALu9KTOaKKACikyKQk0AKSBSE0lFABRRRQAUhIFIT6UlUkApOaQnFIT6UlMVwJzRRTS3pQGwpOKbRRVWsL1Ciimk5piAnNITignFN600gDrRRTSewpgBNJRRQJsKQmgnFNoJCmk5pSe1JVJAFITilphOaYtwoooppDYUhPagnFNqhbBRRQTigQjHtSUUVSAKSlprHtS3ASiiimAUUUhOBQAhOaSiigAooooEFFFFBIUUUUAFFFIx7UwEoooqgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACnDpTaVT2pMBaKKKkAooooAKKKKBoKKKKChQcU6mU5T2oAWiiigApwOabQDihgPooopIABxTqbSg9qGgFooopAP60U0HFOoHuFKDikoqWrD3H0U0GnUhbCg9qWm0oNJoY8HNLTKcDmpAWlBxSUUFJj6KaDinUDFBzTs4plKD60NXAeDmlplOBqQFpQcUlFA9xwOaWmU4H1qWh+ooOKcCDTaKQDqcG9ajBNOBBoC4+imU7d61Nhi0UZFFIAzil3UlFADsilplFAD6Kbk0bvagB1FJkUZHrQAtGT60UUAGTRk0UUAGTRk0UUAGT60ZNFFABRSZHrRkUALRTd3tRk0AOpMim0UALu9KTJNFFABRRRQAUUhb0pM5p2AUt6U2gkCkLVQrikgU0nNFFAbhSUE02mkHoKTmkoopiCgnFITikpiAnNITikJpKpIAooppPpQAE9hSUUUCbCgnFBOKb1oJCmk0pOKbTSAKKKaT2qhPsBOaSiigewUUU0mrFsBOaSiigQU0nNKT2pKaQBRRRQwEJwKbSk5pKaAKKKKACmk5pSabQAUUUUAFFFFBLCiiigQUUUUAFNpWPakqkAUUUUwCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBwOaKRaWpYBRRRSAKKKKACiiigpBRRRQMeDmimg4p1ABRRRQAoPanUynA5pMBaKKKaAcDmim04HNJoApwPam0UgH0UgNLSH5oKUHtSUVI9x9FNB7GnUCQoOaWm0oOaloY8HNLTKcDmkAtKDikooKTHdaWmZxTgc0DHA4pabQDigB4OKdTAc0ucVLQDqKQHNLQO4A4pwINNopWD0H0U0E0oINKw9xQTTgQabRSAdS5NMyRS7vWgLj9wpaZkUUrDH0U3Jpd1KwC0UmRS0gCiiigAoyaKKADJ9aMn1oooAMn1oyfWiigAyfWiiigAooooAKKKTIoAWik3Um407AOpMim0U7ALuNJSbvSkyTTFccSBSFqSigAopCQKQmnYNhSQKQnNJRTsAUUUhIFMVxaaT6UE5pCcUWEFIT6UhOaKoAopCcU0nNACk5pKKKBNhQTikJxSdaCQ60hOKCcU2mkAUUUhOKoQE02iigewUUUhOKoXmBPam0UUxBQTijpTSc0JAFFFFVsAU0ntSk4ptJAFFFFMAooppPagA60lFFABRRRQIKKKKCQooooAKKKRqYCHmiiiqAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigA6U6m0qntSYC0UUVIBRRRQAUUUUDQUUUUFBTgabS9KAHUUA5ooAKOlFFADutLTQcU6lsAUA4oopgOopoOKdUsApwOabVjTdOvdY1O00jTYfOu76eO2gj3Bd8jsFVcsQBkkDJIFLYEQ5FGRX0if+Ccf7Z//RG//Li0n/5Ko/4dx/tn/wDRG/8Ay4tJ/wDkqub67hf+fkfvX+Zr7Gr/ACv7j5vyPWlB7Gvo8f8ABOP9s7/ojY/8KLSf/kqsrxZ+wd+1f4F8Mar4y8U/Cr7Do+iWkt9fXP8Abumy+TBGpZ32JcMzYAJwoJPYUljMM3ZVI/egdGpbWL+48HpKYGr1P4P/ALMPxz+Pmm6hq/wm8D/27aaVOttdyf2nZ2vlyMu4Li4lQtxzkAitqk4UlzTdl56ExUpOyVzzENnjNLXtnxB/Yl/ae+Fng/UvH3j34ZDS9B0hEe8u/wC2tOn8pXkWNTsinZ2yzqOFPXPTNeIK+ODUU6lOsuanJNeTuOUZQdpKxKD60ZFaHhbwzrvjbxNpXg/wxY/bdX1u8h0+wtvNSPzp5XCIm9yFXLEDLEAdyK9+H/BOf9s3/ojg/wDCi0r/AOSampXpUXapJL1aQ4wnP4U2fOWRRWz448FeJ/hv4s1PwN400z+ztb0eb7Pe2vnxzeVJgHG+NmRuCOVYik8E+DfE3xF8V6Z4H8G6b/aGtaxOLaytfOjh82QgkLvkZUXgHlmAq+aPLzX0Fre3UyN3rS7hX0Yf+Cc/7Znb4OD/AMKLSv8A5Jo/4d0ftm/9Ec/8uLSv/kqsPruG/wCfkfvRp7Kr/K/uPnPPvTg3rXuPiL9hb9rbwtavean8EtZmjjGWGnT22oP+CW0kjH8BXiN7ZX+lXs2m6pZXFnd2zmOa3uI2jkjcdVZWAKkehrWFWnV/hyT9HciUZQ+JWG0oJFRg+lKWqrASbhRuFNghuLu4itLSCSaeZxHFHGpZ3YnAVQOSSeMV9I/D7/gnb+1V8QbOPUh4Gg8OWcyB45NfvFtXYH1hG6ZT/vIKyqVqdFXqSS9SoxlN2irnzfvFLkGvsHVf+CVH7T2nWpuLTUfA+qOE3CC01aZXJ/u5mgRc/wDAse9fOXxR+B/xc+CmoR6d8UPAmp6C85IhmmQPbzkdRHPGWicjuFYkVFLFUKztTmm/UqVOcFeSONBNLuFRK9O3VtYgfuFJur0z4Rfsy/HH49abqGrfCfwR/blppU6213J/adna+XIy7lGJ5UJ47gEV33/Duv8AbL/6I6P/AAotK/8AkmsJYihTlyzmk/NotU5yV1FnzruHelD+9fRD/wDBO79smNS7fBwkKMnHiDSifyFzk15t8Rv2d/jl8JLc3vxE+F+vaNZKQrXr2xltAx6Azx7owT6bs04YihUdoTTfk0Dpzjq00cFupcioQ1BatbEEu4Um+vb/AAX+xB+1H8RfCmmeN/Bvww/tDRdYgFzZXX9t6dD5sZJAbZJcK68g8MAa2T/wTr/bK/6I7/5cWlf/ACTXO8Vh4uzqRv6o09nUeqi/uPnfzD604SV9D/8ADuv9sr/ojo/8KHSv/kmlH/BOz9sn/oj3/lw6V/8AJNL63hv+fkfvQeyqfyv7j54D5pd3tVjXdG1Twxruo+G9ctfs2paTdzWN5DvV/KnicpIu5SVbDKRkEg44JqrkVvo9SB24UbhTcimM1FguSGQUnmCvbvBf7EH7UfxF8KaZ438G/DH+0NF1iAXNldf23p0XmxkkBtklwrryDwQDWz/w7r/bJ/6I7/5cOlf/ACTWDxOHi7OpG/qi/Z1HtF/cfPHmD0pd9fQF1/wT3/bEsojNN8G5mUdotb02Vv8AvlLgn9K8c8c/Db4ifDDUU0n4h+Cda8O3UmTEmo2TwCUDq0bMMOPdSRVwrUajtCSfo0JxlH4lYwtxpC3vUYerGnWF7rGo2ukabD5t3fTx20Ee4LvkdgqrkkAZJAySBWtibkW4Um+voo/8E7P2yu3we/8ALh0r/wCSab/w7r/bK/6I7/5cOlf/ACTXP9bw/wDz8j96L9lU/lf3HzvvFLvHavd9Y/YJ/a80K2e7vvgtqEiRruIs9QsrtyPZIJnYn2AzXiWveH/EHhTVp9B8UaHqGj6nbHbPZ39s9vPGfRkcBh+IrWnVp1f4ck/R3JlGUfiVipk0hIpgb3ra8F+DfEvxE8V6Z4I8Hab/AGhrWsTi2srXzo4vNkIJA3yMqL0PLECtHaKu9hJXMjcKMivov/h3X+2Tn/kjv/lw6V/8k14L4r8M694H8Tap4O8UWP2LV9Fu5bG+tvNSXyp42Kuu9CVbBBGVJB7Gs6dalVdqck/RplShKHxKxnbhSFq7b4SfBL4ofHfW7zw58KvDaa3qVha/bbi3OoWtqywb1QuPPkQMAzqDgnG4eteqf8O6/wBsr/ojw/8ACh0r/wCSaU69Gk+Wc0n5tAoTkrpM+dKKs61o+qeG9b1Dw5rtm9nqWlXUtleW7kFoZ4nKSIcZGQykcHtVQt61utdURsLkCjcBXYfCj4OfEv45eJZvCHwr8Mvreq29o9/LALqC3CQIyIzl5nRB80iDGcndwK9b/wCHdP7ZX/RHv/Lh0r/5JrKeIo0nyzmk/NpFKE5axTZ857s9KSr3iLQNW8JeIdT8La9bpb6no93NY3kKTRzLHPE5R1DxlkbDKRlSQccE1nkk1srNXRApb0pM+tNZsV714W/YQ/aw8beGtL8X+GvhO91pOtWkV9YzvrWnQmaCRQyPskuFdQVIIDKDg1NSrTpK9SSXq7DjGU/hVzwbI9aCfSvow/8ABOn9sxQSfg5wOePEOlE/+lNfOUkcsEr29xG0csTFHRxhlYHBBB6EGlTrUq38OSduzuEoyh8SsJRRTSa1JbF3CkL4r6Pb/gnN+2b2+Dn/AJcWlf8AyTTf+Hcv7Z3/AERz/wAuLSv/AJKrm+uYb/n5H70V7Gr/ACv7j5w3UhcCvo8/8E5f2z/+iOD/AMKLSv8A5KpB/wAE5P2zv+iOf+XFpP8A8lU/rmF/5+R+9f5h7Gr/ACv7j5wyDS17V8R/2Lf2mPhH4Mv/AIg/EP4ajSdA0sxC7vP7Z0+fy/NlSJPkhnZzl5EHCnGcnABNeIlu1b06kKy5qck15O5Eoyg7SVh5OKbkete6+Cf2Gf2p/iP4T0zxx4M+F39o6JrMAubK6/tzTYfNjJI3bJLhXXkHhlBrb/4dx/tnf9EbH/hRaT/8lVm8XhouzqRv6opUalrqL+4+bsijIr6R/wCHcf7Z/wD0Rv8A8uLSf/kqgf8ABOP9s/8A6I2P/Ci0n/5KpfXcL/z8j96/zD2NV/Zf3HzcTim1e17Q9V8L69qXhnXbX7NqWk3c1jeQb1fyp4nKSJuUlWwykZBIOOCao11J3V0ZMKKKQmmAhOaKKKoAooppOaW4CE5ooopgFFFFACE4ptKTmkoAKKKKACiiiglsKKKKBBRRRQAU0nNKx7UlUgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQA4HNFNBxTqlqwBRRRSAKKKKACiiigpMKKKKBig4p1MpwPagBaKKKAClBpKKAH0U0HtTqWwBSg0lFMB1dB8N22/EXwqfTW7E/+R0rnc8YNb/w9O34g+GG9NZsj/wCR0rKrpCT8mVD4kf0M/wBpf7VefeLf2lfgh4C12fwx4z+KvhvRdWtVRprK9v0imjDqGUlScjKkEexrX/tI/wB/9a/Hv/godL537WHiuTOc22m/+kUNflWQQjnGKeHlJq0W9PJpfqfWZjfBUlUSvrY/VX/hsX9mf/oung3/AMGsf+Nec/tIftT/ALP/AIo+APxD8O6D8YvCt/qWpeG9QtbS1g1KN5J5XgYKiqDkkkgAV+MK1Kvavs6fDNKlNTVSWjT6HiSzOUotcqHV+n3/AASMu/I+HXj8ZxnW7Y/+QDX5g1+kv/BKe6+z/D/x0u7GdZtv/RBrTier7HLZz84/mhZVD2mKjH1/I+kP2+b7zf2RfiHHu62tn/6XW9fiYOlfsl+3RfGX9lLx/Huzm2tO/wD0+wV+Ni1xcH1/rGCnL+8/yibZzT9lXivL9WeofsvSeX+0l8Ln/u+L9JP/AJNR1+8v9pf7Vfgl+zU/l/tD/DR/7vizSz/5MpX7h/2kf7/615fGOK+r4iku8f1OvJaPtacn5n4yftry+Z+1X8SH9dXz/wCQo6i/Ywl8v9qf4bPnpraH/wAcaov2x5PN/af+Ib5zu1bP/kJKj/Y/k8v9pv4dv026yn/oDV9Up/8ACVz/APTu/wD5KeRy/wC18v8Ae/U/dP8AtL/arzHWv2rf2ffDutXnhzXvjF4XsNT0+4e1urW41BEeCVTtZGB6EEEGuk/tI/3/ANa/D79p5vM/aL+Jb/3vFGon/wAjvXwnD9COc1Z05Sa5VfQ+gzGTwMIzSvdn7o+FPiP4O8d6cdY8E+LdH1+xDbDc6ZfR3UQb+6WjYgH2PNeLftc/sueDP2kPBd5cRaba2fjnT7Zn0fV0QJI7qCVtp2/jiY8c52E7h3Dfm5/wT28VeJfD37T3hzTNDup1stchvLTVLdWxHNAttLKpcdPkdEYHrkY/iOf18/tI/wB/9anNpVOHsbGEJ3dlJP52s/u+Y8HCGY0HKUfI/AK5t7mwuprG9heG4t5GiljcYZHU4ZSOxBBFJBBcXlxFaWkMk887rFFHGpZndjgKAOSSTjFeiftNWtpY/tD/ABHt7AIsP/CS37hUGApaZmYAezEivQf2A/AVp46/aR0W61G1Wey8L282vSI4+XzItqQH6rNLE4/3K/Qq2NhRwTxktlHm/C9j5yFBzrqgt72Pv/8AYw/ZA8Lfs+eGrPxZ4q022v8A4iahBvu7uTEi6YrD/j2t+ykDh5Byx3AHbgV9FeLfiP4Q8BaQ+v8AjbxTpehach2m61C7SCMtjIUFyMscHCjk9hWedTwCTIABySTX4qftQfHfX/j/APFbVfEt7qMz6HZ3ElpoVnuPlW9mrYVgvZ5AA7nqScdFUD4HKlX4jxM5TnZLVv12S/E+hxap5ZSSS1e3+Z+xHhH9qv4AeO9Xj0Dwp8XfDd9qUz+XDa/bBHJM2cBY1faZD7Lk12vi3Q/DHjzw9e+E/GOi2er6RqMRiubO6jDxyKf5EdQwwQQCCCM1/PRhkIZSQRyCOoNfrF/wT7/aA134sfCW68PeLtSkvtd8G3EdlJdSsWkuLSRSbd5GP3nGyRCepEakkkk12Z3lU8po/WqM24pq9912d15mGAxUcZP2M42bPib9s39l+b9m74gxDQnmuvBviHzJ9GuJW3SQlceZbSHuybgQ38SkHkhsfPhbjrX7A/tz+CrX4i/s2+KA1ukt94ciXXrKQ8mI25zMR9YDMPx9q/HsHivoeHc0ea4Tnn8UXZ/o/wCup5+ZYX6nW5Vs9Ufpx/wSUu/I+Hnj4Z661bf+iDX2/wCKPHnhzwVoN34o8W63a6TpNiqtc3l1IEiiDMFBZj0yzKPqRXwR/wAErbsweAPHK7sZ1i2/9EmvbP25r7zv2VPH0e/O62tO/wD0+wV8hmeIVTOnhm7XlFffY9jC0rYFVeyb+656npH7V37O+u3iWGl/GzwbLcSELHG2sQxl2JwAu9huPsOa9IuLq1vraS1uoori3nQpJHIodJEIwQQeCCO1fzo1+rf/AATZ+IXiXxN8ALjS/EN7PdR+HNbm0zT5pWyVtvJhlWLJ5OxpWxnopUDgAV3Z3lX9lYf6zTm2k0mn5nPgMUsZU9lKNmfPv/BQr9lLQPhBqln8Vvhnpq2PhfXbk2t/psS/utOvSCymMfwxSBXwvRGXA4ZVX4xLjFfsL+3PDZaz+y144ivdh+zw2t1CzdUkS6iII9zyv/AjX46k8V7vDOYSzHBc03dxdr/JP9ThzTDLDV7R2aufuL+xjf8Al/st/DdN3TRU/wDQ2rvvHXxm+HHwxjs5fiF430jw8mos62jahdLCJim3eF3dcblz9RXj37H9/wCX+zN8PE3/AHdHQdf9tq+Z/wDgq9dfaNI+Go3Z23Oq/wDoFtXyGHmsfmzwjla8pbeV3+h7NSH1fBqsleyX6H2Z/wANg/s1/wDRcfB//g0j/wAaX/hr/wDZsPT44eD/APwaR/41+EynipENfV/6s0v+fkvwPHWZy/lR2vxg1Ox1v4u+N9Z0q8iurK/8R6ndW88Tbklie6kZHU9wQQQfQ1yg6VGvrT93tX0MY8sVFdDz27u4pqNz1p+72qKQ4BqkhOx+3/7GV/5f7Lfw3Td00VB/4+1d749+NPw3+F0dlL8RPG+k+Hk1FpFtGv7gRCYpt3hc9cblz9RXj/7IF+Y/2Zvh5Hvxt0dB1/22r5o/4KuXX2jSPhqC2dtzqv8A6DbV+YYeax+bPCSdk5S28rv9D6mrD6vg1WS2S/Q+6/B37QPwd+IV6ul+CPij4Y1q+YMy2dnqkL3BA5JEQbeQPXGK1vHnhLwb8TvDF54O8e+H7PWtHvl2y21ymRns6kfMjjqHUhgeQRX8+1jf3ulXsGp6bdzWt3ayLNBPC5SSKRTlWVhyCCAQRX7m/BbxvrHjP4Q+CvFuvsf7T1jQLC9vGIC75pIEZ3AHADElgPQiuvPcFLJFCrCd03bs0zHL6qx7lCUbNH5K/tU/AS7/AGdfi3feCo7ia70W6jGoaLdyj5pbRyQFcjjejKyN0ztDYAYCuA+HT7fiH4WPprVj/wCj0r7j/wCCq9rZ3Gn/AA61nCC8SfUbXcPvNGVgbH0BH/jx9a+Fvh8xHj/wyc9NYsj/AOR0r67Kca8fl0cRLdp3+V1+h5GLoLD4l0ltp+J/QZ/aX+1Xnvi79pb4I+Aten8L+M/il4e0bVrVUaazvLxY5Yw6hlJU9MqQR7Gtj+0j/f8A1r8hf+ChEvnftV+KpCc5ttN/9Ioa+FyGMc3xLoSk1aLenk0v1PdzC+CpKolfWx+wHg34ufDz4iQy3HgLx3oPiJLfHnHTNRiuTFnpvCMSmffFch+0F8Bvh3+0X4Nn8M+M9OhS/jif+y9YjjButOmI4ZG4JTON0ZO1h6HBH44fsw+KPEnhL9oHwFqPhW6niu7jXrKxlSJsefbzTLHNE3bayMwOenXqAa/bj+0j/f8A1rbOoTyHEQ9nUvdXT6ojA8uYU3zR20Pwc8beEdb+H3jHWfA/iOERanod7LY3KqcqXjYjcp7qcZB7gg16X+xpL5f7Uvw3f01pD/441dF/wUDt7OH9qbxPNaBA11bafNMFGMSfZI1P4kKD+Ncl+yFJ5f7TPw8kzjbrCH/xxq+5+s/WMseJ/mhf743PC9l7PFey7St+J+5v9pf7VfhN+1NIZP2kvie+fveK9SP/AJMPX7X/ANpH+/8ArX4kftMv5n7RHxJfP3vE+on/AMjtXyvCGK+sYiou0f1PWzmj7KnF+Z0H7HHxWb4PftF+EPFE9z5OnXd3/ZGpEnC/Zbn90Wb2Rikn/bMV+4P9pf7Vfzpnpwa/bL9mb4tt8WPgb4S8ZXF15t/LYraaiS3zfa4P3UrH03Mhceziuni6Lw6p4pbP3X+a/Uyye1VypP1/z/Q/O/8A4KN/DoeBf2ltU1u0g8uw8ZWsWtwlR8omOY7gZ/vGSNnP/XUV8vljiv01/wCCnXgQeJ/hJo3xDtYd914S1Hyp2A6Wl1tRiT7SrAB/vGvzELk8Cvb4exqzDAQqX1Xuv1X/AALM4MxoPDYiUej1+8/Tb/gk54BGkeDvGHxVvIMTazex6NZMw5EFuu+Ur7M8qg+8NfYfxu+K8Hwm+Eniv4izOm/Q9Mmnt1fpJckbIEP+9K0a/jXBfs2+Cx8KPgZ4N8DPGIbqy0yOW9XoRdzZmnB9cSSOPoBXzb/wVC+KjWHw/wDDnwrsbrE3iC9bUr1Vbn7Nb8IrD0aVww94TXxccZ/bOceyg7py/wDJV/wEe48P9SwXPLdL8X/wT83p7u5vrmW9vJ3mnuJGllkc5Z3Y5LE9ySSaaTimL0oY1+n7Hyp1Xwn8B3nxS+J3hj4eWO8Pr+pwWbuo5iiZh5sn0SMOx9lr9+dNNlpGnWuk6bAlvZ2UKW9vCnCxxooVVHsAAK/Kb/gmH8PBrPxW1v4m3sANv4V0/wCzWjkdLu6yu4H2hWYH/roK/QT41fEU/Dz4R+MPGqXAjm0jRrq4tznGbjyyIR+MhQfjX57xNmTqY+GCpvVWXzlb9LH0eV4W2HdefX8l/TPWLTXbW/tYb6yuo57e4jWWGWNgySIwyrKRwQQQQa/FP9uv4ZD4X/tL+KbW0t/K0zxDIPENgAMLsuSWkAHQBZxMoHoor9Cf2EviQ3jb9mTwmbi58y70FJdCuMtnb9nbEQ/78GH868e/4Ki/D0a/4B8OfFOyhDXPhy8bTr1lHJtbjGxmPosqKo95jWeTY94HNngqr3bj81t9/wCpWNwyr4NV4dk/8/68j83AabnkfWmqe9Oav0c+ZP3X/wCGwv2ah1+OXg7/AMGkf+NbPhD9pD4KeP8AXIvDXgn4peHNb1WZHkjs7K/SWVlQZYhQc4A5NfgUwzX0v/wTnk8j9qXRJM4xpuoj/wAgNXx+OyClhMLUxCqN8qb6dEezh8fKtVjTcVq0j9nf7S/2q8pm/a+/Zutp5Laf43+D45YmKOjapGCrA4IPPrXWf2kf7/61+Anib5vE2rn1v7j/ANGNXicPYWGdOopTa5bbed/8jvzKo8CotK97/hY/VP8Abp/aR+B/j/8AZc8ZeE/B3xV8Nazq982mm3srO/SSaXZqFu7bVBycKrMfYGvybPSlC01q+/y7ARy6k6UZN3d9fRL9D57E13iJKbVtD9zP2Lb/AMv9lf4ax7vu6Ig/8favQPHnxo+G3wvjspfiJ450fw6motIto2o3SwiYpt3hd3XG5c/UV47+x3fmP9mL4dR78bdGQdf9tq+Y/wDgrNc/aNH+Gg3Z23Oq/wDoFtX5zh5LMM3eDlKycpbeV3+h9LVh9XwarpbJfjY+0P8AhsX9mf8A6Lp4N/8ABrH/AI0f8Ni/s0f9F08Hf+DWP/Gvwap4r6//AFWo/wDP2X4Hjf2rP+Rfidp8ZdUsNc+MHjnWtKu4ruy1DxLqd1bXETbklie6kZHUjqCpBB9DXIUi9aCewr6WEeSKiuh5bd3cCe1JRRWggoopCcUtwEJ7UlFFMAooooAKaT2pSabQAUUUUAFFFFAmwooooJCiiigAoopCe1NAJRRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSg9qSikwHUUdaKkAooooAKKKKACiiigpBRRRQMcDmlpvSnA5oAKKKKACnA02igB9FIDmlpbAIelbngFtvjvw2fTV7P8A9HJWGelbPgY48b+Hj6araH/yMtZ1/wCFL0ZdP416n7mf2iPWj+0R61y/9oj1r8zv21PGvi3Tv2i/EVppPirV7O2SCxKQ299LGik2sROFVgBk5NfgWQ5LPPMS8NGfLaLd7X2aXl3P0fMcbHLqSquN7u35/wCR+rP9oj1r5U/4KSXfn/ACwQH/AJma0P8A5Aua/OEfELx9n/kePEH/AIM5v/iqr6j4r8Ua3biz1nxJql/AGDiK6vJJUDDIBwxIzyefevvMs4Gq5fjKeKddPkd7W3/E+cxfEEMTQlRVO11bf/gGcelfod/wTCuvI8CeNlz11e3P/kGvzvzxivvH/gmxq0MfhjxvpoYebFf2c7DP8LxuB+qGvZ41TeTVLd4/+lI4cht9fj8/yZ9C/trXol/Zg8dR5629p/6WQV+RanAr9bP2mtG1Lxr8BvGfh3R4XnvJtP8AOiiQZaQwyJNtUd2IjIA7kivyQDY615nh9JPAVYX1U7/fFW/JnXxNFrEwfTl/Vno37Oz7Pj78On/u+KNMP/kylfs//aI9a/G/9lrw5qfif4++DIdNgeQadqcOqXDgcRw27CRmY9h8oUe7Ad6/Wj+0R614fiFJPGUop6qP6nocMxfsJvpf9D8ov2uH839pPx9J66p/7TSmfsmyeX+0f4Ac9tXQ/wDjrVT/AGm9Qh1T4/8Aju7gYFRrE0JIOfmjwjfqpqT9lx/L/aE8Cyemqof/AB1q+8s1kdn/AM+v/bD5zfMP+3//AG4/ZD+0R618w+N/2Bfgp4+8Z61441nxN40ivtdv5tQuYra9tVhWSRyzBA1sWC5PGWJ9692/tEetfGPj3/goF4q8D/E/XPBsvgTS7nTNE1iaweZZ5BPJDHKVLAfd3lQcds1+QZDQzWtVmsrk1JLXVLT5n2+ZTwdOEXjFpfTTr8j6d+C37N3wg+A09xqPgbRrh9VuojBLqd/cGe5MRIJjBwFRcgE7VGcDOcCun+Lnxl8MfBzwNqHjfxRdqsVshW2tw37y7uCDshjHdmI/AAk8Amm6L4p0zxDo9lr2j3iXNhqNvHdW0yHiSJ1DKw+oIr4A/wCCg3g7xRYfEPTvG9zq9/f6BrEAgtYppWeLT7iNQJIkXoiuAJB6nf8A3a1yjCSz7NFSx9V3e993b7Plpf0sRjqqy7COeGgreWyv1PmTxBr2peKdf1PxPrM3nahq95Nf3UgGN80rl3OPdmNfXP8AwTKe3h+Jfi+dm/fDQ0VB/sG4Qt+oWvjcdK+h/wBhHxpD4S+PNvp11KscPiPTrjTAWOAJPlmTn1Jh2j1LYr9X4joOplFenT6R/Ba/kj43K5qONpyl3/M/Trx1qk0XgjxDLasRMmlXbRkHB3CFsfrX4fxkV+2Ut5FPE8Myh45FKsp5BBGCDX49/Fv4d6p8KPiHrHgrU4ZFWzuGNnK44uLViTFKD3yuM46EMOoNfH+HteEXXoN+8+VrzSun911957nE1KVqdRbar8jlW6V9p/8ABMS8ntvFnjuJSRBJp9kzjPG8SSbf0LV8TmSv0N/4J/fD7UPBnw71XxvrFs9vceLZ4mtUcYY2cIYRvg8je0khHqoU9CK+k4xrwo5RUjJ6ysl63T/JNnlZFSlUxsWtldv7j6j+L95bT/CbxtBdtiCTw7qSSf7htpAf0r8UQeOa/Vv9qrx5D4R+Afi+6aZVm1KwbSYFJ5d7n90QvuEd2+imvykA4ryPD6lOOErVHs5JL5L/AIJ28TSXtoQW6X5v/gH6Ff8ABMe6EHgbxqM9dWtz/wCQTX0l8e/A978XvhH4h+HOmalb2FzrUUMcdxOrNHGUnjkOQvPRCPxr5W/4Jw3P2fwV4xGeuqwH/wAgmvpz4j/E7R/hh4K1Px3r1ve3FhpSRvNFZorzMHkWMbQ7Kp5cdWHGa+Rz91o8QTlh/jUo8vraNvxPby2MJZZFVPhs7+mtz4+0z/gmZ4qe8jXWPipo8NpuHmNbWEssm3vgMyjP1Nfbfwj+HPhP4LeBrHwF4OilWytC0kk0xBmuZnOXlkIABY8DpgAKBwBXzQ3/AAUd+DW0mPwr42Ldg1naAH8ftJrhfHf/AAUfvbmzls/ht4DNrO4wl9q84fy/cQR8E+hLkeoNejjMHxPnnLRxMXyp315Yr1ff8fI5aFbKMvvUpS1+bZ6b/wAFEfjFp2i/DCH4VWV4r6t4onimuYVYborKGQPuYdRulRAvqFf0Nfm4RgVr+KPFXiPxvr134n8V6vcanql8++e5nbLMegA7KoGAFAAAAAAArJYcV+h5DlKybBrDXvLdvu3+myPmcxxjx1d1bWWy9D9f/wBk6+Ef7OXgFM9NJQf+PtXrP9oj1rwX9l2+Ef7P3gZM9NLUf+PNXhv/AAUT8Ua7pOmeBToet3+nmWfUBIbS5eLfhYMZ2kZxk9fWvyGOXSzXOp4RS5eac9d9rv8AQ+1eIWDwEa7V7Rj+Nkfdn9oj1rjvjNfhvg/46XPXw1qY/wDJWSvxyX4g+PP+h21//wAGU3/xVLL468bXUMltceMdclhlQpJG+oTMrqRgggtggjtX1dHgCrSqRn7daNP4X/meNPiSE4uPs9/P/gGSpqSo1Ip+R61+ks+XuLUMh4qUkY61DJTQrn6+/sn3wj/Zz8BJnppKD/x9q5T9rv8AZ3139o+z8MWuh+JdP0k6DLdySG7jd/M84RAbdvTHlnr61b/ZevhH+z94HTPTS1/9CapfjX+0j4N+A8GkXHi7TdavF1l5kgGmwxSFTEELb/MkTH+sGMZ79K/CozxlLOpzwKvU5526976PyufobhQngIrEaQ5Y3/D9TwLwJ/wTWjttbgvPiN8RYbzTIXDyWWl2zI9wB/CZXPyA98KTjoQea+6rB7LS7G30zTreK2tLSJIIIYl2pFGgCqqgcAAAAD2r47uP+CjnwiEZNp4R8YyP2WS3tUH5idv5V458WP2/fH/jLTp9C8AaOvhO0uFMcl4Lgz3zKf7jgKsWR3ALDqGFe1iMp4iz+rFYxWS6uyS+S1f3M4KWMyvLYP2Du32u2/mx3/BQv4u6f4/+J+neCtEu1ubLwbBLDcSIwKG9mKmVQR12LHGp9GDjtXzf4EO3x14cPpq1n/6OWsdi0jNJIxZmJLEnJJPc1reCjt8a+Hz6apaf+jlr9KweBhluAWEpu6jF693u382fKV8RLFYh1pdWft9/aI9a+efi9+xd8JfjT49v/iJ4p8Q+LLXUtRSGOWKwu7ZIAIoljXaHgduiDOWPOenSvXv7RHrXyZ8ff23PF3wh+KOqeAtJ8G6TqFtYR27pcXE0quxkhSQ5C8cFiPwr8WyKjmVbEuOWStPld9UtLq+/nY+9zGWFp0k8Wrxv2vrqe2/B/wDZK+CPwV11PFPhrSr/AFDWoAy29/qt0JpLcMpVjGqqqKSCRu25wSAQCa9W8X+P/DvgTw3f+LfFWqRWGl6bCZriaQ9AOigdWYnACjkkgDk1xXw3+JmkfEzwPo/jjRXxbarbLKY92TDIOJIm90cMp+lfKf8AwUR8I+J7+x0Hx9Z6vfT6FaH7De6f5rGC2mYkx3AToC2SjN7IO9bYTD1s5zSOGzGq1Juzb1en2V27LpczrzhgcG62FgmrX08+p8o/GD4i3nxZ+J3iL4iXqNG2s3rSwxtjdFbqAkMZx3WJEUn2rpv2Un8v9o3wC/pq6f8AoLV5QuMcV6f+zBJ5f7QXgZ/TVUP/AI61fsmOpRo5dVpU1ZRg0vRRsj4XDzdTFQnLdyX5n7E/2iPWvxs/aMfzPj98Q3/veJdQP/kdq/Wv+0R61+Rv7QD7/jp4+f8AveIr8/8AkZq/O/D5P63W/wAK/M+n4mVqMPX9DgjX3V/wTP8AicYB4q+FF7ccEprtghP+7FcAf+QDgf7Rr4W4xXoH7PvxCb4XfGPwz4vkn8q0ivBbXxJ4+yzDy5SfXarFh7qK+9z/AAH9pZdVoJa2uvVar79vmfOZdiPquKhUe17P0eh+tfxX8NW/xH+GnibwLOFP9taZcWkRbokzIfKf/gLhW/CvyV/Z08CyeOvjz4Q8H3tqxi/tZJr6J1/5YW+ZZkb0ysbL9TX62/2iD/F+tfKHwI+FaeFv2vPir4iNqFs7CNZbI4wobUWE+U/3Qkqe2a/NeGs2eX4HGU29eXmj6/D+bj9x9ZmuB+s4ihK3Wz9N/wBGfa/9oj1r8lf20PiQ3xK/aD8Q3MFx5thoLLoVng5AWAkSY9QZmmIPoRX6K/Fn4jxfDj4a+I/GzuofSrCSWAN0a4I2wqfrIyD8a/HuSea5mkubiVpZZWMkjsclmJyST3JNen4f4ByqVcbLouVer1f4W+84+JcRyxhQXXV/p+v3CjgUyRsCnHPet/4deD7n4heP9A8FWu4NrF/DbO6jmOIt+8f/AICgZvwr9NqTjSg6k3ZJNv0R8lCLnJRjuz9Ov2GvA6/Dv9nzRZbiHy7/AMTO+u3ORztlAEI+nkpEcerGuT/4KOfEP+w/gbbeELefbP4q1SGGRM8tbQfvnP4SLAP+BV79ZSWmm2Vvp1jEsNtaxJDDGvCoigBVHsAAKx/E/hLwH43a2bxn4M0HXzZhxbnVNOhujCGxu2eYp252rnHXA9K/B6GaR/tZZliIuS5nKy+9L5afcfo1TBP6n9VpOzta/wCf3nyT/wAEw/iKbS+8Y/DO5n+W4jh1yzQnADKRDOfqQ1v/AN8mvs/4t+E7T4ofDPxL4AuymNa06W3iZ+kc+N0Un/AZAjf8BrnPD3w9+GHhLURrHhT4deF9Fv1RoxdafpFvbTBG6rvjQNg9xmuo/tEetGcZpDHZi8fhouDdnr3VtfwQYHBSw+F+rVXzbr5M/E26trnT7uewvIWhuLaRoZo3GGR1OGU+4IIpg5r279s7wGvgf48azdWsOyx8SBdbt8DjdKSJh9fOWQ49GFeIrX7ngcVHHYaniYbSSf39PkfnmIovDVZUpbp2Eavor/gn/L5P7S+jPnpp9+P/ACA1fOrHjivff2FJfJ/aL0mQn/lwvv8A0S1cmff8ivEf4JfkzfLdcZS/xL8z9Yf7RHrX4XeI+fEWqn1vZ/8A0Y1ftT/aI9a/FTxAc+INT/6/J/8A0M18P4dJ8+I9I/8Atx9DxQrRpfP9CnUb8VIOlROa/UD5E/Yn9kq+Ef7N/gBM9NIQf+PtXrf9oj1rwP8AZZvhH+z14Fjz93SkH/jzV4X/AMFGvFOu6TpngQ6Hrl/pxln1ESG0uXh3gLBjdtIzjJ6+tfgkculmudTwcZcvNOeu+13+h+jSxCweAjXavaMdPuR94f2iPWuN+NN+G+Dnjtc9fDOqD/yVkr8aB8QvH+f+R48Qf+DOf/4qmzePPG91DJbXPjLXJYZUKSRvqMzK6kYIILYII7V9bR8PatKpGf1haNP4X0+Z4s+JYTi4+zevn/wDFB5wKWmrTq/UD5IKKKQnFJsAJxTaKKaVgCiiigAoJxR0ppOaAEooooAKKKKBBRRRQSFFFFABRRRQAE4ptBOaKpAFFFFMAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAAHFOptKD2pNALRRRUgFFFFABRRRQAUUUUFBSg4pKKBj+tFNBxTqACiiigApwOabRQA+tXwYdvjLQW9NTtf/Rq1kg5qxp19NpWpWuqW6o0tpOk6BwSpZGDDOMHGR61nUTlBxXVFQfLJNn7G/2iP71eT+Pf2bvg38S/FF14x8XaHd3OqXixpLLHfzRKQiBF+VWAHyqK+TT+3f8AGDt4f8I/+Alz/wDJFH/Dd/xg/wChe8I/+Alz/wDJFfkmG4Sz3Bz9ph5KL2upWdvkfc1c8yyvHlqq681c+kf+GM/2d/8AoV77/wAGtx/8VXK/Fj9lP4GeFfhn4o8SaH4dvIdQ0zSrm6tpG1GdwsiISpKlsHkdDXjH/Dd/xg/6F7wj/wCAlz/8kVmeK/2yfih4x8M6p4V1TRPDEdpq1rJZzvBa3CyKjqVJUtOQDg9wa9TD5NxNCtCVWs3FNX997X1OOrj8nlTkoU1ezt7p4RXsf7LHxng+DXxIW81mRl0HWovsOosAT5IzmObA67W6/wCyzYBOK8dAzSFa/QMZhKWOoTw1ZXjJWf8AXdbnytCvPDVY1ae6P2PtNbtL+1ivbG7juLe4RZIpYnDJIhGQykcEEdxXjnjf9lL4G+OtZm1++8PT6de3LmS4fTbkwLM5OSxTBQE9yoBOcnmvhn4Z/tA/E/4URrZeG9bWfTAxb+zb5POt8nrtGQyevyMuT1zXtFh+35rscKrqnw2s7iXHzNBqbwqT7K0bkfnX5hPhPOsrrOWXTun1jLldvNNr82fZRzvLsZTSxUbPs1dfK1/0PrH4Z/Cv4c/CKyltPAvh+Kye5AFzcu7S3E+OgaRiTj/ZGFHpVb41fG3Qvg94LuvEGoXEcmoSo8Wl2Rb5rq4x8owOdgOCzdh7kA/IPiL9u34gahbtB4b8LaTpDOCPOmd7qRPdfuLn6qR7V4D4q8X+J/HGsSa94t1u51S/lG0yztnavZVUcKv+yoArfAcG43F4n6xmstN3rzSflfZL5meKz/DUKXssEtemlkjP1C/u9Vv7nVNQmaa6vJnuJ5G6vI7FmY/UkmvQ/wBmt/L+O/gqT+7qan/x1q82AxWz4M8V6l4F8Vab4v0eG3lvNLnE8KXCs0bMARhgpUkc9iK/RsZRdbC1KNPdxaXzVkfKYeahWhUl0ab+8/Xf+0R/er8pvjz+8+Nfjl/72v3p/wDIzV6n/wAN1/F3/oAeEv8AwEuf/kivCvFXiG98X+JdU8U6nFBHd6tdy3k6QKVjV3YsQoJJAyeMk/Wvj+E8gxmT16lTEpWkrKzv1PdzzM8PjqUYUb3T7eR9lfsJ/GRr/Qbv4Sa1dk3OkhrzSi7cvbM37yIf7jtuHs57LXvfxl8B6b8XPh3qvgq+KLLcx+bZTsP9RdJzG/0zwcdVZh3r8wPBfi7WvAPinTvF/h2ZI7/TZvNj3glHGCGRwCCVZSVIBBwTyOte4f8ADdXxe/6F/wAI/wDgJc//ACRXJnPC2MnmX17LbK7Ut7Wl/wAHf1ub5fnOHjhPq2Lu+m26/rQ8A1LTL/RdSu9H1W2e3vLGZ7e4hcfNHIjFWU/Qg0abqV/oup2ms6Xcvb3ljPHc28yH5o5UYMrD3BANbnxD8e6j8SvFVz4v1bStMsb28VBcLp8bxxyMo27yHdjuIABwcHGcZyTzeM9DX3tLnqUl7ZWk1qt1fqvQ+Ynywm/ZvS+jP1A+BPx/0H4zeFYb2K4httetYwuqacG+aKToZEB5MbHkHnGcE5FbnxF+Gfw7+K9jHY+O/DlvqP2fPkT7mjnhz12SIQwHcrnBwMg1+WOh69rnhjVIda8Oatdabf25zHcW0pjdfUZHUHuDwe9e++F/24viXpNult4l0XStdCKB52GtZmPqxXKH8EFfnGY8G4vDYj6xlUtN0r2kvR9vmn6n1mEz+hWpeyx0de9rp+qPpLw3+yL8A/DmpR6oPDE+pyRMHjj1G7eaFSPWPhXHswYV7VJqtpp9o0ss0VtbW0ZZmZgkcaKOST0AAH0Ar4hvf299ckhK6d8N7SCXbw02ptKufXaI1OPbNeO/En9oP4o/FOJrDxBrYttMbrp1gpht25z84yWftwzEDHArmjwtnWaVU8wnZLrKXM16JN/mjeWc5dg4P6rG78lb72/+Cd3+1x8f7f4t+Irbwv4YufM8NaDIzJOCcXtyRhpQP7qjKp65Y9GGPn+hQRxTj71+kYDBUstw8cNQXux/Hu35s+RxOIni6rrVN2fbX/BPy58jwf4sXOM6nAf/ACFXqf7V94Jf2fPF8e7O6C2/9Koq+HfhN+0D40+DWnX+m+FtO0a5i1GdZ5TfwyuwZV2jbskTAx6g1u+PP2sfiR8RPCWoeDNb0fw7DZakqJK9rbzrKArq42lpmA5UdQeM18VjOHMdXztY+KXJzxe+tla+nyPosPm2Gp5d9Wlfm5Wtu9zxVFFSBRSDil3V+gs+XSFpr5p2RSNSCx+nn7Nl75fwK8GJuxt01R/481aPxP8AhR8P/jDFp0PjzTZ7xNKaV7YRXUkO0yBQ2dhGfuL1r4e8G/tdfEvwL4W03wlpGjeG5bPS4RBC9xbTtIygk/MVmAJ57AVsf8NzfF3/AKAHhL/wEuf/AJIr8srcK5vHGzxWGai3KTTUrPVv9GfZ085wDw8aNW70SatdaH0YP2OP2eh08M33/g0uP/iqcP2O/wBnwdPDN9/4NJ//AIqvnH/hub4u/wDQA8Jf+Alz/wDJFOH7cvxd76B4S/8AAS5/+P1v/Y3E/wDz+f8A4MZH9oZN/wA+1/4CjxTxtptlovjXxBo2mxlLSw1S7trdSxYrGkrKoJPJ4A5rIqzrWrXOv61qGvXiRpcajdS3cqxghA8jlmCgknGScZJ+tVK/SKUZRpxU97K/qfJTacm47DqjanUhGa0IZ+nf7Nt6I/gV4MTd93TVH/jzV4Z/wUJn+06d4HGc7Z9Q/wDQYK8j8G/tc/EvwN4X03wlpGjeG5bPS4RBC9xbTtIVBJ+YrMATz2ArmPi38dvGHxnh0yDxTp+kWy6S0rwfYIZULGQKG3b5Hz9wYxjvX59lvDmOwuc/XqiXJzSe+tmnbT5n1GLzbDVsv+rRvzWitu1v8jzhVp4X8KQDFLX6CfLoCB61qeDzjxhoR9NTtf8A0atZdTafey6XqNrqduqNLaTJOgcEqWRgwzjBxkVFSLlBxXVFRdpJs/X7+0R/er83f2yn8/8AaD8QSdcwWP8A6Sx10X/Dcnxc/wCgB4S/8BLn/wCP1458RfHusfE7xbd+M9ftrOC+vViSRLRGSICNFQYDMx6KM89a+F4W4dxuU42VfEJcri1o763T/Q+kznNcNjsOqdG97p7eTPoP9hb4wP4f168+FOsXW2y1ktd6YWbiO7VfnjHpvRc/VPVq+yPGOi6P458L6n4R16LzbDVbZ7aZe4BHDL6MpwwPYgGvyY0zUb7RtStdY0u5e3vLGZLi3lQ4aORGDKw+hAr34fty/FwDB0Hwmf8At0uf/j9LiHhfE4vGrG4Cyb1etrSXVev5q/UMqzijQw7w+K2W2l9H0PFPHPg7Vfh94u1TwdrS4utMuGhLgYWVOqSL/sspVh7Gur/Zvfy/jr4Lk/u6mv8A6C1ZvxU+K+ufF/WrbxB4i0bR7O+t7f7MZNPhkj85ASV375HyRk4IxwcHOBjD8G+KtS8DeKdN8XaRDbS3mlzCeFLhWaNmAI+YKQSOexFfXShiMTl8qdZJVJQafa9rfceGpUqWKU4O8FJP5XP1v/tEf3q/K/46Nv8AjT44fru1+9P/AJGavT/+G5vi5/0APCX/AICXP/yRXhnijxDfeLvEmp+KdTihju9Wu5byZIFIjV3YsQoJJAyeMk/WvmOFMhxmUV6lTEpWkrKzv1PYzvM8PjqcY0b3T7GZnjFMkGafSNmvuD5xn6ffs5/Eg+Pvg74d1i4uDJe21sNPvSTlvPg+Qs3uyhX/AOB16FD9hgvrjUoYES5u1jSeQdZAmdmfpuP51+ZXwm/aG8efBrS77RvDFrpN1aX9wLpk1CGV/Lk2hSU2SJjIC5zn7o6V3P8Aw3R8Xv8AoAeEv/AS5/8AkivyvMODMdPFVJYVLkbbWttHra3l+h9rhc/wsaMFWvzJa6fI9Y/b6+IRtvCOh/D20nxJq90b+7UHnyIeEU+zSPke8VfECjArrfih8UPEvxc8TDxT4oS0juUtktI4rRHWKONSSAoZmPJZieeprkwK+8yHLXlOAhh5/Fq36v8Ay0XyPmczxaxuJlVjtsvQGPpX03+wZ4NGo/EDVfHl3FmHQLP7PbMR0uZ8jI+kayA/74r5jbpXqnws/aT8bfCDw9N4b8K6J4emguLpruWa8t5nld2VV5KSqMAKABj19arPMPicXgJ4fCL3paau2nX8NPmLLatGhiY1a/wrX59D9ML7XrXTbK41G9nEVvaxPPM5PCooJYn6AGvzA8QftH/GfWNe1LVrL4k+JbC3vbua4htYdSlSOBHcssaqDgBQQAB6V1fiz9sb4qeMPDOp+Fr7S/DlrbarbPaTy2ttOsojcYYKWmYDIJHIPBNeFha8LhjhqWWqpPHQi5StbZ2S/wA/0PSznNo4twWGk0lv0O5Px9+OH/RWfFf/AINZv/iq/R/4J/EU/EH4VeGvFc1x5l1dWKR3bZ5NzHmOU/i6MfoRX5Tla9Y+Fn7TPxB+EXhuTwr4dstFu7J7p7pf7Qgmd42YKCqlJUAX5c4x1J9a6eJeHVmWGisHCKnF+Suuv6GOUZr9UrN4iTcWvXU+mP28/By+Ifh7pfje1i3XPhu88udgP+XW4wpJ+kixY/3jXwcDxXuviv8AbE+JXjPw1qXhTWvDnhVrLVbZ7aby7W4DqGGNykzkBgcEEg8gcV4WBiuzhnA4vLcF9VxaWjdrO+j1/O5hnGIw+LxHtqHVa6df+GA17n+xTL5Px+0qTPSxvf8A0Sa8Mrpvhr8Rdc+FfiyDxj4etbGe9t4pIlS8R3iIddpyEZTnB45r08zw88XgatCn8UotL1aOPB1Y0cTCpLZNNn60/wBoj+9X49a6c67qR/6e5v8A0M179/w3Z8Xh/wAy/wCEf/AS5/8Akivni6uJLy6mvJQoeeRpWC9Mk5OPzr5rhHIsXk0qzxSXvctrO+1/8z188zKhj1BUb6Xvp3sMzximN3p1IR3r7VHzx+o/7NF6I/gP4KTd00xf/QmrS+KPwl+Hvxjh06Dx7ps96mlNK9qIrqSHaZAobOwjP3F618LeC/2wPib4E8K6b4Q0fRfDMtlpUAghe5trhpWUEn5isygnnsBWz/w3f8YP+he8I/8AgJc//JFflNbhPOI42eKwzUW5SaalZ6t/oz7alneXvDxo1rvRJq11pY+kf+GMv2d/+hXvv/Brcf8AxVH/AAxn+zv/ANCvff8Ag1uP/iq+bv8Ahu/4wf8AQveEf/AS5/8Akil/4bu+L/fw/wCEf/AS5/8Akit/7E4p/wCf7/8ABjM/7QyX/n2v/AUeHeOdLstD8ceIdF02Mx2mn6rd2tuhYsVjSZlUEnk8AcmsWrmuavc+Idc1DX71I0uNSupryVYgQgeRyzBQSSBknGSfrVInFfplJSVOMZb2V/U+Pm05Nx2AnFNoorVIkKKKKACiimk5oACc0lFFABRRRQAUUUUEsKKKKBBRRRQAUhPalJxTapIAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFADgc0U0HFOqWgCiiikAUUUUAFFFFA0wooooKClBxSUUAPopoOKdQAUUUUAFKD2NJRQA7Ao2ikB9adS2ATaKAMdKWimA4HNFNpQfWk0AuAaTb70tFIAHvTgB2ptKDigLjqKQEGlpD9Aoziiikx3FyD1pcCm0AkUhWHUtJkUtAXDPrS4B70lFAxdtKBim5Ipd3rS1AeCKWmUVIDsCl/Gm5NLuoAWikyPWloHcKKKKB3CiiigNAoGO9FFMNB2RRkU2ikMdketGR602igB3HrRketNooCw7IoyKbRQA7cKTPtSUUAFFFFMV0FFFFIV0FFFGRQFwoxSbqTJoEOpCwptFAAeaTbRuFJk09QF4FBb0pKKdgCkwDS0mRTFcMCjIFISTSUBYCc0UUU0h7BRRQSBTEFNJFBOaSmFwwKKKKBBQTikJ9KSmkAHnrSbRS0UwE2ijApaaT6UtwFJxTaKKYBRRRQAUUU0nNAATmkoooAKKKKACiiiglsKKKKBBRRRQAUdKKaTmmlcA60UUVQBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFKDSUUAOopAe1LUgFFFFIAooooAKKKKBphRRRQUFKDikooAf1opucUu4UALRSbhRuFAC0oOKbuFGRQA/rS0wH0pwOaWwC0UUU7gAOKcDmm0mR60NAPopocdzTqkApQaSigB+c0UylDetA9x1FGc0UrBqgoyRRRSsO4u71pabketJketIViSimhqXIoDUWjJoooHcXdS5FNopWAdRTcn1pdxpWAdk0u6mbh3o3iiwD9wpcj1qLd9KXdRYCSio9wpQfQ0APopuT60ZNIB1FNyaQtjvQA+imbzRv8AenYB9FNyaMn1pAOophPqaTdTsBJketJuFM3e1LkUWAdupNxpMj1pNwosA7NJTS+KTf8AWiwD80m4U3INLTsAZNFFFMLhRSZFJu9KBDqTd6U2jIoHYCSaKTIpadgugooop2FqwopC3pTSfU0w2FLelJSbhRu9qBC0Um6jcO1FgFJxTSc0UU0gCiikyKdwFoppYCmls0twHE5pKTcKNwpgLRSbhRuFAC0Um4UhOaAAnNJRRQAUUUUAFFFFBLYUUUUCCiiigAoopCaYAT2pKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKUHNJRQwHUUA5oqACiiigAooooAKKKKBphRRRQUb3gDwXqvxI8deH/AIfaHcWkGo+JNTttKtZbt2WBJp5FjRpCqswUFhkhScdAa+wv+HQf7Snbxz8Mv/BnqH/yFXzd+yy239pb4Vt6eMtH/wDSuOv36+1D1r5zO81rZfUhCnbVHoYLCRxMW5dD8l/+HQv7Sv8A0PPwy/8ABnf/APyFR/w6E/aU/wCh5+Gf/gyv/wD5Cr9aPtQ9aPtQ9a8T/WXFd19x2/2ZTPyWb/gkL+0qFJHjf4aMR2Gp3+T/AOSdc74g/wCCV/7WOi2zz6dpvhbXnXpDp+tKjt9PtCxL+Zr9i/tQ9aPtQ9apcTYlb2fyD+zKfmfz2fEr4J/Fv4O3q2PxN+HuteHmdtsct3bHyJT6RzLmOT/gLGuLDV/Rvr+k6D4q0e78PeJtIstV0u/jMN1Z3kCzQzIeqsjAgj6ivyZ/b8/Yl074Fyp8VvhZBKPBOo3K295pxZpG0i4f7m1ySTA5BALHKthcncuPby3iCnjZqjVXLJ7dn/kcWJy+dGPPHVHxgD606o1PalzgV9BY887z4IfB3xP8ffiZpXwr8H3+l2erawtw0E2pyyR2yiGB5m3NGjsMrGwGFPJHQc19Sf8ADob9pP8A6Hj4Z/8Agyv/AP5Crzf/AIJvSbP2xfBDZ6Q6r/6briv2u+1D1r5nOc3rYDEKlTtZq+3mz0sHg4Yim5S7/wCR+Sl3/wAEj/2kLK1mvJfG/wANSkEbSMF1K/yQoycf6H7V8TKx9a/o2126H9iahz/y6y/+gGv5xlrpyPMquYqftfs2/G/+RnjcNHD8vL1uTA5optAJFe7Y4R1FAINFIApQ3rSUUAPyKRFkmkWKJGd3IVUUZLE9AB3NNJwK93/Ya+GH/C1/2m/B+kXVv52m6Nc/2/qAIyvk2uJFDDurS+Sh/wB+sq9WNClKrLZJsuEXUkorqexWn/BJH9pW6tIbl/F/w5tmmjWQwzalfb4yRna22zIyOhwSMjgmpf8Ah0V+0n/0PHwz/wDBlf8A/wAhV+sf2oetH2oetfEf6yYnuvuPb/s2mfk4P+CRX7SXfxx8M/8AwZX/AP8AIVfIXxA8Ea98M/HGu/D7xPHGmqeHr+bT7ryiWjZ42K70JAJRsBlJAypBwK/og+1D1r8l/wDgqv8AC8eF/jdpXxNsLfbZ+NtOC3DAcG+tAsb59Mwm3+pDV6mUZ1UxmI9jWtqtPX/hjlxeCVCnzxPiml3Gmqc0tfTWPN0HZFLTKKQrD6aWpCxAr0/9nj9nrx1+0j48j8G+DoVgtoAs2q6rMpNvp9uTje2PvOeQiA5Yg9AGZYqVIUYOpUdkioxlNqMdWec6Xpeq69qNvo+h6Zd6jf3biO3tbSFpppnPRURQWY+wFfUvw1/4JlftReP4Ir/WNF0nwbZy4YNr14VnK+vkQrI6n/ZcIa/TP9n39mX4R/s4aEmn+BdDjl1aWIJfa7dor312e+Xx8iZ6RphRgZBOSfXftQ9a+UxXE3vcuHWnd/5Hq0ssdr1Gfmzpv/BHHW5YVbWP2gLC1mx8yW3hx51B9ma5Qn8qztc/4I8+P7eCRvDXxr8P38wH7tL7S57RWPuyNKR+Rr9N/tQ9aPtQ9a4FxDi735vwX+Rv/Z1LsfiF8V/2D/2nvhBaS6rrPgCTWtKhyZL/AECX7fGgHVmjUCVFxzuZAPevn7cwJBGCODmv6PvtQ9a+VP2sv2Evhx8frDUPFnhKztfDXxA2NLFfwr5dtqMg5CXaKMEt080DeMgneBtr08HxLCclDEq3mv1RzVssklem/kfjeHz2pd3tWl4u8I+JfAPifUfBvjDSJ9L1nSZzb3dpOMNG457cEEEEMCQwIIJBBrLBzX1KtJXWx5b00YpbAr3D9mr9kL4lftUQ+IZvh9rnhnTl8NNapd/2zc3ERc3AlKeX5UMmceS2c46jGeceGtX6Sf8ABHqby7H4rZPWbRf/AEG8rhzPESweFlWhurfi0jfDU1WqqD6nm/8Aw6M/aS/6Hf4af+DK/wD/AJDrg/jj/wAE8/jV8APhtqXxR8ZeKPBN7pWlyW8c0OmX13JcMZpViXaslsinDOCcsOM9elfs79qHrXzD/wAFJrgP+yF4uXPW60v/ANLoa+cwmfYivXhSk1ZtLbuz0auAhTpykuiPxiV+2KC2O1RqaGavsrHj3JIknuZo7a3heWaVgkcaKWZmJwAAOSSe1fZXh/8A4JRftM69oVhrVxrvgTR5L63S4aw1HULtbq2LDPlyiO1dA4zggMQD3r07/gm5+x4oax/aN+J+l9MTeFNOuE/K/dT/AOQs/wDXT/nma/SP7UPWvl8zz76vV9jh7O278+3yPTw2A9pDnqddj8nR/wAEi/2kv+h4+Gn/AIM7/wD+Q64j4zf8E8fiv8BvAN98RfiF8R/hxb6bZERxwwajfPcXc7Z2QQobQB5GwcAkAAFiQoJH7CeKvGfh7wR4c1Hxb4r1aDTdI0m3e6vLqZsJFGo5PqT2AGSSQACSBX4m/teftT+Iv2nviI2qsZ7HwnpDPBoOlu3+rjJ5nlA4M0mAT12gKoJxk3leYYzManTkW7t+HqTisPRw0fNnhQORQTigYAprGvpTzbn0b+zv+wl8Xf2mPA114/8AAfiTwfYadaanLpTxaveXUUxljjjkLARW8i7cTLg7s5B46Z9P/wCHRf7SX/Q8fDT/AMGd/wD/ACFX0j/wSdn8v9mvWQTj/isb0/8AkpZ19o/ah618hjs9xGGxM6UbWT7HsUMBCrTU31PxG/aN/Yg+K/7MHhPTfGPj7xF4S1Cy1TURpkMej3dzLKspieTLCWCMBcRtyCTkjjvXz2G4r9Vv+CuM4k+BnhEZ6eLI/wD0jua/Kda97KsVPG4ZVp73Z5+KoqjV5EO3UmTRRXomGiCiiinYVxYkaaZIEIDSMEBPTJOK+2j/AMEif2kv+h4+Gn/gyv8A/wCQq+J7I4v7b/rsn/oQr+jv7UPWvCzvMquX+z9n1v8Ahb/M78Fho4jm5ulj8nP+HRP7Sf8A0PHw0/8ABnf/APyFXyn8YfhZ4h+CPxJ1v4W+K73TrvVdBkijuZtOkeS3cyRJKNjSIjH5ZADlRzn61/Qf9qHrX4e/t/Pv/a/+Izet1Z/+kNvWOS5tWx9eVOpayV/xX+ZWMwkcPBSj3PAt3pSUg6UjGvpTzbgWro/Afw1+IPxS1keH/h14N1bxFfnBaKwtWl8sHo0jAbY1/wBpiB717J+xv+yPrX7T/jCabULmXS/BehSxnWNQQfvJWPItoMjBkYDJY5CKQSCSqt+yPw1+G/w++EHhiDwf8N/C9loelQc+Vbp80r4wZJXOXkc45ZyT714eZ55SwEvZRXNP8F6/5HdhcDPELneiPy88C/8ABJv9orxHHFdeMNd8LeE4nUF4Zrt7y6QntshUxn/v7XpEH/BGzVWgLXX7QlnHPjhI/DDOpP8AvG6B/Sv0l+1D1o+1D1r56XEeKk7qSXyX63PQWW01uj8sPFn/AASB+MWnWzT+Dfif4U1uRckw3kU9izD0UgSrn6kD3r5X+MH7M/xy+BE7L8TPh7qWnWe4KmpRKLixkJ6AXEZaME/3SQ3tX77/AGoetVdUtdL1vTrnR9asLa/sLyJobi1uYllimjYYZHRgQykdQRitqHE9aD/epSX3P+vkRPLIte7ofziBqdX3R+3z+wppvwptbj4z/BqxaLwnvUazo4ZnOmO7BRNETkmBmIBUnKEjGVOE+FQ2K+vwmMpY6kqtF6fl5M8itRnQnyTFJxX0B+zd+xL8Vv2o/DereKPh/wCIfCen2uj3wsJ01m7uYpGkMavlRFBICuGHUg57V8+Oc1+qX/BIWYR/CLxwM9fEif8ApLHXNmuKngsK60N01+ZphKSr1VBnhv8Aw6F/aU/6Hn4Z/wDgzv8A/wCQqT/h0J+0p/0PPwz/APBlf/8AyFX60fah60fah618p/rLiu6+49X+zKZ+S/8Aw6E/aU/6Hn4Z/wDgyv8A/wCQqP8Ah0J+0p/0PPwz/wDBlf8A/wAhV+tH2oetH2oetH+suK7r7g/symfkv/w6E/aU/wCh5+Gf/gyv/wD5Co/4dC/tKf8AQ8/DP/wZ3/8A8hV+tH2oetH2oetH+suK7r7g/symfkt/w6E/aV7+Ofhl/wCDPUP/AJCr5z/aO/Zw8cfsv+NrHwH4+1XQtQv9Q0qPV4pNHnmlhELzSxBWMsUbb90DkgKRgrz1A/fX7UPWvyS/4K5SeZ+0Z4abP/Mk2g/8n76vUyjOq+OxKpVLWs+hzYvBQoU+eJ8R0UDpRX1R5QUUUUCbCiiigQUUUUAFFFBOKAAnFNo60VSQBRRRTAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApwOabRSaAdRQDmipAKKKKACiiigAooooHex6X+zCdv7SHwub08YaQf/ACbjr95PtR/vV+C/7NDbf2ifhk3p4t0k/wDk1HX7n/a/evznjWt7LEUl/df5n02RU+enN+Zs/aj/AHq/Nn4if8FTfiv4N+IPifwhZfDnwpPbaFrN7psMsr3O+RIZ3jVmw+MkKCcd6/Q37X71+DfxxOfjZ8QG9fFOrH/yblrDhKhQzKrUjXjzWSsaZxOphYQdN2uz7A07/grr8TYrlH1b4TeGbm3B+eO3vLiByPZm3gf98mvtX9mj9rT4f/tN6DdXnhmO50vWtLCf2lo92waWAN92RGHEkZII3AAgjDKuRn8NT0r60/4Jix61/wANIyXOm+YLOHw9e/2iV+75JeIIG/7a+WQPb2r6DPMkwVHBTr0Y8soq+71t017nnYDHV51405u6eh+v32o/3q4n42+E7H4j/CHxj4H1GPzItX0a6gXjJSXyyYnA9VkCMPdRW79r965H4u+PLH4ffC7xX401CdY4tI0i5uRlsb5BGfLQH+8zlVHuwr83w+Lm6sFT+K6t630PpqlFKD5trH4LqelOPSmr2px6V+6nwR9If8E6n2fte+Cm9IdU/wDTfcV+zv2o/wB6vxc/4J7vs/a18GN6Q6n/AOm+4r9ivtfvX5lxnX9lj4r+4vzkfU5JT58O35v8kXNcuj/YuofN/wAusv8A6Aa/nfXpX9A+tXf/ABJr/n/l2l/9ANfz7q3HNejwRV9qq/8A27/7ccue0+R0/n+hLRRRX3dzwAoBNFFMBwINFNoyRSsAMa/Sv/gk78Nhpnhfxf8AF6+t8TatcpomnuwwRBCBJMw9VaR4x9YTX5pgPK6xxozO5wqqMkk9AK/c39nrwBH8Ifgt4R+H3lrHcaXpsZvQB1u5My3B9/3rvj2xXyfF+P8AqeDVFPWb/Bav8bfeevk2Hdau59I/m/6Z679qP96uT1H4oaNpvxQ0P4WTOP7R1zR7/V4ju+6ttLbpsx3LCaRh7QtWn9r96/Ov41fHT+xv+CkvhG+F5t0/wx9h8Mznd+7CXiN5zH/dN5z7xD0r4XKqUsyqThH7MJS+5afjY9/FyWFjGT6tI/S37Uf71fMn/BRL4a/8LK/Zs1jUbSDzdS8HTJr9sQPm8qMFbgZ9PJd3I9Y1r6C+1+9VdTgsdZ0270jU4EuLO+gktriJx8skTqVZT7EEiuTCZm8LXhWX2WmbVsJ7Wm4Pqj+fpDUldH8UvAt78MPiR4k+H9+WMmhalPZq7DBliVj5cn0dCrD2auaDcV+2wnGrBTg7pq6+Z8LKPK3GW6HUUmRQxqhFnStL1HXtVstD0ezkur/UbiO0tbeMZeWaRgqIPcsQB9a/cP8AZi+Bmhfs6/CnTfBGnJFJqkqrd63fKObu9ZRvOeuxfuIOyqO5JP5q/wDBOP4dQeNf2hYfEeo26y2Xg2xl1UBhlTdMRFAPqC7SD3iFfrV9r96/PeMM1cK0cFB6JXfq9vuWvzPo8lwfNB15LfRGz9qP96uO+Knxo+HnwW8MyeLPiP4mt9JsQSkKsS01zJjPlwxj5pG9gOBycDJrQ1DWrPSrC51TUblLe0s4XuJ5XOFjjRSzMfYAE1+Jf7SXx58Q/tC/E7UPGOp3E6aVFI1vomnu3yWdmD8oA6b2wGc92PoAB5GQZfPOazTdoR3f5JHZmOIWBgrK8nsfaviz/grn4ftr2SDwN8G9R1G0HEd1qmrJaOfrFHHKP/H60vAH/BWfwJq+oRWXxG+Geq+HIJGCm9sL5dQjT/adCkbhf93efY1+YwHoKCvqK+9fDeXOHLyP1u7/AJ2/A+fWZ4i9+b8Ef0I+E/G/hrx14esvFfg/XLXV9I1GPzba7tZN8ci5wfoQQQQcEEEEAgitb7Uf71flF/wTT+OGo+Dvidc/CTVtSI0DxTBLcW0csmEt7+FC+9SeFDxI6t6lY/Sv03/4STR/+gvZ/wDf9P8AGvzrOMLUynFPDt3W6fdP+rH0mCqxxlJVFo9n6nxt/wAFQPgNp+v+Drb4+aDZbNY0ForDWjGv/HxYu22OVvVo5GVc/wB2Q5OEGPzKVq/eDx9beGfHvgjX/BOp6pYNba7ptxp8m6ZCFEsbLu69QSCD2IFfhDNBLbTyW06FJImKOp6hgcEV9nwhmEsXhpUJ7wat6P8A4ZniZxhlRqqovtfmhrGv0X/4JFy+XZfFPnGZtG/leV+c7dK/Qv8A4JOTeVZfE/nrLo/8ruu/iefs8qqy/wAP/pSOfKo82LgvX8mfo19qP96vmf8A4KNXG/8AZJ8WLnObrTP/AEthr3/7X7180f8ABRS8/wCMVfEkef8AWXumr/5Nxn+lfm+UYnnx9GP96P5o+mxlHlw835P8j8hw2K+rf2FP2Spfjv4sHjrxxYOvgPw/cDzUcEDVrpcEWy/9MxwZD6EKOWJXyL9m74C+IP2h/iRaeDtLMlrpkGLnWdRC5WztAcEjPBkb7qL3JyeAxH7SeCvC/hv4eeFdM8FeENNi0/SNIt1trW3jHCqOpJ6szElmY8liSeTX3XE2frLofVaL/eS3/ur/ADfT7+x4OVZc8S/azXur8WdjA8NtDHbW0aRRRKEjjRQqooGAABwAB2pZb+OCJ5ppljjjUs7s2FVRySSegrI+1+9fnv8A8FBf2wmlF98APhnqny8w+J9Rt36+tijD/wAikf7n98V8LldCtmuIVCj832Xc97FThg6bqT+Xmeaft5/tiT/HLxE/w18A6k48B6JcZkmjYgaxdIcecfWFTnyx3++eqhfkZR3pFHtTq/XsJhKeCoqjSWi/HzZ8dVrSrzc57hSNS0x+9dCRlc/V/wD4JWTeX+zlrC5/5m+8P/kpaV9kfaj/AHq+Jv8Agl1P5f7PGrrn/mbbw/8AkraV9gfa/evx7PcTyZlWj/ePtMvo82Gg/I+O/wDgrFN5nwR8JDOf+Kqj/wDSS4r8tl7V+nP/AAVTn8z4LeFBnp4pQ/8AkpcV+YqkV9/wpP2mWRl5v8z53N48uKa8kPopN1Jk19IeboOyKaW44pKD0oC5JZk/brb/AK6p/MV/RH9qP96v527P/j+tv+uqfzFf0F/a/evguNq3snQ/7e/9tPoMihz+0+X6mz9qP96vxR/bzbf+1v8AEJvW6s//AEht6/ZX7X71+Mn7dD7/ANq/x+3rc2n/AKRQVx8F1/a42a/uP84m2d0+ShF+f6M8MHSmMf1pQTirWhz29trmnXN4AYIruF5Qe6BwT+ma/SXornzC1P3S/Zs+FunfBH4LeGPANlapDdW9lHcao6jDTX8qhp3Y9/nJUZ6KqjoBXpv2o/3qxfteeQ1L9r96/CquYSrVHUm9W7n30MMoRUYrRHh37Vv7bXgz9mRLTQzpMviLxZqMH2m30uKcQxwwZKiWeTDFQSrBVCkttP3RzXxnef8ABWX9oKS7Mlh4J8AwW2flils7yRsehcXK5/ACsr/gpl8NfF2lfGv/AIWfNZXFx4d8QWVrBBeKpaK3uIY/LaBj/CxChxn725sZ2tj47GK/TMjynAV8DTryipuSu359vlsfL4/F4inXlTTsl/X4n6ofs5/8FOtB+JPiew8C/FnwvB4X1HU5VtrPVLO4aSxknY4WORX+aHJwA25xk87RzX2/9qP96v50d20hkbBHIIPQ19z6P/wVb8eadpNlp958LNJvp7W3jhlupNTlDTuqgGQjZwWIJ/GuDOuGqjnGeWx0e6vt6XZ0YHM48rWJfo7f5H6c67puleJtFv8Aw7r1lFe6bqdtJZ3dtKMpNDIpV0YehBIr8Cviv4Duvhf8TPE/w9vHLv4f1S4sVkP/AC1jRyI5P+BJtb8a+yB/wVm8af8ARHdG/wDBrL/8RXyL8bPijcfGn4pa78TrvRYNJm1x4ZJLOCUyJGyQRxHDEAnPl7unVjXXw1l+YZfVmsTG0Gu6eq9H2uY5niMPiIRdJ3a8uhw5GRX0n+y1+214g/Ze8Lax4X0jwJYa7HrGoC/eW5vXhMbCNU2gKpyPlzmvm2jANfUYnDUsXT9lWV4nlU6s6MueDsz79/4e7+N/+iM6L/4Npf8A4ikP/BXjxv8A9EZ0X/wbS/8AxuvgLbTG4+ted/q/lv8Az6/F/wCZ0/2hif5vyP3a/Zh+OOofH/4O6V8T9T0ODR7jUZ7qFrSCZpUQRTNGCGIBOQuenevVvtR/vV8nf8E6LjZ+yl4aXPS91L/0rkr6Y+1+9flWZ1Y4fG1aNPRRk0vkz63C03UoQnLdpHgn7Z37Xmt/stW3hKfRvB1lr58SSXySC5u3h8nyBCRjapznzj+VfMX/AA958b/9EY0X/wAG0v8A8brT/wCCtUvm6f8ADAZ6Tax/6DaV+dgFfecP5Vgsdl1OvWheTvrd9JNdz5/McVXw+JlThKyVu3ZH6A/8PePG/wD0RnRf/BtL/wDG6+X/ANqH9o7Vf2nvH2n+PNX8MWuhTafpEWkLb29w0yuqTTS7yzAEEmcjH+zXkGBRX0OGynB4Op7WjC0vV/qzzquLrVo8s5XXyCiiivQOVsKKKKBBRRRQAUUUE4oACcU3rR1oqkgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFOBzTaKTQDqKAc0UgCiiikAUUUUAeifs3nb+0H8NW9PFelH/yajr9uPtR9TX4h/s7Hb8fPhy3p4p0s/wDkylftH9rHrX5P4hzccVRt/K/zPs+GIqVGd+/6Gz9qPqa+APHf/BNTxT4w8c+IvFsPxV0m2j1vVrvUkhbTZGaJZpmkCkh+SN2M+1fc32setH2setfHZbneNymUpYWVnLfRP8z3MVl9DGJKsr287HwPpv8AwSv1lrpP7Y+MtlHbA/P9m0Z3cj0G6VQPrz9DX2D8BP2fvh3+zv4dm0TwRazy3V+yvqOp3bK1zdsudoYgAKi5O1FAAyTySSe3+1j1o+1j1rfH8SZnmdP2WJqXj2SSXzslf5meGyrCYWXPShr33/Ml8S+NPDfgzSJtf8W6/YaPp1uMyXV7cLDGvtuYgEnsBye1fmd+2t+2dD8bQvw1+HElxH4NtJ1mu7yRTG+qzIcp8h5WFT8wDcs2CQNor7Q+K/7L/wAFfjNfT6x428P3kuqzKFF/b6lcRyRAKANibzEOAOChHfrXwd+0v+xP4m+CdnN4z8I6jN4i8JRt+/keMLd6eCcAzBeHTkDzFAGeqrwT9Jwd/ZH1mMq837b7KkrRv5O7u+17eSueXnixvsmqcV7Pq07u3norLva/qfNS880p6UxTinE8V+vHxZ9CfsBvs/as8Ht6Ral/6QT1+u/2o+pr8gf2EH2ftSeEX9ItR/8ASGev1l+1j1r8d8QJyjmcEv5F/wClSPtuG4p4SV/5n+SLus3R/se+5P8Ax7S/+gmvwOXpX7s6xdj+yL7n/l2l/wDQTX4TL0r1vDmTlHE3/uf+3HHxPFRdK3n+hJnFODU2iv0yx8qPopmcUob1pWaAdSHpRSMaLgez/sdfDofEz9obwrpVxB5thpVx/bV8CMr5VthwGHo0nlIf9+v2R+1H1NfBH/BMzwANO8P+KfilewYl1KdNHsWIwRDEBJMR6hnaMfWI19vfax61+K8b5i8Vmjowfu00o/Pd/nb5H3eQYVUsIpyWstfl0/z+ZrT6jFbQyXFxKI4olLu7HAVQMkk+mK/C74leNbnx38S/Enj/AM2RJdZ1i51GI5IaNXlLRgem1doH0Ffq/wDtZfEL/hAf2fPGWsQzeXdXdgdLtcHDebckQ5X3VXZ/+A1+O4IxivovDzCt0q2Ln1aivlq/zR5nEtVKcKK6a/ovyZ+6Pwl8fp8Rvhj4W8cxuC2taVbXcwXoszIPNT/gL7l/Cus+1H1NfG3/AATh+In9vfBa98FXM+648J6m6RpnO21uMyof+/n2gfhX1h9rHrX5/nGHnl+Pq4bpGTt6br8LH0mBqRxOHhV7r8ev4n51/wDBTT4df2L8T9E+Jtlb7bfxRY/ZbtgP+Xu2wuSf9qFogP8Arma+N1r9Yv23fAI+I37Puu/Z4PM1Dw2V120wOf3IPnD15haXjuQK/JtTX63wXmDx2VxhJ+9TfK/Tdfhp8j4zPcN9Xxba2lr/AJ/iPpGpaa1fWHjH6Hf8EsdJjtfDHj7xKUHmXd/ZWIbuBFHI5H/kYfkK+6PtR9TXxJ/wTLuY4/hN4piH3x4jLH6G2hx/I19hfax61+D8V1pyzivfuvwSP0TJ6cfqNP0/U8o/bY8YT+Fv2ZPG11bSOk1/axaWpU4ytxMkUg/79u9fjymK/U3/AIKBvLP+zXqvlsQsepWDSe6+cB/MivyxXtX6BwBFf2ZOfVzf5RPm+I3bFRj/AHV+bJhRTKWvuDwLgVppWnZPrSbhQGgBRTgMUgb0xRuNAaA1ff3/AASrl8uz+JmD1l0j+V3XwAx9q+8v+CXc3lWfxI95dJ/ldV8xxk2slrNf3f8A0qJ6uRpPHwXr+TP0C+1H1NfOP7f1rqWvfs73WgaPaS3d/qet6ZaWtvEMvLK9wAiKO5JwK91+1j1qte2+n6i1s9/aRzmznFzB5i58uUAgOPcBjg9uvWvxjAY6WCxVPE2vytO3ex91iMMq9KVLa6scH+y98C9J/Z7+GNp4YiSKXXb4Lea5epz590R9wHr5cYOxR9WwCxr177UfU1jfax60fax61nicbXxdaVes7yk7sulh6dGCpwVkjwn9ub9oDxZ8E/hfbx+DLC6TU/E80mnR6uo/daaAmWbPaZlz5f8Auu2cqAfyaMkk0jTTOzu7FmZjksT1JPc1+1/xU8AeHPi74C1bwB4ni3WeqQlFlCgvbzDmOZM/xIwBHrgg8Eivxv8AiH4C8Q/C/wAa6r4E8T2/lahpM5hcgHZKnVJUJ6o6lWB9DX6jwBjMNUw08PFWqp3f95dH8trfPqfI8R0KsKsard4PReT/AOD/AFsYQ6UtMByKK/QT5u47I9aa5HNFNbvQgufp/wD8EyZ/L/Z+1ZQf+Zquz/5K2tfW/wBqPqa+OP8AgmzOI/gJqq5/5mi7P/kta19Xfax61+BcSzks2xCX8zP0bKoJ4Om/I+T/APgqHMZPg34WGenidD/5KXFfmkv9K/R3/gpnN5vwg8MD08Sof/JWevziX+lfp/BDcsng33l+Z8ln6tjWvJfkOoooyK+uPFCg9KTdSZJppASWhAvbf/rqv8xX75faj6mvwLtP+Py3/wCuq/zFfu39rHrX5j4jScXhrf3/AP20+r4Yipe1v/d/U2ftR9TX47/tutv/AGp/Hretzaf+kcFfrf8Aax61+Rf7aT7/ANp/x03rcWv/AKRwV5/h9NyzGpf+R/8ApUTp4lio4WNv5l+TPFR0prCnDpQ3Sv1658WfsX+yF8c9P+M3wY0a7a9Vte0K3i0vWYC+ZFmjXasxHXbKqhwemSw/hNe2faj6mvw5+E3xg8c/BTxbF4w8B6p9muQPLubeQboLuHIJilT+JTjtgg8gg81+jPwd/b7+DvxFtoLHxdejwXrjYV4NQkzaO3rHc4Cgf9dNh+vWvx3iThbGYKvLEYOLnSbvZauPlbe3Z9tz7fKs2oV6apV3aa77P/gn1Fq1lpWvadcaPrmm2uo2F0nlz2t3Cs0Mq/3WRgVYexFfOXjv/gn3+zd4zklutN0PUvC1zKSxfRr0rHu/65Sh0Ueyhfwr3ix1qw1S0jv9MvoLu2mG6OaCRZI3HqGUkGp/tY9a+TwuZ43ASvh6jg/J2+9f5ns1cJQxC/eRTPgHxv8A8EufEtqslx8Ovidp2odStrq9o9qwHp5sZkDH/gCivmL4o/s5fGf4OM83jrwNfW1ghwNStwLizOTgZmjyqk9g21vav2b+1j1qO4a2vLeS0u4I54JkMckUihkdSMFSDwQR2NfUYHj3MsO0sSlUj6Wf3rT70zyMRw7haq/dXi/vX4/5n4QdacOlffH7XH7EWinS7/4nfBTShZ3NopuNS8P2yfuZoxy0tso+4wHJiHBA+UAja3wMpr9TyjOMNnVD2+Hfqnun5/o+p8jjcDVwFT2dVej6MdRSEikJzXqHIBb0prdaWkbrTA/W3/gnrOY/2WvDi5P/AB+aj/6VyV9Ifaj6mvl39gK4Ef7MXh1c/wDL3qH/AKVSV9E/ax61/POfVJLNMQl/PL82fpWXQTwlJ/3V+R8Qf8FWJfNsPhnntNq//oNpX59LX3x/wVIm82x+G/tNq3/oNrXwOvSv17gxt5JRb/vf+lyPis893HzXp/6ShaKKK+nPHCiiigAooooAKKKCcUABOKb1ooqkgCiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUoPY0lFADqKQH1pakAooopAd7+z62347fDxvTxPph/wDJlK/Y/wC1D1r8bPgI2344eAG9PEumn/yYSv16+1n1r8n8Q1fFUf8AC/zPteFv4NT1/Q2ftQ9a/F34w/N8XfHB9fEepn/yakr9iftZ9a/HT4ttn4seNG9fEOpf+lMlX4dq2Ir+i/Ni4p/hU/V/kcvDLNbyCW3meKReQyMVI/EV9G/szfte/ED4a+LtN0Dxj4kvda8IX06W1zFfzNM9irHAmhdiWUKTkpnaRngHBHzfketbXgrwhrXj/wAV6Z4P8PWrz32qXCW8YVc7AT8zt6KoyxPQAE1+j5lg8LjcPOni4pxs9X080+lu58phMRWoVYyot3v9/kftr9qHrUF6llqVnPp2oW8Vza3UTQzwyoHSSNhhlZTwQQSCDWXFP5UaRhiQihck5JxTvtZ9a/nOzTuj9U33PyM/aA+G8fwl+L3iPwPabzY2dyJrBn5JtZVEkQz3KqwUnuVNefnpX0f+37NbTfHsGD766JZib/f3Skf+Ola+b/4a/ojJsRPF5fRrVfilFX9bb/M/L8fSjQxVSnDZNnvH7DT+X+054Tb0i1H/ANIZ6/VX7UPWvyj/AGJ38v8AaU8Kt6R6h/6RTV+of2s+tfl/iAr5nD/Av/SpH1/DP+6S/wAT/JF7V7of2Ve8/wDLvJ/6Ca/D1elftTq12f7LvOf+XeT/ANBNfiqrCvX8OVaOJ/7c/wDbji4p3pf9vfoS0U0N70bvpX6WfJjqKTd60tABSDe7BEUszHAAGSTQelerfss+Ax8Qfjn4a0ueHzLLTp/7WvQRlfKt/nAYejOI0P8Av1z4vEQwdCeIntFN/caUKUq9SNKO7dj9OPgV4Jj+F3wi8L+CDGI7jT7BDeAd7qTMk/1/eO+PbFd59qHrWN9rPrR9rPrX8416k8RVlWqfFJtv1ep+qU6caUFCOyVjk/jf8GPC/wAe/DVn4U8Xa3rdjYWd6t+F0uaKJpZVRkXeZI3yAHbgAcn2rxT/AIdxfAr/AKGvx1/4HWf/AMi19L/az60faz616GEznMMDT9jhqrjHsjmrZfhcRPnqwTZ5n8DP2Y/AX7P2s6nrPgvxF4mu21a2W2ubfUrmCSEhW3K4EcKHcPmAOcYduOmPZftQ9axvtZ9aPtZ9a48Via+OqutiJOUn1ZvRoU8PD2dJWRqXJtr22ls7uNJYJ0aKWNxlXRhggj0INfjN8WPA8/w1+JfiTwLMHxpGoSwwM3V4Cd0Ln/ejZG/Gv2F+1n1r4H/4KHeBBYeM9B+JFnDiLWrU6feMo4+0QcozH1aNsD2ir7HgLHfVsfLDSelRfjHVfhc8LiTDe1wyrLeL/B/8Gx8lBjigmmrSnpX7DY+GPuX/AIJoeJ4o4vHPhSSTEm6y1CFfUYkjkP4fuvzr7i+1D1r8nP2RPiRH8Nfjho15ez+Vp2thtGvGJwqrMV8tj2AEqxEnsM1+pX2s+tfivHGClh81lWtpUSa+Ss/yv8z77h6uquDUOsW1+v6nD/tPeF5vH3wF8ZeHLSEzXTaeby3jUfM0tu6zqq+5MePxr8iFNftcbrIwcV+aP7Vn7N+r/CjxTeeLPDOmSTeDdUmaaF4ULDTnY5MEmPurknYx4IwM5HPscA5pToueX1XZyfNHzezXrorfM4eJMFKajiYK9tH6dH+Z4GDmgnFRCT2oMgr9RsfHm34S8I+JPHniK08KeEtLk1LVr4uLe2jZVL7EZ25YgDCqx5PavSv+GPv2kv8Aol93/wCB1p/8dr6C/YW+AmseGZ5vjB4y06SzuLq2a20W1nTbIsT433DKeV3AbVzyVLHoVJ+yftZ9a/Os941q4HGPD4KMZRju3d69bWa229bn1OXcPwxNBVcQ2m9krbfNH5aj9j79pHv8L7v/AMDrT/47XkEsUlvNJbzAB42KMAQcEHB5HBr9dfjN8RIPhv8AC7xJ4xmlCSWNjILYZwWuX+SFfxkZfwya/IZe1e1wtnWLzunUq4iEYxi0la+r3e7e2h5+cZfQy+cYUm23du9vl0XmK3Wvub/gmXKIrP4ic9ZNK/ldV8Mt1r7Z/wCCbk3lWnxA95NL/lc1fGSvktb/ALd/9KiTkP8AyMKfz/Jn3Z9qHrR9qHrWN9rPrXnf7QPxT1H4TfCbXPHGkWcVzf2aRQ2ySn5FllkWNXYdwpfdjvjGRnNfieHw08VWjQp/FJpL1eh+gVakaMHUnsld/I4b9rz9rFPg5pf/AAhfga7hm8aX8YcyFVkTTIT0kdTkGRh9xD2+Y8bQ3qXwF+NOlfGz4bab4zsjHDeEfZtTtFOfs14gG9f905DL/ssvfNfkPres6t4l1e81/XtQmvtRv5muLm4mbLySMckk/wCQK9h/ZM+OknwW+IscWq3ZTwzr5S01RSflhOf3dx/wAk5/2GbqcV+nZhwTSpZTyYdXrQ95v+buvT+XzXmz5HC5/OeN5qulOWlu3Z/5/wDAP1b+1D1r5b/bm+Aq/ErwcPiP4Zs9/iTwxAxnSNcve2Ayzp7tHkuvsXHJIr6JS+WRFkjdWVgCrA5BHqKU3WRg4r85y3G1srxUMVR3i/vXVP1PqsVhoYui6NTZ/wBXPxSU0+vff2w/gUPhR46PiXw9Z7PC/iSV5rdUX5LO56yW/oF/iQf3SQPuE18/hu1f0BgMbSzHDwxNF+7Jfd3XqmfmeJw88LVlRqbofTW70ZNNcn9K7EjA/SL/AIJzziP4Faouf+Zmuj/5LW1fU32oetfJH/BPWfy/ghqa5/5mW6P/AJL21fT32s+tfgPEsf8AhWxH+Jn6VlP+5UvQ+Yf+Cks4k+EnhoZz/wAVGn/pLPX53Kx/Sv0B/wCCi0/mfCnw4PTxCh/8lp6/PwNX6hwOrZPH1l+Z8hxD/vz9F+RJRTN3vS7vpX154g6ikDUtK4C2v/H3B/10X+Yr9xftQ9a/Dq1OLuD/AK6L/MV+1n2s+tfmPiMrvDf9v/8Atp9dwttV/wC3f1Nn7UPWvyc/bIcP+0v43bPW4tf/AEkhr9SvtZ9a/K79r5t/7SHjRvWe2/8ASSGvP8PlbMan+B/+lROnif8A3WP+JfkzyENxxSYZztUFj6AZpB0r2f8AY412LQf2i/Cc1w4SO7e5siSf4pbeRUH4uUH41+rY2u8JhqmIjHmcYt22vZXsfG4ekq1WNNu12lf1PGTDMP8Ali//AHyaaYZgCTE4A/2TX7Zfaz61keLtItvF/hTWvCl7IUt9a0+40+VgMlUljZCR9A1fnsPES8kpYey/x/8A2p9PLhZpNqrr/h/4J+Pnhjxt408F3H2vwf4s1fRJicl9PvZLct9dhGfxr2zwf+3h+0V4UKR33iKx8RW6YAi1ayRjj/rpFskJ9yxrxLxj4R1/wD4m1Dwj4nsXtNR02ZoZkYHBx0dSfvIwwyt0IINY+RX3dfAYHMoKdanGaezaT+5nzdPE4jCy5YScWul/0P0h+DP/AAUF8D+PNTtfDXxA0ZvCmpXbrFDdifzrGSQ8AM5AaLJ6bgV9WFfVf2oetfhtZWN5qd7b6bp1rLc3d1KsMEMSlnkkY4VVA5JJIAFfsv4Mh1PSPB+haVrM/nahZaba293IW3b5kiVXbPfLAnNflfGWQ4PKJ06mE0573je9rW1V9ep9lkOY18dGUa2vLbU7L7UPWvyQ/ay+Htn8NPjt4j0TSbZLfTLyRNUsY04VI513MoHYLJ5igeiiv1W+1n1r85P+ChFzb3HxzsRARvi8O2qTY/v+fcEZ/wCAlafANWdPMpU1tKLv8mrP+u4cS04ywim901+J8z0UDpRX7GfCBSN1paRutMZ+pX7B1wI/2avD656Xd/8A+lUlfQf2oetfNX7DlwY/2ctBXP8Ay9X/AP6UyV759rPrX8859H/hUxH+OX5s/Tst/wBzpf4V+R8b/wDBTiXzbL4dc9JdV/8AQbWvhNelfb//AAUnm82z+H3tLqn8raviBelfr3BqtktH/t7/ANLkfDZ//wAjCp8v/SULRRRX0544UUUUAFFFIT2FMAJxSUUVVgCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACgHFFFADqKbnFOBzUtAdt8C22/GrwG3p4j04/+TCV+sv2uvyX+CR2/GTwOfTxDp5/8jpX6n/aj/er8p8QVfFUf8L/M+34V/gVPX9DZ+114Nrn7GnwP8Q63qHiDUbPWTd6ndS3lwU1Eqpkkcu2BjgZJ4r2D7Uf71H2o/wB6vicJjcTgW5Yabg3vZ2Po6+Fo4lJVoqVu54pF+w/8AI3DPpmsyAfwtqb4P5AGvUfh78Jvhl8K45F8CeEbPTJZl2S3ALS3Ei9cGWQs5GecZx7Vtfaj/eo+1H+9W2IzXH4uHs69aUo9m3b7jOlgcNQlzU6aT72Nn7XUN7rFpptnPqN/cx29taxNNNLI21Y41BLMT2AAJNcH40+Lnw/+Hts1z4v8W2GnlRkQNLvnf/diXLt+Ar4p/aI/aw1X4q28vg/wjBcaV4ZL/v3kbFxfgHjeBwkeedmTnAJPYduT8O4vN6iUItQ6ye1vLu/JfM5swzWhgIPmd5dF1/4B5n8bviF/wtP4p+IPG0Rk+y31zss1cYK20aiOLI7EqoJHqTXEHpSAd6Wv3OhRhhqUaNNWjFJL0Wh+b1Ksq03Unu3f7z2r9jJ/L/aM8MP6R3//AKRzV+mP2uvzI/Y/bZ+0H4ab0jvv/SSav0e+1H+9X5Nx8r5nD/Av/SpH3PDH+5y/xP8AJGtNKlxDJBJykilG57EYNeCD9ib9nsf8wDVP/BpL/jXsv2o/3qPtR/vV8nhcdisDf6tUlC+9m1ex7dbC0cTb20FK3dXPGv8Ahif9nz/oAan/AODSX/Gl/wCGKP2fP+gDqf8A4NJf8a9k+1H+9R9qP96uv+3c0/6CJ/8AgTMP7Mwf/PqP3I8H8U/sb/AbSvDGr6nZaHqS3FnYXE8ROpSkB0jZlJGeeQK/PYGv1m8b3JPgvXxn/mF3X/opq/JcHPFfonA+OxONp1niajnZxtd3tufK8R4ajhp01Sio3T2Vuw5q+2/+CfHgsWOjeI/iPdQ4kv5k0qzYjBEUeHlI9QzNGPrGa+JArMwVQSScADvX6m/Brwkvw6+GHh3wgUCT2VkjXQH/AD8yZkl/8fZvwArfjnHfV8vWHjvUdvktX+Nl8zPhvDe2xTqvaC/F6L9T037XXK/FTx2ngD4c+IvGLOofS9Pllg3dGnI2xL+MhQfjWj9qP96vmT9u7xwdO+H2k+CrebEuvX3nzKD1t7cAkEe8jxEf7pr8wybA/wBoY+lh7aNq/otX+CZ9hmGI+q4adXstPXZfifHn/Cz/AImMSx+IniYk8k/2vcf/ABdL/wALN+Jf/RRPE3/g2uP/AIuubAp2B6V++fVaH8i+5H5l7ap/M/vOhPxO+Jf/AEUPxN/4Nrj/AOLr9AP2MviZe+Ofg7DaazqM17qmg3ktjcTTymSWRCfMidmOSflfYCf+edfm6R3FfSP7C/jc6B8SdR8ITzbbfxHZExrnrcwZdf8AyGZvyFfNcW5ZTxOVzlTilKHvaLtv+Fz18jxkqWNipPSWn37fifoR9rryH9q3wWPiD8EdesoYfMvdJQaxZ8ZIeAEuAO5MRlUe7CvRftR/vU2SZJY2ilAdHBVlYZBB6givx7B4ieDxEMRDeLT+4+9r0ViKUqUtmrH5BKelPrqfiz4Mf4efEjxB4Q2MsNhev9mz1Nu/zxH/AL9sv41ym72r+iKNWNenGrTd1JJr0ep+VVISpTcJbp2EIIPHHpX6Q/so/tB23xV8HQ+HNdvV/wCEr0KBYrpXb5ryBcKtwM9T0D+jc8BhX5vkg1oeHfEeueEtbtPEfhvU5tP1KxkEkE8LYZT6ehBGQQcggkEEGvHz/Jaed4X2Unaa1i+z8/J9fv6HdlmYSy6tzrWL3X9dUfsP9rqO4eC7gktbqGOaGZSkkcihldSMEEHggjtXy18Hv20/Cfim3g0f4kvF4e1gAIbs5+xXB9d3JhPqG+X/AGu1fRVnq1pqFtHe2F5Dc28y7o5YZA6OPUMOCK/FcflmKyyp7PEwcX0fR+j2Z+h4XF0MbDnoyv8An80cB4g/ZV/Z88R3T3t38OrS1nkOSbC4mtEH0jidUH/fNaPg79nT4HeBL2PUvD/w+sBeRNujuLx5Lt0bsy+czBT7riu0+1H+9R9qP96nLNMfKn7KVabj25nb8wWBw0Zc6pxv3sjZ+10fa64zxX4/8KeBtMbV/F3iGz0u1XOHuJMFz6Iv3nPsoJr45+PX7ZOpeL7W48JfC83OmaTMrRXWpSDZc3KngrGP+WSEd/vn/Z5B6cpyHGZxUUaMbR6yey/zfkjHHZlQwEb1Hr26jf20vj7bfEDW4Phx4T1AT6Hokxkvp4m+S7vBlcA/xJGMgHoWZjyApr5jUd6RVp9ft+W5fRyvDRwtHZfi+rfqfnWLxU8ZWdapu/w8hrV9n/8ABOqXyrXx77yaZ/K5r4xavsL/AIJ+S+VbeOuesmnfyuK8fjHXJa3/AG7/AOlRO/If+RhT+f8A6Sz7U+114d+2jceZ+zx4hT1nsf8A0qjr1j7Uf71eLftiTmT4A6+ues9l/wClMdfkmRr/AIU8P/jj+aPuMy/3Or/hf5H50AcUpFKopSM1/QJ+Xn35+xR8dW8Y+Ej8NPEV5v1rw5CPsbu3zXNiMBR7tGSFP+yU68mvpr7XX5B+B/GWtfD7xZpvjHw/P5d7pk4lUEnbIvR42x1VlJU+xNfqJ4C8f6P8Q/CWm+MNBm3WuowiTYTlonHDxt/tKwKn6elfjvGWR/2fifrdFfu6j+6XVfPdfPsfe5BmP1qj7Cb96P4r/gbfcXfih4E0P4reCNS8E6+mIL6P91MBl7adeY5V91P5jIPBNflX4y8I634C8U6l4Q8RW3k3+mTmGUD7rDqrqe6spDA9wRX6zfaj/er5t/bH+DA8b+Gx8RvD9pu1vQYSLtEX5rqyGSfq0eSw/wBksOflFVwbnf8AZ+I+qVn+7m/ul39Hs/kLP8t+tUvb0170fxX/AAD4UBzSNSrSNX6/c+DP0C/YDn8v4Lakv/Ux3J/8l7evpX7XXy3+wnN5Xwd1Fc/8zBcn/wAgW9fRf2o/3q/BuJFfNq/+Jn6ZlP8AuNL0Mb4ofC/wX8YNGtdB8cWdxc2dndC8iWG4aEiQIyZJXqMO3Feaf8MUfs+/9AHVP/BpL/jXsn2o/wB6j7Uf71ceHzTHYSHsqFWUY9k2kb1cDh68uerTTfdo8b/4Yp/Z9/6AOp/+DSX/ABo/4Yp/Z9/6AOp/+DSX/GvZPtR/vUfaj/erf+3c0/6CJ/8AgTM/7Lwf/PqP3I+Hf2u/gT8N/hD4f8PX/gbTru2m1C8mhnM928wKqgIwG6cmvmIMSK+1P2/ZfM8K+EhnpqFx/wCixXxUtfrnCeIq4rKoVa8nKTctXq92fDZ3ShQxsoU1ZaaL0H2v/H1B/wBdF/nX7Lfa6/Gm1H+lQ/8AXRf51+vv2o/3q+W8RFd4b/t//wBtPZ4V2q/9u/qbP2uvzA/a0bf+0R4xb1ntv/SWGv0m+1H+9X5qftUtv+P/AIuf1nt//SaKvP4AVsxqf4H/AOlROrij/dYf4v0Z5UOlXNE1jUPDmt2HiDSpvKvdMuory2f+7LG4ZT+YFVKQjvX63KKknGWzPhk2ndH64fDH4maP8UfA+l+NdFYLFfwgyw7stbzDiSJvdWBHuMHoRXU/a6/LL4G/HvxR8Edce409Wv8ARb1h9v0t5CqSHoJEODskHrjkcHPGPvT4b/tAfDT4o2sLeHfEcEV/KPm0y8dYbtG7jYT8/wBULD3r8Sz/AIZxGVVZTpRcqL2a1t5Ptbvs/wAD9EyvN6WOgozdqnVd/NHRfEr4Q/DX4t2yQ+OfDFvezQqUgu0ZormIeiyoQ2M87Tlc9q8Zn/YE+DEtwZYvEPi+GMnPlLeWxA9gTAT+ea+hPtR/vUfaj/ery8LnGYYKHs8PWlGPa+n3HbXy/C4iXPVppvvY4b4Yfs6fCH4S3i6t4Y8OGbVUBVdRv5TcToCMHZnCxnBIyigkEgnFepfa6xvtR/vVgeLviP4N8B2J1Hxh4msNKhCllE8wEkmOyIPmc+ygmuarUxOY1uao5Tm/Vs2hTo4SnaKUYr5I7K91i002yn1HULmO3tbWJppppG2pHGoJZmPYAAkmvyh+N/xC/wCFp/FPxB41iaQ2t7dbLIOMFbWMCOLI7EqoJHqTXqX7Rf7WWofFC2l8G+CY7rTPDbHF1LIds+oAHgMB9yPvtzluM4+7XzqB3r9U4P4eqZXGWKxStUkrJdlvr5vT0Pis+zWGMao0XeK1v3f+SFooor7c+cuFI3WlpGoJP0n/AGJ7jy/2etCX0ur7/wBKHr3X7XXzx+xtP5fwC0Rc/wDLze/+lD17d9qP96v5/wA9X/CniP8AHL82fqeW/wC50v8ACvyPk/8A4KLzebZ+AvaXUv5W1fFi9K+xv+Cg0vm2ngbnpJqP8revjodK/WuDv+RLR/7e/wDSpHwuf/8AIwqfL/0lBRRRX0x4wUUE4ppOaaQCk5pKKKoAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigCeyvr3TbyDUdOvJrS7tpFlgngkKSROpyrKw5UggEEciuoPxh+Ln/RU/F//g8uv/i65CgEisamHpVnepFP1SZpCrOnpCTXozrv+Fw/Fz/oqnjD/wAHl1/8XR/wuH4uf9FU8Yf+Dy6/+Lrkwc0Vj9Sw3/PuP3L/ACK+s1v5397Os/4XD8XP+iqeMP8AweXX/wAXVO9+JHxF1JWTUfH3iS6VhhhNqs7gj3y1c/RTWEw8XdU4/chOvVejk/vYh3OxdiSxOSSeSaAMUtFdBkFFFFAFzSdZ1jw/qEeraBq15pt9DuEdzZztDKm4FTtdCCMgkHB6E10B+MPxc/6Kn4w/8Hl1/wDF1ydFZVMPRqvmqQTfmkzSFapTVoyaXqdZ/wALh+Ln/RVPGH/g8uv/AIuj/hcPxc/6Kp4w/wDB5df/ABdcnRWf1LDf8+4/cv8AIv6zW/nf3s6z/hcPxc/6Kp4w/wDB5df/ABdH/C4fi5/0VTxh/wCDy6/+Lrk6KPqWG/59x+5f5D+sVv5397Oqm+LXxWuoZLa5+JviyWGVSkkcmtXLK6kYIIL4II7VyoGKKK1p0adG/s4pX7KxE6k6nxtsfFLLBKk9vK8UsTB0dGIZWByCCOhBrq/+Fw/Fzv8AFLxf/wCDy6/+LrkaKVShSrfxIp+quOFSdP4G0dcPjD8Wz/zVPxf/AODy5/8Ai6xte8UeKPFU0Vz4o8R6prEsCFIpL+8kuGRSc4UuSQM84FZVLk0oYahTfNCCT8khyrVJq0pNr1HdKKTdRkVsZi1Y03UtT0W/h1TRtRurG8t23Q3FtM0UsZxjKspBBwT0NV6KTSkrPYE2ndHV/wDC4Pi5/wBFT8X/APg8uv8A4ulHxg+Ln/RU/F//AIPLr/4uuTorn+pYb/n3H7kbfWK387+9l3WNd1zxHfHVPEWs32qXjKENxe3DzylR0BZyTgemapUUV0RioLlirIybcndhQRmiimIaVrZ8O+NPGHhCUy+FvFGq6SxO5hZ3bxBj/tBSA341kUVM6cKseWauvMcZSg+aLsz1G0/aj+PdlGIofiHcsB3ms7aU/m8ZNVtT/aT+OWrxmK7+I+pxqRgm1WO2P5xKprzfA9KMD0riWU4CMuZUIX/wx/yOl47FNWdSVv8AE/8AMs6lqup61dvf6xqV1f3T/emuZmlkb6sxJNVwB3NJRXcoqKstjlbbd2O4paZRRYB1a2g+MPF/hMTr4W8Vaxowuipn/s++lt/N2527tjDdjccZ6ZPrWPRUzpxqR5Zq68xxlKDvF2Z1v/C3/i3/ANFT8X/+Du5/+Lqpq/xF+IXiGwk0rX/HfiLU7KUqZLa81SeaJyDkZR2IOCARx1Fc7RWUcHh4tSjBJryRo69WSs5P72OAxRTaK3sZCnB71uaJ498c+F7RtP8ADXjXXtItXkMrQWOozQRlyACxVGAJwAM+wrCoqZ0oVVyzSa8yozlB3i7M6z/hcPxb/wCip+L/APwd3P8A8XQfjB8W2BU/FHxcQeDnW7n/AOLrk6Kx+pYb/n3H7kafWK387+9hknkkkmg89aKK6TE3ND8e+O/C9m2neGvGuvaTaPIZWgsdSmt4y5ABYqjAZIAGevAq/wD8Lg+Ln/RU/F//AIPLr/4uuUorCWFoTfNKCb9EaqvVirKTt6s6v/hcHxc/6Kp4v/8AB5df/F0f8Lg+Ln/RVPF//g8uv/i65TA9KMD0qfqWG/59x+5D+sVv5397Or/4XB8XP+iqeL//AAeXX/xdH/C4Pi5/0VPxf/4PLr/4uuUwPSij6lhv+fcfuQfWK387+9mxr3jXxn4riig8UeLta1iK3YvEmoX8twsbEYJUOxwcelY9FFbwpwpx5YKy8jKUpTd5O7DkEMpII5BFdYfjB8XP+ipeL/8AweXX/wAXXJ5FJuqalGlWt7SKdu6uVCpOn8Da9Drf+FwfFz/oqfi//wAHl1/8XXOapq2qa5fzatrep3eoXtwQZbm6maWWQgAAs7Ek4AA5PQCqmTSUqeHo0nenFJ+SSCVWpNWlJv5ji3pSZzSUVqQBGaQblIZSQQcgjqKWigDstC+NPxa8NKI9G+ImuwxqMLE948sa/RHyo/Kujj/ap+P0UZiX4hzEHu1haMfzMWa8qowPSuKplmBrPmqUYN+cU/0OiGMxNNWhUkvRs9A1b9oX42a1EYL34la0qN1+zSi2J/GIKa4S9vr/AFO6e91K8nu7iTl5p5GkdvqzEk1FRW1HC0MMrUYKPokvyMqlepV/iSb9W2IBiloorcxuFFFFABR1oooA6DR/iL8Q/DtgmleH/HfiLTLKMsyW1nqk8MSknJIRGAGSSTxV3/hcPxc/6Kn4w/8AB5df/F1yVFYSwmHk3KUE2/JGqr1Yqyk/vZr6/wCMfGHiwQL4q8V6xrItSxgGoX0tx5W7G7bvY7c7RnHXArIooJxWsIRprlgrLyIlKU3eTuwpCfSkJJorRIkKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFKG9aSigB1FNzilDVNgFooopAFFFFABRRRQAUUUUAFFFFABRRRQVcKKKKACiiigYUUUUALmjcaSigB24UuRTKKAH0U2jJoAdRSbvajcKAFopMj1paACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKTI9aAFopNwo3e1AC0U3caMmgB2RSbhTaKAF3GjJpKKACiiigAooooAKKKKACiiigVwooooFcKKKKBBRRRQAUUUUAFFFFABRQSBTSSadgFLelJRRVAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAAOKcCDTaKVgHUU0EinAg0rAFFFFIAooooAKKKKACiiigAooooAKKKKB3CiiigdwooooC4UUUUDCiiigAooooAKKKKAFyaXcKbRQA7Ipcj1plFAD8j1oplFAD6KZRQA+imUUAPoyPWmUUAPyPWkyKbRQA7cKQmkooAKKKKACiiigAooooAKKKKACiiigQUUUUBcKKKKBXCiiigQUUUUAFFFFABRRRQAUUUUAFFBIFNJNOwDiQKaTmiinYAooopgFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAAJFKCKSilYB1FNyaUN60rALRRmikAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUDuFFFFAXCiiigdwooooAKKKKBhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAgooooC4UUUUCuFFFFAXCiiigQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUhb0pMk07AOJAppJoop2AKKKKYBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUZNFFAC7hS02ilYB1FJuNG4UrALRRRSAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigdwooooC4UUUUBcKKKKAuFFFFAXCiiigLhRRRQIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACik3CjcadgFpMikop2AMmiiimAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH/9k=";
var CUSTOM_EMOJI = {
	"👤": "6032693626394382504",
	"✏️": "6039779802741739617",
	"📄": "6034969813032374911",
	"💰": "5778421276024509124",
	"📎": "6039451237743595514",
	"📝": "5922693616953725714",
	"📊": "5936143551854285132"
};
var KEYS = Object.keys(CUSTOM_EMOJI).sort((a, b) => b.length - a.length);
function escapeRegExp(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function applyCustomEmoji(text) {
	let out = text;
	for (const base of KEYS) {
		const id = CUSTOM_EMOJI[base];
		out = out.replace(new RegExp(escapeRegExp(base), "g"), `<tg-emoji emoji-id="${id}">${base}</tg-emoji>`);
	}
	return out;
}
function hasCustomEmoji(text) {
	return /<tg-emoji\b/.test(text);
}
var BUTTON_EMOJI = {
	"🛡": "6030445631921721471",
	"📝": "5922693616953725714",
	"📣": "6039422865189638057",
	"👥": "6032609071373226027",
	"🌐": "5776233299424843260",
	"⬅️": "5960671702059848143",
	"✅": "5774022692642492953",
	"🔎": "6032850693348399258",
	"🌟": "5805331990618053402"
};
var BTN_KEYS = Object.keys(BUTTON_EMOJI).sort((a, b) => b.length - a.length);
function decorateButtons(markup, useIcons) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return markup;
	const rows = m.inline_keyboard.map((row) => row.map((btn) => {
		const text = typeof btn.text === "string" ? btn.text : "";
		if (!useIcons || !text) return { ...btn };
		for (const emoji of BTN_KEYS) if (text.startsWith(emoji + " ")) return {
			...btn,
			text: text.slice(emoji.length + 1),
			icon_custom_emoji_id: BUTTON_EMOJI[emoji]
		};
		return { ...btn };
	}));
	return {
		...markup,
		inline_keyboard: rows
	};
}
function markupHasIconableButton(markup) {
	const m = markup;
	if (!m || !Array.isArray(m.inline_keyboard)) return false;
	return m.inline_keyboard.some((row) => row.some((btn) => typeof btn.text === "string" && BTN_KEYS.some((e) => btn.text.startsWith(e + " "))));
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	allowCheck: () => allowCheck,
	allowEvidenceChunk: () => allowEvidenceChunk,
	allowEvidenceDownload: () => allowEvidenceDownload,
	allowEvidenceUpload: () => allowEvidenceUpload,
	appendEvidenceChunk: () => appendEvidenceChunk,
	bannerById: () => bannerById,
	bannerFilePath: () => bannerFilePath,
	blacklistEntry: () => blacklistEntry,
	checkCounterparty: () => checkCounterparty,
	configureFromOrigin: () => configureFromOrigin,
	diagnoseUserSearch: () => diagnoseUserSearch,
	evidenceBytesOnDisk: () => evidenceBytesOnDisk,
	evidenceOwnedBy: () => evidenceOwnedBy,
	featuresEnabled: () => featuresEnabled,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	hasUserbot: () => hasUserbot,
	isDisconnectError: () => isDisconnectError,
	listBanners: () => listBanners,
	listComplaintsForUser: () => listComplaintsForUser,
	listSponsors: () => listSponsors,
	postMatchesSubject: () => postMatchesSubject,
	recentBlacklist: () => recentBlacklist,
	registerMiniAppUrl: () => registerMiniAppUrl,
	resolveChannelAsUser: () => resolveChannelAsUser,
	resolveHandleServer: () => resolveHandleServer,
	saveUploadedEvidence: () => saveUploadedEvidence,
	saveUserLocaleServer: () => saveUserLocaleServer,
	sendApplicationToArbiters: () => sendApplicationToArbiters,
	setAudienceBase: () => setAudienceBase,
	setSponsorLink: () => setSponsorLink,
	sponsorAvatarPath: () => sponsorAvatarPath,
	sponsorStats: () => sponsorStats,
	uploadedEvidencePath: () => uploadedEvidencePath,
	userbotStatus: () => userbotStatus,
	verifyAccountPair: () => verifyAccountPair,
	verifyEvidenceDownload: () => verifyEvidenceDownload,
	verifyTelegramInitData: () => verifyTelegramInitData,
	webhookSecret: () => webhookSecret,
	webhookSecretMatches: () => webhookSecretMatches
});
function botToken() {
	return process.env.TELEGRAM_BOT_TOKEN || "";
}
var warnedMissingToken = false;
function requireToken() {
	const token = botToken();
	if (!token && !warnedMissingToken) {
		warnedMissingToken = true;
		console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
	}
	return token;
}
function isDisconnectError(err) {
	const any = err;
	const code = String(any?.code || any?.cause?.code || "");
	const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
	return code === "ECONNRESET" || code === "EPIPE" || code === "ECONNABORTED" || code === "ERR_STREAM_PREMATURE_CLOSE" || /aborted|socket hang up|ECONNRESET|premature close/i.test(msg);
}
function installDisconnectGuards() {
	const swallow = (err) => {
		if (isDisconnectError(err)) return;
		console.error("[epb]", err);
	};
	process.on("uncaughtException", swallow);
	process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
function botApi() {
	return `https://api.telegram.org/bot${requireToken()}`;
}
var BOT_USERNAME = "EuropeBlack_bot";
function webhookSecret() {
	return `epb-${createHash("sha256").update(botToken()).digest("hex").slice(0, 24)}`;
}
function webhookSecretMatches(header) {
	const expected = webhookSecret();
	const got = String(header || "");
	const a = Buffer.from(got);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
var DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
var BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var PINNED_ARBITER_CHAT = "-1003904954808";
var PINNED_CHANNEL = "-1003958415589";
var DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";
var RELAY_PATH = join(DATA_DIR, "telegram-relay-chats.json");
var BACKUP_DIR = join(DATA_DIR, "backups");
function writeJsonAtomic(path, value) {
	mkdirSync(dirname(path), { recursive: true });
	const tmp = `${path}.${process.pid}.tmp`;
	writeFileSync(tmp, JSON.stringify(value, null, 2));
	renameSync(tmp, path);
}
function readJson(path) {
	try {
		return JSON.parse(readFileSync(path, "utf8"));
	} catch {
		return null;
	}
}
function latestBackup(prefix) {
	try {
		const names = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		return names.length ? join(BACKUP_DIR, names[names.length - 1]) : null;
	} catch {
		return null;
	}
}
function backupDaily(prefix, value) {
	try {
		const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
		writeJsonAtomic(join(BACKUP_DIR, `${prefix}-${day}.json`), value);
		const old = readdirSync(BACKUP_DIR).filter((n) => n.startsWith(`${prefix}-`) && n.endsWith(".json")).sort();
		for (const name of old.slice(0, Math.max(0, old.length - 30))) unlinkSync(join(BACKUP_DIR, name));
	} catch {}
}
function mergeRelayLists(...lists) {
	const out = [];
	for (const list of lists) for (const chat of list || []) {
		if (!chat?.id) continue;
		const idx = out.findIndex((c) => sameChat(c.id, chat.id));
		if (idx < 0) out.push({
			...chat,
			id: String(chat.id)
		});
		else if (out[idx].status !== "on" && chat.status === "on") out[idx] = {
			...out[idx],
			...chat
		};
	}
	return out;
}
var bindingsLoadFailed = false;
var bindings = loadBindings();
var profileReady = false;
var commandsStamp = "";
var COMMANDS_STAMP = "eu-blacklist-bot-v4-admin";
function loadBindings() {
	let raw = readJson(BINDINGS_PATH);
	if (!raw && existsSync(BINDINGS_PATH)) {
		const backup = latestBackup("telegram-bindings");
		raw = backup ? readJson(backup) : null;
		if (!raw) {
			if (!bindingsLoadFailed) console.error("[epb] telegram-bindings.json is unreadable and there is no backup; it will not be overwritten");
			bindingsLoadFailed = true;
		}
	}
	const loaded = raw || {};
	const relayFile = readJson(RELAY_PATH);
	const relayBackup = relayFile ? null : readJson(latestBackup("telegram-relay-chats") || "");
	loaded.relayChats = mergeRelayLists(loaded.relayChats, relayFile, relayBackup);
	return loaded;
}
function saveBindings() {
	if (bindingsLoadFailed) return;
	try {
		writeJsonAtomic(BINDINGS_PATH, bindings);
		writeJsonAtomic(RELAY_PATH, bindings.relayChats || []);
		backupDaily("telegram-bindings", bindings);
		backupDaily("telegram-relay-chats", bindings.relayChats || []);
	} catch {}
}
var ID_CACHE_PATH = join(DATA_DIR, "telegram-ids-verified.json");
var PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
var LOCALES_PATH = join(DATA_DIR, "telegram-locales.json");
var userLocales = {};
try {
	if (existsSync(LOCALES_PATH)) {
		const raw = JSON.parse(readFileSync(LOCALES_PATH, "utf8"));
		for (const [id, value] of Object.entries(raw || {})) if (isLocale(value)) userLocales[id] = value;
	}
} catch {
	userLocales = {};
}
function saveLocales() {
	try {
		writeJsonAtomic(LOCALES_PATH, userLocales);
	} catch {}
}
function langOf(userId) {
	return userLocales[String(userId || "")] === "en" ? "en" : "ru";
}
function hasLang(userId) {
	return isLocale(userLocales[String(userId || "")]);
}
function setLang(userId, locale) {
	userLocales[String(userId)] = locale;
	saveLocales();
}
function saveUserLocaleServer(userId, locale) {
	if (!isLocale(locale)) return;
	setLang(userId, locale);
}
function btUser(userId, key, vars) {
	return tb(langOf(userId), key, vars);
}
var idCache = {};
var legacyIds = {};
var pendingPosts = {};
legacyIds = readJson(join(DATA_DIR, "telegram-ids.json")) || {};
idCache = {
	...KNOWN_TELEGRAM_IDS,
	...readJson(ID_CACHE_PATH) || {}
};
try {
	pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8"));
} catch {
	pendingPosts = {};
}
for (const rec of Object.values(pendingPosts)) if (rec.status === "published" && rec.channelPosted === void 0) rec.channelPosted = true;
var BLACKLIST_CLEANUP = [
	"hugos",
	"mkcrd",
	"annuit1",
	"ballin812"
];
var BLACKLIST_CLEANUP_STAMP = "cleanup-v2";
if (bindings.blacklistCleanupStamp !== BLACKLIST_CLEANUP_STAMP) {
	let changed = false;
	for (const rec of Object.values(pendingPosts)) {
		if (rec.removedFromCheck) continue;
		if (pendingAccounts(rec).map((a) => a.username.replace(/^@/, "").toLowerCase()).some((n) => BLACKLIST_CLEANUP.includes(n))) {
			rec.removedFromCheck = true;
			changed = true;
		}
	}
	if (changed) savePending();
	bindings.blacklistCleanupStamp = BLACKLIST_CLEANUP_STAMP;
	saveBindings();
}
var FINDS_CLEANUP_STAMP = "finds-v1";
if (bindings.findsCleanupStamp !== FINDS_CLEANUP_STAMP) {
	if (bindings.recentFinds?.length) bindings.recentFinds = [];
	bindings.findsCleanupStamp = FINDS_CLEANUP_STAMP;
	saveBindings();
}
var idCacheTimer = null;
function saveIdCache() {
	if (idCacheTimer) return;
	idCacheTimer = setTimeout(() => {
		idCacheTimer = null;
		try {
			writeJsonAtomic(ID_CACHE_PATH, idCache);
		} catch {}
	}, 2e3);
}
function savePending() {
	try {
		const entries = Object.entries(pendingPosts);
		if (entries.length > 1200) {
			const drop = entries.filter(([, rec]) => rec.status === "published" || rec.status === "rejected").sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
			const extra = entries.length - 1e3;
			for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
		}
		writeJsonAtomic(PENDING_PATH, pendingPosts);
	} catch {}
}
function rememberUser(user) {
	if (!user?.id || !user.username) return;
	rememberHandle(user.username, String(user.id));
}
function rememberHandle(username, id) {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key || !id || !/^\d{5,15}$/.test(id)) return;
	if (idCache[key] === id) return;
	idCache[key] = id;
	const keys = Object.keys(idCache);
	if (keys.length > 8e3) for (const extra of keys.slice(0, keys.length - 7e3)) delete idCache[extra];
	saveIdCache();
}
var EVIDENCE_DIR = join(DATA_DIR, "evidence");
var MAX_EVIDENCE_FILE = 1073741824;
var MAX_EVIDENCE_CHUNK = 2097152;
function sanitizeEvidenceId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9_-]/g, "");
	if (!safe || safe.length < 8 || safe.length > 80) return null;
	if (safe === ".." || safe.startsWith(".")) return null;
	return safe;
}
function evidenceOwnerPath(id) {
	return join(EVIDENCE_DIR, `${id}.own`);
}
function writeEvidenceOwner(id, userId) {
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	writeFileSync(evidenceOwnerPath(id), String(userId || ""));
}
function readEvidenceOwner(id) {
	try {
		return readFileSync(evidenceOwnerPath(id), "utf8").trim();
	} catch {
		return "";
	}
}
function evidenceOwnedBy(id, userId) {
	const safe = sanitizeEvidenceId(id || "");
	if (!safe || !userId) return false;
	return readEvidenceOwner(safe) === userId && Boolean(uploadedEvidencePath(safe));
}
function evidenceHmacKey() {
	return createHmac("sha256", "EvidenceGet").update(botToken() || "none").digest();
}
function evidenceSig(key, exp) {
	return createHmac("sha256", evidenceHmacKey()).update(`${key}.${exp}`).digest("hex").slice(0, 32);
}
function verifyEvidenceDownload(key, exp, sig) {
	const safe = sanitizeEvidenceId(key);
	if (!safe) return false;
	const expMs = Number(exp);
	if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
	if (expMs > Date.now() + 1728e5) return false;
	const expect = evidenceSig(safe, expMs);
	const a = Buffer.from(expect, "hex");
	const b = Buffer.from(String(sig || ""), "hex");
	if (a.length !== b.length || a.length === 0) return false;
	return timingSafeEqual(a, b);
}
function isAllowedEvidenceMagic(bytes) {
	if (!bytes.length) return false;
	const head = bytes.subarray(0, 256).toString("utf8").replace(/^\uFEFF/, "").trimStart().toLowerCase();
	if (head.startsWith("<!doctype") || head.startsWith("<html") || head.startsWith("<script") || head.startsWith("<svg") || head.startsWith("<?xml") || head.startsWith("<?php") || head.startsWith("#!") || head.startsWith("import ") || head.startsWith("function ") || head.startsWith("const ") || head.startsWith("var ") || head.startsWith("{")) return false;
	if (bytes[0] === 77 && bytes[1] === 90) return false;
	if (bytes[0] === 127 && bytes[1] === 69 && bytes[2] === 76 && bytes[3] === 70) return false;
	if (bytes[0] === 202 && bytes[1] === 254 && bytes[2] === 186 && bytes[3] === 190) return false;
	if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return true;
	if (bytes.length >= 8 && bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71) return true;
	if (bytes.length >= 6 && bytes.subarray(0, 3).toString("ascii") === "GIF") return true;
	if (bytes.length >= 12 && bytes.subarray(0, 4).toString("ascii") === "RIFF" && (bytes.subarray(8, 12).toString("ascii") === "WEBP" || bytes.subarray(8, 12).toString("ascii") === "AVI ")) return true;
	if (bytes.length >= 4 && bytes[0] === 26 && bytes[1] === 69 && bytes[2] === 223 && bytes[3] === 163) return true;
	if (bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp") return true;
	return false;
}
function saveUploadedEvidence(userId, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
	if (!isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const id = randomUUID();
	writeFileSync(join(EVIDENCE_DIR, id), bytes);
	writeEvidenceOwner(id, userId);
	pruneEvidenceDir();
	return id;
}
var chunkCursor = /* @__PURE__ */ new Map();
function appendEvidenceChunk(userId, requestedId, index, total, bytes) {
	if (!userId) throw new Error("telegram auth required");
	if (index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
	mkdirSync(EVIDENCE_DIR, { recursive: true });
	const safe = index === 0 ? randomUUID() : sanitizeEvidenceId(requestedId);
	if (!safe) throw new Error("bad chunk");
	if (index === 0 && !isAllowedEvidenceMagic(bytes)) throw new Error("not media");
	if (index > 0 && readEvidenceOwner(safe) !== userId) throw new Error("forbidden");
	if (index === 0) writeEvidenceOwner(safe, userId);
	const part = join(EVIDENCE_DIR, `${safe}.part`);
	const dest = join(EVIDENCE_DIR, safe);
	const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
	if (existsSync(dest) && readEvidenceOwner(safe) === userId) return safe;
	const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
	if (index < expected) return safe;
	if (index !== expected) throw new Error("chunk order");
	if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
	if (index === 0) {
		if (existsSync(part)) unlinkSync(part);
		if (existsSync(dest)) unlinkSync(dest);
	}
	if ((existsSync(part) ? statSync(part).size : 0) + bytes.length > MAX_EVIDENCE_FILE) {
		try {
			unlinkSync(part);
		} catch {}
		chunkCursor.delete(safe);
		throw new Error("file too large");
	}
	appendFileSync(part, bytes);
	const next = index + 1;
	chunkCursor.set(safe, next);
	writeFileSync(idxPath, String(next));
	if (index !== total - 1) return safe;
	if (existsSync(dest)) unlinkSync(dest);
	renameSync(part, dest);
	try {
		unlinkSync(idxPath);
	} catch {}
	chunkCursor.delete(safe);
	pruneEvidenceDir();
	return safe;
}
function evidenceBytesOnDisk(id) {
	const path = id ? uploadedEvidencePath(id) : null;
	if (!path) return 0;
	try {
		return statSync(path).size;
	} catch {
		return 0;
	}
}
var rateHits = /* @__PURE__ */ new Map();
function tooMany(key, max, windowMs) {
	const now = Date.now();
	if (rateHits.size > 4e3) for (const [k, hits] of rateHits) {
		const keep = hits.filter((t) => now - t < 216e5);
		if (!keep.length) rateHits.delete(k);
		else rateHits.set(k, keep);
	}
	const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
	if (keep.length >= max) {
		rateHits.set(key, keep);
		return true;
	}
	keep.push(now);
	rateHits.set(key, keep);
	return false;
}
function verifyTelegramInitData(initData) {
	if (!botToken() || !initData) return null;
	try {
		const params = new URLSearchParams(initData);
		const hash = params.get("hash") || "";
		if (!hash) return null;
		params.delete("hash");
		const dataCheck = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
		const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
		const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
		const a = Buffer.from(calc, "hex");
		const b = Buffer.from(hash, "hex");
		if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
		const authDate = Number(params.get("auth_date") || 0);
		if (!authDate || Math.abs(Date.now() / 1e3 - authDate) > 86400) return null;
		const user = JSON.parse(params.get("user") || "{}");
		if (!user?.id) return null;
		return {
			id: String(user.id),
			username: user.username
		};
	} catch {
		return null;
	}
}
function pruneEvidenceDir() {
	try {
		if (!existsSync(EVIDENCE_DIR)) return;
		const groups = /* @__PURE__ */ new Map();
		for (const name of readdirSync(EVIDENCE_DIR)) {
			const path = join(EVIDENCE_DIR, name);
			const st = statSync(path);
			const key = name.replace(/\.(own|part|idx)$/, "");
			const group = groups.get(key) || {
				paths: [],
				mtime: 0,
				size: 0
			};
			group.paths.push(path);
			group.mtime = Math.max(group.mtime, st.mtimeMs);
			group.size += st.size;
			groups.set(key, group);
		}
		const list = [...groups.values()].sort((a, b) => a.mtime - b.mtime);
		let total = list.reduce((sum, g) => sum + g.size, 0);
		const maxBytes = 8589934592;
		const maxUploads = 400;
		const fresh = Date.now() - 18e5;
		let count = list.length;
		for (const group of list) {
			if (count <= maxUploads && total <= maxBytes) break;
			if (group.mtime > fresh) break;
			for (const path of group.paths) try {
				unlinkSync(path);
			} catch {}
			total -= group.size;
			count -= 1;
		}
	} catch {}
}
function allowEvidenceUpload(initData, bytes = 1) {
	if (bytes < 0) return {
		ok: false,
		error: "file required"
	};
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`up:${user.id}`, 40, 36e5)) return {
		ok: false,
		error: "too many uploads"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("up:global", 2e3, 36e5)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowEvidenceDownload() {
	return !tooMany("evget:global", 240, 6e4);
}
function allowEvidenceChunk(initData, bytes) {
	if (bytes > MAX_EVIDENCE_CHUNK) return {
		ok: false,
		error: "chunk too large"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`upchunk:${user.id}`, 600, 6e4)) return {
		ok: false,
		error: "upload too fast"
	};
	if (tooMany("upchunk:global", 2e3, 6e4)) return {
		ok: false,
		error: "server busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function allowNewComplaint(userId, storyLen) {
	const loc = langOf(userId);
	if (storyLen > 5e3) return tb(loc, "storyLong");
	if (tooMany(`app:${userId}`, 3, 216e5)) return tb(loc, "tooManyUser");
	if (tooMany("app:global", 40, 36e5)) return tb(loc, "tooManyGlobal");
	return null;
}
function readUploadedEvidence(id) {
	const path = uploadedEvidencePath(id);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
function uploadedEvidencePath(id) {
	const safe = sanitizeEvidenceId(id);
	if (!safe) return null;
	const path = join(EVIDENCE_DIR, safe);
	if (!path.startsWith(EVIDENCE_DIR)) return null;
	return existsSync(path) ? path : null;
}
var BANNER_DIR = join(DATA_DIR, "banners");
var MAX_BANNER_BYTES = 20971520;
var MAX_BANNERS = 20;
function sanitizeBannerId(id) {
	const safe = String(id || "").replace(/[^a-zA-Z0-9]/g, "");
	if (safe.length < 10 || safe.length > 40) return null;
	return safe;
}
function newBannerId() {
	return createHash("sha256").update(randomUUID()).digest("hex").slice(0, 24);
}
function saveBannerFile(id, bytes) {
	mkdirSync(BANNER_DIR, { recursive: true });
	writeFileSync(join(BANNER_DIR, id), bytes);
}
var SPONSOR_AVATAR_DIR = join(DATA_DIR, "sponsor-avatars");
function sanitizeAvatarKey(k) {
	const safe = String(k || "").replace(/[^a-f0-9]/g, "");
	return safe.length >= 8 && safe.length <= 64 ? safe : null;
}
function sponsorAvatarPath(key) {
	const safe = sanitizeAvatarKey(key);
	if (!safe) return null;
	const path = join(SPONSOR_AVATAR_DIR, safe);
	if (!path.startsWith(SPONSOR_AVATAR_DIR)) return null;
	return existsSync(path) ? path : null;
}
async function sponsorAvatarUrl(smallFileId) {
	if (!smallFileId) return "";
	const key = createHash("sha256").update(smallFileId).digest("hex").slice(0, 24);
	const path = join(SPONSOR_AVATAR_DIR, key);
	if (!existsSync(path)) {
		const bytes = await downloadTelegramFile(smallFileId);
		if (!bytes) return "";
		try {
			mkdirSync(SPONSOR_AVATAR_DIR, { recursive: true });
			writeFileSync(path, bytes);
		} catch {
			return "";
		}
	}
	return `/api/telegram/sponsor-avatar?a=${key}`;
}
function bannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	return (bindings.banners || []).find((b) => b.id === safe) || null;
}
function bannerFilePath(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return null;
	const path = join(BANNER_DIR, safe);
	if (!path.startsWith(BANNER_DIR)) return null;
	return existsSync(path) ? path : null;
}
function listBanners() {
	return (bindings.banners || []).map((b) => ({
		id: b.id,
		type: b.type,
		link: b.link,
		width: b.width,
		height: b.height,
		src: `/api/telegram/banner?id=${encodeURIComponent(b.id)}`
	}));
}
var sponsorsCache = null;
function invalidateSponsors() {
	sponsorsCache = null;
	statsCache = null;
}
var AUDIENCE_DEFAULT = 20178;
var statsCache = null;
async function sponsorStats() {
	if (statsCache && Date.now() - statsCache.at < 6e5) return statsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	let sum = 0;
	await Promise.all(chats.map(async (c) => {
		const n = await tgSoft("getChatMemberCount", { chat_id: c.id });
		if (typeof n === "number" && n > 0) sum += n;
	}));
	const base = typeof bindings.audienceBase === "number" ? bindings.audienceBase : AUDIENCE_DEFAULT;
	const value = {
		chats: chats.length,
		audience: Math.max(base, sum)
	};
	statsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setAudienceBase(n) {
	if (!Number.isFinite(n) || n < 0 || n > 1e9) return false;
	bindings.audienceBase = Math.round(n);
	saveBindings();
	statsCache = null;
	return true;
}
async function listSponsors() {
	if (sponsorsCache && Date.now() - sponsorsCache.at < 6e5) return sponsorsCache.value;
	const chats = (bindings.relayChats || []).filter((c) => c.status === "on" && isGroupOrChannel(c));
	const value = await Promise.all(chats.map(async (c) => {
		const chat = await tgSoft("getChat", { chat_id: c.id });
		const title = chat?.title || c.title || "Чат";
		const avatar = await sponsorAvatarUrl(chat?.photo?.small_file_id);
		return {
			id: String(c.id),
			title,
			link: c.link || "",
			avatar
		};
	}));
	sponsorsCache = {
		at: Date.now(),
		value
	};
	return value;
}
function setSponsorLink(chatId, raw) {
	const relay = findRelay(chatId);
	if (!relay) return "bad";
	const text = (raw || "").trim();
	if (text === "-" || text === "—" || text === "") {
		delete relay.link;
		saveBindings();
		invalidateSponsors();
		return "cleared";
	}
	if (!(/^https:\/\/[^\s]+$/i.test(text) || /^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text))) return "bad";
	relay.link = text.startsWith("http") ? text : `https://${text}`;
	saveBindings();
	invalidateSponsors();
	return "set";
}
function removeBannerById(id) {
	const safe = sanitizeBannerId(id);
	if (!safe) return;
	bindings.banners = (bindings.banners || []).filter((b) => b.id !== safe);
	saveBindings();
	try {
		const path = join(BANNER_DIR, safe);
		if (path.startsWith(BANNER_DIR) && existsSync(path)) unlinkSync(path);
	} catch {}
}
async function downloadTelegramFile(fileId) {
	const info = await tgSoft("getFile", { file_id: fileId });
	if (!info?.file_path) return null;
	if (info.file_size && info.file_size > MAX_BANNER_BYTES) return null;
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 6e4);
	try {
		const res = await fetch(`https://api.telegram.org/file/bot${requireToken()}/${info.file_path}`, { signal: ctrl.signal });
		if (!res.ok) return null;
		const bytes = Buffer.from(await res.arrayBuffer());
		if (bytes.length > MAX_BANNER_BYTES) return null;
		return bytes;
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
	}
}
function extractBannerMedia(msg) {
	if (msg.animation?.file_id) return {
		type: "video",
		fileId: msg.animation.file_id,
		mime: msg.animation.mime_type || "video/mp4",
		width: msg.animation.width,
		height: msg.animation.height
	};
	if (msg.video?.file_id) return {
		type: "video",
		fileId: msg.video.file_id,
		mime: msg.video.mime_type || "video/mp4",
		width: msg.video.width,
		height: msg.video.height
	};
	if (msg.photo?.length) {
		const ph = msg.photo.at(-1);
		return {
			type: "image",
			fileId: ph.file_id,
			mime: "image/jpeg",
			width: ph.width,
			height: ph.height
		};
	}
	const doc = msg.document;
	if (doc?.file_id && doc.mime_type) {
		if (doc.mime_type.startsWith("image/") && doc.mime_type !== "image/svg+xml") return {
			type: "image",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
		if (doc.mime_type.startsWith("video/")) return {
			type: "video",
			fileId: doc.file_id,
			mime: doc.mime_type
		};
	}
	return null;
}
function normalizeBannerLink(raw) {
	const text = raw.trim();
	if (text === "-" || text === "—" || text.toLowerCase() === "нет") return "";
	if (/^https:\/\/[^\s]+$/i.test(text)) return text;
	if (/^tg:\/\/[^\s]+$/i.test(text)) return text;
	if (/^(?:https?:\/\/)?(?:t\.me|telegram\.me)\/[^\s]+$/i.test(text)) return text.startsWith("http") ? text : `https://${text}`;
	return null;
}
var TgError = class extends Error {
	code;
	retryAfter;
	migrateTo;
	constructor(json, method) {
		super(json.description || method);
		this.code = json.error_code;
		this.retryAfter = json.parameters?.retry_after;
		this.migrateTo = json.parameters?.migrate_to_chat_id ? String(json.parameters.migrate_to_chat_id) : void 0;
	}
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function tgOnce(method, body) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 45e3);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify(body),
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new TgError(json, method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
async function tg(method, body = {}) {
	let payload = body;
	for (let attempt = 0;; attempt++) try {
		return await tgOnce(method, payload);
	} catch (err) {
		if (!(err instanceof TgError) || attempt >= 3) throw err;
		if (err.migrateTo && payload.chat_id != null) {
			onChatMigrated(String(payload.chat_id), err.migrateTo);
			payload = {
				...payload,
				chat_id: err.migrateTo
			};
			continue;
		}
		if (err.code === 429 && (err.retryAfter ?? 0) <= 60) {
			await sleep(((err.retryAfter ?? 1) + 1) * 1e3);
			continue;
		}
		throw err;
	}
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function customEmojiEnabled() {
	if (typeof bindings.customEmoji === "boolean") return bindings.customEmoji;
	return process.env.EPB_CUSTOM_EMOJI === "0" ? false : true;
}
function isPrivateChat(chatId) {
	return Number(chatId) > 0;
}
function isCustomEmojiError(err) {
	return err instanceof TgError && /emoji/i.test(err.message || "");
}
function isNotModified(err) {
	return err instanceof TgError && /not modified/i.test(err.message || "");
}
async function sendCeMessage(chatId, text, extra = {}) {
	if (customEmojiEnabled() && isPrivateChat(chatId)) {
		const richText = applyCustomEmoji(text);
		const markup = extra.reply_markup;
		if (hasCustomEmoji(richText) || markupHasIconableButton(markup)) {
			const richExtra = markup ? {
				...extra,
				reply_markup: decorateButtons(markup, true)
			} : extra;
			try {
				return await tg("sendMessage", {
					chat_id: chatId,
					text: richText,
					parse_mode: "HTML",
					...richExtra
				});
			} catch (err) {
				if (!isCustomEmojiError(err)) return null;
			}
		}
	}
	return tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		...extra
	});
}
async function editCard(cb, caption, reply_markup) {
	const chatId = cb.message?.chat.id;
	const messageId = cb.message?.message_id;
	if (chatId == null || messageId == null) return;
	const isMedia = Boolean(cb.message?.photo || cb.message?.caption);
	const method = isMedia ? "editMessageCaption" : "editMessageText";
	const field = isMedia ? "caption" : "text";
	const build = (txt, markup) => ({
		chat_id: chatId,
		message_id: messageId,
		[field]: txt,
		parse_mode: "HTML",
		reply_markup: markup,
		...isMedia ? {} : { disable_web_page_preview: true }
	});
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const richText = useCe ? applyCustomEmoji(caption) : caption;
	if (useCe && (hasCustomEmoji(richText) || markupHasIconableButton(reply_markup))) try {
		await tg(method, build(richText, decorateButtons(reply_markup, true)));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
		if (!isCustomEmojiError(err)) {}
	}
	try {
		await tg(method, build(caption, reply_markup));
		return;
	} catch (err) {
		if (isNotModified(err)) return;
	}
	await sendCeMessage(chatId, caption, { reply_markup });
}
function escapeHtml(value) {
	return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function chatIdKey(id) {
	return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}
function sameChat(a, b) {
	if (a == null || b == null) return false;
	return chatIdKey(a) === chatIdKey(b);
}
var OFFICIAL_ARBITER_IDS = [
	PINNED_ARBITER_CHAT,
	REQUESTED_ARBITER,
	withHundredPrefix(REQUESTED_ARBITER)
].filter((id) => Boolean(id));
function isOfficialArbiterChat(id) {
	if (id == null) return false;
	return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}
function arbiterCandidates() {
	const ids = [
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId,
		...OFFICIAL_ARBITER_IDS
	].filter((id) => Boolean(id) && isOfficialArbiterChat(id));
	return [...new Set(ids)];
}
function isOfficialChannel(id) {
	if (id == null) return false;
	if (sameChat(id, PINNED_CHANNEL)) return true;
	return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}
if (!isOfficialArbiterChat(bindings.arbiterChatId)) bindings.arbiterChatId = PINNED_ARBITER_CHAT;
if (!bindings.channelId) bindings.channelId = PINNED_CHANNEL;
if (bindings.cardStamp !== "new-bot-v2") {
	bindings.cards = {};
	bindings.cardStamp = "new-bot-v2";
}
saveBindings();
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
function refreshBindings() {
	bindings = {
		...bindings,
		...loadBindings()
	};
}
function isGatedHost(url) {
	try {
		const host = new URL(url).hostname;
		return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
	} catch {
		return true;
	}
}
function publicMiniAppUrl() {
	refreshBindings();
	const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
	if (!url.startsWith("https://") || isGatedHost(url)) return void 0;
	return url.replace(/\/$/, "");
}
var lastMenuUrl = "";
async function applyMenuButton() {
	const url = publicMiniAppUrl() || "";
	if (url === lastMenuUrl) return;
	lastMenuUrl = url;
	if (url) {
		await tgSoft("setChatMenuButton", { menu_button: {
			type: "web_app",
			text: "Открыть",
			web_app: { url }
		} });
		return;
	}
	await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}
function publicSiteUrl() {
	const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
	if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
	return publicMiniAppUrl();
}
async function ensureProductionWebhook() {
	const site = publicSiteUrl();
	if (!site) return;
	const hook = `${site}/api/telegram/webhook`;
	if ((await tgSoft("getWebhookInfo"))?.url === hook && bindings.webhookStamp === webhookStamp()) {
		await applyMenuButton();
		return;
	}
	await registerMiniAppUrl(site);
}
function webhookStamp() {
	return createHash("sha256").update(webhookSecret()).digest("hex").slice(0, 16);
}
async function ensurePolling() {
	if (process.env.PUBLIC_URL || true) {
		await ensureProductionWebhook();
		return;
	}
	if ((await tgSoft("getWebhookInfo"))?.url) await tgSoft("deleteWebhook", { drop_pending_updates: false });
	if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
		delete bindings.miniAppUrl;
		saveBindings();
	}
	await applyMenuButton();
}
async function ensureBotProfile() {
	if (profileReady && commandsStamp === COMMANDS_STAMP) return;
	await ensurePolling();
	if (commandsStamp !== COMMANDS_STAMP) {
		commandsStamp = COMMANDS_STAMP;
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Открыть приложение"
				},
				{
					command: "apply",
					description: "Подать жалобу в чате"
				},
				{
					command: "cancel",
					description: "Отменить заявку"
				},
				{
					command: "lang",
					description: "Язык / Language"
				}
			],
			language_code: "ru",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("setMyCommands", {
			commands: [
				{
					command: "start",
					description: "Open the app"
				},
				{
					command: "apply",
					description: "File a complaint in chat"
				},
				{
					command: "cancel",
					description: "Cancel the complaint"
				},
				{
					command: "lang",
					description: "Language / Язык"
				}
			],
			language_code: "en",
			scope: { type: "all_private_chats" }
		});
		await tgSoft("deleteMyCommands", { scope: { type: "default" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
		await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
		for (const chat_id of arbiterCandidates()) await tgSoft("setMyCommands", {
			commands: [
				{
					command: "admin",
					description: "Панель управления"
				},
				{
					command: "relays",
					description: "Чаты рассылки"
				},
				{
					command: "channel",
					description: "Канал для постов"
				},
				{
					command: "id",
					description: "ID этого чата"
				}
			],
			scope: {
				type: "chat",
				chat_id
			}
		});
	}
	profileReady = true;
}
var statusCache = null;
function getBotStatus() {
	if (!statusCache || Date.now() - statusCache.at > 6e4) statusCache = {
		at: Date.now(),
		value: computeBotStatus()
	};
	return statusCache.value;
}
async function computeBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	for (const id of arbiterCandidates()) {
		if (!await chatReachable(id)) continue;
		arbiterOk = true;
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		channelOk
	};
}
var mtClient = null;
var mtIdleTimer = null;
var mtBlockedUntil = 0;
var mtMisses = /* @__PURE__ */ new Map();
var mtInflight = /* @__PURE__ */ new Map();
var MT_SESSION_PATH = join(DATA_DIR, "mtproto.session");
function mtproto() {
	if (!mtClient) {
		mtClient = (async () => {
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
			const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
			let saved = "";
			try {
				const [stamp, value] = readFileSync(MT_SESSION_PATH, "utf8").split("\n");
				if (stamp === webhookStamp() && value) saved = value.trim();
			} catch {}
			const client = new TelegramClient(new StringSession(saved), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 12,
				floodSleepThreshold: 0,
				deviceModel: "EPB",
				systemVersion: "Linux",
				appVersion: "1.0",
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.start({ botAuthToken: botToken() }), 2e4, "mtproto login timeout");
			try {
				mkdirSync(DATA_DIR, { recursive: true });
				writeFileSync(MT_SESSION_PATH, `${webhookStamp()}\n${client.session.save()}`, { mode: 384 });
			} catch {}
			return {
				client,
				Api
			};
		})();
		mtClient.catch(() => dropMtproto());
	}
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = setTimeout(() => dropMtproto(), 18e5);
	return mtClient;
}
function withTimeout(promise, ms, message) {
	let timer;
	const timeout = new Promise((_, reject) => {
		timer = setTimeout(() => reject(new Error(message)), ms);
	});
	return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}
function dropMtproto() {
	const pending = mtClient;
	mtClient = null;
	if (mtIdleTimer) clearTimeout(mtIdleTimer);
	mtIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
function floodSeconds(err) {
	const e = err;
	if (typeof e?.seconds === "number" && e.seconds > 0) return e.seconds;
	const m = `${e?.errorMessage || ""} ${e?.message || ""}`.match(/FLOOD_WAIT_(\d+)|A wait of (\d+) seconds/);
	return m ? Number(m[1] || m[2]) : 0;
}
var USER_SESSION_PATH = join(DATA_DIR, "user-session.txt");
function userSession() {
	const env = (process.env.TELEGRAM_USER_SESSION || "").trim();
	if (env) return env;
	try {
		return readFileSync(USER_SESSION_PATH, "utf8").trim();
	} catch {
		return "";
	}
}
function hasUserbot() {
	return Boolean(userSession());
}
var userClient = null;
var userIdleTimer = null;
var userBlockedUntil = 0;
function userApiCreds() {
	return {
		apiId: Number(process.env.TELEGRAM_API_ID || bindings.userbotApi?.apiId || 0),
		apiHash: (process.env.TELEGRAM_API_HASH || bindings.userbotApi?.apiHash || "").trim()
	};
}
var OWNER_ID = "1457986905";
function isOwner(id) {
	return String(id || "") === OWNER_ID;
}
function checkEnabled() {
	if (typeof bindings.checkEnabled === "boolean") return bindings.checkEnabled;
	if (process.env.EPB_CHECK_ENABLED === "0") return false;
	return true;
}
function featuresEnabled() {
	return { check: checkEnabled() };
}
function saveUserSession(session) {
	try {
		mkdirSync(DATA_DIR, { recursive: true });
		writeFileSync(USER_SESSION_PATH, session, { mode: 384 });
	} catch {}
}
function clearUserSession() {
	dropUserbot();
	try {
		if (existsSync(USER_SESSION_PATH)) unlinkSync(USER_SESSION_PATH);
	} catch {}
}
function userbot() {
	if (!userClient) {
		userClient = (async () => {
			const session = userSession();
			if (!session) throw new Error("no user session");
			const { apiId, apiHash } = userApiCreds();
			if (!apiId || !apiHash) throw new Error("set TELEGRAM_API_ID and TELEGRAM_API_HASH for the userbot");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
				connectionRetries: 1,
				timeout: 15,
				floodSleepThreshold: 0,
				autoReconnect: false,
				baseLogger: new Logger("none")
			});
			await withTimeout(client.connect(), 2e4, "userbot connect timeout");
			return {
				client,
				Api
			};
		})();
		userClient.catch(() => dropUserbot());
	}
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = setTimeout(() => dropUserbot(), 12e5);
	return userClient;
}
var userEntitiesLoaded = false;
async function ensureUserEntities(client) {
	if (userEntitiesLoaded) return;
	userEntitiesLoaded = true;
	try {
		await withTimeout(client.getDialogs({ limit: 300 }), 25e3, "dialogs timeout");
		const saved = client.session?.save?.();
		if (typeof saved === "string" && saved) saveUserSession(saved);
	} catch {
		userEntitiesLoaded = false;
	}
}
async function userInputPeer(client, ref) {
	try {
		return await client.getInputEntity(ref);
	} catch {
		await ensureUserEntities(client);
		return client.getInputEntity(ref);
	}
}
function dropUserbot() {
	const pending = userClient;
	userClient = null;
	userEntitiesLoaded = false;
	if (userIdleTimer) clearTimeout(userIdleTimer);
	userIdleTimer = null;
	pending?.then(async ({ client }) => {
		await client.disconnect?.().catch(() => {});
		await client.destroy?.().catch(() => {});
	}).catch(() => {});
}
async function userbotStatus() {
	if (!userSession()) return {
		ok: false,
		error: "нет сессии"
	};
	const { apiId, apiHash } = userApiCreds();
	if (!apiId || !apiHash) return {
		ok: false,
		error: "нет TELEGRAM_API_ID / TELEGRAM_API_HASH"
	};
	try {
		const { client, Api } = await userbot();
		const u = (await withTimeout(client.invoke(new Api.users.GetUsers({ id: [new Api.InputUserSelf()] })), 12e3, "timeout"))?.[0];
		return {
			ok: true,
			name: u?.username ? `@${u.username}` : u?.firstName || "аккаунт"
		};
	} catch (err) {
		return {
			ok: false,
			error: err?.message || "ошибка"
		};
	}
}
async function resolveChannelAsUser(ref) {
	if (!userSession()) return null;
	try {
		const { client } = await userbot();
		const chan = await withTimeout(client.getInputEntity(ref), 12e3, "timeout");
		if (!chan?.channelId) return null;
		const id = `-100${chan.channelId.toString()}`;
		const full = await client.getEntity(ref).catch(() => null);
		return {
			id,
			title: full?.title,
			username: full?.username,
			addedAt: Date.now()
		};
	} catch {
		return null;
	}
}
function snippetAround(text, needle) {
	const flat = text.replace(/\s+/g, " ").trim();
	if (!needle) return flat.slice(0, 180);
	const i = flat.toLowerCase().indexOf(needle.toLowerCase());
	if (i < 0) return flat.slice(0, 180);
	const from = Math.max(0, i - 60);
	return (from > 0 ? "…" : "") + flat.slice(from, from + 180).trim() + (from + 180 < flat.length ? "…" : "");
}
var deletedCache = /* @__PURE__ */ new Map();
async function channelPostDeleted(rec) {
	if (!userSession() || Date.now() < userBlockedUntil) return false;
	const ids = rec.channelMsgIds || [];
	const chat = rec.channelChatId || bindings.channelId || "";
	if (!ids.length || !chat) return false;
	const cacheKey = `${chat}:${ids.join(",")}`;
	const cached = deletedCache.get(cacheKey);
	if (cached && Date.now() - cached.at < 3e5) return cached.deleted;
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, chat);
		const deleted = !(await withTimeout(client.getMessages(peer, { ids }), 12e3, "getMessages timeout") || []).some((m) => m && m.id && m.className !== "MessageEmpty");
		deletedCache.set(cacheKey, {
			at: Date.now(),
			deleted
		});
		return deleted;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) userBlockedUntil = Date.now() + (wait + 5) * 1e3;
		else if (!err?.errorMessage) dropUserbot();
		return false;
	}
}
function channelRef(channel) {
	if (channel.username) return `@${channel.username.replace(/^@/, "")}`;
	const n = Number(channel.id);
	return Number.isSafeInteger(n) ? n : channel.id;
}
async function serverSearch(client, peer, query) {
	return await withTimeout(client.getMessages(peer, {
		search: searchQueryFor(query),
		limit: 60
	}), 15e3, "search timeout") || [];
}
async function scanRecent(client, peer, limit = 800) {
	return await withTimeout(client.getMessages(peer, { limit }), 45e3, "scan timeout") || [];
}
var scanCache = /* @__PURE__ */ new Map();
var SCAN_TTL = 12e4;
async function scanRecentCached(client, peer, channelKey) {
	const hit = scanCache.get(channelKey);
	if (hit && Date.now() - hit.at < SCAN_TTL) return hit.msgs;
	const msgs = await scanRecent(client, peer);
	scanCache.set(channelKey, {
		at: Date.now(),
		msgs
	});
	return msgs;
}
function searchQueryFor(raw) {
	return raw.replace(/[^\p{L}\p{N}]+/gu, " ").trim() || raw;
}
function escapeRe(s) {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
var NON_ACCUSATION_LINE_RE = /(оспор|обжал|по\s*(всем\s*)?вопрос|для\s*связ|связ[ьи]|контакт|админ|administrator|\badmin\b|support|поддержк|dispute|appeal|помощ|реклам|сотруднич|менеджер|гарант|куп(лю|ить)|прод(ам|аж|ать)|прайс|услуг|сервис|магазин|\bshop\b|подписк|вступай|вступить|присоединя|заказать|скидк|акци|цен[аы])/iu;
var ACCUSED_LABEL_RE = /^(?:[📛🚫❌🤡⚠🔴🛑‼️\s])*(?:ответчик|обвиняем\w*|скамер|кидал\w*|мошенник|виновник|respondent|defendant)\s*:?\s*$/iu;
function isStrictChannel(channel) {
	return /wwh/i.test(channel.title || "") || /wwh/i.test(channel.username || "");
}
var IGNORE_USERNAMES = /* @__PURE__ */ new Set([
	"europepromo",
	"ctoroot",
	"sbepbank",
	BOT_USERNAME.toLowerCase()
]);
function isIgnoredHandle(uname) {
	return IGNORE_USERNAMES.has((uname || "").replace(/^@/, "").toLowerCase());
}
function usernameOnLine(line, uname) {
	if (!uname) return false;
	return new RegExp("@?(?<!\\w)" + escapeRe(uname) + "(?!\\w)", "iu").test(line);
}
function idOnLine(line, id) {
	const digits = (id || "").replace(/\D/g, "");
	if (digits.length < 5) return false;
	return new RegExp("(?<!\\d)" + digits + "(?!\\d)").test(line);
}
function arbitrationAccused(line, strict = false) {
	const marker = strict ? "(?:пользовател\\S*\\s+|юзер\\S*\\s+|user\\s+|@)" : "(?:пользовател\\S*\\s+|юзер\\S*\\s+|человек\\S*\\s+|аккаунт\\S*\\s+|user\\s+|@)?";
	const m = line.match(new RegExp("(?:^|\\s)(?:на|против|on|against)\\s+" + marker + "(.+)$", "i"));
	if (!m) return "";
	return m[1].split(/\s+(?:от|from|by|заявител\S*|подал\S*|reporter)\s+/i)[0] || "";
}
function postMatchesSubject(body, username, id, strict = false) {
	const uname = (username || "").replace(/^@/, "").toLowerCase();
	const ignoredName = !uname || IGNORE_USERNAMES.has(uname);
	if (ignoredName && !id) return false;
	let labelAbove = false;
	for (const line of body.split(/\r?\n/)) {
		if (/арбитраж|arbitr/i.test(line)) {
			const accused = arbitrationAccused(line, strict);
			if (accused && (!ignoredName && usernameOnLine(accused, uname) || idOnLine(accused, id))) return true;
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		const hasId = idOnLine(line, id);
		const hasU = !ignoredName && usernameOnLine(line, uname);
		if (!hasId && !hasU) {
			if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
			continue;
		}
		let rest = line;
		if (uname) rest = rest.replace(new RegExp("@?" + escapeRe(uname), "ig"), " ");
		const idDigits = (id || "").replace(/\D/g, "");
		if (idDigits.length >= 5) rest = rest.replace(new RegExp(idDigits, "g"), " ");
		if (!NON_ACCUSATION_LINE_RE.test(rest)) {
			if (!strict) return true;
			if (labelAbove) return true;
		}
		if (line.trim()) labelAbove = ACCUSED_LABEL_RE.test(line);
	}
	return false;
}
async function userSearchChannel(channel, query, subject) {
	if (Date.now() < userBlockedUntil) return [];
	try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(channel));
		const strict = isStrictChannel(channel);
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, query)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(channel.id))) if (m.id) byId.set(m.id, m);
		const out = [];
		for (const m of byId.values()) {
			const body = m.message || "";
			if (!m.id || !body || !postMatchesSubject(body, subject.username, subject.id, strict)) continue;
			out.push({
				channelId: channel.id,
				channelTitle: channel.title || "канал",
				messageId: m.id,
				link: messageLink(channel, m.id),
				date: (m.date || 0) * 1e3,
				snippet: snippetAround(body, subject.username || subject.id)
			});
		}
		return out;
	} catch (err) {
		const wait = floodSeconds(err);
		if (wait) {
			userBlockedUntil = Date.now() + (wait + 5) * 1e3;
			console.warn(`[epb] userbot FLOOD_WAIT ${wait}s`);
		} else if (!err?.errorMessage) dropUserbot();
		return [];
	}
}
async function diagnoseUserSearch(input) {
	const parsed = parseTelegramInput(input);
	const uname = parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const q = uname || id;
	if (!q) return "Укажите @username или ID для проверки.";
	if (!hasUserbot()) return "Юзербот не подключён (нет сессии). Подключите: /userbot.";
	const channels = checkChannels();
	if (!channels.length) return "Не выбрано ни одного канала для поиска. Выберите: /userbot → каналы.";
	const st = await userbotStatus();
	if (!st.ok) return `Аккаунт не отвечает: ${st.error || "ошибка"}`;
	let resolvedId = id;
	if (uname && !resolvedId) {
		const r = await resolveUsernameMtproto(uname, "");
		if (r && r !== "busy" && r.id) resolvedId = r.id;
	}
	const idDigits = (resolvedId || "").replace(/\D/g, "");
	const mentions = (body) => uname && body.toLowerCase().includes(uname) || idDigits.length >= 5 && body.includes(idDigits);
	const lines = [`Аккаунт: ${st.name || "ок"}. Каналов: ${channels.length}. Ищу «${q}»${resolvedId && resolvedId !== q ? ` (id ${resolvedId})` : ""}…`];
	let total = 0;
	for (const ch of channels) try {
		const { client } = await userbot();
		const peer = await userInputPeer(client, channelRef(ch));
		const byId = /* @__PURE__ */ new Map();
		for (const m of await serverSearch(client, peer, q)) if (m.id) byId.set(m.id, m);
		for (const m of await scanRecentCached(client, peer, chatIdKey(ch.id))) if (m.id) byId.set(m.id, m);
		const msgs = [...byId.values()];
		const strict = isStrictChannel(ch);
		const mentioned = msgs.filter((m) => m.id && mentions(m.message || ""));
		const relevant = msgs.filter((m) => m.id && postMatchesSubject(m.message || "", uname, resolvedId, strict));
		total += relevant.length;
		lines.push(`• ${ch.title || ch.username || ch.id}: просмотрено ${msgs.length}, упомянут ${mentioned.length}, в тему ${relevant.length}`);
	} catch (err) {
		lines.push(`• ${ch.title || ch.username || ch.id}: ошибка — ${err?.message || String(err)}`);
	}
	lines.push(`Итого по делу: ${total}.`);
	return lines.join("\n");
}
async function resolveUsernameMtproto(username, userId = "") {
	const key = username.toLowerCase();
	if (!botToken()) return null;
	if (Date.now() < mtBlockedUntil) return "busy";
	if (Date.now() - (mtMisses.get(key) || 0) < 18e5) return null;
	const running = mtInflight.get(key);
	if (running) return running;
	if (userId && tooMany(`mtproto:user:${userId}`, 8, 6e4)) return "busy";
	if (tooMany("mtproto:resolve", 30, 6e4) || tooMany("mtproto:resolve:h", 400, 36e5)) return "busy";
	const job = (async () => {
		try {
			const ask = async () => {
				const { client, Api } = await mtproto();
				if (client.connected === false) throw new Error("mtproto disconnected");
				return withTimeout(client.invoke(new Api.contacts.ResolveUsername({ username })), 1e4, "mtproto request timeout");
			};
			let raw;
			try {
				raw = await ask();
			} catch (err) {
				if (err?.errorMessage || floodSeconds(err)) throw err;
				dropMtproto();
				raw = await ask();
			}
			const result = raw;
			const user = result.users?.[0];
			const id = String(user?.id ?? result.peer?.userId ?? "");
			if (!/^\d{5,15}$/.test(id)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			return {
				username: user?.username || username,
				id
			};
		} catch (err) {
			const wait = floodSeconds(err);
			if (wait) {
				mtBlockedUntil = Date.now() + (wait + 5) * 1e3;
				console.warn(`[epb] MTProto FLOOD_WAIT ${wait}s, lookups paused`);
				return "busy";
			}
			const rpc = err?.errorMessage;
			if (rpc && /USERNAME_(NOT_OCCUPIED|INVALID)/.test(rpc)) {
				mtMisses.set(key, Date.now());
				return null;
			}
			if (!rpc) dropMtproto();
			return null;
		} finally {
			mtInflight.delete(key);
			if (mtMisses.size > 5e3) mtMisses.clear();
		}
	})();
	mtInflight.set(key, job);
	return job;
}
async function lookupVerifiedId(username, userId = "") {
	const key = username.replace(/^@/, "").toLowerCase();
	if (!key) return null;
	const cached = idCache[key];
	if (cached) return {
		username,
		id: cached
	};
	const chat = await tgSoft("getChat", { chat_id: `@${key}` });
	if (chat?.id) {
		rememberHandle(chat.username || username, String(chat.id));
		return {
			username: chat.username || username,
			id: String(chat.id)
		};
	}
	const mt = await resolveUsernameMtproto(key, userId);
	if (mt && mt !== "busy" && mt.id) {
		rememberHandle(mt.username, mt.id);
		return mt;
	}
	return mt === "busy" ? "busy" : null;
}
async function verifyAccountPair(username, id) {
	const handle = username.replace(/^@/, "").trim();
	if (!handle || !id) return { check: "unknown" };
	const found = await lookupVerifiedId(handle);
	if (!found || found === "busy") return { check: "unknown" };
	return found.id === id ? { check: "ok" } : {
		check: "mismatch",
		realId: found.id
	};
}
async function resolveHandleServer(input, userId = "") {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (tooMany("resolve:global", 80, 6e4)) {
		const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
		if (cached && (!parsed.id || cached === parsed.id)) return {
			username: parsed.username,
			id: cached,
			source: "telegram"
		};
		return {
			username: parsed.username,
			id: parsed.id,
			source: parsed.id ? "parsed" : "unresolved"
		};
	}
	if (parsed.id) {
		if (parsed.username) {
			const pair = await verifyAccountPair(parsed.username, parsed.id);
			if (pair.check === "mismatch" && pair.realId) return {
				username: parsed.username,
				id: pair.realId,
				source: "telegram"
			};
			return {
				username: parsed.username,
				id: parsed.id,
				source: pair.check === "ok" ? "telegram" : "parsed"
			};
		}
		const chat = await tgSoft("getChat", { chat_id: parsed.id });
		if (chat?.username) rememberHandle(chat.username, parsed.id);
		return {
			username: chat?.username || "",
			id: parsed.id,
			source: chat?.username ? "telegram" : "parsed"
		};
	}
	const username = parsed.username;
	const found = await lookupVerifiedId(username, userId);
	if (found && found !== "busy") return {
		username: found.username,
		id: found.id,
		source: "telegram"
	};
	const legacy = legacyIds[username.toLowerCase()];
	if (legacy) return {
		username,
		id: legacy,
		source: "parsed"
	};
	return {
		username,
		id: "",
		source: "unresolved",
		busy: found === "busy"
	};
}
function pendingAccounts(record, fallbackUser = "", fallbackId = "") {
	if (record?.accounts?.length) return record.accounts;
	if (record?.username || record?.id) return [{
		username: record.username,
		id: record.id
	}];
	if (fallbackUser || fallbackId) return [{
		username: fallbackUser,
		id: fallbackId
	}];
	return [];
}
function formatAccountLine(username, id, html = false) {
	const handle = username.replace(/^@/, "");
	const name = handle ? `@${handle}` : "";
	if (html) return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
	return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}
function previousPosts(accounts, exceptKey = "") {
	const ids = new Set(accounts.map((a) => a.id || a.telegramId || "").filter(Boolean));
	const names = new Set(accounts.map((a) => (a.username || "").replace(/^@/, "").toLowerCase()).filter(Boolean));
	const hits = Object.entries(pendingPosts).filter(([key, rec]) => key !== exceptKey && rec.status === "published").filter(([, rec]) => pendingAccounts(rec).some((a) => a.id && ids.has(a.id) || a.username && names.has(a.username.replace(/^@/, "").toLowerCase()))).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
	if (!hits.length) return "";
	return `⚠️ По этому аккаунту уже был пост: ${hits.slice(0, 3).map(([key, rec]) => `${escapeHtml(key)} (${new Date(rec.createdAt || 0).toLocaleDateString("ru-RU")})`).join(", ")}${hits.length > 3 ? ` и ещё ${hits.length - 3}` : ""}`;
}
function accountCheckHtml(a) {
	if (!a.username) return "❔ указан только ID, проверить по username нельзя";
	if (a.check === "ok") return "✅ username и ID совпадают (проверено в Telegram)";
	if (a.check === "mismatch") return `⚠️ Заявитель указал чужой ID <code>${escapeHtml(a.claimedId || "?")}</code> — заменён на настоящий ID @${escapeHtml(a.username.replace(/^@/, ""))}`;
	return "❔ связку username и ID проверить не удалось";
}
function applicationBriefHtml(app) {
	const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
	const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const accounts = scammerAccounts(app);
	const scammer = accounts.map((a) => `${formatAccountLine(a.username, a.telegramId, true)}\n${accountCheckHtml(a)}`).join("\n");
	const brief = (app.summary || app.story).trim();
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Аккаунт</b>\n${scammer}`,
		...previousPosts(accounts) ? [previousPosts(accounts)] : [],
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(brief)}`
	].join("\n");
}
function applicationDetailHtml(app) {
	const detail = app.story.trim();
	const brief = (app.summary || "").trim();
	if (!detail || detail === brief) return "";
	return `<b>Подробно</b>\n${escapeHtml(detail)}`;
}
function formatScamAmount(amount, currency) {
	const value = amount.trim();
	if (!value) return "";
	if (currency === "USD") return `scam ${escapeHtml(value)}$`;
	return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}
function formatChannelAccounts(accounts, amount = "", currency = "") {
	const scam = formatScamAmount(amount, currency);
	const multi = accounts.length > 1;
	return accounts.map((a, i) => {
		const handle = a.username.replace(/^@/, "");
		const name = handle ? `@${escapeHtml(handle)}` : "";
		const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
		const last = i === accounts.length - 1;
		if (multi) {
			const head = [name, id].filter(Boolean).join(" ");
			if (!last) return `${head} ;`;
			return scam ? `${head} - ${scam}` : head;
		}
		if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
		return [name, id].filter(Boolean).join("\n");
	});
}
function channelHtml(accounts, story, amount = "", currency = "", bodyHtml = "") {
	const people = formatChannelAccounts(accounts, amount, currency);
	const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
	return [
		...people,
		"",
		bodyHtml.trim() || escapeHtml(story.trim()),
		"",
		subscribe
	].filter((line, i, arr) => line !== "" || arr[i - 1] !== "" && i !== 0).join("\n").replace(/\n{3,}/g, "\n\n");
}
function applicationCaption(app) {
	const scamLine = scammerAccounts(app).map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
	const victimUser = app.victim.username.replace(/^@/, "");
	return [
		`<b>Жалоба ${escapeHtml(app.id)}</b>`,
		`Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
		`Аккаунт:\n${scamLine}`,
		`Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`
	].join("\n").slice(0, 1024);
}
function splitHtml(html, max = 4090) {
	if (html.length <= max) return [html];
	const tokens = html.match(/<[^>]*>|&[#a-zA-Z0-9]+;|[\s\S]/g) || [];
	const parts = [];
	const closers = (stack) => stack.map((t) => `</${t.name}>`).reverse().join("");
	const openers = (stack) => stack.map((t) => t.tag).join("");
	let stack = [];
	let cur = "";
	let lastNl = null;
	let lastSpace = null;
	for (let i = 0; i < tokens.length; i++) {
		const token = tokens[i];
		if (cur.length + token.length + closers(stack).length > max && cur.trim()) {
			const lastBreak = lastNl && lastNl.at > max / 3 ? lastNl : lastSpace && lastSpace.at > max / 3 ? lastSpace : null;
			lastNl = null;
			lastSpace = null;
			if (lastBreak) {
				parts.push(cur.slice(0, lastBreak.at) + closers(lastBreak.stack));
				stack = [...lastBreak.stack];
				cur = openers(stack);
				i = lastBreak.next - 1;
				continue;
			}
			parts.push(cur + closers(stack));
			cur = openers(stack);
		}
		const tag = token.match(/^<(\/)?([a-zA-Z0-9-]+)/);
		if (tag) {
			const name = tag[2].toLowerCase();
			if (tag[1]) {
				const idx = stack.map((t) => t.name).lastIndexOf(name);
				if (idx >= 0) stack = stack.slice(0, idx);
			} else if (!token.endsWith("/>")) stack = [...stack, {
				name,
				tag: token
			}];
		}
		cur += token;
		if (token === "\n") lastNl = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
		else if (token === " ") lastSpace = {
			at: cur.length - 1,
			stack: [...stack],
			next: i + 1
		};
	}
	if (cur.replace(/<[^>]*>/g, "").trim()) parts.push(cur);
	return parts.map((p) => p.replace(/^\n+/, ""));
}
function reviewKeyboard(appId = "") {
	return { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: appId ? `pub:${appId}` : "pub"
	}, {
		text: "Отклонить",
		callback_data: appId ? `rej:${appId}` : "rej"
	}]] };
}
function publishChoiceKeyboard(key = "") {
	const suffix = key ? `:${key}` : "";
	const rows = [[{
		text: "Опубликовать с рассылкой",
		callback_data: `puball${suffix}`.slice(0, 64)
	}], [{
		text: "Опубликовать без рассылки",
		callback_data: `pubch${suffix}`.slice(0, 64)
	}]];
	if (key && pendingPosts[key]) {
		rows.push([{
			text: "✏ Изменить текст",
			callback_data: `pedit:${key}`
		}, {
			text: "👁 Предпросмотр",
			callback_data: `pview:${key}`
		}]);
		if (pendingPosts[key].postHtml) rows.push([{
			text: "↩ Вернуть исходный текст",
			callback_data: `porig:${key}`
		}]);
	}
	return { inline_keyboard: rows };
}
async function tgForm(method, form) {
	const ctrl = new AbortController();
	const timer = setTimeout(() => ctrl.abort(), 12e4);
	try {
		const json = await (await fetch(`${botApi()}/${method}`, {
			method: "POST",
			body: form,
			signal: ctrl.signal
		})).json();
		if (!json.ok) throw new Error(json.description || method);
		return json.result;
	} finally {
		clearTimeout(timer);
	}
}
var TG_UPLOAD_MAX = 51380224;
function mediaSize(file) {
	return file.size || evidenceBytesOnDisk(file.storageKey);
}
function evidencePublicUrl(storageKey) {
	if (!storageKey || !sanitizeEvidenceId(storageKey)) return "";
	const site = publicSiteUrl();
	if (!site) return "";
	const exp = Date.now() + 864e5;
	const sig = evidenceSig(storageKey, exp);
	return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}&exp=${exp}&sig=${sig}`;
}
async function sendMediaFile(chatId, file, opts = {}) {
	const size = mediaSize(file);
	if (file.kind === "video" && size > TG_UPLOAD_MAX) return sendLargeVideo(chatId, file, opts);
	const blob = evidenceBlob(file);
	if (!blob) throw new Error("empty file");
	if (blob.size > TG_UPLOAD_MAX && file.kind === "video") return sendLargeVideo(chatId, file, opts);
	const form = new FormData();
	form.set("chat_id", String(chatId));
	if (opts.caption) {
		form.set("caption", opts.caption);
		form.set("parse_mode", "HTML");
	}
	if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
	if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
	if (file.kind === "video") {
		form.set("video", blob, file.name || "video.mp4");
		const sent = await tgForm("sendVideo", form);
		return {
			...sent,
			fileId: sent.video?.file_id,
			kind: "video"
		};
	}
	form.set("photo", blob, file.name || "photo.jpg");
	const sent = await tgForm("sendPhoto", form);
	return {
		...sent,
		fileId: sent.photo?.at(-1)?.file_id,
		kind: "photo"
	};
}
async function sendLargeVideo(chatId, file, opts = {}) {
	const url = evidencePublicUrl(file.storageKey);
	const extra = { chat_id: chatId };
	if (opts.caption) {
		extra.caption = opts.caption;
		extra.parse_mode = "HTML";
	}
	if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
	if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
	if (url) {
		const video = await tgSoft("sendVideo", {
			...extra,
			video: url,
			supports_streaming: true
		});
		if (video) return {
			...video,
			fileId: video.video?.file_id,
			kind: "video"
		};
		const doc = await tgSoft("sendDocument", {
			...extra,
			document: url
		});
		if (doc) return {
			message_id: doc.message_id,
			chat: doc.chat,
			fileId: doc.document?.file_id,
			kind: "video"
		};
	}
	const link = url || file.name || "видео";
	return {
		...await tg("sendMessage", {
			chat_id: chatId,
			text: [
				opts.caption,
				`Видео: ${escapeHtml(file.name || "файл")}`,
				url ? `<a href="${url}">скачать</a>` : link
			].filter(Boolean).join("\n"),
			parse_mode: "HTML",
			disable_web_page_preview: false,
			reply_markup: opts.replyMarkup,
			reply_to_message_id: opts.replyTo
		}),
		kind: "video"
	};
}
function storePending(app, files) {
	const accounts = scammerAccounts(app).map((a) => ({
		username: a.username.replace(/^@/, ""),
		id: a.telegramId
	}));
	const first = accounts[0] || {
		username: app.scammer.username,
		id: app.scammer.telegramId
	};
	pendingPosts[app.id] = {
		username: first.username,
		id: first.id,
		accounts,
		story: app.story,
		summary: app.summary || "",
		amount: app.damageAmount,
		currency: app.damageCurrency,
		files,
		victimId: app.victim.telegramId,
		victimUsername: app.victim.username,
		createdAt: app.createdAt || Date.now(),
		status: "pending"
	};
	savePending();
}
function scamLabel(record) {
	const accounts = pendingAccounts(record);
	if (!accounts.length) return "аккаунт";
	return accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", ");
}
async function notifyApplicant(record, appId, kind) {
	const chatId = record?.victimId;
	if (!chatId) return;
	const scam = scamLabel(record);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: kind === "pending" ? btUser(chatId, "pendingNotice", {
			id: appId,
			scam
		}) : kind === "published" ? btUser(chatId, "publishedNotice", {
			id: appId,
			scam
		}) : btUser(chatId, "rejectedNotice", {
			id: appId,
			scam
		}),
		disable_web_page_preview: true
	});
}
function listComplaintsForUser(telegramId) {
	const uid = String(telegramId || "").trim();
	if (!uid) return [];
	return Object.entries(pendingPosts).filter(([, c]) => c.victimId === uid).map(([id, c]) => ({
		id,
		scammerUsername: pendingAccounts(c).map((a) => a.username).filter(Boolean).join(" · ") || c.username || "",
		scammerId: pendingAccounts(c).map((a) => a.id).filter(Boolean).join(", ") || c.id || "",
		amount: c.amount || "",
		currency: c.currency || "",
		status: c.status || "pending",
		createdAt: c.createdAt || 0
	})).sort((a, b) => b.createdAt - a.createdAt);
}
var loginStates = /* @__PURE__ */ new Map();
function ownerLoginActive(chatId) {
	const st = loginStates.get(String(chatId));
	if (!st) return false;
	if (Date.now() - st.touched > 6e5) {
		st.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(chatId));
		return false;
	}
	return true;
}
async function sendOwnerPanel(chatId) {
	const st = await userbotStatus();
	const connected = st.ok;
	const channels = checkChannels();
	const rows = [];
	if (connected) {
		rows.push([{
			text: "📡 Выбрать каналы для поиска",
			callback_data: "ub:chans"
		}]);
		rows.push([{
			text: "🔌 Переподключить аккаунт",
			callback_data: "ub:connect"
		}]);
		rows.push([{
			text: "❌ Отключить аккаунт",
			callback_data: "ub:off"
		}]);
	} else rows.push([{
		text: "➕ Подключить аккаунт",
		callback_data: "ub:connect"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Юзербот для поиска по блеклистам</b>",
			connected ? `Аккаунт: ${escapeHtml(st.name || "подключён")} ✅` : "Аккаунт не подключён",
			`Каналов выбрано для поиска: ${channels.length}`,
			"",
			connected ? "Поиск в мини-приложении идёт по выложенным жалобам EPB и по выбранным каналам (через аккаунт, по username, включая старые посты)." : "Подключите свой аккаунт Telegram, затем выберите каналы, по которым искать. Понадобятся api_id и api_hash с my.telegram.org."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
}
async function startOwnerLogin(chatId) {
	const existing = loginStates.get(String(chatId));
	if (existing?.client) await existing.client.disconnect?.().catch(() => {});
	loginStates.set(String(chatId), {
		step: "apiId",
		touched: Date.now()
	});
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Подключение аккаунта</b>",
			"",
			"Нужны api_id и api_hash: зайдите на https://my.telegram.org → API development tools.",
			"",
			"Пришлите <b>api_id</b> (число).",
			"Отмена: /cancel_userbot"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function handleOwnerLogin(chatId, text) {
	const key = String(chatId);
	const st = loginStates.get(key);
	if (!st) return false;
	st.touched = Date.now();
	const value = text.trim();
	const fail = async (msg) => {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: msg
		});
	};
	try {
		if (st.step === "apiId") {
			const n = Number(value);
			if (!n || !Number.isInteger(n)) return await fail("api_id — это число. Пришлите ещё раз."), true;
			st.apiId = n;
			st.step = "apiHash";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Теперь пришлите <b>api_hash</b>.",
				parse_mode: "HTML"
			});
			return true;
		}
		if (st.step === "apiHash") {
			if (!/^[a-f0-9]{16,}$/i.test(value)) return await fail("Похоже, это не api_hash. Пришлите ещё раз."), true;
			st.apiHash = value;
			st.step = "phone";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Пришлите номер телефона аккаунта в формате +7999…"
			});
			return true;
		}
		if (st.step === "phone") {
			if (!/^\+?\d{7,15}$/.test(value.replace(/\s/g, ""))) return await fail("Неверный номер. Пример: +79991234567"), true;
			st.phone = value.replace(/\s/g, "");
			const { TelegramClient } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.r()));
			const { StringSession } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.i()));
			const { Api } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
			const { Logger } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.a()));
			st.client = new TelegramClient(new StringSession(""), st.apiId, st.apiHash, {
				connectionRetries: 2,
				baseLogger: new Logger("none")
			});
			st.Api = Api;
			await withTimeout(st.client.connect(), 25e3, "connect timeout");
			st.phoneCodeHash = (await withTimeout(st.client.sendCode({
				apiId: st.apiId,
				apiHash: st.apiHash
			}, st.phone), 25e3, "sendCode timeout")).phoneCodeHash;
			st.step = "code";
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: "Код отправлен в Telegram на этот аккаунт. Пришлите код. Если боитесь, что Telegram заблокирует код в сообщении — вставьте пробелы: 1 2 3 4 5."
			});
			return true;
		}
		if (st.step === "code") {
			const code = value.replace(/\D/g, "");
			if (!code) return await fail("Пришлите код из Telegram."), true;
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.SignIn({
					phoneNumber: st.phone,
					phoneCodeHash: st.phoneCodeHash,
					phoneCode: code
				})), 25e3, "signin timeout");
			} catch (err) {
				const m = err?.errorMessage || err?.message || "";
				if (/SESSION_PASSWORD_NEEDED/.test(m)) {
					st.step = "password";
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: "На аккаунте включена двухфакторная защита. Пришлите пароль."
					});
					return true;
				}
				if (/PHONE_CODE_INVALID|PHONE_CODE_EXPIRED/.test(m)) return await fail("Код неверный или просрочен. Пришлите ещё раз, либо начните заново: /cancel_userbot."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
		if (st.step === "password") {
			const { computeCheck } = await import("../_libs/telegram+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const check = await computeCheck(await st.client.invoke(new st.Api.account.GetPassword()), value);
			try {
				await withTimeout(st.client.invoke(new st.Api.auth.CheckPassword({ password: check })), 25e3, "password timeout");
			} catch (err) {
				const m = err?.errorMessage || "";
				if (/PASSWORD_HASH_INVALID/.test(m)) return await fail("Пароль неверный. Пришлите ещё раз."), true;
				throw err;
			}
			await finishOwnerLogin(chatId, st);
			return true;
		}
	} catch (err) {
		loginStates.delete(key);
		await st.client?.disconnect?.().catch(() => {});
		await fail(`Не удалось подключить аккаунт: ${err?.message || "ошибка"}. Начните заново: /userbot`);
		return true;
	}
	return true;
}
async function finishOwnerLogin(chatId, st) {
	saveUserSession(st.client.session.save());
	bindings.userbotApi = {
		apiId: st.apiId,
		apiHash: st.apiHash
	};
	saveBindings();
	await st.client.disconnect?.().catch(() => {});
	loginStates.delete(String(chatId));
	dropUserbot();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Аккаунт подключён ✅\nТеперь выберите каналы для поиска."
	});
	await sendChannelPicker(chatId);
}
async function sendChannelPicker(chatId, editMessageId) {
	const dialogs = [];
	try {
		const { client } = await userbot();
		const list = await withTimeout(client.getDialogs({ limit: 200 }), 2e4, "dialogs timeout");
		for (const d of list) {
			const e = d?.entity;
			if (!e || e.className !== "Channel") continue;
			dialogs.push({
				id: `-100${e.id?.toString?.() ?? e.id}`,
				title: d.title || e.title || "канал",
				username: e.username || void 0
			});
		}
	} catch (err) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось получить список каналов: ${err?.message || "ошибка"}`
		});
		return;
	}
	if (!dialogs.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "У аккаунта нет каналов. Подпишитесь на нужные каналы и откройте список снова: /userbot"
		});
		return;
	}
	const selected = new Set(checkChannels().map((c) => chatIdKey(c.id)));
	const rows = dialogs.slice(0, 60).map((d) => [{
		text: `${selected.has(chatIdKey(d.id)) ? "✅" : "▫️"} ${cut(d.title, 40)}`,
		callback_data: `ub:tgl:${d.id}`
	}]);
	rows.push([{
		text: "Готово",
		callback_data: "ub:done"
	}]);
	const text = "<b>Каналы для поиска</b>\nОтметьте, по каким каналам искать. Нажмите «Готово», когда закончите.";
	if (editMessageId) await tgSoft("editMessageText", {
		chat_id: chatId,
		message_id: editMessageId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	else await tgSoft("sendMessage", {
		chat_id: chatId,
		text,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: rows }
	});
	dialogCache.clear();
	for (const d of dialogs) dialogCache.set(chatIdKey(d.id), d);
}
var dialogCache = /* @__PURE__ */ new Map();
async function toggleCheckChannel(id) {
	const list = [...checkChannels()];
	const idx = list.findIndex((c) => sameChat(c.id, id));
	if (idx >= 0) list.splice(idx, 1);
	else {
		const d = dialogCache.get(chatIdKey(id));
		list.push({
			id,
			title: d?.title,
			username: d?.username,
			addedAt: Date.now()
		});
	}
	bindings.checkChannels = list.slice(-100);
	saveBindings();
}
async function handleOwnerCallback(cb) {
	const data = cb.data || "";
	if (!data.startsWith("ub:")) return false;
	const chatId = cb.message?.chat.id;
	if (!chatId || !isOwner(cb.from?.id)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Недоступно",
			show_alert: true
		});
		return true;
	}
	const [, action, ...rest] = data.split(":");
	const answer = (t = "") => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: t || void 0
	});
	if (action === "connect") {
		await answer();
		await startOwnerLogin(chatId);
	} else if (action === "off") {
		clearUserSession();
		delete bindings.userbotApi;
		saveBindings();
		await answer("Аккаунт отключён");
		await sendOwnerPanel(chatId);
	} else if (action === "chans") {
		await answer();
		await sendChannelPicker(chatId);
	} else if (action === "tgl") {
		await toggleCheckChannel(rest.join(":"));
		await answer();
		await sendChannelPicker(chatId, cb.message.message_id);
	} else if (action === "done") {
		await answer("Сохранено");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Готово. Каналов для поиска: ${checkChannels().length}.`
		});
	} else await answer();
	return true;
}
var CHECK_INDEX_PATH = join(DATA_DIR, "telegram-check-index.json");
var checkIndex = readJson(CHECK_INDEX_PATH) || {};
var checkIndexTimer = null;
function saveCheckIndex() {
	if (checkIndexTimer) return;
	checkIndexTimer = setTimeout(() => {
		checkIndexTimer = null;
		try {
			writeJsonAtomic(CHECK_INDEX_PATH, checkIndex);
		} catch {}
	}, 3e3);
}
function checkChannels() {
	return bindings.checkChannels || [];
}
function isCheckChannel(id) {
	if (id == null) return void 0;
	return checkChannels().find((c) => sameChat(c.id, id));
}
function tokensFromText(text) {
	const usernames = /* @__PURE__ */ new Set();
	const ids = /* @__PURE__ */ new Set();
	for (const m of text.matchAll(/@([A-Za-z][A-Za-z0-9_]{3,31})/g)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,31})/gi)) usernames.add(m[1].toLowerCase());
	for (const m of text.matchAll(/(?:tg:\/\/user\?id=|\bid[:\s=]*)(\d{5,15})/gi)) ids.add(m[1]);
	for (const m of text.matchAll(/\b(\d{7,15})\b/g)) ids.add(m[1]);
	return {
		usernames: [...usernames],
		ids: [...ids]
	};
}
function messageLink(channel, messageId) {
	if (channel.username) return `https://t.me/${channel.username.replace(/^@/, "")}/${messageId}`;
	return `https://t.me/c/${String(channel.id).replace(/^-100/, "").replace(/^-/, "")}/${messageId}`;
}
function addCheckHit(token, hit) {
	const list = checkIndex[token] || (checkIndex[token] = []);
	if (list.some((h) => sameChat(h.channelId, hit.channelId) && h.messageId === hit.messageId)) return;
	list.unshift(hit);
	if (list.length > 25) list.length = 25;
}
function indexCheckPost(channel, messageId, text, date) {
	const body = (text || "").slice(0, 4096);
	if (!body.trim()) return;
	const { usernames, ids } = tokensFromText(body);
	if (!usernames.length && !ids.length) return;
	const snippet = body.replace(/\s+/g, " ").trim().slice(0, 160);
	const hit = {
		channelId: String(channel.id),
		channelTitle: channel.title || "канал",
		messageId,
		link: messageLink(channel, messageId),
		date: date * 1e3 || Date.now(),
		snippet
	};
	for (const u of usernames) addCheckHit(`@${u}`, {
		...hit,
		username: u
	});
	for (const id of ids) addCheckHit(id, hit);
	const keys = Object.keys(checkIndex);
	if (keys.length > 2e5) for (const k of keys.slice(0, keys.length - 18e4)) delete checkIndex[k];
	saveCheckIndex();
}
function removeCheckChannelFromIndex(channelId) {
	for (const [token, list] of Object.entries(checkIndex)) {
		const kept = list.filter((h) => !sameChat(h.channelId, channelId));
		if (kept.length) checkIndex[token] = kept;
		else delete checkIndex[token];
	}
	saveCheckIndex();
}
var DEFAULT_MANUAL_SOURCE = "Сторонний источник";
var RECENT_FINDS_MAX = 25;
function recordFind(uname, id, display, result) {
	if (!result.channels.length) return;
	if (!uname && !id) return;
	const sources = [];
	for (const c of result.channels) {
		const title = c.channelTitle || "источник";
		const name = /wwh/i.test(title) ? "WWH" : title;
		if (!sources.includes(name)) sources.push(name);
	}
	const list = [...bindings.recentFinds || []];
	const same = (f) => uname && (f.username || "").toLowerCase() === uname || id && f.telegramId === id;
	const entry = {
		id: list.find(same)?.id || `find-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
		username: uname || void 0,
		telegramId: id || void 0,
		label: display || (uname ? `@${uname}` : `ID ${id}`),
		sources,
		at: Date.now()
	};
	bindings.recentFinds = [entry, ...list.filter((f) => !same(f))].slice(0, RECENT_FINDS_MAX);
	saveBindings();
}
function recentBlacklist(limit = 24) {
	if (!checkEnabled()) return [];
	const out = [];
	const shownKeys = /* @__PURE__ */ new Set();
	const key = (v) => (v || "").replace(/^@/, "").toLowerCase().trim();
	for (const [k, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		out.push({
			kind: "epb",
			id: k,
			account: scamLabel(rec),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
		for (const a of pendingAccounts(rec)) {
			if (a.username) shownKeys.add(key(a.username));
			if (a.id) shownKeys.add(key(a.id));
		}
	}
	for (const e of bindings.manualBlacklist || []) {
		out.push({
			kind: "manual",
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			date: e.addedAt || 0,
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note
		});
		if (e.username) shownKeys.add(key(e.username));
		if (e.telegramId) shownKeys.add(key(e.telegramId));
	}
	for (const f of bindings.recentFinds || []) {
		if (f.username && shownKeys.has(key(f.username)) || f.telegramId && shownKeys.has(key(f.telegramId))) continue;
		out.push({
			kind: "find",
			id: f.id,
			account: f.label,
			date: f.at,
			source: (f.sources || []).join(" · ")
		});
	}
	out.sort((a, b) => b.date - a.date);
	return out.slice(0, Math.max(1, limit));
}
function blacklistEntry(id) {
	if (!checkEnabled() || !id) return null;
	const rec = pendingPosts[id] || pendingPosts[id.toUpperCase()];
	if (rec && rec.status === "published" && rec.channelPosted && !rec.removedFromCheck) return {
		kind: "epb",
		id,
		account: scamLabel(rec),
		amount: rec.amount || "",
		currency: rec.currency || "",
		date: rec.createdAt || 0,
		summary: rec.summary || "",
		story: rec.story || rec.summary || ""
	};
	const man = (bindings.manualBlacklist || []).find((e) => e.id === id);
	if (man) return {
		kind: "manual",
		id,
		account: man.username ? `@${man.username.replace(/^@/, "")}` : man.telegramId ? `ID ${man.telegramId}` : "",
		date: man.addedAt || 0,
		source: man.source || DEFAULT_MANUAL_SOURCE,
		note: man.note
	};
	const find = (bindings.recentFinds || []).find((f) => f.id === id);
	if (find) return {
		kind: "find",
		id,
		account: find.label,
		date: find.at,
		source: (find.sources || []).join(" · "),
		note: "Найден по запросу проверки контрагента."
	};
	return null;
}
function matchManualBlacklist(uname, id) {
	const out = [];
	for (const e of bindings.manualBlacklist || []) {
		const eu = (e.username || "").replace(/^@/, "").toLowerCase();
		if (uname && eu === uname || id && e.telegramId === id) out.push({
			id: e.id,
			account: e.username ? `@${e.username.replace(/^@/, "")}` : e.telegramId ? `ID ${e.telegramId}` : "",
			source: e.source || DEFAULT_MANUAL_SOURCE,
			note: e.note,
			date: e.addedAt || 0
		});
	}
	return out.sort((a, b) => b.date - a.date);
}
async function checkCounterparty(input) {
	if (!checkEnabled()) return {
		query: {
			username: "",
			id: ""
		},
		epb: [],
		channels: [],
		manual: []
	};
	const parsed = parseTelegramInput(input);
	const uname = isIgnoredHandle(parsed.username) ? "" : parsed.username.replace(/^@/, "").toLowerCase();
	const id = parsed.id;
	const matched = [];
	for (const [key, rec] of Object.entries(pendingPosts)) {
		if (rec.status !== "published" || !rec.channelPosted || rec.removedFromCheck) continue;
		const accounts = pendingAccounts(rec);
		if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) matched.push({
			key,
			rec
		});
	}
	const epb = [];
	for (const { key, rec } of matched) {
		if (await channelPostDeleted(rec)) {
			rec.removedFromCheck = true;
			savePending();
			continue;
		}
		const accounts = pendingAccounts(rec);
		epb.push({
			id: key,
			accounts: accounts.map((a) => a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : "").filter(Boolean).join(", "),
			amount: rec.amount || "",
			currency: rec.currency || "",
			date: rec.createdAt || 0
		});
	}
	epb.sort((a, b) => b.date - a.date);
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (list) => {
		for (const h of list) {
			const dkey = `${chatIdKey(h.channelId)}:${h.messageId}`;
			if (seen.has(dkey)) continue;
			seen.add(dkey);
			hits.push(h);
		}
	};
	const channels = checkChannels();
	if (hasUserbot() && channels.length) {
		let effectiveId = id;
		if (uname && !effectiveId) {
			const r = await resolveUsernameMtproto(uname, "");
			if (r && r !== "busy" && r.id) effectiveId = r.id;
		}
		const subject = {
			username: uname,
			id: effectiveId
		};
		const searchTerms = [uname, effectiveId].filter(Boolean);
		for (const channel of channels) for (const term of searchTerms) push(await userSearchChannel(channel, term, subject));
	} else for (const token of [uname ? `@${uname}` : "", id].filter(Boolean)) push(checkIndex[token] || []);
	hits.sort((a, b) => b.date - a.date);
	const result = {
		query: {
			username: uname,
			id
		},
		epb,
		channels: hits.slice(0, 30),
		manual: matchManualBlacklist(uname, id)
	};
	recordFind(uname, id, uname ? `@${parsed.username.replace(/^@/, "")}` : id ? `ID ${id}` : "", result);
	return result;
}
function allowCheck(initData) {
	if (!checkEnabled()) return {
		ok: false,
		error: "disabled"
	};
	const user = verifyTelegramInitData(initData);
	if (!user) return {
		ok: false,
		error: "telegram auth required"
	};
	if (tooMany(`check:${user.id}`, 40, 6e4)) return {
		ok: false,
		error: "too many"
	};
	if (tooMany("check:global", 1500, 6e4)) return {
		ok: false,
		error: "busy"
	};
	return {
		ok: true,
		userId: user.id
	};
}
function packCaption(full, _fallback = "") {
	if (full.length <= 1024) return {
		caption: full,
		leftover: ""
	};
	return {
		caption: "",
		leftover: full
	};
}
async function attachReviewButtons(chatId, messageId, leftover, keyboard) {
	if (!leftover) return (await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Опубликовать или отклонить:",
		reply_to_message_id: messageId,
		reply_markup: keyboard
	}))?.message_id || messageId;
	const parts = splitHtml(leftover);
	let lastId = messageId;
	for (let i = 0; i < parts.length; i++) {
		const sent = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: parts[i],
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_to_message_id: i === 0 ? messageId : void 0,
			reply_markup: i === parts.length - 1 ? keyboard : void 0
		});
		if (sent?.message_id) lastId = sent.message_id;
	}
	return lastId;
}
function mediaRefsFromCopies(copies) {
	return copies.filter((c) => Boolean(c.fileId)).map((c) => ({
		type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
		file_id: c.fileId
	}));
}
function groupMedia(files) {
	const groups = [];
	let current = [];
	let currentDoc = false;
	for (const file of files) {
		const isDoc = (file.type || file.kind) === "document";
		if (current.length && (current.length >= 10 || isDoc !== currentDoc)) {
			groups.push(current);
			current = [];
		}
		currentDoc = isDoc;
		current.push(file);
	}
	if (current.length) groups.push(current);
	return groups;
}
async function sendAlbumByFileIds(chatId, files, caption, keyboard, followUp = caption) {
	if (!files.length) {
		const parts = splitHtml(followUp);
		let lastId = 0;
		let lastChat = chatId;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id: chatId,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		return {
			chat_id: lastChat,
			message_id: lastId,
			files: []
		};
	}
	if (files.length === 1) {
		const file = files[0];
		const packed = packCaption(followUp, caption);
		const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
		const payload = { chat_id: chatId };
		if (packed.caption) {
			payload.caption = packed.caption;
			payload.parse_mode = "HTML";
		}
		if (!packed.leftover) payload.reply_markup = keyboard;
		if (file.type === "video") payload.video = file.file_id;
		else if (file.type === "document") payload.document = file.file_id;
		else payload.photo = file.file_id;
		const sent = await tg(method, payload);
		if (!packed.leftover) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	const packed = packCaption(followUp, caption);
	let firstId = 0;
	for (const [i, chunk] of groupMedia(files).entries()) {
		if (chunk.length === 1) {
			const file = chunk[0];
			const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
			const payload = { chat_id: chatId };
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			if (i === 0 && packed.caption) {
				payload.caption = packed.caption;
				payload.parse_mode = "HTML";
			}
			const sent = await tg(method, payload);
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const result = await tg("sendMediaGroup", {
			chat_id: chatId,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			}))
		});
		if (i === 0) firstId = result[0]?.message_id || 0;
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendAlbumFromBlobs(chatId, blobs, caption, keyboard, followUp = caption) {
	const packed = packCaption(followUp, caption);
	const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
	const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
	const files = [];
	let firstId = 0;
	if (!small.length && large.length) {
		const sent = await sendMediaFile(chatId, large[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length > 1 ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		for (const extra of large.slice(1)) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && large.length === 1) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	if (small.length <= 1) {
		const sent = await sendMediaFile(chatId, small[0], {
			caption: packed.caption || void 0,
			replyMarkup: packed.leftover || large.length ? void 0 : keyboard
		});
		if (sent.fileId) files.push({
			type: sent.kind,
			file_id: sent.fileId
		});
		firstId = sent.message_id;
		for (const extra of large) {
			const more = await sendMediaFile(chatId, extra);
			if (more.fileId) files.push({
				type: more.kind,
				file_id: more.fileId
			});
		}
		if (!packed.leftover && !large.length) return {
			chat_id: String(sent.chat.id),
			message_id: sent.message_id,
			files
		};
		const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
		return {
			chat_id: String(sent.chat.id),
			message_id: actionId,
			files
		};
	}
	for (let i = 0; i < small.length; i += 10) {
		const chunk = small.slice(i, i + 10);
		if (chunk.length === 1) {
			const sent = await sendMediaFile(chatId, chunk[0], i === 0 && packed.caption ? { caption: packed.caption } : {});
			if (sent.fileId) files.push({
				type: sent.kind,
				file_id: sent.fileId
			});
			if (i === 0) firstId = sent.message_id;
			continue;
		}
		const form = new FormData();
		form.set("chat_id", chatId);
		const media = [];
		chunk.forEach((file, idx) => {
			const blob = evidenceBlob(file);
			if (!blob) return;
			const key = `file${i + idx}`;
			form.set(key, blob, file.name || `${key}.jpg`);
			media.push({
				type: file.kind === "video" ? "video" : "photo",
				media: `attach://${key}`,
				...i === 0 && idx === 0 && packed.caption ? {
					caption: packed.caption,
					parse_mode: "HTML"
				} : {}
			});
		});
		form.set("media", JSON.stringify(media));
		const result = await tgForm("sendMediaGroup", form);
		if (i === 0) firstId = result[0]?.message_id || 0;
		for (const msg of result) if (msg.video?.file_id) files.push({
			type: "video",
			file_id: msg.video.file_id
		});
		else if (msg.photo?.length) files.push({
			type: "photo",
			file_id: msg.photo.at(-1).file_id
		});
	}
	for (const extra of large) {
		const more = await sendMediaFile(chatId, extra);
		if (more.fileId) files.push({
			type: more.kind,
			file_id: more.fileId
		});
	}
	return {
		chat_id: chatId,
		message_id: await attachReviewButtons(chatId, firstId, packed.leftover, keyboard),
		files
	};
}
async function sendDetail(chatId, html, replyTo) {
	for (const [i, part] of splitHtml(html).entries()) await tgSoft("sendMessage", {
		chat_id: chatId,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: i === 0 ? replyTo : void 0
	});
}
async function deliverApplication(app, copies = []) {
	const caption = applicationCaption(app);
	const briefText = applicationBriefHtml(app);
	const detailText = applicationDetailHtml(app);
	const keyboard = reviewKeyboard(app.id);
	const blobs = app.evidence.filter((f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)));
	const copyFiles = mediaRefsFromCopies(copies);
	let lastError = "chat not found";
	for (const chat_id of arbiterCandidates()) try {
		if (copyFiles.length || copies.length) {
			const sent = copyFiles.length ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard, briefText) : null;
			if (sent) {
				if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
				storePending(app, sent.files);
				return {
					chat_id: sent.chat_id,
					message_id: sent.message_id
				};
			}
		}
		if (blobs.length) {
			const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard, briefText);
			if (detailText) await sendDetail(sent.chat_id, detailText, sent.message_id);
			storePending(app, sent.files);
			return {
				chat_id: sent.chat_id,
				message_id: sent.message_id
			};
		}
		const parts = splitHtml(briefText);
		let lastId = 0;
		let lastChat = chat_id;
		for (let i = 0; i < parts.length; i++) {
			const sent = await tg("sendMessage", {
				chat_id,
				text: parts[i],
				parse_mode: "HTML",
				disable_web_page_preview: true,
				reply_markup: i === parts.length - 1 ? keyboard : void 0
			});
			lastId = sent.message_id;
			lastChat = String(sent.chat.id);
		}
		if (detailText) await sendDetail(lastChat, detailText, lastId);
		storePending(app, []);
		return {
			chat_id: lastChat,
			message_id: lastId
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
async function sendApplicationToArbiters(app, copies = []) {
	const userId = app.victim.telegramId || "";
	const blocked = allowNewComplaint(userId, app.story.length);
	if (blocked) return {
		ok: false,
		error: blocked
	};
	app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
	app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
		...file,
		name: String(file.name || "file").slice(0, 120),
		dataUrl: "",
		storageKey: evidenceOwnedBy(file.storageKey, userId) ? file.storageKey : void 0
	}));
	if (app.evidence.length > 30) return {
		ok: false,
		error: btUser(userId, "tooManyFiles")
	};
	for (const account of scammerAccounts(app).slice(0, 8)) {
		account.username = String(account.username || "").replace(/^@/, "").trim();
		account.telegramId = /^\d{5,15}$/.test(String(account.telegramId || "").trim()) ? String(account.telegramId).trim() : "";
		account.check = "unknown";
		if (account.username) {
			const found = await lookupVerifiedId(account.username);
			if (found && found !== "busy") {
				if (account.telegramId && account.telegramId !== found.id) account.claimedId = account.telegramId;
				account.telegramId = found.id;
				account.check = account.claimedId ? "mismatch" : "ok";
			}
		} else if (account.telegramId) {
			const chat = await tgSoft("getChat", { chat_id: account.telegramId });
			if (chat?.type === "private" && chat.username) {
				account.username = chat.username;
				rememberHandle(chat.username, account.telegramId);
				account.check = "ok";
			}
		}
	}
	try {
		const sent = await deliverApplication(app, copies);
		if (isOfficialArbiterChat(sent.chat_id)) {
			bindings.arbiterChatId = sent.chat_id;
			saveBindings();
		}
		if (pendingPosts[app.id]) {
			pendingPosts[app.id].reviewChatId = String(sent.chat_id);
			pendingPosts[app.id].reviewMessageId = sent.message_id;
			savePending();
		}
		await notifyApplicant(pendingPosts[app.id], app.id, "pending");
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: btUser(userId, "addBotArbiter", { bot: BOT_USERNAME })
		};
		return {
			ok: false,
			error: description
		};
	}
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function evidenceBlob(item) {
	const fromUrl = dataUrlToBlob(item);
	if (fromUrl) return fromUrl;
	if (!item.storageKey) return null;
	const buf = readUploadedEvidence(item.storageKey);
	if (!buf?.length) return null;
	return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}
function parseAppKey(text, data = "") {
	const fromCb = callbackKey(data);
	if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
	const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
	if (fromText?.[1]) return fromText[1];
	return parseEpbMarker(text)?.key || fromCb;
}
function stripServiceMarker(text) {
	return text.replace(/\n*#epb[^\n]*/gi, "").replace(/\n*#published[^\n]*/gi, "").replace(/\n*#rejected[^\n]*/gi, "").replace(/\n*Статус:[^\n]*/gi, "").trim();
}
function alreadyHandled(text) {
	return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
	if (!marker) return null;
	let story = "";
	if (text.includes("Суть обмана")) story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	else story = text.replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "").replace(/\n*#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story,
		key: marker[3] ?? ""
	};
}
var PartialSendError = class extends Error {
	sentIds;
	answered;
	constructor(cause, sentIds) {
		super(cause instanceof Error ? cause.message : String(cause));
		this.sentIds = sentIds;
		this.answered = cause instanceof TgError;
	}
};
async function sendPostToChat(chat_id, html, files) {
	const ids = [];
	try {
		return await sendPostParts(chat_id, html, files, ids);
	} catch (err) {
		throw new PartialSendError(err, ids);
	}
}
async function sendPostParts(chat_id, html, files, ids) {
	const collect = (sent) => {
		for (const m of Array.isArray(sent) ? sent : [sent]) {
			const id = m?.message_id;
			if (id) ids.push(id);
		}
	};
	const packed = packCaption(html);
	const parts = packed.leftover ? splitHtml(packed.leftover, 4090) : [];
	if (!files.length) {
		const chunks = splitHtml(html, 4090);
		for (const part of chunks) collect(await tg("sendMessage", {
			chat_id,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: false
		}));
		return ids;
	}
	for (const [i, chunk] of groupMedia(files).entries()) {
		const firstCaption = i === 0 && packed.caption ? packed.caption : void 0;
		if (chunk.length === 1) {
			const file = chunk[0];
			const payload = {
				chat_id,
				caption: firstCaption,
				parse_mode: firstCaption ? "HTML" : void 0
			};
			if (file.type === "video") payload.video = file.file_id;
			else if (file.type === "document") payload.document = file.file_id;
			else payload.photo = file.file_id;
			collect(await tg(file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto", payload));
		} else collect(await tg("sendMediaGroup", {
			chat_id,
			media: chunk.map((file, idx) => ({
				type: file.type,
				media: file.file_id,
				...firstCaption && idx === 0 ? {
					caption: firstCaption,
					parse_mode: "HTML"
				} : {}
			}))
		}));
	}
	for (const part of parts) collect(await tg("sendMessage", {
		chat_id,
		text: part,
		parse_mode: "HTML",
		disable_web_page_preview: false
	}));
	return ids;
}
function isMissingRights(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /not enough rights|need administrator|have no rights|CHAT_WRITE_FORBIDDEN|not allowed to post|CHAT_SEND_\w+_FORBIDDEN/i.test(text);
}
function isChatGone(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /chat not found|bot was blocked|bot is not a member|kicked|chat was deactivated|group chat was upgraded/i.test(text);
}
function isGroupOrChannel(chat) {
	if (chat.type === "private") return false;
	if (chat.type === "group" || chat.type === "supergroup" || chat.type === "channel") return true;
	const id = Number(chat.id);
	return Number.isFinite(id) && id < 0;
}
function relayDestinations() {
	const skip = new Set([
		...channelCandidates(),
		PINNED_ARBITER_CHAT,
		bindings.arbiterChatId || "",
		...OFFICIAL_ARBITER_IDS
	].filter(Boolean).map((id) => chatIdKey(id)));
	const seen = /* @__PURE__ */ new Set();
	return (bindings.relayChats || []).filter((chat) => {
		const k = chatIdKey(chat.id);
		if (chat.status !== "on" || !isGroupOrChannel(chat) || skip.has(k) || seen.has(k)) return false;
		seen.add(k);
		return true;
	});
}
async function sendChannelPost(html, files) {
	const ids = channelCandidates();
	if (!ids.length) throw new Error("channel not found");
	let lastError = "channel not found";
	for (const chat_id of ids) try {
		return {
			chatId: chat_id,
			messageIds: await sendPostToChat(chat_id, html, files)
		};
	} catch (err) {
		if (err instanceof PartialSendError && err.sentIds.length) return {
			chatId: chat_id,
			messageIds: err.sentIds,
			partialError: err.message
		};
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
var RIGHTS_NOTICE_EVERY = 864e5;
function isMediaForbidden(err) {
	const text = err instanceof Error ? err.message : String(err);
	return /rights to send (photos|videos|documents|media|audios|voice)|CHAT_SEND_(PHOTOS|VIDEOS|MEDIA|DOCS|GIFS)_FORBIDDEN/i.test(text);
}
var BROADCAST_PATH = join(DATA_DIR, "telegram-broadcasts.json");
var broadcastJobs = readJson(BROADCAST_PATH) || [];
var migratedKeys = /* @__PURE__ */ new Map();
function saveBroadcastJobs() {
	try {
		writeJsonAtomic(BROADCAST_PATH, broadcastJobs);
	} catch {}
}
async function channelAllowsForwarding(chatId) {
	return !(await tgSoft("getChat", { chat_id: chatId }))?.has_protected_content;
}
function recordRelayDelivery(key, chatId, messageIds) {
	const ids = messageIds.filter((n) => Number.isFinite(n));
	if (!key || !ids.length) return;
	const rec = pendingPosts[key];
	if (!rec) return;
	const list = rec.relayDeliveries ||= [];
	const k = chatIdKey(chatId);
	const existing = list.find((d) => chatIdKey(d.chatId) === k);
	if (existing) {
		for (const id of ids) if (!existing.messageIds.includes(id)) existing.messageIds.push(id);
	} else list.push({
		chatId: String(chatId),
		messageIds: [...ids]
	});
	savePending();
}
async function runBroadcast(job) {
	const report = job.report;
	if (job.inflight && !job.done.includes(job.inflight)) {
		(report.unconfirmed ||= []).push(`${job.inflight}: сервер перезапустился во время отправки, повторно не отправляли`);
		report.sent += 1;
		job.done.push(job.inflight);
	}
	job.inflight = void 0;
	const done = new Set(job.done);
	const approved = relayDestinations().filter((c) => !done.has(chatIdKey(c.id)));
	report.total = Math.max(report.total, done.size + approved.length);
	let forward = Boolean(job.source?.messageIds.length) && await channelAllowsForwarding(job.source.chatId);
	if (job.source?.messageIds.length && !forward && !report.failed.some((x) => x.startsWith("пересылка"))) report.failed.push("пересылка из канала запрещена (защита контента), в чаты ушли копии");
	let forwardedOk = 0;
	let emptyInARow = 0;
	for (const chat of approved) {
		if (job.done.includes(chatIdKey(chat.id))) continue;
		const label = chat.title ? `${chat.title} (${chat.id})` : chat.id;
		job.inflight = chatIdKey(chat.id);
		saveBroadcastJobs();
		try {
			let viaForward = false;
			if (forward && job.source) {
				let result = null;
				let fwdErr = null;
				try {
					result = await tg("forwardMessages", {
						chat_id: chat.id,
						from_chat_id: job.source.chatId,
						message_ids: job.source.messageIds
					});
				} catch (err) {
					fwdErr = err;
				}
				if (!fwdErr && result && result.length >= job.source.messageIds.length) {
					viaForward = true;
					forwardedOk += 1;
					emptyInARow = 0;
					recordRelayDelivery(job.key, chat.id, result.map((m) => m?.message_id).filter((n) => typeof n === "number"));
				} else if (fwdErr instanceof TgError && /protected|CHAT_FORWARDS_RESTRICTED|message to forward not found|message can't be forwarded/i.test(fwdErr.message)) {
					forward = false;
					report.failed.push("пересылка из канала невозможна (защита контента или пост удалён), в чаты ушли копии");
				} else if (fwdErr instanceof TgError && (isChatGone(fwdErr) || isMissingRights(fwdErr) && !isMediaForbidden(fwdErr))) throw fwdErr;
				else if (fwdErr instanceof TgError && isMediaForbidden(fwdErr)) {} else {
					(report.unconfirmed ||= []).push(`${label}: ${fwdErr instanceof Error ? fwdErr.message.replace(/^Bad Request: /, "") : `переслано ${result?.length ?? 0} из ${job.source.messageIds.length}`}`);
					viaForward = true;
					if (!fwdErr && result && !result.length && !forwardedOk && ++emptyInARow >= 3) {
						forward = false;
						report.failed.push("пересылка из канала не работает (Telegram пропускает сообщения), остальным чатам ушли копии");
					}
				}
			}
			if (!viaForward) try {
				const ids = await sendPostToChat(chat.id, job.html, job.files);
				recordRelayDelivery(job.key, chat.id, ids);
				if (forward) (report.copies ||= []).push(label);
			} catch (err) {
				const refusedCleanly = err instanceof PartialSendError && err.answered && !err.sentIds.length;
				if (!job.files.length || !refusedCleanly || !isMediaForbidden(err)) throw err;
				const ids = await sendPostToChat(chat.id, job.html, []);
				recordRelayDelivery(job.key, chat.id, ids);
				(report.textOnly ||= []).push(label);
			}
			report.sent += 1;
		} catch (err) {
			if (isMissingRights(err)) {
				report.noRights.push(label);
				const relay = findRelay(chat.id);
				if (relay && Date.now() - (relay.rightsNoticeAt || 0) > RIGHTS_NOTICE_EVERY) {
					relay.rightsNoticeAt = Date.now();
					saveBindings();
					await tgSoft("sendMessage", {
						chat_id: chat.id,
						text: "Сообщение для администрации: Вы не выдали достаточно прав для отправки рассылки в Вашем чате."
					});
				}
			} else if (isChatGone(err)) report.gone.push(label);
			else {
				const noAnswer = !(err instanceof TgError) && !(err instanceof PartialSendError && err.answered) && !(err instanceof Error && err.message.startsWith("пересланы"));
				report.failed.push(noAnswer ? `${label}: Telegram не ответил (возможно, пост дошёл); повторно не отправляем, чтобы не было дублей` : `${label}: ${err instanceof Error ? err.message : String(err)}`);
			}
		}
		const k = chatIdKey(chat.id);
		job.done.push(k);
		job.inflight = void 0;
		const moved = migratedKeys.get(k);
		if (moved) job.done.push(moved);
		saveBroadcastJobs();
		await sleep(Math.max(50, 40 * ((forward ? job.source?.messageIds.length : job.files.length) || 1)));
	}
	return report;
}
async function finishBroadcast(job) {
	const report = job.report;
	bindings.lastBroadcast = {
		at: Date.now(),
		total: report.total,
		sent: report.sent,
		noRights: report.noRights.length,
		gone: report.gone.length,
		failed: report.failed.length
	};
	saveBindings();
	broadcastJobs = broadcastJobs.filter((j) => j.id !== job.id);
	saveBroadcastJobs();
	if (!job.reportTo || !report.total) return;
	await tgSoft("sendMessage", {
		chat_id: job.reportTo.chatId,
		text: broadcastReportHtml(report),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: job.reportTo.messageId
	});
}
async function deleteChatMessages(chatId, messageIds) {
	let ok = 0;
	let fail = 0;
	const ids = [...new Set(messageIds.filter((n) => Number.isFinite(n)))];
	for (let i = 0; i < ids.length; i += 100) {
		const batch = ids.slice(i, i + 100);
		if (await tgSoft("deleteMessages", {
			chat_id: chatId,
			message_ids: batch
		})) ok += batch.length;
		else for (const id of batch) if (await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: id
		})) ok += 1;
		else fail += 1;
		await sleep(40);
	}
	return {
		ok,
		fail
	};
}
async function deletePublishedEverywhere(key) {
	const channel = {
		ok: 0,
		fail: 0
	};
	const chats = {
		ok: 0,
		fail: 0
	};
	let chatCount = 0;
	const rec = pendingPosts[key];
	if (!rec) return {
		channel,
		chats,
		chatCount
	};
	if (rec.channelChatId && rec.channelMsgIds?.length) {
		const r = await deleteChatMessages(rec.channelChatId, rec.channelMsgIds);
		channel.ok += r.ok;
		channel.fail += r.fail;
	}
	for (const d of rec.relayDeliveries || []) {
		if (!d.messageIds.length) continue;
		chatCount += 1;
		const r = await deleteChatMessages(d.chatId, d.messageIds);
		chats.ok += r.ok;
		chats.fail += r.fail;
	}
	rec.deletedEverywhere = true;
	rec.channelPosted = false;
	rec.removedFromCheck = true;
	rec.relayDeliveries = [];
	rec.channelMsgIds = [];
	savePending();
	return {
		channel,
		chats,
		chatCount
	};
}
function enqueueBroadcast(job) {
	broadcastQueue = broadcastQueue.then(() => runBroadcast(job)).then(() => finishBroadcast(job)).catch((err) => console.error("[epb] broadcast", err));
}
function resumeBroadcasts() {
	const fresh = broadcastJobs.filter((j) => Date.now() - j.startedAt < 432e5);
	if (fresh.length !== broadcastJobs.length) {
		broadcastJobs = fresh;
		saveBroadcastJobs();
	}
	for (const job of fresh) {
		console.log(`[epb] resuming broadcast ${job.key}: ${job.done.length} chats already done`);
		enqueueBroadcast(job);
	}
}
function broadcastReportHtml(report) {
	const list = (items) => items.slice(0, 15).map((x) => `• ${escapeHtml(x)}`).join("\n") + (items.length > 15 ? `\n… и ещё ${items.length - 15}` : "");
	const unsure = report.unconfirmed?.length || 0;
	const lines = [`<b>Рассылка завершена</b>: доставлено ${report.sent - unsure} из ${report.total}` + (unsure ? `, без подтверждения ${unsure}` : "")];
	if (report.unconfirmed?.length) lines.push("", `<b>Telegram ответил ошибкой, но пост обычно доходит — проверьте чат, повторно не отправляли (${report.unconfirmed.length})</b>`, list(report.unconfirmed));
	if (report.copies?.length) lines.push("", `<b>Пересылка в чат не прошла, отправлено копией (${report.copies.length})</b>`, list(report.copies));
	if (report.textOnly?.length) lines.push("", `<b>В чате запрещены фото/видео, отправлен только текст (${report.textOnly.length})</b>`, list(report.textOnly));
	if (report.noRights.length) lines.push("", `<b>Нет прав (${report.noRights.length})</b>`, list(report.noRights));
	if (report.gone.length) lines.push("", `<b>Бот удалён или чат недоступен (${report.gone.length})</b>`, list(report.gone));
	if (report.failed.length) lines.push("", `<b>Ошибки (${report.failed.length})</b>`, list(report.failed));
	return lines.join("\n");
}
function entitiesToHtml(text, entities = []) {
	const tags = {
		bold: ["<b>", "</b>"],
		italic: ["<i>", "</i>"],
		underline: ["<u>", "</u>"],
		strikethrough: ["<s>", "</s>"],
		spoiler: ["<tg-spoiler>", "</tg-spoiler>"],
		code: ["<code>", "</code>"],
		pre: ["<pre>", "</pre>"],
		blockquote: ["<blockquote>", "</blockquote>"],
		expandable_blockquote: ["<blockquote expandable>", "</blockquote>"]
	};
	const opens = /* @__PURE__ */ new Map();
	const closes = /* @__PURE__ */ new Map();
	const usable = entities.filter((e) => typeof e.offset === "number" && typeof e.length === "number" && e.length > 0).filter((e) => tags[e.type] || e.type === "text_link" && /^https?:\/\//i.test(e.url || "")).sort((a, b) => a.offset - b.offset || b.length - a.length);
	for (const e of usable) {
		const [open, close] = e.type === "text_link" ? [`<a href="${escapeHtml(e.url || "")}">`, "</a>"] : tags[e.type];
		if (e.offset >= text.length) continue;
		opens.set(e.offset, [...opens.get(e.offset) || [], open]);
		const end = Math.min(e.offset + e.length, text.length);
		closes.set(end, [close, ...closes.get(end) || []]);
	}
	let out = "";
	for (let i = 0; i <= text.length; i++) {
		out += (closes.get(i) || []).join("");
		out += (opens.get(i) || []).join("");
		if (i < text.length) out += escapeHtml(text[i]);
	}
	return out;
}
var postEditPrompts = /* @__PURE__ */ new Map();
function postPreviewHtml(key) {
	const rec = pendingPosts[key];
	return channelHtml(pendingAccounts(rec), rec.summary || rec.story, rec.amount, rec.currency, rec.postHtml);
}
async function sendPostPreview(chatId, key, replyTo) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const repeat = previousPosts(pendingAccounts(rec), key);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: `${`<b>Предпросмотр поста ${escapeHtml(key)}</b>${rec.postHtml ? " (текст изменён)" : ""}` + (rec.files?.length ? `\nК посту приложится доказательств: ${rec.files.length}` : "") + (repeat ? `\n${repeat}` : "")}\n━━━━━━━━━━\n${postPreviewHtml(key)}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_to_message_id: replyTo,
		reply_markup: publishChoiceKeyboard(key)
	});
}
async function askPostEdit(chatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return;
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			`<b>Новый текст поста ${escapeHtml(key)}</b>`,
			"",
			"Ответьте на это сообщение новым текстом. Можно жирный, курсив и ссылки.",
			"Строки с аккаунтом и суммой и подпись Subscribe бот добавит сам.",
			"",
			"Сейчас в посте:",
			rec.postHtml || escapeHtml((rec.summary || rec.story).trim())
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Новый текст поста"
		}
	});
	if (prompt?.message_id) {
		postEditPrompts.set(`${chatId}:${prompt.message_id}`, key);
		if (postEditPrompts.size > 200) postEditPrompts.delete(postEditPrompts.keys().next().value);
	}
}
async function handlePostEditReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const key = postEditPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!key) return false;
	const rec = pendingPosts[key];
	if (!rec || rec.status !== "pending") {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Заявка уже обработана, текст не изменён.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const text = (msg.text || msg.caption || "").trim();
	if (text.length < 5) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком коротко. Ответьте на сообщение бота ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	if (text.length > 3500) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Слишком длинно: максимум 3500 символов.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	const html = entitiesToHtml(msg.text || msg.caption || "", msg.entities || msg.caption_entities).trim();
	const previous = rec.postHtml;
	rec.postHtml = html;
	if (postPreviewHtml(key).length > 3900) {
		rec.postHtml = previous;
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пост получается слишком длинным для Telegram. Сократите текст и ответьте ещё раз.",
			reply_to_message_id: msg.message_id
		});
		return true;
	}
	savePending();
	postEditPrompts.delete(`${msg.chat.id}:${replyTo}`);
	await sendPostPreview(msg.chat.id, key, msg.message_id);
	return true;
}
var publishing = /* @__PURE__ */ new Set();
var broadcastQueue = Promise.resolve();
async function publishFromMessage(text, callbackId, extraFiles = [], relay = false, keyHint = "", reportTo) {
	const parsed = parseEpbMarker(text);
	const key = keyHint || parsed?.key || "";
	const stored = key ? pendingPosts[key] : void 0;
	if (!parsed && !stored) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	if (stored?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (stored?.status === "rejected") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Заявка уже отклонена",
			show_alert: true
		});
		return false;
	}
	const lock = key || `txt:${createHash("sha256").update(text).digest("hex").slice(0, 16)}`;
	if (!key && pendingPosts[lock]?.status === "published") {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже опубликовано"
		});
		return false;
	}
	if (publishing.has(lock)) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Уже публикуем"
		});
		return false;
	}
	publishing.add(lock);
	const html = channelHtml(pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""), stored?.summary || stored?.story || parsed?.story || "", stored?.amount, stored?.currency, stored?.postHtml);
	const files = stored?.files?.length ? stored.files : extraFiles;
	if (!channelCandidates().length) {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	let channelPost;
	try {
		channelPost = await sendChannelPost(html, files);
	} catch {
		publishing.delete(lock);
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: relay ? "Не удалось опубликовать в канал. Чаты без прав пропускаются." : "Не удалось опубликовать. Бот должен быть админом канала.",
			show_alert: true
		});
		return false;
	}
	if (key && pendingPosts[key]) {
		pendingPosts[key].status = "published";
		pendingPosts[key].channelPosted = true;
		pendingPosts[key].channelChatId = channelPost.chatId;
		pendingPosts[key].channelMsgIds = channelPost.messageIds;
	} else pendingPosts[lock] = {
		username: "",
		id: "",
		story: "",
		amount: "",
		currency: "",
		files: [],
		createdAt: Date.now(),
		status: "published",
		channelPosted: true
	};
	savePending();
	if (relay) {
		const job = {
			id: randomUUID(),
			key: lock,
			html,
			files,
			source: channelPost,
			done: [],
			report: {
				total: 0,
				sent: 0,
				noRights: [],
				gone: [],
				failed: []
			},
			reportTo,
			startedAt: Date.now()
		};
		broadcastJobs.push(job);
		saveBroadcastJobs();
		enqueueBroadcast(job);
	}
	publishing.delete(lock);
	if (key && pendingPosts[key]) await notifyApplicant(pendingPosts[key], key, "published");
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: channelPost.partialError ? "Пост в канале вышел не целиком. Повторно не публикуем — проверьте канал." : relay ? "Опубликовано в канал, рассылка по чатам идёт" : "Опубликовано без рассылки",
		show_alert: Boolean(channelPost.partialError)
	});
	return true;
}
var sessions = /* @__PURE__ */ new Map();
var channelSetup = /* @__PURE__ */ new Set();
var checkChannelSetup = /* @__PURE__ */ new Set();
var removeFromCheckSetup = /* @__PURE__ */ new Set();
var addBlacklistSetup = /* @__PURE__ */ new Set();
var sponsorLinkSetup = /* @__PURE__ */ new Map();
var bannerSetup = /* @__PURE__ */ new Map();
function gcSessions() {
	const now = Date.now();
	for (const [id, session] of sessions) if (now - (session.touched || 0) > 72e5) sessions.delete(id);
	if (sessions.size <= 400) return;
	const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
	for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}
function commandName(text) {
	if (!text?.startsWith("/")) return null;
	return (text.split(/\s+/)[0] ?? "").slice(1).split("@")[0]?.toLowerCase() || null;
}
function applyKeyboard(locale) {
	const url = publicMiniAppUrl();
	const rows = [];
	if (url) rows.push([{
		text: tb(locale, "openApp"),
		web_app: { url }
	}]);
	rows.push([{
		text: tb(locale, "applyBtn"),
		callback_data: "apply"
	}]);
	if (checkEnabled()) rows.push([{
		text: tb(locale, "checkMenuBtn"),
		callback_data: "bcheck"
	}]);
	rows.push([{
		text: tb(locale, "sponsorsMenuBtn"),
		callback_data: "bsponsors"
	}]);
	rows.push([{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}, {
		text: tb(locale, "ownersBtn"),
		callback_data: "owners"
	}]);
	rows.push([{
		text: tb(locale, "langBtn"),
		callback_data: "lang"
	}]);
	return { inline_keyboard: rows };
}
var checkWait = /* @__PURE__ */ new Set();
function backToMenuKeyboard(locale) {
	return { inline_keyboard: [[{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function checkResultKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "checkMore"),
		callback_data: "bcheck"
	}], [{
		text: tb(locale, "inMenu"),
		callback_data: "home"
	}]] };
}
async function botSponsorsText(locale) {
	const list = await listSponsors().catch(() => []);
	const lines = [`<b>${tb(locale, "sponsorsMenuBtn").replace(/^\s*[^\p{L}\p{N}]+\s*/u, "")}</b>`, ""];
	if (!list.length) {
		lines.push(tb(locale, "sponsorsEmptyB"));
		return lines.join("\n");
	}
	for (const s of list.slice(0, 20)) lines.push(s.link ? `• <a href="${s.link}">${escapeHtml(s.title)}</a>` : `• ${escapeHtml(s.title)}`);
	if (list.length > 20) lines.push(`… +${list.length - 20}`);
	return lines.join("\n");
}
function formatBotCheck(locale, input, res) {
	const q = res.query.username ? `@${res.query.username}` : res.query.id ? `ID ${res.query.id}` : input.trim();
	if (!(res.epb.length || res.manual.length || res.channels.length)) return tb(locale, "checkClean", { q: escapeHtml(q) });
	const lines = [`🔎 <b>${escapeHtml(q)}</b>`, ""];
	if (res.epb.length) {
		lines.push(tb(locale, "checkEpbHdr"));
		for (const e of res.epb.slice(0, 6)) lines.push(`• ${escapeHtml(e.accounts)}${e.amount ? ` — ${escapeHtml(e.amount)} ${escapeHtml(e.currency)}` : ""}`);
		lines.push("");
	}
	for (const m of res.manual.slice(0, 6)) lines.push(`📛 ${escapeHtml(m.source)}: ${escapeHtml(m.account)}`);
	if (res.channels.length) {
		const allWwh = res.channels.every((c) => /wwh/i.test(c.channelTitle || ""));
		lines.push(allWwh ? tb(locale, "checkFoundForum") : tb(locale, "checkFoundChats"));
		for (const c of res.channels.slice(0, 8)) {
			const wwh = /wwh/i.test(c.channelTitle || "");
			const name = wwh ? "WWH" : c.channelTitle || "источник";
			lines.push(wwh ? `• ${escapeHtml(name)}` : `• <a href="${c.link}">${escapeHtml(name)}</a>`);
		}
		lines.push("");
	}
	lines.push(tb(locale, "checkDispute"));
	return lines.join("\n").slice(0, 3900);
}
async function runBotCheck(chatId, input) {
	const locale = langOf(chatId);
	await tgSoft("sendChatAction", {
		chat_id: chatId,
		action: "typing"
	});
	let res;
	try {
		res = await checkCounterparty(input);
	} catch {
		res = {
			query: {
				username: "",
				id: ""
			},
			epb: [],
			channels: [],
			manual: []
		};
	}
	await sendCeMessage(chatId, formatBotCheck(locale, input, res), {
		reply_markup: checkResultKeyboard(locale),
		disable_web_page_preview: true
	});
}
function applyCancelRow(chatId) {
	return [{
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}];
}
function startText(locale) {
	return tb(locale, "start");
}
function ownersText(locale) {
	return tb(locale, "owners", { bot: BOT_USERNAME });
}
function ownersKeyboard(locale) {
	return { inline_keyboard: [[{
		text: tb(locale, "channel"),
		url: CHANNEL_URL
	}], [{
		text: `⬅️ ${tb(locale, "back")}`,
		callback_data: "home"
	}]] };
}
function langKeyboard(withBack = false) {
	const rows = [[{
		text: "Русский",
		callback_data: "lang:ru"
	}, {
		text: "English",
		callback_data: "lang:en"
	}]];
	if (withBack) rows.push([{
		text: "⬅️ Назад / Back",
		callback_data: "home"
	}]);
	return { inline_keyboard: rows };
}
var LANG_PROMPT = "Выберите язык / Choose language";
async function askLanguage(chatId, withBack = false) {
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: "Выберите язык / Choose language",
		reply_markup: langKeyboard(withBack)
	});
}
function cardPath(kind) {
	const name = `${kind}.jpg`;
	const candidates = [
		join(process.cwd(), "public/bot", name),
		join(process.cwd(), ".output/public/bot", name),
		join(process.cwd(), "public", name),
		join("/workspace/public/bot", name),
		join("/workspace/.output/public/bot", name)
	];
	try {
		const here = dirname(fileURLToPath(import.meta.url));
		candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
	} catch {}
	return candidates.find((p) => existsSync(p)) || null;
}
function cardBytes(kind) {
	if (kind === "welcome") try {
		return Buffer.from(WELCOME_JPEG_BASE64, "base64");
	} catch {}
	const path = cardPath(kind);
	if (!path) return null;
	try {
		return readFileSync(path);
	} catch {
		return null;
	}
}
async function sendCard(chatId, kind, caption, extra = {}) {
	const useCe = customEmojiEnabled() && isPrivateChat(chatId);
	const rich = useCe ? applyCustomEmoji(caption) : caption;
	const plainMarkup = extra.reply_markup;
	const richMarkup = useCe ? decorateButtons(plainMarkup, true) : plainMarkup;
	const needsRich = useCe && (hasCustomEmoji(rich) || markupHasIconableButton(plainMarkup));
	const cap = needsRich ? rich : caption;
	const rest = (markup) => {
		const { reply_markup: _omit, ...other } = extra;
		return markup === void 0 ? other : {
			...other,
			reply_markup: markup
		};
	};
	const trySend = async (method, build) => {
		try {
			return await tg(method, build(cap, needsRich ? richMarkup : plainMarkup));
		} catch (err) {
			if (needsRich && isCustomEmojiError(err)) return await tgSoft(method, build(caption, plainMarkup));
			return null;
		}
	};
	const cached = bindings.cards?.[kind];
	if (cached) {
		if (await trySend("sendPhoto", (c, markup) => ({
			chat_id: chatId,
			photo: cached,
			caption: c,
			parse_mode: "HTML",
			...rest(markup)
		}))) return;
		if (bindings.cards) delete bindings.cards[kind];
		saveBindings();
	}
	const bytes = cardBytes(kind);
	if (bytes?.length) {
		const sendForm = (c, markup) => {
			const form = new FormData();
			form.set("chat_id", String(chatId));
			form.set("caption", c);
			form.set("parse_mode", "HTML");
			if (markup) form.set("reply_markup", JSON.stringify(markup));
			form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
			return tgForm("sendPhoto", form);
		};
		try {
			let sent;
			try {
				sent = await sendForm(cap, needsRich ? richMarkup : plainMarkup);
			} catch (err) {
				if (needsRich && isCustomEmojiError(err)) sent = await sendForm(caption, plainMarkup);
				else throw err;
			}
			const fileId = sent.photo?.at(-1)?.file_id;
			if (fileId) {
				bindings.cards = {
					...bindings.cards,
					[kind]: fileId
				};
				saveBindings();
			}
			return;
		} catch {}
	}
	await trySend("sendMessage", (c, markup) => ({
		chat_id: chatId,
		text: c,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		...rest(markup)
	}));
}
async function startCaption(locale) {
	return startText(locale);
}
async function replyStart(chatId, userId) {
	const locale = langOf(userId ?? chatId);
	await sendCard(chatId, "welcome", await startCaption(locale), { reply_markup: applyKeyboard(locale) });
}
function newSession(from) {
	return {
		step: "scammer",
		accounts: [],
		victimUsername: from.username || "",
		victimId: String(from.id),
		victimName: from.first_name || "",
		summary: "",
		story: "",
		amount: "",
		currency: "USD",
		evidence: [],
		touched: Date.now()
	};
}
function parseAmount(text) {
	return parseDamageAmount(text);
}
function formatAmount(amount) {
	const [intPart, frac] = amount.split(".");
	const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
	return frac ? `${grouped}.${frac}` : grouped;
}
function hasMedia(msg) {
	return Boolean(msg.photo?.length || msg.video || msg.document);
}
function formatSessionAccounts(session, userId) {
	if (!session.accounts.length) return btUser(userId, "emptyAccounts");
	return session.accounts.map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`).join("\n");
}
async function sendStep(chatId, text, extra = {}) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
	const sent = await sendCeMessage(chatId, text, extra);
	if (session && sent?.message_id) session.stepMsgId = sent.message_id;
	return sent;
}
function clearStepMessage(chatId, deleteIt = true) {
	const session = sessions.get(String(chatId));
	if (session?.stepMsgId) {
		if (deleteIt) tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: session.stepMsgId
		});
		session.stepMsgId = void 0;
	}
}
async function askScammer(chatId, session) {
	const listed = session ? formatSessionAccounts(session, chatId) : "";
	const rows = [];
	if (session?.accounts.length) rows.push([{
		text: btUser(chatId, "moreAccount"),
		callback_data: "apply:more"
	}, {
		text: btUser(chatId, "next"),
		callback_data: "apply:next"
	}]);
	rows.push(applyCancelRow(chatId));
	await sendStep(chatId, session?.accounts.length ? btUser(chatId, "accountsListed", { list: listed }) : btUser(chatId, "stepAccounts"), { reply_markup: { inline_keyboard: rows } });
}
async function askSummary(chatId) {
	await sendStep(chatId, btUser(chatId, "stepSummary"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askStory(chatId) {
	await sendStep(chatId, btUser(chatId, "stepStory"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askAmount(chatId) {
	await sendStep(chatId, btUser(chatId, "stepAmount"), { reply_markup: { inline_keyboard: [applyCancelRow(chatId)] } });
}
async function askCurrency(chatId, amount) {
	await sendStep(chatId, btUser(chatId, "pickCurrency", { amount: formatAmount(amount) }), { reply_markup: { inline_keyboard: [[{
		text: "💵 USD",
		callback_data: "apply:cur:USD"
	}, {
		text: "💶 EUR",
		callback_data: "apply:cur:EUR"
	}], applyCancelRow(chatId)] } });
}
async function askEvidence(chatId) {
	await sendStep(chatId, btUser(chatId, "stepEvidence"), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "done"),
		callback_data: "apply:done"
	}, {
		text: btUser(chatId, "skipFiles"),
		callback_data: "apply:skip"
	}], applyCancelRow(chatId)] } });
}
async function askConfirm(chatId, session) {
	const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
	const files = session.evidence.length ? btUser(chatId, "filesCount", { n: session.evidence.length }) : btUser(chatId, "noFiles");
	await sendStep(chatId, btUser(chatId, "confirm", {
		accounts: formatSessionAccounts(session, chatId),
		victim,
		id: session.victimId,
		amount: session.amount,
		currency: session.currency,
		files,
		summary: session.summary,
		story: session.story
	}), { reply_markup: { inline_keyboard: [[{
		text: btUser(chatId, "sendReview"),
		callback_data: "apply:send"
	}, {
		text: btUser(chatId, "cancelBtn"),
		callback_data: "apply:cancel"
	}]] } });
}
async function startApply(chatId, from) {
	const session = newSession(from);
	sessions.set(String(from.id), session);
	await sendCeMessage(chatId, btUser(from.id, "applyStart"));
	await askScammer(chatId, session);
}
async function cancelApply(chatId, userId, notice) {
	clearStepMessage(chatId);
	sessions.delete(userId);
	await sendCeMessage(chatId, notice || btUser(userId, "cancel"), { reply_markup: applyKeyboard(langOf(userId)) });
}
async function submitSession(chatId, userId, session) {
	const accounts = session.accounts.filter((a) => a.id);
	if (!accounts.length) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needAccountSubmit")
		});
		session.step = "scammer";
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (!session.summary.trim() || session.summary.trim().length < 10) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needSummary")
		});
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (!session.story.trim() || session.story.trim().length < 20) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "needStory")
		});
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	const first = accounts[0];
	const app = {
		id: `EPB-${Date.now().toString(36).toUpperCase()}`,
		createdAt: Date.now(),
		status: "pending",
		victim: {
			username: session.victimUsername,
			telegramId: session.victimId,
			firstName: session.victimName
		},
		scammer: {
			username: first.username,
			telegramId: first.id
		},
		scammers: accounts.map((a) => ({
			username: a.username,
			telegramId: a.id
		})),
		summary: session.summary,
		story: session.story,
		damageAmount: session.amount,
		damageCurrency: session.currency,
		evidence: []
	};
	const result = await sendApplicationToArbiters(app, session.evidence);
	if (!result.ok) {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: result.error || btUser(userId, "sendFail")
		});
		return;
	}
	clearStepMessage(chatId);
	sessions.delete(userId);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: btUser(userId, "sent", { id: app.id })
	});
}
function forwardedUser(msg) {
	return msg.forward_from || msg.forward_origin?.sender_user;
}
async function handleApplyMessage(msg, session) {
	const chatId = msg.chat.id;
	const userId = String(msg.from?.id || chatId);
	if (session.step === "scammer") {
		let username = "";
		let id = "";
		const fwd = forwardedUser(msg);
		const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
		if (fwd) {
			rememberUser(fwd);
			id = String(fwd.id);
			username = fwd.username || "";
		} else if (mention) {
			rememberUser(mention);
			id = String(mention.id);
			username = mention.username || "";
		} else {
			const raw = (msg.text || "").trim();
			if (!raw) {
				await askScammer(chatId, session);
				return;
			}
			const low = raw.toLowerCase();
			if (low === "далее" || low === "готово" || low === "next") {
				if (!session.accounts.length) {
					await tgSoft("sendMessage", {
						chat_id: chatId,
						text: btUser(userId, "addAccountLeast")
					});
					return;
				}
				session.step = "summary";
				sessions.set(userId, session);
				await askSummary(chatId);
				return;
			}
			const resolved = await resolveHandleServer(raw, userId);
			if (!resolved) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "parseAccount")
				});
				return;
			}
			username = resolved.username;
			id = resolved.id;
			if (!id) {
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(userId, "idNoNumeric", { user: resolved.username })
				});
				return;
			}
		}
		if (!id) {
			await askScammer(chatId, session);
			return;
		}
		if (!session.accounts.some((a) => a.id === id)) session.accounts.push({
			username,
			id
		});
		sessions.set(userId, session);
		await askScammer(chatId, session);
		return;
	}
	if (session.step === "victim") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (session.step === "summary") {
		const summary = (msg.text || msg.caption || "").trim();
		if (summary.length < 10) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needSummary")
			});
			return;
		}
		if (summary.length > 800) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "summaryLong")
			});
			return;
		}
		session.summary = summary;
		session.step = "story";
		sessions.set(userId, session);
		await askStory(chatId);
		return;
	}
	if (session.step === "story") {
		const story = (msg.text || msg.caption || "").trim();
		if (story.length < 20) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needStory")
			});
			return;
		}
		if (story.length > 5e3) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "storyLong")
			});
			return;
		}
		session.story = story;
		session.step = "amount";
		await askAmount(chatId);
		return;
	}
	if (session.step === "amount") {
		const parsed = parseAmount(msg.text || "");
		if (!parsed) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "needAmount")
			});
			return;
		}
		session.amount = parsed.amount;
		if (!parsed.currency) {
			sessions.set(userId, session);
			await askCurrency(chatId, parsed.amount);
			return;
		}
		session.currency = parsed.currency;
		session.step = "evidence";
		await askEvidence(chatId);
		return;
	}
	if (session.step === "evidence") {
		if (hasMedia(msg)) {
			const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
			const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
			session.evidence.push({
				chatId: msg.chat.id,
				messageId: msg.message_id,
				fileId,
				kind
			});
			if (session.evidence.length >= 30) {
				await askConfirm(chatId, session);
				return;
			}
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "fileAccepted", { n: session.evidence.length }),
				reply_markup: { inline_keyboard: [[{
					text: btUser(userId, "done"),
					callback_data: "apply:done"
				}]] }
			});
			return;
		}
		const text = (msg.text || "").trim().toLowerCase();
		if (text === "готово" || text === "done") {
			await askConfirm(chatId, session);
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "sendMedia")
		});
	}
	sessions.set(userId, session);
}
async function handleApplyCallback(cb, session) {
	const chatId = cb.message?.chat.id;
	const userId = String(cb.from?.id || "");
	if (!chatId) return;
	if (cb.data === "apply:cancel") {
		await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
		await cancelApply(chatId, userId);
		return;
	}
	if (!session) {
		if (cb.data === "apply") {
			if (!cb.from) return;
			if (cb.message?.chat.type && cb.message.chat.type !== "private") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: btUser(cb.from?.id, "applyInDm"),
					show_alert: true
				});
				await tgSoft("sendMessage", {
					chat_id: chatId,
					text: btUser(cb.from?.id, "applyOpen", { bot: BOT_USERNAME })
				});
				return;
			}
			await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await startApply(chatId, cb.from);
			return;
		}
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: btUser(cb.from?.id, "restart")
		});
		return;
	}
	tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
	if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
		if (!session.amount) {
			await askAmount(chatId);
			return;
		}
		session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
		session.step = "evidence";
		sessions.set(userId, session);
		await askEvidence(chatId);
		return;
	}
	if (cb.data === "apply:keep") {
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:next") {
		if (!session.accounts.length) {
			await tgSoft("sendMessage", {
				chat_id: chatId,
				text: btUser(userId, "addAccountFirst")
			});
			return;
		}
		session.step = "summary";
		sessions.set(userId, session);
		await askSummary(chatId);
		return;
	}
	if (cb.data === "apply:more") {
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: btUser(userId, "nextAccount")
		});
		return;
	}
	if (cb.data === "apply:done" || cb.data === "apply:skip") {
		await askConfirm(chatId, session);
		return;
	}
	if (cb.data === "apply:send") await submitSession(chatId, userId, session);
}
function findRelay(id) {
	return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}
function upsertRelay(chat, status) {
	const list = [...bindings.relayChats || []];
	const idx = list.findIndex((c) => sameChat(c.id, chat.id));
	const next = {
		id: String(chat.id),
		title: chat.title || list[idx]?.title,
		type: chat.type || list[idx]?.type,
		status
	};
	if (status === "pending") next.requestedAt = Date.now();
	if (idx >= 0) list[idx] = {
		...list[idx],
		...next
	};
	else list.push(next);
	bindings.relayChats = pruneRelays(list);
	saveBindings();
}
function pruneRelays(list) {
	const LIMIT = 5e3;
	if (list.length <= LIMIT) return list;
	const removable = list.filter((c) => c.status !== "on").sort((a, b) => (a.requestedAt || 0) - (b.requestedAt || 0)).slice(0, list.length - LIMIT);
	const drop = new Set(removable.map((c) => chatIdKey(c.id)));
	return list.filter((c) => !drop.has(chatIdKey(c.id)));
}
function onChatMigrated(oldId, newId) {
	if (!oldId || !newId || sameChat(oldId, newId)) return;
	migratedKeys.set(chatIdKey(oldId), chatIdKey(newId));
	let changed = false;
	const list = bindings.relayChats || [];
	const old = list.find((c) => sameChat(c.id, oldId));
	if (old) {
		const twin = list.find((c) => sameChat(c.id, newId));
		if (twin) {
			if (old.status === "on") twin.status = "on";
			bindings.relayChats = list.filter((c) => c !== old);
		} else {
			old.id = newId;
			old.type = "supergroup";
		}
		changed = true;
	}
	if (bindings.channelId && sameChat(bindings.channelId, oldId)) {
		bindings.channelId = newId;
		changed = true;
	}
	if (changed) {
		saveBindings();
		console.log(`[epb] chat ${oldId} migrated to ${newId}`);
	}
}
function dropRelay(id) {
	bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
	saveBindings();
}
function chatKindLabel(type) {
	if (type === "channel") return "канал";
	if (type === "supergroup") return "супергруппа";
	if (type === "group") return "группа";
	return type || "чат";
}
async function greetRelayChat(chat) {
	await tgSoft("sendMessage", {
		chat_id: chat.id,
		text: [
			`<b>${CHANNEL_NAME}</b>`,
			"",
			"Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает."
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true
	});
}
async function notifyArbitersAboutRelay(chat, addedBy) {
	const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
	const who = addedBy?.username ? `@${addedBy.username}` : addedBy?.first_name ? `${escapeHtml(addedBy.first_name)} (<code>${addedBy.id}</code>)` : "неизвестно";
	await tgSoft("sendMessage", {
		chat_id: arbiter,
		text: [
			"<b>Бот добавлен в чужой чат</b>",
			"",
			`Название: ${escapeHtml(chat.title || "без названия")}`,
			`Тип: ${chatKindLabel(chat.type)}`,
			`ID: <code>${chat.id}</code>`,
			`Кто добавил: ${who}`,
			"",
			"Подключить рассылку одобренных постов в этот чат?"
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [[{
			text: "Принять",
			callback_data: `rel:y:${chat.id}`
		}, {
			text: "Отклонить",
			callback_data: `rel:n:${chat.id}`
		}]] }
	});
}
async function replaceReplyMarkup(msg, markup, nextText) {
	const text = nextText ?? msg.caption ?? msg.text ?? "";
	const isMedia = Boolean(msg.caption || msg.photo || msg.video);
	if (nextText) {
		if (isMedia) {
			if (await tgSoft("editMessageCaption", {
				chat_id: msg.chat.id,
				message_id: msg.message_id,
				caption: text.slice(0, 1024),
				parse_mode: "HTML",
				reply_markup: markup
			})) return true;
		} else if (await tgSoft("editMessageText", {
			chat_id: msg.chat.id,
			message_id: msg.message_id,
			text,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: markup
		})) return true;
	}
	const markupOnly = await tgSoft("editMessageReplyMarkup", {
		chat_id: msg.chat.id,
		message_id: msg.message_id,
		reply_markup: markup
	});
	return Boolean(markupOnly);
}
function callbackKey(data) {
	const i = data.indexOf(":");
	return i >= 0 ? data.slice(i + 1) : "";
}
async function handleRelayDecision(cb, allow) {
	const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
	if (!raw) return;
	const chatId = raw;
	const relay = findRelay(chatId);
	const title = relay?.title || chatId;
	if (allow) {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "on");
		const wrote = await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
			show_alert: !wrote
		});
	} else {
		upsertRelay({
			id: chatId,
			title: relay?.title,
			type: relay?.type
		}, "off");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят."
		});
		await tgSoft("answerCallbackQuery", {
			callback_query_id: cb.id,
			text: "Отклонено"
		});
	}
	const next = allow ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.` : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
	if (cb.message) await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: next,
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: [] }
	});
}
async function bindChat(chat, from, justAdded = true) {
	if (!isGroupOrChannel(chat)) return;
	const id = String(chat.id);
	if (isOfficialArbiterChat(id)) {
		bindings.arbiterChatId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: id,
			text: [
				`${CHANNEL_NAME}: чат арбитров подтверждён.`,
				`ID: <code>${id}</code>`,
				"",
				"Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
				"",
				"Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
				"Сменить: /channel -100…"
			].join("\n"),
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialChannel(id)) {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: arbiterCandidates()[0] || REQUESTED_ARBITER,
			text: `Канал подключён: ${escapeHtml(chat.title ?? id)}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	const existing = findRelay(id);
	if (existing?.status === "on") {
		if (!justAdded) return;
		await tgSoft("sendMessage", {
			chat_id: chat.id,
			text: "Рассылка уже включена. Одобренные посты будут приходить сюда."
		});
		return;
	}
	if (existing?.status === "pending" && Date.now() - (existing.requestedAt || 0) < 864e5) return;
	if (existing?.status === "off" && !justAdded) return;
	if (tooMany("relay:global", 8, 6e4)) return;
	if (from?.id && tooMany(`relay:${from.id}`, 3, 36e5)) return;
	upsertRelay(chat, "pending");
	await greetRelayChat(chat);
	await notifyArbitersAboutRelay(chat, from);
}
var USERS_PATH = join(DATA_DIR, "telegram-users.json");
var botUsers = readJson(USERS_PATH) || {};
var isUserId = (id) => /^[1-9]\d{0,15}$/.test(String(id ?? ""));
if (!existsSync(USERS_PATH)) {
	const seed = /* @__PURE__ */ new Set([...Object.keys(userLocales), ...Object.values(pendingPosts).map((r) => r.victimId || "")]);
	for (const id of seed) if (isUserId(id)) botUsers[id] = {
		first: Date.now(),
		last: 0
	};
	try {
		writeJsonAtomic(USERS_PATH, botUsers);
	} catch {}
}
var usersTimer = null;
function saveUsers() {
	if (usersTimer) return;
	usersTimer = setTimeout(() => {
		usersTimer = null;
		try {
			writeJsonAtomic(USERS_PATH, botUsers);
		} catch {}
	}, 3e3);
}
function touchUser(id, blocked) {
	if (!isUserId(id)) return;
	const key = String(id);
	const now = Date.now();
	const user = botUsers[key] || {
		first: now,
		last: now
	};
	user.last = now;
	if (blocked !== void 0) user.blocked = blocked;
	else if (user.blocked) user.blocked = false;
	botUsers[key] = user;
	saveUsers();
}
function userStats() {
	const all = Object.values(botUsers);
	const blocked = all.filter((u) => u.blocked).length;
	return {
		total: all.length,
		active: all.length - blocked,
		blocked
	};
}
var DM_JOBS_PATH = join(DATA_DIR, "telegram-dm-broadcasts.json");
var dmDonePath = (id) => join(DATA_DIR, `dm-done-${id.replace(/[^a-z0-9-]/gi, "")}.log`);
var dmJobs = readJson(DM_JOBS_PATH) || [];
var dmDraft = null;
var dmPrompts = /* @__PURE__ */ new Map();
var dmAlbums = /* @__PURE__ */ new Map();
var dmQueue = Promise.resolve();
var dmStarting = /* @__PURE__ */ new Set();
function saveDmJobs() {
	try {
		writeJsonAtomic(DM_JOBS_PATH, dmJobs);
	} catch {}
}
function readDone(id) {
	try {
		return new Set(readFileSync(dmDonePath(id), "utf8").split("\n").filter(Boolean).map((l) => l.replace(/^\?/, "")));
	} catch {
		return /* @__PURE__ */ new Set();
	}
}
function dmMarkup(draft) {
	return draft.buttons.length ? { inline_keyboard: draft.buttons } : void 0;
}
async function sendDmCopy(chatId, draft) {
	if (draft.srcIds.length > 1) {
		if (!(await tg("copyMessages", {
			chat_id: chatId,
			from_chat_id: draft.srcChat,
			message_ids: draft.srcIds
		}))?.length) throw new Error("сообщение не скопировалось");
		return;
	}
	await tg("copyMessage", {
		chat_id: chatId,
		from_chat_id: draft.srcChat,
		message_id: draft.srcIds[0],
		reply_markup: dmMarkup(draft)
	});
}
function parseDmButtons(text) {
	const rows = [];
	for (const line of text.split("\n").map((l) => l.trim()).filter(Boolean)) {
		const row = [];
		for (const part of line.split("|").map((p) => p.trim()).filter(Boolean)) {
			const m = part.match(/^(.+?)\s+[-–—]\s+(\S+)$/);
			if (!m) return `Не понял строку: «${part}». Формат: Текст - https://ссылка`;
			const url = m[2];
			if (!/^(https?:\/\/|tg:\/\/)\S+$/i.test(url)) return `Ссылка должна начинаться с https:// или tg:// — «${url}»`;
			row.push({
				text: m[1].slice(0, 64),
				url
			});
		}
		if (row.length > 8) return "В одном ряду максимум 8 кнопок";
		if (row.length) rows.push(row);
	}
	if (!rows.length) return "Не нашёл ни одной кнопки";
	if (rows.length > 10) return "Максимум 10 рядов кнопок";
	return rows;
}
function dmScreen() {
	const st = userStats();
	const running = dmJobs.find((j) => !j.stopped);
	const lines = [
		"<b>Пользователи бота</b>",
		`Всего: ${st.total}`,
		`Получат рассылку: ${st.active}`,
		`Заблокировали бота: ${st.blocked}`,
		"",
		"Рассылка уходит только в личные сообщения пользователям бота. В чаты и каналы она не отправляется."
	];
	const keyboard = [];
	if (running) {
		const done = readDone(running.id).size;
		lines.push("", `<b>Идёт рассылка</b>: ${done} из ${running.recipients.length}`);
		keyboard.push([{
			text: "⏹ Остановить рассылку",
			callback_data: `adm:ubstop:${running.id}`
		}]);
		keyboard.push([{
			text: "🔄 Обновить",
			callback_data: "adm:ub"
		}]);
	} else keyboard.push([{
		text: "✉ Новая рассылка",
		callback_data: "adm:ubnew"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function askDmContent(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Новая рассылка пользователям бота</b>",
			"",
			"Ответьте на это сообщение тем, что нужно разослать: текст, фото, видео, GIF, стикер или альбом, с подписью и форматированием.",
			"Премиум-эмодзи сохранятся, если у владельца бота есть Telegram Premium.",
			"",
			"Не удаляйте своё сообщение, пока рассылка не закончится: бот копирует именно его."
		].join("\n"),
		parse_mode: "HTML",
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Сообщение для рассылки"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "content");
}
async function askDmButtons(chatId) {
	const prompt = await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Кнопки под рассылкой</b>",
			"",
			"Ответьте на это сообщение. Каждая строка — ряд кнопок, кнопки в ряду через «|»:",
			"<code>Наш канал - https://t.me/+KkrYz9IKvoBmYTQy</code>",
			"<code>Сайт - https://example.com | Бот - https://t.me/EuropeBlack_bot</code>"
		].join("\n"),
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: {
			force_reply: true,
			selective: false,
			input_field_placeholder: "Текст - https://ссылка"
		}
	});
	if (prompt?.message_id) dmPrompts.set(`${chatId}:${prompt.message_id}`, "buttons");
}
async function sendDmPreview(chatId) {
	const draft = dmDraft;
	if (!draft) return;
	const st = userStats();
	let previewOk = true;
	try {
		await sendDmCopy(String(chatId), draft);
	} catch (err) {
		previewOk = false;
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: `Не удалось показать предпросмотр: ${err.message}`
		});
	}
	const album = draft.srcIds.length > 1;
	const keyboard = [];
	if (!album) {
		keyboard.push([{
			text: draft.buttons.length ? "✏ Изменить кнопки" : "➕ Добавить кнопки",
			callback_data: "adm:ubbtn"
		}]);
		if (draft.buttons.length) keyboard.push([{
			text: "🗑 Убрать кнопки",
			callback_data: "adm:ubclr"
		}]);
	}
	if (previewOk) keyboard.push([{
		text: `🚀 Разослать (${st.active})`,
		callback_data: `adm:ubgo:${draft.id}`
	}]);
	keyboard.push([{
		text: "✖ Отменить",
		callback_data: "adm:ubcancel"
	}]);
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: [
			"<b>Предпросмотр рассылки — выше</b>",
			`Получат: ${st.active} пользователей бота (только личные сообщения, не чаты и не каналы).`,
			album ? "Это альбом: Telegram не позволяет добавить к альбому кнопки." : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML",
		reply_markup: { inline_keyboard: keyboard }
	});
}
async function handleDmReply(msg) {
	const replyTo = msg.reply_to_message?.message_id;
	if (!replyTo) return false;
	const kind = dmPrompts.get(`${msg.chat.id}:${replyTo}`);
	if (!kind) return false;
	if (kind === "buttons") {
		if (!dmDraft) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Черновик рассылки не найден. Начните заново: /admin"
			});
			return true;
		}
		const parsed = parseDmButtons(msg.text || "");
		if (typeof parsed === "string") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: `${parsed}\nОтветьте на сообщение с инструкцией ещё раз.`,
				reply_to_message_id: msg.message_id
			});
			return true;
		}
		dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
		dmDraft.buttons = parsed;
		await sendDmPreview(msg.chat.id);
		return true;
	}
	if (msg.media_group_id) {
		const albumKey = `${msg.chat.id}:${msg.media_group_id}`;
		const album = dmAlbums.get(albumKey);
		if (album) {
			album.ids.push(msg.message_id);
			return true;
		}
		const timer = setTimeout(async () => {
			const done = dmAlbums.get(albumKey);
			dmAlbums.delete(albumKey);
			if (!done) return;
			dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
			dmDraft = {
				id: randomUUID(),
				srcChat: done.chat,
				srcIds: [...done.ids].sort((a, b) => a - b),
				buttons: []
			};
			await sendDmPreview(msg.chat.id);
		}, 1500);
		dmAlbums.set(albumKey, {
			chat: String(msg.chat.id),
			ids: [msg.message_id],
			timer
		});
		return true;
	}
	dmPrompts.delete(`${msg.chat.id}:${replyTo}`);
	dmDraft = {
		id: randomUUID(),
		srcChat: String(msg.chat.id),
		srcIds: [msg.message_id],
		buttons: []
	};
	await sendDmPreview(msg.chat.id);
	return true;
}
function collectDmAlbumItem(msg) {
	if (!msg.media_group_id) return false;
	const album = dmAlbums.get(`${msg.chat.id}:${msg.media_group_id}`);
	if (!album) return false;
	if (!album.ids.includes(msg.message_id)) album.ids.push(msg.message_id);
	return true;
}
async function updateDmStatus(job, final = false) {
	const done = readDone(job.id).size;
	const text = final ? [
		`<b>Рассылка пользователям ${job.stopped ? "остановлена" : "завершена"}</b>`,
		`Доставлено: ${job.sent}`,
		`Заблокировали бота / недоступны: ${job.blocked}`,
		job.failed ? `Ошибки: ${job.failed}` : "",
		`Обработано: ${done} из ${job.recipients.length}`
	].filter(Boolean).join("\n") : `<b>Идёт рассылка пользователям</b>: ${done} из ${job.recipients.length}\nДоставлено ${job.sent}, недоступны ${job.blocked}${job.failed ? `, ошибки ${job.failed}` : ""}`;
	const markup = final ? void 0 : { inline_keyboard: [[{
		text: "⏹ Остановить",
		callback_data: `adm:ubstop:${job.id}`
	}]] };
	if (job.statusMessage) {
		if (await tgSoft("editMessageText", {
			chat_id: job.statusChat,
			message_id: job.statusMessage,
			text,
			parse_mode: "HTML",
			reply_markup: markup
		}) || !final) return;
	}
	const sent = await tgSoft("sendMessage", {
		chat_id: job.statusChat,
		text,
		parse_mode: "HTML",
		reply_markup: markup
	});
	if (sent?.message_id && !final) {
		job.statusMessage = sent.message_id;
		saveDmJobs();
	}
}
async function runDmJob(job) {
	const done = readDone(job.id);
	let lastStatus = 0;
	await updateDmStatus(job);
	for (const chatId of job.recipients) {
		if (job.stopped) break;
		if (!isUserId(chatId) || done.has(chatId)) continue;
		appendFileSync(dmDonePath(job.id), `?${chatId}\n`);
		try {
			await sendDmCopy(chatId, job);
			job.sent += 1;
		} catch (err) {
			const text = String(err?.message || "");
			if (err instanceof TgError && (err.code === 403 || /blocked|deactivated|can't initiate|chat not found|user not found/i.test(text))) {
				job.blocked += 1;
				touchUser(chatId, true);
			} else job.failed += 1;
		}
		done.add(chatId);
		appendFileSync(dmDonePath(job.id), `${chatId}\n`);
		if (Date.now() - lastStatus > 4e3) {
			lastStatus = Date.now();
			saveDmJobs();
			await updateDmStatus(job);
		}
		await sleep(Math.max(45, 45 * job.srcIds.length));
	}
	await updateDmStatus(job, true);
	dmJobs = dmJobs.filter((j) => j.id !== job.id);
	saveDmJobs();
	try {
		unlinkSync(dmDonePath(job.id));
	} catch {}
}
function enqueueDmJob(job) {
	dmQueue = dmQueue.then(() => runDmJob(job)).catch((err) => console.error("[epb] user broadcast", err));
}
function resumeDmJobs() {
	for (const job of dmJobs) {
		if (Date.now() - job.startedAt > 864e5) continue;
		console.log(`[epb] resuming user broadcast ${job.id}: ${readDone(job.id).size} done`);
		enqueueDmJob(job);
	}
}
async function handleDmCallback(cb, action, arg) {
	const chatId = cb.message.chat.id;
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "ub") {
		await answer();
		await renderAdmin(cb, dmScreen());
		return true;
	}
	if (action === "ubnew") {
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Сначала дождитесь окончания текущей рассылки", true);
			return true;
		}
		await answer("Ответьте на сообщение бота тем, что нужно разослать");
		await askDmContent(chatId);
		return true;
	}
	if (action === "ubbtn") {
		await answer();
		if (!dmDraft) await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Черновик не найден. Начните заново: /admin"
		});
		else await askDmButtons(chatId);
		return true;
	}
	if (action === "ubclr") {
		if (dmDraft) dmDraft.buttons = [];
		await answer("Кнопки убраны");
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubcancel") {
		dmDraft = null;
		await answer("Рассылка отменена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: "Рассылка отменена."
		});
		return true;
	}
	if (action === "ubgo") {
		if (!dmDraft || dmDraft.id !== arg) {
			await answer("Этот черновик уже неактуален", true);
			return true;
		}
		await answer();
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Разослать это сообщение ${userStats().active} пользователям бота? Отменить уже отправленное будет нельзя.`,
			reply_markup: { inline_keyboard: [[{
				text: "✅ Да, разослать",
				callback_data: `adm:ubyes:${dmDraft.id}`
			}], [{
				text: "⬅ Назад",
				callback_data: "adm:ubback"
			}]] }
		});
		return true;
	}
	if (action === "ubback") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		await sendDmPreview(chatId);
		return true;
	}
	if (action === "ubyes") {
		if (!dmDraft || dmDraft.id !== arg || dmStarting.has(arg) || dmJobs.some((j) => j.id === arg)) {
			await answer("Эта рассылка уже запущена или отменена", true);
			return true;
		}
		if (dmJobs.some((j) => !j.stopped)) {
			await answer("Уже идёт другая рассылка", true);
			return true;
		}
		dmStarting.add(arg);
		const recipients = Object.entries(botUsers).filter(([id, u]) => isUserId(id) && !u.blocked).map(([id]) => id);
		const job = {
			...dmDraft,
			recipients,
			sent: 0,
			blocked: 0,
			failed: 0,
			startedAt: Date.now(),
			statusChat: String(chatId)
		};
		dmJobs.push(job);
		saveDmJobs();
		dmDraft = null;
		await answer("Рассылка запущена");
		await tgSoft("editMessageText", {
			chat_id: chatId,
			message_id: cb.message.message_id,
			text: `Рассылка запущена: ${recipients.length} получателей.`
		});
		enqueueDmJob(job);
		return true;
	}
	if (action === "ubstop") {
		const job = dmJobs.find((j) => j.id === arg);
		if (job) {
			job.stopped = true;
			saveDmJobs();
		}
		await answer(job ? "Останавливаем…" : "Рассылка уже закончилась");
		return true;
	}
	return false;
}
var ADMIN_PAGE = 8;
var RELAY_FILTERS = [
	{
		key: "a",
		label: "Все",
		match: () => true
	},
	{
		key: "on",
		label: "✅ Вкл",
		match: (c) => c.status === "on"
	},
	{
		key: "pd",
		label: "⏳ Ждут",
		match: (c) => c.status === "pending"
	},
	{
		key: "off",
		label: "⛔ Выкл",
		match: (c) => c.status === "off"
	}
];
var statusIcon = (status) => status === "on" ? "✅" : status === "pending" ? "⏳" : "⛔";
var statusText = (status) => status === "on" ? "рассылка включена" : status === "pending" ? "ждёт решения" : "рассылка выключена";
function ago(ts) {
	if (!ts) return "давно";
	const min = Math.round((Date.now() - ts) / 6e4);
	if (min < 60) return `${Math.max(1, min)} мин назад`;
	const h = Math.round(min / 60);
	if (h < 48) return `${h} ч назад`;
	return `${Math.round(h / 24)} дн назад`;
}
function cut(text, max) {
	return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}
function pendingComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => (rec.status || "pending") === "pending").sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function publishedComplaints() {
	return Object.entries(pendingPosts).filter(([, rec]) => rec.status === "published" && rec.channelPosted && !rec.deletedEverywhere).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
}
function adminDeleteList(page) {
	const list = publishedComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => {
		const chats = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
		return [{
			text: `${cut(scamLabel(rec), 22)} · ${chats} чат. · ${ago(rec.createdAt)}`,
			callback_data: `adm:dlc:${key}`
		}];
	});
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:dl:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:dl:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:dl:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Удалить блеклист</b>: опубликовано ${list.length}\nВыберите запись — бот спросит подтверждение и удалит пост из канала и из всех чатов рассылки.` : "<b>Удалить блеклист</b>: опубликованных записей нет.",
		keyboard
	};
}
async function adminDeleteConfirm(key) {
	const rec = pendingPosts[key];
	const back = {
		text: "⬅ К списку",
		callback_data: "adm:dl:0"
	};
	if (!rec || rec.status !== "published") return {
		text: "Эта запись уже не опубликована.",
		keyboard: [[back]]
	};
	const chatCount = (rec.relayDeliveries || []).filter((d) => d.messageIds.length).length;
	const channelCount = rec.channelMsgIds?.length || 0;
	return {
		text: [
			"<b>Удалить блеклист везде?</b>",
			`Аккаунт: ${escapeHtml(scamLabel(rec))}`,
			`Ущерб: ${escapeHtml(rec.amount || "—")} ${escapeHtml(rec.currency || "")}`,
			"",
			`Будет удалено: пост в канале (${channelCount} сообщ.) и сообщения в ${chatCount} чатах рассылки.`,
			"Отменить удаление нельзя. Сообщения старше 48 часов Telegram может не дать удалить в некоторых чатах."
		].join("\n"),
		keyboard: [[{
			text: "🗑 Да, удалить везде",
			callback_data: `adm:dlgo:${key}`
		}], [back]]
	};
}
function adminHome() {
	const relays = bindings.relayChats || [];
	const all = Object.values(pendingPosts);
	const count = (st) => all.filter((r) => (r.status || "pending") === st).length;
	const last = bindings.lastBroadcast;
	return {
		text: [
			`<b>${CHANNEL_NAME} — панель</b>`,
			"",
			`<b>Заявки</b>: ждут решения ${count("pending")}, опубликовано ${count("published")}, отклонено ${count("rejected")}`,
			`<b>Чаты рассылки</b>: включено ${relays.filter((c) => c.status === "on").length}, ждут ${relays.filter((c) => c.status === "pending").length}, выключено ${relays.filter((c) => c.status === "off").length}`,
			`<b>Пользователи бота</b>: ${userStats().total} (заблокировали ${userStats().blocked})`,
			`<b>Канал</b>: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			last ? `<b>Последняя рассылка</b>: ${ago(last.at)}, доставлено ${last.sent} из ${last.total}` + (last.noRights ? `, без прав ${last.noRights}` : "") + (last.gone ? `, недоступно ${last.gone}` : "") : "<b>Последняя рассылка</b>: ещё не было"
		].join("\n"),
		keyboard: [
			[{
				text: `📝 Заявки без решения (${count("pending")})`,
				callback_data: "adm:ap:0"
			}],
			[{
				text: `🗑 Удалить блеклист (${count("published")})`,
				callback_data: "adm:dl:0"
			}],
			[{
				text: "📋 Чаты рассылки",
				callback_data: "adm:rl:a:0"
			}, {
				text: "⏳ Ждут решения",
				callback_data: "adm:rl:pd:0"
			}],
			[{
				text: "📢 Канал для постов",
				callback_data: "adm:ch"
			}],
			[{
				text: "📣 Рассылка пользователям бота",
				callback_data: "adm:ub"
			}],
			[{
				text: `🖼 Баннеры (${(bindings.banners || []).length})`,
				callback_data: "adm:bn"
			}],
			...checkEnabled() ? [
				[{
					text: "➕ Добавить юзера в блеклист",
					callback_data: "adm:bladd"
				}],
				[{
					text: "🧹 Убрать юзера из блеклиста",
					callback_data: "adm:ccrm"
				}],
				[{
					text: "🔎 Каналы для проверки",
					callback_data: "adm:cc"
				}]
			] : [],
			[{
				text: "🔄 Обновить",
				callback_data: "adm:home"
			}, {
				text: "✖ Закрыть",
				callback_data: "adm:x"
			}]
		]
	};
}
function adminRelayList(filter, page) {
	const f = RELAY_FILTERS.find((x) => x.key === filter) || RELAY_FILTERS[0];
	const list = (bindings.relayChats || []).filter(f.match);
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const slice = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE);
	const keyboard = [RELAY_FILTERS.map((x) => ({
		text: x.key === f.key ? `• ${x.label}` : x.label,
		callback_data: `adm:rl:${x.key}:0`
	})), ...slice.map((c) => [{
		text: `${statusIcon(c.status)} ${cut(c.title || c.id, 40)}`,
		callback_data: `adm:rc:${c.id}:${f.key}:${p}`
	}])];
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:rl:${f.key}:${p - 1}`
	});
	nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:rl:${f.key}:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:rl:${f.key}:${p + 1}`
	});
	keyboard.push(nav, [{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: [`<b>Чаты рассылки</b> — ${f.label}: ${list.length}`, list.length ? "Нажмите на чат, чтобы открыть карточку." : "Здесь пока пусто."].join("\n"),
		keyboard
	};
}
async function adminRelayCard(chatId, filter, page, note = "") {
	const relay = findRelay(chatId);
	const back = {
		text: "⬅ К списку",
		callback_data: `adm:rl:${filter}:${page}`
	};
	if (!relay) return {
		text: "Этого чата уже нет в списке.",
		keyboard: [[back]]
	};
	const suffix = `${relay.id}:${filter}:${page}`;
	const toggle = relay.status === "on" ? {
		text: "⛔ Выключить рассылку",
		callback_data: `adm:roff:${suffix}`
	} : {
		text: "✅ Включить рассылку",
		callback_data: `adm:ron:${suffix}`
	};
	return {
		text: [
			`<b>${escapeHtml(relay.title || "без названия")}</b>`,
			`ID: <code>${escapeHtml(relay.id)}</code>`,
			`Тип: ${chatKindLabel(relay.type)}`,
			`Статус: ${statusIcon(relay.status)} ${statusText(relay.status)}`,
			`Ссылка спонсора: ${relay.link ? `<code>${escapeHtml(relay.link)}</code>` : "не задана"}`,
			relay.requestedAt ? `Запрос: ${ago(relay.requestedAt)}` : "",
			note ? `\n${note}` : ""
		].filter(Boolean).join("\n"),
		keyboard: [
			[toggle],
			[{
				text: relay.link ? "🔗 Изменить ссылку спонсора" : "🔗 Задать ссылку спонсора",
				callback_data: `adm:rlink:${suffix}`
			}],
			[{
				text: "🔍 Проверить права бота",
				callback_data: `adm:rchk:${suffix}`
			}],
			[back]
		]
	};
}
async function botRightsNote(chatId) {
	const member = await tgSoft("getChatMember", {
		chat_id: chatId,
		user_id: Number(botToken().split(":")[0])
	});
	if (!member) return "❌ Бот не видит этот чат: его удалили или чат закрыт.";
	if (member.status === "left" || member.status === "kicked") return "❌ Бота в этом чате нет.";
	if ((await tgSoft("getChat", { chat_id: chatId }))?.type === "channel") return member.status === "administrator" && member.can_post_messages !== false ? "✅ Бот админ канала и может публиковать." : "⚠️ Бот не может публиковать в канале: нужен админ с правом публикации.";
	if (member.status === "restricted" && (member.can_send_messages === false || member.can_send_photos === false)) return "⚠️ Боту запрещено отправлять сообщения или медиа в этом чате.";
	return member.status === "administrator" || member.status === "creator" ? "✅ Бот админ, рассылка будет доходить." : "✅ Бот участник чата и может писать. Лучше выдать админа, чтобы медиа точно доходили.";
}
function adminPendingList(page) {
	const list = pendingComplaints();
	const pages = Math.max(1, Math.ceil(list.length / ADMIN_PAGE));
	const p = Math.min(Math.max(0, page), pages - 1);
	const keyboard = list.slice(p * ADMIN_PAGE, (p + 1) * ADMIN_PAGE).map(([key, rec]) => [{
		text: `${key} · ${cut(scamLabel(rec), 24)} · ${rec.amount} ${rec.currency} · ${ago(rec.createdAt)}`,
		callback_data: `adm:as:${key}`
	}]);
	const nav = [];
	if (p > 0) nav.push({
		text: "◀",
		callback_data: `adm:ap:${p - 1}`
	});
	if (pages > 1) nav.push({
		text: `${p + 1} / ${pages}`,
		callback_data: `adm:ap:${p}`
	});
	if (p < pages - 1) nav.push({
		text: "▶",
		callback_data: `adm:ap:${p + 1}`
	});
	if (nav.length) keyboard.push(nav);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: list.length ? `<b>Заявки без решения</b>: ${list.length}\nНажмите на заявку — бот пришлёт её ещё раз с кнопками.` : "<b>Заявки без решения</b>: нет, все разобраны.",
		keyboard
	};
}
async function adminShowComplaint(arbiterChatId, key) {
	const rec = pendingPosts[key];
	if (!rec) return false;
	const accounts = pendingAccounts(rec).map((a) => formatAccountLine(a.username, a.id, true)).join("\n");
	const parts = splitHtml([
		`<b>Заявка ${escapeHtml(key)}</b> (повтор из панели, ${ago(rec.createdAt)})`,
		"",
		`<b>Аккаунт</b>\n${accounts}`,
		`<b>Ущерб</b>\n${escapeHtml(rec.amount)} ${escapeHtml(rec.currency)}`,
		"",
		`<b>Кратко (в пост)</b>\n${escapeHtml(rec.summary || rec.story)}`,
		rec.files?.length ? `\nДоказательств: ${rec.files.length} (в исходной заявке, они уйдут в пост)` : ""
	].join("\n"));
	for (const [i, part] of parts.entries()) {
		const payload = {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			reply_markup: i === parts.length - 1 ? reviewKeyboard(key) : void 0
		};
		if (i === 0 && rec.reviewMessageId && rec.reviewChatId && sameChat(rec.reviewChatId, arbiterChatId)) payload.reply_parameters = {
			message_id: rec.reviewMessageId,
			allow_sending_without_reply: true
		};
		await tgSoft("sendMessage", payload);
	}
	return true;
}
function adminCheck() {
	const list = checkChannels();
	const ub = hasUserbot();
	const lines = [
		"<b>Каналы для проверки контрагента</b>",
		`Подключено: ${list.length}`,
		`Аккаунт (юзербот): ${ub ? "подключён ✅" : "не подключён"}`,
		"",
		ub ? "Поиск идёт через подключённый аккаунт по всем постам этих каналов, включая старые. Бота в каналы добавлять не нужно — аккаунт должен быть на них подписан." : "Сейчас бот индексирует только новые посты каналов, где он сам состоит. Чтобы искать по старым постам чужих каналов без добавления бота, подключите аккаунт (юзербот) — см. HOSTING.md."
	];
	const keyboard = list.map((c) => [{
		text: `🗑 ${cut(c.title || c.username || c.id, 36)}`,
		callback_data: `adm:ccdel:${c.id}`
	}]);
	keyboard.push([{
		text: "🔌 Проверить аккаунт",
		callback_data: "adm:ccping"
	}]);
	keyboard.push([{
		text: "🧹 Убрать жалобу из блеклиста",
		callback_data: "adm:ccrm"
	}]);
	keyboard.push([{
		text: "➕ Добавить канал",
		callback_data: "adm:ccadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
function adminBanners() {
	const list = bindings.banners || [];
	const lines = [
		"<b>Баннеры в мини-аппе</b>",
		`Сейчас: ${list.length} из ${MAX_BANNERS}`,
		"",
		list.length ? "Баннеры показываются сверху в приложении. Видео и GIF идут без звука и по кругу. Тап по баннеру открывает ссылку." : "Пока нет ни одного баннера. Нажмите «Добавить баннер», пришлите картинку / видео / GIF, затем ссылку."
	];
	const keyboard = list.map((b, i) => [{
		text: `🗑 ${i + 1}. ${b.type === "video" ? "🎞" : "🖼"} ${cut(b.link || "без ссылки", 34)}`,
		callback_data: `adm:bndel:${b.id}`
	}]);
	if (list.length < MAX_BANNERS) keyboard.push([{
		text: "➕ Добавить баннер",
		callback_data: "adm:bnadd"
	}]);
	keyboard.push([{
		text: "⬅ В меню",
		callback_data: "adm:home"
	}]);
	return {
		text: lines.join("\n"),
		keyboard
	};
}
async function handleBannerInput(msg) {
	const key = String(msg.chat.id);
	const st = bannerSetup.get(key);
	if (!st) return false;
	if (st.phase === "media") {
		const media = extractBannerMedia(msg);
		if (!media) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Пришлите картинку, видео или GIF одним сообщением (не текстом). Или /admin, чтобы выйти."
			});
			return true;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Загружаю медиа…"
		});
		const bytes = await downloadTelegramFile(media.fileId);
		if (!bytes) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Не удалось загрузить файл. Для баннера подойдёт картинка / видео / GIF до 20 МБ. Пришлите ещё раз."
			});
			return true;
		}
		const id = newBannerId();
		saveBannerFile(id, bytes);
		st.draft = {
			type: media.type,
			file: id,
			mime: media.mime,
			width: media.width,
			height: media.height
		};
		st.phase = "link";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа сохранено. Теперь пришлите ссылку (https://… или t.me/…), которая откроется по тапу на баннер.\nЕсли ссылка не нужна — отправьте «-»."
		});
		return true;
	}
	if (!msg.text) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Пришлите ссылку текстом (https://…) или «-», чтобы без ссылки."
		});
		return true;
	}
	const link = normalizeBannerLink(msg.text);
	if (link === null) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Это не похоже на ссылку. Пришлите адрес вида https://… или t.me/…, либо «-» без ссылки."
		});
		return true;
	}
	const draft = st.draft;
	bannerSetup.delete(key);
	if (!draft) {
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Медиа не найдено, начните заново: /admin → Баннеры."
		});
		return true;
	}
	const banner = {
		id: draft.file,
		type: draft.type,
		file: draft.file,
		mime: draft.mime,
		link,
		width: draft.width,
		height: draft.height,
		createdAt: Date.now()
	};
	bindings.banners = [...bindings.banners || [], banner].slice(-20);
	saveBindings();
	const view = adminBanners();
	await tgSoft("sendMessage", {
		chat_id: msg.chat.id,
		text: `Баннер добавлен${link ? "" : " (без ссылки)"}.\n\n${view.text}`,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
	return true;
}
async function applySponsorLink(arbiterChatId, raw) {
	const st = sponsorLinkSetup.get(String(arbiterChatId));
	sponsorLinkSetup.delete(String(arbiterChatId));
	if (!st) return;
	const res = setSponsorLink(st.relayId, raw);
	if (res === "bad") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не похоже на ссылку. Пришлите https://… или t.me/…, либо «-», чтобы убрать."
		});
		return;
	}
	const view = await adminRelayCard(st.relayId, st.filter, st.page, res === "set" ? "Ссылка спонсора сохранена." : "Ссылка спонсора убрана.");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function applyRemoveFromCheck(arbiterChatId, raw) {
	removeFromCheckSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	let removed = 0;
	const epbId = text.match(/\b(EPB-[A-Za-z0-9]+)\b/i)?.[1];
	if (epbId) {
		const rec = pendingPosts[epbId] || pendingPosts[epbId.toUpperCase()];
		if (rec && !rec.removedFromCheck) {
			rec.removedFromCheck = true;
			removed = 1;
		}
	} else {
		const parsed = parseTelegramInput(text);
		const uname = parsed.username.replace(/^@/, "").toLowerCase();
		const id = parsed.id;
		if (!uname && !id) {
			await tgSoft("sendMessage", {
				chat_id: arbiterChatId,
				text: "Не понял. Пришлите EPB-… или @username / ID."
			});
			return;
		}
		for (const rec of Object.values(pendingPosts)) {
			if (rec.removedFromCheck) continue;
			const accounts = pendingAccounts(rec);
			if (uname && accounts.some((a) => a.username.replace(/^@/, "").toLowerCase() === uname) || id && accounts.some((a) => a.id === id)) {
				rec.removedFromCheck = true;
				removed += 1;
			}
		}
		const manual = bindings.manualBlacklist || [];
		const keptManual = manual.filter((e) => {
			const eu = (e.username || "").replace(/^@/, "").toLowerCase();
			return !(uname && eu === uname || id && e.telegramId === id);
		});
		if (keptManual.length !== manual.length) {
			removed += manual.length - keptManual.length;
			bindings.manualBlacklist = keptManual;
			saveBindings();
		}
	}
	if (removed) savePending();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: removed ? `Убрано из блеклиста: ${removed}. В проверке контрагента больше не показывается.` : "Ничего подходящего не нашёл."
	});
}
async function applyAddToBlacklist(arbiterChatId, raw) {
	addBlacklistSetup.delete(String(arbiterChatId));
	const text = raw.trim();
	const firstTok = text.split(/\s+/)[0] || "";
	const note = text.slice(firstTok.length).trim();
	const parsed = parseTelegramInput(firstTok);
	const username = parsed.username.replace(/^@/, "");
	const id = parsed.id;
	if (!username && !id) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не понял. Пришлите @username или ID, можно с комментарием через пробел."
		});
		return;
	}
	const entry = {
		id: randomUUID(),
		username: username || void 0,
		telegramId: id || void 0,
		source: DEFAULT_MANUAL_SOURCE,
		note: note || void 0,
		addedAt: Date.now()
	};
	bindings.manualBlacklist = [...bindings.manualBlacklist || [], entry].slice(-5e3);
	saveBindings();
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Добавлено в блеклист (проверка контрагента).",
			`Аккаунт: ${escapeHtml(username ? `@${username}` : `ID ${id}`)}`,
			`Источник: ${escapeHtml(DEFAULT_MANUAL_SOURCE)}`,
			note ? `Комментарий: ${escapeHtml(note)}` : ""
		].filter(Boolean).join("\n"),
		parse_mode: "HTML"
	});
}
async function applyCheckChannel(arbiterChatId, raw) {
	checkChannelSetup.delete(String(arbiterChatId));
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала (-100…) или @username."
		});
		return;
	}
	let entry = null;
	const chat = await chatReachable(ref);
	if (chat && (chat.type === "channel" || chat.type === "supergroup")) entry = {
		id: String(chat.id),
		title: chat.title,
		username: chat.username,
		addedAt: Date.now()
	};
	else if (hasUserbot()) entry = await resolveChannelAsUser(String(ref));
	if (!entry) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: hasUserbot() ? "Не удалось открыть этот канал. Подключённый аккаунт должен быть подписан на него. Пришлите @username или ID ещё раз." : "Не вижу этот канал. Добавьте бота в канал (участником или админом) и пришлите ID ещё раз — или подключите аккаунт (юзербот), тогда бота добавлять не нужно."
		});
		return;
	}
	if (isOfficialChannel(entry.id) || isOfficialArbiterChat(entry.id)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный канал бота, добавлять его не нужно."
		});
		return;
	}
	const list = [...checkChannels()];
	if (!list.some((c) => sameChat(c.id, entry.id))) {
		list.push(entry);
		bindings.checkChannels = list.slice(-100);
		saveBindings();
	}
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал подключён для проверки.",
			escapeHtml(entry.title || entry.id),
			`ID: <code>${escapeHtml(entry.id)}</code>`,
			"",
			hasUserbot() ? "Поиск по этому каналу идёт через подключённый аккаунт, включая старые посты." : "Новые посты этого канала будут попадать в поиск. Для старых постов подключите аккаунт (юзербот)."
		].join("\n"),
		parse_mode: "HTML"
	});
}
function adminChannel() {
	return {
		text: [
			"<b>Канал для постов</b>",
			`Сейчас: <code>${escapeHtml(bindings.channelId || PINNED_CHANNEL)}</code>`,
			"",
			"Чтобы сменить: нажмите кнопку и пришлите ID канала (-100…) или @username следующим сообщением. Бот должен быть админом канала."
		].join("\n"),
		keyboard: [[{
			text: "✏ Сменить канал",
			callback_data: "adm:chset"
		}], [{
			text: "⬅ В меню",
			callback_data: "adm:home"
		}]]
	};
}
async function sendAdminPanel(chatId) {
	const view = adminHome();
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function renderAdmin(cb, view) {
	if (!cb.message) return;
	return await tgSoft("editMessageText", {
		chat_id: cb.message.chat.id,
		message_id: cb.message.message_id,
		text: view.text,
		parse_mode: "HTML",
		disable_web_page_preview: true,
		reply_markup: { inline_keyboard: view.keyboard }
	});
}
async function handleAdminCallback(cb) {
	const chatId = cb.message.chat.id;
	const [, action = "home", ...rest] = (cb.data || "").split(":");
	const answer = (text = "", alert = false) => tgSoft("answerCallbackQuery", {
		callback_query_id: cb.id,
		text: text || void 0,
		show_alert: alert
	});
	if (action === "x") {
		await answer();
		await tgSoft("deleteMessage", {
			chat_id: chatId,
			message_id: cb.message.message_id
		});
		return;
	}
	if (action === "home") {
		await answer();
		await renderAdmin(cb, adminHome());
		return;
	}
	if (action.startsWith("ub") && await handleDmCallback(cb, action, rest[0] || "")) return;
	if (action === "rl") {
		await answer();
		await renderAdmin(cb, adminRelayList(rest[0] || "a", Number(rest[1] || 0)));
		return;
	}
	const [target = "", filter = "a", page = "0"] = rest;
	if (action === "rc") {
		await answer();
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "ron" || action === "roff") {
		const relay = findRelay(target);
		if (!relay) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		upsertRelay({
			id: relay.id,
			title: relay.title,
			type: relay.type
		}, action === "ron" ? "on" : "off");
		if (action === "ron") await tgSoft("sendMessage", {
			chat_id: relay.id,
			text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`
		});
		await answer(action === "ron" ? "Рассылка включена" : "Рассылка выключена");
		await renderAdmin(cb, await adminRelayCard(target, filter, page));
		return;
	}
	if (action === "rchk") {
		await answer("Проверяем…");
		await renderAdmin(cb, await adminRelayCard(target, filter, page, await botRightsNote(target)));
		return;
	}
	if (action === "rlink") {
		if (!findRelay(target)) {
			await answer("Чата уже нет в списке", true);
			return;
		}
		sponsorLinkSetup.set(String(chatId), {
			relayId: target,
			filter,
			page
		});
		await answer("Пришлите ссылку");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ссылку на чат (https://… или t.me/…), которая будет прикреплена к названию на странице «Спонсоры проекта». Чтобы убрать ссылку — отправьте «-»."
		});
		return;
	}
	if (action === "ap") {
		await answer();
		await renderAdmin(cb, adminPendingList(Number(rest[0] || 0)));
		return;
	}
	if (action === "as") {
		const key = rest[0] || "";
		const shown = (pendingPosts[key]?.status || "pending") === "pending" && await adminShowComplaint(chatId, key);
		await answer(shown ? "Заявка отправлена ниже" : "Заявка уже обработана", !shown);
		if (!shown) await renderAdmin(cb, adminPendingList(0));
		return;
	}
	if (action === "cc") {
		await answer();
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "ccping") {
		await answer("Проверяем аккаунт…");
		const st = await userbotStatus();
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: st.ok ? `Аккаунт подключён: ${escapeHtml(st.name || "аккаунт")}` : `Аккаунт не подключён: ${escapeHtml(st.error || "ошибка")}`
		});
		return;
	}
	if (action === "ccrm") {
		removeFromCheckSetup.add(String(chatId));
		await answer("Пришлите номер жалобы или аккаунт");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите номер жалобы (EPB-…) либо @username / ID аккаунта, который нужно убрать из блеклиста (поиска). Жалоба останется в истории, но перестанет находиться в проверке контрагента."
		});
		return;
	}
	if (action === "bladd") {
		addBlacklistSetup.add(String(chatId));
		await answer("Пришлите @username или ID");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите @username или ID аккаунта, которого нужно добавить в блеклист (проверку контрагента). Можно с комментарием через пробел, например:\n@scammer кинул на сделке, инфа из чужого блеклиста\n\nИсточник отметится как «Сторонний источник»."
		});
		return;
	}
	if (action === "ccadd") {
		checkChannelSetup.add(String(chatId));
		await answer("Пришлите ID канала следующим сообщением");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите ID канала (-100…) или @username для проверки. Бот должен быть в этом канале."
		});
		return;
	}
	if (action === "ccdel") {
		const target = rest.join(":");
		bindings.checkChannels = checkChannels().filter((c) => !sameChat(c.id, target));
		saveBindings();
		removeCheckChannelFromIndex(target);
		await answer("Канал убран");
		await renderAdmin(cb, adminCheck());
		return;
	}
	if (action === "dl") {
		await answer();
		await renderAdmin(cb, adminDeleteList(Number(rest[0] || 0)));
		return;
	}
	if (action === "dlc") {
		await answer();
		await renderAdmin(cb, await adminDeleteConfirm(rest.join(":")));
		return;
	}
	if (action === "dlgo") {
		const delKey = rest.join(":");
		if (!pendingPosts[delKey] || pendingPosts[delKey].status !== "published") {
			await answer("Запись уже удалена", true);
			await renderAdmin(cb, adminDeleteList(0));
			return;
		}
		await answer("Удаляю во всех чатах…");
		const res = await deletePublishedEverywhere(delKey);
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: [
				"Блеклист удалён.",
				`Канал: удалено ${res.channel.ok}${res.channel.fail ? `, не удалось ${res.channel.fail}` : ""}.`,
				`Чаты рассылки (${res.chatCount}): удалено ${res.chats.ok}${res.chats.fail ? `, не удалось ${res.chats.fail}` : ""}.`,
				res.channel.fail || res.chats.fail ? "Часть сообщений не удалилась — вероятно, они старше 48 часов или у бота нет прав на удаление в чате." : ""
			].filter(Boolean).join("\n")
		});
		await renderAdmin(cb, adminDeleteList(0));
		return;
	}
	if (action === "bn") {
		bannerSetup.delete(String(chatId));
		await answer();
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "bnadd") {
		if ((bindings.banners || []).length >= MAX_BANNERS) {
			await answer("Достигнут лимит баннеров", true);
			await renderAdmin(cb, adminBanners());
			return;
		}
		bannerSetup.set(String(chatId), { phase: "media" });
		await answer("Пришлите медиа для баннера");
		await tgSoft("sendMessage", {
			chat_id: chatId,
			text: "Пришлите картинку, видео или GIF для баннера (до 20 МБ). Следующим сообщением попрошу ссылку."
		});
		return;
	}
	if (action === "bndel") {
		removeBannerById(rest.join(":"));
		await answer("Баннер удалён");
		await renderAdmin(cb, adminBanners());
		return;
	}
	if (action === "ch") {
		await answer();
		await renderAdmin(cb, adminChannel());
		return;
	}
	if (action === "chset") {
		await answer("Пришлите ID канала следующим сообщением");
		await askPublishChannel(chatId);
		return;
	}
	await answer();
}
function relayListHtml() {
	const list = bindings.relayChats || [];
	const by = (status) => list.filter((c) => c.status === status);
	const line = (c) => `• ${escapeHtml(c.title || "без названия")} — <code>${escapeHtml(c.id)}</code>`;
	const lines = [
		`<b>Чаты рассылки</b>: включено ${by("on").length}, ждут решения ${by("pending").length}, выключено ${by("off").length}`,
		"",
		"<b>Включены</b>",
		...by("on").length ? by("on").map(line) : ["—"]
	];
	if (by("pending").length) lines.push("", "<b>Ждут решения</b>", ...by("pending").map(line));
	lines.push("", "Включить вручную: /relay_on -100…", "Выключить: /relay_off -100…");
	return splitHtml(lines.join("\n"));
}
async function handleRelayCommand(arbiterChatId, cmd, arg) {
	if (cmd === "relays") {
		for (const part of relayListHtml()) await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: part,
			parse_mode: "HTML",
			disable_web_page_preview: true
		});
		return;
	}
	const raw = arg.trim().split(/\s+/)[0] || "";
	if (!/^-\d{5,20}$/.test(raw)) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: `Укажите ID чата: /${cmd} -100…\nСписок: /relays`
		});
		return;
	}
	const chat = await tgSoft("getChat", { chat_id: raw });
	if (cmd === "relay_on" && !chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Бот не видит этот чат. Сначала добавьте бота в чат, потом повторите команду."
		});
		return;
	}
	if (chat && (isOfficialArbiterChat(chat.id) || isOfficialChannel(chat.id))) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это служебный чат, рассылка туда не нужна."
		});
		return;
	}
	const target = chat ? {
		id: chat.id,
		type: chat.type,
		title: chat.title
	} : { id: raw };
	upsertRelay(target, cmd === "relay_on" ? "on" : "off");
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: `${cmd === "relay_on" ? "Рассылка включена" : "Рассылка выключена"}: ${escapeHtml(chat?.title || raw)}\nID: <code>${escapeHtml(String(target.id))}</code>`,
		parse_mode: "HTML"
	});
}
async function parseChannelRef(raw) {
	const t = raw.trim().split(/\s+/)[0] || "";
	if (!t) return null;
	if (t.startsWith("@")) return t;
	const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
	if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
	const num = t.replace(/[^\d-]/g, "");
	if (/^-100\d{6,}$/.test(num)) return num;
	if (/^100\d{6,}$/.test(num)) return `-${num}`;
	if (/^\d{6,}$/.test(num)) return `-100${num}`;
	return t;
}
async function applyPublishChannel(arbiterChatId, raw) {
	const ref = await parseChannelRef(raw);
	if (!ref) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
			parse_mode: "HTML"
		});
		return;
	}
	const chat = await chatReachable(ref);
	if (!chat) {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз."
		});
		return;
	}
	if (chat.type !== "channel" && chat.type !== "supergroup") {
		await tgSoft("sendMessage", {
			chat_id: arbiterChatId,
			text: "Это не канал. Нужен ID канала, куда постить одобренные заявки."
		});
		return;
	}
	bindings.channelId = String(chat.id);
	saveBindings();
	channelSetup.delete(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			"Канал для постов обновлён.",
			escapeHtml(chat.title || "Канал"),
			`ID: <code>${chat.id}</code>`
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function askPublishChannel(arbiterChatId) {
	channelSetup.add(String(arbiterChatId));
	await tgSoft("sendMessage", {
		chat_id: arbiterChatId,
		text: [
			`Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
			"",
			"Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
			"Бот должен быть админом этого канала.",
			"",
			"Или сразу: /channel -100…"
		].join("\n"),
		parse_mode: "HTML"
	});
}
var seenUpdates = /* @__PURE__ */ new Set();
async function handleUpdate(update) {
	if (typeof update?.update_id === "number") {
		if (seenUpdates.has(update.update_id)) return;
		seenUpdates.add(update.update_id);
		if (seenUpdates.size > 5e3) seenUpdates.delete(seenUpdates.values().next().value);
	}
	try {
		await handleTelegramUpdate(update);
	} catch (err) {
		if (!isDisconnectError(err)) console.error("[epb] update", err);
	}
}
async function handleTelegramUpdate(update) {
	ensureBotProfile();
	const post = update.channel_post || update.edited_channel_post;
	if (post) {
		const ch = isCheckChannel(post.chat.id);
		if (ch) {
			if (post.chat.title && post.chat.title !== ch.title) {
				ch.title = post.chat.title;
				saveBindings();
			}
			indexCheckPost(ch, post.message_id, post.text || post.caption || "", post.date || 0);
		}
		return;
	}
	rememberUser(update.message?.from);
	rememberUser(update.message?.forward_from);
	rememberUser(update.message?.forward_origin?.sender_user);
	rememberUser(update.message?.reply_to_message?.from);
	rememberUser(update.message?.reply_to_message?.forward_from);
	rememberUser(update.callback_query?.from);
	for (const ent of [
		...update.message?.entities || [],
		...update.message?.caption_entities || [],
		...update.message?.reply_to_message?.entities || []
	]) rememberUser(ent.user);
	const groupMsg = update.message;
	if (groupMsg && (groupMsg.chat.type === "group" || groupMsg.chat.type === "supergroup")) {
		if (groupMsg.migrate_to_chat_id) onChatMigrated(String(groupMsg.chat.id), String(groupMsg.migrate_to_chat_id));
		if (groupMsg.migrate_from_chat_id) onChatMigrated(String(groupMsg.migrate_from_chat_id), String(groupMsg.chat.id));
		if (!isOfficialArbiterChat(groupMsg.chat.id)) return;
	}
	const floodId = String(update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "");
	const liveSession = sessions.get(floodId);
	const incoming = update.message;
	const evidenceBurst = liveSession?.step === "evidence" && Boolean(incoming?.photo?.length || incoming?.video || incoming?.document);
	if (tooMany("upd:global", 600, 6e4)) return;
	if (floodId && !evidenceBurst && tooMany(`flood:${floodId}`, 80, 6e4)) return;
	if (liveSession) liveSession.touched = Date.now();
	gcSessions();
	if (update.message?.chat.type === "private") touchUser(update.message.from?.id);
	if (update.callback_query?.message?.chat.type === "private") touchUser(update.callback_query.from?.id);
	const member = update.my_chat_member;
	if (member) {
		if (member.chat.type === "private") {
			touchUser(member.chat.id, member.new_chat_member.status === "kicked");
			return;
		}
		if (!isGroupOrChannel(member.chat)) return;
		const status = member.new_chat_member.status;
		if (status === "left" || status === "kicked") {
			dropRelay(member.chat.id);
			return;
		}
		if (status === "member" || status === "administrator" || status === "creator") {
			const before = member.old_chat_member?.status;
			await bindChat(member.chat, member.from, !before || before === "left" || before === "kicked");
		}
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		if (cb.data === "owners") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, ownersText(locale), ownersKeyboard(locale));
			return;
		}
		if (cb.data === "home") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			checkWait.delete(String(cb.message.chat.id));
			const locale = langOf(cb.from?.id);
			await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			return;
		}
		if (cb.data === "bsponsors") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			const locale = langOf(cb.from?.id);
			await editCard(cb, await botSponsorsText(locale), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "bcheck") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			if (!checkEnabled() || cb.message.chat.type !== "private") return;
			const locale = langOf(cb.from?.id);
			checkWait.add(String(cb.message.chat.id));
			await editCard(cb, tb(locale, "checkPrompt"), backToMenuKeyboard(locale));
			return;
		}
		if (cb.data === "lang") {
			tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
			await editCard(cb, LANG_PROMPT, langKeyboard(true));
			return;
		}
		if (cb.data === "lang:ru" || cb.data === "lang:en") {
			const locale = cb.data.endsWith("en") ? "en" : "ru";
			if (cb.from?.id) setLang(cb.from.id, locale);
			tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: tb(locale, "langSaved")
			});
			if (Boolean(cb.message.photo || cb.message.caption)) await editCard(cb, await startCaption(locale), applyKeyboard(locale));
			else {
				tgSoft("deleteMessage", {
					chat_id: cb.message.chat.id,
					message_id: cb.message.message_id
				});
				await replyStart(cb.message.chat.id, cb.from?.id);
			}
			return;
		}
		if (cb.data.startsWith("ub:")) {
			if (await handleOwnerCallback(cb)) return;
		}
		if (cb.data.startsWith("adm:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleAdminCallback(cb);
			return;
		}
		if (cb.data.startsWith("rel:")) {
			if (!isOfficialArbiterChat(cb.message.chat.id)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Чат не авторизован",
					show_alert: true
				});
				return;
			}
			await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
			return;
		}
		if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:") || /^p(edit|view|orig):/.test(cb.data)) && !isOfficialArbiterChat(cb.message.chat.id)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Чат не авторизован",
				show_alert: true
			});
			return;
		}
		const text = cb.message.caption || cb.message.text || "";
		Boolean(cb.message.caption || cb.message.photo || cb.message.video);
		if (alreadyHandled(text)) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub" || cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch")) {
			const markup = publishChoiceKeyboard(parseAppKey(text, cb.data));
			if (!await replaceReplyMarkup(cb.message, markup)) await tgSoft("sendMessage", {
				chat_id: cb.message.chat.id,
				text: "Как опубликовать эту заявку?",
				reply_to_message_id: cb.message.message_id,
				reply_markup: markup
			});
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Выберите тип публикации"
			});
			return;
		}
		if (/^p(edit|view|orig):/.test(cb.data)) {
			const [action, key = ""] = cb.data.split(":");
			const rec = pendingPosts[key];
			if (!rec || (rec.status || "pending") !== "pending") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже обработана",
					show_alert: true
				});
				return;
			}
			if (action === "pedit") {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Ответьте на сообщение бота новым текстом"
				});
				await askPostEdit(cb.message.chat.id, key);
			} else if (action === "pview") {
				await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			} else {
				delete rec.postHtml;
				savePending();
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Вернули исходный текст"
				});
				await sendPostPreview(cb.message.chat.id, key, cb.message.message_id);
			}
			return;
		}
		if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
			const extraFiles = [];
			const lastPhoto = cb.message.photo?.at(-1)?.file_id;
			if (lastPhoto) extraFiles.push({
				type: "photo",
				file_id: lastPhoto
			});
			if (cb.message.video?.file_id) extraFiles.push({
				type: "video",
				file_id: cb.message.video.file_id
			});
			const relay = cb.data.startsWith("puball");
			const key = parseAppKey(text, cb.data);
			if (!await publishFromMessage(key && pendingPosts[key] ? `#epb u=${pendingPosts[key].username || ""} id=${pendingPosts[key].id || "0"} k=${key}` : text, cb.id, extraFiles, relay, key, {
				chatId: cb.message.chat.id,
				messageId: cb.message.message_id
			})) return;
			const next = `${escapeHtml(stripServiceMarker(text || "Заявка"))}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
			const cleared = { inline_keyboard: [] };
			if (!await replaceReplyMarkup(cb.message, cleared, next)) await tgSoft("editMessageReplyMarkup", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				reply_markup: cleared
			});
			return;
		}
		if (cb.data === "rej" || cb.data.startsWith("rej:")) {
			const key = parseAppKey(text, cb.data);
			const record = key ? pendingPosts[key] : void 0;
			if (record?.status === "published" || key && publishing.has(key)) {
				await tgSoft("answerCallbackQuery", {
					callback_query_id: cb.id,
					text: "Заявка уже опубликована",
					show_alert: true
				});
				return;
			}
			if (record && record.status !== "rejected") {
				record.status = "rejected";
				savePending();
				await notifyApplicant(record, key, "rejected");
			}
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			const next = `${escapeHtml(stripServiceMarker(text))}\n\nСтатус: отклонено`;
			await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
			return;
		}
		const userId = String(cb.from?.id || "");
		await handleApplyCallback(cb, sessions.get(userId));
		return;
	}
	const msg = update.message;
	if (!msg) return;
	if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
	}
	if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
	const cmd = commandName(msg.text);
	const userId = String(msg.from?.id || msg.chat.id);
	if (cmd === "start" || cmd === "app") {
		const fromId = msg.from?.id;
		if (fromId && !hasLang(fromId)) {
			await askLanguage(msg.chat.id);
			return;
		}
		await replyStart(msg.chat.id, fromId);
		return;
	}
	if (cmd === "lang") {
		await askLanguage(msg.chat.id, hasLang(msg.from?.id));
		return;
	}
	if (cmd === "channel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
		if (arg) await applyPublishChannel(msg.chat.id, arg);
		else await askPublishChannel(msg.chat.id);
		return;
	}
	if (cmd === "admin" || cmd === "menu" || cmd === "panel") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await sendAdminPanel(msg.chat.id);
		return;
	}
	if (cmd === "checkon" || cmd === "checkoff") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		bindings.checkEnabled = cmd === "checkon";
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: cmd === "checkon" ? "Проверка контрагента включена." : "Проверка контрагента выключена и скрыта."
		});
		return;
	}
	if (cmd === "audience") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const n = Number((msg.text || "").replace(/[^\d]/g, ""));
		if (!setAudienceBase(n)) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Укажите число, например: /audience 20178"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `Базовая аудитория обновлена: ~${n.toLocaleString("ru-RU")}. Показывается в приложении (с учётом реального числа участников чатов).`
		});
		return;
	}
	if (cmd === "emoji") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim().toLowerCase();
		if (arg === "on" || arg === "off") {
			bindings.customEmoji = arg === "on";
			saveBindings();
		}
		const state = customEmojiEnabled() ? "включены" : "выключены";
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: arg === "on" || arg === "off" ? `Премиум-эмодзи ${state}. Работают в личных сообщениях бота (меню и шаги жалобы), пока у владельца активен Telegram Premium.` : `Премиум-эмодзи сейчас ${state}. Включить: /emoji on · выключить: /emoji off`
		});
		return;
	}
	if (cmd === "usearch") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		const arg = (msg.text || "").replace(/^\/\S+\s*/, "").trim();
		if (!arg) {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: "Проверка поиска по юзернейму. Пришлите: /usearch @username"
			});
			return;
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Проверяю поиск…"
		});
		const report = await diagnoseUserSearch(arg);
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: report
		});
		return;
	}
	if (cmd === "userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id) || !checkEnabled()) return;
		await sendOwnerPanel(msg.chat.id);
		return;
	}
	if (cmd === "cancel_userbot") {
		if (msg.chat.type !== "private" || !isOwner(msg.from?.id)) return;
		await loginStates.get(String(msg.chat.id))?.client?.disconnect?.().catch(() => {});
		loginStates.delete(String(msg.chat.id));
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: "Подключение отменено."
		});
		return;
	}
	if (cmd === "relays" || cmd === "relay_on" || cmd === "relay_off") {
		if (!isOfficialArbiterChat(msg.chat.id)) return;
		await handleRelayCommand(msg.chat.id, cmd, (msg.text || "").split(/\s+/).slice(1).join(" "));
		return;
	}
	if (cmd === "cancel") {
		await cancelApply(msg.chat.id, userId);
		return;
	}
	if (cmd === "apply") {
		if (msg.chat.type !== "private") {
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: btUser(msg.from?.id, "applyInGroup", { bot: BOT_USERNAME })
			});
			return;
		}
		if (!msg.from) return;
		await startApply(msg.chat.id, msg.from);
		return;
	}
	if (cmd === "id" || cmd === "bind") {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			if (!isOfficialArbiterChat(msg.chat.id)) return;
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров подтверждён.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки будут приходить только сюда.",
					"",
					`Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
					"Сменить: /channel -100…"
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && bannerSetup.has(String(msg.chat.id)) && await handleBannerInput(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && collectDmAlbumItem(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handleDmReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && !cmd && await handlePostEditReply(msg)) return;
	if (isOfficialArbiterChat(msg.chat.id) && removeFromCheckSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyRemoveFromCheck(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && addBlacklistSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyAddToBlacklist(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && sponsorLinkSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applySponsorLink(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && checkChannelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyCheckChannel(msg.chat.id, msg.text);
		return;
	}
	if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
		await applyPublishChannel(msg.chat.id, msg.text);
		return;
	}
	if (msg.chat.type !== "private") return;
	if (isOwner(msg.from?.id) && !cmd && ownerLoginActive(msg.chat.id) && msg.text) {
		if (await handleOwnerLogin(msg.chat.id, msg.text)) return;
	}
	if (checkWait.has(String(msg.chat.id)) && msg.text && !cmd) {
		checkWait.delete(String(msg.chat.id));
		await runBotCheck(msg.chat.id, msg.text);
		return;
	}
	const session = sessions.get(userId);
	if (session) await handleApplyMessage(msg, session);
}
async function registerMiniAppUrl(url) {
	const clean = url.replace(/\/$/, "");
	if (!clean.startsWith("https://") || isGatedHost(clean)) return {
		ok: false,
		reason: "gated"
	};
	bindings.miniAppUrl = clean;
	saveBindings();
	lastMenuUrl = "";
	await applyMenuButton();
	if (await tgSoft("setWebhook", {
		url: `${clean}/api/telegram/webhook`,
		secret_token: webhookSecret(),
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member",
			"channel_post",
			"edited_channel_post"
		],
		drop_pending_updates: false
	})) {
		bindings.webhookStamp = webhookStamp();
		saveBindings();
	}
	return {
		ok: true,
		url: clean
	};
}
var webhookArmed = false;
async function configureFromOrigin(_origin) {
	const site = publicSiteUrl();
	if (!site) return {
		configured: false,
		reason: "need_https"
	};
	if (!webhookArmed) {
		webhookArmed = true;
		ensureProductionWebhook();
	}
	return {
		configured: true,
		url: site
	};
}
if (botToken() && (process.env.PUBLIC_URL || true)) setTimeout(() => void ensureBotProfile().catch(() => {}), 3e3);
if (botToken() && broadcastJobs.length) setTimeout(resumeBroadcasts, 5e3);
if (botToken() && dmJobs.length) setTimeout(resumeDmJobs, 6e3);
//#endregion
export { parseDamageAmount as C, waitForTelegramUser as D, telegramInitData as E, openExternal as S, readTelegramWebUser as T, CHANNEL_URL as _, bannerById as a, lockTelegramViewport as b, isDisconnectError as c, sponsorAvatarPath as d, telegram_bot_server_exports as f, webhookSecretMatches as g, verifyTelegramInitData as h, appendEvidenceChunk as i, resolveHandleServer as l, verifyEvidenceDownload as m, allowEvidenceDownload as n, bannerFilePath as o, uploadedEvidencePath as p, allowEvidenceUpload as r, handleUpdate as s, allowEvidenceChunk as t, saveUploadedEvidence as u, bootTelegramWebApp as v, parseTelegramInput as w, lookupTelegramHandle as x, haptic as y };
