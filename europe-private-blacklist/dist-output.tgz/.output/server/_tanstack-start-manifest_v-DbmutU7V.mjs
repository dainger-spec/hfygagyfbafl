//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DbmutU7V.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-CoL1zvhI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CoL1zvhI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CI8TuC2H.js"]
	}
} });
//#endregion
export { tsrStartManifest };
