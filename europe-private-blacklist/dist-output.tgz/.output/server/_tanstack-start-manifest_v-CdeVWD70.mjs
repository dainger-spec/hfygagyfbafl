//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CdeVWD70.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DcCAsN8v.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DcCAsN8v.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DUpD1SQN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
