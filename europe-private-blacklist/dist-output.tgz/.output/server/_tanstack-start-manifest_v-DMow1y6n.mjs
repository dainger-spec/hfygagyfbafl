// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DMow1y6n.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-CLwOY5EG.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CLwOY5EG.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-bBzdx9wN.js"]
	}
} });
export { tsrStartManifest };
