//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CzSvG7Ez.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-C4TgwCie.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C4TgwCie.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DvTtOFB_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
