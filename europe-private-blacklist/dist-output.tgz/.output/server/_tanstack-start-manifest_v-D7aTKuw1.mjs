//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D7aTKuw1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-CTB9N6bv.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CTB9N6bv.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-XVt4kP4q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
