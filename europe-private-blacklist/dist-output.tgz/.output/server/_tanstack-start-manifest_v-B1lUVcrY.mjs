//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B1lUVcrY.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DERk658t.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DERk658t.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B6Saea6k.js"]
	}
} });
//#endregion
export { tsrStartManifest };
