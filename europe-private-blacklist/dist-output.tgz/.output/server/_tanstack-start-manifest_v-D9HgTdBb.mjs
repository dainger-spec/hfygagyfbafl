//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D9HgTdBb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BU9xytNn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BU9xytNn.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C3Xe5UZe.js"]
	}
} });
//#endregion
export { tsrStartManifest };
