//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-gkRkkCcp.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-Ct1jcA9H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Ct1jcA9H.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CwI6eu5b.js"]
	}
} });
//#endregion
export { tsrStartManifest };
