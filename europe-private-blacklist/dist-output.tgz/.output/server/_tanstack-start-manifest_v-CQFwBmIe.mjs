//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CQFwBmIe.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-D3liWlGu.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D3liWlGu.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BVg9EFUU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
