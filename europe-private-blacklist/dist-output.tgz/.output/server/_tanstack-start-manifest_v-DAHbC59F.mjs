//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DAHbC59F.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-C_wmYjv-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C_wmYjv-.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bb1kSUjS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
