//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-igD5RI-X.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-B2oz0QiF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B2oz0QiF.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CCKvoeLr.js"]
	}
} });
//#endregion
export { tsrStartManifest };
