//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-mfEo4RM6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BIqyRLSF.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BIqyRLSF.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-PqrH5PzJ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
