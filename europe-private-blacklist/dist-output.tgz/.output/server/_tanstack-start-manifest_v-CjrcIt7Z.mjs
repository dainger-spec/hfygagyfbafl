//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CjrcIt7Z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BzJ29nmf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BzJ29nmf.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DM0fqMzG.js"]
	}
} });
//#endregion
export { tsrStartManifest };
