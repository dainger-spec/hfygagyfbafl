//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cq_eJpuw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DtjAaMos.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DtjAaMos.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D6NlSP6w.js"]
	}
} });
//#endregion
export { tsrStartManifest };
