//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CBIxxA6r.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-vAc9HtgE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-vAc9HtgE.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cn5TO-fG.js"]
	}
} });
//#endregion
export { tsrStartManifest };
