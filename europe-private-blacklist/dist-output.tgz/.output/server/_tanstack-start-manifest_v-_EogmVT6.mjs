//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-_EogmVT6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-gPojWlZS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-gPojWlZS.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BbJXB5bf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
