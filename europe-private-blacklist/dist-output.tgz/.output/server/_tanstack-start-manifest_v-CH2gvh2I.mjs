// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CH2gvh2I.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-zHzlEFq4.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-zHzlEFq4.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-0mYfd-6v.js"]
	}
} });
export { tsrStartManifest };
