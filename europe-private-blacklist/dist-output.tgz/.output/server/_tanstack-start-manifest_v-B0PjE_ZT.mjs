//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B0PjE_ZT.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BcwGA48U.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BcwGA48U.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BqrCDeg8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
