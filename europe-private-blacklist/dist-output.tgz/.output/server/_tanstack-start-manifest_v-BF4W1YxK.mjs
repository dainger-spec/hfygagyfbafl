//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BF4W1YxK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BB0aJdyN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BB0aJdyN.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-_Jwftmli.js"]
	}
} });
//#endregion
export { tsrStartManifest };
