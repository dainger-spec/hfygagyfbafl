//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BCsIGevk.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-BUyvgmJ0.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BUyvgmJ0.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Df1YKfqx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
