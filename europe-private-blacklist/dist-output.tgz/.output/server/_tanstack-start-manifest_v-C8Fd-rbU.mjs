//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C8Fd-rbU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-CK7K6Wwt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CK7K6Wwt.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B5L214m2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
