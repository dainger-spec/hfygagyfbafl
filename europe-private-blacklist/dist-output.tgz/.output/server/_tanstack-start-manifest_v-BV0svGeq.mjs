// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BV0svGeq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-DdVOCVpV.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DdVOCVpV.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DPJv7D-l.js"]
	}
} });
export { tsrStartManifest };
