// node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B4LmG4_N.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/__root.tsx",
		children: [
			"/",
			"/api/telegram/banner",
			"/api/telegram/evidence",
			"/api/telegram/resolve",
			"/api/telegram/sponsor-avatar",
			"/api/telegram/webhook"
		],
		preloads: ["/assets/index-CXO_69My.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CXO_69My.js"
		} }]
	},
	"/": {
		filePath: "/home/user/hfygagyfbafl/source/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-M6nDkx4d.js"]
	}
} });
export { tsrStartManifest };
