export type Locale = "ru" | "en";

export const dict = {
  ru: {
    loadingTitle: "Подключаем Telegram",
    loadingText: "Подождите, подтягиваем ваш аккаунт. Это займёт пару секунд.",
    signedIn: "Вы вошли как",
    openFromBot: "Откройте Mini App из бота Telegram, чтобы войти своим аккаунтом.",
    fileComplaint: "Подать жалобу",
    history: "История жалоб",
    subscribe: "Подписаться на канал",
    ownersLink: "Для владельцев чатов",
    back: "Назад",
    ownersTitle: "Для владельцев чатов",
    ownersIntro:
      "Бота можно добавить в группу или канал. Тогда при публикации с рассылкой туда уйдёт тот же пост, что в Europe Private Blacklist.",
    ownersHow: "Как подключить",
    ownersStep1: "1. Добавьте @EuropeBlack_bot в чат или канал.",
    ownersStep2: "2. Сделайте бота администратором и выдайте права:",
    ownersGroup: "- группа: отправка сообщений и медиа",
    ownersChannel: "- канал: публикация сообщений и медиа",
    ownersStep3: "3. Все новые блеки будут автоматом публиковаться в Ваш чат/канал",
    ownersHelp: "Нужна помощь с добавлением — напишите",
    historyLoading: "Загружаем историю…",
    historyEmpty: "Пока нет поданных жалоб.",
    noUsername: "без username",
    statusPending: "Подано",
    statusPublished: "Одобрено",
    statusRejected: "Отклонено",
    doneTitle: "Жалоба у арбитров",
    doneText:
      "Материалы ушли в закрытый чат. Если кейс подтвердят - пост выйдет в канал. Если нет - публикации не будет.",
    home: "На главную",
    closeApp: "Закрыть приложение",
    accTitle: "Аккаунт в жалобе",
    accHint: "@username или t.me. Если несколько - добавьте все. ID подтянется само",
    accPlaceholder: "@username или t.me",
    addAccount: "Ещё аккаунт",
    accountN: "Аккаунт",
    removeAccount: "Удалить аккаунт",
    summaryTitle: "Суть проблемы кратко",
    summaryHint: "Это заголовок поста. Именно этот текст пойдёт в канал и в рассылку.",
    summaryPh: "Например: якобы продаёт FTP, клянчит по 50-100$ и пропадает.",
    storyTitle: "Подробное описание",
    storyHint: "Подробности увидят только арбитры. В пост это не попадёт.",
    storyPh: "Подробности: переписка, сроки, что происходило шаг за шагом.",
    amount: "Сумма ущерба",
    currency: "Валюта",
    evidenceTitle: "Доказательства",
    evidenceHint: "Переписка, чеки, видеозвонки.",
    send: "Отправить на рассмотрение",
    sending: "Отправляем…",
    errOpenBot: "Откройте Mini App из бота Telegram, чтобы подтянуть ваш аккаунт",
    errAccount: "Укажите хотя бы один аккаунт",
    errUserOrId: "Укажите username или ID аккаунта",
    errSummary: "Кратко опишите суть - это заголовок поста",
    errSummaryLong: "Краткая суть - до 800 символов",
    errStory: "Подробное описание - от 20 символов",
    errStoryLong: "Описание слишком длинное - до 5000 символов",
    errAmount: "Укажите сумму ущерба",
    errFiles: "Прикрепите хотя бы одно доказательство",
    errTimeout: "Слишком долго. Попробуйте ещё раз.",
    sentOk: "Заявка ушла в чат арбитров в Telegram.",
    sentFail: "Не удалось отправить. Проверьте сеть и попробуйте ещё раз.",
    sentSaved: "Заявка сохранена. Telegram ещё не принял - добавьте бота в чат арбитров.",
    parseFail: "Не удалось разобрать username или ID",
    idNotFound: "ID не найден. Перешлите боту сообщение этого человека и введите @username ещё раз - или вставьте числовой ID.",
    pasteId: "Вставьте числовой ID",
    dropFiles: "Скрины и видео",
    dropHint: "До {n} файлов. Можно перетащить сюда.",
    uploading: "Загружаем файлы…",
    uploadingN: "Загружаем {i} из {n}…",
    uploadingVideo: "Загружаем видео…",
    uploadingFile: "Загружаем файл…",
    uploadingNProgress: "Загружаем {i} из {n}: {done}/{total}",
    uploadingVideoProgress: "Загружаем видео: {done}/{total}",
    uploadFail: "Не удалось загрузить файл. Проверьте сеть и попробуйте ещё раз.",
    maxFiles: "Максимум {n} файлов",
    removeFile: "Удалить файл",
    resolvingId: "Подтягиваем ID…",
    language: "Язык",
    chooseLang: "Выберите язык / Choose language",
  },
  en: {
    loadingTitle: "Connecting Telegram",
    loadingText: "Please wait, we are pulling your account. This takes a couple of seconds.",
    signedIn: "Signed in as",
    openFromBot: "Open the Mini App from the Telegram bot to sign in with your account.",
    fileComplaint: "File a complaint",
    history: "Complaint history",
    subscribe: "Subscribe to the channel",
    ownersLink: "For chat owners",
    back: "Back",
    ownersTitle: "For chat owners",
    ownersIntro:
      "You can add the bot to a group or channel. Then broadcast posts will go there the same way as to Europe Private Blacklist.",
    ownersHow: "How to connect",
    ownersStep1: "1. Add @EuropeBlack_bot to the chat or channel.",
    ownersStep2: "2. Make the bot an admin and grant:",
    ownersGroup: "- group: send messages and media",
    ownersChannel: "- channel: post messages and media",
    ownersStep3: "3. New blacklist posts will be published to your chat/channel automatically",
    ownersHelp: "Need help adding it — write",
    historyLoading: "Loading history…",
    historyEmpty: "No complaints yet.",
    noUsername: "no username",
    statusPending: "Submitted",
    statusPublished: "Approved",
    statusRejected: "Rejected",
    doneTitle: "Sent to arbiters",
    doneText:
      "Materials went to the private chat. If confirmed, a post goes to the channel. If not, nothing is published.",
    home: "Home",
    closeApp: "Close app",
    accTitle: "Account in the complaint",
    accHint: "@username or t.me. If several - add them all. ID is resolved automatically",
    accPlaceholder: "@username or t.me",
    addAccount: "Another account",
    accountN: "Account",
    removeAccount: "Remove account",
    summaryTitle: "Problem in short",
    summaryHint: "This is the post headline. This exact text goes to the channel and the broadcast.",
    summaryPh: "e.g. pretends to sell FTP, asks for $50-100 and disappears.",
    storyTitle: "Detailed description",
    storyHint: "Details are for arbiters only. This will not go into the post.",
    storyPh: "Details: chats, timeline, what happened step by step.",
    amount: "Damage amount",
    currency: "Currency",
    evidenceTitle: "Evidence",
    evidenceHint: "Chats, receipts, video calls.",
    send: "Submit for review",
    sending: "Sending…",
    errOpenBot: "Open the Mini App from the Telegram bot so we can attach your account",
    errAccount: "Add at least one account",
    errUserOrId: "Enter a username or ID",
    errSummary: "Describe the case in short - this is the post headline",
    errSummaryLong: "Short summary - up to 800 characters",
    errStory: "Detailed description - at least 20 characters",
    errStoryLong: "Description is too long - up to 5000 characters",
    errAmount: "Enter the damage amount",
    errFiles: "Attach at least one piece of evidence",
    errTimeout: "Took too long. Try again.",
    sentOk: "The complaint was sent to the arbiter chat in Telegram.",
    sentFail: "Could not send. Check the network and try again.",
    sentSaved: "Saved locally. Telegram did not accept it yet - add the bot to the arbiter chat.",
    parseFail: "Could not parse username or ID",
    idNotFound: "ID not found. Forward this person a message to the bot and enter @username again - or paste a numeric ID.",
    pasteId: "Paste numeric ID",
    dropFiles: "Screenshots and video",
    dropHint: "Up to {n} files. You can drop them here.",
    uploading: "Uploading files…",
    uploadingN: "Uploading {i} of {n}…",
    uploadingVideo: "Uploading video…",
    uploadingFile: "Uploading file…",
    uploadingNProgress: "Uploading {i} of {n}: {done}/{total}",
    uploadingVideoProgress: "Uploading video: {done}/{total}",
    uploadFail: "Could not upload the file. Check the network and try again.",
    maxFiles: "Maximum {n} files",
    removeFile: "Remove file",
    resolvingId: "Resolving ID…",
    language: "Language",
    chooseLang: "Choose language / Выберите язык",
  },
} as const;

export type Msg = keyof typeof dict.ru;

export function isLocale(value: string | null | undefined): value is Locale {
  return value === "ru" || value === "en";
}

export function detectLocale(): Locale {
  if (typeof window === "undefined") return "ru";
  try {
    const saved = window.localStorage.getItem("epb-locale");
    if (isLocale(saved)) return saved;
  } catch {
    /* ignore */
  }
  const lang =
    window.Telegram?.WebApp?.initDataUnsafe?.user?.language_code ||
    (typeof navigator !== "undefined" ? navigator.language : "") ||
    "";
  if (/^en/i.test(lang)) return "en";
  return "ru";
}

export function persistLocale(locale: Locale) {
  try {
    window.localStorage.setItem("epb-locale", locale);
  } catch {
    /* ignore */
  }
}

export function hasSavedLocale(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return isLocale(window.localStorage.getItem("epb-locale"));
  } catch {
    return false;
  }
}

export function t(locale: Locale, key: Msg, vars?: Record<string, string | number>): string {
  let text: string = dict[locale][key] || dict.ru[key];
  if (vars) {
    for (const [k, v] of Object.entries(vars)) text = text.replaceAll(`{${k}}`, String(v));
  }
  return text;
}

export const botDict = {
  ru: {
    chooseLang: "Выберите язык / Choose language",
    start:
      "<b>Europe Private Blacklist</b>\n\nОткройте приложение, чтобы подать жалобу.\n\nАрбитры проверят материалы: одобрили - пост в канале, отклонили - без публикации.",
    openApp: "Открыть приложение",
    channel: "Наш канал",
    ownersBtn: "Для владельцев чатов",
    applyBtn: "Подать жалобу в чате",
    langBtn: "Язык / Language",
    back: "Назад",
    owners:
      "<b>Для владельцев чатов</b>\n\nБот можно добавить в группу или канал. Тогда при публикации с рассылкой туда уйдёт тот же пост, что в Europe Private Blacklist.\n\n<b>Как подключить</b>\n1. Добавьте @{bot} в чат или канал.\n\n<b>2. Сделайте бота администратором и выдайте права:</b>\n- группа: отправка сообщений и медиа\n- канал: публикация сообщений и медиа\n\n3. Все новые блеки будут автоматом публиковаться в Ваш чат/канал\n\nНужна помощь с добавлением - напишите <a href=\"https://t.me/EuropePromo\">@EuropePromo</a>",
    applyStart: "Заявка на блеклист. Отмена - /cancel.",
    cancel: "Заявка отменена.",
    stepAccounts:
      "Шаг 1/5. Аккаунты.\nПерешлите сообщение, @username или t.me.\nЕсли несколько аккаунтов - пришлите по очереди, затем «Далее».",
    accountsListed:
      "Аккаунты:\n{list}\n\nПерешлите сообщение следующего аккаунта или напишите @username. Когда все добавлены - «Далее».",
    moreAccount: "Ещё аккаунт",
    next: "Далее",
    stepSummary:
      "Шаг 2/5. Суть проблемы кратко.\nЭто заголовок поста. Именно этот текст пойдёт в канал и в рассылку.",
    stepStory: "Шаг 3/5. Подробное описание.\nЕго увидят только арбитры. В пост это не попадёт.",
    stepAmount: "Шаг 4/5. Сумма ущерба. Например: 15 000, 15,000 или 250 USD.",
    pickCurrency: "Сумма {amount}. Выберите валюту:",
    stepEvidence: "Шаг 5/5. Скрины и видео. Пришлите файлы, можно несколько. Когда закончите - «Готово».",
    done: "Готово",
    skipFiles: "Без файлов",
    confirm: "Проверьте заявку:\n\nАккаунт:\n{accounts}\nПострадавший: {victim} · {id}\nУщерб: {amount} {currency}\nДоказательства: {files}\n\nКратко (в пост):\n{summary}\n\nПодробно:\n{story}",
    sendReview: "Отправить на рассмотрение",
    cancelBtn: "Отмена",
    addAccountFirst: "Сначала добавьте аккаунт.",
    addAccountLeast: "Сначала добавьте хотя бы один аккаунт.",
    needSummary: "Кратко опишите суть - это заголовок поста.",
    summaryLong: "Краткая суть слишком длинная - до 800 символов.",
    needStory: "Нужно описание схемы - хотя бы пару предложений.",
    storyLong: "Описание слишком длинное - сократите до 5000 символов.",
    needAmount: "Напишите сумму, например 15 000 или 15000 USD.",
    needAccountSubmit: "Добавьте хотя бы один аккаунт.",
    sendFail: "Не удалось отправить арбитрам.",
    sent: "Заявка {id} ушла арбитрам. Если одобрят - пост в канале, если нет - публикация не выйдет.",
    parseAccount: "Не разобрал. Перешлите сообщение или напишите @username.",
    nextAccount: "Пришлите следующий аккаунт: перешлите сообщение или @username.",
    pendingNotice: "Жалоба {id} на {scam} принята.\nСтатус: подано. Арбитры проверят материалы.",
    publishedNotice: "Жалоба {id} на {scam} одобрена и опубликована в Europe Private Blacklist.",
    rejectedNotice: "Жалоба {id} на {scam} отклонена арбитрами. Публикации не будет.",
    emptyAccounts: "пока пусто",
    filesCount: "{n} файл(ов)",
    noFiles: "без файлов",
    applyInDm: "Заявку нужно подать в личке с ботом",
    applyOpen: "Откройте @{bot} в личных сообщениях и нажмите /apply",
    applyInGroup: "Заявку подайте в личке: @{bot}",
    restart: "Начните заново: /apply",
    langSaved: "Язык сохранён.",
    idNoNumeric: "@{user} принят, но ID не найден. Перешлите любое его сообщение или допишите числовой ID.",
    fileAccepted: "Файл {n}/30 принят. Ещё или «Готово».",
    sendMedia: "Пришлите скрин или видео, либо нажмите «Готово».",
    tooManyUser: "Слишком много заявок. Подождите несколько часов.",
    tooManyGlobal: "Сейчас слишком много заявок. Попробуйте позже.",
    tooManyFiles: "Слишком много файлов.",
    addBotArbiter: "Добавьте @{bot} в чат арбитров админом и напишите там /id",
  },
  en: {
    chooseLang: "Choose language / Выберите язык",
    start:
      "<b>Europe Private Blacklist</b>\n\nOpen the app to file a complaint.\n\nArbiters review the materials: approved - a post in the channel, rejected - no publication.",
    openApp: "Open app",
    channel: "Our channel",
    ownersBtn: "For chat owners",
    applyBtn: "File a complaint in chat",
    langBtn: "Language / Язык",
    back: "Back",
    owners:
      "<b>For chat owners</b>\n\nYou can add the bot to a group or channel. Then broadcast posts go there the same way as to Europe Private Blacklist.\n\n<b>How to connect</b>\n1. Add @{bot} to the chat or channel.\n\n<b>2. Make the bot an admin and grant:</b>\n- group: send messages and media\n- channel: post messages and media\n\n3. New blacklist posts will be published to your chat/channel automatically\n\nNeed help adding it - write <a href=\"https://t.me/EuropePromo\">@EuropePromo</a>",
    applyStart: "Blacklist complaint. Cancel - /cancel.",
    cancel: "Complaint cancelled.",
    stepAccounts:
      "Step 1/5. Accounts.\nForward a message, @username or t.me.\nIf several accounts - send them one by one, then tap Next.",
    accountsListed:
      "Accounts:\n{list}\n\nForward the next account or send @username. When all are added - tap Next.",
    moreAccount: "Another account",
    next: "Next",
    stepSummary:
      "Step 2/5. Problem in short.\nThis is the post headline. This exact text goes to the channel and the broadcast.",
    stepStory: "Step 3/5. Detailed description.\nArbiters only. This will not go into the post.",
    stepAmount: "Step 4/5. Damage amount. e.g. 15 000, 15,000 or 250 USD.",
    pickCurrency: "Amount {amount}. Choose currency:",
    stepEvidence: "Step 5/5. Screenshots and video. Send files, you can send several. When done - Done.",
    done: "Done",
    skipFiles: "No files",
    confirm:
      "Check the complaint:\n\nAccount:\n{accounts}\nVictim: {victim} · {id}\nDamage: {amount} {currency}\nEvidence: {files}\n\nHeadline (post):\n{summary}\n\nDetails:\n{story}",
    sendReview: "Submit for review",
    cancelBtn: "Cancel",
    addAccountFirst: "Add an account first.",
    addAccountLeast: "Add at least one account first.",
    needSummary: "Describe the case in short - this is the post headline.",
    summaryLong: "Short summary is too long - up to 800 characters.",
    needStory: "Need a description of the scheme - at least a couple of sentences.",
    storyLong: "Description is too long - keep it under 5000 characters.",
    needAmount: "Send the amount, e.g. 15 000 or 15000 USD.",
    needAccountSubmit: "Add at least one account.",
    sendFail: "Could not send to arbiters.",
    sent: "Complaint {id} was sent to arbiters. If approved - a channel post, if not - no publication.",
    parseAccount: "Could not parse. Forward a message or send @username.",
    nextAccount: "Send the next account: forward a message or @username.",
    pendingNotice: "Complaint {id} against {scam} was received.\nStatus: submitted. Arbiters will review it.",
    publishedNotice: "Complaint {id} against {scam} was approved and published in Europe Private Blacklist.",
    rejectedNotice: "Complaint {id} against {scam} was rejected by arbiters. Nothing will be published.",
    emptyAccounts: "none yet",
    filesCount: "{n} file(s)",
    noFiles: "no files",
    applyInDm: "File the complaint in a private chat with the bot",
    applyOpen: "Open @{bot} in private messages and tap /apply",
    applyInGroup: "File the complaint in a private chat: @{bot}",
    restart: "Start over: /apply",
    langSaved: "Language saved.",
    idNoNumeric: "@{user} accepted, but the ID was not found. Forward any message from them or add the numeric ID.",
    fileAccepted: "File {n}/30 received. Send more or tap Done.",
    sendMedia: "Send a screenshot or video, or tap Done.",
    tooManyUser: "Too many complaints. Wait a few hours.",
    tooManyGlobal: "Too many complaints right now. Try again later.",
    tooManyFiles: "Too many files.",
    addBotArbiter: "Add @{bot} to the arbiter chat as admin and send /id there",
  },
} as const;

export type BotMsg = keyof typeof botDict.ru;

export function tb(locale: Locale, key: BotMsg, vars?: Record<string, string | number>): string {
  let text: string = botDict[locale][key] || botDict.ru[key];
  if (vars) {
    for (const [k, v] of Object.entries(vars)) text = text.replaceAll(`{${k}}`, String(v));
  }
  return text;
}
