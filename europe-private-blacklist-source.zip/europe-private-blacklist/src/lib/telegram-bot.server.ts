import { createHash, createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync, statSync, unlinkSync, appendFileSync, renameSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { CHANNEL_NAME, CHANNEL_URL, KNOWN_TELEGRAM_IDS, parseDamageAmount, parseTelegramInput } from "@/lib/telegram";
import type { Application, ComplaintHistoryItem, Currency, EvidenceItem, PersonRef } from "@/lib/types";
import { scammerAccounts } from "@/lib/types";
import { WELCOME_JPEG_BASE64 } from "@/lib/welcome-card";
import { isLocale, tb, type BotMsg, type Locale } from "@/lib/i18n";

function botToken() {
  return process.env.TELEGRAM_BOT_TOKEN || "";
}

let warnedMissingToken = false;
function requireToken() {
  const token = botToken();
  if (!token && !warnedMissingToken) {
    warnedMissingToken = true;
    console.warn("[epb] TELEGRAM_BOT_TOKEN is not set");
  }
  return token;
}

export function isDisconnectError(err: unknown) {
  const any = err as { code?: string; message?: string; cause?: { code?: string; message?: string } };
  const code = String(any?.code || any?.cause?.code || "");
  const msg = `${any?.message || ""} ${any?.cause?.message || ""} ${err || ""}`;
  return (
    code === "ECONNRESET" ||
    code === "EPIPE" ||
    code === "ECONNABORTED" ||
    code === "ERR_STREAM_PREMATURE_CLOSE" ||
    /aborted|socket hang up|ECONNRESET|premature close/i.test(msg)
  );
}

function installDisconnectGuards() {
  const swallow = (err: unknown) => {
    if (isDisconnectError(err)) return;
    console.error("[epb]", err);
  };
  process.on("uncaughtException", swallow);
  process.on("unhandledRejection", swallow);
}
installDisconnectGuards();
function botApi() {
  return `https://api.telegram.org/bot${requireToken()}`;
}
export const BOT_USERNAME = "EuropeBlack_bot";
export function webhookSecret() {
  return `epb-${createHash("sha256").update(botToken()).digest("hex").slice(0, 24)}`;
}

export function webhookSecretMatches(header: string | null | undefined): boolean {
  const expected = webhookSecret();
  const got = String(header || "");
  const a = Buffer.from(got);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

const DATA_DIR = process.env.DATA_DIR || join(process.cwd(), "data");
const BINDINGS_PATH = join(DATA_DIR, "telegram-bindings.json");
const REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
const PINNED_ARBITER_CHAT = "-1003904954808";
const PINNED_CHANNEL = "-1003958415589";
const DEFAULT_PUBLIC_URL = "https://europe.bothost.tech";

type Bindings = {
  arbiterChatId?: string;
  channelId?: string;
  miniAppUrl?: string;
  cards?: Partial<Record<"welcome" | "submitted" | "published", string>>;
  cardStamp?: string;
  relayChats?: { id: string; title?: string; type?: string; status: "pending" | "on" | "off" }[];
};

let bindings: Bindings = loadBindings();
let profileReady = false;
let commandsStamp = "";
const COMMANDS_STAMP = "eu-blacklist-bot-v3-i18n";

function loadBindings(): Bindings {
  try {
    return JSON.parse(readFileSync(BINDINGS_PATH, "utf8")) as Bindings;
  } catch {
    return {};
  }
}

function saveBindings() {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(BINDINGS_PATH, JSON.stringify(bindings, null, 2));
  } catch {
    // Vercel filesystem is read-only - in-memory bindings still work for this instance.
  }
}

const ID_CACHE_PATH = join(DATA_DIR, "telegram-ids.json");
const PENDING_PATH = join(DATA_DIR, "telegram-pending.json");
const LOCALES_PATH = join(DATA_DIR, "telegram-locales.json");

let userLocales: Record<string, Locale> = {};
try {
  if (existsSync(LOCALES_PATH)) {
    const raw = JSON.parse(readFileSync(LOCALES_PATH, "utf8")) as Record<string, string>;
    for (const [id, value] of Object.entries(raw || {})) {
      if (isLocale(value)) userLocales[id] = value;
    }
  }
} catch {
  userLocales = {};
}

function saveLocales() {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(LOCALES_PATH, JSON.stringify(userLocales, null, 2));
  } catch {
    /* ignore */
  }
}

function langOf(userId: string | number | undefined): Locale {
  const saved = userLocales[String(userId || "")];
  return saved === "en" ? "en" : "ru";
}

function hasLang(userId: string | number | undefined): boolean {
  return isLocale(userLocales[String(userId || "")]);
}

function setLang(userId: string | number, locale: Locale) {
  userLocales[String(userId)] = locale;
  saveLocales();
}

export function saveUserLocaleServer(userId: string | number, locale: Locale) {
  if (!isLocale(locale)) return;
  setLang(userId, locale);
}

function btUser(userId: string | number | undefined, key: BotMsg, vars?: Record<string, string | number>) {
  return tb(langOf(userId), key, vars);
}

type MediaRef = { type: "photo" | "video" | "document"; file_id: string };
type PendingPost = {
  username: string;
  id: string;
  accounts?: { username: string; id: string }[];
  story: string;
  summary?: string;
  amount: string;
  currency: string;
  files: MediaRef[];
  victimId?: string;
  victimUsername?: string;
  createdAt?: number;
  status?: "pending" | "published" | "rejected";
};

let idCache: Record<string, string> = {};
let pendingPosts: Record<string, PendingPost> = {};

try {
  idCache = { ...KNOWN_TELEGRAM_IDS, ...(JSON.parse(readFileSync(ID_CACHE_PATH, "utf8")) as Record<string, string>) };
} catch {
  idCache = { ...KNOWN_TELEGRAM_IDS };
}
try {
  pendingPosts = JSON.parse(readFileSync(PENDING_PATH, "utf8")) as Record<string, PendingPost>;
} catch {
  pendingPosts = {};
}

function saveIdCache() {
  try {
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(ID_CACHE_PATH, JSON.stringify(idCache, null, 2));
  } catch {
    /* ignore */
  }
}

function savePending() {
  try {
    const entries = Object.entries(pendingPosts);
    if (entries.length > 1200) {
      const drop = entries
        .filter(([, rec]) => rec.status === "published" || rec.status === "rejected")
        .sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
      const extra = entries.length - 1000;
      for (const [key] of drop.slice(0, Math.max(0, extra))) delete pendingPosts[key];
    }
    mkdirSync(DATA_DIR, { recursive: true });
    writeFileSync(PENDING_PATH, JSON.stringify(pendingPosts, null, 2));
  } catch {
    /* ignore */
  }
}

function rememberUser(user?: { id?: number; username?: string } | null) {
  const username = user?.username?.replace(/^@/, "").toLowerCase();
  if (!user?.id || !username) return;
  const id = String(user.id);
  if (idCache[username] === id) return;
  idCache[username] = id;
  saveIdCache();
}

function rememberHandle(username: string, id: string) {
  const key = username.replace(/^@/, "").toLowerCase();
  if (!key || !id || !/^\d{5,15}$/.test(id)) return;
  if (idCache[key] === id) return;
  idCache[key] = id;
  const keys = Object.keys(idCache);
  if (keys.length > 8000) {
    for (const extra of keys.slice(0, keys.length - 7000)) delete idCache[extra];
  }
  saveIdCache();
}

const EVIDENCE_DIR = join(DATA_DIR, "evidence");

const MAX_EVIDENCE_FILE = 1024 * 1024 * 1024;
const MAX_EVIDENCE_CHUNK = 2 * 1024 * 1024;

function sanitizeEvidenceId(id: string): string | null {
  const safe = String(id || "").replace(/[^a-zA-Z0-9_-]/g, "");
  if (!safe || safe.length < 8 || safe.length > 80) return null;
  if (safe === ".." || safe.startsWith(".")) return null;
  return safe;
}

function evidenceOwnerPath(id: string) {
  return join(EVIDENCE_DIR, `${id}.own`);
}

function writeEvidenceOwner(id: string, userId: string) {
  mkdirSync(EVIDENCE_DIR, { recursive: true });
  writeFileSync(evidenceOwnerPath(id), String(userId || ""));
}

function readEvidenceOwner(id: string): string {
  try {
    return readFileSync(evidenceOwnerPath(id), "utf8").trim();
  } catch {
    return "";
  }
}

export function evidenceOwnedBy(id: string | undefined, userId: string): boolean {
  const safe = sanitizeEvidenceId(id || "");
  if (!safe || !userId) return false;
  return readEvidenceOwner(safe) === userId && Boolean(uploadedEvidencePath(safe));
}

function evidenceHmacKey() {
  return createHmac("sha256", "EvidenceGet").update(botToken() || "none").digest();
}

function evidenceSig(key: string, exp: number): string {
  return createHmac("sha256", evidenceHmacKey()).update(`${key}.${exp}`).digest("hex").slice(0, 32);
}

export function verifyEvidenceDownload(key: string, exp: string, sig: string): boolean {
  const safe = sanitizeEvidenceId(key);
  if (!safe) return false;
  const expMs = Number(exp);
  if (!Number.isFinite(expMs) || expMs < Date.now()) return false;
  if (expMs > Date.now() + 48 * 60 * 60 * 1000) return false;
  const expect = evidenceSig(safe, expMs);
  const a = Buffer.from(expect, "hex");
  const b = Buffer.from(String(sig || ""), "hex");
  if (a.length !== b.length || a.length === 0) return false;
  return timingSafeEqual(a, b);
}

function isAllowedEvidenceMagic(bytes: Buffer): boolean {
  if (!bytes.length) return false;
  const head = bytes.subarray(0, 256).toString("utf8").replace(/^\uFEFF/, "").trimStart().toLowerCase();
  if (
    head.startsWith("<!doctype") ||
    head.startsWith("<html") ||
    head.startsWith("<script") ||
    head.startsWith("<svg") ||
    head.startsWith("<?xml") ||
    head.startsWith("<?php") ||
    head.startsWith("#!") ||
    head.startsWith("import ") ||
    head.startsWith("function ") ||
    head.startsWith("const ") ||
    head.startsWith("var ") ||
    head.startsWith("{")
  ) {
    return false;
  }
  if (bytes[0] === 0x4d && bytes[1] === 0x5a) return false;
  if (bytes[0] === 0x7f && bytes[1] === 0x45 && bytes[2] === 0x4c && bytes[3] === 0x46) return false;
  if (bytes[0] === 0xca && bytes[1] === 0xfe && bytes[2] === 0xba && bytes[3] === 0xbe) return false;
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return true;
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return true;
  if (bytes.length >= 6 && bytes.subarray(0, 3).toString("ascii") === "GIF") return true;
  if (
    bytes.length >= 12 &&
    bytes.subarray(0, 4).toString("ascii") === "RIFF" &&
    (bytes.subarray(8, 12).toString("ascii") === "WEBP" || bytes.subarray(8, 12).toString("ascii") === "AVI ")
  ) {
    return true;
  }
  if (bytes.length >= 4 && bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3) return true;
  if (bytes.length >= 12 && bytes.subarray(4, 8).toString("ascii") === "ftyp") return true;
  return false;
}

export function saveUploadedEvidence(userId: string, bytes: Buffer) {
  if (!userId) throw new Error("telegram auth required");
  if (bytes.length > MAX_EVIDENCE_FILE) throw new Error("file too large");
  if (!isAllowedEvidenceMagic(bytes)) throw new Error("not media");
  mkdirSync(EVIDENCE_DIR, { recursive: true });
  const id = randomUUID();
  writeFileSync(join(EVIDENCE_DIR, id), bytes);
  writeEvidenceOwner(id, userId);
  pruneEvidenceDir();
  return id;
}

const chunkCursor = new Map<string, number>();

export function appendEvidenceChunk(userId: string, requestedId: string, index: number, total: number, bytes: Buffer) {
  if (!userId) throw new Error("telegram auth required");
  if (index < 0 || total < 1 || index >= total) throw new Error("bad chunk");
  mkdirSync(EVIDENCE_DIR, { recursive: true });
  const safe = index === 0 ? randomUUID() : sanitizeEvidenceId(requestedId);
  if (!safe) throw new Error("bad chunk");
  if (index === 0 && !isAllowedEvidenceMagic(bytes)) throw new Error("not media");
  if (index > 0 && readEvidenceOwner(safe) !== userId) throw new Error("forbidden");
  if (index === 0) writeEvidenceOwner(safe, userId);
  const part = join(EVIDENCE_DIR, `${safe}.part`);
  const dest = join(EVIDENCE_DIR, safe);
  const idxPath = join(EVIDENCE_DIR, `${safe}.idx`);
  if (existsSync(dest) && readEvidenceOwner(safe) === userId) return safe;
  const expected = chunkCursor.get(safe) ?? (existsSync(idxPath) ? Number(readFileSync(idxPath, "utf8") || 0) : 0);
  if (index < expected) return safe;
  if (index !== expected) throw new Error("chunk order");
  if (bytes.length > MAX_EVIDENCE_CHUNK) throw new Error("chunk too large");
  if (index === 0) {
    if (existsSync(part)) unlinkSync(part);
    if (existsSync(dest)) unlinkSync(dest);
  }
  const already = existsSync(part) ? statSync(part).size : 0;
  if (already + bytes.length > MAX_EVIDENCE_FILE) {
    try {
      unlinkSync(part);
    } catch {
      /* ignore */
    }
    chunkCursor.delete(safe);
    throw new Error("file too large");
  }
  appendFileSync(part, bytes);
  const next = index + 1;
  chunkCursor.set(safe, next);
  writeFileSync(idxPath, String(next));
  if (index !== total - 1) return safe;
  if (existsSync(dest)) unlinkSync(dest);
  renameSync(part, dest);
  try {
    unlinkSync(idxPath);
  } catch {
    /* ignore */
  }
  chunkCursor.delete(safe);
  pruneEvidenceDir();
  return safe;
}

export function evidenceBytesOnDisk(id?: string): number {
  const path = id ? uploadedEvidencePath(id) : null;
  if (!path) return 0;
  try {
    return statSync(path).size;
  } catch {
    return 0;
  }
}

const rateHits = new Map<string, number[]>();

function tooMany(key: string, max: number, windowMs: number) {
  const now = Date.now();
  if (rateHits.size > 4000) {
    for (const [k, hits] of rateHits) {
      const keep = hits.filter((t) => now - t < 6 * 60 * 60 * 1000);
      if (!keep.length) rateHits.delete(k);
      else rateHits.set(k, keep);
    }
  }
  const keep = (rateHits.get(key) || []).filter((t) => now - t < windowMs);
  if (keep.length >= max) {
    rateHits.set(key, keep);
    return true;
  }
  keep.push(now);
  rateHits.set(key, keep);
  return false;
}

export function verifyTelegramInitData(initData: string): { id: string; username?: string } | null {
  if (!botToken() || !initData) return null;
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get("hash") || "";
    if (!hash) return null;
    params.delete("hash");
    const dataCheck = [...params.entries()]
      .map(([k, v]) => `${k}=${v}`)
      .sort()
      .join("\n");
    const secret = createHmac("sha256", "WebAppData").update(botToken()).digest();
    const calc = createHmac("sha256", secret).update(dataCheck).digest("hex");
    const a = Buffer.from(calc, "hex");
    const b = Buffer.from(hash, "hex");
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const authDate = Number(params.get("auth_date") || 0);
    if (!authDate || Math.abs(Date.now() / 1000 - authDate) > 86_400) return null;
    const user = JSON.parse(params.get("user") || "{}") as { id?: number; username?: string };
    if (!user?.id) return null;
    return { id: String(user.id), username: user.username };
  } catch {
    return null;
  }
}

function pruneEvidenceDir() {
  try {
    if (!existsSync(EVIDENCE_DIR)) return;
    const files = readdirSync(EVIDENCE_DIR)
      .map((name) => {
        const path = join(EVIDENCE_DIR, name);
        const st = statSync(path);
        return { path, mtime: st.mtimeMs, size: st.size };
      })
      .sort((a, b) => a.mtime - b.mtime);
    let total = files.reduce((s, f) => s + f.size, 0);
    const maxBytes = 8 * 1024 * 1024 * 1024;
    const maxFiles = 400;
    while (files.length && (files.length > maxFiles || total > maxBytes)) {
      const drop = files.shift();
      if (!drop) break;
      total -= drop.size;
      try {
        unlinkSync(drop.path);
      } catch {
        /* ignore */
      }
    }
  } catch {
    /* ignore */
  }
}

export function allowEvidenceUpload(initData: string, bytes = 1): { ok: true; userId: string } | { ok: false; error: string } {
  if (bytes < 0) return { ok: false, error: "file required" };
  if (bytes > MAX_EVIDENCE_CHUNK) return { ok: false, error: "chunk too large" };
  const user = verifyTelegramInitData(initData);
  if (!user) return { ok: false, error: "telegram auth required" };
  if (tooMany(`up:${user.id}`, 40, 60 * 60 * 1000)) return { ok: false, error: "too many uploads" };
  if (tooMany(`upchunk:${user.id}`, 600, 60 * 1000)) return { ok: false, error: "upload too fast" };
  if (tooMany("up:global", 2000, 60 * 60 * 1000)) return { ok: false, error: "server busy" };
  return { ok: true, userId: user.id };
}

export function allowEvidenceDownload(): boolean {
  return !tooMany("evget:global", 240, 60 * 1000);
}

export function allowEvidenceChunk(initData: string, bytes: number): { ok: true; userId: string } | { ok: false; error: string } {
  if (bytes > MAX_EVIDENCE_CHUNK) return { ok: false, error: "chunk too large" };
  const user = verifyTelegramInitData(initData);
  if (!user) return { ok: false, error: "telegram auth required" };
  if (tooMany(`upchunk:${user.id}`, 600, 60 * 1000)) return { ok: false, error: "upload too fast" };
  if (tooMany("upchunk:global", 2000, 60 * 1000)) return { ok: false, error: "server busy" };
  return { ok: true, userId: user.id };
}

function allowNewComplaint(userId: string, storyLen: number): string | null {
  const loc = langOf(userId);
  if (storyLen > 5000) return tb(loc, "storyLong");
  if (tooMany(`app:${userId}`, 3, 6 * 60 * 60 * 1000)) return tb(loc, "tooManyUser");
  if (tooMany("app:global", 40, 60 * 60 * 1000)) return tb(loc, "tooManyGlobal");
  return null;
}

function readUploadedEvidence(id: string): Buffer | null {
  const path = uploadedEvidencePath(id);
  if (!path) return null;
  try {
    return readFileSync(path);
  } catch {
    return null;
  }
}

export function uploadedEvidencePath(id: string): string | null {
  const safe = sanitizeEvidenceId(id);
  if (!safe) return null;
  const path = join(EVIDENCE_DIR, safe);
  if (!path.startsWith(EVIDENCE_DIR)) return null;
  return existsSync(path) ? path : null;
}

type TgResult<T> = { ok: true; result: T } | { ok: false; description: string; error_code?: number };

async function tg<T>(method: string, body: Record<string, unknown> = {}): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 45_000);
  try {
    const res = await fetch(`${botApi()}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    const json = (await res.json()) as TgResult<T>;
    if (!json.ok) throw new Error(json.description || method);
    return json.result;
  } finally {
    clearTimeout(timer);
  }
}

async function tgSoft<T>(method: string, body: Record<string, unknown> = {}): Promise<T | null> {
  try {
    return await tg<T>(method, body);
  } catch {
    return null;
  }
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&" + "amp;")
    .replace(/</g, "&" + "lt;")
    .replace(/>/g, "&" + "gt;");
}

function withHundredPrefix(id: string): string | null {
  if (!id.startsWith("-") || id.startsWith("-100")) return null;
  return `-100${id.slice(1)}`;
}

function chatIdKey(id: string | number): string {
  return String(id).trim().replace(/^-100/, "-").replace(/^-/, "");
}

function sameChat(a: string | number | undefined, b: string | number | undefined): boolean {
  if (a == null || b == null) return false;
  return chatIdKey(a) === chatIdKey(b);
}

const OFFICIAL_ARBITER_IDS = [
  PINNED_ARBITER_CHAT,
  REQUESTED_ARBITER,
  withHundredPrefix(REQUESTED_ARBITER),
].filter((id): id is string => Boolean(id));

function isOfficialArbiterChat(id: string | number | undefined): boolean {
  if (id == null) return false;
  return OFFICIAL_ARBITER_IDS.some((allowed) => sameChat(allowed, id));
}

function arbiterCandidates(): string[] {
  const ids = [PINNED_ARBITER_CHAT, bindings.arbiterChatId, ...OFFICIAL_ARBITER_IDS].filter(
    (id): id is string => Boolean(id) && isOfficialArbiterChat(id),
  );
  return [...new Set(ids)];
}

function isOfficialChannel(id: string | number | undefined): boolean {
  if (id == null) return false;
  if (sameChat(id, PINNED_CHANNEL)) return true;
  return Boolean(bindings.channelId && sameChat(bindings.channelId, id));
}

if (!isOfficialArbiterChat(bindings.arbiterChatId)) {
  bindings.arbiterChatId = PINNED_ARBITER_CHAT;
}
if (!bindings.channelId) {
  bindings.channelId = PINNED_CHANNEL;
}
if (bindings.cardStamp !== "new-bot-v1") {
  bindings.cards = {};
  bindings.cardStamp = "new-bot-v1";
}
saveBindings();

function channelCandidates(): string[] {
  const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter(
    (id): id is string => Boolean(id),
  );
  return [...new Set(ids)];
}

async function chatReachable(id: string) {
  return tgSoft<{ id: number; title?: string; type: string }>("getChat", { chat_id: id });
}

function refreshBindings() {
  bindings = { ...bindings, ...loadBindings() };
}

function isGatedHost(url: string) {
  try {
    const host = new URL(url).hostname;
    return /(^|\.)grok\.me$/i.test(host) || /(^|\.)grok-sandbox\.com$/i.test(host);
  } catch {
    return true;
  }
}

function publicMiniAppUrl(): string | undefined {
  refreshBindings();
  const url = bindings.miniAppUrl || DEFAULT_PUBLIC_URL;
  if (!url.startsWith("https://") || isGatedHost(url)) return undefined;
  return url.replace(/\/$/, "");
}

let lastMenuUrl = "";

async function applyMenuButton() {
  const url = publicMiniAppUrl() || "";
  if (url === lastMenuUrl) return;
  lastMenuUrl = url;
  if (url) {
    await tgSoft("setChatMenuButton", {
      menu_button: {
        type: "web_app",
        text: "Открыть",
        web_app: { url },
      },
    });
    return;
  }
  await tgSoft("setChatMenuButton", { menu_button: { type: "commands" } });
}

function publicSiteUrl(): string | undefined {
  const fromEnv = (process.env.PUBLIC_URL || DEFAULT_PUBLIC_URL).replace(/\/$/, "");
  if (fromEnv.startsWith("https://") && !isGatedHost(fromEnv)) return fromEnv;
  return publicMiniAppUrl();
}

async function ensureProductionWebhook() {
  const site = publicSiteUrl();
  if (!site) return;
  const hook = `${site}/api/telegram/webhook`;
  const info = await tgSoft<{ url?: string }>("getWebhookInfo");
  if (info?.url === hook) {
    await applyMenuButton();
    return;
  }
  await tgSoft("setWebhook", {
    url: hook,
    secret_token: webhookSecret(),
    allowed_updates: ["message", "callback_query", "my_chat_member"],
    drop_pending_updates: false,
  });
  await registerMiniAppUrl(site);
}

async function ensurePolling() {
  if (process.env.PUBLIC_URL || process.env.NODE_ENV === "production") {
    await ensureProductionWebhook();
    return;
  }
  const info = await tgSoft<{ url?: string }>("getWebhookInfo");
  if (info?.url) {
    await tgSoft("deleteWebhook", { drop_pending_updates: false });
  }
  if (bindings.miniAppUrl && isGatedHost(bindings.miniAppUrl)) {
    delete bindings.miniAppUrl;
    saveBindings();
  }
  await applyMenuButton();
}

async function ensureBotProfile() {
  if (profileReady && commandsStamp === COMMANDS_STAMP) return;
  await ensurePolling();
  if (commandsStamp !== COMMANDS_STAMP) {
    commandsStamp = COMMANDS_STAMP;
    await tgSoft("setMyCommands", {
      commands: [
        { command: "start", description: "Открыть приложение" },
        { command: "apply", description: "Подать жалобу в чате" },
        { command: "cancel", description: "Отменить заявку" },
        { command: "lang", description: "Язык / Language" },
      ],
      scope: { type: "all_private_chats" },
    });
    await tgSoft("setMyCommands", {
      commands: [
        { command: "start", description: "Открыть приложение" },
        { command: "apply", description: "Подать жалобу в чате" },
        { command: "cancel", description: "Отменить заявку" },
        { command: "lang", description: "Язык / Language" },
      ],
      language_code: "ru",
      scope: { type: "all_private_chats" },
    });
    await tgSoft("setMyCommands", {
      commands: [
        { command: "start", description: "Open the app" },
        { command: "apply", description: "File a complaint in chat" },
        { command: "cancel", description: "Cancel the complaint" },
        { command: "lang", description: "Language / Язык" },
      ],
      language_code: "en",
      scope: { type: "all_private_chats" },
    });
    await tgSoft("deleteMyCommands", { scope: { type: "default" } });
    await tgSoft("deleteMyCommands", { scope: { type: "all_group_chats" } });
    await tgSoft("deleteMyCommands", { scope: { type: "all_chat_administrators" } });
  }
  profileReady = true;
}

export async function getBotStatus() {
  await ensureBotProfile();
  const me = await tgSoft<{ username: string; first_name: string }>("getMe");

  let arbiterOk = false;
  for (const id of arbiterCandidates()) {
    const chat = await chatReachable(id);
    if (!chat) continue;
    arbiterOk = true;
    break;
  }

  let channelOk = false;
  for (const id of channelCandidates()) {
    const chat = await chatReachable(id);
    if (chat) {
      channelOk = true;
      break;
    }
  }

  return {
    bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
    arbiterOk,
    channelOk,
  };
}

async function resolveUsernameMtproto(username: string): Promise<{ username: string; id: string } | null> {
  if (!botToken() || tooMany("mtproto:resolve", 12, 60_000)) return null;
  let client: any = null;
  try {
    const { TelegramClient } = await import("telegram");
    const { StringSession } = await import("telegram/sessions/index.js");
    const { Api } = await import("telegram/tl/index.js");
    const { Logger } = await import("telegram/extensions/Logger.js");
    const apiId = Number(process.env.TELEGRAM_API_ID || 2040);
    const apiHash = process.env.TELEGRAM_API_HASH || "b18441a1ff607e10a989891a5462e627";
    client = new TelegramClient(new StringSession(""), apiId, apiHash, {
      connectionRetries: 1,
      timeout: 12,
      deviceModel: "EPB",
      systemVersion: "Linux",
      appVersion: "1.0",
      autoReconnect: false,
      baseLogger: new Logger("none" as never),
    });
    await client.start({ botAuthToken: botToken() });
    const result = (await client.invoke(new Api.contacts.ResolveUsername({ username }))) as {
      peer?: { userId?: unknown };
      users?: { id?: unknown; username?: string }[];
    };
    const user = result.users?.[0];
    const id = String(user?.id ?? result.peer?.userId ?? "");
    if (!/^\d{5,15}$/.test(id)) return null;
    return { username: user?.username || username, id };
  } catch {
    return null;
  } finally {
    try {
      await client?.disconnect?.();
    } catch {
      /* ignore */
    }
    try {
      await client?.destroy?.();
    } catch {
      /* ignore */
    }
  }
}

export async function resolveHandleServer(input: string): Promise<{
  username: string;
  id: string;
  source: "telegram" | "parsed" | "unresolved";
} | null> {
  const parsed = parseTelegramInput(input);
  if (!parsed.username && !parsed.id) return null;
  if (tooMany("resolve:global", 80, 60_000)) {
    const cached = parsed.username ? idCache[parsed.username.toLowerCase()] : "";
    return {
      username: parsed.username,
      id: parsed.id || cached || "",
      source: parsed.id || cached ? "telegram" : "unresolved",
    };
  }
  if (parsed.id) {
    if (parsed.username) rememberHandle(parsed.username, parsed.id);
    else {
      const chat = await tgSoft<{ id: number; username?: string }>("getChat", { chat_id: parsed.id });
      if (chat?.username) rememberHandle(chat.username, parsed.id);
      return { username: chat?.username || "", id: parsed.id, source: "parsed" };
    }
    return { username: parsed.username, id: parsed.id, source: "parsed" };
  }
  const username = parsed.username;
  const cached = idCache[username.toLowerCase()];
  if (cached) return { username, id: cached, source: "telegram" };

  for (const rec of Object.values(pendingPosts)) {
    const hit = pendingAccounts(rec).find((a) => a.username.replace(/^@/, "").toLowerCase() === username.toLowerCase() && a.id);
    if (hit?.id) {
      rememberHandle(username, hit.id);
      return { username, id: hit.id, source: "telegram" };
    }
  }

  const chat = await tgSoft<{ id: number; username?: string; type?: string }>("getChat", {
    chat_id: `@${username}`,
  });
  if (chat?.id) {
    const id = String(chat.id);
    rememberHandle(chat.username || username, id);
    return { username: chat.username || username, id, source: "telegram" };
  }
  const mt = await resolveUsernameMtproto(username);
  if (mt?.id) {
    rememberHandle(mt.username, mt.id);
    return { username: mt.username, id: mt.id, source: "telegram" };
  }
  return { username, id: "", source: "unresolved" };
}

function pendingAccounts(record?: PendingPost, fallbackUser = "", fallbackId = ""): { username: string; id: string }[] {
  if (record?.accounts?.length) return record.accounts;
  if (record?.username || record?.id) return [{ username: record.username, id: record.id }];
  if (fallbackUser || fallbackId) return [{ username: fallbackUser, id: fallbackId }];
  return [];
}

function formatAccountLine(username: string, id: string, html = false) {
  const handle = username.replace(/^@/, "");
  const name = handle ? `@${handle}` : "";
  if (html) {
    return `${name ? `${escapeHtml(name)} · ` : ""}<code>${escapeHtml(id)}</code>`;
  }
  return [name, id ? `Id: ${id}` : ""].filter(Boolean).join("\n");
}

function applicationBriefHtml(app: Application): string {
  const victimUser = escapeHtml(app.victim.username.replace(/^@/, ""));
  const victim = `${victimUser ? `@${victimUser}` : "без username"} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
  const accounts = scammerAccounts(app);
  const scammer = accounts.map((a) => formatAccountLine(a.username, a.telegramId, true)).join("\n");
  const brief = (app.summary || app.story).trim();
  return [
    `<b>Заявка ${escapeHtml(app.id)}</b>`,
    "",
    `<b>Пострадавший</b>\n${victim}`,
    `<b>Аккаунт</b>\n${scammer}`,
    `<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
    "",
    `<b>Кратко (в пост)</b>\n${escapeHtml(brief)}`,
  ].join("\n");
}

function applicationDetailHtml(app: Application): string {
  const detail = app.story.trim();
  const brief = (app.summary || "").trim();
  if (!detail || detail === brief) return "";
  return `<b>Подробно</b>\n${escapeHtml(detail)}`;
}

function applicationHtml(app: Application): string {
  const extra = applicationDetailHtml(app);
  return extra ? `${applicationBriefHtml(app)}\n\n${extra}` : applicationBriefHtml(app);
}

function formatScamAmount(amount: string, currency: string) {
  const value = amount.trim();
  if (!value) return "";
  if (currency === "USD") return `scam ${escapeHtml(value)}$`;
  return `scam ${escapeHtml(value)} ${escapeHtml(currency)}`.trim();
}

function formatChannelAccounts(
  accounts: { username: string; id: string }[],
  amount = "",
  currency = "",
): string[] {
  const scam = formatScamAmount(amount, currency);
  const multi = accounts.length > 1;
  return accounts.map((a, i) => {
    const handle = a.username.replace(/^@/, "");
    const name = handle ? `@${escapeHtml(handle)}` : "";
    const id = a.id ? `Id: ${escapeHtml(a.id)}` : "";
    const last = i === accounts.length - 1;
    if (multi) {
      const head = [name, id].filter(Boolean).join(" ");
      if (!last) return `${head} ;`;
      return scam ? `${head} - ${scam}` : head;
    }
    if (id && scam) return [name, `${id} - ${scam}`].filter(Boolean).join("\n");
    return [name, id].filter(Boolean).join("\n");
  });
}

function channelHtml(
  accounts: { username: string; id: string }[],
  story: string,
  amount = "",
  currency = "",
): string {
  const people = formatChannelAccounts(accounts, amount, currency);
  const subscribe = `<b>Subscribe:</b> <b><a href="${CHANNEL_URL}">Europe Private Blacklist</a></b>`;
  return [...people, "", escapeHtml(story.trim()), "", subscribe]
    .filter((line, i, arr) => line !== "" || (arr[i - 1] !== "" && i !== 0))
    .join("\n")
    .replace(/\n{3,}/g, "\n\n");
}

function applicationCaption(app: Application): string {
  const accounts = scammerAccounts(app);
  const scamLine = accounts
    .map((a) => formatAccountLine(a.username, a.telegramId, true))
    .join("\n");
  const victimUser = app.victim.username.replace(/^@/, "");
  return [
    `<b>Жалоба ${escapeHtml(app.id)}</b>`,
    `Пострадавший: ${victimUser ? `@${escapeHtml(victimUser)} · ` : ""}<code>${escapeHtml(app.victim.telegramId)}</code>`,
    `Аккаунт:\n${scamLine}`,
    `Ущерб: ${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
  ].join("\n").slice(0, 1024);
}

function splitHtml(html: string, max = 4090): string[] {
  if (html.length <= max) return [html];
  const parts: string[] = [];
  let rest = html;
  while (rest.length) {
    if (rest.length <= max) {
      parts.push(rest);
      break;
    }
    let cut = rest.lastIndexOf("\n", max);
    if (cut < max / 3) cut = max;
    parts.push(rest.slice(0, cut));
    rest = rest.slice(cut).replace(/^\n+/, "");
  }
  return parts;
}

function reviewKeyboard(appId = "") {
  return {
    inline_keyboard: [
      [
        { text: "Опубликовать", callback_data: appId ? `pub:${appId}` : "pub" },
        { text: "Отклонить", callback_data: appId ? `rej:${appId}` : "rej" },
      ],
    ],
  };
}

function publishChoiceKeyboard(key = "") {
  const suffix = key ? `:${key}` : "";
  return {
    inline_keyboard: [
      [{ text: "Опубликовать с рассылкой", callback_data: `puball${suffix}`.slice(0, 64) }],
      [{ text: "Опубликовать без рассылки", callback_data: `pubch${suffix}`.slice(0, 64) }],
    ],
  };
}

async function tgForm<T>(method: string, form: FormData): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 120_000);
  try {
    const res = await fetch(`${botApi()}/${method}`, { method: "POST", body: form, signal: ctrl.signal });
    const json = (await res.json()) as TgResult<T>;
    if (!json.ok) throw new Error(json.description || method);
    return json.result;
  } finally {
    clearTimeout(timer);
  }
}

const TG_UPLOAD_MAX = 49 * 1024 * 1024;

function mediaSize(file: EvidenceItem) {
  return file.size || evidenceBytesOnDisk(file.storageKey);
}

function evidencePublicUrl(storageKey?: string) {
  if (!storageKey || !sanitizeEvidenceId(storageKey)) return "";
  const site = publicSiteUrl();
  if (!site) return "";
  const exp = Date.now() + 24 * 60 * 60 * 1000;
  const sig = evidenceSig(storageKey, exp);
  return `${site}/api/telegram/evidence?key=${encodeURIComponent(storageKey)}&exp=${exp}&sig=${sig}`;
}

async function sendMediaFile(
  chatId: string,
  file: EvidenceItem,
  opts: { caption?: string; replyMarkup?: unknown; replyTo?: number } = {},
): Promise<{ message_id: number; chat: { id: number }; fileId?: string; kind: "photo" | "video" }> {
  const size = mediaSize(file);
  if (file.kind === "video" && size > TG_UPLOAD_MAX) {
    return sendLargeVideo(chatId, file, opts);
  }
  const blob = evidenceBlob(file);
  if (!blob) throw new Error("empty file");
  if (blob.size > TG_UPLOAD_MAX && file.kind === "video") {
    return sendLargeVideo(chatId, file, opts);
  }
  const form = new FormData();
  form.set("chat_id", String(chatId));
  if (opts.caption) {
    form.set("caption", opts.caption);
    form.set("parse_mode", "HTML");
  }
  if (opts.replyMarkup) form.set("reply_markup", JSON.stringify(opts.replyMarkup));
  if (opts.replyTo) form.set("reply_to_message_id", String(opts.replyTo));
  if (file.kind === "video") {
    form.set("video", blob, file.name || "video.mp4");
    const sent = await tgForm<{ message_id: number; chat: { id: number }; video?: { file_id: string } }>(
      "sendVideo",
      form,
    );
    return { ...sent, fileId: sent.video?.file_id, kind: "video" };
  }
  form.set("photo", blob, file.name || "photo.jpg");
  const sent = await tgForm<{ message_id: number; chat: { id: number }; photo?: { file_id: string }[] }>(
    "sendPhoto",
    form,
  );
  return { ...sent, fileId: sent.photo?.at(-1)?.file_id, kind: "photo" };
}

async function sendLargeVideo(
  chatId: string,
  file: EvidenceItem,
  opts: { caption?: string; replyMarkup?: unknown; replyTo?: number } = {},
): Promise<{ message_id: number; chat: { id: number }; fileId?: string; kind: "photo" | "video" }> {
  const url = evidencePublicUrl(file.storageKey);
  const extra: Record<string, unknown> = {
    chat_id: chatId,
  };
  if (opts.caption) {
    extra.caption = opts.caption;
    extra.parse_mode = "HTML";
  }
  if (opts.replyMarkup) extra.reply_markup = opts.replyMarkup;
  if (opts.replyTo) extra.reply_to_message_id = opts.replyTo;
  if (url) {
    const video = await tgSoft<{ message_id: number; chat: { id: number }; video?: { file_id: string } }>("sendVideo", {
      ...extra,
      video: url,
      supports_streaming: true,
    });
    if (video) return { ...video, fileId: video.video?.file_id, kind: "video" };
    const doc = await tgSoft<{ message_id: number; chat: { id: number }; document?: { file_id: string } }>(
      "sendDocument",
      { ...extra, document: url },
    );
    if (doc) return { message_id: doc.message_id, chat: doc.chat, fileId: doc.document?.file_id, kind: "video" };
  }
  const link = url || file.name || "видео";
  const sent = await tg<{ message_id: number; chat: { id: number } }>("sendMessage", {
    chat_id: chatId,
    text: [opts.caption, `Видео: ${escapeHtml(file.name || "файл")}`, url ? `<a href="${url}">скачать</a>` : link]
      .filter(Boolean)
      .join("\n"),
    parse_mode: "HTML",
    disable_web_page_preview: false,
    reply_markup: opts.replyMarkup,
    reply_to_message_id: opts.replyTo,
  });
  return { ...sent, kind: "video" };
}

type CopiedMedia = {
  chatId: number;
  messageId: number;
  fileId?: string;
  kind?: "photo" | "video" | "document";
};

function storePending(app: Application, files: MediaRef[]) {
  const accounts = scammerAccounts(app).map((a) => ({
    username: a.username.replace(/^@/, ""),
    id: a.telegramId,
  }));
  for (const a of accounts) rememberHandle(a.username, a.id);
  const first = accounts[0] || { username: app.scammer.username, id: app.scammer.telegramId };
  pendingPosts[app.id] = {
    username: first.username,
    id: first.id,
    accounts,
    story: app.story,
    summary: app.summary || "",
    amount: app.damageAmount,
    currency: app.damageCurrency,
    files,
    victimId: app.victim.telegramId,
    victimUsername: app.victim.username,
    createdAt: app.createdAt || Date.now(),
    status: "pending",
  };
  savePending();
}

function scamLabel(record: PendingPost | undefined) {
  const accounts = pendingAccounts(record);
  if (!accounts.length) return "аккаунт";
  return accounts
    .map((a) => (a.username ? `@${a.username.replace(/^@/, "")}` : a.id ? `ID ${a.id}` : ""))
    .filter(Boolean)
    .join(", ");
}

async function notifyApplicant(record: PendingPost | undefined, appId: string, kind: "pending" | "published" | "rejected") {
  const chatId = record?.victimId;
  if (!chatId) return;
  const scam = scamLabel(record);
  const text =
    kind === "pending"
      ? btUser(chatId, "pendingNotice", { id: appId, scam })
      : kind === "published"
        ? btUser(chatId, "publishedNotice", { id: appId, scam })
        : btUser(chatId, "rejectedNotice", { id: appId, scam });
  await tgSoft("sendMessage", { chat_id: chatId, text, disable_web_page_preview: true });
}

export function listComplaintsForUser(telegramId: string): ComplaintHistoryItem[] {
  const uid = String(telegramId || "").trim();
  if (!uid) return [];
  return Object.entries(pendingPosts)
    .filter(([, c]) => c.victimId === uid)
    .map(([id, c]) => ({
      id,
      scammerUsername: pendingAccounts(c)
        .map((a) => a.username)
        .filter(Boolean)
        .join(" · ") || c.username || "",
      scammerId: pendingAccounts(c)
        .map((a) => a.id)
        .filter(Boolean)
        .join(", ") || c.id || "",
      amount: c.amount || "",
      currency: c.currency || "",
      status: c.status || "pending",
      createdAt: c.createdAt || 0,
    }))
    .sort((a, b) => b.createdAt - a.createdAt);
}

function packCaption(full: string, _fallback = "") {
  if (full.length <= 1024) return { caption: full, leftover: "" };
  return { caption: "", leftover: full };
}

async function attachReviewButtons(chatId: string, messageId: number, leftover: string, keyboard: unknown) {
  if (!leftover) {
    const sent = await tgSoft<{ message_id: number }>("sendMessage", {
      chat_id: chatId,
      text: "Опубликовать или отклонить:",
      reply_to_message_id: messageId,
      reply_markup: keyboard,
    });
    return sent?.message_id || messageId;
  }
  const parts = splitHtml(leftover);
  let lastId = messageId;
  for (let i = 0; i < parts.length; i++) {
    const sent = await tgSoft<{ message_id: number }>("sendMessage", {
      chat_id: chatId,
      text: parts[i],
      parse_mode: "HTML",
      disable_web_page_preview: true,
      reply_to_message_id: i === 0 ? messageId : undefined,
      reply_markup: i === parts.length - 1 ? keyboard : undefined,
    });
    if (sent?.message_id) lastId = sent.message_id;
  }
  return lastId;
}

function mediaRefsFromCopies(copies: CopiedMedia[]): MediaRef[] {
  return copies
    .filter((c): c is CopiedMedia & { fileId: string } => Boolean(c.fileId))
    .map((c) => ({
      type: c.kind === "video" ? "video" : c.kind === "document" ? "document" : "photo",
      file_id: c.fileId,
    }));
}

async function sendAlbumByFileIds(
  chatId: string,
  files: MediaRef[],
  caption: string,
  keyboard: unknown,
  followUp = caption,
): Promise<{ chat_id: string; message_id: number; files: MediaRef[] }> {
  if (!files.length) {
    const parts = splitHtml(followUp);
    let lastId = 0;
    let lastChat = chatId;
    for (let i = 0; i < parts.length; i++) {
      const sent = await tg<{ message_id: number; chat: { id: number } }>("sendMessage", {
        chat_id: chatId,
        text: parts[i],
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: i === parts.length - 1 ? keyboard : undefined,
      });
      lastId = sent.message_id;
      lastChat = String(sent.chat.id);
    }
    return { chat_id: lastChat, message_id: lastId, files: [] };
  }
  if (files.length === 1) {
    const file = files[0]!;
    const packed = packCaption(followUp, caption);
    const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
    const payload: Record<string, unknown> = {
      chat_id: chatId,
    };
    if (packed.caption) {
      payload.caption = packed.caption;
      payload.parse_mode = "HTML";
    }
    if (!packed.leftover) payload.reply_markup = keyboard;
    if (file.type === "video") payload.video = file.file_id;
    else if (file.type === "document") payload.document = file.file_id;
    else payload.photo = file.file_id;
    const sent = await tg<{ message_id: number; chat: { id: number } }>(method, payload);
    if (!packed.leftover) return { chat_id: String(sent.chat.id), message_id: sent.message_id, files };
    const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
    return { chat_id: String(sent.chat.id), message_id: actionId, files };
  }

  const packed = packCaption(followUp, caption);
  let firstId = 0;
  for (let i = 0; i < files.length; i += 10) {
    const chunk = files.slice(i, i + 10);
    if (chunk.length === 1) {
      const file = chunk[0]!;
      const method = file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
      const payload: Record<string, unknown> = { chat_id: chatId };
      if (file.type === "video") payload.video = file.file_id;
      else if (file.type === "document") payload.document = file.file_id;
      else payload.photo = file.file_id;
      if (i === 0 && packed.caption) {
        payload.caption = packed.caption;
        payload.parse_mode = "HTML";
      }
      const sent = await tg<{ message_id: number }>(method, payload);
      if (i === 0) firstId = sent.message_id;
      continue;
    }
    const result = await tg<{ message_id: number }[]>("sendMediaGroup", {
      chat_id: chatId,
      media: chunk.map((file, idx) => ({
        type: file.type,
        media: file.file_id,
        ...(i === 0 && idx === 0 && packed.caption ? { caption: packed.caption, parse_mode: "HTML" } : {}),
      })),
    });
    if (i === 0) firstId = result[0]?.message_id || 0;
  }
  const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
  return { chat_id: chatId, message_id: actionId, files };
}

async function sendAlbumFromBlobs(
  chatId: string,
  blobs: EvidenceItem[],
  caption: string,
  keyboard: unknown,
  followUp = caption,
): Promise<{ chat_id: string; message_id: number; files: MediaRef[] }> {
  const packed = packCaption(followUp, caption);
  const small = blobs.filter((f) => f.kind !== "video" || mediaSize(f) <= TG_UPLOAD_MAX);
  const large = blobs.filter((f) => f.kind === "video" && mediaSize(f) > TG_UPLOAD_MAX);
  const files: MediaRef[] = [];
  let firstId = 0;

  if (!small.length && large.length) {
    const sent = await sendMediaFile(chatId, large[0]!, {
      caption: packed.caption || undefined,
      replyMarkup: packed.leftover || large.length > 1 ? undefined : keyboard,
    });
    if (sent.fileId) files.push({ type: sent.kind, file_id: sent.fileId });
    for (const extra of large.slice(1)) {
      const more = await sendMediaFile(chatId, extra);
      if (more.fileId) files.push({ type: more.kind, file_id: more.fileId });
    }
    if (!packed.leftover && large.length === 1) {
      return { chat_id: String(sent.chat.id), message_id: sent.message_id, files };
    }
    const actionId = await attachReviewButtons(chatId, sent.message_id, packed.leftover, keyboard);
    return { chat_id: String(sent.chat.id), message_id: actionId, files };
  }

  if (small.length <= 1) {
    const sent = await sendMediaFile(chatId, small[0]!, {
      caption: packed.caption || undefined,
      replyMarkup: packed.leftover || large.length ? undefined : keyboard,
    });
    if (sent.fileId) files.push({ type: sent.kind, file_id: sent.fileId });
    firstId = sent.message_id;
    for (const extra of large) {
      const more = await sendMediaFile(chatId, extra);
      if (more.fileId) files.push({ type: more.kind, file_id: more.fileId });
    }
    if (!packed.leftover && !large.length) {
      return { chat_id: String(sent.chat.id), message_id: sent.message_id, files };
    }
    const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
    return { chat_id: String(sent.chat.id), message_id: actionId, files };
  }

  for (let i = 0; i < small.length; i += 10) {
    const chunk = small.slice(i, i + 10);
    if (chunk.length === 1) {
      const sent = await sendMediaFile(chatId, chunk[0]!, i === 0 && packed.caption ? { caption: packed.caption } : {});
      if (sent.fileId) files.push({ type: sent.kind, file_id: sent.fileId });
      if (i === 0) firstId = sent.message_id;
      continue;
    }
    const form = new FormData();
    form.set("chat_id", chatId);
    const media: Record<string, unknown>[] = [];
    chunk.forEach((file, idx) => {
      const blob = evidenceBlob(file);
      if (!blob) return;
      const key = `file${i + idx}`;
      form.set(key, blob, file.name || `${key}.jpg`);
      media.push({
        type: file.kind === "video" ? "video" : "photo",
        media: `attach://${key}`,
        ...(i === 0 && idx === 0 && packed.caption ? { caption: packed.caption, parse_mode: "HTML" } : {}),
      });
    });
    form.set("media", JSON.stringify(media));
    const result = await tgForm<
      { message_id: number; photo?: { file_id: string }[]; video?: { file_id: string } }[]
    >("sendMediaGroup", form);
    if (i === 0) firstId = result[0]?.message_id || 0;
    for (const msg of result) {
      if (msg.video?.file_id) files.push({ type: "video", file_id: msg.video.file_id });
      else if (msg.photo?.length) files.push({ type: "photo", file_id: msg.photo.at(-1)!.file_id });
    }
  }
  for (const extra of large) {
    const more = await sendMediaFile(chatId, extra);
    if (more.fileId) files.push({ type: more.kind, file_id: more.fileId });
  }
  const actionId = await attachReviewButtons(chatId, firstId, packed.leftover, keyboard);
  return { chat_id: chatId, message_id: actionId, files };
}

async function deliverApplication(
  app: Application,
  copies: CopiedMedia[] = [],
): Promise<{ chat_id: string; message_id: number }> {
  const caption = applicationCaption(app);
  const briefText = applicationBriefHtml(app);
  const detailText = applicationDetailHtml(app);
  const keyboard = reviewKeyboard(app.id);
  const blobs = app.evidence.filter(
    (f) => Boolean(f.storageKey && uploadedEvidencePath(f.storageKey)) || Boolean(evidenceBlob(f)),
  );
  const copyFiles = mediaRefsFromCopies(copies);
  let lastError = "chat not found";

  for (const chat_id of arbiterCandidates()) {
    try {
      if (copyFiles.length || copies.length) {
        const sent = copyFiles.length
          ? await sendAlbumByFileIds(chat_id, copyFiles, caption, keyboard, briefText)
          : null;
        if (sent) {
          if (detailText) {
            await tgSoft("sendMessage", {
              chat_id: sent.chat_id,
              text: detailText,
              parse_mode: "HTML",
              disable_web_page_preview: true,
              reply_to_message_id: sent.message_id,
            });
          }
          storePending(app, sent.files);
          return { chat_id: sent.chat_id, message_id: sent.message_id };
        }
      }

      if (blobs.length) {
        const sent = await sendAlbumFromBlobs(chat_id, blobs, caption, keyboard, briefText);
        if (detailText) {
          await tgSoft("sendMessage", {
            chat_id: sent.chat_id,
            text: detailText,
            parse_mode: "HTML",
            disable_web_page_preview: true,
            reply_to_message_id: sent.message_id,
          });
        }
        storePending(app, sent.files);
        return { chat_id: sent.chat_id, message_id: sent.message_id };
      }

      const parts = splitHtml(briefText);
      let lastId = 0;
      let lastChat = chat_id;
      for (let i = 0; i < parts.length; i++) {
        const sent = await tg<{ message_id: number; chat: { id: number } }>("sendMessage", {
          chat_id,
          text: parts[i],
          parse_mode: "HTML",
          disable_web_page_preview: true,
          reply_markup: i === parts.length - 1 ? keyboard : undefined,
        });
        lastId = sent.message_id;
        lastChat = String(sent.chat.id);
      }
      if (detailText) {
        await tgSoft("sendMessage", {
          chat_id: lastChat,
          text: detailText,
          parse_mode: "HTML",
          disable_web_page_preview: true,
          reply_to_message_id: lastId,
        });
      }
      storePending(app, []);
      return { chat_id: lastChat, message_id: lastId };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }
  }
  throw new Error(lastError);
}

export async function sendApplicationToArbiters(
  app: Application,
  copies: CopiedMedia[] = [],
): Promise<{
  ok: boolean;
  error?: string;
}> {
  const userId = app.victim.telegramId || "";
  const blocked = allowNewComplaint(userId, app.story.length);
  if (blocked) return { ok: false, error: blocked };
  app.id = `EPB-${createHash("sha256").update(`${userId}:${Date.now()}:${Math.random()}`).digest("hex").slice(0, 6).toUpperCase()}`;
  app.evidence = (app.evidence || []).slice(0, 30).map((file) => ({
    ...file,
    name: String(file.name || "file").slice(0, 120),
    dataUrl: "",
    storageKey: evidenceOwnedBy(file.storageKey, userId) ? file.storageKey : undefined,
  }));
  if (app.evidence.length > 30) return { ok: false, error: btUser(userId, "tooManyFiles") };
  try {
    const sent = await deliverApplication(app, copies);
    if (isOfficialArbiterChat(sent.chat_id)) {
      bindings.arbiterChatId = sent.chat_id;
      saveBindings();
    }
    await notifyApplicant(pendingPosts[app.id], app.id, "pending");
    return { ok: true };
  } catch (err) {
    const description = err instanceof Error ? err.message : "send failed";
    if (/chat not found/i.test(description)) {
      return {
        ok: false,
        error: btUser(userId, "addBotArbiter", { bot: BOT_USERNAME }),
      };
    }
    return { ok: false, error: description };
  }
}

async function sendToFirstChat(ids: string[], html: string, extra: Record<string, unknown> = {}) {
  let lastError = "chat not found";
  for (const chat_id of ids) {
    try {
      const result = await tg<{ message_id: number; chat: { id: number } }>("sendMessage", {
        chat_id,
        text: html,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        ...extra,
      });
      return { ...result, chat_id: String(result.chat.id) };
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }
  }
  throw new Error(lastError);
}

function dataUrlToBlob(item: EvidenceItem): Blob | null {
  if (!item.dataUrl?.includes(",")) return null;
  const b64 = item.dataUrl.split(",")[1] || "";
  if (!b64) return null;
  const buf = Buffer.from(b64, "base64");
  return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}

function evidenceBlob(item: EvidenceItem): Blob | null {
  const fromUrl = dataUrlToBlob(item);
  if (fromUrl) return fromUrl;
  if (!item.storageKey) return null;
  const buf = readUploadedEvidence(item.storageKey);
  if (!buf?.length) return null;
  return new Blob([new Uint8Array(buf)], { type: item.mime || "application/octet-stream" });
}

function parseAppKey(text: string, data = "") {
  const fromCb = callbackKey(data);
  if (fromCb && /^EPB-/i.test(fromCb)) return fromCb;
  const fromText = text.match(/\b(EPB-[A-Z0-9]+)\b/i);
  if (fromText?.[1]) return fromText[1];
  return parseEpbMarker(text)?.key || fromCb;
}

function stripServiceMarker(text: string) {
  return text
    .replace(/\n*#epb[^\n]*/gi, "")
    .replace(/\n*#published[^\n]*/gi, "")
    .replace(/\n*#rejected[^\n]*/gi, "")
    .replace(/\n*Статус:[^\n]*/gi, "")
    .trim();
}

function alreadyHandled(text: string) {
  return /Статус:\s*(опубликовано|отклонено)/i.test(text) || text.includes("#published") || text.includes("#rejected");
}

function parseEpbMarker(text: string): { username: string; id: string; story: string; key: string } | null {
  const marker = text.match(/#epb u=(\S*) id=(\d+)(?: k=(\S+))?/);
  if (!marker) return null;
  let story = "";
  if (text.includes("Суть обмана")) {
    story = (text.split("Суть обмана")[1] ?? "")
      .replace(/^\s*\n/, "")
      .replace(/\n#epb[\s\S]*$/, "")
      .trim();
  } else {
    story = text
      .replace(/[\s\S]*?Ущерб:[^\n]*\n+/i, "")
      .replace(/\n*#epb[\s\S]*$/, "")
      .trim();
  }
  return { username: marker[1] ?? "", id: marker[2] ?? "", story, key: marker[3] ?? "" };
}

async function sendPostToChat(chat_id: string, html: string, files: MediaRef[]) {
  const packed = packCaption(html);
  const parts = packed.leftover ? splitHtml(packed.leftover, 4090) : [];
  if (!files.length) {
    const chunks = splitHtml(html, 4090);
    for (const part of chunks) {
      await tg("sendMessage", {
        chat_id,
        text: part,
        parse_mode: "HTML",
        disable_web_page_preview: false,
      });
    }
    return;
  }
  for (let i = 0; i < files.length; i += 10) {
    const chunk = files.slice(i, i + 10);
    const firstCaption = i === 0 && packed.caption ? packed.caption : undefined;
    if (chunk.length === 1) {
      const file = chunk[0]!;
      const payload: Record<string, unknown> = {
        chat_id,
        caption: firstCaption,
        parse_mode: firstCaption ? "HTML" : undefined,
      };
      if (file.type === "video") payload.video = file.file_id;
      else if (file.type === "document") payload.document = file.file_id;
      else payload.photo = file.file_id;
      const method =
        file.type === "video" ? "sendVideo" : file.type === "document" ? "sendDocument" : "sendPhoto";
      await tg(method, payload);
    } else {
      await tg("sendMediaGroup", {
        chat_id,
        media: chunk.map((file, idx) => ({
          type: file.type,
          media: file.file_id,
          ...(firstCaption && idx === 0 ? { caption: firstCaption, parse_mode: "HTML" } : {}),
        })),
      });
    }
  }
  for (const part of parts) {
    await tg("sendMessage", {
      chat_id,
      text: part,
      parse_mode: "HTML",
      disable_web_page_preview: false,
    });
  }
}

function isMissingRights(err: unknown) {
  const text = err instanceof Error ? err.message : String(err);
  return /not enough rights|need administrator|chat not found|bot was blocked|bot is not a member|have no rights|kicked|can't parse/i.test(
    text,
  );
}

function isGroupOrChannel(chat: { id?: number | string; type?: string }) {
  if (chat.type === "private") return false;
  if (chat.type === "group" || chat.type === "supergroup" || chat.type === "channel") return true;
  const id = Number(chat.id);
  return Number.isFinite(id) && id < 0;
}

function relayDestinations(): { id: string; title?: string; type?: string; status: "pending" | "on" | "off" }[] {
  const skip = new Set(
    [...channelCandidates(), PINNED_ARBITER_CHAT, bindings.arbiterChatId || "", ...OFFICIAL_ARBITER_IDS]
      .filter(Boolean)
      .map((id) => chatIdKey(id)),
  );
  return (bindings.relayChats || []).filter(
    (chat) => chat.status === "on" && isGroupOrChannel(chat) && !skip.has(chatIdKey(chat.id)),
  );
}

async function sendChannelPost(html: string, files: MediaRef[]) {
  const ids = channelCandidates();
  if (!ids.length) throw new Error("channel not found");
  let lastError = "channel not found";
  let posted = false;
  for (const chat_id of ids) {
    try {
      await sendPostToChat(chat_id, html, files);
      posted = true;
      break;
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
    }
  }
  if (!posted) throw new Error(lastError);
}

async function broadcastPublished(html: string, files: MediaRef[]) {
  await sendChannelPost(html, files);
  const approved = relayDestinations();
  for (const chat of approved) {
    try {
      await sendPostToChat(chat.id, html, files);
    } catch (err) {
      if (!isMissingRights(err)) continue;
      await tgSoft("sendMessage", {
        chat_id: chat.id,
        text: "Сообщение для администрации: Вы не выдали достаточно прав для отправки рассылки в Вашем чате.",
      });
    }
  }
}

const publishing = new Set<string>();

async function publishFromMessage(
  text: string,
  callbackId: string,
  extraFiles: MediaRef[] = [],
  relay = false,
  keyHint = "",
): Promise<boolean> {
  const parsed = parseEpbMarker(text);
  const key = keyHint || parsed?.key || "";
  const stored = key ? pendingPosts[key] : undefined;
  if (!parsed && !stored) {
    await tgSoft("answerCallbackQuery", {
      callback_query_id: callbackId,
      text: "Не удалось разобрать заявку",
      show_alert: true,
    });
    return false;
  }
  if (stored?.status === "published") {
    await tgSoft("answerCallbackQuery", {
      callback_query_id: callbackId,
      text: "Уже опубликовано",
    });
    return false;
  }
  if (key && publishing.has(key)) {
    await tgSoft("answerCallbackQuery", { callback_query_id: callbackId, text: "Уже публикуем" });
    return false;
  }
  if (key) publishing.add(key);
  const html = channelHtml(
    pendingAccounts(stored, parsed?.username || stored?.username || "", parsed?.id || stored?.id || ""),
    stored?.summary || stored?.story || parsed?.story || "",
    stored?.amount,
    stored?.currency,
  );
  const files = stored?.files?.length ? stored.files : extraFiles;
  if (!channelCandidates().length) {
    if (key) publishing.delete(key);
    await tgSoft("answerCallbackQuery", {
      callback_query_id: callbackId,
      text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
      show_alert: true,
    });
    return false;
  }
  try {
    if (relay) await broadcastPublished(html, files);
    else await sendChannelPost(html, files);
  } catch {
    if (key) publishing.delete(key);
    await tgSoft("answerCallbackQuery", {
      callback_query_id: callbackId,
      text: relay
        ? "Не удалось опубликовать в канал. Чаты без прав пропускаются."
        : "Не удалось опубликовать. Бот должен быть админом канала.",
      show_alert: true,
    });
    return false;
  }
  if (key && pendingPosts[key]) {
    pendingPosts[key]!.status = "published";
    savePending();
    await notifyApplicant(pendingPosts[key], key, "published");
  }
  if (key) publishing.delete(key);
  await tgSoft("answerCallbackQuery", {
    callback_query_id: callbackId,
    text: relay ? "Опубликовано с рассылкой" : "Опубликовано без рассылки",
  });
  return true;
}

type TgUser = { id: number; username?: string; first_name?: string };

type TgMessage = {
  message_id: number;
  chat: { id: number; type: string; title?: string };
  text?: string;
  caption?: string;
  from?: TgUser;
  photo?: { file_id: string }[];
  video?: { file_id: string };
  document?: { mime_type?: string; file_id?: string };
  forward_from?: TgUser;
  forward_origin?: { sender_user?: TgUser };
  reply_to_message?: TgMessage;
  entities?: { type: string; user?: TgUser }[];
  caption_entities?: { type: string; user?: TgUser }[];
};

type TgUpdate = {
  update_id: number;
  message?: TgMessage;
  my_chat_member?: {
    chat: { id: number; type: string; title?: string };
    from?: TgUser;
    new_chat_member: { status: string };
  };
  callback_query?: {
    id: string;
    data?: string;
    from?: TgUser;
    message?: {
      message_id: number;
      chat: { id: number; type: string };
      text?: string;
      caption?: string;
      photo?: { file_id: string }[];
      video?: { file_id: string };
    };
  };
};

type ApplyStep = "scammer" | "victim" | "summary" | "story" | "amount" | "evidence";

type ApplySession = {
  step: ApplyStep;
  accounts: { username: string; id: string }[];
  victimUsername: string;
  victimId: string;
  victimName: string;
  summary: string;
  story: string;
  amount: string;
  currency: Currency;
  evidence: CopiedMedia[];
  touched?: number;
};

const sessions = new Map<string, ApplySession>();
const channelSetup = new Set<string>();

function gcSessions() {
  const now = Date.now();
  for (const [id, session] of sessions) {
    if (now - (session.touched || 0) > 2 * 60 * 60 * 1000) sessions.delete(id);
  }
  if (sessions.size <= 400) return;
  const oldest = [...sessions.entries()].sort((a, b) => (a[1].touched || 0) - (b[1].touched || 0));
  for (const [id] of oldest.slice(0, sessions.size - 400)) sessions.delete(id);
}

function commandName(text?: string): string | null {
  if (!text?.startsWith("/")) return null;
  const token = text.split(/\s+/)[0] ?? "";
  return token.slice(1).split("@")[0]?.toLowerCase() || null;
}

function applyKeyboard(locale: Locale) {
  const url = publicMiniAppUrl();
  const rows: Record<string, unknown>[][] = [];
  if (url) {
    rows.push([{ text: tb(locale, "openApp"), web_app: { url } }]);
  }
  rows.push([{ text: tb(locale, "channel"), url: CHANNEL_URL }]);
  rows.push([{ text: tb(locale, "ownersBtn"), callback_data: "owners" }]);
  rows.push([{ text: tb(locale, "applyBtn"), callback_data: "apply" }]);
  rows.push([{ text: tb(locale, "langBtn"), callback_data: "lang" }]);
  return { inline_keyboard: rows };
}

function startText(locale: Locale) {
  return tb(locale, "start");
}

function ownersText(locale: Locale) {
  return tb(locale, "owners", { bot: BOT_USERNAME });
}

function ownersKeyboard(locale: Locale) {
  return {
    inline_keyboard: [
      [{ text: tb(locale, "channel"), url: CHANNEL_URL }],
      [{ text: tb(locale, "back"), callback_data: "home" }],
    ],
  };
}

function langKeyboard(withBack = false) {
  const rows: { text: string; callback_data: string }[][] = [
    [
      { text: "Русский", callback_data: "lang:ru" },
      { text: "English", callback_data: "lang:en" },
    ],
  ];
  if (withBack) rows.push([{ text: "Назад / Back", callback_data: "home" }]);
  return { inline_keyboard: rows };
}

async function askLanguage(chatId: number | string, withBack = false) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: "Выберите язык / Choose language",
    reply_markup: langKeyboard(withBack),
  });
}

type CardKind = "welcome" | "submitted" | "published";

function cardPath(kind: CardKind): string | null {
  const name = `${kind}.jpg`;
  const candidates = [
    join(process.cwd(), "public/bot", name),
    join(process.cwd(), ".output/public/bot", name),
    join(process.cwd(), "public", name),
    join("/workspace/public/bot", name),
    join("/workspace/.output/public/bot", name),
  ];
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    candidates.unshift(join(here, "../public/bot", name), join(here, "../../public/bot", name));
  } catch {
    /* ignore */
  }
  return candidates.find((p) => existsSync(p)) || null;
}

function cardBytes(kind: CardKind): Buffer | null {
  if (kind === "welcome") {
    try {
      return Buffer.from(WELCOME_JPEG_BASE64, "base64");
    } catch {
      /* fall through */
    }
  }
  const path = cardPath(kind);
  if (!path) return null;
  try {
    return readFileSync(path);
  } catch {
    return null;
  }
}

async function sendCard(
  chatId: string | number,
  kind: CardKind,
  caption: string,
  extra: Record<string, unknown> = {},
) {
  const cached = bindings.cards?.[kind];
  if (cached) {
    const sent = await tgSoft("sendPhoto", {
      chat_id: chatId,
      photo: cached,
      caption,
      parse_mode: "HTML",
      ...extra,
    });
    if (sent) return;
    if (bindings.cards) delete bindings.cards[kind];
    saveBindings();
  }
  const bytes = cardBytes(kind);
  if (bytes?.length) {
    const form = new FormData();
    form.set("chat_id", String(chatId));
    form.set("caption", caption);
    form.set("parse_mode", "HTML");
    if (extra.reply_markup) form.set("reply_markup", JSON.stringify(extra.reply_markup));
    form.set("photo", new File([new Uint8Array(bytes)], `${kind}.jpg`, { type: "image/jpeg" }));
    try {
      const sent = await tgForm<{ photo?: { file_id: string }[] }>("sendPhoto", form);
      const fileId = sent.photo?.at(-1)?.file_id;
      if (fileId) {
        bindings.cards = { ...bindings.cards, [kind]: fileId };
        saveBindings();
      }
      return;
    } catch {
      /* fall through to text */
    }
  }
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: caption,
    parse_mode: "HTML",
    disable_web_page_preview: true,
    ...extra,
  });
}

async function replyStart(chatId: number, userId?: string | number) {
  const locale = langOf(userId ?? chatId);
  await sendCard(chatId, "welcome", startText(locale), { reply_markup: applyKeyboard(locale) });
}

function newSession(from: TgUser): ApplySession {
  return {
    step: "scammer",
    accounts: [],
    victimUsername: from.username || "",
    victimId: String(from.id),
    victimName: from.first_name || "",
    summary: "",
    story: "",
    amount: "",
    currency: "USD",
    evidence: [],
    touched: Date.now(),
  };
}

function parseAmount(text: string): { amount: string; currency: Currency | null } | null {
  return parseDamageAmount(text);
}

function formatAmount(amount: string) {
  const [intPart, frac] = amount.split(".");
  const grouped = (intPart || "0").replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return frac ? `${grouped}.${frac}` : grouped;
}

function hasMedia(msg: TgMessage) {
  return Boolean(msg.photo?.length || msg.video || msg.document);
}

function formatSessionAccounts(session: ApplySession, userId: string | number) {
  if (!session.accounts.length) return btUser(userId, "emptyAccounts");
  return session.accounts
    .map((a, i) => `${i + 1}. ${a.username ? `@${a.username.replace(/^@/, "")} · ` : ""}${a.id}`)
    .join("\n");
}

async function askScammer(chatId: number, session?: ApplySession) {
  const listed = session ? formatSessionAccounts(session, chatId) : "";
  const rows: { text: string; callback_data: string }[][] = [];
  if (session?.accounts.length) {
    rows.push([
      { text: btUser(chatId, "moreAccount"), callback_data: "apply:more" },
      { text: btUser(chatId, "next"), callback_data: "apply:next" },
    ]);
  }
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: session?.accounts.length
      ? btUser(chatId, "accountsListed", { list: listed })
      : btUser(chatId, "stepAccounts"),
    reply_markup: rows.length ? { inline_keyboard: rows } : undefined,
  });
}

async function askVictim(chatId: number, session: ApplySession) {
  const current = session.victimUsername
    ? `@${session.victimUsername} · id ${session.victimId}`
    : `id ${session.victimId} (username нет)`;
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: `Шаг 2/5. Ваш контакт, чтобы арбитры могли связаться.\nСейчас: ${current}\nНапишите другой @username или нажмите «Оставить».`,
    reply_markup: {
      inline_keyboard: [[{ text: "Оставить", callback_data: "apply:keep" }]],
    },
  });
}

async function askSummary(chatId: number) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "stepSummary"),
  });
}

async function askStory(chatId: number) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "stepStory"),
  });
}

async function askAmount(chatId: number) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "stepAmount"),
  });
}

async function askCurrency(chatId: number, amount: string) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "pickCurrency", { amount: formatAmount(amount) }),
    reply_markup: {
      inline_keyboard: [
        [
          { text: "USD", callback_data: "apply:cur:USD" },
          { text: "EUR", callback_data: "apply:cur:EUR" },
        ],
      ],
    },
  });
}

async function askEvidence(chatId: number) {
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "stepEvidence"),
    reply_markup: {
      inline_keyboard: [
        [
          { text: btUser(chatId, "done"), callback_data: "apply:done" },
          { text: btUser(chatId, "skipFiles"), callback_data: "apply:skip" },
        ],
      ],
    },
  });
}

async function askConfirm(chatId: number, session: ApplySession) {
  const victim = session.victimUsername ? `@${session.victimUsername}` : session.victimName || session.victimId;
  const files = session.evidence.length
    ? btUser(chatId, "filesCount", { n: session.evidence.length })
    : btUser(chatId, "noFiles");
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(chatId, "confirm", {
      accounts: formatSessionAccounts(session, chatId),
      victim,
      id: session.victimId,
      amount: session.amount,
      currency: session.currency,
      files,
      summary: session.summary,
      story: session.story,
    }),
    reply_markup: {
      inline_keyboard: [
        [
          { text: btUser(chatId, "sendReview"), callback_data: "apply:send" },
          { text: btUser(chatId, "cancelBtn"), callback_data: "apply:cancel" },
        ],
      ],
    },
  });
}

async function startApply(chatId: number, from: TgUser) {
  const session = newSession(from);
  sessions.set(String(from.id), session);
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(from.id, "applyStart"),
  });
  await askScammer(chatId, session);
}

async function cancelApply(chatId: number, userId: string, notice?: string) {
  sessions.delete(userId);
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: notice || btUser(userId, "cancel"),
    reply_markup: applyKeyboard(langOf(userId)),
  });
}

async function copyEvidenceToArbiters(items: ApplySession["evidence"]) {
  const chatId = bindings.arbiterChatId;
  if (!chatId || !items.length) return;
  for (const item of items) {
    await tgSoft("copyMessage", {
      chat_id: chatId,
      from_chat_id: item.chatId,
      message_id: item.messageId,
    });
  }
}

async function submitSession(chatId: number, userId: string, session: ApplySession) {
  const accounts = session.accounts.filter((a) => a.id);
  if (!accounts.length) {
    await tgSoft("sendMessage", { chat_id: chatId, text: btUser(userId, "needAccountSubmit") });
    session.step = "scammer";
    sessions.set(userId, session);
    await askScammer(chatId, session);
    return;
  }
  if (!session.summary.trim() || session.summary.trim().length < 10) {
    await tgSoft("sendMessage", { chat_id: chatId, text: btUser(userId, "needSummary") });
    session.step = "summary";
    sessions.set(userId, session);
    await askSummary(chatId);
    return;
  }
  if (!session.story.trim() || session.story.trim().length < 20) {
    await tgSoft("sendMessage", { chat_id: chatId, text: btUser(userId, "needStory") });
    session.step = "story";
    sessions.set(userId, session);
    await askStory(chatId);
    return;
  }
  const first = accounts[0]!;
  const app: Application = {
    id: `EPB-${Date.now().toString(36).toUpperCase()}`,
    createdAt: Date.now(),
    status: "pending",
    victim: {
      username: session.victimUsername,
      telegramId: session.victimId,
      firstName: session.victimName,
    },
    scammer: {
      username: first.username,
      telegramId: first.id,
    },
    scammers: accounts.map((a) => ({ username: a.username, telegramId: a.id })),
    summary: session.summary,
    story: session.story,
    damageAmount: session.amount,
    damageCurrency: session.currency,
    evidence: [],
  };
  const result = await sendApplicationToArbiters(app, session.evidence);
  if (!result.ok) {
    await tgSoft("sendMessage", {
      chat_id: chatId,
      text: result.error || btUser(userId, "sendFail"),
    });
    return;
  }
  sessions.delete(userId);
  await tgSoft("sendMessage", {
    chat_id: chatId,
    text: btUser(userId, "sent", { id: app.id }),
  });
}

function forwardedUser(msg: TgMessage): TgUser | undefined {
  return msg.forward_from || msg.forward_origin?.sender_user;
}

async function handleApplyMessage(msg: TgMessage, session: ApplySession) {
  const chatId = msg.chat.id;
  const userId = String(msg.from?.id || chatId);

  if (session.step === "scammer") {
    let username = "";
    let id = "";
    const fwd = forwardedUser(msg);
    const mention = msg.entities?.find((e) => e.type === "text_mention" && e.user?.id)?.user;
    if (fwd) {
      rememberUser(fwd);
      id = String(fwd.id);
      username = fwd.username || "";
    } else if (mention) {
      rememberUser(mention);
      id = String(mention.id);
      username = mention.username || "";
    } else {
      const raw = (msg.text || "").trim();
      if (!raw) {
        await askScammer(chatId, session);
        return;
      }
      const low = raw.toLowerCase();
      if (low === "далее" || low === "готово" || low === "next") {
        if (!session.accounts.length) {
          await tgSoft("sendMessage", {
            chat_id: chatId,
            text: btUser(userId, "addAccountLeast"),
          });
          return;
        }
        session.step = "summary";
        sessions.set(userId, session);
        await askSummary(chatId);
        return;
      }
      const resolved = await resolveHandleServer(raw);
      if (!resolved) {
        await tgSoft("sendMessage", {
          chat_id: chatId,
          text: btUser(userId, "parseAccount"),
        });
        return;
      }
      username = resolved.username;
      id = resolved.id;
      if (!id) {
        await tgSoft("sendMessage", {
          chat_id: chatId,
          text: btUser(userId, "idNoNumeric", { user: resolved.username }),
        });
        return;
      }
    }
    if (!id) {
      await askScammer(chatId, session);
      return;
    }
    if (!session.accounts.some((a) => a.id === id)) {
      session.accounts.push({ username, id });
    }
    sessions.set(userId, session);
    await askScammer(chatId, session);
    return;
  }

  if (session.step === "victim") {
    session.step = "summary";
    sessions.set(userId, session);
    await askSummary(chatId);
    return;
  }

  if (session.step === "summary") {
    const summary = (msg.text || msg.caption || "").trim();
    if (summary.length < 10) {
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "needSummary"),
      });
      return;
    }
    if (summary.length > 800) {
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "summaryLong"),
      });
      return;
    }
    session.summary = summary;
    session.step = "story";
    sessions.set(userId, session);
    await askStory(chatId);
    return;
  }

  if (session.step === "story") {
    const story = (msg.text || msg.caption || "").trim();
    if (story.length < 20) {
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "needStory"),
      });
      return;
    }
    if (story.length > 5000) {
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "storyLong"),
      });
      return;
    }
    session.story = story;
    session.step = "amount";
    await askAmount(chatId);
    return;
  }

  if (session.step === "amount") {
    const parsed = parseAmount(msg.text || "");
    if (!parsed) {
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "needAmount"),
      });
      return;
    }
    session.amount = parsed.amount;
    if (!parsed.currency) {
      sessions.set(userId, session);
      await askCurrency(chatId, parsed.amount);
      return;
    }
    session.currency = parsed.currency;
    session.step = "evidence";
    await askEvidence(chatId);
    return;
  }

  if (session.step === "evidence") {
    if (hasMedia(msg)) {
      const fileId = msg.video?.file_id || msg.photo?.at(-1)?.file_id || msg.document?.file_id;
      const kind = msg.video ? "video" : msg.photo?.length ? "photo" : "document";
      session.evidence.push({
        chatId: msg.chat.id,
        messageId: msg.message_id,
        fileId,
        kind,
      });
      if (session.evidence.length >= 30) {
        await askConfirm(chatId, session);
        return;
      }
      await tgSoft("sendMessage", {
        chat_id: chatId,
        text: btUser(userId, "fileAccepted", { n: session.evidence.length }),
        reply_markup: {
          inline_keyboard: [[{ text: btUser(userId, "done"), callback_data: "apply:done" }]],
        },
      });
      return;
    }
    const text = (msg.text || "").trim().toLowerCase();
    if (text === "готово" || text === "done") {
      await askConfirm(chatId, session);
      return;
    }
    await tgSoft("sendMessage", {
      chat_id: chatId,
      text: btUser(userId, "sendMedia"),
    });
  }

  sessions.set(userId, session);
}

async function handleApplyCallback(
  cb: NonNullable<TgUpdate["callback_query"]>,
  session: ApplySession | undefined,
) {
  const chatId = cb.message?.chat.id;
  const userId = String(cb.from?.id || "");
  if (!chatId) return;

  if (cb.data === "apply:cancel") {
    await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
    await cancelApply(chatId, userId);
    return;
  }

  if (!session) {
    if (cb.data === "apply") {
      if (!cb.from) return;
      if (cb.message?.chat.type && cb.message.chat.type !== "private") {
        await tgSoft("answerCallbackQuery", {
          callback_query_id: cb.id,
          text: btUser(cb.from?.id, "applyInDm"),
          show_alert: true,
        });
        await tgSoft("sendMessage", {
          chat_id: chatId,
          text: btUser(cb.from?.id, "applyOpen", { bot: BOT_USERNAME }),
        });
        return;
      }
      await tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
      await startApply(chatId, cb.from);
      return;
    }
    await tgSoft("answerCallbackQuery", {
      callback_query_id: cb.id,
      text: btUser(cb.from?.id, "restart"),
    });
    return;
  }

  void tgSoft("answerCallbackQuery", { callback_query_id: cb.id });

  if (cb.data === "apply:cur:USD" || cb.data === "apply:cur:EUR") {
    if (!session.amount) {
      await askAmount(chatId);
      return;
    }
    session.currency = cb.data.endsWith("USD") ? "USD" : "EUR";
    session.step = "evidence";
    sessions.set(userId, session);
    await askEvidence(chatId);
    return;
  }
  if (cb.data === "apply:keep") {
    session.step = "summary";
    sessions.set(userId, session);
    await askSummary(chatId);
    return;
  }
  if (cb.data === "apply:next") {
    if (!session.accounts.length) {
      await tgSoft("sendMessage", { chat_id: chatId, text: btUser(userId, "addAccountFirst") });
      return;
    }
    session.step = "summary";
    sessions.set(userId, session);
    await askSummary(chatId);
    return;
  }
  if (cb.data === "apply:more") {
    await tgSoft("sendMessage", {
      chat_id: chatId,
      text: btUser(userId, "nextAccount"),
    });
    return;
  }
  if (cb.data === "apply:done" || cb.data === "apply:skip") {
    await askConfirm(chatId, session);
    return;
  }
  if (cb.data === "apply:send") {
    await submitSession(chatId, userId, session);
  }
}

function findRelay(id: string | number) {
  return (bindings.relayChats || []).find((c) => sameChat(c.id, id));
}

function upsertRelay(
  chat: { id: number | string; type?: string; title?: string },
  status: "pending" | "on" | "off",
) {
  const list = [...(bindings.relayChats || [])];
  const idx = list.findIndex((c) => sameChat(c.id, chat.id));
  const next = {
    id: String(chat.id),
    title: chat.title || list[idx]?.title,
    type: chat.type || list[idx]?.type,
    status,
  };
  if (idx >= 0) list[idx] = { ...list[idx], ...next };
  else list.push(next);
  bindings.relayChats = list.slice(-250);
  saveBindings();
}

function dropRelay(id: string | number) {
  bindings.relayChats = (bindings.relayChats || []).filter((c) => !sameChat(c.id, id));
  saveBindings();
}

function chatKindLabel(type?: string) {
  if (type === "channel") return "канал";
  if (type === "supergroup") return "супергруппа";
  if (type === "group") return "группа";
  return type || "чат";
}

async function greetRelayChat(chat: { id: number; type: string; title?: string }) {
  await tgSoft("sendMessage", {
    chat_id: chat.id,
    text: [
      `<b>${CHANNEL_NAME}</b>`,
      "",
      "Выдайте боту права администратора: отправка сообщений и медиа. Без этого рассылка не заработает.",
    ].join("\n"),
    parse_mode: "HTML",
    disable_web_page_preview: true,
  });
}

async function notifyArbitersAboutRelay(
  chat: { id: number; type: string; title?: string },
  addedBy?: { id: number; username?: string; first_name?: string },
) {
  const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
  const who = addedBy?.username
    ? `@${addedBy.username}`
    : addedBy?.first_name
      ? `${addedBy.first_name} (<code>${addedBy.id}</code>)`
      : "неизвестно";
  await tgSoft("sendMessage", {
    chat_id: arbiter,
    text: [
      "<b>Бот добавлен в чужой чат</b>",
      "",
      `Название: ${escapeHtml(chat.title || "без названия")}`,
      `Тип: ${chatKindLabel(chat.type)}`,
      `ID: <code>${chat.id}</code>`,
      `Кто добавил: ${who}`,
      "",
      "Подключить рассылку одобренных постов в этот чат?",
    ].join("\n"),
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Принять", callback_data: `rel:y:${chat.id}` },
          { text: "Отклонить", callback_data: `rel:n:${chat.id}` },
        ],
      ],
    },
  });
}

async function replaceReplyMarkup(
  msg: {
    chat: { id: number };
    message_id: number;
    text?: string;
    caption?: string;
    photo?: unknown;
    video?: unknown;
  },
  markup: unknown,
  nextText?: string,
) {
  const text = nextText ?? msg.caption ?? msg.text ?? "";
  const isMedia = Boolean(msg.caption || msg.photo || msg.video);
  if (nextText) {
    if (isMedia) {
      const edited = await tgSoft("editMessageCaption", {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        caption: text.slice(0, 1024),
        parse_mode: "HTML",
        reply_markup: markup,
      });
      if (edited) return true;
    } else {
      const edited = await tgSoft("editMessageText", {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: markup,
      });
      if (edited) return true;
    }
  }
  const markupOnly = await tgSoft("editMessageReplyMarkup", {
    chat_id: msg.chat.id,
    message_id: msg.message_id,
    reply_markup: markup,
  });
  return Boolean(markupOnly);
}

function callbackKey(data: string) {
  const i = data.indexOf(":");
  return i >= 0 ? data.slice(i + 1) : "";
}

async function handleRelayDecision(cb: NonNullable<TgUpdate["callback_query"]>, allow: boolean) {
  const raw = (cb.data || "").replace(/^rel:[yn]:/, "");
  if (!raw) return;
  const chatId = raw;
  const relay = findRelay(chatId);
  const title = relay?.title || chatId;
  if (allow) {
    upsertRelay({ id: chatId, title: relay?.title, type: relay?.type }, "on");
    const wrote = await tgSoft("sendMessage", {
      chat_id: chatId,
      text: `Рассылка ${CHANNEL_NAME} включена. Сюда будут приходить одобренные посты.`,
    });
    await tgSoft("answerCallbackQuery", {
      callback_query_id: cb.id,
      text: wrote ? "Рассылка включена" : "Включили, но бот не смог написать в чат. Проверьте права.",
      show_alert: !wrote,
    });
  } else {
    upsertRelay({ id: chatId, title: relay?.title, type: relay?.type }, "off");
    await tgSoft("sendMessage", {
      chat_id: chatId,
      text: "Арбитры не подключили рассылку в этот чат. Одобренные посты сюда не приходят.",
    });
    await tgSoft("answerCallbackQuery", { callback_query_id: cb.id, text: "Отклонено" });
  }
  const next = allow
    ? `Принято: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка включена.`
    : `Отклонено: ${escapeHtml(title)}\nID: <code>${escapeHtml(chatId)}</code>\nРассылка выключена.`;
  if (cb.message) {
    await tgSoft("editMessageText", {
      chat_id: cb.message.chat.id,
      message_id: cb.message.message_id,
      text: next,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [] },
    });
  }
}

async function bindChat(
  chat: { id: number; type: string; title?: string },
  from?: { id: number; username?: string; first_name?: string },
) {
  if (!isGroupOrChannel(chat)) return;
  const id = String(chat.id);
  if (isOfficialArbiterChat(id)) {
    bindings.arbiterChatId = id;
    saveBindings();
    await tgSoft("sendMessage", {
      chat_id: id,
      text: [
        `${CHANNEL_NAME}: чат арбитров подтверждён.`,
        `ID: <code>${id}</code>`,
        "",
        "Сюда будут приходить заявки с кнопками Опубликовать / Отклонить.",
        "",
        "Канал для постов сейчас: <code>" + (bindings.channelId || PINNED_CHANNEL) + "</code>",
        "Сменить: /channel -100…",
      ].join("\n"),
      parse_mode: "HTML",
    });
    return;
  }
  if (isOfficialChannel(id)) {
    bindings.channelId = id;
    saveBindings();
    const arbiter = arbiterCandidates()[0] || REQUESTED_ARBITER;
    await tgSoft("sendMessage", {
      chat_id: arbiter,
      text: `Канал подключён: ${chat.title ?? id}\nID: <code>${id}</code>`,
      parse_mode: "HTML",
    });
    return;
  }
  const existing = findRelay(id);
  if (existing?.status === "on") {
    await tgSoft("sendMessage", {
      chat_id: chat.id,
      text: "Рассылка уже включена. Одобренные посты будут приходить сюда.",
    });
    return;
  }
  if (existing?.status === "pending") return;
  if (tooMany("relay:global", 8, 60_000)) return;
  if (from?.id && tooMany(`relay:${from.id}`, 3, 60 * 60 * 1000)) return;
  upsertRelay(chat, "pending");
  await greetRelayChat(chat);
  await notifyArbitersAboutRelay(chat, from);
}

async function parseChannelRef(raw: string): Promise<string | null> {
  const t = raw.trim().split(/\s+/)[0] || "";
  if (!t) return null;
  if (t.startsWith("@")) return t;
  const fromUrl = t.match(/(?:t\.me|telegram\.me)\/([A-Za-z][A-Za-z0-9_]{3,})/i);
  if (fromUrl?.[1] && !fromUrl[1].startsWith("+")) return `@${fromUrl[1]}`;
  const num = t.replace(/[^\d-]/g, "");
  if (/^-100\d{6,}$/.test(num)) return num;
  if (/^100\d{6,}$/.test(num)) return `-${num}`;
  if (/^\d{6,}$/.test(num)) return `-100${num}`;
  return t;
}

async function applyPublishChannel(arbiterChatId: number | string, raw: string) {
  const ref = await parseChannelRef(raw);
  if (!ref) {
    await tgSoft("sendMessage", {
      chat_id: arbiterChatId,
      text: "Пришлите ID канала, например <code>-1003958415589</code>, или @username.",
      parse_mode: "HTML",
    });
    return;
  }
  const chat = await chatReachable(ref);
  if (!chat) {
    await tgSoft("sendMessage", {
      chat_id: arbiterChatId,
      text: "Не вижу этот канал. Добавьте бота админом и пришлите ID ещё раз.",
    });
    return;
  }
  if (chat.type !== "channel" && chat.type !== "supergroup") {
    await tgSoft("sendMessage", {
      chat_id: arbiterChatId,
      text: "Это не канал. Нужен ID канала, куда постить одобренные заявки.",
    });
    return;
  }
  bindings.channelId = String(chat.id);
  saveBindings();
  channelSetup.delete(String(arbiterChatId));
  await tgSoft("sendMessage", {
    chat_id: arbiterChatId,
    text: [
      "Канал для постов обновлён.",
      `${chat.title || "Канал"}`,
      `ID: <code>${chat.id}</code>`,
    ].join("\n"),
    parse_mode: "HTML",
  });
}

async function askPublishChannel(arbiterChatId: number | string) {
  channelSetup.add(String(arbiterChatId));
  await tgSoft("sendMessage", {
    chat_id: arbiterChatId,
    text: [
      `Сейчас посты идут в <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
      "",
      "Пришлите ID канала (например <code>-1003958415589</code>) или @username.",
      "Бот должен быть админом этого канала.",
      "",
      "Или сразу: /channel -100…",
    ].join("\n"),
    parse_mode: "HTML",
  });
}

export async function handleUpdate(update: TgUpdate) {
  try {
    await handleTelegramUpdate(update);
  } catch (err) {
    if (!isDisconnectError(err)) console.error("[epb] update", err);
  }
}

async function handleTelegramUpdate(update: TgUpdate) {
  void ensureBotProfile();
  rememberUser(update.message?.from);
  rememberUser(update.message?.forward_from);
  rememberUser(update.message?.forward_origin?.sender_user);
  rememberUser(update.message?.reply_to_message?.from);
  rememberUser(update.message?.reply_to_message?.forward_from);
  rememberUser(update.callback_query?.from);
  for (const ent of [
    ...(update.message?.entities || []),
    ...(update.message?.caption_entities || []),
    ...(update.message?.reply_to_message?.entities || []),
  ]) {
    rememberUser(ent.user);
  }

  const floodId = String(
    update.message?.from?.id || update.callback_query?.from?.id || update.my_chat_member?.from?.id || "",
  );
  const liveSession = sessions.get(floodId);
  const incoming = update.message;
  const evidenceBurst =
    liveSession?.step === "evidence" &&
    Boolean(incoming?.photo?.length || incoming?.video || incoming?.document);
  if (tooMany("upd:global", 400, 60_000)) return;
  if (floodId && !evidenceBurst && tooMany(`flood:${floodId}`, 80, 60_000)) {
    return;
  }
  if (liveSession) liveSession.touched = Date.now();
  gcSessions();

  const member = update.my_chat_member;
  if (member) {
    if (!isGroupOrChannel(member.chat)) return;
    const status = member.new_chat_member.status;
    if (status === "left" || status === "kicked") {
      dropRelay(member.chat.id);
      return;
    }
    if (status === "member" || status === "administrator" || status === "creator") {
      await bindChat(member.chat, member.from);
    }
    return;
  }

  const cb = update.callback_query;
  if (cb?.message && cb.data) {
    if (cb.data === "owners") {
      void tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
      const locale = langOf(cb.from?.id);
      await tgSoft("sendMessage", {
        chat_id: cb.message.chat.id,
        text: ownersText(locale),
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: ownersKeyboard(locale),
      });
      return;
    }
    if (cb.data === "home") {
      void tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
      await replyStart(cb.message.chat.id, cb.from?.id);
      return;
    }
    if (cb.data === "lang") {
      void tgSoft("answerCallbackQuery", { callback_query_id: cb.id });
      await askLanguage(cb.message.chat.id, true);
      return;
    }
    if (cb.data === "lang:ru" || cb.data === "lang:en") {
      const locale: Locale = cb.data.endsWith("en") ? "en" : "ru";
      if (cb.from?.id) setLang(cb.from.id, locale);
      void tgSoft("answerCallbackQuery", { callback_query_id: cb.id, text: tb(locale, "langSaved") });
      await replyStart(cb.message.chat.id, cb.from?.id);
      return;
    }
    if (cb.data.startsWith("rel:")) {
      if (!isOfficialArbiterChat(cb.message.chat.id)) {
        await tgSoft("answerCallbackQuery", {
          callback_query_id: cb.id,
          text: "Чат не авторизован",
          show_alert: true,
        });
        return;
      }
      await handleRelayDecision(cb, cb.data.startsWith("rel:y:"));
      return;
    }
    if ((cb.data === "pub" || cb.data.startsWith("pub:") || cb.data.startsWith("puball") || cb.data.startsWith("pubch") || cb.data === "rej" || cb.data.startsWith("rej:")) && !isOfficialArbiterChat(cb.message.chat.id)) {
      await tgSoft("answerCallbackQuery", {
        callback_query_id: cb.id,
        text: "Чат не авторизован",
        show_alert: true,
      });
      return;
    }
    const text = cb.message.caption || cb.message.text || "";
    const isMedia = Boolean(cb.message.caption || cb.message.photo || cb.message.video);
    if (alreadyHandled(text)) {
      await tgSoft("answerCallbackQuery", {
        callback_query_id: cb.id,
        text: "Заявка уже обработана",
      });
      return;
    }
    if (cb.data === "pub" || (cb.data.startsWith("pub:") && !cb.data.startsWith("puball") && !cb.data.startsWith("pubch"))) {
      const key = parseAppKey(text, cb.data);
      const markup = publishChoiceKeyboard(key);
      const ok = await replaceReplyMarkup(cb.message, markup);
      if (!ok) {
        await tgSoft("sendMessage", {
          chat_id: cb.message.chat.id,
          text: "Как опубликовать эту заявку?",
          reply_to_message_id: cb.message.message_id,
          reply_markup: markup,
        });
      }
      await tgSoft("answerCallbackQuery", { callback_query_id: cb.id, text: "Выберите тип публикации" });
      return;
    }
    if (cb.data.startsWith("puball") || cb.data.startsWith("pubch")) {
      const extraFiles: MediaRef[] = [];
      const lastPhoto = cb.message.photo?.at(-1)?.file_id;
      if (lastPhoto) extraFiles.push({ type: "photo", file_id: lastPhoto });
      if (cb.message.video?.file_id) extraFiles.push({ type: "video", file_id: cb.message.video.file_id });
      const relay = cb.data.startsWith("puball");
      const key = parseAppKey(text, cb.data);
      const lookup = key && pendingPosts[key]
        ? `#epb u=${pendingPosts[key]!.username || ""} id=${pendingPosts[key]!.id || "0"} k=${key}`
        : text;
      const published = await publishFromMessage(lookup, cb.id, extraFiles, relay, key);
      if (!published) return;
      const next = `${stripServiceMarker(text || "Заявка")}\n\nСтатус: ${relay ? "опубликовано с рассылкой" : "опубликовано без рассылки"}`;
      const cleared = { inline_keyboard: [] };
      const edited = await replaceReplyMarkup(cb.message, cleared, next);
      if (!edited) {
        await tgSoft("editMessageReplyMarkup", {
          chat_id: cb.message.chat.id,
          message_id: cb.message.message_id,
          reply_markup: cleared,
        });
      }
      return;
    }
    if (cb.data === "rej" || cb.data.startsWith("rej:")) {
      const key = parseAppKey(text, cb.data);
      if (key && pendingPosts[key]) {
        pendingPosts[key]!.status = "rejected";
        savePending();
        await notifyApplicant(pendingPosts[key], key, "rejected");
      }
      await tgSoft("answerCallbackQuery", { callback_query_id: cb.id, text: "Отклонено" });
      const next = `${stripServiceMarker(text)}\n\nСтатус: отклонено`;
      await replaceReplyMarkup(cb.message, { inline_keyboard: [] }, next);
      return;
    }
    const userId = String(cb.from?.id || "");
    await handleApplyCallback(cb, sessions.get(userId));
    return;
  }

  const msg = update.message;
  if (!msg) return;

  if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
    if (!isOfficialArbiterChat(msg.chat.id)) return;
  }
  if (msg.chat.type === "channel" && bindings.channelId && !isOfficialChannel(msg.chat.id)) {
    return;
  }

  const cmd = commandName(msg.text);
  const userId = String(msg.from?.id || msg.chat.id);

  if (cmd === "start" || cmd === "app") {
    const fromId = msg.from?.id;
    if (fromId && !hasLang(fromId)) {
      await askLanguage(msg.chat.id);
      return;
    }
    await replyStart(msg.chat.id, fromId);
    return;
  }
  if (cmd === "lang") {
    await askLanguage(msg.chat.id, hasLang(msg.from?.id));
    return;
  }
  if (cmd === "channel") {
    if (!isOfficialArbiterChat(msg.chat.id)) return;
    const arg = (msg.text || "").replace(/^\/channel(?:@\w+)?/i, "").trim();
    if (arg) await applyPublishChannel(msg.chat.id, arg);
    else await askPublishChannel(msg.chat.id);
    return;
  }
  if (cmd === "cancel") {
    await cancelApply(msg.chat.id, userId);
    return;
  }
  if (cmd === "apply") {
    if (msg.chat.type !== "private") {
      await tgSoft("sendMessage", {
        chat_id: msg.chat.id,
        text: btUser(msg.from?.id, "applyInGroup", { bot: BOT_USERNAME }),
      });
      return;
    }
    if (!msg.from) return;
    await startApply(msg.chat.id, msg.from);
    return;
  }
  if (cmd === "id" || cmd === "bind") {
    if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
      if (!isOfficialArbiterChat(msg.chat.id)) return;
      bindings.arbiterChatId = String(msg.chat.id);
      saveBindings();
      await tgSoft("sendMessage", {
        chat_id: msg.chat.id,
        text: [
          `Чат арбитров подтверждён.`,
          `ID: <code>${msg.chat.id}</code>`,
          "",
          "Заявки будут приходить только сюда.",
          "",
          `Канал для постов: <code>${bindings.channelId || PINNED_CHANNEL}</code>`,
          "Сменить: /channel -100…",
        ].join("\n"),
        parse_mode: "HTML",
      });
      return;
    }
    if (msg.chat.type === "channel") {
      if (bindings.channelId && !isOfficialChannel(msg.chat.id)) return;
      bindings.channelId = String(msg.chat.id);
      saveBindings();
    }
    await tgSoft("sendMessage", {
      chat_id: msg.chat.id,
      text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
      parse_mode: "HTML",
    });
    return;
  }

  if (isOfficialArbiterChat(msg.chat.id) && channelSetup.has(String(msg.chat.id)) && msg.text && !cmd) {
    await applyPublishChannel(msg.chat.id, msg.text);
    return;
  }

  if (msg.chat.type !== "private") return;
  const session = sessions.get(userId);
  if (session) await handleApplyMessage(msg, session);
}

export async function registerMiniAppUrl(url: string) {
  const clean = url.replace(/\/$/, "");
  if (!clean.startsWith("https://") || isGatedHost(clean)) {
    return { ok: false as const, reason: "gated" };
  }
  bindings.miniAppUrl = clean;
  saveBindings();
  lastMenuUrl = "";
  await applyMenuButton();
  await tgSoft("setWebhook", {
    url: `${clean}/api/telegram/webhook`,
    secret_token: webhookSecret(),
    allowed_updates: ["message", "callback_query", "my_chat_member"],
    drop_pending_updates: false,
  });
  return { ok: true as const, url: clean };
}

let webhookArmed = false;

export async function configureFromOrigin(_origin: string) {
  const site = publicSiteUrl();
  if (!site) {
    return { configured: false as const, reason: "need_https" };
  }
  if (!webhookArmed) {
    webhookArmed = true;
    void ensureProductionWebhook();
  }
  return { configured: true as const, url: site };
}

export async function deleteWebhook() {
  await tgSoft("deleteWebhook", { drop_pending_updates: false });
}
