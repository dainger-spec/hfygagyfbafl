import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.functions-BRSKdrdY.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus_createServerFn_handler = createServerRpc({
	id: "35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b",
	name: "getTelegramStatus",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => getTelegramStatus.__executeServer(opts));
var getTelegramStatus = createServerFn({ method: "GET" }).handler(getTelegramStatus_createServerFn_handler, async () => {
	const { getBotStatus } = await import("./telegram-bot.server-dxom9DlT.mjs").then((n) => n.r);
	return getBotStatus();
});
var resolveTelegramHandle_createServerFn_handler = createServerRpc({
	id: "ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093",
	name: "resolveTelegramHandle",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => resolveTelegramHandle.__executeServer(opts));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({ input: string().min(1).max(200) })).handler(resolveTelegramHandle_createServerFn_handler, async ({ data }) => {
	const { resolveHandleServer } = await import("./telegram-bot.server-dxom9DlT.mjs").then((n) => n.r);
	return resolveHandleServer(data.input);
});
var evidenceSchema = object({
	id: string(),
	kind: _enum(["image", "video"]),
	name: string(),
	size: number(),
	mime: string(),
	dataUrl: string()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: object({
		username: string(),
		telegramId: string(),
		firstName: string().optional()
	}),
	scammer: object({
		username: string(),
		telegramId: string(),
		firstName: string().optional()
	}),
	story: string().min(1),
	damageAmount: string(),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(8)
});
var submitToTelegram_createServerFn_handler = createServerRpc({
	id: "60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359",
	name: "submitToTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => submitToTelegram.__executeServer(opts));
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(submitToTelegram_createServerFn_handler, async ({ data }) => {
	const { sendApplicationToArbiters } = await import("./telegram-bot.server-dxom9DlT.mjs").then((n) => n.r);
	return sendApplicationToArbiters(data);
});
var configureTelegram_createServerFn_handler = createServerRpc({
	id: "308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e",
	name: "configureTelegram",
	filename: "src/lib/telegram-bot.functions.ts"
}, (opts) => configureTelegram.__executeServer(opts));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(configureTelegram_createServerFn_handler, async ({ data }) => {
	const { configureFromOrigin } = await import("./telegram-bot.server-dxom9DlT.mjs").then((n) => n.r);
	return configureFromOrigin(data.origin);
});
//#endregion
export { configureTelegram_createServerFn_handler, getTelegramStatus_createServerFn_handler, resolveTelegramHandle_createServerFn_handler, submitToTelegram_createServerFn_handler };
