import { i as __toESM } from "../_runtime.mjs";
import { a as CHANNEL_URL, c as resolveTelegramId, i as CHANNEL_NAME, o as bootTelegramWebApp, s as readTelegramWebUser } from "./telegram-bot.server-dxom9DlT.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as object, i as number, n as array, o as string, t as _enum } from "../_libs/zod.mjs";
import { a as LoaderCircle, c as ChevronLeft, i as Megaphone, l as Check, o as ImagePlus, r as Shield, s as Film, t as X } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as isToday, r as format, t as ru } from "../_libs/date-fns.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DJxrvslC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "") {
	const core = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
	return prefix ? `${prefix}-${core}` : core;
}
function r(n) {
	return Math.round(n * 100) / 100;
}
function starPoints(cx, cy, outer = 7.1, inner = 2.85) {
	const pts = [];
	for (let i = 0; i < 10; i++) {
		const rad = i % 2 === 0 ? outer : inner;
		const a = -Math.PI / 2 + i * Math.PI / 5;
		pts.push(`${r(cx + rad * Math.cos(a))},${r(cy + rad * Math.sin(a))}`);
	}
	return pts.join(" ");
}
function EuStarsLogo({ className, size = 64, title }) {
	const stars = Array.from({ length: 12 }, (_, i) => {
		const angle = (i * 30 - 90) * Math.PI / 180;
		const radius = 36;
		return {
			cx: r(50 + radius * Math.cos(angle)),
			cy: r(50 + radius * Math.sin(angle))
		};
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 100 100",
		width: size,
		height: size,
		className: cn("text-gold", className),
		role: title ? "img" : "presentation",
		"aria-hidden": title ? void 0 : true,
		"aria-label": title,
		children: [title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: title }) : null, stars.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
			points: starPoints(s.cx, s.cy),
			fill: "currentColor"
		}, i))]
	});
}
function BrandLockup({ className, size = 40, stacked = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-3", stacked && "flex-col gap-2 text-center", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, { size }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("leading-tight", stacked && "items-center"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm font-extrabold tracking-tight text-fg",
				children: "Europe Private"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm font-extrabold tracking-tight text-gold",
				children: "Blacklist"
			})]
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-semibold tracking-tight transition-[background-color,color,opacity,transform,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-gold text-gold-fg hover:bg-gold/92",
			secondary: "bg-surface-2 text-fg hover:bg-surface shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.14)] hover:bg-surface",
			ghost: "bg-transparent text-fg hover:bg-surface-2",
			danger: "bg-danger text-danger-fg hover:bg-danger/90",
			ok: "bg-ok text-ok-fg hover:bg-ok/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getTelegramStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("35f0fc36d2774c4f378cd803a42ca1bac2a8f10f86e221ba61c097f879a77c1b"));
var resolveTelegramHandle = createServerFn({ method: "POST" }).validator(object({ input: string().min(1).max(200) })).handler(createSsrRpc("ba3bd030aa4e6f716dd9871c947e9b1f6c84244f5314656e3e1da4327b38b093"));
var evidenceSchema = object({
	id: string(),
	kind: _enum(["image", "video"]),
	name: string(),
	size: number(),
	mime: string(),
	dataUrl: string()
});
var applicationSchema = object({
	id: string(),
	createdAt: number(),
	status: _enum([
		"pending",
		"published",
		"rejected"
	]),
	victim: object({
		username: string(),
		telegramId: string(),
		firstName: string().optional()
	}),
	scammer: object({
		username: string(),
		telegramId: string(),
		firstName: string().optional()
	}),
	story: string().min(1),
	damageAmount: string(),
	damageCurrency: _enum([
		"EUR",
		"USD",
		"USDT",
		"RUB"
	]),
	evidence: array(evidenceSchema).max(8)
});
var submitToTelegram = createServerFn({ method: "POST" }).validator(applicationSchema).handler(createSsrRpc("60a79fd2a88ca34be3449cf13c580eb84d9782092e948237418e0f65fcb0c359"));
var configureTelegram = createServerFn({ method: "POST" }).validator(object({ origin: string().max(300) })).handler(createSsrRpc("308f2dce1c73514fa318d5af8b8dce844027128b5305d029570996374a87612e"));
var SEED_STORY = "якобы продает фтп.\nКлянчит деньги по мелочи 50-100 баксов и включает дурачка, не может выдать, надо еще докинуть или просто игнорит.";
var SEED_AT = Date.UTC(2026, 7, 26, 12, 0, 0);
var seedPublished = {
	id: "EPB-SEED",
	createdAt: SEED_AT,
	publishedAt: SEED_AT,
	status: "published",
	victim: {
		username: "archive_epb",
		telegramId: "1000000001",
		firstName: "Archive"
	},
	scammer: {
		username: "LopataBuild",
		telegramId: "5213159067"
	},
	story: SEED_STORY,
	damageAmount: "100",
	damageCurrency: "USD",
	evidence: []
};
var demoIdentity = {
	firstName: "Алексей",
	username: "alex_epb",
	telegramId: "847291003"
};
var useBlacklistStore = create()(persist((set) => ({
	identity: demoIdentity,
	applications: [seedPublished],
	setIdentity: (patch) => set((s) => ({ identity: {
		...s.identity,
		...patch
	} })),
	submitApplication: (app) => set((s) => ({ applications: [app, ...s.applications] })),
	publishApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "published",
		publishedAt: Date.now()
	} : a) })),
	rejectApplication: (id) => set((s) => ({ applications: s.applications.map((a) => a.id === id && a.status === "pending" ? {
		...a,
		status: "rejected",
		rejectedAt: Date.now()
	} : a) })),
	resetDemo: () => set({
		identity: demoIdentity,
		applications: [seedPublished]
	})
}), {
	name: "epb-blacklist",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		identity: s.identity,
		applications: s.applications
	})
}));
function rehydrateBlacklistStore() {
	useBlacklistStore.persist.rehydrate();
}
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const finish = () => setHydrated(true);
		const unsub = useBlacklistStore.persist.onFinishHydration(finish);
		rehydrateBlacklistStore();
		if (useBlacklistStore.persist.hasHydrated()) finish();
		return unsub;
	}, []);
	return hydrated;
}
function BotChat({ onOpenApp, onBack }) {
	const hydrated = useHydrated();
	const identity = useBlacklistStore((s) => s.identity);
	const applications = useBlacklistStore((s) => s.applications);
	const mine = hydrated ? applications.filter((a) => a.id !== "EPB-SEED" && (a.victim.telegramId === identity.telegramId || a.victim.username.toLowerCase() === identity.username.toLowerCase())) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatHeader, {
				title: "EPB Bot",
				subtitle: "бот · Europe Private Blacklist",
				onBack,
				avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, { size: 22 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-3 py-4 md:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramLiveStatus, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BotBubble, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Привет." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2",
						children: [
							"Это бот ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-gold",
								children: CHANNEL_NAME
							}),
							" — закрытого европейского блеклиста мошенников."
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BotBubble, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-fg",
						children: "Как это работает"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-2 list-decimal space-y-1.5 pl-4 text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Открываете приложение и подаёте заявку." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Прикладываете скрины и видео, описываете схему, указываете сумму ущерба и Telegram мошенника. ID подтянется сам. Ваш @username нужен, чтобы арбитры могли связаться." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Заявка уходит в закрытый чат арбитрам." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								"Одобрили — карточка публикуется в",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: CHANNEL_URL,
									target: "_blank",
									rel: "noreferrer",
									className: "font-medium text-gold underline-offset-2 hover:underline",
									children: "канале"
								}),
								". Отклонили — ничего не выходит."
							] })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BotBubble, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Открывайте приложение, если есть подтверждённый кейс." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onOpenApp,
						className: "mt-3 flex w-full items-center gap-3 rounded-xl bg-surface-2 p-3 text-left shadow-[0_0_0_1px_rgba(240,196,48,0.28)] transition-colors duration-150 hover:bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-11 items-center justify-center rounded-lg bg-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, { size: 28 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted",
								children: "Mini App"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-semibold text-fg",
								children: "Europe Private Blacklist"
							})]
						})]
					})] }),
					mine.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BotBubble, { children: [
						app.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Заявка ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: app.id
							}),
							" принята. Арбитры смотрят материалы."
						] }) : null,
						app.status === "published" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Заявка ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: app.id
							}),
							" опубликована в канале",
							" ",
							CHANNEL_NAME,
							"."
						] }) : null,
						app.status === "rejected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Заявка ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-fg",
								children: app.id
							}),
							" отклонена. В канал ничего не ушло."
						] }) : null
					] }, app.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-line bg-bg-elevated p-3 pb-20 md:pb-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: onOpenApp,
					children: "Открыть приложение"
				})
			})
		]
	});
}
function ChatHeader({ title, subtitle, onBack, avatar }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex h-14 shrink-0 items-center gap-2 border-b border-line bg-bg-elevated px-2",
		children: [
			onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-11 items-center justify-center rounded-md text-gold md:hidden",
				onClick: onBack,
				"aria-label": "К чатам",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "hidden size-2 md:block" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-9 items-center justify-center rounded-full bg-surface-2",
				children: avatar
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-semibold leading-tight",
					children: title
				}), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: subtitle
				}) : null]
			})
		]
	});
}
function TelegramLiveStatus() {
	const [status, setStatus] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getTelegramStatus().then(setStatus).catch(() => {
			setStatus({
				bot: "@EuBlack_bot",
				arbiterOk: false,
				channelOk: false
			});
		});
	}, []);
	if (!status) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-3 py-2.5 text-xs leading-relaxed text-muted shadow-[0_0_0_1px_rgba(243,239,228,0.06)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Живой бот: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-semibold text-gold",
				children: status.bot
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1",
				children: [
					"Чат арбитров:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: status.arbiterOk ? "text-ok" : "text-danger",
						children: status.arbiterOk ? "подключён" : "бот не в чате — добавьте @EuBlack_bot админом и напишите /id"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Канал:",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: status.channelOk ? "text-ok" : "text-danger",
					children: status.channelOk ? "подключён" : "добавьте @EuBlack_bot админом канала"
				})
			] })
		]
	});
}
function BotBubble({ children, className }) {
	const [time, setTime] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		setTime(format(/* @__PURE__ */ new Date(), "HH:mm", { locale: ru }));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("max-w-[min(100%,36rem)] rounded-2xl rounded-tl-md bg-surface px-3.5 py-3 text-sm leading-relaxed text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.06)]", className),
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-right text-xs text-subtle",
			children: time || "\xA0"
		})]
	});
}
var MAX_FILES = 8;
var MAX_VIDEO_DATA_URL = 18e5;
var sessionBlobs = /* @__PURE__ */ new Map();
function resizeImage(file, max = 960, quality = .8) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const objectUrl = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.max(1, Math.round(img.width * scale));
			canvas.height = Math.max(1, Math.round(img.height * scale));
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(objectUrl);
				reject(/* @__PURE__ */ new Error("canvas"));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(objectUrl);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(objectUrl);
			reject(/* @__PURE__ */ new Error("image"));
		};
		img.src = objectUrl;
	});
}
function readAsDataUrl(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(file);
	});
}
async function fileToEvidence(file) {
	const isVideo = file.type.startsWith("video/");
	const id = uid("ev");
	if (isVideo) {
		let dataUrl = "";
		if (file.size <= MAX_VIDEO_DATA_URL) dataUrl = await readAsDataUrl(file);
		else sessionBlobs.set(id, URL.createObjectURL(file));
		return {
			id,
			kind: "video",
			name: file.name,
			size: file.size,
			mime: file.type || "video/mp4",
			dataUrl
		};
	}
	const dataUrl = await resizeImage(file);
	return {
		id,
		kind: "image",
		name: file.name,
		size: file.size,
		mime: "image/jpeg",
		dataUrl
	};
}
function canAddEvidence(current, incoming) {
	return current + incoming <= MAX_FILES;
}
function evidenceSrc(item) {
	return item.dataUrl || sessionBlobs.get(item.id) || "";
}
function EvidencePicker({ files, onChange }) {
	const inputRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	async function addFiles(list) {
		const incoming = Array.from(list).filter((f) => f.type.startsWith("image/") || f.type.startsWith("video/"));
		if (!incoming.length) return;
		if (!canAddEvidence(files.length, incoming.length)) {
			setError(`Максимум 8 файлов`);
			return;
		}
		setError("");
		setBusy(true);
		try {
			const next = [];
			for (const file of incoming) next.push(await fileToEvidence(file));
			onChange([...files, ...next]);
		} catch {
			setError("Не удалось прочитать файл");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				accept: "image/*,video/*",
				multiple: true,
				className: "sr-only",
				onChange: (e) => {
					if (e.target.files) addFiles(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => inputRef.current?.click(),
				onDragOver: (e) => {
					e.preventDefault();
				},
				onDrop: (e) => {
					e.preventDefault();
					if (e.dataTransfer.files) addFiles(e.dataTransfer.files);
				},
				className: cn("flex min-h-28 w-full flex-col items-center justify-center gap-2 rounded-xl bg-surface px-4 py-6 text-center shadow-[0_0_0_1px_rgba(243,239,228,0.10)] transition-[background-color,box-shadow] duration-150", "hover:bg-surface-2"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-6 text-gold" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium text-fg",
						children: busy ? "Обрабатываем файлы…" : "Скрины и видео"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted",
						children: [
							"До ",
							8,
							" файлов. Можно перетащить сюда."
						]
					})
				]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			files.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-3 gap-2",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, { item: file }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "secondary",
						size: "icon",
						className: "absolute top-1 right-1 size-8 rounded-full",
						onClick: () => onChange(files.filter((f) => f.id !== file.id)),
						"aria-label": "Удалить файл",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, file.id))
			}) : null
		]
	});
}
function EvidenceThumb({ item }) {
	const src = evidenceSrc(item);
	if (item.kind === "video") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative aspect-square overflow-hidden rounded-lg bg-surface-2",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			className: "size-full object-cover img-outline",
			muted: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex size-full items-center justify-center text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute bottom-1 left-1 rounded-sm bg-bg/80 px-1.5 py-0.5 text-xs font-medium tracking-wide text-fg",
			children: "VIDEO"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: item.name,
		className: "aspect-square w-full rounded-lg object-cover img-outline"
	});
}
function EvidenceGallery({ items, onOpen }) {
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "grid grid-cols-3 gap-1.5",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "block w-full overflow-hidden rounded-md",
			onClick: () => onOpen?.(item),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceThumb, { item })
		}) }, item.id))
	});
}
function PostBody({ app }) {
	const username = app.scammer.username.replace(/^@/, "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "whitespace-pre-wrap text-base leading-relaxed text-fg",
		children: [
			username ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-semibold text-gold",
				children: ["@", username]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["Id: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums",
				children: app.scammer.telegramId
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-pretty",
				children: app.story.trim()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4",
				children: [
					"Subscribe:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: CHANNEL_URL,
						target: "_blank",
						rel: "noreferrer",
						className: "font-semibold text-gold underline-offset-4 hover:underline",
						children: CHANNEL_NAME
					})
				]
			})
		]
	});
}
function ArbiterChat({ onBack }) {
	const hydrated = useHydrated();
	const applications = useBlacklistStore((s) => s.applications);
	const publishApplication = useBlacklistStore((s) => s.publishApplication);
	const rejectApplication = useBlacklistStore((s) => s.rejectApplication);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [rejecting, setRejecting] = (0, import_react.useState)(null);
	const [lightbox, setLightbox] = (0, import_react.useState)(null);
	const inbox = hydrated ? applications.filter((a) => a.id !== "EPB-SEED").sort((a, b) => b.createdAt - a.createdAt) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatHeader, {
				title: "Арбитры",
				subtitle: "закрытый чат · публикация в канал",
				onBack,
				avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4 text-gold" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4 md:px-6",
				children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Загружаем заявки…"
				}) : inbox.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-surface px-4 py-8 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display font-bold",
						children: "Очередь пуста"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Новые заявки из Mini App появляются здесь с кнопками «Опубликовать» и «Отклонить»."
					})]
				}) : inbox.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "max-w-[min(100%,40rem)] rounded-2xl rounded-tl-md bg-surface p-4 shadow-[0_0_0_1px_rgba(243,239,228,0.07)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs font-medium tracking-wide text-muted",
								children: ["Заявка ", app.id]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: app.status })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Пострадавший",
									value: `@${app.victim.username.replace(/^@/, "")} · ID ${app.victim.telegramId}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Мошенник",
									value: `${app.scammer.username ? `@${app.scammer.username.replace(/^@/, "")} · ` : ""}ID ${app.scammer.telegramId}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Ущерб",
									value: `${app.damageAmount} ${app.damageCurrency}`
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs font-medium text-muted",
							children: "Суть обмана"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 whitespace-pre-wrap text-sm leading-relaxed text-pretty",
							children: app.story
						}),
						app.evidence.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1.5 text-xs font-medium text-muted",
								children: "Доказательства"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceGallery, {
								items: app.evidence,
								onOpen: setLightbox
							})]
						}) : null,
						app.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "rounded-lg",
								onClick: () => setPreview(app),
								children: "Опубликовать"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "danger",
								className: "rounded-lg",
								onClick: () => setRejecting(app),
								children: "Отклонить"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-right text-xs text-subtle",
							children: format(app.createdAt, "d MMM, HH:mm", { locale: ru })
						})
					]
				}, app.id))
			}),
			preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConfirmModal, {
				title: "Публикация в канал",
				confirmLabel: "Опубликовать",
				onCancel: () => setPreview(null),
				onConfirm: () => {
					publishApplication(preview.id);
					setPreview(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Пост уйдёт в канал в таком виде:"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 rounded-lg bg-bg p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostBody, { app: preview })
				})]
			}) : null,
			rejecting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmModal, {
				title: "Отклонить заявку",
				confirmLabel: "Отклонить",
				danger: true,
				onCancel: () => setRejecting(null),
				onConfirm: () => {
					rejectApplication(rejecting.id);
					setRejecting(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Заявка ",
						rejecting.id,
						" будет отклонена. В канал ничего не публикуется."
					]
				})
			}) : null,
			lightbox ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				item: lightbox,
				onClose: () => setLightbox(null)
			}) : null
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "font-medium tabular-nums text-fg",
		children: value
	})] });
}
function StatusPill({ status }) {
	const item = {
		pending: {
			label: "на рассмотрении",
			className: "text-gold"
		},
		published: {
			label: "опубликовано",
			className: "text-ok"
		},
		rejected: {
			label: "отклонено",
			className: "text-danger"
		}
	}[status];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("text-xs font-semibold uppercase tracking-wide", item.className),
		children: item.label
	});
}
function ConfirmModal({ title, children, confirmLabel, danger, onConfirm, onCancel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg font-bold",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: onCancel,
						children: "Назад"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: danger ? "danger" : "default",
						onClick: onConfirm,
						children: confirmLabel
					})]
				})
			]
		})
	});
}
function Lightbox({ item, onClose }) {
	const src = evidenceSrc(item);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/90 p-4",
		onClick: onClose,
		role: "presentation",
		children: item.kind === "video" && src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			controls: true,
			autoPlay: true,
			className: "max-h-[80dvh] max-w-full rounded-lg",
			onClick: (e) => e.stopPropagation()
		}) : src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: item.name,
			className: "max-h-[80dvh] max-w-full rounded-lg img-outline",
			onClick: (e) => e.stopPropagation()
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: "Файл недоступен в этой сессии"
		})
	});
}
function ChannelFeed({ onBack }) {
	const hydrated = useHydrated();
	const applications = useBlacklistStore((s) => s.applications);
	const posts = hydrated ? applications.filter((a) => a.status === "published").sort((a, b) => (b.publishedAt ?? b.createdAt) - (a.publishedAt ?? a.createdAt)) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatHeader, {
			title: CHANNEL_NAME,
			subtitle: "канал · только одобренные кейсы",
			onBack,
			avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-4 text-gold" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 space-y-4 overflow-y-auto px-3 py-4 md:px-6",
			children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Загружаем канал…"
			}) : posts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-surface px-4 py-8 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display font-bold",
					children: "Пока нет публикаций"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Одобренные арбитрами заявки появляются здесь по шаблону."
				})]
			}) : posts.map((app) => {
				const at = app.publishedAt ?? app.createdAt;
				const time = isToday(at) ? format(at, "HH:mm") : format(at, "d MMM, HH:mm", { locale: ru });
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "max-w-[min(100%,40rem)] rounded-2xl rounded-tl-md bg-surface p-4 shadow-[0_0_0_1px_rgba(243,239,228,0.07)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostBody, { app }),
						app.evidence.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceGallery, { items: app.evidence })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-right text-xs text-subtle",
							children: time
						})
					]
				}, app.id);
			})
		})]
	});
}
function ChatsList({ active, onOpen, className }) {
	const hydrated = useHydrated();
	const pending = useBlacklistStore((s) => s.applications.filter((a) => a.status === "pending").length);
	const count = hydrated ? pending : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: cn("flex h-full min-h-0 w-full flex-col border-line bg-bg-elevated md:w-80 md:border-r", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "flex h-14 items-center px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-base font-bold tracking-tight",
					children: "Чаты"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "min-h-0 flex-1 overflow-y-auto px-2 pb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatRow, {
						active: active === "bot",
						onClick: () => onOpen("bot"),
						avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, { size: 28 }),
						title: "EPB Bot",
						preview: "Откройте приложение и подайте заявку"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatRow, {
						active: active === "arbiters",
						onClick: () => onOpen("arbiters"),
						avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-gold" }),
						title: "Арбитры",
						preview: count ? `${count} на рассмотрении` : "Закрытый чат проверки",
						badge: count
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatRow, {
						active: active === "channel",
						onClick: () => onOpen("channel"),
						avatar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-5 text-gold" }),
						title: "Europe Private Blacklist",
						preview: "Канал публикаций",
						meta: "канал"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line p-3 md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs leading-relaxed text-muted",
					children: "Превью пути: бот → приложение → арбитры → канал"
				})
			})
		]
	});
}
function ChatRow({ active, onClick, avatar, title, preview, badge, meta }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex w-full items-center gap-3 rounded-xl px-2 py-2.5 text-left transition-colors duration-150", active ? "bg-surface" : "hover:bg-surface/70"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-12 shrink-0 items-center justify-center rounded-full bg-surface-2 text-gold",
				children: avatar
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-semibold text-fg",
						children: title
					}), meta ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-subtle",
						children: meta
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 block truncate text-sm text-muted",
					children: preview
				})]
			}),
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1.5 text-xs font-bold text-gold-fg",
				children: badge
			}) : null
		]
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("flex h-11 w-full rounded-md bg-surface px-3 text-base text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none transition-[box-shadow,background-color] duration-150 placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.55)]", "disabled:cursor-not-allowed disabled:opacity-50", "file:mr-3 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-fg", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("flex min-h-32 w-full rounded-lg bg-surface px-3 py-3 text-base leading-relaxed text-fg shadow-[0_0_0_1px_rgba(243,239,228,0.10)] outline-none transition-[box-shadow] duration-150 placeholder:text-subtle", "focus-visible:shadow-[0_0_0_2px_rgba(240,196,48,0.55)]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
var CURRENCIES = [
	"EUR",
	"USD",
	"USDT",
	"RUB"
];
function ApplyForm({ onSubmitted }) {
	const identity = useBlacklistStore((s) => s.identity);
	const setIdentity = useBlacklistStore((s) => s.setIdentity);
	const submitApplication = useBlacklistStore((s) => s.submitApplication);
	const [victimUser, setVictimUser] = (0, import_react.useState)(identity.username);
	const [victimId, setVictimId] = (0, import_react.useState)(identity.telegramId);
	const [victimResolving, setVictimResolving] = (0, import_react.useState)(false);
	const [scammerInput, setScammerInput] = (0, import_react.useState)("");
	const [scammerUser, setScammerUser] = (0, import_react.useState)("");
	const [scammerId, setScammerId] = (0, import_react.useState)("");
	const [scammerResolving, setScammerResolving] = (0, import_react.useState)(false);
	const [scammerError, setScammerError] = (0, import_react.useState)("");
	const [story, setStory] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("EUR");
	const [files, setFiles] = (0, import_react.useState)([]);
	const [formError, setFormError] = (0, import_react.useState)("");
	const [sending, setSending] = (0, import_react.useState)(false);
	const fromTelegram = (0, import_react.useMemo)(() => Boolean(readTelegramWebUser()), []);
	(0, import_react.useEffect)(() => {
		const tg = readTelegramWebUser();
		if (!tg) return;
		setIdentity(tg);
		setVictimUser(tg.username);
		setVictimId(tg.telegramId);
	}, [setIdentity]);
	(0, import_react.useEffect)(() => {
		const handle = victimUser.trim();
		if (!handle || fromTelegram) return;
		let cancelled = false;
		setVictimResolving(true);
		const t = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await resolveTelegramHandle({ data: { input: handle } });
				} catch {
					res = await resolveTelegramId(handle);
				}
				if (cancelled) return;
				setVictimResolving(false);
				if (res?.id) {
					setVictimId(res.id);
					setIdentity({
						username: res.username || handle.replace(/^@/, ""),
						telegramId: res.id
					});
				}
			})();
		}, 480);
		return () => {
			cancelled = true;
			clearTimeout(t);
		};
	}, [
		victimUser,
		fromTelegram,
		setIdentity
	]);
	(0, import_react.useEffect)(() => {
		const value = scammerInput.trim();
		setScammerError("");
		if (!value) {
			setScammerUser("");
			setScammerId("");
			return;
		}
		let cancelled = false;
		setScammerResolving(true);
		const t = setTimeout(() => {
			(async () => {
				let res = null;
				try {
					res = await resolveTelegramHandle({ data: { input: value } });
				} catch {
					res = await resolveTelegramId(value);
				}
				if (cancelled) return;
				setScammerResolving(false);
				if (!res) {
					setScammerUser("");
					setScammerId("");
					setScammerError("Не удалось разобрать username или ID");
					return;
				}
				setScammerUser(res.username);
				setScammerId(res.id);
			})();
		}, 520);
		return () => {
			cancelled = true;
			clearTimeout(t);
		};
	}, [scammerInput]);
	async function onSubmit(e) {
		e.preventDefault();
		setFormError("");
		const vUser = victimUser.replace(/^@/, "").trim();
		if (!vUser) {
			setFormError("Укажите ваш Telegram, чтобы арбитры могли связаться");
			return;
		}
		if (!victimId) {
			setFormError("ID пострадавшего ещё подтягивается");
			return;
		}
		if (!scammerId) {
			setFormError("Укажите Telegram мошенника — ID подтянется сам");
			return;
		}
		if (story.trim().length < 20) {
			setFormError("Опишите схему подробнее (от 20 символов)");
			return;
		}
		if (!amount.trim() || Number(amount) <= 0) {
			setFormError("Укажите сумму ущерба");
			return;
		}
		if (!files.length) {
			setFormError("Прикрепите хотя бы одно доказательство");
			return;
		}
		setSending(true);
		const app = {
			id: `EPB-${uid().slice(0, 4).toUpperCase()}`,
			createdAt: Date.now(),
			status: "pending",
			victim: {
				username: vUser,
				telegramId: victimId,
				firstName: identity.firstName
			},
			scammer: {
				username: scammerUser,
				telegramId: scammerId
			},
			story: story.trim(),
			damageAmount: amount.trim(),
			damageCurrency: currency,
			evidence: files
		};
		submitApplication(app);
		setIdentity({
			username: vUser,
			telegramId: victimId
		});
		let notice = "Заявка сохранена. Telegram ещё не принял — добавьте бота в чат арбитров.";
		try {
			const tg = await submitToTelegram({ data: app });
			notice = tg.ok ? "Заявка ушла в чат арбитров в Telegram." : tg.error || notice;
		} catch {}
		setSending(false);
		onSubmitted(notice);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "flex flex-col gap-8 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Пострадавший"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: fromTelegram ? "Данные подтянуты из Telegram. Username нужен, чтобы арбитры могли написать вам." : "В Mini App username и ID приходят из Telegram. Сейчас можно указать вручную — ID подтянется сам."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ваш Telegram",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: victimUser ? victimUser.startsWith("@") ? victimUser : `@${victimUser}` : "",
							onChange: (e) => setVictimUser(e.target.value.replace(/^@/, "")),
							placeholder: "@username",
							autoComplete: "username",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdStatus, {
						label: "Ваш ID",
						idValue: victimId,
						resolving: victimResolving,
						emptyText: "Подтянется из username"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Мошенник"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Username, t.me-ссылка или числовой ID. Telegram ID подтягивается автоматически."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Telegram мошенника",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: scammerInput,
							onChange: (e) => setScammerInput(e.target.value),
							placeholder: "@username или t.me/…",
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdStatus, {
						label: "ID мошенника",
						idValue: scammerId,
						resolving: scammerResolving,
						emptyText: "Введите username — ID появится сам"
					}),
					scammerError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-danger",
						children: scammerError
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Суть обмана"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Как связывались, что обещали, куда просили перевести. Этот текст уйдёт в пост, если заявку одобрят."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: story,
						onChange: (e) => setStory(e.target.value),
						placeholder: "Например: якобы продаёт FTP, клянчит по 50–100$, включает дурачка и пропадает."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Сумма ущерба",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "decimal",
								value: amount,
								onChange: (e) => setAmount(e.target.value.replace(/[^\d.,]/g, "")),
								placeholder: "100"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Валюта",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex h-11 overflow-hidden rounded-md shadow-[0_0_0_1px_rgba(243,239,228,0.10)]",
								children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setCurrency(c),
									className: cn("min-w-0 flex-1 px-2 text-xs font-semibold transition-colors duration-150", currency === c ? "bg-gold text-gold-fg" : "bg-surface text-muted hover:text-fg"),
									children: c
								}, c))
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-bold",
						children: "Доказательства"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Переписка, чеки, видеозвонки — всё, что подтверждает схему."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidencePicker, {
					files,
					onChange: setFiles
				})]
			}),
			formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: formError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky bottom-0 z-10 -mx-4 mt-2 border-t border-line bg-bg/95 p-4 pb-8 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full rounded-xl",
					disabled: sending,
					children: sending ? "Отправляем…" : "Отправить на рассмотрение"
				})
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function IdStatus({ label, idValue, resolving, emptyText }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3 rounded-md bg-surface px-3 py-2.5 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-medium text-muted",
			children: label
		}), resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex items-center gap-1.5 text-sm text-gold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-3.5 animate-spin" }), "Подтягиваем ID…"]
		}) : idValue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium tabular-nums text-fg",
			children: idValue
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-subtle",
			children: emptyText
		})] }), idValue && !resolving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-8 items-center justify-center rounded-full bg-ok/15 text-ok",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" })
		}) : null]
	});
}
function MiniApp({ page, onPage, onClose, onReview, embedded = false }) {
	const [notice, setNotice] = (0, import_react.useState)("");
	const title = page === "apply" ? "Заявка на блеклист" : page === "mine" ? "Мои заявки" : page === "done" ? "Заявка отправлена" : "Europe Private Blacklist";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex h-dvh flex-col bg-bg text-fg", !embedded && "fixed inset-0 z-50 items-center"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-full w-full max-w-lg flex-col",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-2 py-2",
				children: [page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-11 flex-1 items-center px-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, { size: 36 })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-md text-fg hover:bg-surface",
					onClick: () => onPage("home"),
					"aria-label": "Назад",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "flex-1 font-display text-sm font-bold tracking-tight",
					children: title
				})] }), onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-md text-muted hover:bg-surface hover:text-fg",
					onClick: onClose,
					"aria-label": "Закрыть приложение",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-md px-4 py-6",
					children: [
						page === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, { onPage }) : null,
						page === "apply" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApplyForm, { onSubmitted: (msg) => {
							setNotice(msg ?? "");
							onPage("done");
						} }) : null,
						page === "mine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MyReports, {}) : null,
						page === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Done, {
							onPage,
							onClose,
							onReview,
							notice
						}) : null
					]
				})
			})]
		})
	});
}
function Home$1({ onPage }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70dvh] flex-col items-center justify-center py-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "star-breathe rise-in",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
					size: 120,
					title: "Europe Private Blacklist"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "rise-in mt-8 font-display text-3xl font-extrabold tracking-tight",
				children: ["Europe Private", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-gold",
					children: "Blacklist"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise-in mt-3 max-w-xs text-sm leading-relaxed text-muted",
				children: "Закрытый европейский блеклист. Заявка уходит арбитрам — публикация только после проверки."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rise-in mt-10 flex w-full flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: () => onPage("apply"),
					children: "Подать заявку на блеклист"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "secondary",
					className: "w-full rounded-xl",
					onClick: () => onPage("mine"),
					children: "Мои заявки"
				})]
			})
		]
	});
}
function Done({ onPage, onClose, onReview, notice }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[60dvh] flex-col items-center justify-center py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-16 items-center justify-center rounded-full bg-gold text-gold-fg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EuStarsLogo, {
					size: 40,
					className: "text-gold-fg"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl font-bold",
				children: "Заявка у арбитров"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm text-sm leading-relaxed text-muted",
				children: notice || "Материалы ушли в закрытый чат. Если кейс подтвердят — карточка выйдет в канал. Если нет — публикации не будет."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex w-full flex-col gap-3",
				children: [onReview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: onReview,
					children: "Открыть чат арбитров"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					className: "w-full rounded-xl",
					onClick: () => onPage("mine"),
					children: "Смотреть статус"
				}), onClose ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "ghost",
					className: "w-full",
					onClick: onClose,
					children: "Закрыть приложение"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "lg",
					variant: "ghost",
					className: "w-full",
					onClick: () => onPage("home"),
					children: "На главную"
				})]
			})
		]
	});
}
function MyReports() {
	const hydrated = useHydrated();
	const identity = useBlacklistStore((s) => s.identity);
	const mine = useBlacklistStore((s) => s.applications).filter((a) => a.victim.telegramId === identity.telegramId || a.victim.username.toLowerCase() === identity.username.toLowerCase());
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Загружаем заявки…"
	});
	if (!mine.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-lg font-bold",
			children: "Пока пусто"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: "Отправленные заявки появятся здесь со статусом."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-3",
		children: mine.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportCard, { app }) }, app.id))
	});
}
function ReportCard({ app }) {
	const label = app.status === "pending" ? "На рассмотрении" : app.status === "published" ? "Опубликовано" : "Отклонено";
	const tone = app.status === "pending" ? "text-gold" : app.status === "published" ? "text-ok" : "text-danger";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface p-4 shadow-[0_0_0_1px_rgba(243,239,228,0.08)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted",
					children: app.id
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("text-xs font-semibold uppercase tracking-wide", tone),
					children: label
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostBody, { app })
			}),
			app.evidence.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EvidenceGallery, { items: app.evidence })
			}) : null
		]
	});
}
function TelegramSimulator() {
	const [activeChat, setActiveChat] = (0, import_react.useState)(null);
	const [miniOpen, setMiniOpen] = (0, import_react.useState)(false);
	const [miniPage, setMiniPage] = (0, import_react.useState)("home");
	const resetDemo = useBlacklistStore((s) => s.resetDemo);
	const chat = activeChat ?? "bot";
	const showListOnMobile = activeChat === null;
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape" && miniOpen) setMiniOpen(false);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [miniOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden items-center justify-between gap-3 border-b border-line px-4 py-2 md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, { size: 32 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					className: "text-muted",
					onClick: () => {
						resetDemo();
						setActiveChat(null);
						setMiniOpen(false);
						setMiniPage("home");
					},
					children: "Сбросить демо"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatsList, {
					active: chat,
					onOpen: setActiveChat,
					className: cn(showListOnMobile ? "flex" : "hidden md:flex")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: cn("min-w-0 flex-1", showListOnMobile ? "hidden md:flex md:flex-col" : "flex flex-col"),
					children: [
						chat === "bot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotChat, {
							onBack: () => setActiveChat(null),
							onOpenApp: () => {
								setMiniPage("home");
								setMiniOpen(true);
							}
						}) : null,
						chat === "arbiters" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArbiterChat, { onBack: () => setActiveChat(null) }) : null,
						chat === "channel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelFeed, { onBack: () => setActiveChat(null) }) : null
					]
				})]
			}),
			miniOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniApp, {
				page: miniPage,
				onPage: setMiniPage,
				onReview: () => {
					setMiniOpen(false);
					setActiveChat("arbiters");
				},
				onClose: () => {
					setMiniOpen(false);
					if (miniPage === "done") setActiveChat("arbiters");
				}
			}) : null
		]
	});
}
function TelegramOnlyMiniApp() {
	const [page, setPage] = (0, import_react.useState)("home");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniApp, {
		page,
		onPage: setPage,
		embedded: true
	});
}
function Home() {
	const [inTelegram, setInTelegram] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if ((window.Telegram?.WebApp)?.initData) {
			bootTelegramWebApp();
			setInTelegram(true);
		}
		configureTelegram({ data: { origin: window.location.origin } }).catch(() => {});
	}, []);
	if (inTelegram) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramOnlyMiniApp, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelegramSimulator, {});
}
//#endregion
export { Home as component };
