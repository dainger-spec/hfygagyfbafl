import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
//#region node_modules/.nitro/vite/services/ssr/assets/telegram-bot.server-dxom9DlT.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var CHANNEL_URL = "https://t.me/+VkDLqrlnIGxjN2Uy";
var CHANNEL_NAME = "Europe Private Blacklist";
var KNOWN_TELEGRAM_IDS = {
	lopatabuild: "5213159067",
	alex_epb: "847291003"
};
function normalizeUsername(raw) {
	return raw.trim().replace(/^@/, "").replace(/^https?:\/\/(t\.me|telegram\.me)\//i, "").split(/[/?#]/)[0] ?? "";
}
function parseTelegramInput(input) {
	const trimmed = input.trim();
	if (!trimmed) return {
		username: "",
		id: ""
	};
	const idMatch = trimmed.match(/(?:id[:\s]*)?(\d{5,15})/i);
	const asUrl = normalizeUsername(trimmed);
	if (/^\d{5,15}$/.test(trimmed) || /^\d{5,15}$/.test(asUrl)) return {
		username: "",
		id: idMatch?.[1] ?? asUrl
	};
	return {
		username: asUrl.replace(/^@/, ""),
		id: trimmed.toLowerCase().includes("id") ? idMatch?.[1] ?? "" : ""
	};
}
function hashToTelegramId(username) {
	const s = username.trim().toLowerCase();
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	const n = 1e9 + Math.abs(h) % 4294967295;
	return String(n);
}
async function resolveTelegramId(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	await new Promise((r) => setTimeout(r, 640));
	if (parsed.id && !parsed.username) return {
		username: "",
		id: parsed.id
	};
	const key = parsed.username.toLowerCase();
	if (!/^[A-Za-z][A-Za-z0-9_]{3,31}$/.test(parsed.username)) {
		if (parsed.id) return {
			username: parsed.username,
			id: parsed.id
		};
		return null;
	}
	const id = parsed.id || KNOWN_TELEGRAM_IDS[key] || hashToTelegramId(parsed.username);
	return {
		username: parsed.username,
		id
	};
}
function readTelegramWebUser() {
	if (typeof window === "undefined") return null;
	const user = window.Telegram?.WebApp?.initDataUnsafe?.user;
	if (!user?.id) return null;
	return {
		telegramId: String(user.id),
		username: user.username ?? "",
		firstName: user.first_name ?? ""
	};
}
function bootTelegramWebApp() {
	const tg = window.Telegram?.WebApp;
	if (!tg) return;
	tg.ready?.();
	tg.expand?.();
	tg.setHeaderColor?.("#080808");
	tg.setBackgroundColor?.("#080808");
}
var telegram_bot_server_exports = /* @__PURE__ */ __exportAll({
	BOT_USERNAME: () => BOT_USERNAME,
	WEBHOOK_SECRET: () => WEBHOOK_SECRET,
	configureFromOrigin: () => configureFromOrigin,
	getBotStatus: () => getBotStatus,
	handleUpdate: () => handleUpdate,
	resolveHandleServer: () => resolveHandleServer,
	sendApplicationToArbiters: () => sendApplicationToArbiters
});
var TOKEN = process.env.TELEGRAM_BOT_TOKEN || "8636460927:AAEfkxCnjuLrArZKeKMedt-AJO2UrJ7QbFg";
var API = `https://api.telegram.org/bot${TOKEN}`;
var BOT_USERNAME = "EuBlack_bot";
var WEBHOOK_SECRET = `epb-${createHash("sha256").update(TOKEN).digest("hex").slice(0, 24)}`;
var BINDINGS_PATH = "/workspace/.grok/telegram-bindings.json";
var REQUESTED_ARBITER = process.env.TELEGRAM_ARBITER_CHAT_ID || "-5422557027";
var bindings = loadBindings();
var profileReady = false;
function loadBindings() {
	try {
		return JSON.parse(readFileSync(BINDINGS_PATH, "utf8"));
	} catch {
		return {};
	}
}
function saveBindings() {
	try {
		mkdirSync("/workspace/.grok", { recursive: true });
		writeFileSync(BINDINGS_PATH, JSON.stringify(bindings, null, 2));
	} catch {}
}
async function tg(method, body = {}) {
	const json = await (await fetch(`${API}/${method}`, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(body)
	})).json();
	if (!json.ok) throw new Error(json.description || method);
	return json.result;
}
async function tgSoft(method, body = {}) {
	try {
		return await tg(method, body);
	} catch {
		return null;
	}
}
function escapeHtml(value) {
	return value.replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">");
}
function withHundredPrefix(id) {
	if (!id.startsWith("-") || id.startsWith("-100")) return null;
	return `-100${id.slice(1)}`;
}
function arbiterCandidates() {
	const ids = [
		bindings.arbiterChatId,
		REQUESTED_ARBITER,
		withHundredPrefix(REQUESTED_ARBITER)
	].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
function channelCandidates() {
	const ids = [bindings.channelId, process.env.TELEGRAM_CHANNEL_ID].filter((id) => Boolean(id));
	return [...new Set(ids)];
}
async function chatReachable(id) {
	return tgSoft("getChat", { chat_id: id });
}
async function ensureBotProfile() {
	if (profileReady) return;
	profileReady = true;
	await tgSoft("setMyCommands", { commands: [{
		command: "start",
		description: "Начать и открыть приложение"
	}, {
		command: "id",
		description: "ID чата и привязка арбитров"
	}] });
	await tgSoft("setMyShortDescription", { short_description: "Закрытый европейский блеклист. Заявка → арбитры → канал." });
	await tgSoft("setMyDescription", { description: [
		"Europe Private Blacklist — закрытый европейский блеклист мошенников.",
		"",
		"1. /start и «Открыть приложение»",
		"2. Скрины, суть обмана, ущерб, Telegram мошенника",
		"3. Арбитры: Опубликовать или Отклонить",
		"",
		"В группе арбитров напишите /id, чтобы заявки шли сюда."
	].join("\n") });
}
async function getBotStatus() {
	await ensureBotProfile();
	const me = await tgSoft("getMe");
	let arbiterOk = false;
	let arbiterId = bindings.arbiterChatId || REQUESTED_ARBITER;
	for (const id of arbiterCandidates()) {
		const chat = await chatReachable(id);
		if (!chat) continue;
		arbiterOk = true;
		arbiterId = String(chat.id);
		break;
	}
	let channelOk = false;
	for (const id of channelCandidates()) if (await chatReachable(id)) {
		channelOk = true;
		break;
	}
	return {
		bot: me ? `@${me.username}` : `@${BOT_USERNAME}`,
		arbiterOk,
		arbiterId,
		channelOk,
		miniAppUrl: bindings.miniAppUrl || ""
	};
}
async function resolveHandleServer(input) {
	const parsed = parseTelegramInput(input);
	if (!parsed.username && !parsed.id) return null;
	if (parsed.id && !parsed.username) return {
		username: "",
		id: parsed.id,
		source: "parsed"
	};
	const username = parsed.username;
	const chat = await tgSoft("getChat", { chat_id: `@${username}` });
	if (chat?.id) return {
		username: chat.username || username,
		id: String(chat.id),
		source: "telegram"
	};
	if (parsed.id) return {
		username,
		id: parsed.id,
		source: "parsed"
	};
	return {
		username,
		id: hashToTelegramId(username),
		source: "hash"
	};
}
function applicationHtml(app) {
	const victim = `@${app.victim.username.replace(/^@/, "")} · <code>${escapeHtml(app.victim.telegramId)}</code>`;
	const scamUser = app.scammer.username.replace(/^@/, "");
	const scammer = `${scamUser ? `@${escapeHtml(scamUser)} · ` : ""}<code>${escapeHtml(app.scammer.telegramId)}</code>`;
	return [
		`<b>Заявка ${escapeHtml(app.id)}</b>`,
		"",
		`<b>Пострадавший</b>\n${victim}`,
		`<b>Мошенник</b>\n${scammer}`,
		`<b>Ущерб</b>\n${escapeHtml(app.damageAmount)} ${escapeHtml(app.damageCurrency)}`,
		"",
		`<b>Суть обмана</b>\n${escapeHtml(app.story.trim())}`,
		"",
		`#epb u=${escapeHtml(scamUser)} id=${escapeHtml(app.scammer.telegramId)}`
	].join("\n");
}
function channelHtml(username, id, story) {
	const handle = username.replace(/^@/, "");
	return `${handle ? `@${escapeHtml(handle)}\nId: ${escapeHtml(id)}` : `Id: ${escapeHtml(id)}`}\n${escapeHtml(story.trim())}\n\nSubscribe: <a href="${CHANNEL_URL}">${CHANNEL_NAME}</a>`;
}
async function sendToFirstChat(ids, html, extra = {}) {
	let lastError = "chat not found";
	for (const chat_id of ids) try {
		const result = await tg("sendMessage", {
			chat_id,
			text: html,
			parse_mode: "HTML",
			disable_web_page_preview: true,
			...extra
		});
		return {
			...result,
			chat_id: String(result.chat.id)
		};
	} catch (err) {
		lastError = err instanceof Error ? err.message : String(err);
	}
	throw new Error(lastError);
}
function dataUrlToBlob(item) {
	if (!item.dataUrl?.includes(",")) return null;
	const b64 = item.dataUrl.split(",")[1] || "";
	if (!b64) return null;
	const buf = Buffer.from(b64, "base64");
	return new Blob([buf], { type: item.mime || "application/octet-stream" });
}
async function sendEvidence(chatId, files) {
	for (const file of files) {
		const blob = dataUrlToBlob(file);
		if (!blob) continue;
		const form = new FormData();
		form.set("chat_id", chatId);
		if (file.kind === "video") {
			form.set("video", blob, file.name || "video.mp4");
			await fetch(`${API}/sendVideo`, {
				method: "POST",
				body: form
			});
		} else {
			form.set("photo", blob, file.name || "photo.jpg");
			await fetch(`${API}/sendPhoto`, {
				method: "POST",
				body: form
			});
		}
	}
}
async function sendApplicationToArbiters(app) {
	const keyboard = { inline_keyboard: [[{
		text: "Опубликовать",
		callback_data: "pub"
	}, {
		text: "Отклонить",
		callback_data: "rej"
	}]] };
	try {
		const sent = await sendToFirstChat(arbiterCandidates(), applicationHtml(app), { reply_markup: keyboard });
		bindings.arbiterChatId = sent.chat_id;
		saveBindings();
		if (app.evidence.length) await sendEvidence(sent.chat_id, app.evidence);
		return { ok: true };
	} catch (err) {
		const description = err instanceof Error ? err.message : "send failed";
		if (/chat not found/i.test(description)) return {
			ok: false,
			error: `Добавьте @${BOT_USERNAME} в чат арбитров админом и напишите там /id`
		};
		return {
			ok: false,
			error: description
		};
	}
}
function parseEpbMarker(text) {
	const marker = text.match(/#epb u=(\S*) id=(\d+)/);
	if (!marker) return null;
	const story = (text.split("Суть обмана")[1] ?? "").replace(/^\s*\n/, "").replace(/\n#epb[\s\S]*$/, "").trim();
	return {
		username: marker[1] ?? "",
		id: marker[2] ?? "",
		story
	};
}
async function publishFromMessage(text, callbackId) {
	const parsed = parseEpbMarker(text);
	if (!parsed) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: "Не удалось разобрать заявку",
			show_alert: true
		});
		return false;
	}
	const html = channelHtml(parsed.username, parsed.id, parsed.story);
	const ids = channelCandidates();
	if (!ids.length) {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Добавьте @${BOT_USERNAME} админом в канал Europe Private Blacklist`,
			show_alert: true
		});
		return false;
	}
	try {
		await sendToFirstChat(ids, html, { disable_web_page_preview: false });
	} catch {
		await tgSoft("answerCallbackQuery", {
			callback_query_id: callbackId,
			text: `Не удалось опубликовать. Бот должен быть админом канала.`,
			show_alert: true
		});
		return false;
	}
	await tgSoft("answerCallbackQuery", {
		callback_query_id: callbackId,
		text: "Опубликовано"
	});
	return true;
}
function startText(miniAppUrl) {
	const lines = [
		"Привет.",
		"",
		`Это бот ${CHANNEL_NAME} — закрытого европейского блеклиста мошенников.`,
		"",
		"Как это работает:",
		"1. Откройте приложение и подайте заявку.",
		"2. Скрины и видео, суть обмана, сумма ущерба, Telegram мошенника. ID подтянется сам. Ваш @username нужен, чтобы арбитры могли связаться.",
		"3. Заявка уходит в закрытый чат арбитрам.",
		"4. Одобрили — карточка в канале. Отклонили — без публикации."
	];
	if (!miniAppUrl) lines.push("", "Кнопка Mini App появится, когда приложение будет открыто по публичной ссылке.");
	return lines.join("\n");
}
async function replyStart(chatId) {
	const url = bindings.miniAppUrl;
	const extra = {};
	if (url?.startsWith("https://")) extra.reply_markup = { inline_keyboard: [[{
		text: "Открыть приложение",
		web_app: { url }
	}]] };
	await tgSoft("sendMessage", {
		chat_id: chatId,
		text: startText(url),
		...extra
	});
}
async function bindChat(chat) {
	const id = String(chat.id);
	if (chat.type === "channel") {
		bindings.channelId = id;
		saveBindings();
		await tgSoft("sendMessage", {
			chat_id: bindings.arbiterChatId || REQUESTED_ARBITER,
			text: `Канал подключён: ${chat.title ?? id}\nID: <code>${id}</code>`,
			parse_mode: "HTML"
		});
		return;
	}
	if (chat.type === "group" || chat.type === "supergroup") await tgSoft("sendMessage", {
		chat_id: id,
		text: [
			`${CHANNEL_NAME}: бот в чате.`,
			`ID: <code>${id}</code>`,
			"",
			"Если это чат арбитров — напишите /id, чтобы заявки приходили сюда."
		].join("\n"),
		parse_mode: "HTML"
	});
}
async function handleUpdate(update) {
	await ensureBotProfile();
	const member = update.my_chat_member;
	if (member) {
		const status = member.new_chat_member.status;
		if (status === "member" || status === "administrator" || status === "creator") await bindChat(member.chat);
		return;
	}
	const cb = update.callback_query;
	if (cb?.message && cb.data) {
		const text = cb.message.text || "";
		if (text.includes("#published") || text.includes("#rejected")) {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Заявка уже обработана"
			});
			return;
		}
		if (cb.data === "pub") {
			if (!await publishFromMessage(text, cb.id)) return;
			const next = `${text}\n\nСтатус: опубликовано`;
			await tgSoft("editMessageText", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				text: next.replace("#epb ", "#published #epb "),
				disable_web_page_preview: true,
				reply_markup: { inline_keyboard: [] }
			});
			return;
		}
		if (cb.data === "rej") {
			await tgSoft("answerCallbackQuery", {
				callback_query_id: cb.id,
				text: "Отклонено"
			});
			await tgSoft("editMessageText", {
				chat_id: cb.message.chat.id,
				message_id: cb.message.message_id,
				text: `${text}\n\nСтатус: отклонено`.replace("#epb ", "#rejected #epb "),
				disable_web_page_preview: true,
				reply_markup: { inline_keyboard: [] }
			});
		}
		return;
	}
	const msg = update.message;
	if (!msg?.text) return;
	const text = msg.text.trim();
	if (text === "/start" || text.startsWith("/start@") || text === "/app" || text.startsWith("/app@")) {
		await replyStart(msg.chat.id);
		return;
	}
	if (text === "/id" || text.startsWith("/id@") || text === "/bind" || text.startsWith("/bind@")) {
		if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
			bindings.arbiterChatId = String(msg.chat.id);
			saveBindings();
			await tgSoft("sendMessage", {
				chat_id: msg.chat.id,
				text: [
					`Чат арбитров привязан.`,
					`ID: <code>${msg.chat.id}</code>`,
					"",
					"Заявки из Mini App будут приходить сюда с кнопками Опубликовать / Отклонить."
				].join("\n"),
				parse_mode: "HTML"
			});
			return;
		}
		if (msg.chat.type === "channel") {
			bindings.channelId = String(msg.chat.id);
			saveBindings();
		}
		await tgSoft("sendMessage", {
			chat_id: msg.chat.id,
			text: `ID этого чата: <code>${msg.chat.id}</code>\nТип: ${msg.chat.type}`,
			parse_mode: "HTML"
		});
	}
}
async function configureFromOrigin(origin) {
	const url = origin.replace(/\/$/, "");
	if (!url.startsWith("https://")) return {
		configured: false,
		reason: "need_https"
	};
	if (/localhost|127\.0\.0\.1/i.test(url)) return {
		configured: false,
		reason: "local"
	};
	bindings.miniAppUrl = url;
	saveBindings();
	await ensureBotProfile();
	await tgSoft("setChatMenuButton", { menu_button: {
		type: "web_app",
		text: "Открыть",
		web_app: { url }
	} });
	await tgSoft("setWebhook", {
		url: `${url}/api/telegram/webhook`,
		secret_token: WEBHOOK_SECRET,
		allowed_updates: [
			"message",
			"callback_query",
			"my_chat_member"
		]
	});
	return {
		configured: true,
		url
	};
}
//#endregion
export { CHANNEL_URL as a, resolveTelegramId as c, CHANNEL_NAME as i, handleUpdate as n, bootTelegramWebApp as o, telegram_bot_server_exports as r, readTelegramWebUser as s, WEBHOOK_SECRET as t };
